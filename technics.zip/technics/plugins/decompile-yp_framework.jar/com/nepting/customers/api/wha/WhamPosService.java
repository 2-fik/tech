/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.ws.Service
 *  javax.xml.ws.WebEndpoint
 *  javax.xml.ws.WebServiceClient
 *  javax.xml.ws.WebServiceException
 *  javax.xml.ws.WebServiceFeature
 */
package com.nepting.customers.api.wha;

import com.nepting.customers.api.wha.WhamPosSrv;
import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.WebServiceFeature;

@WebServiceClient(name="WhamPosService", targetNamespace="urn:service.ws.mpos.appli.wha.com", wsdlLocation="file:/C:/data/svn_files/nepting/depot/SERVEUR_NEPTING/branches/DEV/web_prod/customers-api/wha/wha_jaxws/src/main/wsdl/WhamPosService.wsdl")
public class WhamPosService
extends Service {
    private static final URL WHAMPOSSERVICE_WSDL_LOCATION;
    private static final WebServiceException WHAMPOSSERVICE_EXCEPTION;
    private static final QName WHAMPOSSERVICE_QNAME;

    static {
        WHAMPOSSERVICE_QNAME = new QName("urn:service.ws.mpos.appli.wha.com", "WhamPosService");
        URL uRL = null;
        WebServiceException webServiceException = null;
        try {
            uRL = new URL("file:/C:/data/svn_files/nepting/depot/SERVEUR_NEPTING/branches/DEV/web_prod/customers-api/wha/wha_jaxws/src/main/wsdl/WhamPosService.wsdl");
        }
        catch (MalformedURLException malformedURLException) {
            webServiceException = new WebServiceException((Throwable)malformedURLException);
        }
        WHAMPOSSERVICE_WSDL_LOCATION = uRL;
        WHAMPOSSERVICE_EXCEPTION = webServiceException;
    }

    public WhamPosService() {
        super(WhamPosService.__getWsdlLocation(), WHAMPOSSERVICE_QNAME);
    }

    public WhamPosService(WebServiceFeature ... webServiceFeatureArray) {
        super(WhamPosService.__getWsdlLocation(), WHAMPOSSERVICE_QNAME, webServiceFeatureArray);
    }

    public WhamPosService(URL uRL) {
        super(uRL, WHAMPOSSERVICE_QNAME);
    }

    public WhamPosService(URL uRL, WebServiceFeature ... webServiceFeatureArray) {
        super(uRL, WHAMPOSSERVICE_QNAME, webServiceFeatureArray);
    }

    public WhamPosService(URL uRL, QName qName) {
        super(uRL, qName);
    }

    public WhamPosService(URL uRL, QName qName, WebServiceFeature ... webServiceFeatureArray) {
        super(uRL, qName, webServiceFeatureArray);
    }

    @WebEndpoint(name="WhamPosSrv")
    public WhamPosSrv getWhamPosSrv() {
        return (WhamPosSrv)super.getPort(new QName("urn:service.ws.mpos.appli.wha.com", "WhamPosSrv"), WhamPosSrv.class);
    }

    @WebEndpoint(name="WhamPosSrv")
    public WhamPosSrv getWhamPosSrv(WebServiceFeature ... webServiceFeatureArray) {
        return (WhamPosSrv)super.getPort(new QName("urn:service.ws.mpos.appli.wha.com", "WhamPosSrv"), WhamPosSrv.class, webServiceFeatureArray);
    }

    private static URL __getWsdlLocation() {
        if (WHAMPOSSERVICE_EXCEPTION != null) {
            throw WHAMPOSSERVICE_EXCEPTION;
        }
        return WHAMPOSSERVICE_WSDL_LOCATION;
    }
}

