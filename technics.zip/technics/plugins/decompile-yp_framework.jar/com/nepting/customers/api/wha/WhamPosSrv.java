/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.jws.WebMethod
 *  javax.jws.WebParam
 *  javax.jws.WebParam$Mode
 *  javax.jws.WebService
 *  javax.xml.bind.annotation.XmlSeeAlso
 *  javax.xml.ws.Holder
 *  javax.xml.ws.RequestWrapper
 *  javax.xml.ws.ResponseWrapper
 */
package com.nepting.customers.api.wha;

import com.nepting.customers.api.wha.TechnicalException;
import com.wha.appli.mpos.ws.service.ObjectFactory;
import com.wha.appli.mpos.ws.service.RecordBusinessResponse;
import com.wha.appli.mpos.ws.service.exceptions.RecordTrxExceptions;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Holder;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="WhamPosSrv", targetNamespace="urn:service.ws.mpos.appli.wha.com")
@XmlSeeAlso(value={ObjectFactory.class, com.wha.appli.mpos.ws.service.exceptions.ObjectFactory.class})
public interface WhamPosSrv {
    @WebMethod(operationName="RecordTransactionInfos", action="urn:RecordTransactionInfos")
    @RequestWrapper(localName="RecordTransactionInfos", targetNamespace="urn:service.ws.mpos.appli.wha.com", className="com.wha.appli.mpos.ws.service.TTransaction")
    @ResponseWrapper(localName="RecordTrxWhamPosResponse", targetNamespace="urn:service.ws.mpos.appli.wha.com", className="com.wha.appli.mpos.ws.service.RecordTrxWhamPosResponse")
    public void recordTransactionInfos(@WebParam(name="MerchantTransactionIdentifier", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var1, @WebParam(name="Type", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var2, @WebParam(name="Amount", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var3, @WebParam(name="Currency", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var4, @WebParam(name="Timestamp", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var5, @WebParam(name="Status", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var6, @WebParam(name="MaskedPAN", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var7, @WebParam(name="UserName", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var8, @WebParam(name="MerchantContractIdentifier", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var9, @WebParam(name="VerificationMethod", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var10, @WebParam(name="AuthorizationNumber", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var11, @WebParam(name="AuthorizationRespCode", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var12, @WebParam(name="NepSAServerResponse", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var13, @WebParam(name="TerminalSerialNumber", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var14, @WebParam(name="Scheme", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var15, @WebParam(name="EntryCondition", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var16, @WebParam(name="ApplicationType", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var17, @WebParam(name="CustomerTillReceipt", targetNamespace="urn:service.ws.mpos.appli.wha.com") String var18, @WebParam(name="RecordTrxBusinessResponse", targetNamespace="urn:service.ws.mpos.appli.wha.com", mode=WebParam.Mode.OUT) Holder<RecordBusinessResponse> var19, @WebParam(name="RecordTrxExceptions", targetNamespace="urn:service.ws.mpos.appli.wha.com", mode=WebParam.Mode.OUT) Holder<RecordTrxExceptions> var20) throws TechnicalException;
}

