/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.ws.WebFault
 */
package com.nepting.customers.api.wha;

import javax.xml.ws.WebFault;

@WebFault(name="TechnicalException", targetNamespace="urn:exceptions.service.ws.mpos.appli.wha.com")
public class TechnicalException
extends Exception {
    private com.wha.appli.mpos.ws.service.exceptions.TechnicalException faultInfo;

    public TechnicalException(String string, com.wha.appli.mpos.ws.service.exceptions.TechnicalException technicalException) {
        super(string);
        this.faultInfo = technicalException;
    }

    public TechnicalException(String string, com.wha.appli.mpos.ws.service.exceptions.TechnicalException technicalException, Throwable throwable) {
        super(string, throwable);
        this.faultInfo = technicalException;
    }

    public com.wha.appli.mpos.ws.service.exceptions.TechnicalException getFaultInfo() {
        return this.faultInfo;
    }
}

