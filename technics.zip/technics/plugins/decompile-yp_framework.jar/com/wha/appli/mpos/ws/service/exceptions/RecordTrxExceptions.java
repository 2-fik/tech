/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBElement
 *  javax.xml.bind.annotation.XmlAccessType
 *  javax.xml.bind.annotation.XmlAccessorType
 *  javax.xml.bind.annotation.XmlElementRef
 *  javax.xml.bind.annotation.XmlType
 */
package com.wha.appli.mpos.ws.service.exceptions;

import com.wha.appli.mpos.ws.service.exceptions.BusinessException;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(value=XmlAccessType.FIELD)
@XmlType(name="RecordTrxExceptions", propOrder={"unexpectedValue", "serviceDenied", "trxIdNotFound"})
public class RecordTrxExceptions {
    @XmlElementRef(name="UnexpectedValue", namespace="urn:exceptions.service.ws.mpos.appli.wha.com", type=JAXBElement.class, required=false)
    protected JAXBElement<BusinessException> unexpectedValue;
    @XmlElementRef(name="ServiceDenied", namespace="urn:exceptions.service.ws.mpos.appli.wha.com", type=JAXBElement.class, required=false)
    protected JAXBElement<BusinessException> serviceDenied;
    @XmlElementRef(name="TrxIdNotFound", namespace="urn:exceptions.service.ws.mpos.appli.wha.com", type=JAXBElement.class, required=false)
    protected JAXBElement<BusinessException> trxIdNotFound;

    public JAXBElement<BusinessException> getUnexpectedValue() {
        return this.unexpectedValue;
    }

    public void setUnexpectedValue(JAXBElement<BusinessException> jAXBElement) {
        this.unexpectedValue = jAXBElement;
    }

    public JAXBElement<BusinessException> getServiceDenied() {
        return this.serviceDenied;
    }

    public void setServiceDenied(JAXBElement<BusinessException> jAXBElement) {
        this.serviceDenied = jAXBElement;
    }

    public JAXBElement<BusinessException> getTrxIdNotFound() {
        return this.trxIdNotFound;
    }

    public void setTrxIdNotFound(JAXBElement<BusinessException> jAXBElement) {
        this.trxIdNotFound = jAXBElement;
    }
}

