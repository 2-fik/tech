/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBElement
 *  javax.xml.bind.annotation.XmlElementDecl
 *  javax.xml.bind.annotation.XmlRegistry
 */
package com.wha.appli.mpos.ws.service;

import com.wha.appli.mpos.ws.service.RecordBusinessResponse;
import com.wha.appli.mpos.ws.service.RecordTrxWhamPosResponse;
import com.wha.appli.mpos.ws.service.TTransaction;
import com.wha.appli.mpos.ws.service.exceptions.RecordTrxExceptions;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
    private static final QName _RecordTrxWhamPosResponse_QNAME = new QName("urn:service.ws.mpos.appli.wha.com", "RecordTrxWhamPosResponse");
    private static final QName _RecordTransactionInfos_QNAME = new QName("urn:service.ws.mpos.appli.wha.com", "RecordTransactionInfos");
    private static final QName _RecordTrxWhamPosResponseRecordTrxExceptions_QNAME = new QName("urn:service.ws.mpos.appli.wha.com", "RecordTrxExceptions");
    private static final QName _RecordTrxWhamPosResponseRecordTrxBusinessResponse_QNAME = new QName("urn:service.ws.mpos.appli.wha.com", "RecordTrxBusinessResponse");

    public RecordTrxWhamPosResponse createRecordTrxWhamPosResponse() {
        return new RecordTrxWhamPosResponse();
    }

    public TTransaction createTTransaction() {
        return new TTransaction();
    }

    public RecordBusinessResponse createRecordBusinessResponse() {
        return new RecordBusinessResponse();
    }

    @XmlElementDecl(namespace="urn:service.ws.mpos.appli.wha.com", name="RecordTrxWhamPosResponse")
    public JAXBElement<RecordTrxWhamPosResponse> createRecordTrxWhamPosResponse(RecordTrxWhamPosResponse recordTrxWhamPosResponse) {
        return new JAXBElement(_RecordTrxWhamPosResponse_QNAME, RecordTrxWhamPosResponse.class, null, (Object)recordTrxWhamPosResponse);
    }

    @XmlElementDecl(namespace="urn:service.ws.mpos.appli.wha.com", name="RecordTransactionInfos")
    public JAXBElement<TTransaction> createRecordTransactionInfos(TTransaction tTransaction) {
        return new JAXBElement(_RecordTransactionInfos_QNAME, TTransaction.class, null, (Object)tTransaction);
    }

    @XmlElementDecl(namespace="urn:service.ws.mpos.appli.wha.com", name="RecordTrxExceptions", scope=RecordTrxWhamPosResponse.class)
    public JAXBElement<RecordTrxExceptions> createRecordTrxWhamPosResponseRecordTrxExceptions(RecordTrxExceptions recordTrxExceptions) {
        return new JAXBElement(_RecordTrxWhamPosResponseRecordTrxExceptions_QNAME, RecordTrxExceptions.class, RecordTrxWhamPosResponse.class, (Object)recordTrxExceptions);
    }

    @XmlElementDecl(namespace="urn:service.ws.mpos.appli.wha.com", name="RecordTrxBusinessResponse", scope=RecordTrxWhamPosResponse.class)
    public JAXBElement<RecordBusinessResponse> createRecordTrxWhamPosResponseRecordTrxBusinessResponse(RecordBusinessResponse recordBusinessResponse) {
        return new JAXBElement(_RecordTrxWhamPosResponseRecordTrxBusinessResponse_QNAME, RecordBusinessResponse.class, RecordTrxWhamPosResponse.class, (Object)recordBusinessResponse);
    }
}

