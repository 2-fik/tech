/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBElement
 *  javax.xml.bind.annotation.XmlAccessType
 *  javax.xml.bind.annotation.XmlAccessorType
 *  javax.xml.bind.annotation.XmlElementRef
 *  javax.xml.bind.annotation.XmlType
 */
package com.wha.appli.mpos.ws.service;

import com.wha.appli.mpos.ws.service.RecordBusinessResponse;
import com.wha.appli.mpos.ws.service.exceptions.RecordTrxExceptions;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(value=XmlAccessType.FIELD)
@XmlType(name="RecordTrxWhamPosResponse", propOrder={"recordTrxBusinessResponse", "recordTrxExceptions"})
public class RecordTrxWhamPosResponse {
    @XmlElementRef(name="RecordTrxBusinessResponse", namespace="urn:service.ws.mpos.appli.wha.com", type=JAXBElement.class, required=false)
    protected JAXBElement<RecordBusinessResponse> recordTrxBusinessResponse;
    @XmlElementRef(name="RecordTrxExceptions", namespace="urn:service.ws.mpos.appli.wha.com", type=JAXBElement.class, required=false)
    protected JAXBElement<RecordTrxExceptions> recordTrxExceptions;

    public JAXBElement<RecordBusinessResponse> getRecordTrxBusinessResponse() {
        return this.recordTrxBusinessResponse;
    }

    public void setRecordTrxBusinessResponse(JAXBElement<RecordBusinessResponse> jAXBElement) {
        this.recordTrxBusinessResponse = jAXBElement;
    }

    public JAXBElement<RecordTrxExceptions> getRecordTrxExceptions() {
        return this.recordTrxExceptions;
    }

    public void setRecordTrxExceptions(JAXBElement<RecordTrxExceptions> jAXBElement) {
        this.recordTrxExceptions = jAXBElement;
    }
}

