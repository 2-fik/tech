/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBElement
 *  javax.xml.bind.annotation.XmlElementDecl
 *  javax.xml.bind.annotation.XmlRegistry
 */
package com.wha.appli.mpos.ws.service.exceptions;

import com.wha.appli.mpos.ws.service.exceptions.BusinessException;
import com.wha.appli.mpos.ws.service.exceptions.RecordTrxExceptions;
import com.wha.appli.mpos.ws.service.exceptions.TechnicalException;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
    private static final QName _TechnicalException_QNAME = new QName("urn:exceptions.service.ws.mpos.appli.wha.com", "TechnicalException");
    private static final QName _RecordTrxExceptionsServiceDenied_QNAME = new QName("urn:exceptions.service.ws.mpos.appli.wha.com", "ServiceDenied");
    private static final QName _RecordTrxExceptionsUnexpectedValue_QNAME = new QName("urn:exceptions.service.ws.mpos.appli.wha.com", "UnexpectedValue");
    private static final QName _RecordTrxExceptionsTrxIdNotFound_QNAME = new QName("urn:exceptions.service.ws.mpos.appli.wha.com", "TrxIdNotFound");

    public TechnicalException createTechnicalException() {
        return new TechnicalException();
    }

    public BusinessException createBusinessException() {
        return new BusinessException();
    }

    public RecordTrxExceptions createRecordTrxExceptions() {
        return new RecordTrxExceptions();
    }

    @XmlElementDecl(namespace="urn:exceptions.service.ws.mpos.appli.wha.com", name="TechnicalException")
    public JAXBElement<TechnicalException> createTechnicalException(TechnicalException technicalException) {
        return new JAXBElement(_TechnicalException_QNAME, TechnicalException.class, null, (Object)technicalException);
    }

    @XmlElementDecl(namespace="urn:exceptions.service.ws.mpos.appli.wha.com", name="ServiceDenied", scope=RecordTrxExceptions.class)
    public JAXBElement<BusinessException> createRecordTrxExceptionsServiceDenied(BusinessException businessException) {
        return new JAXBElement(_RecordTrxExceptionsServiceDenied_QNAME, BusinessException.class, RecordTrxExceptions.class, (Object)businessException);
    }

    @XmlElementDecl(namespace="urn:exceptions.service.ws.mpos.appli.wha.com", name="UnexpectedValue", scope=RecordTrxExceptions.class)
    public JAXBElement<BusinessException> createRecordTrxExceptionsUnexpectedValue(BusinessException businessException) {
        return new JAXBElement(_RecordTrxExceptionsUnexpectedValue_QNAME, BusinessException.class, RecordTrxExceptions.class, (Object)businessException);
    }

    @XmlElementDecl(namespace="urn:exceptions.service.ws.mpos.appli.wha.com", name="TrxIdNotFound", scope=RecordTrxExceptions.class)
    public JAXBElement<BusinessException> createRecordTrxExceptionsTrxIdNotFound(BusinessException businessException) {
        return new JAXBElement(_RecordTrxExceptionsTrxIdNotFound_QNAME, BusinessException.class, RecordTrxExceptions.class, (Object)businessException);
    }
}

