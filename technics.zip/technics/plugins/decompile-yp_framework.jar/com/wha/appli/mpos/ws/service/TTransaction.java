/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.annotation.XmlAccessType
 *  javax.xml.bind.annotation.XmlAccessorType
 *  javax.xml.bind.annotation.XmlElement
 *  javax.xml.bind.annotation.XmlType
 */
package com.wha.appli.mpos.ws.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(value=XmlAccessType.FIELD)
@XmlType(name="TTransaction", propOrder={"merchantTransactionIdentifier", "type", "amount", "currency", "timestamp", "status", "maskedPAN", "userName", "merchantContractIdentifier", "verificationMethod", "authorizationNumber", "authorizationRespCode", "nepSAServerResponse", "terminalSerialNumber", "scheme", "entryCondition", "applicationType", "customerTillReceipt"})
public class TTransaction {
    @XmlElement(name="MerchantTransactionIdentifier", required=true, nillable=true)
    protected String merchantTransactionIdentifier;
    @XmlElement(name="Type", required=true, nillable=true)
    protected String type;
    @XmlElement(name="Amount", required=true, nillable=true)
    protected String amount;
    @XmlElement(name="Currency", required=true, nillable=true)
    protected String currency;
    @XmlElement(name="Timestamp", required=true, nillable=true)
    protected String timestamp;
    @XmlElement(name="Status", required=true, nillable=true)
    protected String status;
    @XmlElement(name="MaskedPAN", required=true, nillable=true)
    protected String maskedPAN;
    @XmlElement(name="UserName", required=true, nillable=true)
    protected String userName;
    @XmlElement(name="MerchantContractIdentifier", required=true, nillable=true)
    protected String merchantContractIdentifier;
    @XmlElement(name="VerificationMethod", required=true, nillable=true)
    protected String verificationMethod;
    @XmlElement(name="AuthorizationNumber", required=true, nillable=true)
    protected String authorizationNumber;
    @XmlElement(name="AuthorizationRespCode", required=true, nillable=true)
    protected String authorizationRespCode;
    @XmlElement(name="NepSAServerResponse", required=true, nillable=true)
    protected String nepSAServerResponse;
    @XmlElement(name="TerminalSerialNumber", required=true, nillable=true)
    protected String terminalSerialNumber;
    @XmlElement(name="Scheme", required=true, nillable=true)
    protected String scheme;
    @XmlElement(name="EntryCondition", required=true, nillable=true)
    protected String entryCondition;
    @XmlElement(name="ApplicationType", required=true, nillable=true)
    protected String applicationType;
    @XmlElement(name="CustomerTillReceipt", required=true, nillable=true)
    protected String customerTillReceipt;

    public String getMerchantTransactionIdentifier() {
        return this.merchantTransactionIdentifier;
    }

    public void setMerchantTransactionIdentifier(String string) {
        this.merchantTransactionIdentifier = string;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String string) {
        this.type = string;
    }

    public String getAmount() {
        return this.amount;
    }

    public void setAmount(String string) {
        this.amount = string;
    }

    public String getCurrency() {
        return this.currency;
    }

    public void setCurrency(String string) {
        this.currency = string;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(String string) {
        this.timestamp = string;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String string) {
        this.status = string;
    }

    public String getMaskedPAN() {
        return this.maskedPAN;
    }

    public void setMaskedPAN(String string) {
        this.maskedPAN = string;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String string) {
        this.userName = string;
    }

    public String getMerchantContractIdentifier() {
        return this.merchantContractIdentifier;
    }

    public void setMerchantContractIdentifier(String string) {
        this.merchantContractIdentifier = string;
    }

    public String getVerificationMethod() {
        return this.verificationMethod;
    }

    public void setVerificationMethod(String string) {
        this.verificationMethod = string;
    }

    public String getAuthorizationNumber() {
        return this.authorizationNumber;
    }

    public void setAuthorizationNumber(String string) {
        this.authorizationNumber = string;
    }

    public String getAuthorizationRespCode() {
        return this.authorizationRespCode;
    }

    public void setAuthorizationRespCode(String string) {
        this.authorizationRespCode = string;
    }

    public String getNepSAServerResponse() {
        return this.nepSAServerResponse;
    }

    public void setNepSAServerResponse(String string) {
        this.nepSAServerResponse = string;
    }

    public String getTerminalSerialNumber() {
        return this.terminalSerialNumber;
    }

    public void setTerminalSerialNumber(String string) {
        this.terminalSerialNumber = string;
    }

    public String getScheme() {
        return this.scheme;
    }

    public void setScheme(String string) {
        this.scheme = string;
    }

    public String getEntryCondition() {
        return this.entryCondition;
    }

    public void setEntryCondition(String string) {
        this.entryCondition = string;
    }

    public String getApplicationType() {
        return this.applicationType;
    }

    public void setApplicationType(String string) {
        this.applicationType = string;
    }

    public String getCustomerTillReceipt() {
        return this.customerTillReceipt;
    }

    public void setCustomerTillReceipt(String string) {
        this.customerTillReceipt = string;
    }
}

