/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.annotation.XmlNsForm
 *  javax.xml.bind.annotation.XmlSchema
 */
@XmlSchema(namespace="urn:service.ws.mpos.appli.wha.com", elementFormDefault=XmlNsForm.QUALIFIED)
package com.wha.appli.mpos.ws.service;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;


