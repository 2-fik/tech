/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.utils.ConfigReader;
import org.yp.xml.jaxb.ypplugin.Plugin;

public abstract class YP_Object {
    private static final AtomicInteger uniqueProcessID = new AtomicInteger(0);
    public static final int STATUS_UNDEFINED = 0;
    public static final int STATUS_RUNNING = 1;
    public static final int STATUS_STOP_ASKED = 2;
    public static final int STATUS_STOPPING = 3;
    public static final int STATUS_STOPPED = 4;
    public static final int STATUS_CORRUPTED = 5;
    public static final int STATUS_IDLE = 6;
    private volatile int objectStatus = 0;
    private YP_Service supervisor;
    private int processID = 0;
    private YP_Object father;
    private YP_Process ancestor;
    private long threadID;
    private YP_Object basePlugin;
    private int rankInFatherChildList = -1;
    private int rankInComponentManager = -1;
    private boolean clone = false;
    private String contractIdentifier;
    private String simpleName;
    private final long startTime = System.currentTimeMillis();
    private ReentrantLock mutexYPObject;
    private List<Integer> watcherProcessIDList;
    private ReentrantLock watcherProcessIDListMutex;
    private List<Integer> notifierProcessIDList;
    private ReentrantLock notifierProcessIDListMutex;
    private String propertyFileName;
    private int logLevel = 4;
    private String preferredName;
    private AtomicInteger cptCurrent;
    private AtomicInteger cptCreation;
    private int cptMax = 0;
    private long lastCreationTime = 0L;
    private Constructor<? extends YP_Object> constructor;
    protected List<Plugin> pluginsRestriction;
    private static final Map<String, String> fileContentList = new HashMap<String, String>();
    private static final ReentrantLock fileContentListMutex = new ReentrantLock();

    public YP_Object(YP_Object yP_Object, Object ... objectArray) throws Exception {
        int n;
        String string = this.getClass().getName();
        StackTraceElement[] stackTraceElementArray = new Throwable().getStackTrace();
        boolean bl = false;
        int n2 = 0;
        block0: while (n2 < stackTraceElementArray.length) {
            if (stackTraceElementArray[n2].getClassName().contentEquals(string)) {
                n = n2 + 1;
                while (n < stackTraceElementArray.length) {
                    if (stackTraceElementArray[n].getClassName().startsWith("org.yp")) {
                        if (!stackTraceElementArray[n].getClassName().contentEquals("org.yp.framework.YP_Object") || !stackTraceElementArray[n].getMethodName().startsWith("newPlugin")) break block0;
                        bl = true;
                        break block0;
                    }
                    ++n;
                }
                break;
            }
            ++n2;
        }
        if (!bl) {
            StackTraceElement[] stackTraceElementArray2 = stackTraceElementArray;
            int n3 = stackTraceElementArray.length;
            n = 0;
            while (n < n3) {
                StackTraceElement stackTraceElement = stackTraceElementArray2[n];
                if (stackTraceElement.getClassName().contentEquals("org.yp.framework.services.YP_TS_GlobalProcessManager") && (stackTraceElement.getMethodName().contentEquals("add_YP_Object") || stackTraceElement.getMethodName().contentEquals("set_YP_Object"))) {
                    bl = true;
                    break;
                }
                ++n;
            }
            if (!(bl || this.getSimpleName().contentEquals("YP_TS_GlobalProcessManager") || this.getSimpleName().contentEquals("YP_TS_CryptoManager"))) {
                throw new Exception();
            }
        }
        this.setProcessID(YP_Object.getUniqueProcessID());
        if (yP_Object != null) {
            this.setFather(yP_Object);
            this.setSupervisor(yP_Object.getSupervisor());
            this.setContractIdentifier(yP_Object.getContractIdentifier());
            this.setLogLevel(yP_Object.getLogLevel());
            if (this instanceof YP_Process) {
                this.setAncestor((YP_Process)this);
            } else {
                this.setAncestor(yP_Object.getAncestor());
            }
        }
        this.setThreadID(Thread.currentThread().getId());
    }

    private static int getUniqueProcessID() {
        return uniqueProcessID.incrementAndGet();
    }

    public final void setObjectStatus(int n) {
        this.objectStatus = n;
    }

    public final int getObjectStatus() {
        return this.objectStatus;
    }

    public final void setSupervisor(YP_Service yP_Service) {
        this.supervisor = yP_Service;
    }

    public final YP_Service getSupervisor() {
        return this.supervisor;
    }

    private void setProcessID(int n) {
        this.processID = n;
    }

    public final int getProcessID() {
        return this.processID;
    }

    public final void setFather(YP_Object yP_Object) {
        this.father = yP_Object;
    }

    public final YP_Object getFather() {
        return this.father;
    }

    public final void setAncestor(YP_Process yP_Process) {
        this.ancestor = yP_Process;
    }

    public final YP_Process getAncestor() {
        return this.ancestor;
    }

    public final void setThreadID(long l) {
        this.threadID = l;
    }

    public final long getThreadID() {
        return this.threadID;
    }

    private void setBasePlugin(YP_Object yP_Object) {
        this.basePlugin = yP_Object;
    }

    protected YP_Object getBasePlugin() {
        return this.basePlugin;
    }

    public final void setRankInFatherChildList(int n) {
        this.rankInFatherChildList = n;
    }

    public final int getRankInFatherChildList() {
        return this.rankInFatherChildList;
    }

    public final void setRankInComponentManager(int n) {
        this.rankInComponentManager = n;
    }

    public final int getRankInComponentManager() {
        return this.rankInComponentManager;
    }

    private void setClone(boolean bl) {
        this.clone = bl;
    }

    public final boolean getClone() {
        return this.clone;
    }

    public final boolean setContractIdentifier(String string) {
        if (string == this.contractIdentifier) {
            return false;
        }
        if (string != null && this.contractIdentifier != null && string.contentEquals(this.contractIdentifier)) {
            return false;
        }
        this.contractIdentifier = string;
        return true;
    }

    public final String getContractIdentifier() {
        return this.contractIdentifier;
    }

    public final String getSimpleName() {
        if (this.simpleName == null) {
            this.simpleName = this.getClass().getSimpleName();
        }
        return this.simpleName;
    }

    public final long getStartTime() {
        return this.startTime;
    }

    private ReentrantLock getmutexYPObject() {
        if (this.mutexYPObject == null) {
            this.mutexYPObject = new ReentrantLock();
        }
        return this.mutexYPObject;
    }

    public final void lock() {
        this.getmutexYPObject().lock();
    }

    public final boolean isLockedByMe() {
        return this.getmutexYPObject().isHeldByCurrentThread();
    }

    public final void unlock() {
        this.getmutexYPObject().unlock();
    }

    public final int registerWatcher(int n) {
        try {
            if (this.watcherProcessIDListMutex == null) {
                this.watcherProcessIDListMutex = new ReentrantLock();
            }
            this.watcherProcessIDListMutex.lock();
            if (this.watcherProcessIDList == null) {
                this.watcherProcessIDList = new ArrayList<Integer>();
            }
            for (int n2 : this.watcherProcessIDList) {
                if (n2 != n) continue;
                return 0;
            }
            this.watcherProcessIDList.add(n);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "registerWatcher() " + exception);
            return -1;
        }
        finally {
            this.watcherProcessIDListMutex.unlock();
        }
    }

    public final int notifyWatcher() {
        try {
            if (this.watcherProcessIDList == null) {
                return 0;
            }
            if (this.watcherProcessIDListMutex == null) {
                return 0;
            }
            this.watcherProcessIDListMutex.lock();
            int n = 0;
            for (int n2 : this.watcherProcessIDList) {
                YP_Object yP_Object = this.getPluginByProcessID(n2);
                if (yP_Object == null) continue;
                yP_Object.addNotification(this.getProcessID());
                ++n;
            }
            int n3 = n;
            return n3;
        }
        catch (Exception exception) {
            this.logger(2, "notifyWatcher() " + exception);
            return -1;
        }
        finally {
            if (this.watcherProcessIDListMutex != null) {
                this.watcherProcessIDListMutex.unlock();
            }
        }
    }

    public final boolean haveWatcher(int n) {
        try {
            if (this.watcherProcessIDList == null) {
                return false;
            }
            if (this.watcherProcessIDListMutex == null) {
                return false;
            }
            this.watcherProcessIDListMutex.lock();
            for (int n2 : this.watcherProcessIDList) {
                if (n2 != n) continue;
                return true;
            }
            return false;
        }
        catch (Exception exception) {
            this.logger(2, "haveWatcher() " + exception);
            return false;
        }
        finally {
            if (this.watcherProcessIDListMutex != null) {
                this.watcherProcessIDListMutex.unlock();
            }
        }
    }

    private int addNotification(int n) {
        try {
            if (this.notifierProcessIDListMutex == null) {
                this.notifierProcessIDListMutex = new ReentrantLock();
            }
            this.notifierProcessIDListMutex.lock();
            if (this.notifierProcessIDList == null) {
                this.notifierProcessIDList = new ArrayList<Integer>();
            }
            this.notifierProcessIDList.add(n);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "addNotification() " + exception);
            return -1;
        }
        finally {
            this.notifierProcessIDListMutex.unlock();
        }
    }

    public final int getNotification() {
        try {
            if (this.notifierProcessIDList == null) {
                return 0;
            }
            if (this.notifierProcessIDListMutex == null) {
                return 0;
            }
            this.notifierProcessIDListMutex.lock();
            int n = this.notifierProcessIDList.size();
            if (n == 0) {
                return 0;
            }
            int n2 = this.notifierProcessIDList.get(0);
            int n3 = n - 1;
            while (n3 >= 0) {
                if (n2 == this.notifierProcessIDList.get(n3)) {
                    this.notifierProcessIDList.remove(n3);
                }
                --n3;
            }
            int n4 = n2;
            return n4;
        }
        catch (Exception exception) {
            this.logger(2, "getNotification() " + exception);
            return -1;
        }
        finally {
            if (this.notifierProcessIDListMutex != null) {
                this.notifierProcessIDListMutex.unlock();
            }
        }
    }

    public final void setPropertyFileName(String string) {
        this.propertyFileName = string;
    }

    public final String getPropertyFileName() {
        return this.propertyFileName;
    }

    public final void setLogLevel(int n) {
        this.logLevel = n;
    }

    public final int getLogLevel() {
        return this.logLevel;
    }

    public final void setPreferredName(String string) {
        this.preferredName = string;
    }

    public final String getPreferredName() {
        if (this.preferredName == null) {
            return "";
        }
        return this.preferredName;
    }

    public final int getCptCurrent() {
        if (this.cptCurrent == null) {
            return 0;
        }
        return this.cptCurrent.intValue();
    }

    private void decrementCptCurrent() {
        if (this.cptCurrent == null) {
            return;
        }
        this.cptCurrent.decrementAndGet();
    }

    public final int getCptCreation() {
        if (this.cptCreation == null) {
            return 0;
        }
        return this.cptCreation.intValue();
    }

    public final int getCptMax() {
        return this.cptMax;
    }

    public final long getLastCreationTime() {
        return this.lastCreationTime;
    }

    private Constructor<? extends YP_Object> getconstructor() {
        try {
            if (this.constructor == null) {
                this.constructor = this.getClass().getConstructor(YP_Object.class, Object[].class);
            }
            return this.constructor;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getconstructor() " + exception);
            }
            return null;
        }
    }

    public final int logger(int n, String string) {
        if (this.getLogLevel() >= n) {
            try {
                YP_Object yP_Object = this.getPluginByName("EventLogger");
                if (yP_Object != null) {
                    yP_Object.dealRequest(this, "makeLog", n, string);
                } else {
                    System.out.println(string);
                }
                return 1;
            }
            catch (Exception exception) {
                System.out.println(string);
                exception.printStackTrace();
                return -1;
            }
        }
        return 0;
    }

    public final int logger(int n, String string, Exception exception) {
        if (exception != null) {
            StringWriter stringWriter = new StringWriter();
            exception.printStackTrace(new PrintWriter(stringWriter));
            string = String.valueOf(string) + stringWriter.toString();
        }
        return this.logger(n, string);
    }

    public final int sysLog(int n, String string) {
        this.logger(2, string);
        if (this.getLogLevel() >= n) {
            try {
                YP_Object yP_Object = this.getPluginByName("EventLogger");
                if (yP_Object != null) {
                    yP_Object.dealRequest(this, "sysLog", n, string);
                } else {
                    System.out.println(string);
                }
                return 1;
            }
            catch (Exception exception) {
                System.out.println(string);
                exception.printStackTrace();
                return -1;
            }
        }
        return 0;
    }

    public final String getProperty(String string, String string2) {
        try {
            YP_Object yP_Object = this.getPluginByName("PropertiesManager");
            if (yP_Object == null) {
                return ConfigReader.get(string, string2);
            }
            return (String)yP_Object.dealRequest(this, "getProperty", string, string2);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getProperty() error :" + string + " " + string2 + " " + exception);
            }
            return null;
        }
    }

    public final int setProperty(String string, String string2, String string3) {
        YP_Object yP_Object;
        block4: {
            try {
                yP_Object = this.getPluginByName("PropertiesManager");
                if (yP_Object != null) break block4;
                return -1;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setProperty() error :" + string + " " + string2 + " " + string3 + " " + exception);
                }
                return -1;
            }
        }
        return (Integer)yP_Object.dealRequest(this, "setProperty", string, string2, string3);
    }

    public String getFileContent(String string) {
        Object object;
        try {
            object = (YP_Service)this.getPluginByName("FileContentManager");
            if (object != null) {
                return (String)((YP_Object)object).dealRequest(this, "getFileContent", string);
            }
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getFileContent() error :" + string + " " + exception);
            }
            return null;
        }
        fileContentListMutex.lock();
        try {
            try {
                object = fileContentList.get(string);
                if (object == null) {
                    FileInputStream fileInputStream = new FileInputStream(string);
                    byte[] byArray = new byte[fileInputStream.available()];
                    fileInputStream.read(byArray);
                    fileInputStream.close();
                    object = new String(byArray);
                    fileContentList.put(string, (String)object);
                }
            }
            catch (Exception exception) {
                this.logger(2, "getFileContent() " + exception);
                object = null;
                fileContentListMutex.unlock();
            }
        }
        finally {
            fileContentListMutex.unlock();
        }
        return object;
    }

    public final YP_Object getPluginByName(String string) {
        try {
            YP_Object yP_Object = null;
            if (this.ancestor != null) {
                yP_Object = this.ancestor.getCachedPluginByName(string);
            }
            if (yP_Object == null && (yP_Object = this.getSupervisor().getChildByName(string)) != null) {
                this.ancestor.addCachedPlugin(string, yP_Object);
            }
            if (yP_Object == null && !string.contentEquals("EventLogger") && this.getLogLevel() >= 2) {
                this.logger(2, "getPluginByName() plugin not found :" + string);
            }
            return yP_Object;
        }
        catch (Exception exception) {
            if (!string.contentEquals("EventLogger") && this.getLogLevel() >= 2) {
                this.logger(2, "getPluginByName() " + string + " " + exception);
            }
            return null;
        }
    }

    public final YP_Object getPluginByProcessID(int n) {
        try {
            int n2 = this.getSupervisor().getChildNB();
            int n3 = 0;
            while (n3 < n2) {
                YP_Object yP_Object = this.getSupervisor().getChildByRank(n3);
                if (yP_Object.getProcessID() == n) {
                    return yP_Object;
                }
                if (yP_Object instanceof YP_Service && (yP_Object = ((YP_Service)yP_Object).getChildByProcessID(n)) != null) {
                    return yP_Object;
                }
                ++n3;
            }
            return null;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getPluginByProcessID() " + n + " " + exception);
            }
            return null;
        }
    }

    public final YP_Process getProcessPluginByThreadID(long l) {
        YP_Service yP_Service;
        block6: {
            try {
                yP_Service = (YP_Service)this.getPluginByName("ProcessLauncher");
                if (yP_Service != null) break block6;
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getProcessPluginByThreadID() " + l + " " + exception);
                }
                return null;
            }
        }
        YP_Process yP_Process = yP_Service.getChildProcessByThreadID(l);
        if (yP_Process != null) {
            return yP_Process;
        }
        yP_Process = this.getSupervisor().getChildProcessByThreadID(l);
        if (yP_Process != null) {
            return yP_Process;
        }
        return null;
    }

    public YP_Object newPluginByName(String string, Object ... objectArray) {
        int n;
        YP_Object yP_Object;
        YP_Object yP_Object2;
        List<Plugin> list;
        block16: {
            Object[] objectArray2;
            block15: {
                list = null;
                objectArray2 = objectArray == null ? new Object[1] : objectArray;
                try {
                    if (this.pluginsRestriction != null) {
                        for (Plugin object2 : this.pluginsRestriction) {
                            if (!object2.getName().contentEquals(string)) continue;
                            string = object2.getPluginName();
                            list = object2.getPlugin();
                            break;
                        }
                    } else if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_Application && ((YP_Application)objectArray[0]).pluginsRestriction != null) {
                        for (Plugin exception : ((YP_Application)objectArray[0]).pluginsRestriction) {
                            if (!exception.getName().contentEquals(string)) continue;
                            string = exception.getPluginName();
                            list = exception.getPlugin();
                            break;
                        }
                    }
                    yP_Object2 = this.getPluginByName(string);
                    if (yP_Object2 != null) break block15;
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "newPluginByName() " + string + " " + exception);
                    }
                    return null;
                }
            }
            yP_Object = yP_Object2.getconstructor().newInstance(this, objectArray2);
            if (yP_Object != null) break block16;
            return null;
        }
        super.setBasePlugin(yP_Object2);
        yP_Object.setPropertyFileName(yP_Object2.getPropertyFileName());
        if (yP_Object2.cptCurrent == null) {
            yP_Object2.cptCurrent = new AtomicInteger(0);
        }
        if ((n = yP_Object2.cptCurrent.incrementAndGet()) > yP_Object2.cptMax) {
            yP_Object2.cptMax = n;
        }
        if (yP_Object2.cptCreation == null) {
            yP_Object2.cptCreation = new AtomicInteger(0);
        }
        yP_Object2.cptCreation.incrementAndGet();
        yP_Object2.lastCreationTime = System.currentTimeMillis();
        if (list != null) {
            yP_Object.setPluginsRestriction(list);
        }
        return yP_Object;
    }

    public final YP_Object newPlugin(YP_Object yP_Object, Object ... objectArray) {
        Object[] objectArray2 = objectArray == null ? new Object[1] : objectArray;
        try {
            int n;
            YP_Object yP_Object2 = yP_Object.getconstructor().newInstance(this, objectArray2);
            yP_Object2.setBasePlugin(yP_Object);
            yP_Object2.setPropertyFileName(yP_Object.getPropertyFileName());
            if (yP_Object.cptCurrent == null) {
                yP_Object.cptCurrent = new AtomicInteger(0);
            }
            if ((n = yP_Object.cptCurrent.incrementAndGet()) > yP_Object.cptMax) {
                yP_Object.cptMax = n;
            }
            if (yP_Object.cptCreation == null) {
                yP_Object.cptCreation = new AtomicInteger(0);
            }
            yP_Object.cptCreation.incrementAndGet();
            yP_Object.lastCreationTime = System.currentTimeMillis();
            return yP_Object2;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "newPlugin() " + yP_Object.toString() + " " + exception);
            }
            return null;
        }
    }

    public void setPluginsRestriction(List<Plugin> list) {
        this.pluginsRestriction = list;
    }

    public int shutdown() {
        int n;
        this.setObjectStatus(3);
        try {
            if (this.father instanceof YP_Service) {
                if (this.getRankInFatherChildList() != -1) {
                    ((YP_Service)this.father).removeChildByRank(this.getRankInFatherChildList());
                } else if (this.getLogLevel() >= 2) {
                    this.logger(2, "shutdown() : no rank ???");
                }
            }
            n = 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "shutdown() error :" + exception);
            }
            n = -1;
        }
        if (this.getBasePlugin() != null) {
            this.getBasePlugin().decrementCptCurrent();
        }
        return n;
    }

    public int initialize() {
        if (this.getPropertyFileName() != null) {
            String string = this.getProperty(this.getPropertyFileName(), "logLevel");
            if (string != null) {
                this.setLogLevel(Integer.parseInt(string));
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "preferredName")) != null) {
                this.setPreferredName(string);
            }
        }
        return 1;
    }

    public Object clone() {
        this.logger(1, " FRED pour voir si c'est used !!!");
        try {
            YP_Object yP_Object = (YP_Object)super.clone();
            yP_Object.setClone(true);
            yP_Object.setProcessID(YP_Object.getUniqueProcessID());
            return yP_Object;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public final String getLabel(String string) {
        try {
            String string2;
            YP_Object yP_Object = this.getPluginByName("Internationalization");
            if (yP_Object == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getLabel() unable to retrieve Internationalization plugin!!!");
                }
                return string;
            }
            YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
            if (!(yP_Process instanceof YP_Transaction)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getLabel() process sould be a transaction !!!");
                }
                return string;
            }
            String string3 = ((YP_Transaction)yP_Process).getDataContainerTransaction().userHandler.getUserPreferredLanguage();
            if (string3 == null) {
                string3 = "fr";
            }
            if ((string2 = (String)yP_Object.dealRequest(this, "getTranslatedText", string, string3)) == null) {
                return string;
            }
            return string2;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getLabel() " + exception);
            }
            return null;
        }
    }

    public final String getLabel(long l) {
        YP_Process yP_Process;
        YP_Object yP_Object;
        block11: {
            block10: {
                block9: {
                    try {
                        if (l > 0L) break block9;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "getLabel() bad parameter");
                        }
                        return null;
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "getLabel() " + exception);
                        }
                        return null;
                    }
                }
                yP_Object = this.getPluginByName("Internationalization");
                if (yP_Object != null) break block10;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getLabel() unable to retrieve Internationalization plugin!!!");
                }
                return null;
            }
            yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
            if (yP_Process instanceof YP_Transaction) break block11;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getLabel() process sould be a transaction !!!");
            }
            return null;
        }
        String string = (String)yP_Object.dealRequest(this, "getTranslatedText", l, ((YP_Transaction)yP_Process).getDataContainerTransaction().userHandler.getUserPreferredLanguage());
        return string;
    }

    public abstract String toString();

    public abstract String getVersion();

    public abstract Object dealRequest(YP_Object var1, String var2, Object ... var3) throws Exception;
}

