/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import org.yp.framework.YP_Component;
import org.yp.framework.YP_Object;

public abstract class YP_GlobalComponent
extends YP_Component {
    public YP_GlobalComponent(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }
}

