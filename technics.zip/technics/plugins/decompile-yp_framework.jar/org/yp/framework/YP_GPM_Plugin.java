/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import org.yp.framework.YP_Object;

final class YP_GPM_Plugin {
    public YP_Object yp_Object;
    public int status;

    YP_GPM_Plugin(YP_Object yP_Object, int n) {
        this.yp_Object = yP_Object;
        this.status = n;
    }
}

