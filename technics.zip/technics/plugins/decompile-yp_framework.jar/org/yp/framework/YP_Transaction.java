/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.ondemandcomponents.YP_TCD_ConnectionHandler;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;

public abstract class YP_Transaction
extends YP_Process {
    private YP_TCD_ConnectionHandler clientConnectionHandler = null;
    private YP_TCD_DC_Transaction dataContainerTransaction = null;
    protected String dataContainerTransactionName = null;

    public YP_Transaction(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray == null) {
                this.logger(2, "YP_Transaction() no parameter !!!");
                throw new Exception();
            }
            if (objectArray.length < 1 || objectArray[0] == null || !(objectArray[0] instanceof YP_TCD_ConnectionHandler)) {
                this.logger(2, "YP_Transaction() bad parameter 1 !!!");
                throw new Exception();
            }
            this.setClientConnectionHandler((YP_TCD_ConnectionHandler)objectArray[0]);
            if (objectArray.length >= 2 && objectArray[1] != null && objectArray[1] instanceof String) {
                try {
                    this.dataContainerTransactionName = (String)objectArray[1];
                    this.setDataContainerTransaction((YP_TCD_DC_Transaction)this.newPluginByName(this.dataContainerTransactionName, new Object[0]));
                    this.getDataContainerTransaction().setTransactionProcessFather(this);
                    this.getDataContainerTransaction().initialize();
                }
                catch (Exception exception) {
                    this.logger(2, "YP_Transaction() failed to get data container for:" + (String)objectArray[1] + " " + exception);
                    throw new Exception();
                }
            }
        }
    }

    @Override
    public int shutdown() {
        this.clientConnectionHandler = null;
        this.dataContainerTransaction = null;
        return super.shutdown();
    }

    private void extractAdviceData() {
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    public final List<YP_TCD_DCC_Business> getApplicationList() {
        block44: {
            block43: {
                block46: {
                    block42: {
                        block45: {
                            var2_1 = null;
                            var3_2 = null;
                            this.extractAdviceData();
                            if (this.dataContainerTransaction != null) {
                                var2_1 = this.dataContainerTransaction.contextHandler.getPositiveMerchantIdentifierList();
                                var3_2 = this.dataContainerTransaction.contextHandler.getStoreIdentifier();
                            }
                            if (var2_1 == null || var2_1.isEmpty()) break block45;
                            if (var2_1.size() > 1) {
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, "getApplicationList() a positive identifiers list has been received");
                                }
                                var1_3 = new ArrayList<E>();
                                for (HashSet<YP_TCD_DCC_Business> var4_8 : var2_1) {
                                    var6_9 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", new Object[]{this, var4_8, var3_2});
                                    if (var6_9 == null || var6_9.isEmpty()) continue;
                                    var1_3.addAll((Collection<YP_TCD_DCC_Business>)var6_9);
                                }
                            } else {
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, "getApplicationList() a positive identifier has been received");
                                }
                                var1_3 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", new Object[]{this, var2_1.get(0), var3_2});
                            }
                            ** GOTO lbl62
                        }
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "getApplicationList() no positive identifier received");
                        }
                        if (!this.getContractIdentifier().startsWith("GROUP")) ** GOTO lbl61
                        var1_3 = new ArrayList<E>();
                        var4_8 = this.getContractIdentifier().substring("GROUP".length());
                        var4_8 = UtilsYP.decryptInfo((String)var4_8);
                        if (this.dataContainerTransaction.contextHandler.groupContainers == null) ** GOTO lbl62
                        var6_9 = this.dataContainerTransaction.contextHandler.groupContainers.iterator();
                        break block42;
                        while (true) {
                            var5_5 = var6_9.next();
                            if (!var4_8.contentEquals(var5_5.getGroupName())) break;
                            if (this.dataContainerTransaction.userHandler.getUserIdentifier() > 0L) {
                                var7_10 = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                                var8_11 = var7_10.getDataContainerTechnique();
                                var9_13 = var8_11.getIdBrandListByGroup(var5_5.getIDGroup());
                                if (var9_13 == null || var9_13.isEmpty()) {
                                    this.logger(2, "getApplicationList() Nothing for group " + var5_5.getGroupName());
                                } else {
                                    for (YP_TCD_DCC_Merchant var10_14 : this.dataContainerTransaction.contextHandler.merchantContainers) {
                                        if (!var9_13.contains(var10_14.getDataContainerBrand().getIDBrand())) continue;
                                        var1_3.addAll(var10_14.dataContainerBusinessList);
                                    }
                                }
                                break;
                            }
                            this.logger(2, "getApplicationList() sur un groupe sans user ???");
                            return null;
                        }
                    }
                    if (var6_9.hasNext()) ** continue;
                    break block46;
lbl61:
                    // 1 sources

                    var1_3 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", new Object[]{this, this.getContractIdentifier(), var3_2});
                }
                if (var1_3 != null) break block43;
                this.logger(2, "getApplicationList() DC is null !!!");
                return null;
            }
            if (var1_3.isEmpty()) {
                this.logger(3, "getApplicationList() no DC Found !!!");
                return var1_3;
            }
            if (this.dataContainerTransaction == null) ** GOTO lbl134
            var4_8 = this.dataContainerTransaction.contextHandler.getPositiveApplicationIdentifierList();
            var5_5 = this.dataContainerTransaction.contextHandler.getNegativeApplicationIdentifierList();
            if ((var4_8 == null || var4_8.isEmpty()) && (var5_5 == null || var5_5.isEmpty())) ** GOTO lbl134
            var6_9 = this.dataContainerTransaction.getContractIdentifier().split("_");
            if (((String[])var6_9).length >= 2) break block44;
            this.logger(2, " getApplicationList() bad contract identifier :" + this.getContractIdentifier());
            return null;
        }
        try {
            var7_10 = String.valueOf(var6_9[0]) + "_" + var6_9[1];
            var8_12 = var1_3.size() - 1;
            while (var8_12 >= 0) {
                var9_13 = ((YP_TCD_DCC_Business)var1_3.get(var8_12)).getContractIdentifier();
                var10_15 = false;
                if (var4_8 == null || var4_8.isEmpty()) ** GOTO lbl109
                for (Object var11_16 : var4_8) {
                    var11_16 = String.valueOf(var7_10) + "_" + (String)var11_16;
                    if (!var11_16.startsWith((String)var9_13)) continue;
                    if (var11_16.split("_").length == 4 && !var11_16.contentEquals((CharSequence)var9_13)) {
                        this.logger(4, "getApplicationList() Not found anymore :" + (String)var9_13 + " vs " + (String)var11_16);
                        continue;
                    }
                    var10_15 = true;
                    break;
                }
                if (!var10_15) {
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "getApplicationList() not found in positive application list :" + (String)var9_13);
                    }
                    var1_3.remove(var8_12);
                } else {
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "getApplicationList() found in positive application list :" + (String)var9_13);
                    }
lbl109:
                    // 4 sources

                    var10_15 = false;
                    if (var5_5 != null && !var5_5.isEmpty()) {
                        var12_17 = var5_5.iterator();
                        while (var12_17.hasNext()) {
                            var11_16 = (String)var12_17.next();
                            var11_16 = String.valueOf(var7_10) + "_" + (String)var11_16;
                            if (!var11_16.startsWith((String)var9_13)) continue;
                            if (var11_16.split("_").length == 4 && !var11_16.contentEquals((CharSequence)var9_13)) {
                                this.logger(4, "getApplicationList() Not found anymore :" + (String)var9_13 + " vs " + (String)var11_16);
                                continue;
                            }
                            var10_15 = true;
                            break;
                        }
                        if (var10_15) {
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "getApplicationList() found in negative application list :" + (String)var9_13);
                            }
                            var1_3.remove(var8_12);
                        } else if (this.getLogLevel() >= 5) {
                            this.logger(5, "getApplicationList() not found in negative application list :" + (String)var9_13);
                        }
                    }
                }
                --var8_12;
            }
lbl134:
            // 3 sources

            if (this.dataContainerTransaction != null) {
                if (this.dataContainerTransaction.userHandler.getUserIdentifier() > 0L) {
                    if (var1_3.size() > this.dataContainerTransaction.contextHandler.businessContainers.size() || var1_3.size() < 1000 || this.dataContainerTransaction.contextHandler.businessContainers.size() < 1000) {
                        var4_8 = new HashSet<YP_TCD_DCC_Business>();
                        var4_8.addAll(this.dataContainerTransaction.contextHandler.businessContainers);
                        var5_6 = var1_3.size() - 1;
                        while (var5_6 >= 0) {
                            var6_9 = (YP_TCD_DCC_Business)var1_3.get(var5_6);
                            if (!var4_8.contains(var6_9)) {
                                var1_3.remove(var5_6);
                            }
                            --var5_6;
                        }
                    }
                    if (var1_3.isEmpty()) {
                        this.logger(3, "getApplicationList() No data container left after rights check");
                    }
                }
                if ((var4_8 = this.dataContainerTransaction.contextHandler.getContractLabel()) != null && !var4_8.isEmpty()) {
                    var5_7 = var1_3.size() - 1;
                    while (var5_7 >= 0) {
                        var6_9 = ((YP_TCD_DCC_Business)var1_3.get(var5_7)).getContractRow().getFieldStringValueByName("contractLabel");
                        if (!var6_9.contentEquals((CharSequence)var4_8)) {
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "getApplicationList() ignored " + (String)var6_9);
                            }
                            var1_3.remove(var5_7);
                        }
                        --var5_7;
                    }
                }
            }
            return var1_3;
        }
        catch (Exception var1_4) {
            this.logger(2, "getApplicationList() failed to get data container for merchant:" + this.getContractIdentifier() + " " + var1_4);
            return null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final List<YP_TCD_DCC_Merchant> getMerchantList() {
        try {
            block23: {
                block22: {
                    block21: {
                        var1_1 = new ArrayList<YP_TCD_DCC_Merchant>();
                        var2_3 = null;
                        if (this.dataContainerTransaction != null) {
                            var2_3 = this.dataContainerTransaction.contextHandler.getPositiveMerchantIdentifierList();
                        }
                        if (var2_3 == null || var2_3.isEmpty()) break block21;
                        if (var2_3.size() > 1) {
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "getMerchantList() a positive identifiers list has been received");
                            }
                        } else if (this.getLogLevel() >= 5) {
                            this.logger(5, "getMerchantList() a positive identifier has been received");
                        }
                        var4_4 = var2_3.iterator();
                        if (true) ** GOTO lbl88
                    }
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "getMerchantList() no positive identifier received");
                    }
                    if (!this.getContractIdentifier().contentEquals("KERNEL")) break block22;
                    if (this.dataContainerTransaction.userHandler.getUserIdentifier() <= 0L) {
                        this.logger(2, "getMerchantList() sur le KERNEL sans user ???");
                        return null;
                    }
                    var1_1.addAll(this.dataContainerTransaction.contextHandler.merchantContainers);
                    ** GOTO lbl63
                }
                if (this.getContractIdentifier().indexOf(95) == -1) break block23;
                var3_6 = (YP_TCD_DCC_Merchant)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerMerchant", new Object[]{this.getContractIdentifier()});
                if (var3_6 != null) {
                    var1_1.add(var3_6);
                }
                ** GOTO lbl63
            }
            if (!this.getContractIdentifier().startsWith("GROUP")) ** GOTO lbl59
            var3_7 = this.getContractIdentifier().substring("GROUP".length());
            var3_8 = UtilsYP.decryptInfo(var3_7);
            if (this.dataContainerTransaction.contextHandler.groupContainers == null) ** GOTO lbl59
            var5_13 = this.dataContainerTransaction.contextHandler.groupContainers.iterator();
lbl42:
            // 2 sources

            while (true) {
                block24: {
                    if (!var5_13.hasNext()) break block24;
                    var4_4 = (YP_TCD_DCC_Group)var5_13.next();
                    if (!var3_8.contentEquals(var4_4.getGroupName())) continue;
                    if (this.dataContainerTransaction.userHandler.getUserIdentifier() <= 0L) {
                        this.logger(2, "getMerchantList() sur un groupe sans user ???");
                        return null;
                    }
                    var6_15 = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                    var7_18 = var6_15.getDataContainerTechnique();
                    var8_19 = var7_18.getIdBrandListByGroup(var4_4.getIDGroup());
                    if (var8_19 == null || var8_19.isEmpty()) {
                        this.logger(2, "getMerchantList() Nothing for group " + var4_4.getGroupName());
                        continue;
                    }
                    var10_21 = this.dataContainerTransaction.contextHandler.merchantContainers.iterator();
                    if (true) ** GOTO lbl94
                }
                if (var1_1.isEmpty() && (var3_9 = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", new Object[]{this.getContractIdentifier()})) != null) {
                    var1_1.addAll(var3_9.dataContainerMerchantList);
                }
lbl63:
                // 6 sources

                while (true) {
                    if (var1_1.isEmpty()) {
                        this.logger(3, "getMerchantList() no DC Found !!!");
                        return var1_1;
                    }
                    if (this.dataContainerTransaction == null || this.dataContainerTransaction.userHandler.getUserIdentifier() <= 0L || var1_1.size() <= this.dataContainerTransaction.contextHandler.merchantContainers.size() && var1_1.size() >= 1000 && this.dataContainerTransaction.contextHandler.merchantContainers.size() >= 1000) ** GOTO lbl76
                    var3_11 = var1_1.size() - 1;
lbl70:
                    // 2 sources

                    while (true) {
                        block25: {
                            if (var3_12 < 0) break block25;
                            var4_4 = (YP_TCD_DCC_Merchant)var1_1.get((int)var3_12);
                            var5_14 = false;
                            var7_18 = this.dataContainerTransaction.contextHandler.merchantContainers.iterator();
                            if (true) ** GOTO lbl100
                        }
                        return var1_1;
                    }
                    break;
                }
                break;
            }
        }
        catch (Exception var1_2) {
            this.logger(2, "getMerchantList() failed to get data container for merchant:" + this.getContractIdentifier(), var1_2);
            return null;
        }
        do {
            var3_5 = var4_4.next();
            var5_13 = (YP_TCD_DCC_Merchant)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerMerchant", new Object[]{var3_5});
            if (var5_13 == null) continue;
            var1_1.add((YP_TCD_DCC_Merchant)var5_13);
lbl88:
            // 3 sources

        } while (var4_4.hasNext());
        ** while (true)
        do {
            if (!var8_19.contains((var9_20 = var10_21.next()).getDataContainerBrand().getIDBrand())) continue;
            var1_1.add(var9_20);
lbl94:
            // 3 sources

        } while (var10_21.hasNext());
        ** while (true)
        do {
            if ((var6_17 = var7_18.next()) != var4_4) continue;
            var5_14 = true;
            break;
lbl100:
            // 2 sources

        } while (var7_18.hasNext());
        if (!var5_14) {
            var1_1.remove((int)var3_12);
        }
        --var3_12;
        ** while (true)
    }

    public List<YP_TCD_DCC_Group> getGroupList() {
        try {
            ArrayList<YP_TCD_DCC_Group> arrayList = new ArrayList<YP_TCD_DCC_Group>();
            if (this.dataContainerTransaction.contextHandler.groupContainers != null) {
                if (this.getContractIdentifier().contentEquals("KERNEL")) {
                    arrayList.addAll(this.dataContainerTransaction.contextHandler.groupContainers);
                } else {
                    List<Long> list;
                    YP_TS_DataContainerManager yP_TS_DataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)yP_TS_DataContainerManager.dealRequest(this, "getDataContainerBrand", this.getContractIdentifier());
                    if (yP_TCD_DCC_Brand != null && (list = yP_TS_DataContainerManager.getDataContainerTechnique().getGroupIDs(yP_TCD_DCC_Brand.getIDBrand())) != null) {
                        block2: for (long l : list) {
                            for (YP_TCD_DCC_Group yP_TCD_DCC_Group : this.dataContainerTransaction.contextHandler.groupContainers) {
                                if (yP_TCD_DCC_Group.getIDGroup() != l) continue;
                                if (arrayList.contains(yP_TCD_DCC_Group)) continue block2;
                                arrayList.add(yP_TCD_DCC_Group);
                                continue block2;
                            }
                        }
                    }
                }
            }
            if (arrayList.isEmpty() && this.getLogLevel() >= 5) {
                this.logger(5, "getGroupList() no DC Found !!!");
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getGroupList() failed to get data container for :" + this.getContractIdentifier(), exception);
            return null;
        }
    }

    @Deprecated
    public List<YP_TCD_DCC_Brand> getBrandList() {
        return this.getBrandList(false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public List<YP_TCD_DCC_Brand> getBrandList(boolean bl) {
        try {
            ArrayList<YP_TCD_DCC_Brand> arrayList = new ArrayList<YP_TCD_DCC_Brand>();
            if (this.getContractIdentifier().contentEquals("KERNEL")) {
                if (this.dataContainerTransaction.userHandler.getUserIdentifier() <= 0L) {
                    this.logger(2, "getBrandList() sur le KERNEL sans user ???");
                    return null;
                }
                arrayList.addAll(this.dataContainerTransaction.contextHandler.brandContainers);
            } else {
                Object object;
                if (this.getContractIdentifier().startsWith("GROUP")) {
                    object = this.getContractIdentifier().substring("GROUP".length());
                    object = UtilsYP.decryptInfo((String)object);
                    if (this.dataContainerTransaction.contextHandler.groupContainers != null) {
                        for (YP_TCD_DC_Context yP_TCD_DC_Context : this.dataContainerTransaction.contextHandler.groupContainers) {
                            if (!((String)object).contentEquals(((YP_TCD_DCC_Group)yP_TCD_DC_Context).getGroupName())) continue;
                            if (this.dataContainerTransaction.userHandler.getUserIdentifier() <= 0L) {
                                this.logger(2, "getBrandList() sur un groupe sans user ???");
                                return null;
                            }
                            YP_TS_DataContainerManager yP_TS_DataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                            YP_TCD_DCC_Technique yP_TCD_DCC_Technique = yP_TS_DataContainerManager.getDataContainerTechnique();
                            List<Long> list = yP_TCD_DCC_Technique.getIdBrandListByGroup(((YP_TCD_DCC_Group)yP_TCD_DC_Context).getIDGroup());
                            if (list == null || list.isEmpty()) {
                                this.logger(2, "getBrandList() Nothing for group " + ((YP_TCD_DCC_Group)yP_TCD_DC_Context).getGroupName());
                                continue;
                            }
                            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : this.dataContainerTransaction.contextHandler.brandContainers) {
                                if (!list.contains(yP_TCD_DCC_Brand.getIDBrand())) continue;
                                arrayList.add(yP_TCD_DCC_Brand);
                            }
                        }
                    }
                }
                if (arrayList.isEmpty()) {
                    object = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", this.getContractIdentifier());
                    arrayList.add((YP_TCD_DCC_Brand)object);
                }
            }
            if (bl && this.dataContainerTransaction != null && this.dataContainerTransaction.userHandler.getUserIdentifier() > 0L) {
                int n = arrayList.size() - 1;
                while (n >= 0) {
                    YP_TCD_DC_Context yP_TCD_DC_Context;
                    yP_TCD_DC_Context = (YP_TCD_DCC_Brand)arrayList.get(n);
                    boolean bl2 = false;
                    for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : this.dataContainerTransaction.contextHandler.brandContainers) {
                        if (yP_TCD_DCC_Brand != yP_TCD_DC_Context) continue;
                        bl2 = true;
                        break;
                    }
                    if (!bl2) {
                        arrayList.remove(n);
                    }
                    --n;
                }
            }
            if (arrayList.isEmpty()) {
                this.logger(3, "getBrandList() no DC Found !!!");
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getBrandList() failed to get data container for merchant:" + this.getContractIdentifier(), exception);
            return null;
        }
    }

    public final void setClientConnectionHandler(YP_TCD_ConnectionHandler yP_TCD_ConnectionHandler) {
        this.clientConnectionHandler = yP_TCD_ConnectionHandler;
    }

    public final YP_TCD_ConnectionHandler getClientConnectionHandler() {
        return this.clientConnectionHandler;
    }

    public final void setDataContainerTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public final YP_TCD_DC_Transaction getDataContainerTransaction() {
        return this.dataContainerTransaction;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }
}

