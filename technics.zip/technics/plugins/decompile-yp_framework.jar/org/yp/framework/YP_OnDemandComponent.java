/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import org.yp.framework.YP_Component;
import org.yp.framework.YP_Object;

public abstract class YP_OnDemandComponent
extends YP_Component {
    public YP_OnDemandComponent(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        try {
            this.getPluginByName("ComponentManager").dealRequest(this, "registerComponent", new Object[0]);
        }
        catch (Exception exception) {
            this.logger(2, "YP_OnDemandComponent() Failed to register :" + exception);
        }
    }

    @Override
    public int shutdown() {
        block3: {
            super.shutdown();
            try {
                if (!this.getClone()) break block3;
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "shutdown() error :" + exception);
                return -1;
            }
        }
        return (Integer)this.getPluginByName("ComponentManager").dealRequest(this, "unregisterComponent", new Object[0]);
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }
}

