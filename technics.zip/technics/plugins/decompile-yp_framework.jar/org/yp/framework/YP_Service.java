/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_GPM_Plugin;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Transaction;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.framework.services.YP_TS_ProcessLauncher;

public abstract class YP_Service
extends YP_Process {
    public static final int CHILD_STATUS_CORRUPTED = -2;
    public static final int CHILD_STATUS_ERROR = -1;
    public static final int CHILD_STATUS_INACTIVE = 0;
    public static final int CHILD_STATUS_ACTIVE = 1;
    private boolean initDone = false;
    private int maxChild = 200;
    private boolean maxChildUnlimited = false;
    private final List<YP_GPM_Plugin> childList = new ArrayList<YP_GPM_Plugin>();
    private final Map<Integer, YP_GPM_Plugin> childMap = new HashMap<Integer, YP_GPM_Plugin>();
    private Map<String, YP_GPM_Plugin> hashedChildListForSupervisor = null;
    private Map<Long, YP_Process> processList = null;
    private final ReentrantLock childListMutex = new ReentrantLock();
    private int peakChildByDay = 0;
    private Date peakChildDate = null;
    private int curseur = 0;

    public YP_Service(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (this instanceof YP_TS_GlobalProcessManager) {
            this.hashedChildListForSupervisor = new HashMap<String, YP_GPM_Plugin>();
            this.processList = new HashMap<Long, YP_Process>();
        } else if (this instanceof YP_TS_ProcessLauncher) {
            this.processList = new HashMap<Long, YP_Process>();
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "maxChilds");
        if (string != null) {
            this.setMaxChild(Integer.parseInt(string));
        }
        this.initDone = true;
        return 1;
    }

    public final int getChildNB() {
        if (this.childList == null) {
            return -1;
        }
        return this.childList.size();
    }

    public final int getChildPeakByDay(Date date, int n) {
        try {
            if (this.peakChildDate == null || date.getDay() != date.getDay() || date.getMonth() != date.getMonth() || date.getYear() != date.getYear()) {
                this.peakChildByDay = n;
                this.peakChildDate = date;
            }
            if (n > this.peakChildByDay) {
                this.peakChildByDay = n;
            }
            return this.peakChildByDay;
        }
        catch (Exception exception) {
            this.logger(2, "getChildPeakByDay() ", exception);
            return -1;
        }
    }

    protected final int addChild(YP_Object yP_Object) {
        return this.addChild(yP_Object, 1);
    }

    protected final int addChild(YP_Object yP_Object, int n) {
        int n2;
        YP_GPM_Plugin yP_GPM_Plugin;
        block13: {
            yP_GPM_Plugin = null;
            try {
                YP_Process yP_Process;
                yP_GPM_Plugin = new YP_GPM_Plugin(yP_Object, n);
                int n3 = this.getChildNB();
                this.childListMutex.lock();
                if (this.hashedChildListForSupervisor != null) {
                    this.hashedChildListForSupervisor.put(yP_Object.toString(), yP_GPM_Plugin);
                }
                if (yP_Object instanceof YP_Process && this.processList != null && (this.hashedChildListForSupervisor == null || !(yP_Object instanceof YP_Transaction)) && (yP_Process = this.processList.put(yP_Object.getThreadID(), (YP_Process)yP_Object)) != null) {
                    this.logger(2, "addChild() previousProcess found : " + yP_Process + " while adding : " + yP_Object.toString());
                }
                n2 = this.curseur;
                while (n2 < n3) {
                    if (this.childList.get(n2) == null) {
                        this.curseur = n2 + 1;
                        this.childList.set(n2, yP_GPM_Plugin);
                        this.childMap.put(yP_GPM_Plugin.yp_Object.getProcessID(), yP_GPM_Plugin);
                        this.childListMutex.unlock();
                        if (yP_Object.getFather() == this) {
                            yP_Object.setRankInFatherChildList(n2);
                        }
                        this.notifyWatcher();
                        return n2;
                    }
                    ++n2;
                }
                if (!this.initDone || n3 < this.getMaxChild()) break block13;
                if (this.isMaxChildUnlimited()) {
                    this.setMaxChild(this.getMaxChild() + 1);
                    break block13;
                }
                this.childListMutex.unlock();
                if (yP_Object.getFather() == this) {
                    this.logger(2, "addChild() No more space available...");
                    yP_GPM_Plugin.yp_Object.shutdown();
                }
                return -1;
            }
            catch (Exception exception) {
                if (yP_GPM_Plugin != null) {
                    this.childListMutex.unlock();
                    if (yP_Object.getFather() == this) {
                        yP_GPM_Plugin.yp_Object.shutdown();
                    }
                }
                this.logger(2, "addChild() ", exception);
                return -1;
            }
        }
        this.childList.add(yP_GPM_Plugin);
        this.childMap.put(yP_GPM_Plugin.yp_Object.getProcessID(), yP_GPM_Plugin);
        this.childListMutex.unlock();
        this.curseur = n2 = this.getChildNB() - 1;
        if (yP_Object.getFather() == this) {
            yP_Object.setRankInFatherChildList(n2);
        }
        this.notifyWatcher();
        return n2;
    }

    public final YP_Object getChildByName(String string) {
        YP_GPM_Plugin yP_GPM_Plugin;
        YP_GPM_Plugin yP_GPM_Plugin2;
        if (string == null || string.isEmpty()) {
            this.logger(2, "getChildByName() no name given");
            return null;
        }
        if (this.hashedChildListForSupervisor != null && (yP_GPM_Plugin2 = this.hashedChildListForSupervisor.get(string)) != null && yP_GPM_Plugin2.yp_Object != null && yP_GPM_Plugin2.yp_Object.toString().contentEquals(string)) {
            return yP_GPM_Plugin2.yp_Object;
        }
        int n = this.getChildNB();
        int n2 = 0;
        while (n2 < n) {
            yP_GPM_Plugin = this.childList.get(n2);
            if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && yP_GPM_Plugin.yp_Object.toString().contentEquals(string)) {
                if (this.hashedChildListForSupervisor != null) {
                    this.hashedChildListForSupervisor.put(string, yP_GPM_Plugin);
                }
                return yP_GPM_Plugin.yp_Object;
            }
            ++n2;
        }
        n2 = 0;
        while (n2 < n) {
            yP_GPM_Plugin = this.childList.get(n2);
            if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && string.contentEquals(yP_GPM_Plugin.yp_Object.getPreferredName())) {
                return yP_GPM_Plugin.yp_Object;
            }
            ++n2;
        }
        return null;
    }

    public final YP_Object getChildByPreferredName(String string) {
        int n = this.getChildNB();
        int n2 = 0;
        while (n2 < n) {
            YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n2);
            if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && yP_GPM_Plugin.yp_Object.getPreferredName().contentEquals(string)) {
                return yP_GPM_Plugin.yp_Object;
            }
            ++n2;
        }
        return null;
    }

    public final int getChildStatusByPreferredName(String string) {
        int n = this.getChildNB();
        int n2 = 0;
        while (n2 < n) {
            YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n2);
            if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && yP_GPM_Plugin.yp_Object.getPreferredName().contentEquals(string)) {
                return yP_GPM_Plugin.status;
            }
            ++n2;
        }
        return -1;
    }

    public final int setChildStatusByPreferredName(String string, int n) {
        int n2 = this.getChildNB();
        int n3 = 0;
        while (n3 < n2) {
            YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n3);
            if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && yP_GPM_Plugin.yp_Object.getPreferredName().contentEquals(string)) {
                yP_GPM_Plugin.status = n;
                return 1;
            }
            ++n3;
        }
        return -1;
    }

    public final YP_Object getChildByRank(int n) {
        YP_GPM_Plugin yP_GPM_Plugin;
        block3: {
            try {
                yP_GPM_Plugin = this.childList.get(n);
                if (yP_GPM_Plugin != null) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getChildByRank() ", exception);
                return null;
            }
        }
        return yP_GPM_Plugin.yp_Object;
    }

    public final int getChildStatusByRank(int n) {
        YP_GPM_Plugin yP_GPM_Plugin;
        block3: {
            try {
                yP_GPM_Plugin = this.childList.get(n);
                if (yP_GPM_Plugin != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getChildStatusByRank() ", exception);
                return -1;
            }
        }
        return yP_GPM_Plugin.status;
    }

    public final int setChildStatusByRank(int n, int n2) {
        block3: {
            try {
                YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n);
                if (yP_GPM_Plugin != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "setChildStatusByRank() ", exception);
                return -1;
            }
        }
        yP_GPM_Plugin.status = n2;
        return 1;
    }

    public final YP_Process getChildProcessByThreadID(long l) {
        try {
            if (this.processList != null) {
                return this.processList.get(l);
            }
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n2);
                if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object != null && yP_GPM_Plugin.yp_Object instanceof YP_Process && ((YP_Process)yP_GPM_Plugin.yp_Object).getThreadID() == l) {
                    return (YP_Process)yP_GPM_Plugin.yp_Object;
                }
                ++n2;
            }
        }
        catch (Exception exception) {
            this.logger(2, "getChildProcessByThreadID() ", exception);
        }
        return null;
    }

    public final YP_Object getChildByProcessID(int n) {
        block7: {
            try {
                YP_GPM_Plugin yP_GPM_Plugin = this.childMap.get(n);
                if (yP_GPM_Plugin != null) {
                    return yP_GPM_Plugin.yp_Object;
                }
            }
            catch (Exception exception) {
                this.logger(2, "getChildByProcessID() ", exception);
            }
            try {
                int n2 = this.getChildNB();
                int n3 = 0;
                while (n3 < n2) {
                    YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n3);
                    if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object.getProcessID() == n) {
                        return yP_GPM_Plugin.yp_Object;
                    }
                    ++n3;
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block7;
                this.logger(2, "getChildByProcessID() ", exception);
            }
        }
        return null;
    }

    protected final int removeChildByRank(int n) {
        YP_GPM_Plugin yP_GPM_Plugin;
        YP_GPM_Plugin yP_GPM_Plugin2;
        block6: {
            try {
                yP_GPM_Plugin2 = this.childList.get(n);
                if (yP_GPM_Plugin2 != null) break block6;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "removeChildByRank() ", exception);
                return -1;
            }
        }
        if (this.processList != null && yP_GPM_Plugin2.yp_Object instanceof YP_Process) {
            this.processList.remove(yP_GPM_Plugin2.yp_Object.getThreadID());
        }
        if (this.hashedChildListForSupervisor != null && (yP_GPM_Plugin = this.hashedChildListForSupervisor.get(yP_GPM_Plugin2.yp_Object.toString())) == yP_GPM_Plugin2) {
            this.hashedChildListForSupervisor.remove(yP_GPM_Plugin2.yp_Object.toString());
        }
        this.childList.set(n, null);
        this.childMap.remove(yP_GPM_Plugin2.yp_Object.getProcessID());
        if (this.curseur > n) {
            this.curseur = n;
        }
        this.notifyWatcher();
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final int removeChildByID(int n) {
        try {
            int n2 = this.getChildNB();
            int n3 = n2 - 1;
            while (true) {
                if (n3 < 0) {
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "removeChildByID() process already freed ? :" + n);
                    }
                    return 0;
                }
                YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n3);
                if (yP_GPM_Plugin != null && yP_GPM_Plugin.yp_Object.getProcessID() == n) {
                    YP_GPM_Plugin yP_GPM_Plugin2;
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "removeChildByID() process removed :" + n);
                    }
                    if (this.processList != null && yP_GPM_Plugin.yp_Object instanceof YP_Process) {
                        this.processList.remove(yP_GPM_Plugin.yp_Object.getThreadID());
                    }
                    if (this.hashedChildListForSupervisor != null && (yP_GPM_Plugin2 = this.hashedChildListForSupervisor.get(yP_GPM_Plugin.yp_Object.toString())) == yP_GPM_Plugin) {
                        this.hashedChildListForSupervisor.remove(yP_GPM_Plugin.yp_Object.toString());
                    }
                    this.childList.set(n3, null);
                    this.childMap.remove(n);
                    if (this.curseur > n3) {
                        this.curseur = n3;
                    }
                    this.notifyWatcher();
                    return 1;
                }
                --n3;
            }
        }
        catch (Exception exception) {
            this.logger(2, "removeChildByID() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int shutdownChildListByID(int n) {
        try {
            YP_GPM_Plugin yP_GPM_Plugin;
            YP_GPM_Plugin yP_GPM_Plugin2;
            int n2 = this.getChildNB();
            int n3 = 0;
            while (n3 < n2) {
                yP_GPM_Plugin2 = this.childList.get(n3);
                if (yP_GPM_Plugin2 != null && yP_GPM_Plugin2.yp_Object.getFather().getProcessID() == n) {
                    this.shutdownChildListByID(yP_GPM_Plugin2.yp_Object.getProcessID());
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "shutdownChildListByID() process removed :" + n);
                    }
                    if (this.processList != null && yP_GPM_Plugin2.yp_Object instanceof YP_Process) {
                        this.processList.remove(yP_GPM_Plugin2.yp_Object.getThreadID());
                    }
                    if (this.hashedChildListForSupervisor != null && (yP_GPM_Plugin = this.hashedChildListForSupervisor.get(yP_GPM_Plugin2.yp_Object.toString())) == yP_GPM_Plugin2) {
                        this.hashedChildListForSupervisor.remove(yP_GPM_Plugin2.yp_Object.toString());
                    }
                    this.childList.set(n3, null);
                    this.childMap.remove(yP_GPM_Plugin2.yp_Object.getProcessID());
                    this.notifyWatcher();
                    if (this.curseur > n3) {
                        this.curseur = n3;
                    }
                }
                ++n3;
            }
            n3 = n2 - 1;
            while (n3 >= 0) {
                yP_GPM_Plugin2 = this.childList.get(n3);
                if (yP_GPM_Plugin2 != null && yP_GPM_Plugin2.yp_Object.getProcessID() == n && yP_GPM_Plugin2.yp_Object.getObjectStatus() != 3) {
                    yP_GPM_Plugin2.yp_Object.shutdown();
                    if (this.processList != null && yP_GPM_Plugin2.yp_Object instanceof YP_Process) {
                        this.processList.remove(yP_GPM_Plugin2.yp_Object.getThreadID());
                    }
                    if (this.hashedChildListForSupervisor != null && (yP_GPM_Plugin = this.hashedChildListForSupervisor.get(yP_GPM_Plugin2.yp_Object.toString())) == yP_GPM_Plugin2) {
                        this.hashedChildListForSupervisor.remove(yP_GPM_Plugin2.yp_Object.toString());
                    }
                    this.childList.set(n3, null);
                    this.childMap.remove(n);
                    this.notifyWatcher();
                    if (this.curseur <= n3) return 1;
                    this.curseur = n3;
                    return 1;
                }
                --n3;
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "shutdownChildListByID() ", exception);
        }
        return 0;
    }

    @Override
    public int shutdown() {
        try {
            super.shutdown();
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_GPM_Plugin yP_GPM_Plugin = this.childList.get(n2);
                if (yP_GPM_Plugin != null) {
                    yP_GPM_Plugin.yp_Object.shutdown();
                    this.childList.set(n2, null);
                }
                ++n2;
            }
            this.childMap.clear();
            if (this.hashedChildListForSupervisor != null) {
                this.hashedChildListForSupervisor.clear();
                this.hashedChildListForSupervisor = null;
            }
            if (this.processList != null) {
                this.processList.clear();
                this.processList = null;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "shutdown() ", exception);
            return -1;
        }
    }

    public final void stopThread() {
        this.setObjectStatus(2);
    }

    public final void setMaxChild(int n) {
        this.maxChild = n;
    }

    public final int getMaxChild() {
        return this.maxChild;
    }

    public int getRunningChildNB() {
        try {
            int n = 0;
            int n2 = this.getChildNB();
            int n3 = 0;
            while (n3 < n2) {
                if (this.getChildByRank(n3) != null) {
                    ++n;
                } else if (this.curseur > n3) {
                    this.curseur = n3;
                }
                ++n3;
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "getRunningChildNB() ", exception);
            return -1;
        }
    }

    public boolean isMaxChildUnlimited() {
        return this.maxChildUnlimited;
    }

    public void setMaxChildUnlimited(boolean bl) {
        this.maxChildUnlimited = bl;
    }
}

