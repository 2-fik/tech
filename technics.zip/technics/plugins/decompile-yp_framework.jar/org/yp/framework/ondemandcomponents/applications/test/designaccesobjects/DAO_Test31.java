/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.Partition;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test31
extends YP_Row {
    @PrimaryKey
    public long idTest31 = 0L;
    @Index
    @Partition(name="archiveOrderedByMSTimePS", tableType=8)
    public long test31Long = 0L;
}

