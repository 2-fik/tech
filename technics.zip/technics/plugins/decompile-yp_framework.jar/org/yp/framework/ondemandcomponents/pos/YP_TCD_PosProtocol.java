/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos;

import java.util.Calendar;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public abstract class YP_TCD_PosProtocol
extends YP_OnDemandComponent {
    private int errorStatus = 0;
    private YP_GlobalComponent parser = null;
    private String parserName = null;

    public YP_TCD_PosProtocol(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.getParserName() != null) {
            try {
                this.setParser((YP_GlobalComponent)this.getPluginByName(this.getParserName()));
            }
            catch (Exception exception) {
                this.logger(2, "initialize() :" + exception);
                return -1;
            }
        }
        return 1;
    }

    public YP_GlobalComponent getParser() {
        return this.parser;
    }

    public void setParser(YP_GlobalComponent yP_GlobalComponent) {
        this.parser = yP_GlobalComponent;
    }

    public String getParserName() {
        return this.parserName;
    }

    public void setParserName(String string) {
        this.parserName = string;
    }

    public int getErrorStatus() {
        return this.errorStatus;
    }

    public void setErrorStatus(int n) {
        this.errorStatus = n;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    public abstract int loadInitialRequest(String var1);

    public abstract String getInitialRequest();

    public abstract String getResponse();

    public abstract String getRequest(Object var1);

    public abstract int readRequest(YP_TCD_DC_Transaction var1);

    public abstract int prepareResponse(YP_TCD_DC_Transaction var1);

    public abstract String createScheduledRequest(YP_Object var1, String var2);

    public abstract REQUEST_TYPE getRequestType();

    public abstract boolean getTestMode();

    public abstract SUB_REQUEST_TYPE getSubRequestType();

    public abstract int getDifferedFlag();

    public abstract int setDifferedFlag(int var1);

    public abstract Calendar getUploadTimeStamp();

    public abstract int setUploadTimeStamp(Calendar var1);

    public abstract int getShiftNumber();

    public abstract int setShiftNumber(int var1);

    public abstract int getSessionNumber();

    public abstract int setSessionNumber(int var1);

    public abstract long getTransactionAmount();

    public abstract int setTransactionAmount(long var1);

    public abstract String getTransactionCurrencyAlpha();

    public abstract int setTransactionCurrencyAlpha(String var1);

    public abstract int getTransactionCurrencyNumerical();

    public abstract int setTransactionCurrencyNumerical(int var1);

    public abstract int setTransactionAmountAlpha(String var1);

    public abstract int getTransactionCurrencyFraction();

    public abstract int setTransactionCurrencyFraction(int var1);

    public abstract String getTransactionAmountAlpha();

    public abstract String getTransactionNumber();

    public abstract int setTransactionNumber(String var1);

    public abstract Calendar getTransactionAppliLocalTime();

    public abstract int setTransactionAppliLocalTime(Calendar var1);

    public abstract String getMerchantTransactionIdentifier();

    public abstract int setMerchantTransactionIdentifier(String var1);

    public abstract Calendar getMerchantTransactionTime();

    public abstract int setMerchantTransactionTime(Calendar var1);

    public abstract String getReferenceTransactionNumber();

    public abstract int setReferenceTransactionNumber(String var1);

    public abstract Calendar getReferenceTransactionAppliLocalTime();

    public abstract int setReferenceTransactionAppliLocalTime(Calendar var1);

    public abstract String getReferenceMerchantTransactionIdentifier();

    public abstract int setReferenceMerchantTransactionIdentifier(String var1);

    public abstract Calendar getReferenceMerchantTransactionTime();

    public abstract int setReferenceMerchantTransactionTime(Calendar var1);

    public abstract int setTicket(String var1);

    public abstract String get(String var1);

    public abstract int setXMLResponse(String var1);

    public abstract String getAppTags();

    public abstract void setAppTags(String var1);

    public abstract String getEMVTags();

    public abstract void setEMVTags(String var1);

    public abstract String getPrintFormat();

    public abstract String getSecurityTrailer();

    public abstract void setSecurityTrailer(String var1);

    public static enum REQUEST_TYPE {
        Reprint,
        ReprintCustomer,
        ReprintMerchant,
        ReprintLastTrs,
        Reconciliation,
        RemoteParameterization,
        Report,
        System,
        Loyalty,
        Login,
        Logout,
        GetData,
        SetData,
        CreateData,
        Authorization,
        Transparent,
        Shutdown,
        GlobalSummaryReport,
        EnregistrementPari,
        TerminalAuthentication,
        AnnulationPari,
        ReceptionSignal,
        PaiementPari,
        TraitementTicket,
        GetLastOffre;

    }

    public static enum RESULT_TYPE {
        Success,
        Refused,
        Error,
        Intermediate,
        Unknown;

    }

    public static enum SUB_REQUEST_TYPE {
        None,
        RemoteParameterizationReport,
        ReconciliationReport,
        FunctionnalParameterReport,
        ReferenceParameterReport,
        TerminalSummaryReport,
        SummaryReport,
        HardwareReport,
        IncidentsReport,
        Diary,
        Reload,
        GetCustomerData,
        AddCustomerData,
        DeleteCustomerData,
        Debit,
        Credit,
        Annulation,
        NonAboutie,
        OpenTransaction,
        TerminalRiskManagement,
        OpenTransactionAndTRM,
        Authorization,
        Completion,
        ForcedShutdown,
        CloseCXAndShutdownWhenIdle,
        ShutdownWhenIdle,
        Change,
        Reset,
        ProcessNFC,
        ApduCommands,
        AdditionalReport,
        AuthorizationAndCompletion,
        GetBrandList;

    }
}

