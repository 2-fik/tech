/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test4
extends YP_Row {
    @PrimaryKey
    public long idTest4 = 0L;
    public long test4Long = 0L;
    public int test4Int = 0;
    public float test4Float = 0.0f;
    public byte[] test4CharArray = new byte[50];
    public Timestamp test4Timestamp = new Timestamp(0L);
    public Date test4Date = new Date(0L);
}

