/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.vfs2.FileContent
 *  org.apache.commons.vfs2.FileObject
 *  org.apache.commons.vfs2.FileSystemException
 *  org.apache.commons.vfs2.FileSystemOptions
 *  org.apache.commons.vfs2.impl.StandardFileSystemManager
 *  org.apache.commons.vfs2.provider.sftp.IdentityInfo
 *  org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.File;
import java.io.OutputStream;
import java.net.Socket;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.IdentityInfo;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_SFTP_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private String ipServer = null;
    private int portServer = 0;
    private int connectionTimeoutMS = 3499;
    private StandardFileSystemManager fsmanager = null;
    private FileObject remoteFile = null;
    private String USER_ID;
    private String PASSWORD;
    private String PRIVATE_KEY_FILE_PATH;
    private String PRIVATE_KEY_FILE_PASSPHRASE;
    private String KNOWN_HOSTS_FILE_PATH;
    private String REMOTE_LOCATION;

    public YP_TCD_PHYS_SFTP_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int close() {
        try {
            if (this.remoteFile != null) {
                this.remoteFile.close();
                this.remoteFile = null;
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "close() remoteFile closed...");
            }
        }
        catch (Exception exception) {
            this.logger(2, "close() SFTP remoteFile close error : ", exception);
        }
        try {
            if (this.fsmanager != null) {
                this.fsmanager.close();
                this.fsmanager = null;
            }
        }
        catch (Exception exception) {
            this.logger(2, "close() SFTP manager close error : ", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "SFTPConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int openServer() {
        this.logger(2, "openServer() not done");
        return -1;
    }

    @Override
    public Object waitConnection() {
        this.logger(2, "waitConnection() not done");
        return null;
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        return 0;
    }

    @Override
    public int clean(int n) {
        return 1;
    }

    @Override
    public int available() {
        return 1;
    }

    @Override
    public int send(byte[] byArray, int n) {
        if (this.remoteFile == null) {
            this.logger(2, "send() failed, connection is not OK");
            return -2;
        }
        try (FileContent fileContent = this.remoteFile.getContent();){
            OutputStream outputStream = fileContent.getOutputStream();
            outputStream.write(byArray);
        }
        catch (Exception exception) {
            this.logger(2, "send failed: ", exception);
            return -1;
        }
    }

    @Override
    public int closeHandle(Object object) {
        return 1;
    }

    @Override
    public String getIP() {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int openClient(Object ... objectArray) {
        try {
            boolean bl;
            block17: {
                block15: {
                    block16: {
                        block14: {
                            if (objectArray == null) {
                                this.logger(2, "openClient() missing parameters");
                                return -1;
                            }
                            if (objectArray.length != 1 || !(objectArray[0] instanceof YP_Row)) break block14;
                            this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                            this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                            this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                            this.USER_ID = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "userID");
                            this.PASSWORD = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "password");
                            this.PRIVATE_KEY_FILE_PATH = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "privateKeyFilePath");
                            this.PRIVATE_KEY_FILE_PASSPHRASE = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "privateKeyFilePassphrase");
                            this.KNOWN_HOSTS_FILE_PATH = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "knownHostsFilePath");
                            this.REMOTE_LOCATION = this.getExtensionValueAsStringSafe((YP_Row)objectArray[0], "remoteLocation");
                            if (this.ipServer == null) break block15;
                            break block16;
                        }
                        this.logger(2, "openClient() incorrect parameters");
                        return -1;
                    }
                    if (!this.ipServer.isEmpty()) break block17;
                }
                this.logger(2, "openClient() missing parameter ipServer");
                return -1;
            }
            if (this.USER_ID == null || this.USER_ID.isEmpty()) {
                this.logger(2, "openClient() missing parameter user");
                return -1;
            }
            boolean bl2 = this.PASSWORD == null || this.PASSWORD.isEmpty();
            boolean bl3 = bl = this.PRIVATE_KEY_FILE_PATH == null || this.PRIVATE_KEY_FILE_PATH.isEmpty();
            if (bl2 && bl) {
                this.logger(4, "openClient() parameter password or privateKeyFilePath is required");
                return -1;
            }
            if (this.REMOTE_LOCATION == null || this.REMOTE_LOCATION.isEmpty()) {
                this.logger(2, "openClient() missing parameter remoteLocation");
                return -1;
            }
            String string = this.portServer > 0 ? String.valueOf(this.ipServer) + ":" + String.valueOf(this.portServer) : this.ipServer;
            File file2 = null;
            if (this.PRIVATE_KEY_FILE_PATH != null && !this.PRIVATE_KEY_FILE_PATH.isEmpty() && !(file2 = new File(this.PRIVATE_KEY_FILE_PATH)).exists()) {
                file2 = null;
                this.logger(3, "openClient() private key file not found: " + this.PRIVATE_KEY_FILE_PATH);
            }
            File file = null;
            if (this.KNOWN_HOSTS_FILE_PATH != null && !this.KNOWN_HOSTS_FILE_PATH.isEmpty() && !(file = new File(this.KNOWN_HOSTS_FILE_PATH)).exists()) {
                file = null;
                this.logger(2, "openClient() known hosts file not found: " + this.KNOWN_HOSTS_FILE_PATH);
                return -1;
            }
            String string2 = this.createConnectionString(string, this.USER_ID, this.PASSWORD, file2, this.PRIVATE_KEY_FILE_PASSPHRASE, this.REMOTE_LOCATION);
            this.printConnectionInfo(this.createConnectionString(string, this.USER_ID, "********", file2, this.PRIVATE_KEY_FILE_PASSPHRASE, this.REMOTE_LOCATION));
            this.fsmanager = new StandardFileSystemManager();
            try {
                this.fsmanager.init();
                FileSystemOptions fileSystemOptions = this.createFileSystemOptions(file2, this.PRIVATE_KEY_FILE_PASSPHRASE, file, this.connectionTimeoutMS);
                this.remoteFile = this.fsmanager.resolveFile(string2, fileSystemOptions);
                if (this.remoteFile == null) {
                    this.logger(2, "openClient() connexion failed");
                    return -1;
                }
                this.logger(4, "openClient() login successful: " + this.USER_ID);
                return this.initialize();
            }
            catch (Exception exception) {
                this.logger(2, "openClient() failed : ", exception);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + " ", exception);
            return -1;
        }
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for SFTP !!!");
        return null;
    }

    private void printConnectionInfo(String string) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printConnectionInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append(string);
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }

    private String createConnectionString(String string, String string2, String string3, File file, String string4, String string5) {
        if (string3 == null || string3.isEmpty()) {
            return "sftp://" + string2 + "@" + string + string5;
        }
        return "sftp://" + string2 + ":" + string3 + "@" + string + string5;
    }

    private FileSystemOptions createFileSystemOptions(File file, String string, File file2, Integer n) throws FileSystemException {
        FileSystemOptions fileSystemOptions = new FileSystemOptions();
        if (file2 != null) {
            SftpFileSystemConfigBuilder.getInstance().setKnownHosts(fileSystemOptions, file2);
            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(fileSystemOptions, "yes");
        } else {
            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(fileSystemOptions, "no");
        }
        SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(fileSystemOptions, true);
        SftpFileSystemConfigBuilder.getInstance().setTimeout(fileSystemOptions, n);
        if (file != null) {
            IdentityInfo identityInfo = null;
            identityInfo = string != null && !string.isEmpty() ? new IdentityInfo(file, string.getBytes()) : new IdentityInfo(file);
            SftpFileSystemConfigBuilder.getInstance().setIdentityInfo(fileSystemOptions, new IdentityInfo[]{identityInfo});
        }
        return fileSystemOptions;
    }

    private String getExtensionValueAsStringSafe(YP_Row yP_Row, String string) {
        try {
            return yP_Row.getExtensionValueAsString(string);
        }
        catch (Exception exception) {
            this.logger(4, "getExtensionValueAsStringSafe() field not found: " + string);
            return "";
        }
    }
}

