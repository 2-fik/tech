/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_Hosts_Parameters
extends YP_Row {
    @PrimaryKey
    public long idHostsParameters = 0L;
    public byte[] name = new byte[4];
    public int maxTries = 0;
    public int delayInterCallInSec = 0;
    public byte[] frequencyInYYMMWWDDHHMMSS = new byte[14];
    public byte[] frequencyExtendedInYYMMWWDDHHMMSS = new byte[14];
    public byte[] timeToCallCenterHHMMSS = new byte[6];
    public byte[] dateToCallCenterAAAAMMJJ = new byte[8];
    public int aleaInSec = 0;
    public byte[] externalReference = new byte[30];
}

