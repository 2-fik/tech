/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test16
extends YP_Row {
    @PrimaryKey
    public long idTest16 = 0L;
    public byte[] test16Array = new byte[10];
    public long test16Long = 0L;
    public int test16Int = 0;
}

