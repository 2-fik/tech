/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.time.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_Time
extends YP_Row {
    @PrimaryKey
    public long idTime = 0L;
    public byte[] timeZone = new byte[50];
    public Timestamp lowerGMTPeriod = new Timestamp(0L);
    public Timestamp upperGMTPeriod = new Timestamp(0L);
    public long timeOffsetInMS = 0L;
    public byte[] externalReference = new byte[30];
}

