/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_3DSecure;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.xml.jaxb.threeds.VEReq;
import org.yp.xml.jaxb.threeds.VERes;

public class YP_TCD_PROT_ThreeDSecureInterface
extends YP_OnDemandComponent
implements YP_PROT_Interface_Prot {
    public YP_TCD_DCC_Business dataContainerBusiness = null;
    public YP_TCD_DC_Transaction dataContainerTransaction = null;
    private String directoryName = "VISA";

    public YP_TCD_PROT_ThreeDSecureInterface(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_TCD_DCC_Business) {
            this.dataContainerBusiness = (YP_TCD_DCC_Business)objectArray[0];
        }
        if (objectArray != null && objectArray.length > 1 && objectArray[1] instanceof YP_TCD_DC_Transaction) {
            this.dataContainerTransaction = (YP_TCD_DC_Transaction)objectArray[1];
        }
        if (objectArray != null && objectArray.length > 2 && objectArray[2] instanceof String) {
            this.directoryName = (String)objectArray[2];
        }
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "ThreeDSecure_Interface";
    }

    @Override
    public YP_PROT_Interface_Prot.ConnectionParameters getConnectionParameters(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, int n, boolean bl) {
        String string;
        String string2;
        YP_PROT_Interface_Prot.ConnectionParameters connectionParameters;
        block3: {
            connectionParameters = new YP_PROT_Interface_Prot.ConnectionParameters();
            try {
                String string3 = this.getProperty("business/properties/" + this.getContractIdentifier() + "/directory_parameter.properties", this.directoryName);
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "getConnectionParameters: directoryParameter: " + string3);
                }
                String[] stringArray = string3.split(":");
                string2 = stringArray[0];
                string = stringArray.length == 1 ? "443" : stringArray[1];
            }
            catch (Exception exception) {
                string2 = "127.0.0.1";
                string = "443";
                if (this.getLogLevel() < 2) break block3;
                this.logger(2, "getConnectionParameters put default parameters due to: " + exception);
            }
        }
        connectionParameters.ip = string2;
        connectionParameters.port = string;
        connectionParameters.ert = "24";
        return connectionParameters;
    }

    @Override
    public int transactionDatasToObjectFactory(YP_Object yP_Object, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        YP_TCD_PROT_ThreeDSecure yP_TCD_PROT_ThreeDSecure = (YP_TCD_PROT_ThreeDSecure)yP_Object;
        if (sERVICEDEMANDE == YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto && yP_TCD_PROT_ThreeDSecure.getMessageType(yP_TCD_PROT_ThreeDSecure.YP_GetSendFactoryObject()) == YP_TCD_PROT_ThreeDSecure.MessageType.VEReq) {
            String string;
            VEReq vEReq;
            block12: {
                YP_PROT_Interface_3DSecure yP_PROT_Interface_3DSecure;
                block11: {
                    vEReq = (VEReq)yP_TCD_PROT_ThreeDSecure.getMessage(yP_TCD_PROT_ThreeDSecure.YP_GetSendFactoryObject());
                    String string2 = "ve." + System.currentTimeMillis() + "." + YP_TCD_DCC_Business.getTransactionNumber(this.dataContainerTransaction);
                    yP_TCD_PROT_ThreeDSecure.YP_GetSendFactoryObject().getMessage().get(0).setId(string2);
                    vEReq.setPan(this.dataContainerTransaction.accountHandler.getAccountIdentifier());
                    yP_PROT_Interface_3DSecure = (YP_PROT_Interface_3DSecure)((Object)this.dataContainerTransaction.getProtocolEFT());
                    if (yP_PROT_Interface_3DSecure == null) {
                        return -1;
                    }
                    try {
                        string = yP_PROT_Interface_3DSecure.getAcceptHeader();
                        if (string != null && !string.isEmpty()) {
                            if (this.getLogLevel() >= 6) {
                                this.logger(6, "YP_TCD_PROT_ThreeDSecureInterface::transactionDatasToObjectFactory() acceptHeader: " + string);
                            }
                            vEReq.getBrowser().setAccept(string);
                        }
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 2) break block11;
                        this.logger(2, "YP_TCD_PROT_ThreeDSecureInterface::transactionDatasToObjectFactory() acceptHeader failed");
                    }
                }
                try {
                    string = yP_PROT_Interface_3DSecure.getUserAgentHeader();
                    if (string != null && !string.isEmpty()) {
                        if (this.getLogLevel() >= 6) {
                            this.logger(6, "YP_TCD_PROT_ThreeDSecureInterface::transactionDatasToObjectFactory() userAgentHeader: " + string);
                        }
                        vEReq.getBrowser().setUserAgent(string);
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) break block12;
                    this.logger(2, "YP_TCD_PROT_ThreeDSecureInterface::transactionDatasToObjectFactory() userAgentHeader failed");
                }
            }
            if ((string = this.dataContainerBusiness.getAcquiringInstitutionIdentificationCode()).length() > 6) {
                string = string.substring(6);
            }
            vEReq.getMerchant().setAcqBIN(string);
            vEReq.getMerchant().setMerID(this.dataContainerBusiness.getMerchantContract());
            vEReq.getBrowser().setDeviceCategory("0");
        }
        return 0;
    }

    @Override
    public int objectFactoryToTransactionsData(YP_Object yP_Object, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        YP_TCD_PROT_ThreeDSecure yP_TCD_PROT_ThreeDSecure = (YP_TCD_PROT_ThreeDSecure)yP_Object;
        if (sERVICEDEMANDE == YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto && yP_TCD_PROT_ThreeDSecure.getMessageType(yP_TCD_PROT_ThreeDSecure.YP_GetReceiveFactoryObject()) == YP_TCD_PROT_ThreeDSecure.MessageType.VERes) {
            VERes vERes = (VERes)yP_TCD_PROT_ThreeDSecure.getMessage(yP_TCD_PROT_ThreeDSecure.YP_GetReceiveFactoryObject());
            if (vERes.getCH().getEnrolled().contentEquals("Y")) {
                return 3;
            }
            if (vERes.getCH().getEnrolled().contentEquals("U")) {
                return 2;
            }
            if (vERes.getCH().getEnrolled().contentEquals("N")) {
                return 1;
            }
        }
        return 0;
    }

    @Override
    public byte[] extraAPDUFormat(YP_Object yP_Object, Object object, byte[] byArray) {
        return byArray;
    }

    @Override
    public boolean extraAPDUCheck(YP_Object yP_Object, Object object, byte[] byArray) {
        return true;
    }

    @Override
    public boolean setOneField(Object object, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, int n) {
        return false;
    }

    @Override
    public boolean dealOneField(Object object, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, int n) {
        return false;
    }

    @Override
    public int setParameters(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerBusiness = yP_TCD_DCC_Business;
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
        return 1;
    }
}

