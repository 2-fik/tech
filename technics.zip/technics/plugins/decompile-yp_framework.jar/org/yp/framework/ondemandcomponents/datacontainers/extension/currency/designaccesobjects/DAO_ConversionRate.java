/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.currency.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ConversionRate
extends YP_Row {
    @PrimaryKey
    public long idConversionRate = 0L;
    public byte[] baseCurrencyAlphabeticalCode = new byte[3];
    public byte[] targetCurrencyAlphabeticalCode = new byte[3];
    public float conversionRate = 0.0f;
    public int dynamicRate = 0;
    public int statusConversionRate = 0;
    public Timestamp lastUpdateGMTTime = new Timestamp(0L);
    public Timestamp effectiveDate = new Timestamp(0L);
    public Timestamp expirationdate = new Timestamp(0L);
    public byte[] externalReference = new byte[30];
}

