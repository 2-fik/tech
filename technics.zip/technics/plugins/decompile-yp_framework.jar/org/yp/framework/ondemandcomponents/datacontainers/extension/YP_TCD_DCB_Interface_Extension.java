/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;

public interface YP_TCD_DCB_Interface_Extension {
    public int initialize();

    public String get(String var1);

    public int onChange(YP_TCD_DesignAccesObject var1);

    public int onSaveBefore(YP_TCD_DesignAccesObject var1, List<YP_Row> var2, YP_Row var3);

    public int onSaveAfter(YP_TCD_DesignAccesObject var1, List<YP_Row> var2, YP_Row var3);

    public int shutdown();
}

