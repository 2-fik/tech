/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.rawtlv;

import org.yp.framework.ondemandcomponents.protocols.rawtlv.YP_RawTLVUtils;

public class YP_RawTLVException
extends Exception {
    private static final long serialVersionUID = 8464506352712429732L;
    private String fieldId;
    private String tlvId;
    private ErrorType myError;
    private String myTimerName;

    private String getPrintableFormat(YP_RawTLVUtils.DataFormat dataFormat) {
        String string = "";
        switch (dataFormat) {
            case NUMERIC: {
                string = "Numeric";
                break;
            }
            case ALPHA: {
                string = "Alpha";
                break;
            }
            case ALPHANUM: {
                string = "AlphaNum";
            }
        }
        return string;
    }

    public YP_RawTLVException(ErrorType errorType, String string, String string2, String string3) {
        this.myError = errorType;
        if (string != null && !string.isEmpty()) {
            this.fieldId = string;
        }
        if (string2 != null && !string2.isEmpty()) {
            this.tlvId = string2;
        }
        this.myTimerName = string3 == null ? TimerName.noTimeOut.toString() : string3;
    }

    public void setFieldId(String string) {
        this.fieldId = string;
    }

    public String getTlvId() {
        return this.tlvId;
    }

    public String getFieldId() {
        return this.fieldId;
    }

    public void setTlvId(String string) {
        this.tlvId = string;
    }

    public String getTimerName() {
        return this.myTimerName;
    }

    public void setTimerName(String string) {
        this.myTimerName = string;
    }

    public ErrorType getErrorType() {
        return this.myError;
    }

    public void YP_ResetData() {
        this.myError = ErrorType.noError;
        this.myTimerName = TimerName.noTimeOut.toString();
        this.fieldId = null;
        this.tlvId = null;
    }

    public static enum ErrorType {
        noError,
        fieldMissing,
        syntaxError,
        timeOut,
        formatNotSupported,
        wrongEqualityField,
        internalError;

    }

    public static enum TimerName {
        noTimeOut,
        TNR,
        TSI,
        TGR,
        TMA,
        TSM;

    }
}

