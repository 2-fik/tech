/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.events;

import java.sql.Timestamp;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_Events
extends YP_TCD_DCB_Interface_Extension {
    public static final int EVENT_OK = 1;
    public static final int EVENT_UNKNOWN = 0;
    public static final int EVENT_KO = -1;
    public static final int EVENT_CX_ERROR = -3;

    public int getLastEventStatus(String var1);

    public Timestamp getFirstEventAppliLocalTime(String var1);

    public Timestamp getLastEventAppliLocalTime(String var1);

    public Timestamp getLastEventSystemGMTTime(String var1);

    public int setEventStatus(String var1, int var2);

    public int resetAllEvents();

    public int resetEvents(String var1);
}

