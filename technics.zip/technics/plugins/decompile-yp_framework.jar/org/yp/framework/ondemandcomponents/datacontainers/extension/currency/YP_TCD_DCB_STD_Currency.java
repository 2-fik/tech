/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.currency;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.YP_TCD_DCB_Interface_Currency;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.designaccesobjects.DAO_ConversionRate;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.designaccesobjects.DAO_STD_Currency;
import org.yp.utils.ByteBuilder;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCB_STD_Currency
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Currency {
    private YP_TCD_DCC_Business dataContainer;
    public YP_TCD_DesignAccesObject currency;
    public YP_TCD_DesignAccesObject conversionRate;
    private long cksCurrency = -1L;

    public YP_TCD_DCB_STD_Currency(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.currency = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_STD_Currency.class, 0, 0, null);
            this.conversionRate = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_ConversionRate.class, 0, 0, null);
        }
        catch (Exception exception) {
            this.logger(2, "YP_TCD_DCB_STD_Currency", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionSTD_Currency";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.conversionRate) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() conversionRate");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.currency) {
            this.cksCurrency = -1L;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() currency");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.conversionRate) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() conversionRate");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.currency) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() currency");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if ((this.conversionRate == null || clazz != this.conversionRate.getRowClass()) && this.currency != null && clazz == this.currency.getRowClass()) {
            this.cksCurrency = -1L;
        }
        return 0;
    }

    private float getOneConversionRate(String string, String string2) {
        block4: {
            YP_Row yP_Row;
            block5: {
                int n;
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.conversionRate);
                yP_ComplexGabarit.set("baseCurrencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("targetCurrencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                List<YP_Row> list = this.conversionRate.getRowListSuchAs(yP_ComplexGabarit);
                if (list == null || list.isEmpty()) break block4;
                if (list.size() > 1) {
                    this.logger(3, "getOneConversionRate() too many rows for " + string + " " + string2);
                }
                if ((n = ((Integer)(yP_Row = list.get(0)).getFieldValueByName("statusConversionRate")).intValue()) != 0) break block5;
                this.logger(3, "getOneConversionRate() not active" + string + " " + string2);
                return 0.0f;
            }
            try {
                return ((Float)yP_Row.getFieldValueByName("conversionRate")).floatValue();
            }
            catch (Exception exception) {
                this.logger(2, "getOneConversionRate()", exception);
            }
        }
        return 0.0f;
    }

    private float getConversionRate(String string, String string2) {
        try {
            float f;
            float f2 = this.getOneConversionRate(string, string2);
            if (f2 > 0.0f) {
                return f2;
            }
            f2 = this.getOneConversionRate(string2, string);
            if (f2 > 0.0f) {
                return 1.0f / f2;
            }
            if (!string.contentEquals("EUR") && string2.contentEquals("EUR") && (f2 = this.getOneConversionRate("EUR", string)) > 0.0f && (f = this.getOneConversionRate("EUR", string2)) > 0.0f) {
                return f / f2;
            }
            this.logger(2, "getConversionRate() not found " + string + " " + string2);
            return -1.0f;
        }
        catch (Exception exception) {
            this.logger(2, "getConversionRate() ", exception);
            return 0.0f;
        }
    }

    @Override
    public long convertAmount(long l, int n, int n2) {
        String string = this.getCurrencyAlphabeticalCode(n);
        String string2 = this.getCurrencyAlphabeticalCode(n2);
        if (string == null || string2 == null) {
            return -1L;
        }
        return this.convertAmount(l, string, string2);
    }

    @Override
    public long convertAmount(long l, String string, String string2) {
        float f;
        block3: {
            try {
                f = this.getConversionRate(string, string2);
                if (!(f <= 0.0f)) break block3;
                this.logger(2, "convertAmount() conversionRate not found ");
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "convertAmount() ", exception);
                return -1L;
            }
        }
        BigDecimal bigDecimal = new BigDecimal(f);
        int n = this.getCurrencyFraction(string);
        int n2 = this.getCurrencyFraction(string2);
        BigDecimal bigDecimal2 = new BigDecimal(l);
        bigDecimal2 = bigDecimal2.movePointLeft(n);
        BigDecimal bigDecimal3 = bigDecimal2.multiply(bigDecimal);
        bigDecimal3 = bigDecimal3.setScale(n2, RoundingMode.HALF_UP);
        bigDecimal3 = bigDecimal3.movePointRight(n2);
        return bigDecimal3.longValue();
    }

    private YP_Row getCurrencyRow(String string) {
        List<YP_Row> list;
        block4: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                yP_ComplexGabarit.set("currencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                list = this.currency.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                yP_ComplexGabarit.set("currencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.currency.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(2, "getCurrencyRow() unable to found currency " + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyRow() ", exception);
                return null;
            }
        }
        if (list.size() > 1) {
            this.logger(3, "getCurrencyRow() too many rows for " + string);
        }
        return list.get(0);
    }

    private YP_Row getCurrencyRow(int n) {
        List<YP_Row> list;
        block4: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                yP_ComplexGabarit.set("currencyNumericalCode", YP_ComplexGabarit.OPERATOR.EQUAL, n);
                yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                list = this.currency.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                yP_ComplexGabarit.set("currencyNumericalCode", YP_ComplexGabarit.OPERATOR.EQUAL, n);
                list = this.currency.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(2, "getCurrencyRow() unable to found currency " + n);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyRow() ", exception);
                return null;
            }
        }
        if (list.size() > 1) {
            this.logger(3, "getCurrencyRow() too many rows for " + n);
        }
        return list.get(0);
    }

    @Override
    public String getCurrencyAlphabeticalCode(int n) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(n);
                if (yP_Row != null) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyAlphabeticalCode() ", exception);
                return null;
            }
        }
        return yP_Row.getFieldStringValueByName("currencyAlphabeticalCode");
    }

    @Override
    public int getCurrencyNumericalCode(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(string);
                if (yP_Row != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyNumericalCode() ", exception);
                return -1;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("currencyNumericalCode");
    }

    @Override
    public int getCurrencyFraction(int n) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(n);
                if (yP_Row != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyFraction() ", exception);
                return -1;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("currencyFraction");
    }

    @Override
    public int getCurrencyFraction(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(string);
                if (yP_Row != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyFraction() ", exception);
                return -1;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("currencyFraction");
    }

    @Override
    public int getCounterValuePrintingActivationCode(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(string);
                if (yP_Row != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getCounterValuePrintingActivationCode() ", exception);
                return -1;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("counterValuePrintingActivationCode");
    }

    @Override
    public List<String> getCurrencyAlphabeticalCodeList() {
        try {
            return this.currency.getDistinctStringValueList("currencyAlphabeticalCode");
        }
        catch (Exception exception) {
            this.logger(2, "getCurrencyAlphabeticalCodeList() ", exception);
            return null;
        }
    }

    @Override
    public List<String> getCurrencyAlphabeticalCodeList(boolean bl, boolean bl2) {
        YP_ComplexGabarit yP_ComplexGabarit;
        block6: {
            try {
                yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                if (bl && !bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                    break block6;
                }
                if (!bl && bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                    break block6;
                }
                if (bl && bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.IN, 0, 1);
                    break block6;
                }
                this.logger(2, "getCurrencyAlphabeticalCodeList() bad parameters");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyAlphabeticalCodeList() ", exception);
                return null;
            }
        }
        return this.currency.getDistinctStringValueListSuchAs("currencyAlphabeticalCode", yP_ComplexGabarit);
    }

    @Override
    public List<Integer> getCurrencyNumericalCodeList() {
        try {
            return this.currency.getDistinctValueList("currencyNumericalCode");
        }
        catch (Exception exception) {
            this.logger(2, "getCurrencyNumericalCodeList() ", exception);
            return null;
        }
    }

    @Override
    public List<Integer> getCurrencyNumericalCodeList(boolean bl, boolean bl2) {
        YP_ComplexGabarit yP_ComplexGabarit;
        block6: {
            try {
                yP_ComplexGabarit = new YP_ComplexGabarit(this.currency);
                if (bl && !bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                    break block6;
                }
                if (!bl && bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                    break block6;
                }
                if (bl && bl2) {
                    yP_ComplexGabarit.set("currencyActivationCode", YP_ComplexGabarit.OPERATOR.IN, 0, 1);
                    break block6;
                }
                this.logger(2, "getCurrencyNumericalCodeList() bad parameters");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyNumericalCodeList() ", exception);
                return null;
            }
        }
        return this.currency.getDistinctValueListSuchAs("currencyNumericalCode", yP_ComplexGabarit);
    }

    @Override
    public List<String> getConversionCurrencyAlphaList(String string) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.conversionRate);
            yP_ComplexGabarit.set("baseCurrencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            return this.conversionRate.getDistinctStringValueListSuchAs("targetCurrencyAlphabeticalCode", yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "getConversionCurrencyList() ", exception);
            return null;
        }
    }

    @Override
    public boolean isCurrencyActivated(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(string);
                if (yP_Row != null) break block3;
                return false;
            }
            catch (Exception exception) {
                this.logger(2, "isCurrencyActivated() ", exception);
                return false;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("currencyActivationCode") == 1;
    }

    @Override
    public String formatAmount(long l, String string) {
        int n = this.getCurrencyFraction(string);
        if (n < 0) {
            this.logger(2, "formatAmount() unable to find" + string);
            return null;
        }
        return UtilsYP.formatAmount(l, n, Locale.FRANCE);
    }

    @Override
    public String formatAmount(long l, int n) {
        int n2 = this.getCurrencyFraction(n);
        if (n2 < 0) {
            this.logger(2, "formatAmount() unable to find" + n);
            return null;
        }
        return UtilsYP.formatAmount(l, n2, Locale.FRANCE);
    }

    @Override
    public long getCurrencyMinAmount(int n) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(n);
                if (yP_Row != null) break block3;
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyMinAmount() ", exception);
                return -1L;
            }
        }
        return (Long)yP_Row.getFieldValueByName("currencyMinAmount");
    }

    @Override
    public long getCurrencyMinAmount(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getCurrencyRow(string);
                if (yP_Row != null) break block3;
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "getCurrencyMinAmount() ", exception);
                return -1L;
            }
        }
        return (Long)yP_Row.getFieldValueByName("currencyMinAmount");
    }

    @Override
    public long getCurrencyMaxAmount(int n) {
        long l;
        block5: {
            YP_Row yP_Row;
            block4: {
                try {
                    yP_Row = this.getCurrencyRow(n);
                    if (yP_Row != null) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    this.logger(2, "getCurrencyMaxAmount() ", exception);
                    return -1L;
                }
            }
            l = (Long)yP_Row.getFieldValueByName("currencyMaxAmount");
            if (l != 0L) break block5;
            return Long.MAX_VALUE;
        }
        return l;
    }

    @Override
    public long getCurrencyMaxAmount(String string) {
        long l;
        block5: {
            YP_Row yP_Row;
            block4: {
                try {
                    yP_Row = this.getCurrencyRow(string);
                    if (yP_Row != null) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    this.logger(2, "getCurrencyMaxAmount() ", exception);
                    return -1L;
                }
            }
            l = (Long)yP_Row.getFieldValueByName("currencyMaxAmount");
            if (l != 0L) break block5;
            return Long.MAX_VALUE;
        }
        return l;
    }

    @Override
    public long getCurrencyDoubleAuthentificationAmount(int n) {
        long l;
        block5: {
            YP_Row yP_Row;
            block4: {
                try {
                    yP_Row = this.getCurrencyRow(n);
                    if (yP_Row != null) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    this.logger(2, "getCurrencyDoubleAuthentificationAmount() ", exception);
                    return -1L;
                }
            }
            l = (Long)yP_Row.getFieldValueByName("currencyDoubleAuthentificationAmount");
            if (l != 0L) break block5;
            return Long.MAX_VALUE;
        }
        return l;
    }

    @Override
    public long getCurrencyDoubleAuthentificationAmount(String string) {
        long l;
        block5: {
            YP_Row yP_Row;
            block4: {
                try {
                    yP_Row = this.getCurrencyRow(string);
                    if (yP_Row != null) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    this.logger(2, "getCurrencyDoubleAuthentificationAmount() ", exception);
                    return -1L;
                }
            }
            l = (Long)yP_Row.getFieldValueByName("currencyDoubleAuthentificationAmount");
            if (l != 0L) break block5;
            return Long.MAX_VALUE;
        }
        return l;
    }

    @Override
    public long getCurrencyChecksum() {
        if (this.cksCurrency == -1L) {
            try {
                this.lock();
                if (this.cksCurrency == -1L) {
                    Object object2;
                    ByteBuilder byteBuilder = new ByteBuilder();
                    Field[] fieldArray = this.currency.getFieldList();
                    for (Object object2 : this.currency) {
                        ((YP_Row)object2).serialize(byteBuilder, fieldArray);
                    }
                    if (byteBuilder.size() == 0) {
                        return 0L;
                    }
                    object2 = new CRC32();
                    object2.update(byteBuilder.data(), 0, byteBuilder.size());
                    this.cksCurrency = object2.getValue();
                }
            }
            finally {
                this.unlock();
            }
        }
        return this.cksCurrency;
    }
}

