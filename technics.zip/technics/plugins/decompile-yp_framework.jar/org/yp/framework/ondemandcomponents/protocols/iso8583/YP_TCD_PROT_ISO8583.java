/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.iso8583;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.iso8583.ISO8583MessageObject;
import org.yp.framework.ondemandcomponents.protocols.iso8583.YP_ISO8583Exception;
import org.yp.framework.ondemandcomponents.protocols.iso8583.YP_ISO8583Utils;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.iso8583.ISO8583Field;
import org.yp.xml.jaxb.iso8583.ISO8583FieldPresence;
import org.yp.xml.jaxb.iso8583.ISO8583FieldTraceType;
import org.yp.xml.jaxb.iso8583.ISO8583Message;
import org.yp.xml.jaxb.iso8583.ISO8583MessageDirection;
import org.yp.xml.jaxb.iso8583.ISO8583MessageInfo;
import org.yp.xml.jaxb.iso8583.ISO8583Presence;
import org.yp.xml.jaxb.iso8583.ISO8583TLVElement;
import org.yp.xml.jaxb.iso8583.ISO8583TLVPresence;
import org.yp.xml.jaxb.iso8583.ISO8583TLVStructure;

public class YP_TCD_PROT_ISO8583
extends YP_OnDemandComponent {
    private long parsingTimeInNano = 0L;
    private long formatTimeInNano = 0L;
    private StringBuilder tlvReceivedOrder = new StringBuilder("");
    private YP_GlobalComponent parserXML = null;
    public ISO8583StateMachine myState = ISO8583StateMachine.DISCONNECTED;
    private YP_PROT_Interface_Com myIpduLayer;
    private byte[] apduBuffer;
    private final Map<String, ISO8583Presence> iso8583SendPresenceObjectList = new HashMap<String, ISO8583Presence>();
    private final Map<String, ISO8583Presence> iso8583ReceivePresenceObjectList = new HashMap<String, ISO8583Presence>();
    private ISO8583Presence myISO8583SendPresence;
    private ISO8583Presence myISO8583ReceivePresence;
    private static List<ISO8583MessageObject> iso8583SendMessageObjectList = new ArrayList<ISO8583MessageObject>();
    private static final ReentrantLock iso8583SendMessageObjectListMutex = new ReentrantLock();
    private static List<ISO8583MessageObject> iso8583ReceiveMessageObjectList = new ArrayList<ISO8583MessageObject>();
    private static final ReentrantLock iso8583ReceiveMessageObjectListMutex = new ReentrantLock();
    private ISO8583MessageObject myISO8583SendMessage = null;
    private ISO8583MessageObject myISO8583ReceiveMessage = null;
    private String messageTypeIndicator;
    private YP_ISO8583Exception myErrorData;
    public byte[] dataToSeal = new byte[0];

    public YP_TCD_PROT_ISO8583(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            this.parserXML = (YP_GlobalComponent)this.getPluginByName("ISO8583Parser");
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PROT_Interface_Com) {
                this.myIpduLayer = (YP_PROT_Interface_Com)objectArray[0];
            }
        }
    }

    public YP_ISO8583Exception YP_GetLastError() {
        return this.myErrorData;
    }

    private static ISO8583Field getMessageField(ISO8583Message iSO8583Message, int n) {
        switch (n) {
            case 1: {
                return iSO8583Message.getField1();
            }
            case 2: {
                return iSO8583Message.getField2();
            }
            case 3: {
                return iSO8583Message.getField3();
            }
            case 4: {
                return iSO8583Message.getField4();
            }
            case 5: {
                return iSO8583Message.getField5();
            }
            case 6: {
                return iSO8583Message.getField6();
            }
            case 7: {
                return iSO8583Message.getField7();
            }
            case 8: {
                return iSO8583Message.getField8();
            }
            case 9: {
                return iSO8583Message.getField9();
            }
            case 10: {
                return iSO8583Message.getField10();
            }
            case 11: {
                return iSO8583Message.getField11();
            }
            case 12: {
                return iSO8583Message.getField12();
            }
            case 13: {
                return iSO8583Message.getField13();
            }
            case 14: {
                return iSO8583Message.getField14();
            }
            case 15: {
                return iSO8583Message.getField15();
            }
            case 16: {
                return iSO8583Message.getField16();
            }
            case 17: {
                return iSO8583Message.getField17();
            }
            case 18: {
                return iSO8583Message.getField18();
            }
            case 19: {
                return iSO8583Message.getField19();
            }
            case 20: {
                return iSO8583Message.getField20();
            }
            case 21: {
                return iSO8583Message.getField21();
            }
            case 22: {
                return iSO8583Message.getField22();
            }
            case 23: {
                return iSO8583Message.getField23();
            }
            case 24: {
                return iSO8583Message.getField24();
            }
            case 25: {
                return iSO8583Message.getField25();
            }
            case 26: {
                return iSO8583Message.getField26();
            }
            case 27: {
                return iSO8583Message.getField27();
            }
            case 28: {
                return iSO8583Message.getField28();
            }
            case 29: {
                return iSO8583Message.getField29();
            }
            case 30: {
                return iSO8583Message.getField30();
            }
            case 31: {
                return iSO8583Message.getField31();
            }
            case 32: {
                return iSO8583Message.getField32();
            }
            case 33: {
                return iSO8583Message.getField33();
            }
            case 34: {
                return iSO8583Message.getField34();
            }
            case 35: {
                return iSO8583Message.getField35();
            }
            case 36: {
                return iSO8583Message.getField36();
            }
            case 37: {
                return iSO8583Message.getField37();
            }
            case 38: {
                return iSO8583Message.getField38();
            }
            case 39: {
                return iSO8583Message.getField39();
            }
            case 40: {
                return iSO8583Message.getField40();
            }
            case 41: {
                return iSO8583Message.getField41();
            }
            case 42: {
                return iSO8583Message.getField42();
            }
            case 43: {
                return iSO8583Message.getField43();
            }
            case 44: {
                return iSO8583Message.getField44();
            }
            case 45: {
                return iSO8583Message.getField45();
            }
            case 46: {
                return iSO8583Message.getField46();
            }
            case 47: {
                return iSO8583Message.getField47();
            }
            case 48: {
                return iSO8583Message.getField48();
            }
            case 49: {
                return iSO8583Message.getField49();
            }
            case 50: {
                return iSO8583Message.getField50();
            }
            case 51: {
                return iSO8583Message.getField51();
            }
            case 52: {
                return iSO8583Message.getField52();
            }
            case 53: {
                return iSO8583Message.getField53();
            }
            case 54: {
                return iSO8583Message.getField54();
            }
            case 55: {
                return iSO8583Message.getField55();
            }
            case 56: {
                return iSO8583Message.getField56();
            }
            case 57: {
                return iSO8583Message.getField57();
            }
            case 58: {
                return iSO8583Message.getField58();
            }
            case 59: {
                return iSO8583Message.getField59();
            }
            case 60: {
                return iSO8583Message.getField60();
            }
            case 61: {
                return iSO8583Message.getField61();
            }
            case 62: {
                return iSO8583Message.getField62();
            }
            case 63: {
                return iSO8583Message.getField63();
            }
            case 64: {
                return iSO8583Message.getField64();
            }
            case 65: {
                return iSO8583Message.getField65();
            }
            case 66: {
                return iSO8583Message.getField66();
            }
            case 67: {
                return iSO8583Message.getField67();
            }
            case 68: {
                return iSO8583Message.getField68();
            }
            case 69: {
                return iSO8583Message.getField69();
            }
            case 70: {
                return iSO8583Message.getField70();
            }
            case 71: {
                return iSO8583Message.getField71();
            }
            case 72: {
                return iSO8583Message.getField72();
            }
            case 73: {
                return iSO8583Message.getField73();
            }
            case 74: {
                return iSO8583Message.getField74();
            }
            case 75: {
                return iSO8583Message.getField75();
            }
            case 76: {
                return iSO8583Message.getField76();
            }
            case 77: {
                return iSO8583Message.getField77();
            }
            case 78: {
                return iSO8583Message.getField78();
            }
            case 79: {
                return iSO8583Message.getField79();
            }
            case 80: {
                return iSO8583Message.getField80();
            }
            case 81: {
                return iSO8583Message.getField81();
            }
            case 82: {
                return iSO8583Message.getField82();
            }
            case 83: {
                return iSO8583Message.getField83();
            }
            case 84: {
                return iSO8583Message.getField84();
            }
            case 85: {
                return iSO8583Message.getField85();
            }
            case 86: {
                return iSO8583Message.getField86();
            }
            case 87: {
                return iSO8583Message.getField87();
            }
            case 88: {
                return iSO8583Message.getField88();
            }
            case 89: {
                return iSO8583Message.getField89();
            }
            case 90: {
                return iSO8583Message.getField90();
            }
            case 91: {
                return iSO8583Message.getField91();
            }
            case 92: {
                return iSO8583Message.getField92();
            }
            case 93: {
                return iSO8583Message.getField93();
            }
            case 94: {
                return iSO8583Message.getField94();
            }
            case 95: {
                return iSO8583Message.getField95();
            }
            case 96: {
                return iSO8583Message.getField96();
            }
            case 97: {
                return iSO8583Message.getField97();
            }
            case 98: {
                return iSO8583Message.getField98();
            }
            case 99: {
                return iSO8583Message.getField99();
            }
            case 100: {
                return iSO8583Message.getField100();
            }
            case 101: {
                return iSO8583Message.getField101();
            }
            case 102: {
                return iSO8583Message.getField102();
            }
            case 103: {
                return iSO8583Message.getField103();
            }
            case 104: {
                return iSO8583Message.getField104();
            }
            case 105: {
                return iSO8583Message.getField105();
            }
            case 106: {
                return iSO8583Message.getField106();
            }
            case 107: {
                return iSO8583Message.getField107();
            }
            case 108: {
                return iSO8583Message.getField108();
            }
            case 109: {
                return iSO8583Message.getField109();
            }
            case 110: {
                return iSO8583Message.getField110();
            }
            case 111: {
                return iSO8583Message.getField111();
            }
            case 112: {
                return iSO8583Message.getField112();
            }
            case 113: {
                return iSO8583Message.getField113();
            }
            case 114: {
                return iSO8583Message.getField114();
            }
            case 115: {
                return iSO8583Message.getField115();
            }
            case 116: {
                return iSO8583Message.getField116();
            }
            case 117: {
                return iSO8583Message.getField117();
            }
            case 118: {
                return iSO8583Message.getField118();
            }
            case 119: {
                return iSO8583Message.getField119();
            }
            case 120: {
                return iSO8583Message.getField120();
            }
            case 121: {
                return iSO8583Message.getField121();
            }
            case 122: {
                return iSO8583Message.getField122();
            }
            case 123: {
                return iSO8583Message.getField123();
            }
            case 124: {
                return iSO8583Message.getField124();
            }
            case 125: {
                return iSO8583Message.getField125();
            }
            case 126: {
                return iSO8583Message.getField126();
            }
            case 127: {
                return iSO8583Message.getField127();
            }
            case 128: {
                return iSO8583Message.getField128();
            }
        }
        return null;
    }

    public static ISO8583FieldPresence getFieldTypePresence(ISO8583Presence iSO8583Presence, int n) {
        switch (n) {
            case 1: {
                return iSO8583Presence.getField1();
            }
            case 2: {
                return iSO8583Presence.getField2();
            }
            case 3: {
                return iSO8583Presence.getField3();
            }
            case 4: {
                return iSO8583Presence.getField4();
            }
            case 5: {
                return iSO8583Presence.getField5();
            }
            case 6: {
                return iSO8583Presence.getField6();
            }
            case 7: {
                return iSO8583Presence.getField7();
            }
            case 8: {
                return iSO8583Presence.getField8();
            }
            case 9: {
                return iSO8583Presence.getField9();
            }
            case 10: {
                return iSO8583Presence.getField10();
            }
            case 11: {
                return iSO8583Presence.getField11();
            }
            case 12: {
                return iSO8583Presence.getField12();
            }
            case 13: {
                return iSO8583Presence.getField13();
            }
            case 14: {
                return iSO8583Presence.getField14();
            }
            case 15: {
                return iSO8583Presence.getField15();
            }
            case 16: {
                return iSO8583Presence.getField16();
            }
            case 17: {
                return iSO8583Presence.getField17();
            }
            case 18: {
                return iSO8583Presence.getField18();
            }
            case 19: {
                return iSO8583Presence.getField19();
            }
            case 20: {
                return iSO8583Presence.getField20();
            }
            case 21: {
                return iSO8583Presence.getField21();
            }
            case 22: {
                return iSO8583Presence.getField22();
            }
            case 23: {
                return iSO8583Presence.getField23();
            }
            case 24: {
                return iSO8583Presence.getField24();
            }
            case 25: {
                return iSO8583Presence.getField25();
            }
            case 26: {
                return iSO8583Presence.getField26();
            }
            case 27: {
                return iSO8583Presence.getField27();
            }
            case 28: {
                return iSO8583Presence.getField28();
            }
            case 29: {
                return iSO8583Presence.getField29();
            }
            case 30: {
                return iSO8583Presence.getField30();
            }
            case 31: {
                return iSO8583Presence.getField31();
            }
            case 32: {
                return iSO8583Presence.getField32();
            }
            case 33: {
                return iSO8583Presence.getField33();
            }
            case 34: {
                return iSO8583Presence.getField34();
            }
            case 35: {
                return iSO8583Presence.getField35();
            }
            case 36: {
                return iSO8583Presence.getField36();
            }
            case 37: {
                return iSO8583Presence.getField37();
            }
            case 38: {
                return iSO8583Presence.getField38();
            }
            case 39: {
                return iSO8583Presence.getField39();
            }
            case 40: {
                return iSO8583Presence.getField40();
            }
            case 41: {
                return iSO8583Presence.getField41();
            }
            case 42: {
                return iSO8583Presence.getField42();
            }
            case 43: {
                return iSO8583Presence.getField43();
            }
            case 44: {
                return iSO8583Presence.getField44();
            }
            case 45: {
                return iSO8583Presence.getField45();
            }
            case 46: {
                return iSO8583Presence.getField46();
            }
            case 47: {
                return iSO8583Presence.getField47();
            }
            case 48: {
                return iSO8583Presence.getField48();
            }
            case 49: {
                return iSO8583Presence.getField49();
            }
            case 50: {
                return iSO8583Presence.getField50();
            }
            case 51: {
                return iSO8583Presence.getField51();
            }
            case 52: {
                return iSO8583Presence.getField52();
            }
            case 53: {
                return iSO8583Presence.getField53();
            }
            case 54: {
                return iSO8583Presence.getField54();
            }
            case 55: {
                return iSO8583Presence.getField55();
            }
            case 56: {
                return iSO8583Presence.getField56();
            }
            case 57: {
                return iSO8583Presence.getField57();
            }
            case 58: {
                return iSO8583Presence.getField58();
            }
            case 59: {
                return iSO8583Presence.getField59();
            }
            case 60: {
                return iSO8583Presence.getField60();
            }
            case 61: {
                return iSO8583Presence.getField61();
            }
            case 62: {
                return iSO8583Presence.getField62();
            }
            case 63: {
                return iSO8583Presence.getField63();
            }
            case 64: {
                return iSO8583Presence.getField64();
            }
            case 65: {
                return iSO8583Presence.getField65();
            }
            case 66: {
                return iSO8583Presence.getField66();
            }
            case 67: {
                return iSO8583Presence.getField67();
            }
            case 68: {
                return iSO8583Presence.getField68();
            }
            case 69: {
                return iSO8583Presence.getField69();
            }
            case 70: {
                return iSO8583Presence.getField70();
            }
            case 71: {
                return iSO8583Presence.getField71();
            }
            case 72: {
                return iSO8583Presence.getField72();
            }
            case 73: {
                return iSO8583Presence.getField73();
            }
            case 74: {
                return iSO8583Presence.getField74();
            }
            case 75: {
                return iSO8583Presence.getField75();
            }
            case 76: {
                return iSO8583Presence.getField76();
            }
            case 77: {
                return iSO8583Presence.getField77();
            }
            case 78: {
                return iSO8583Presence.getField78();
            }
            case 79: {
                return iSO8583Presence.getField79();
            }
            case 80: {
                return iSO8583Presence.getField80();
            }
            case 81: {
                return iSO8583Presence.getField81();
            }
            case 82: {
                return iSO8583Presence.getField82();
            }
            case 83: {
                return iSO8583Presence.getField83();
            }
            case 84: {
                return iSO8583Presence.getField84();
            }
            case 85: {
                return iSO8583Presence.getField85();
            }
            case 86: {
                return iSO8583Presence.getField86();
            }
            case 87: {
                return iSO8583Presence.getField87();
            }
            case 88: {
                return iSO8583Presence.getField88();
            }
            case 89: {
                return iSO8583Presence.getField89();
            }
            case 90: {
                return iSO8583Presence.getField90();
            }
            case 91: {
                return iSO8583Presence.getField91();
            }
            case 92: {
                return iSO8583Presence.getField92();
            }
            case 93: {
                return iSO8583Presence.getField93();
            }
            case 94: {
                return iSO8583Presence.getField94();
            }
            case 95: {
                return iSO8583Presence.getField95();
            }
            case 96: {
                return iSO8583Presence.getField96();
            }
            case 97: {
                return iSO8583Presence.getField97();
            }
            case 98: {
                return iSO8583Presence.getField98();
            }
            case 99: {
                return iSO8583Presence.getField99();
            }
            case 100: {
                return iSO8583Presence.getField100();
            }
            case 101: {
                return iSO8583Presence.getField101();
            }
            case 102: {
                return iSO8583Presence.getField102();
            }
            case 103: {
                return iSO8583Presence.getField103();
            }
            case 104: {
                return iSO8583Presence.getField104();
            }
            case 105: {
                return iSO8583Presence.getField105();
            }
            case 106: {
                return iSO8583Presence.getField106();
            }
            case 107: {
                return iSO8583Presence.getField107();
            }
            case 108: {
                return iSO8583Presence.getField108();
            }
            case 109: {
                return iSO8583Presence.getField109();
            }
            case 110: {
                return iSO8583Presence.getField110();
            }
            case 111: {
                return iSO8583Presence.getField111();
            }
            case 112: {
                return iSO8583Presence.getField112();
            }
            case 113: {
                return iSO8583Presence.getField113();
            }
            case 114: {
                return iSO8583Presence.getField114();
            }
            case 115: {
                return iSO8583Presence.getField115();
            }
            case 116: {
                return iSO8583Presence.getField116();
            }
            case 117: {
                return iSO8583Presence.getField117();
            }
            case 118: {
                return iSO8583Presence.getField118();
            }
            case 119: {
                return iSO8583Presence.getField119();
            }
            case 120: {
                return iSO8583Presence.getField120();
            }
            case 121: {
                return iSO8583Presence.getField121();
            }
            case 122: {
                return iSO8583Presence.getField122();
            }
            case 123: {
                return iSO8583Presence.getField123();
            }
            case 124: {
                return iSO8583Presence.getField124();
            }
            case 125: {
                return iSO8583Presence.getField125();
            }
            case 126: {
                return iSO8583Presence.getField126();
            }
            case 127: {
                return iSO8583Presence.getField127();
            }
            case 128: {
                return iSO8583Presence.getField128();
            }
        }
        return null;
    }

    private static boolean isItATlv(YP_ISO8583Utils.FieldFormat fieldFormat) {
        switch (fieldFormat) {
            case fixe: 
            case NVAR: 
            case NNVAR: 
            case AVAR: 
            case AAVAR: 
            case AAAVAR: 
            case NNEEVAR: 
            case NNNEEVAR: 
            case LVAR: 
            case LLVAR: 
            case LLLVAR: {
                return false;
            }
        }
        return true;
    }

    public void resetSeal() {
        this.dataToSeal = new byte[0];
    }

    private void addDataToSeal(byte[] byArray) {
        byte[] byArray2 = this.dataToSeal;
        this.dataToSeal = new byte[byArray2.length + byArray.length];
        System.arraycopy(byArray2, 0, this.dataToSeal, 0, byArray2.length);
        System.arraycopy(byArray, 0, this.dataToSeal, byArray2.length, byArray.length);
    }

    public String YP_CalculateSeal(byte[] byArray, int n) {
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        while (n4 < n) {
            byte by = 1;
            while (by != 0) {
                if (((n2 = (n2 << 1) + ((byArray[n4] & by) != 0 ? 1 : 0)) & Integer.MIN_VALUE) != 0) {
                    n2 ^= 0x88108000;
                }
                by = (byte)(by << 1);
            }
            ++n4;
        }
        n4 = 1;
        while (n4 != 0) {
            if (((n2 <<= 1) & Integer.MIN_VALUE) != 0) {
                n2 ^= 0x88108000;
            }
            n4 = (byte)(n4 << 1);
        }
        n4 = 1;
        while (n4 != 0) {
            if (((n2 <<= 1) & Integer.MIN_VALUE) != 0) {
                n2 ^= 0x88108000;
            }
            n4 = (byte)(n4 << 1);
        }
        n4 = 0;
        while (n4 < 15) {
            if (((n2 <<= 1) & Integer.MIN_VALUE) != 0) {
                n2 ^= 0x88108000;
            }
            ++n4;
        }
        n2 >>= 15;
        n4 = 1;
        while (n4 != 0) {
            n3 = (short)((n3 << 1) + ((n2 & n4) != 0 ? 1 : 0));
            n4 = (short)(n4 << 1);
        }
        int n5 = (n3 & 0xFF) * 256;
        String string = Integer.toHexString(n5 += (n3 & 0xFF00) / 256);
        if (string.length() < 2) {
            return "000" + string;
        }
        if (string.length() < 3) {
            return "00" + string;
        }
        if (string.length() < 4) {
            return "0" + string;
        }
        return string;
    }

    @Deprecated
    public int YP_SetValue(ISO8583Message iSO8583Message, int n, String string, String string2, String string3) {
        if (string2 != null) {
            return this.YP_SetStructureValue(iSO8583Message, n, string, string2, string3);
        }
        if (string != null) {
            return this.YP_SetTLVValue(iSO8583Message, n, string, string3);
        }
        return this.YP_SetFieldValue(iSO8583Message, n, string3);
    }

    public int YP_SetFieldValue(ISO8583Message iSO8583Message, int n, String string) {
        ISO8583Field iSO8583Field;
        block11: {
            YP_ISO8583Utils.FieldFormat fieldFormat;
            block10: {
                block9: {
                    block8: {
                        block7: {
                            try {
                                if (iSO8583Message != null) break block7;
                                this.logger(2, "YP_SetFieldValue() myISO8583Data null");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                            catch (Exception exception) {
                                this.logger(2, "YP_SetFieldValue() " + exception);
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                        }
                        if (n > 0 && n <= 128) break block8;
                        this.logger(2, "YP_SetFieldValue() FieldNumber out of range");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                    if (iSO8583Field != null) break block9;
                    this.logger(2, "YP_SetFieldValue() pb with dataField");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return -1;
                }
                fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                if (fieldFormat != null) break block10;
                this.logger(2, "YP_SetFieldValue() pb with fieldFormat");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            if (!YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block11;
            this.logger(2, "YP_SetFieldValue() It's a tlv field...");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        iSO8583Field.setFieldValue(string);
        return 1;
    }

    public int YP_SetTLVValue(ISO8583Message iSO8583Message, int n, String string, String string2) {
        ISO8583TLVElement iSO8583TLVElement;
        ISO8583Field iSO8583Field;
        block19: {
            block18: {
                block17: {
                    YP_ISO8583Utils.FieldFormat fieldFormat;
                    block16: {
                        block15: {
                            block14: {
                                block13: {
                                    if (iSO8583Message != null) break block13;
                                    this.logger(2, "YP_SetTLVValue() myISO8583Data null");
                                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                    return -1;
                                }
                                if (n > 0 && n <= 128) break block14;
                                this.logger(2, "YP_SetTLVValue() FieldNumber out of range");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                            iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                            if (iSO8583Field != null) break block15;
                            this.logger(2, "YP_SetTLVValue() pb with dataField");
                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                            return -1;
                        }
                        fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                        if (fieldFormat != null) break block16;
                        this.logger(2, "YP_SetTLVValue() pb with fieldFormat");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block17;
                    this.logger(2, "YP_SetTLVValue() It's not a tlv field...");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return -1;
                }
                iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
                if (iSO8583TLVElement != null) break block18;
                this.logger(2, "YP_SetTLVValue() TLV Name not found:" + string);
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
            if (fieldFormat != YP_ISO8583Utils.FieldFormat.structure) break block19;
            this.logger(2, "YP_SetTLVValue() It's a structure field...:" + n + " : " + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        try {
            String string3 = iSO8583TLVElement.getAssociatedTLV();
            if (string3 == null || string3.isEmpty()) {
                iSO8583TLVElement.getTLVValue().add(string2);
            } else {
                int n2 = 1;
                ISO8583TLVElement iSO8583TLVElement2 = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string3);
                if (iSO8583TLVElement2 != null) {
                    n2 = iSO8583TLVElement2.getTLVValue().size();
                }
                int n3 = iSO8583TLVElement.getTLVValue().size();
                while (n3 < n2) {
                    iSO8583TLVElement.getTLVValue().add(null);
                    ++n3;
                }
                iSO8583TLVElement.getTLVValue().set(n2 - 1, string2);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetTLVValue() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int YP_SetStructureValue(ISO8583Message iSO8583Message, int n, String string, String string2, String string3) {
        try {
            ISO8583TLVStructure iSO8583TLVStructure;
            if (iSO8583Message == null) {
                this.logger(2, "YP_SetStructureValue() myISO8583Data null");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            if (n <= 0 || n > 128) {
                this.logger(2, "YP_SetStructureValue() FieldNumber out of range");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            ISO8583Field iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
            if (iSO8583Field == null) {
                this.logger(2, "YP_SetStructureValue() pb with dataField");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
            if (fieldFormat == null) {
                this.logger(2, "YP_SetStructureValue() pb with fieldFormat");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            if (!YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) {
                this.logger(2, "YP_SetStructureValue() It's not a tlv field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            ISO8583TLVElement iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
            if (iSO8583TLVElement == null) {
                this.logger(2, "YP_SetStructureValue() TLV Name not found:" + string);
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            YP_ISO8583Utils.FieldFormat fieldFormat2 = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
            if (fieldFormat2 != YP_ISO8583Utils.FieldFormat.structure) {
                this.logger(2, "YP_SetStructureValue() It's not a structure field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            if (string2 == null) {
                this.logger(2, "YP_SetStructureValue() Structure element name is null");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            }
            Iterator<ISO8583TLVStructure> iterator = iSO8583TLVElement.getTLVStructureElt().iterator();
            do {
                if (iterator.hasNext()) continue;
                this.logger(2, "YP_SetStructureValue() TLV Structure Name not found:" + string2);
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -1;
            } while (!(iSO8583TLVStructure = iterator.next()).getName().contentEquals(string2));
            iSO8583TLVStructure.getTLVStructureValue().add(string3);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetStructureValue() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
    }

    public String YP_GetFieldValue(ISO8583Message iSO8583Message, int n) {
        block12: {
            YP_ISO8583Utils.FieldFormat fieldFormat;
            ISO8583Field iSO8583Field;
            block11: {
                block10: {
                    block9: {
                        block8: {
                            try {
                                if (iSO8583Message != null) break block8;
                                this.logger(2, "YP_GetFieldValue() myISO8583Data null");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return null;
                            }
                            catch (Exception exception) {
                                this.logger(2, "YP_GetFieldValue() " + exception);
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return null;
                            }
                        }
                        if (n > 0 && n <= 128) break block9;
                        this.logger(2, "YP_GetFieldValue() FieldNumber out of range");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return null;
                    }
                    iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                    if (iSO8583Field != null) break block10;
                    this.logger(2, "YP_GetFieldValue() pb with dataField");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return null;
                }
                fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                if (fieldFormat != null) break block11;
                this.logger(2, "YP_GetFieldValue() pb with fieldFormat");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return null;
            }
            if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block12;
            String string = iSO8583Field.getFieldValue();
            if (string != null) {
                return string;
            }
            return "";
        }
        this.logger(2, "YP_GetFieldValue() It's a tlv field...");
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        return null;
    }

    public List<String> YP_GetTLVValueList(ISO8583Message iSO8583Message, int n, String string) {
        List<String> list;
        block17: {
            ISO8583TLVElement iSO8583TLVElement;
            block16: {
                block15: {
                    ISO8583Field iSO8583Field;
                    block14: {
                        YP_ISO8583Utils.FieldFormat fieldFormat;
                        block13: {
                            block12: {
                                block11: {
                                    block10: {
                                        try {
                                            if (iSO8583Message != null) break block10;
                                            this.logger(2, "YP_GetTLVValueList() myISO8583Data null");
                                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                            return null;
                                        }
                                        catch (Exception exception) {
                                            this.logger(2, "YP_GetTLVValueList() " + exception);
                                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                            return null;
                                        }
                                    }
                                    if (n > 0 && n <= 128) break block11;
                                    this.logger(2, "YP_GetTLVValueList() FieldNumber out of range");
                                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                    return null;
                                }
                                iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                                if (iSO8583Field != null) break block12;
                                this.logger(2, "YP_GetTLVValueList() pb with dataField");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return null;
                            }
                            fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                            if (fieldFormat != null) break block13;
                            this.logger(2, "YP_GetTLVValueList() pb with fieldFormat");
                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                            return null;
                        }
                        if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block14;
                        this.logger(2, "YP_GetTLVValueList() It's not a tlv field...");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return null;
                    }
                    iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
                    if (iSO8583TLVElement != null) break block15;
                    this.logger(2, "YP_GetTLVValueList() TLV Name not found:" + string);
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return null;
                }
                YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
                if (fieldFormat != YP_ISO8583Utils.FieldFormat.structure) break block16;
                this.logger(2, "YP_GetTLVValueList() It's a structure field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return null;
            }
            list = iSO8583TLVElement.getTLVValue();
            if (list != null && !list.isEmpty()) break block17;
            return null;
        }
        return list;
    }

    public String YP_GetTLVValue(ISO8583Message iSO8583Message, int n, String string) {
        List<String> list = this.YP_GetTLVValueList(iSO8583Message, n, string);
        if (list == null || list.isEmpty()) {
            return null;
        }
        if (list.size() > 1) {
            this.logger(2, "YP_GetTLVValue() too many TLV retrieved field " + n + " " + string);
            this.logger(2, "YP_GetTLVValue() only the first one is handle");
        }
        return list.get(0);
    }

    public List<String> YP_GetStructureValue(ISO8583Message iSO8583Message, int n, String string, String string2) {
        ISO8583TLVElement iSO8583TLVElement;
        block20: {
            block19: {
                YP_ISO8583Utils.FieldFormat fieldFormat;
                block18: {
                    block17: {
                        ISO8583Field iSO8583Field;
                        block16: {
                            YP_ISO8583Utils.FieldFormat fieldFormat2;
                            block15: {
                                block14: {
                                    block13: {
                                        block12: {
                                            if (iSO8583Message != null) break block12;
                                            this.logger(2, "YP_GetStructureValue() myISO8583Data null");
                                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                            return null;
                                        }
                                        if (n > 0 && n <= 128) break block13;
                                        this.logger(2, "YP_GetStructureValue() FieldNumber out of range");
                                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                        return null;
                                    }
                                    iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                                    if (iSO8583Field != null) break block14;
                                    this.logger(2, "YP_GetStructureValue() pb with dataField");
                                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                    return null;
                                }
                                fieldFormat2 = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                                if (fieldFormat2 != null) break block15;
                                this.logger(2, "YP_GetStructureValue() pb with myFieldFormat");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return null;
                            }
                            if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat2)) break block16;
                            this.logger(2, "YP_GetStructureValue() It's not a structure field...");
                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                            return null;
                        }
                        iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
                        if (iSO8583TLVElement != null) break block17;
                        this.logger(2, "YP_GetStructureValue() TLV Name not found:" + string);
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return null;
                    }
                    fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
                    if (fieldFormat != null) break block18;
                    this.logger(2, "YP_GetStructureValue() pb with fieldFormat");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return null;
                }
                if (fieldFormat == YP_ISO8583Utils.FieldFormat.structure) break block19;
                this.logger(2, "YP_GetStructureValue() It's not a structure field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return null;
            }
            if (string2 != null) break block20;
            this.logger(2, "YP_GetStructureValue() Structure element name is null");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return null;
        }
        try {
            for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
                if (!iSO8583TLVStructure.getName().contentEquals(string2)) continue;
                return iSO8583TLVStructure.getTLVStructureValue();
            }
            this.logger(2, "YP_GetStructureValue() TLV Structure Name not found:" + string2);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "YP_GetStructureValue() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return null;
        }
    }

    public void YP_SetXMLSendMessage(String string) {
        try {
            if (this.myISO8583SendMessage != null) {
                this.myISO8583SendMessage.onUse = 0;
                this.myISO8583SendMessage = null;
            }
            if (string == null) {
                this.logger(2, "YP_SetXMLSendMessage() No presence file given...");
                return;
            }
            ISO8583MessageObject iSO8583MessageObject = null;
            try {
                iso8583SendMessageObjectListMutex.lock();
                for (ISO8583MessageObject object2 : iso8583SendMessageObjectList) {
                    if (object2 == null || object2.onUse != 0 || !object2.name.contentEquals(string)) continue;
                    object2.onUse = 1;
                    iSO8583MessageObject = object2;
                    break;
                }
            }
            finally {
                iso8583SendMessageObjectListMutex.unlock();
            }
            if (iSO8583MessageObject != null) {
                this.myISO8583SendMessage = iSO8583MessageObject;
                this.emptyISO8583Message(this.myISO8583SendMessage.iso8583Message);
                return;
            }
            ISO8583Message iSO8583Message = (ISO8583Message)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.myISO8583SendMessage = new ISO8583MessageObject(string, iSO8583Message);
            try {
                iso8583SendMessageObjectListMutex.lock();
                iso8583SendMessageObjectList.add(this.myISO8583SendMessage);
            }
            finally {
                iso8583SendMessageObjectListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLSendMessage() " + exception + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLSendPresence(String string) {
        try {
            if (string == null) {
                this.logger(2, "YP_SetXMLRequestPresence() No presence file given...");
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_SetXMLSendPresence() " + string);
            }
            this.myISO8583SendPresence = this.iso8583SendPresenceObjectList.get(string);
            if (this.myISO8583SendPresence != null) {
                return;
            }
            this.myISO8583SendPresence = (ISO8583Presence)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.iso8583SendPresenceObjectList.put(string, this.myISO8583SendPresence);
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLSendPresence() " + exception + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLReceiveMessage(String string) {
        try {
            if (this.myISO8583ReceiveMessage != null) {
                this.myISO8583ReceiveMessage.onUse = 0;
                this.myISO8583ReceiveMessage = null;
            }
            if (string == null) {
                this.logger(2, "YP_SetXMLReceiveMessage() No presence file given...");
                return;
            }
            ISO8583MessageObject iSO8583MessageObject = null;
            try {
                iso8583ReceiveMessageObjectListMutex.lock();
                for (ISO8583MessageObject object2 : iso8583ReceiveMessageObjectList) {
                    if (object2 == null || object2.onUse != 0 || !object2.name.contentEquals(string)) continue;
                    object2.onUse = 1;
                    iSO8583MessageObject = object2;
                    break;
                }
            }
            finally {
                iso8583ReceiveMessageObjectListMutex.unlock();
            }
            if (iSO8583MessageObject != null) {
                this.myISO8583ReceiveMessage = iSO8583MessageObject;
                this.emptyISO8583Message(this.myISO8583ReceiveMessage.iso8583Message);
                return;
            }
            ISO8583Message iSO8583Message = (ISO8583Message)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.myISO8583ReceiveMessage = new ISO8583MessageObject(string, iSO8583Message);
            try {
                iso8583ReceiveMessageObjectListMutex.lock();
                iso8583ReceiveMessageObjectList.add(this.myISO8583ReceiveMessage);
            }
            finally {
                iso8583ReceiveMessageObjectListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLReceiveMessage() " + exception + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLReceivePresence(String string) {
        try {
            if (string == null) {
                this.logger(2, "YP_SetXMLReceivePresence() No presence file given...");
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_SetXMLReceivePresence() " + string);
            }
            this.myISO8583ReceivePresence = this.iso8583ReceivePresenceObjectList.get(string);
            if (this.myISO8583ReceivePresence != null) {
                return;
            }
            this.myISO8583ReceivePresence = (ISO8583Presence)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.iso8583ReceivePresenceObjectList.put(string, this.myISO8583ReceivePresence);
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLReceivePresence() " + exception + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    public ISO8583Message YP_GetNewSendFactoryObject() {
        this.emptyISO8583Message(this.myISO8583SendMessage.iso8583Message);
        return this.myISO8583SendMessage.iso8583Message;
    }

    public ISO8583Message YP_GetSendFactoryObject() {
        return this.myISO8583SendMessage.iso8583Message;
    }

    public ISO8583Presence YP_GetSendPresenceFactoryObject() {
        return this.myISO8583SendPresence;
    }

    public ISO8583Presence YP_GetReceivePresenceFactoryObject() {
        return this.myISO8583ReceivePresence;
    }

    public ISO8583Message YP_GetReceiveFactoryObject() {
        return this.myISO8583ReceiveMessage.iso8583Message;
    }

    private void traceMTIInfo(byte[] byArray) {
        String string;
        if (this.getLogLevel() < 5) {
            return;
        }
        if (byArray == null || byArray.length != 4) {
            return;
        }
        switch (byArray[0]) {
            case 48: {
                string = "MTI: 1987 ISO8583 Standard";
                break;
            }
            case 49: {
                string = "MTI: 1993 ISO8583 Standard";
                break;
            }
            case 50: {
                string = "MTI: 2003 ISO8583 Standard";
                break;
            }
            default: {
                string = "MTI: Unknown ISO8583 Standard";
            }
        }
        this.logger(5, string);
        switch (byArray[1]) {
            case 48: 
            case 57: {
                string = "MTI: Message Class : Reserved ISO";
                break;
            }
            case 49: {
                string = "MTI: Message Class : Authorization";
                break;
            }
            case 50: {
                string = "MTI: Message Class : Financial presentment";
                break;
            }
            case 51: {
                string = "MTI: Message Class : File Action";
                break;
            }
            case 52: {
                string = "MTI: Message Class : Reversal/Chargeback";
                break;
            }
            case 53: {
                string = "MTI: Message Class : Reconciliation";
                break;
            }
            case 54: {
                string = "MTI: Message Class : Administrative";
                break;
            }
            case 55: {
                string = "MTI: Message Class : Fee Collection";
                break;
            }
            case 56: {
                string = "MTI: Message Class : Network Management";
                break;
            }
            default: {
                string = "MTI: Message Class : ???";
            }
        }
        this.logger(5, string);
        switch (byArray[2]) {
            case 48: {
                string = "MTI: Message Function : Request";
                break;
            }
            case 49: {
                string = "MTI: Message Function : Request Response";
                break;
            }
            case 50: {
                string = "MTI: Message Function : Advice";
                break;
            }
            case 51: {
                string = "MTI: Message Function : Advice Response";
                break;
            }
            case 52: {
                string = "MTI: Message Function : Notification";
                break;
            }
            case 53: {
                string = "MTI: Message Function : Notification acknowledgment";
                break;
            }
            case 54: {
                string = "MTI: Message Function : Instruction";
                break;
            }
            case 55: {
                string = "MTI: Message Function : Instruction acknowledgment";
                break;
            }
            case 56: 
            case 57: {
                string = "MTI: Message Function : Reserved ISO";
                break;
            }
            default: {
                string = "MTI: Message Function : ???";
            }
        }
        this.logger(5, string);
        switch (byArray[3]) {
            case 48: {
                string = "MTI: Transaction Originator : Acquirer";
                break;
            }
            case 49: {
                string = "MTI: Transaction Originator : Acquirer Repeat";
                break;
            }
            case 50: {
                string = "MTI: Transaction Originator : Card Issuer";
                break;
            }
            case 51: {
                string = "MTI: Transaction Originator : Card Issuer Repeat";
                break;
            }
            case 52: {
                string = "MTI: Transaction Originator : Other Originator";
                break;
            }
            case 53: {
                string = "MTI: Transaction Originator : Other Originator Repeat";
                break;
            }
            case 54: 
            case 55: 
            case 56: 
            case 57: {
                string = "MTI: Transaction Originator : Reserved ISO";
                break;
            }
            default: {
                string = "MTI: Transaction Originator : ???";
            }
        }
        this.logger(5, string);
    }

    /*
     * Exception decompiling
     */
    public int YP_FormatISO8583Message(boolean var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 20[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void YP_ParseISO8583Structure(ISO8583TLVElement iSO8583TLVElement, YP_ISO8583Utils.DataFormat dataFormat, byte[] byArray) {
        YP_ISO8583Utils yP_ISO8583Utils = new YP_ISO8583Utils(this);
        yP_ISO8583Utils.YP_SetFormatedTLV(byArray);
        boolean bl = true;
        for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVStructure.getTLVStructureLengthType());
            YP_ISO8583Utils.DataFormat dataFormat2 = YP_ISO8583Utils.getMyDataFormat(iSO8583TLVStructure.getTLVStructureFormat());
            yP_ISO8583Utils.YP_SetFormat(fieldFormat, dataFormat2, dataFormat, 1);
            yP_ISO8583Utils.YP_SetMyLength(iSO8583TLVStructure.getTLVStructureLength());
            try {
                int n = yP_ISO8583Utils.YP_ParseData(bl);
                if (n == 1) {
                    iSO8583TLVStructure.getTLVStructureValue().add(yP_ISO8583Utils.getValue());
                } else if (n == 0) {
                    iSO8583TLVStructure.getTLVStructureValue().add("");
                } else if (n == -1) {
                    this.logger(2, "YP_ParseISO8583Structure() error during YP_ParseData");
                    this.logger(3, UtilsYP.getFormattedLog(0, byArray, 0, byArray.length));
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, "", iSO8583TLVElement.getName(), null);
                    throw this.myErrorData;
                }
            }
            catch (YP_ISO8583Exception yP_ISO8583Exception) {
                this.logger(2, "??? " + yP_ISO8583Exception);
                this.myErrorData = yP_ISO8583Exception;
            }
            bl = false;
        }
    }

    /*
     * Exception decompiling
     */
    private boolean checkTLVDataLength(boolean var1_1, ISO8583TLVElement var2_2, YP_ISO8583Utils.FieldFormat var3_3, String var4_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Can't sort instructions [@NONE, blocks:[5] lbl68 : CaseStatement: default:\u000a, @NONE, blocks:[5] lbl68 : CaseStatement: default:\u000a]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:8)
         *     at java.base/java.util.TimSort.countRunAndMakeAscending(TimSort.java:360)
         *     at java.base/java.util.TimSort.sort(TimSort.java:220)
         *     at java.base/java.util.Arrays.sort(Arrays.java:1307)
         *     at java.base/java.util.ArrayList.sort(ArrayList.java:1721)
         *     at java.base/java.util.Collections.sort(Collections.java:179)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.buildSwitchCases(SwitchReplacer.java:271)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitch(SwitchReplacer.java:258)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:66)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int YP_ParseISO8583Message(byte[] byArray) {
        int n;
        boolean bl = false;
        long l = 0L;
        int n2 = 0;
        this.emptyISO8583Message(this.myISO8583ReceiveMessage.iso8583Message);
        String string = this.myISO8583ReceiveMessage.iso8583Message.getMessageTypeFormat();
        if (string != null && string.contentEquals("ASCII")) {
            this.messageTypeIndicator = new String(byArray, 0, 4);
            n = 4;
        } else if (string != null && string.contentEquals("EBCDIC")) {
            this.messageTypeIndicator = new String(YP_ISO8583Utils.EBCDICConverter.convertEBCDICToASCII(byArray, 4));
            n = 4;
        } else {
            this.messageTypeIndicator = UtilsYP.devHexa(byArray, 0, 2);
            n = 2;
        }
        this.traceMTIInfo(this.messageTypeIndicator.getBytes());
        try {
            long l2 = System.nanoTime();
            long l3 = byArray[n];
            int n3 = n + 1;
            while (n3 < n + 8) {
                l3 <<= 8;
                l3 |= (long)byArray[n3] & 0xFFL;
                ++n3;
            }
            if ((l3 & Long.MIN_VALUE) != 0L) {
                bl = true;
                l = byArray[n + 8];
                n3 = n + 1;
                while (n3 < n + 8) {
                    l <<= 8;
                    l |= (long)byArray[n3 + 8] & 0xFFL;
                    ++n3;
                }
            }
            n3 = 1;
            YP_ISO8583Utils yP_ISO8583Utils = new YP_ISO8583Utils(this);
            byte[] byArray2 = bl ? Arrays.copyOfRange(byArray, n + 16, byArray.length) : Arrays.copyOfRange(byArray, n + 8, byArray.length);
            yP_ISO8583Utils.YP_SetFormatedTLV(byArray2);
            long l4 = l3;
            int n4 = bl ? 129 : 65;
            n2 = 2;
            while (n2 < n4) {
                block41: {
                    l4 = n2 == 65 ? l : (l4 <<= 1);
                    if ((l4 & Long.MIN_VALUE) != 0L) {
                        ISO8583Field iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583ReceiveMessage.iso8583Message, n2);
                        if (iSO8583Field == null) {
                            this.logger(3, "YP_ParseISO8583Message() unknow field received :" + n2);
                        } else {
                            Object object;
                            int n5;
                            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                            int n6 = iSO8583Field.getFieldLength();
                            yP_ISO8583Utils.YP_SetMyLength(n6);
                            int n7 = 1;
                            if (n6 > 255) {
                                n7 = 2;
                            }
                            if (n6 > 65535) {
                                n7 = 3;
                            }
                            YP_ISO8583Utils.DataFormat dataFormat = YP_ISO8583Utils.getMyDataFormat(iSO8583Field.getFieldFormat());
                            YP_ISO8583Utils.DataFormat dataFormat2 = YP_ISO8583Utils.getMyDataFormat(iSO8583Field.getDataFormat());
                            if (dataFormat2 == null) {
                                dataFormat2 = dataFormat;
                            }
                            if (!YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) {
                                yP_ISO8583Utils.YP_SetFormat(fieldFormat, dataFormat2, dataFormat, n7);
                                try {
                                    n5 = yP_ISO8583Utils.YP_ParseData(n3 != 0);
                                    if (n5 == 1) {
                                        n3 = 0;
                                        object = yP_ISO8583Utils.getValue();
                                        iSO8583Field.setFieldValue((String)object);
                                        break block41;
                                    } else if (n5 == -1) {
                                        this.logger(2, "YP_ParseISO8583Message() error during YP_ParseData 1");
                                        this.logger(3, UtilsYP.getFormattedLog(0, byArray, 0, byArray.length));
                                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, Integer.toString(n2), null, null);
                                        throw this.myErrorData;
                                    }
                                    break block41;
                                }
                                catch (YP_ISO8583Exception yP_ISO8583Exception) {
                                    yP_ISO8583Exception.setFieldId(Integer.toString(n2));
                                    this.logger(2, "YP_ParseISO8583Message() format error " + yP_ISO8583Exception);
                                    throw yP_ISO8583Exception;
                                }
                            }
                            if (fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_zc) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLV_b) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_b) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.BER_TLV) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLV_a)) {
                                try {
                                    yP_ISO8583Utils.YP_SetFormat(fieldFormat, dataFormat, dataFormat, n7);
                                    n5 = yP_ISO8583Utils.YP_ParseData(n3 != 0);
                                    while (n5 == 1) {
                                        Object object2;
                                        if (n2 == 72) {
                                            object = new byte[yP_ISO8583Utils.getValue().length() / 2];
                                            UtilsYP.redHexa((byte[])object, yP_ISO8583Utils.getValue(), ((Object)object).length);
                                            object2 = this.dataToSeal;
                                            this.dataToSeal = new byte[((byte[])object2).length + ((Object)object).length];
                                            System.arraycopy(object2, 0, this.dataToSeal, 0, ((byte[])object2).length);
                                            System.arraycopy(object, 0, this.dataToSeal, ((byte[])object2).length, ((Object)object).length);
                                        }
                                        n3 = 0;
                                        object = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, yP_ISO8583Utils.YP_GetTag());
                                        if (object != null) {
                                            this.tlvReceivedOrder.append(((ISO8583TLVElement)object).getName());
                                            object2 = (Object)YP_ISO8583Utils.getMyFieldFormat(((ISO8583TLVElement)object).getLengthType());
                                            if (object2 == YP_ISO8583Utils.FieldFormat.structure) {
                                                this.YP_ParseISO8583Structure((ISO8583TLVElement)object, dataFormat, yP_ISO8583Utils.YP_GetValueFromTLV());
                                            } else {
                                                YP_ISO8583Utils.DataFormat dataFormat3 = YP_ISO8583Utils.getMyDataFormat(((ISO8583TLVElement)object).getFormat());
                                                yP_ISO8583Utils.YP_SetFieldFormat(dataFormat3);
                                                if (!this.checkTLVDataLength(false, (ISO8583TLVElement)object, fieldFormat, yP_ISO8583Utils.getValue())) {
                                                    n5 = -1;
                                                    this.logger(2, "YP_ParseISO8583Message() Field " + n2 + " TLV " + ((ISO8583TLVElement)object).getName() + " may have a wrong length ");
                                                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n2), ((ISO8583TLVElement)object).getName(), null);
                                                    throw this.myErrorData;
                                                }
                                                String string2 = ((ISO8583TLVElement)object).getAssociatedTLV();
                                                if (string2 == null || string2.isEmpty()) {
                                                    ((ISO8583TLVElement)object).getTLVValue().add(yP_ISO8583Utils.getValue());
                                                } else {
                                                    int n8 = 1;
                                                    ISO8583TLVElement iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string2);
                                                    if (iSO8583TLVElement != null) {
                                                        n8 = iSO8583TLVElement.getTLVValue().size();
                                                    }
                                                    int n9 = ((ISO8583TLVElement)object).getTLVValue().size();
                                                    while (n9 < n8) {
                                                        ((ISO8583TLVElement)object).getTLVValue().add(null);
                                                        ++n9;
                                                    }
                                                    ((ISO8583TLVElement)object).getTLVValue().set(n8 - 1, yP_ISO8583Utils.getValue());
                                                }
                                            }
                                        }
                                        yP_ISO8583Utils.YP_SetFieldFormat(dataFormat);
                                        n5 = yP_ISO8583Utils.YP_ParseData(n3 != 0);
                                    }
                                    if (n5 == -1) {
                                        this.logger(2, "YP_ParseISO8583Message() error during YP_ParseData 2");
                                        this.logger(3, UtilsYP.getFormattedLog(0, byArray, 0, byArray.length));
                                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, Integer.toString(n2), yP_ISO8583Utils.YP_GetTag(), null);
                                        return -1;
                                    }
                                }
                                catch (YP_ISO8583Exception yP_ISO8583Exception) {
                                    this.logger(2, "YP_ParseISO8583Message() error??? " + yP_ISO8583Exception);
                                    yP_ISO8583Exception.setFieldId(Integer.toString(n2));
                                    yP_ISO8583Exception.setTlvId(yP_ISO8583Utils.YP_GetTag());
                                    this.myErrorData = yP_ISO8583Exception;
                                    return -1;
                                }
                            }
                        }
                    }
                }
                ++n2;
            }
            if (this.getLogLevel() >= 5) {
                long l5 = System.nanoTime() - l2;
                this.parsingTimeInNano += l5;
                this.logger(5, "YP_ParseISO8583Message() Parsing Timev = " + this.parsingTimeInNano + " " + l5);
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_ParseISO8583Message() error???  " + n2 + " " + exception);
            if (this.getLogLevel() >= 6) {
                this.logger(6, "YP_ParseISO8583Message() " + this.getISO8583log(this.myISO8583ReceiveMessage.iso8583Message, null, true, this.getLogLevel() < 5));
            } else {
                this.logger(4, "YP_ParseISO8583Message() " + this.getISO8583log(this.myISO8583ReceiveMessage.iso8583Message, null, false, this.getLogLevel() < 5));
            }
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, "YP_ParseISO8583Message() " + this.getISO8583log(this.myISO8583ReceiveMessage.iso8583Message, null, true, this.getLogLevel() < 5));
            return 1;
        }
        if (this.getLogLevel() == 4 && this.messageTypeIndicator != null && this.messageTypeIndicator.contentEquals("0360")) {
            this.logger(4, "YP_ParseISO8583Message() 0360 not logged");
            return 1;
        }
        this.logger(4, "YP_ParseISO8583Message() " + this.getISO8583log(this.myISO8583ReceiveMessage.iso8583Message, null, false, this.getLogLevel() < 5));
        return 1;
    }

    public void YP_SetMessageTypeIndicator(String string) {
        this.messageTypeIndicator = string;
    }

    public String YP_GetMessageTypeIndicator() {
        return this.messageTypeIndicator;
    }

    private boolean checkIfEquals(String string, String string2, YP_ISO8583Utils.DataFormat dataFormat) {
        int n = string.length() - string2.length();
        if (n == 0) {
            return string.contentEquals(string2);
        }
        String string3 = string;
        String string4 = string2;
        switch (dataFormat) {
            case NUMERIC: {
                if (n > 0) {
                    char[] cArray = new char[n];
                    Arrays.fill(cArray, '0');
                    string4 = String.valueOf(new String(cArray)) + string4;
                    break;
                }
                char[] cArray = new char[n *= -1];
                Arrays.fill(cArray, '0');
                string3 = String.valueOf(new String(cArray)) + string3;
                break;
            }
            case ALPHA: 
            case ALPHANUM: {
                if (n > 0) {
                    char[] cArray = new char[n];
                    Arrays.fill(cArray, ' ');
                    string4 = String.valueOf(string4) + new String(cArray);
                    break;
                }
                char[] cArray = new char[n *= -1];
                Arrays.fill(cArray, ' ');
                string3 = String.valueOf(string3) + new String(cArray);
                break;
            }
            case ALPHANUM_EBCDIC: {
                this.logger(2, "checkIfEquals()TODO");
                if (n > 0) {
                    char[] cArray = new char[n];
                    Arrays.fill(cArray, ' ');
                    string4 = String.valueOf(string4) + new String(cArray);
                    break;
                }
                char[] cArray = new char[n *= -1];
                Arrays.fill(cArray, ' ');
                string3 = String.valueOf(string3) + new String(cArray);
                break;
            }
            default: {
                this.logger(3, "checkIfEquals() not equals :" + string3 + " vs " + string4 + " for unknown format :" + dataFormat.toString());
                return false;
            }
        }
        if (string3.contentEquals(string4)) {
            return true;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "checkIfEquals() not equals :" + string3 + " vs " + string4 + " for format :" + dataFormat.toString());
        }
        return false;
    }

    private List<String> YP_GetTlvStructEltByName(ISO8583Message iSO8583Message, int n, String string, String string2) {
        ISO8583TLVElement iSO8583TLVElement;
        block4: {
            iSO8583TLVElement = this.YP_GetTlvByName(iSO8583Message, n, string);
            if (iSO8583TLVElement != null) break block4;
            this.logger(2, "YP_GetTlvStructEltByName() myReqTLV == null");
            return null;
        }
        try {
            for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
                if (!iSO8583TLVStructure.getName().contentEquals(string2)) continue;
                return iSO8583TLVStructure.getTLVStructureValue();
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_GetTlvStructEltByName()" + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
        return null;
    }

    private static ISO8583TLVElement getISO8583TLVElementByName(ISO8583Field iSO8583Field, String string) {
        List<ISO8583TLVElement> list = iSO8583Field.getTlv();
        for (ISO8583TLVElement iSO8583TLVElement : list) {
            if (!iSO8583TLVElement.getName().contentEquals(string)) continue;
            return iSO8583TLVElement;
        }
        return null;
    }

    private ISO8583TLVElement YP_GetTlvByName(ISO8583Message iSO8583Message, int n, String string) {
        try {
            ISO8583Field iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
            if (iSO8583Field != null) {
                return YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_GetTlvByName()" + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
        return null;
    }

    private boolean YP_CheckTLV(ISO8583Message iSO8583Message, ISO8583Message iSO8583Message2, int n, String string, String string2) {
        try {
            return this.YP_CheckTLV(this.YP_GetTlvByName(iSO8583Message, n, string), iSO8583Message2, n, string, string2);
        }
        catch (Exception exception) {
            this.logger(2, "YP_CheckTLV()  " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean YP_CheckTLV(ISO8583TLVElement iSO8583TLVElement, ISO8583Message iSO8583Message, int n, String string, String string2) {
        try {
            List<String> list;
            List<String> list2;
            if (iSO8583TLVElement == null) {
                if (string2.contains("R")) {
                    this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but not found");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), string, null);
                    return false;
                }
                return true;
            }
            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
            if (fieldFormat != YP_ISO8583Utils.FieldFormat.structure) {
                YP_ISO8583Utils.DataFormat dataFormat;
                String string3;
                List<String> list3;
                ISO8583TLVElement iSO8583TLVElement2;
                List<String> list4 = iSO8583TLVElement.getTLVValue();
                if (list4 == null || list4.isEmpty()) {
                    if (string2.contains("R")) {
                        this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but missing");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), string, null);
                        return false;
                    }
                    return true;
                }
                String string4 = list4.get(0);
                if (string4 == null || string4.isEmpty()) {
                    if (string2.contains("R")) {
                        this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but really missing");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), string, null);
                        return false;
                    }
                    return true;
                }
                if (iSO8583Message == null) {
                    return true;
                }
                if (string2.contains("=") && (iSO8583TLVElement2 = this.YP_GetTlvByName(iSO8583Message, n, string)) != null && (list3 = iSO8583TLVElement2.getTLVValue()) != null && !list3.isEmpty() && (string3 = list3.get(0)) != null && !string3.isEmpty() && !this.checkIfEquals(string3, string4, dataFormat = YP_ISO8583Utils.getMyDataFormat(iSO8583TLVElement.getFormat()))) {
                    this.logger(2, "YP_CheckTLV()  Field TLV" + n + string + ": Response field: " + string4 + " different from request field: " + string3);
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.wrongEqualityField, Integer.toString(n), string, null);
                    return false;
                }
                return true;
            }
            if (string2.contains("R")) {
                boolean bl = false;
                for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
                    list2 = iSO8583TLVStructure.getTLVStructureValue();
                    if (list2 == null || list2.isEmpty() || (list = list2.get(0)) == null || ((String)((Object)list)).length() <= 0) continue;
                    bl = true;
                    break;
                }
                if (!bl) {
                    this.logger(2, "YP_CheckTLV()  Element R mais aucune valeure presente ");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), string, null);
                    return false;
                }
            }
            if (iSO8583Message == null) {
                return true;
            }
            if (string2.contains("=")) {
                for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
                    String string5 = iSO8583TLVStructure.getName();
                    list2 = this.YP_GetTlvStructEltByName(iSO8583Message, n, string, string5);
                    if (list2 == null) {
                        return true;
                    }
                    list = iSO8583TLVStructure.getTLVStructureValue();
                    if (list == null || list.size() != list2.size()) {
                        this.logger(2, "YP_CheckTLV() Field " + n + "TLV " + string + "Struct value " + (String)string5 + "resp diff form request");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.wrongEqualityField, Integer.toString(n), string, null);
                        return false;
                    }
                    int n2 = 0;
                    while (n2 < list2.size()) {
                        if (!((String)list.get(n2)).contentEquals(list2.get(n2))) {
                            this.logger(2, "YP_CheckTLV() Field " + n + "TLV " + string + "Struct value " + (String)string5 + "resp diff form request");
                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.wrongEqualityField, Integer.toString(n), string, null);
                            return false;
                        }
                        ++n2;
                    }
                }
            }
            return true;
        }
        catch (Exception exception) {
            this.logger(2, "YP_CheckTLV()  " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean YP_PrepareTLVResponse(int n, String string) {
        try {
            ISO8583TLVElement iSO8583TLVElement = this.YP_GetTlvByName(this.myISO8583ReceiveMessage.iso8583Message, n, string);
            if (iSO8583TLVElement == null) {
                return false;
            }
            ISO8583TLVElement iSO8583TLVElement2 = this.YP_GetTlvByName(this.myISO8583SendMessage.iso8583Message, n, string);
            if (iSO8583TLVElement2 == null) {
                return false;
            }
            YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583TLVElement.getLengthType());
            if (fieldFormat != YP_ISO8583Utils.FieldFormat.structure) {
                if (!iSO8583TLVElement.getTLVValue().isEmpty() && iSO8583TLVElement.getTLVValue().get(0).length() > 0) {
                    iSO8583TLVElement2.getTLVValue().add(iSO8583TLVElement.getTLVValue().get(0));
                    return true;
                }
                return false;
            }
            Iterator<ISO8583TLVStructure> iterator = iSO8583TLVElement2.getTLVStructureElt().iterator();
            block2: while (true) {
                if (!iterator.hasNext()) {
                    return true;
                }
                ISO8583TLVStructure iSO8583TLVStructure = iterator.next();
                List<String> list = this.YP_GetTlvStructEltByName(this.myISO8583SendMessage.iso8583Message, n, string, iSO8583TLVStructure.getName());
                if (list == null || list.isEmpty()) {
                    return false;
                }
                Iterator<String> iterator2 = list.iterator();
                while (true) {
                    if (!iterator2.hasNext()) continue block2;
                    String string2 = iterator2.next();
                    iSO8583TLVStructure.getTLVStructureValue().add(string2);
                }
                break;
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_CheckTLV()  " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
    }

    public boolean YP_CheckField(ISO8583Message iSO8583Message, ISO8583FieldPresence iSO8583FieldPresence, ISO8583Message iSO8583Message2, int n) {
        block17: {
            YP_ISO8583Utils.DataFormat dataFormat;
            ISO8583Field iSO8583Field;
            String string;
            ISO8583Field iSO8583Field2;
            block21: {
                block20: {
                    block18: {
                        block19: {
                            block16: {
                                block15: {
                                    if (iSO8583FieldPresence != null) break block15;
                                    return true;
                                }
                                iSO8583Field2 = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
                                if (iSO8583Field2 != null) break block16;
                                if (iSO8583FieldPresence.getPresence().contains("R")) {
                                    this.logger(2, "YP_CheckField : mandatory field " + n + " missing");
                                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), null, null);
                                    return false;
                                }
                                return true;
                            }
                            try {
                                YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field2.getFieldLengthType());
                                if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) {
                                    if (fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_zc) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLV_b) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.BER_TLV) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_b) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLV_a)) {
                                        for (ISO8583TLVPresence iSO8583TLVPresence : iSO8583FieldPresence.getTlv()) {
                                            String string2 = iSO8583TLVPresence.getPresence();
                                            if (string2.contains("R")) {
                                                this.YP_CheckTLV(iSO8583Message, iSO8583Message2, n, iSO8583TLVPresence.getName(), string2);
                                                continue;
                                            }
                                            if (!string2.contains("=") || iSO8583Message2 == null) continue;
                                            this.YP_CheckTLV(iSO8583Message, iSO8583Message2, n, iSO8583TLVPresence.getName(), string2);
                                        }
                                    } else {
                                        this.logger(2, "YP_CheckField : just for a debug log");
                                    }
                                    break block17;
                                }
                                string = iSO8583Field2.getFieldValue();
                                if (!iSO8583FieldPresence.getPresence().contains("R")) break block18;
                                if (string != null) break block19;
                                this.logger(2, "YP_CheckField : mandatory field " + n + " null value");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), null, null);
                                return false;
                            }
                            catch (Exception exception) {
                                this.logger(2, "YP_CheckField() " + exception);
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, Integer.toString(n), null, null);
                                return false;
                            }
                        }
                        if (!string.isEmpty()) break block18;
                        this.logger(2, "YP_CheckField : mandatory field " + n + " empty");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), null, null);
                        return false;
                    }
                    if (!iSO8583FieldPresence.getPresence().contains("=")) break block17;
                    if (iSO8583Message2 != null) break block20;
                    return true;
                }
                if (string == null) break block17;
                iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583SendMessage.iso8583Message, n);
                if (iSO8583Field != null) break block21;
                this.logger(2, "YP_CheckField() Field " + n + " is set and = but not present in request ");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, Integer.toString(n), null, null);
                return false;
            }
            String string3 = iSO8583Field.getFieldValue();
            if (string3 != null && !this.checkIfEquals(string3, string, dataFormat = YP_ISO8583Utils.getMyDataFormat(iSO8583Field2.getFieldFormat()))) {
                this.logger(2, "YP_CheckField() Field " + n + ": Response field: " + string + " different from request field: " + string3);
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.wrongEqualityField, Integer.toString(n), null, null);
                return false;
            }
        }
        return true;
    }

    public boolean YP_PrepareFieldResponse(int n) {
        YP_ISO8583Utils.FieldFormat fieldFormat;
        ISO8583FieldPresence iSO8583FieldPresence;
        block10: {
            String string;
            ISO8583Field iSO8583Field;
            ISO8583Field iSO8583Field2;
            block9: {
                block8: {
                    iSO8583FieldPresence = YP_TCD_PROT_ISO8583.getFieldTypePresence(this.myISO8583SendPresence, n);
                    if (iSO8583FieldPresence != null) break block8;
                    return true;
                }
                iSO8583Field2 = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583SendMessage.iso8583Message, n);
                if (iSO8583Field2 != null || !iSO8583FieldPresence.getPresence().contains("R")) break block9;
                this.logger(2, "YP_PrepareFieldResponse : mandatory field " + n + " missing");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.fieldMissing, Integer.toString(n), null, null);
                return false;
            }
            fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field2.getFieldLengthType());
            if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block10;
            if (iSO8583FieldPresence.getPresence().contentEquals("R=") && (iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583ReceiveMessage.iso8583Message, n)) != null && (string = iSO8583Field.getFieldValue()) != null && !string.isEmpty()) {
                iSO8583Field2.setFieldValue(string);
                return true;
            }
        }
        try {
            if (fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_c) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_zc) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLV_b) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.BER_TLV) || fieldFormat.equals((Object)YP_ISO8583Utils.FieldFormat.TTLLV_b)) {
                for (ISO8583TLVPresence iSO8583TLVPresence : iSO8583FieldPresence.getTlv()) {
                    if (!iSO8583TLVPresence.getPresence().contentEquals("R=")) continue;
                    this.YP_PrepareTLVResponse(n, iSO8583TLVPresence.getName());
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_PrepareFieldResponse() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, Integer.toString(n), null, null);
            return false;
        }
        return true;
    }

    public List<String> getStructureElementName(int n, String string) {
        ISO8583TLVElement iSO8583TLVElement;
        ArrayList<String> arrayList;
        block14: {
            ISO8583Field iSO8583Field;
            block13: {
                YP_ISO8583Utils.FieldFormat fieldFormat;
                block12: {
                    block11: {
                        block10: {
                            block9: {
                                arrayList = new ArrayList<String>();
                                if (n > 0 && n <= 128) break block9;
                                this.logger(2, "getStructureElementName() FieldNumber out of range");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return null;
                            }
                            iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583SendMessage.iso8583Message, n);
                            if (iSO8583Field != null) break block10;
                            this.logger(2, "getStructureElementName() pb with dataField");
                            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                            return null;
                        }
                        fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                        if (fieldFormat != null) break block11;
                        this.logger(2, "getStructureElementName() pb with fieldFormat");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return null;
                    }
                    if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block12;
                    this.logger(2, "getStructureElementName() It's not a tlv field...");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return null;
                }
                if (fieldFormat == YP_ISO8583Utils.FieldFormat.structure) break block13;
                this.logger(2, "getStructureElementName() It's not a tlv structure field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return null;
            }
            iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
            if (iSO8583TLVElement != null) break block14;
            this.logger(2, "getStructureElementName() TLV Name not found:" + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return null;
        }
        try {
            for (ISO8583TLVStructure iSO8583TLVStructure : iSO8583TLVElement.getTLVStructureElt()) {
                arrayList.add(iSO8583TLVStructure.getName());
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getStructureElementName() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return null;
        }
    }

    public int getFieldLength(int n, String string) {
        ISO8583TLVElement iSO8583TLVElement;
        block11: {
            ISO8583Field iSO8583Field;
            block10: {
                YP_ISO8583Utils.FieldFormat fieldFormat;
                block9: {
                    block8: {
                        block7: {
                            try {
                                if (n > 0 && n <= 128) break block7;
                                this.logger(2, "getFieldLength() FieldNumber out of range");
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return 0;
                            }
                            catch (Exception exception) {
                                this.logger(2, "getFieldLength() " + exception);
                                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                                return 0;
                            }
                        }
                        iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(this.myISO8583SendMessage.iso8583Message, n);
                        if (iSO8583Field != null) break block8;
                        this.logger(2, "getFieldLength() pb with dataField");
                        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                        return 0;
                    }
                    fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
                    if (fieldFormat != null) break block9;
                    this.logger(2, "getFieldLength() pb with fieldFormat");
                    this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                    return 0;
                }
                if (YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) break block10;
                this.logger(2, "getFieldLength() It's not a tlv field...");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return 0;
            }
            iSO8583TLVElement = YP_TCD_PROT_ISO8583.getISO8583TLVElementByName(iSO8583Field, string);
            if (iSO8583TLVElement != null) break block11;
            this.logger(2, "getFieldLength() TLV Name not found:" + string);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return 0;
        }
        return iSO8583TLVElement.getLength() + 2 + 2;
    }

    public boolean checkMessageReceived() {
        String string;
        boolean bl;
        long l = System.currentTimeMillis();
        boolean bl2 = true;
        ISO8583Message iSO8583Message = null;
        if (this.myISO8583ReceivePresence == null) {
            this.logger(2, "checkMessageReceived() Pb State machine receivePresence");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
        ISO8583MessageInfo iSO8583MessageInfo = this.myISO8583ReceivePresence.getInfo();
        if (iSO8583MessageInfo == null) {
            this.logger(2, "checkMessageReceived() Pb State machine messageInfo");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
        ISO8583MessageDirection iSO8583MessageDirection = iSO8583MessageInfo.getMessageDirection();
        if (iSO8583MessageDirection == null) {
            this.logger(2, "checkMessageReceived() Pb State machine messageDirection");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
        switch (iSO8583MessageDirection) {
            case REQUEST: {
                bl = true;
                break;
            }
            case RESPONSE: {
                bl = false;
                break;
            }
            default: {
                this.logger(2, "checkMessageReceived() Pb State machine messageDirection value");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return false;
            }
        }
        if (!(bl || (string = this.myISO8583SendPresence.getInfo().getResponseVerificationLevel()) == null || string.isEmpty() || string.contentEquals("0") || string.contentEquals("1"))) {
            if (string.contentEquals("2")) {
                iSO8583Message = this.myISO8583SendMessage.iso8583Message;
            } else if (string.contentEquals("3")) {
                iSO8583Message = this.myISO8583SendMessage.iso8583Message;
            } else {
                this.logger(3, "checkMessageReceived() unknown value for responseVerificationLevel :" + string);
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "checkMessageReceived() " + this.myISO8583ReceivePresence.getInfo().getMessageName() + "  MTI: " + this.myISO8583ReceivePresence.getInfo().getMessageType());
        }
        int n = 2;
        while (n < 129) {
            if (!this.YP_CheckField(this.myISO8583ReceiveMessage.iso8583Message, YP_TCD_PROT_ISO8583.getFieldTypePresence(this.myISO8583ReceivePresence, n), iSO8583Message, n)) {
                bl2 = false;
            }
            ++n;
        }
        if (this.getLogLevel() >= 5) {
            long l2 = System.currentTimeMillis();
            this.logger(5, "checkMessageReceived() Checkin Time = " + (l2 - l));
        }
        return bl2;
    }

    public boolean YP_PrepareResponseMessage() {
        long l = System.currentTimeMillis();
        boolean bl = true;
        this.emptyISO8583Message(this.myISO8583SendMessage.iso8583Message);
        if (this.myISO8583ReceivePresence.getInfo().getMessageDirection() == ISO8583MessageDirection.RESPONSE) {
            this.logger(2, "YP_PrepareResponseMessage() receive message is not a request");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return false;
        }
        int n = 2;
        while (n < 129) {
            if (!this.YP_PrepareFieldResponse(n)) {
                bl = false;
            }
            ++n;
        }
        if (this.getLogLevel() >= 5) {
            long l2 = System.currentTimeMillis();
            this.logger(5, "YP_PrepareResponseMessage() Checkin Time = " + (l2 - l));
        }
        return bl;
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public String toString() {
        return "ISO8583";
    }

    public int YP_WaitConnection() {
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_WaitConnection()");
        }
        if (this.myState == ISO8583StateMachine.CONNECTED) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_WaitConnection() Connected");
            }
            return 1;
        }
        if (this.myState != ISO8583StateMachine.DISCONNECTED) {
            this.logger(2, "YP_WaitConnection() Pb State machine");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        this.myState = ISO8583StateMachine.WAIT_CONNECTION;
        int n = this.getIPDULayer().waitConnection();
        if (n == 1) {
            this.myState = ISO8583StateMachine.CONNECTED;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_WaitConnection() Connected");
            }
            return 1;
        }
        this.logger(2, "YP_WaitConnection() Connection closed ? before anything have been received ");
        return -1;
    }

    public int connect(YP_Row yP_Row) {
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "connect() Start Connection");
        }
        if (this.myState == ISO8583StateMachine.CONNECTED) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "connect() Connected");
            }
            return 1;
        }
        if (this.myState != ISO8583StateMachine.DISCONNECTED) {
            this.logger(2, "connect() Pb state machine");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        if (this.getIPDULayer().connect(yP_Row) < 0) {
            this.logger(2, "connect() IPDU lost connection?");
            return -1;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "connect() Connected transmitter");
        }
        this.myState = ISO8583StateMachine.CONNECTED;
        return 1;
    }

    public int send(boolean bl) {
        block6: {
            if (this.apduBuffer != null && this.apduBuffer.length > 0) break block6;
            this.logger(2, "formatAndSend() Pb data missing");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -1;
        }
        try {
            this.getIPDULayer().send(this.apduBuffer, bl);
        }
        catch (YP_PROT_Interface_Com.TimeOutException timeOutException) {
            this.logger(2, "formatAndSend() Timer expiration" + timeOutException.timerName);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.timeOut, null, null, timeOutException.timerName);
            return 0;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException disconnectionException) {
            this.logger(2, "formatAndSend() Pb IPDU connection lost");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -3;
        }
        catch (Exception exception) {
            this.logger(2, "formatAndSend() " + exception);
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "formatAndSend() message sent");
        }
        return 1;
    }

    public int formatAndSend(YP_PROT_Interface_Prot yP_PROT_Interface_Prot) {
        boolean bl;
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "formatAndSend()");
        }
        if (this.myState != ISO8583StateMachine.CONNECTED) {
            this.logger(2, "formatAndSend() Pb State machine");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        if (this.myISO8583SendPresence == null) {
            this.logger(2, "formatAndSend() Pb State machine sendPresence");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        ISO8583MessageInfo iSO8583MessageInfo = this.myISO8583SendPresence.getInfo();
        if (iSO8583MessageInfo == null) {
            this.logger(2, "formatAndSend() Pb State machine messageInfo");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        ISO8583MessageDirection iSO8583MessageDirection = iSO8583MessageInfo.getMessageDirection();
        if (iSO8583MessageDirection == null) {
            this.logger(2, "formatAndSend() Pb State machine messageDirection");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        switch (iSO8583MessageDirection) {
            case REQUEST: {
                bl = true;
                break;
            }
            case RESPONSE: {
                bl = false;
                break;
            }
            default: {
                this.logger(2, "formatAndSend() Pb State machine messageDirection value");
                this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                return -2;
            }
        }
        if (this.YP_FormatISO8583Message(bl) < 0) {
            this.logger(2, "formatAndSend() Pb Format ISO8583 message");
            return -1;
        }
        if (yP_PROT_Interface_Prot != null) {
            byte[] byArray = yP_PROT_Interface_Prot.extraAPDUFormat(this, this.myISO8583SendMessage.iso8583Message, this.getApduBuffer());
            if (byArray == null) {
                this.logger(2, "formatAndSend() Pb extra apdu Format");
            } else {
                this.setApduBuffer(byArray);
            }
        }
        return this.send(bl);
    }

    public int YP_Disconnect() {
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.myState == ISO8583StateMachine.DISCONNECTED) {
            return 0;
        }
        this.getIPDULayer().disconnect();
        this.myState = ISO8583StateMachine.DISCONNECTED;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_Disconnect()");
        }
        return 1;
    }

    public int YP_WaitDisconnection() {
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.myState == ISO8583StateMachine.DISCONNECTED) {
            return 0;
        }
        this.getIPDULayer().waitDisconnection();
        this.myState = ISO8583StateMachine.DISCONNECTED;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_WaitDisconnection()");
        }
        return 1;
    }

    /*
     * Unable to fully structure code
     */
    public int receiveAndParse(boolean var1_1, YP_PROT_Interface_Prot var2_2) {
        this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "receiveAndParse()");
        }
        if (this.myState != ISO8583StateMachine.CONNECTED) {
            this.logger(2, "receiveAndParse() Pb State machine");
            this.myErrorData = new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            return -2;
        }
        try {
            this.setApduBuffer(this.getIPDULayer().receive(var1_1));
        }
        catch (YP_PROT_Interface_Com.TimeOutException var3_3) {
            this.logger(2, "receiveAndParse() Timer expiration" + var3_3.timerName);
            return 0;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException v0) {
            var3_4 = this.getIPDULayer().getParameter("STATUT");
            if (var3_4 != null && var3_4.contentEquals(YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED.toString())) {
                this.logger(4, "receiveAndParse() Connection closed by peer");
                return -4;
            }
            var4_5 = new Throwable().getStackTrace();
            var5_6 = 0;
            ** while (var5_6 < var4_5.length)
        }
lbl-1000:
        // 1 sources

        {
            if (var4_5[var5_6].getMethodName().contentEquals("YP_WaitRequest")) {
                this.logger(4, "receiveAndParse() Pb IPDU connection lost?");
                return -3;
            }
            ++var5_6;
            continue;
        }
lbl32:
        // 1 sources

        this.logger(2, "receiveAndParse() Pb IPDU connection lost?");
        return -3;
        catch (YP_PROT_Interface_Com.BadFormatException v1) {
            this.logger(2, "receiveAndParse() BadFormatException !");
            return -3;
        }
        if (this.getApduBuffer() == null) {
            this.logger(2, "receiveAndParse() Pb context no data received");
            return -3;
        }
        if (this.getApduBuffer().length == 0) {
            this.logger(2, "receiveAndParse() Nothing received");
            return 0;
        }
        if (this.YP_ParseISO8583Message(this.getApduBuffer()) < 0) {
            this.logger(2, "receiveAndParse() Pb parsing ISO8583 message");
            return -1;
        }
        if (!var2_2.extraAPDUCheck(this, this.myISO8583ReceiveMessage.iso8583Message, this.getApduBuffer())) {
            this.logger(2, "receiveAndParse() Pb apdu check");
            return -1;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "receiveAndParse() message received");
        }
        return 1;
    }

    private static void logOneField(StringBuilder stringBuilder, ISO8583Presence iSO8583Presence, ISO8583Field iSO8583Field, int n, boolean bl, boolean bl2) {
        if (iSO8583Field == null) {
            return;
        }
        ISO8583FieldPresence iSO8583FieldPresence = null;
        boolean bl3 = true;
        if (iSO8583Presence != null) {
            iSO8583FieldPresence = YP_TCD_PROT_ISO8583.getFieldTypePresence(iSO8583Presence, n);
            if (iSO8583FieldPresence == null) {
                bl3 = false;
            } else if (iSO8583FieldPresence.getPresence() == null) {
                bl3 = false;
            }
        }
        String string = iSO8583Field.getFieldValue();
        if (bl && string != null && string.length() == 0) {
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   [");
            if (n < 10) {
                stringBuilder.append("00");
            } else if (n < 100) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n);
            stringBuilder.append("]");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
        }
        if (string != null && string.length() != 0) {
            boolean bl4 = true;
            if (iSO8583Presence != null) {
                if (bl3) {
                    if (!bl2) {
                        stringBuilder.append("   >>>   ");
                    }
                } else if (bl) {
                    if (!bl2) {
                        stringBuilder.append("   XXX   ");
                    }
                } else {
                    bl4 = false;
                }
            } else if (!bl2) {
                stringBuilder.append("   <<<   ");
            }
            if (bl4) {
                String string2;
                CharSequence charSequence;
                stringBuilder.append("[");
                if (n < 10) {
                    stringBuilder.append("00");
                } else if (n < 100) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(n);
                stringBuilder.append("]:[");
                if (!bl) {
                    ISO8583FieldTraceType iSO8583FieldTraceType = iSO8583Field.getFieldTrace();
                    switch (iSO8583FieldTraceType) {
                        case CVV_MASK: 
                        case END_OF_VALIDITY_MASK: {
                            charSequence = new StringBuilder(string.length());
                            int n2 = 0;
                            while (n2 < string.length()) {
                                charSequence.append('#');
                                ++n2;
                            }
                            string = charSequence.toString();
                            break;
                        }
                        case ISO_1_MASK: {
                            string = UtilsYP.maskISO1Track(string);
                            break;
                        }
                        case ISO_2_MASK: 
                        case ISO_3_MASK: {
                            string = UtilsYP.maskISOTrack(string);
                            break;
                        }
                        case PAN_MASK: {
                            string = UtilsYP.maskPAN(string);
                            break;
                        }
                        case PIN_BLOCK_MASK: {
                            string = UtilsYP.maskPinBlock(string);
                            break;
                        }
                    }
                }
                if (n == 48) {
                    int n3 = string.indexOf("P92003");
                    if (n3 == -1) {
                        stringBuilder.append(string);
                    } else {
                        stringBuilder.append(string.replaceFirst("P92003[0-9][0-9][0-9]", "P92003###"));
                    }
                } else if (n == 72) {
                    if ((string.startsWith("1100") || string.startsWith("1220")) && string.length() > 50) {
                        int n4 = string.indexOf(42);
                        if (n4 > 16 && n4 < 36) {
                            charSequence = string.substring(16, n4);
                            stringBuilder.append(string.replaceFirst((String)charSequence, UtilsYP.maskPAN((String)charSequence)));
                        } else {
                            stringBuilder.append(string.substring(14));
                        }
                    } else {
                        stringBuilder.append(string);
                    }
                } else {
                    stringBuilder.append(string);
                }
                stringBuilder.append("]");
                if (!bl2 && (string2 = iSO8583Field.getFieldWording()) != null) {
                    stringBuilder.append(" \"");
                    stringBuilder.append(string2);
                    stringBuilder.append("\"");
                }
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            return;
        }
        List<ISO8583TLVElement> list = iSO8583Field.getTlv();
        if (list == null || list.isEmpty()) {
            return;
        }
        boolean bl5 = false;
        for (ISO8583TLVElement iSO8583TLVElement : list) {
            List<ISO8583TLVStructure> list2;
            int n5;
            List<String> list4 = iSO8583TLVElement.getTLVValue();
            String string3 = iSO8583TLVElement.getName();
            if (list4 != null && !list4.isEmpty()) {
                boolean bl6 = false;
                for (String string4 : list4) {
                    if (string4 == null || string4.isEmpty()) continue;
                    bl6 = true;
                }
                if (bl6) {
                    for (String string4 : list4) {
                        String string2;
                        if (!bl5) {
                            n5 = 1;
                            bl5 = true;
                            if (iSO8583Presence != null) {
                                if (bl3) {
                                    if (!bl2) {
                                        stringBuilder.append("   >>>   ");
                                    }
                                } else if (bl) {
                                    if (!bl2) {
                                        stringBuilder.append("   XXX   ");
                                    }
                                } else {
                                    n5 = 0;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (n5 != 0) {
                                String string5;
                                stringBuilder.append("[");
                                if (n < 10) {
                                    stringBuilder.append("00");
                                } else if (n < 100) {
                                    stringBuilder.append('0');
                                }
                                stringBuilder.append(n);
                                stringBuilder.append("]");
                                if (!bl2 && (string5 = iSO8583Field.getFieldWording()) != null) {
                                    stringBuilder.append(": \"");
                                    stringBuilder.append(string5);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                        stringBuilder.append(UtilsYP.lineSeparator);
                        n5 = 1;
                        if (iSO8583Presence != null) {
                            if (bl3) {
                                List<ISO8583TLVPresence> list3 = iSO8583FieldPresence.getTlv();
                                if (list3 == null || list3.isEmpty()) {
                                    if (bl) {
                                        if (!bl2) {
                                            stringBuilder.append("   XXX   ");
                                        }
                                    } else {
                                        n5 = 0;
                                    }
                                } else {
                                    boolean bl4 = false;
                                    for (List<String> list5 : list3) {
                                        if (!string3.contentEquals(((ISO8583TLVPresence)((Object)list5)).getName())) continue;
                                        if (((ISO8583TLVPresence)((Object)list5)).getPresence() != null) {
                                            if (!bl2) {
                                                stringBuilder.append("   >>>   ");
                                            }
                                            bl4 = true;
                                            break;
                                        }
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            n5 = 0;
                                        }
                                        bl4 = true;
                                        break;
                                    }
                                    if (!bl4) {
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            n5 = 0;
                                        }
                                    }
                                }
                            } else if (bl) {
                                if (!bl2) {
                                    stringBuilder.append("   XXX   ");
                                }
                            } else {
                                n5 = 0;
                            }
                        } else if (!bl2) {
                            stringBuilder.append("   <<<   ");
                        }
                        if (n5 == 0) continue;
                        if (!bl2) {
                            stringBuilder.append("      ");
                        } else {
                            stringBuilder.append(" ");
                        }
                        stringBuilder.append("(");
                        stringBuilder.append(string3);
                        stringBuilder.append("):");
                        if (string4 == null) {
                            stringBuilder.append("null");
                            continue;
                        }
                        stringBuilder.append("(");
                        if (bl) {
                            stringBuilder.append(string4);
                        } else {
                            ISO8583FieldTraceType iSO8583FieldTraceType = iSO8583TLVElement.getFieldTrace();
                            switch (iSO8583FieldTraceType) {
                                case CVV_MASK: 
                                case END_OF_VALIDITY_MASK: {
                                    StringBuilder stringBuilder2 = new StringBuilder(string4.length());
                                    int n2 = 0;
                                    while (n2 < string4.length()) {
                                        stringBuilder2.append('#');
                                        ++n2;
                                    }
                                    stringBuilder.append(stringBuilder2.toString());
                                    break;
                                }
                                case ISO_1_MASK: 
                                case ISO_2_MASK: 
                                case ISO_3_MASK: {
                                    try {
                                        int n3 = string4.indexOf(68);
                                        if (n3 <= 0 || n3 <= 4) break;
                                        StringBuilder stringBuilder3 = new StringBuilder(string4);
                                        int n4 = 0;
                                        while (n4 < n3 - 4) {
                                            stringBuilder3.setCharAt(n4, '#');
                                            ++n4;
                                        }
                                        n4 = n3 + 1;
                                        while (n4 < string4.length()) {
                                            stringBuilder3.setCharAt(n4, '#');
                                            ++n4;
                                        }
                                        stringBuilder.append((CharSequence)stringBuilder3);
                                    }
                                    catch (Exception exception) {
                                        stringBuilder.append("null");
                                    }
                                    break;
                                }
                                case PAN_MASK: {
                                    stringBuilder.append(UtilsYP.maskPAN(string4));
                                    break;
                                }
                                default: {
                                    stringBuilder.append(string4);
                                }
                            }
                        }
                        stringBuilder.append(")");
                        if (bl2 || (string2 = iSO8583TLVElement.getWording()) == null) continue;
                        stringBuilder.append(" \"");
                        stringBuilder.append(string2);
                        stringBuilder.append("\"");
                    }
                    continue;
                }
            }
            if ((list2 = iSO8583TLVElement.getTLVStructureElt()) == null || list2.isEmpty()) continue;
            boolean bl8 = true;
            int n9 = list2.get(0).getTLVStructureValue().size();
            n5 = 0;
            while (n5 < n9) {
                for (ISO8583TLVStructure iSO8583TLVStructure : list2) {
                    Object object;
                    Object object2;
                    boolean bl6;
                    List<String> list5;
                    list5 = iSO8583TLVStructure.getTLVStructureValue();
                    if (list5 == null || list5.size() <= n5) continue;
                    boolean bl7 = true;
                    String string6 = list5.get(n5);
                    if (string6 != null && string6.length() > 0) {
                        if (!bl5) {
                            bl6 = true;
                            if (iSO8583Presence != null) {
                                if (bl3) {
                                    if (!bl2) {
                                        stringBuilder.append("   >>>   ");
                                    }
                                } else if (bl) {
                                    if (!bl2) {
                                        stringBuilder.append("   XXX   ");
                                    }
                                } else {
                                    bl6 = false;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (bl6) {
                                stringBuilder.append("[");
                                if (n < 10) {
                                    stringBuilder.append("00");
                                } else if (n < 100) {
                                    stringBuilder.append('0');
                                }
                                stringBuilder.append(n);
                                stringBuilder.append("]");
                                if (!bl2 && (object2 = iSO8583Field.getFieldWording()) != null) {
                                    stringBuilder.append(":  \"");
                                    stringBuilder.append((String)object2);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                        if (!bl5 || bl8) {
                            bl6 = true;
                            stringBuilder.append(UtilsYP.lineSeparator);
                            if (iSO8583Presence != null) {
                                if (bl3) {
                                    object2 = iSO8583FieldPresence.getTlv();
                                    if (object2 == null) {
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            bl6 = false;
                                        }
                                        bl7 = false;
                                    } else {
                                        boolean bl9 = false;
                                        object = object2.iterator();
                                        while (object.hasNext()) {
                                            ISO8583TLVPresence iSO8583TLVPresence = object.next();
                                            if (!string3.contentEquals(iSO8583TLVPresence.getName())) continue;
                                            if (iSO8583TLVPresence.getPresence() != null) {
                                                if (!bl2) {
                                                    stringBuilder.append("   >>>   ");
                                                }
                                                bl9 = true;
                                                break;
                                            }
                                            if (bl) {
                                                if (!bl2) {
                                                    stringBuilder.append("   XXX   ");
                                                }
                                            } else {
                                                bl6 = false;
                                            }
                                            bl9 = true;
                                            bl7 = false;
                                            break;
                                        }
                                        if (!bl9) {
                                            if (bl) {
                                                if (!bl2) {
                                                    stringBuilder.append("   XXX   ");
                                                }
                                            } else {
                                                bl6 = false;
                                            }
                                            bl7 = false;
                                        }
                                    }
                                } else {
                                    if (bl) {
                                        if (!bl2) {
                                            stringBuilder.append("   XXX   ");
                                        }
                                    } else {
                                        bl6 = false;
                                    }
                                    bl7 = false;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (bl6) {
                                if (!bl2) {
                                    stringBuilder.append("      ");
                                } else {
                                    stringBuilder.append(" ");
                                }
                                stringBuilder.append("(");
                                stringBuilder.append(string3);
                                stringBuilder.append(")");
                                if (!bl2 && (object2 = iSO8583TLVElement.getWording()) != null) {
                                    stringBuilder.append(":  \"");
                                    stringBuilder.append((String)object2);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                    }
                    stringBuilder.append(UtilsYP.lineSeparator);
                    bl6 = true;
                    if (iSO8583Presence != null) {
                        if (bl7) {
                            if (!bl2) {
                                stringBuilder.append("   >>>   ");
                            }
                        } else if (bl) {
                            if (!bl2) {
                                stringBuilder.append("   XXX   ");
                            }
                        } else {
                            bl6 = false;
                        }
                    } else if (!bl2) {
                        stringBuilder.append("   <<<   ");
                    }
                    if (!bl6) continue;
                    if (!bl2) {
                        stringBuilder.append("               ");
                    } else {
                        stringBuilder.append("  ");
                    }
                    stringBuilder.append("{");
                    if (bl) {
                        stringBuilder.append(string6);
                    } else {
                        object2 = iSO8583TLVStructure.getFieldTrace();
                        switch (YP_TCD_PROT_ISO8583.$SWITCH_TABLE$org$yp$xml$jaxb$iso8583$ISO8583FieldTraceType()[((Enum)object2).ordinal()]) {
                            case 3: 
                            case 4: {
                                StringBuilder stringBuilder4 = new StringBuilder(string6.length());
                                int n6 = 0;
                                while (n6 < string6.length()) {
                                    stringBuilder4.append('#');
                                    ++n6;
                                }
                                stringBuilder.append(stringBuilder4.toString());
                                break;
                            }
                            case 5: 
                            case 6: 
                            case 7: {
                                try {
                                    int n7 = string6.indexOf(68);
                                    if (n7 <= 0 || n7 <= 4) break;
                                    object = new StringBuilder(string6);
                                    int n8 = 0;
                                    while (n8 < n7 - 4) {
                                        ((StringBuilder)object).setCharAt(n8, '#');
                                        ++n8;
                                    }
                                    n8 = n7 + 1;
                                    while (n8 < string6.length()) {
                                        ((StringBuilder)object).setCharAt(n8, '#');
                                        ++n8;
                                    }
                                    stringBuilder.append((CharSequence)object);
                                }
                                catch (Exception exception) {
                                    stringBuilder.append("null");
                                }
                                break;
                            }
                            case 2: {
                                stringBuilder.append(UtilsYP.maskPAN(string6));
                                break;
                            }
                            default: {
                                stringBuilder.append(string6);
                            }
                        }
                    }
                    stringBuilder.append("}:  \"");
                    stringBuilder.append(iSO8583TLVStructure.getName());
                    stringBuilder.append("\"");
                    bl8 = false;
                    bl5 = true;
                }
                ++n5;
            }
        }
        if (bl5) {
            stringBuilder.append(UtilsYP.lineSeparator);
        }
    }

    public String getISO8583log(ISO8583Message iSO8583Message, ISO8583Presence iSO8583Presence, boolean bl, boolean bl2) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(UtilsYP.lineSeparator);
            if (!bl2) {
                if (iSO8583Presence != null) {
                    stringBuilder.append("   >>>   ");
                } else {
                    stringBuilder.append("   <<<   ");
                }
            }
            stringBuilder.append("[000]:[");
            stringBuilder.append(this.YP_GetMessageTypeIndicator());
            stringBuilder.append("]");
            stringBuilder.append(UtilsYP.lineSeparator);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField1(), 1, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField2(), 2, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField3(), 3, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField4(), 4, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField5(), 5, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField6(), 6, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField7(), 7, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField8(), 8, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField9(), 9, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField10(), 10, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField11(), 11, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField12(), 12, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField13(), 13, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField14(), 14, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField15(), 15, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField16(), 16, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField17(), 17, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField18(), 18, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField19(), 19, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField20(), 20, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField21(), 21, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField22(), 22, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField23(), 23, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField24(), 24, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField25(), 25, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField26(), 26, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField27(), 27, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField28(), 28, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField29(), 29, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField30(), 30, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField31(), 31, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField32(), 32, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField33(), 33, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField34(), 34, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField35(), 35, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField36(), 36, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField37(), 37, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField38(), 38, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField39(), 39, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField40(), 40, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField41(), 41, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField42(), 42, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField43(), 43, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField44(), 44, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField45(), 45, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField46(), 46, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField47(), 47, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField48(), 48, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField49(), 49, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField50(), 50, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField51(), 51, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField52(), 52, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField53(), 53, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField54(), 54, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField55(), 55, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField56(), 56, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField57(), 57, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField58(), 58, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField59(), 59, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField60(), 60, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField61(), 61, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField62(), 62, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField63(), 63, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField64(), 64, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField65(), 65, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField66(), 66, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField67(), 67, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField68(), 68, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField69(), 69, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField70(), 70, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField71(), 71, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField72(), 72, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField73(), 73, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField74(), 74, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField75(), 75, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField76(), 76, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField77(), 77, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField78(), 78, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField79(), 79, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField80(), 80, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField81(), 81, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField82(), 82, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField83(), 83, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField84(), 84, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField85(), 85, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField86(), 86, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField87(), 87, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField88(), 88, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField89(), 89, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField90(), 90, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField91(), 91, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField92(), 92, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField93(), 93, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField94(), 94, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField95(), 95, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField96(), 96, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField97(), 97, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField98(), 98, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField99(), 99, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField100(), 100, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField101(), 101, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField102(), 102, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField103(), 103, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField104(), 104, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField105(), 105, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField106(), 106, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField107(), 107, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField108(), 108, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField109(), 109, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField110(), 110, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField111(), 111, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField112(), 112, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField113(), 113, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField114(), 114, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField115(), 115, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField116(), 116, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField117(), 117, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField118(), 118, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField119(), 119, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField120(), 120, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField121(), 121, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField122(), 122, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField123(), 123, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField124(), 124, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField125(), 125, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField126(), 126, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField127(), 127, bl, bl2);
            YP_TCD_PROT_ISO8583.logOneField(stringBuilder, iSO8583Presence, iSO8583Message.getField128(), 128, bl, bl2);
            String string = stringBuilder.toString();
            while (string.indexOf(UtilsYP.doubleLineSeparator) >= 0) {
                string = string.replace(UtilsYP.doubleLineSeparator, UtilsYP.lineSeparator);
            }
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getISO8583log() " + exception);
            return null;
        }
    }

    private static void emptyOneField(ISO8583Field iSO8583Field) {
        if (iSO8583Field == null) {
            return;
        }
        iSO8583Field.setFieldValue(null);
        List<ISO8583TLVElement> list = iSO8583Field.getTlv();
        if (list == null || list.isEmpty()) {
            return;
        }
        for (ISO8583TLVElement iSO8583TLVElement : list) {
            List<String> list2 = iSO8583TLVElement.getTLVValue();
            if (list2 != null && !list2.isEmpty()) {
                list2.clear();
                continue;
            }
            List<ISO8583TLVStructure> list3 = iSO8583TLVElement.getTLVStructureElt();
            if (list3 == null || list3.isEmpty()) continue;
            for (ISO8583TLVStructure iSO8583TLVStructure : list3) {
                List<String> list4 = iSO8583TLVStructure.getTLVStructureValue();
                if (list4 == null || list4.isEmpty()) continue;
                iSO8583TLVStructure.getTLVStructureValue().clear();
            }
        }
    }

    private void emptyISO8583Message(ISO8583Message iSO8583Message) {
        try {
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField1());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField2());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField3());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField4());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField5());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField6());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField7());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField8());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField9());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField10());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField11());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField12());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField13());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField14());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField15());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField16());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField17());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField18());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField19());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField20());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField21());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField22());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField23());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField24());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField25());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField26());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField27());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField28());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField29());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField30());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField31());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField32());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField33());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField34());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField35());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField36());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField37());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField38());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField39());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField40());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField41());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField42());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField43());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField44());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField45());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField46());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField47());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField48());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField49());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField50());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField51());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField52());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField53());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField54());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField55());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField56());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField57());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField58());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField59());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField60());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField61());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField62());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField63());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField64());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField65());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField66());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField67());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField68());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField69());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField70());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField71());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField72());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField73());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField74());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField75());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField76());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField77());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField78());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField79());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField80());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField81());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField82());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField83());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField84());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField85());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField86());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField87());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField88());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField89());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField90());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField91());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField92());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField93());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField94());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField95());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField96());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField97());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField98());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField99());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField100());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField101());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField102());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField103());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField104());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField105());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField106());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField107());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField108());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField109());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField110());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField111());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField112());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField113());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField114());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField115());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField116());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField117());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField118());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField119());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField120());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField121());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField122());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField123());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField124());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField125());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField126());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField127());
            YP_TCD_PROT_ISO8583.emptyOneField(iSO8583Message.getField128());
        }
        catch (Exception exception) {
            this.logger(2, "emptyISO8583Message()  " + exception);
        }
    }

    @Override
    public int shutdown() {
        if (this.myISO8583SendMessage != null) {
            this.myISO8583SendMessage.onUse = 0;
        }
        if (this.myISO8583ReceiveMessage != null) {
            this.myISO8583ReceiveMessage.onUse = 0;
        }
        this.myIpduLayer = null;
        this.parserXML = null;
        return super.shutdown();
    }

    public void setApduBuffer(byte[] byArray) {
        this.apduBuffer = byArray;
    }

    public byte[] getApduBuffer() {
        return this.apduBuffer;
    }

    public YP_PROT_Interface_Com getIPDULayer() {
        return this.myIpduLayer;
    }

    public boolean isSet(ISO8583Message iSO8583Message, int n) {
        if (iSO8583Message == null) {
            this.logger(2, "isSet() myISO8583Data null");
            return false;
        }
        if (n <= 0 || n > 128) {
            this.logger(2, "isSet() FieldNumber out of range ");
            return false;
        }
        ISO8583Field iSO8583Field = YP_TCD_PROT_ISO8583.getMessageField(iSO8583Message, n);
        if (iSO8583Field == null) {
            return false;
        }
        YP_ISO8583Utils.FieldFormat fieldFormat = YP_ISO8583Utils.getMyFieldFormat(iSO8583Field.getFieldLengthType());
        if (fieldFormat == null) {
            this.logger(2, "isSet() pb with fieldFormat");
            return false;
        }
        if (!YP_TCD_PROT_ISO8583.isItATlv(fieldFormat)) {
            String string = iSO8583Field.getFieldValue();
            return string != null && !string.isEmpty();
        }
        if (iSO8583Field.getStructure() != null) {
            this.logger(3, "isSet() TODO");
        } else {
            List<ISO8583TLVElement> list = iSO8583Field.getTlv();
            if (list != null && !list.isEmpty()) {
                for (ISO8583TLVElement iSO8583TLVElement : list) {
                    List<String> list2 = iSO8583TLVElement.getTLVValue();
                    if (list2 != null && !list2.isEmpty()) {
                        return true;
                    }
                    List<ISO8583TLVStructure> list3 = iSO8583TLVElement.getTLVStructureElt();
                    if (list3 == null || list3.isEmpty()) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public String getTlvReceivedOrder() {
        return this.tlvReceivedOrder.toString();
    }

    public void resetTlvReceivedOrder() {
        this.tlvReceivedOrder = new StringBuilder();
    }

    public static enum ISO8583StateMachine {
        DISCONNECTED,
        WAIT_CONNECTION,
        CONNECT,
        CONNECTED,
        WAIT_DISCONNETION;

    }
}

