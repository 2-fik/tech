/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import java.util.Locale;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_3DSecure;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecureAutoStateMachine;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_ThreeDSecureEvent;
import org.yp.utils.CryptoUtils;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.threeds.PAReq;
import org.yp.xml.jaxb.threeds.ThreeDSecure;
import org.yp.xml.jaxb.threeds.VEReq;
import org.yp.xml.jaxb.threeds.VERes;

public class YP_TCD_PROT_ThreeDSecureAuto
extends YP_OnDemandComponent {
    private YP_TCD_PROT_ThreeDSecureAutoStateMachine stateMachineThreeDS;
    private YP_TCD_PROT_ThreeDSecure protocolThreeDS = null;
    private YP_TCD_DCC_Business dataContainerBusiness = null;
    private YP_TCD_DC_Transaction dataContainerTransaction = null;
    private YP_ThreeDSecureEvent eventThreeDS;
    private YP_PROT_Interface_3DSecure protocolEFT;

    public YP_TCD_PROT_ThreeDSecureAuto(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_PROT_ThreeDSecureAutoStateMachine) {
            this.stateMachineThreeDS = (YP_TCD_PROT_ThreeDSecureAutoStateMachine)yP_Object;
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_TCD_DCC_Business) {
                this.dataContainerBusiness = (YP_TCD_DCC_Business)objectArray[0];
            }
            if (objectArray != null && objectArray.length > 1 && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                this.dataContainerTransaction = (YP_TCD_DC_Transaction)objectArray[1];
            }
            if (objectArray != null && objectArray.length > 2 && objectArray[2] instanceof YP_TCD_PROT_ThreeDSecure) {
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)objectArray[2];
            }
            if (objectArray != null && objectArray.length > 3 && objectArray[3] instanceof YP_ThreeDSecureEvent) {
                this.eventThreeDS = (YP_ThreeDSecureEvent)objectArray[3];
            }
            if (objectArray != null && objectArray.length > 4 && objectArray[4] instanceof YP_PROT_Interface_3DSecure) {
                this.protocolEFT = (YP_PROT_Interface_3DSecure)objectArray[4];
            }
        }
    }

    @Override
    public String toString() {
        return "THREEDSECURE_AUTO";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public void YP_ThreeDSAutoPrepareRequest() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        if (this.stateMachineThreeDS.getServiceRequested() != YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto) {
            this.logger(2, "YP_ThreeDSAutoPrepareRequest() bad service requested : " + (Object)((Object)this.stateMachineThreeDS.getServiceRequested()));
            return;
        }
        this.protocolThreeDS.YP_GetNewSendFactoryObject("/technics/xml/threeds/vereq.xml");
        this.stateMachineThreeDS.getProtocolInterface().transactionDatasToObjectFactory(this.protocolThreeDS, this.stateMachineThreeDS.getServiceRequested());
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
    }

    public void YP_ThreeDSAutoConnect() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        YP_PROT_Interface_Prot.ConnectionParameters connectionParameters = this.stateMachineThreeDS.getProtocolInterface().getConnectionParameters(this.stateMachineThreeDS.getServiceRequested(), this.dataContainerTransaction.getCurrentTry(), true);
        if (connectionParameters == null) {
            this.logger(2, "YP_ThreeDSAutoConnect() unable to get connection parameters");
            return;
        }
        try {
            YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
            YP_Row yP_Row = (YP_Row)yP_Service.dealRequest(this, "getConnectionRow", "", connectionParameters.ip, connectionParameters.port, connectionParameters.ert);
            if (yP_Row == null) {
                this.logger(2, "YP_ThreeDSAutoConnect() unable to find connection row");
                return;
            }
            if (this.protocolThreeDS.connect(yP_Row) != 1) {
                this.logger(2, "YP_ThreeDSAutoConnect() connection error");
                return;
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_ThreeDSAutoConnect() " + exception);
            return;
        }
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
    }

    public void YP_ThreeDSAutoProcess() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        switch (this.protocolThreeDS.YP_Send()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSAutoProcess() message sent");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSAutoProcess() Nothing has been sent ( a timeout has expired) ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSAutoProcess() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSAutoProcess() unknown status");
                return;
            }
        }
        switch (this.protocolThreeDS.YP_Receive()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSAutoProcess() message received");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSAutoProcess() nothing received ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSAutoProcess() Something wrong has been received ");
                return;
            }
            case -2: {
                this.logger(2, "YP_ThreeDSAutoProcess() The state is not correct ");
                return;
            }
            case -3: {
                this.logger(2, "YP_ThreeDSAutoProcess() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSAutoProcess() unknown status");
                return;
            }
        }
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
    }

    public void YP_ThreeDSAutoAnalyseResponse() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        this.stateMachineThreeDS.getProtocolInterface().objectFactoryToTransactionsData(this.protocolThreeDS, this.stateMachineThreeDS.getServiceRequested());
        if (!this.protocolThreeDS.isMessageValid("veRes")) {
            this.stateMachineThreeDS.setErrorStatus(3);
            return;
        }
        String string = this.protocolThreeDS.YP_GetReceiveFactoryObject().getMessage().get(0).getVERes().getCH().getEnrolled();
        if (string == null || string.isEmpty()) {
            string = "T";
        }
        this.dataContainerTransaction.setExtensionValue("veresEnrolled", string);
        switch (string) {
            case "Y": {
                if (this.YP_FormatPAReq() <= 0) break;
                this.storeSecuredCVV();
                this.stateMachineThreeDS.setErrorStatus(0);
                break;
            }
            case "N": {
                this.stateMachineThreeDS.setErrorStatus(1);
                break;
            }
            case "U": {
                this.storeSecuredCVV();
                this.stateMachineThreeDS.setErrorStatus(2);
                break;
            }
            default: {
                this.stateMachineThreeDS.setErrorStatus(3);
            }
        }
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
    }

    public void YP_ThreeDSAutoEnd() {
        this.protocolThreeDS.YP_Disconnect();
    }

    private int YP_FormatPAReq() {
        ThreeDSecure threeDSecure;
        String.format("%020d", YP_TCD_DCC_Business.getTransactionNumber(this.dataContainerTransaction));
        VEReq vEReq = this.protocolThreeDS.YP_GetSendFactoryObject().getMessage().get(0).getVEReq();
        if (vEReq == null) {
            this.logger(2, "YP_FormatPAReq() missing initial VEReq message");
            return -1;
        }
        VERes vERes = this.protocolThreeDS.YP_GetReceiveFactoryObject().getMessage().get(0).getVERes();
        if (vERes == null) {
            this.logger(2, "YP_FormatPAReq() missing initial veresMessage message");
            return -2;
        }
        try {
            threeDSecure = this.protocolThreeDS.getObjectFromXMLFile("/technics/xml/threeds/pareq.xml");
        }
        catch (Exception exception) {
            this.logger(2, "YP_FormatPAReq() " + exception);
            return -3;
        }
        PAReq pAReq = threeDSecure.getMessage().get(0).getPAReq();
        pAReq.setVersion("1.0.2");
        this.dataContainerBusiness.getMerchantContract();
        String string = "ffffffff" + YP_TCD_DCC_Business.getExtendedIdentifier(this.dataContainerTransaction);
        threeDSecure.getMessage().get(0).setId(string);
        pAReq.getMerchant().setAcqBIN(vEReq.getMerchant().getAcqBIN());
        pAReq.getMerchant().setMerID(vEReq.getMerchant().getMerID());
        String string2 = this.dataContainerBusiness.getMerchantName();
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "YP_FormatPAReq() missing merchant name");
            return -4;
        }
        if (string2.length() > 25) {
            string2 = string2.substring(0, 25);
        }
        pAReq.getMerchant().setName(string2);
        pAReq.getMerchant().setCountry(this.dataContainerBusiness.getCountryCode());
        String string3 = this.protocolEFT.getMerchantURL();
        this.dataContainerTransaction.setExtensionValue("merchantUrl", string3);
        pAReq.getMerchant().setUrl(string3);
        pAReq.getPurchase().setXid(string.getBytes());
        String string4 = UtilsYP.getAAAAMMJJHHMMSSTime(UtilsYP.getCalendar(YP_TCD_DCC_Business.getTransactionAppliGMTTime(this.dataContainerTransaction)));
        pAReq.getPurchase().setDate(String.valueOf(string4.substring(0, 8)) + " " + string4.substring(8, 10) + ":" + string4.substring(10, 12) + ":" + string4.substring(12, 14));
        try {
            long l = YP_TCD_DCC_Business.getTransactionAmount(this.dataContainerTransaction);
            if (l < 0L) {
                pAReq.getPurchase().setAmount("");
            } else {
                int n = YP_TCD_DCC_Business.getTransactionAmountFraction(this.dataContainerTransaction);
                if (n < 0) {
                    pAReq.getPurchase().setAmount("");
                } else {
                    String string5 = YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.dataContainerTransaction);
                    if (string5 == null || string5.isEmpty()) {
                        pAReq.getPurchase().setAmount("");
                    }
                    pAReq.getPurchase().setAmount(UtilsYP.formatAmount(l, n, Locale.US));
                }
            }
        }
        catch (Exception exception) {
            pAReq.getPurchase().setAmount("");
        }
        pAReq.getPurchase().setPurchAmount(Long.toString(YP_TCD_DCC_Business.getTransactionAmount(this.dataContainerTransaction)));
        pAReq.getPurchase().setCurrency(Integer.toString(YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.dataContainerTransaction)));
        pAReq.getPurchase().setExponent(Integer.toString(YP_TCD_DCC_Business.getTransactionAmountFraction(this.dataContainerTransaction)));
        pAReq.getCH().setAcctID(vERes.getCH().getAcctID());
        pAReq.getCH().setExpiry(UtilsYP.getAAMMJJHHMMSSTime(UtilsYP.getCalendar(this.dataContainerTransaction.accountHandler.getAccountExpirationDate())).substring(0, 4));
        this.protocolEFT.setPaReq(this.protocolThreeDS.YP_FormatXMLPAReq(threeDSecure), vERes.getUrl(), vEReq.getMerchant().getMerID());
        return 1;
    }

    public void YP_ThreeDSPAReqProcess() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        switch (this.protocolThreeDS.YP_Send()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSPAReqProcess() message sent");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSPAReqProcess() Nothing has been sent ( a timeout has expired) ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSPAReqProcess() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSPAReqProcess() unknown status");
                return;
            }
        }
        switch (this.protocolThreeDS.YP_Receive()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSPAReqProcess() message received");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSPAReqProcess() nothing received ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSPAReqProcess() Something wrong has been received ");
                return;
            }
            case -2: {
                this.logger(2, "YP_ThreeDSPAReqProcess() The state is not correct ");
                return;
            }
            case -3: {
                this.logger(2, "YP_ThreeDSPAReqProcess() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSPAReqProcess() unknown status");
                return;
            }
        }
        if (this.protocolThreeDS.checkSignatureDocument()) {
            this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
        } else {
            this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        }
    }

    private void storeSecuredCVV() {
        try {
            this.dataContainerTransaction.setExtensionValue("eCommerceExtra", CryptoUtils.getSecuredCVV(this.dataContainerTransaction.accountHandler.getCardCVV()));
        }
        catch (Exception exception) {
            this.logger(2, "storeSecuredCVV() " + exception);
            return;
        }
    }
}

