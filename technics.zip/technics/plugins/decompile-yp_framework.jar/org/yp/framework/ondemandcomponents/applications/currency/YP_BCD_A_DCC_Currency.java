/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.currency;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.YP_TCD_DCB_Interface_Currency;

public class YP_BCD_A_DCC_Currency
extends YP_TCD_DCC_Business
implements YP_TCD_DCB_Interface_Currency {
    YP_TCD_DCB_Interface_Currency currencyInterface;

    public YP_BCD_A_DCC_Currency(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        this.setContainerBusinessType(this.getContainerBusinessType() | 1);
        super.initialize();
        try {
            this.currencyInterface = (YP_TCD_DCB_Interface_Currency)((Object)this.newPluginByName("DataContainerExtensionSTD_Currency", this));
            this.currencyInterface.initialize();
            this.currencyInterface.isCurrencyActivated("EUR");
        }
        catch (Exception exception) {
            this.logger(2, "initialise ()" + exception);
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        block11: {
            try {
                if (!string.contentEquals("updateCurrency")) break block11;
                if (objectArray == null || objectArray.length == 0) {
                    return this.updateCurrency();
                }
                this.logger(2, "dealRequest() bad parameter for updateCurrency ");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "dealRequest() bad request ??? :" + exception);
                return null;
            }
        }
        if (string.contentEquals("getCurrencyFraction")) {
            if (objectArray[0] instanceof String) {
                return this.getCurrencyFraction((String)objectArray[0]);
            }
            if (objectArray[0] instanceof Integer) {
                return this.getCurrencyFraction((Integer)objectArray[0]);
            }
            this.logger(2, "dealRequest() bad parameter for getCurrencyFraction ");
        } else if (string.contentEquals("convertAmount")) {
            if (objectArray != null && objectArray.length == 3 && objectArray[0] instanceof Long && objectArray[1] instanceof String && objectArray[2] instanceof String) {
                return this.convertAmount((long)((Long)objectArray[0]), (String)objectArray[1], (String)objectArray[2]);
            }
            if (objectArray != null && objectArray.length == 3 && objectArray[0] instanceof Long && objectArray[1] instanceof Integer && objectArray[2] instanceof Integer) {
                return this.convertAmount((long)((Long)objectArray[0]), (Integer)objectArray[1], (Integer)objectArray[2]);
            }
            this.logger(2, "dealRequest() bad parameter for convertAmount");
        }
        this.logger(2, "dealRequest() request unknown " + string);
        return null;
    }

    private int updateCurrency() {
        return 0;
    }

    private float getConversionRateFromGoogle(String string, String string2) {
        float f = 0.0f;
        try {
            int n;
            String string3 = "http://www.google.com/ig/calculator?hl=en&q=1";
            URL uRL = new URL(String.valueOf(string3) + string + "%3D%3F" + string2);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRL.openStream()));
            String string4 = bufferedReader.readLine();
            bufferedReader.close();
            if (string4 != null && (n = string4.indexOf("rhs: \"")) >= 0) {
                String string5 = string4.substring(n + "rhs: \"".length());
                int n2 = (string5 = string5.replace("\u00a0", "")).indexOf(32);
                if (n2 > 0 && string5.charAt(0) != '\"') {
                    string5 = string5.substring(0, n2);
                    f = Float.valueOf(string5).floatValue();
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "getConversionRateFromGoogle() " + exception);
        }
        return f;
    }

    @Override
    public int shutdown() {
        if (this.currencyInterface != null) {
            this.currencyInterface.shutdown();
            this.currencyInterface = null;
        }
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerCurrency";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public long convertAmount(long l, String string, String string2) {
        return this.currencyInterface.convertAmount(l, string, string2);
    }

    @Override
    public long convertAmount(long l, int n, int n2) {
        return this.currencyInterface.convertAmount(l, n, n2);
    }

    @Override
    public String getCurrencyAlphabeticalCode(int n) {
        return this.currencyInterface.getCurrencyAlphabeticalCode(n);
    }

    @Override
    public int getCurrencyNumericalCode(String string) {
        return this.currencyInterface.getCurrencyNumericalCode(string);
    }

    @Override
    public int getCurrencyFraction(int n) {
        return this.currencyInterface.getCurrencyFraction(n);
    }

    @Override
    public int getCurrencyFraction(String string) {
        return this.currencyInterface.getCurrencyFraction(string);
    }

    @Override
    public int getCounterValuePrintingActivationCode(String string) {
        return this.currencyInterface.getCounterValuePrintingActivationCode(string);
    }

    @Override
    public List<String> getCurrencyAlphabeticalCodeList() {
        return this.currencyInterface.getCurrencyAlphabeticalCodeList();
    }

    @Override
    public List<String> getCurrencyAlphabeticalCodeList(boolean bl, boolean bl2) {
        return this.currencyInterface.getCurrencyAlphabeticalCodeList(bl, bl2);
    }

    @Override
    public List<Integer> getCurrencyNumericalCodeList() {
        return this.currencyInterface.getCurrencyNumericalCodeList();
    }

    @Override
    public List<Integer> getCurrencyNumericalCodeList(boolean bl, boolean bl2) {
        return this.currencyInterface.getCurrencyNumericalCodeList(bl, bl2);
    }

    @Override
    public List<String> getConversionCurrencyAlphaList(String string) {
        return this.currencyInterface.getConversionCurrencyAlphaList(string);
    }

    @Override
    public boolean isCurrencyActivated(String string) {
        return this.currencyInterface.isCurrencyActivated(string);
    }

    @Override
    public String formatAmount(long l, String string) {
        return this.currencyInterface.formatAmount(l, string);
    }

    @Override
    public String formatAmount(long l, int n) {
        return this.currencyInterface.formatAmount(l, n);
    }

    @Override
    public long getCurrencyMinAmount(int n) {
        return this.currencyInterface.getCurrencyMinAmount(n);
    }

    @Override
    public long getCurrencyMinAmount(String string) {
        return this.currencyInterface.getCurrencyMinAmount(string);
    }

    @Override
    public long getCurrencyMaxAmount(int n) {
        return this.currencyInterface.getCurrencyMaxAmount(n);
    }

    @Override
    public long getCurrencyMaxAmount(String string) {
        return this.currencyInterface.getCurrencyMaxAmount(string);
    }

    @Override
    public long getCurrencyDoubleAuthentificationAmount(int n) {
        return this.currencyInterface.getCurrencyDoubleAuthentificationAmount(n);
    }

    @Override
    public long getCurrencyDoubleAuthentificationAmount(String string) {
        return this.currencyInterface.getCurrencyDoubleAuthentificationAmount(string);
    }

    @Override
    public long getCurrencyChecksum() {
        return this.currencyInterface.getCurrencyChecksum();
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

