/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;

public interface YP_PROT_IHM {
    public String getViewName();

    public int getStartIndex();

    public int getMaxRecords();

    public int createGetDataResponse(String var1, int var2, int var3, boolean var4);

    public int addColumnToResponse(int var1, String var2, String var3, String var4, Map<String, String> var5);

    public int addRowToResponse(YP_Row var1);

    public int addViewContentToResponse(YP_View var1, int var2, int var3);

    public int updateViewContentFromRequest(YP_View var1);

    public int updateViewHeaderFromRequest(YP_View var1);

    public List<YP_Gabarit> getSearchGabarit();
}

