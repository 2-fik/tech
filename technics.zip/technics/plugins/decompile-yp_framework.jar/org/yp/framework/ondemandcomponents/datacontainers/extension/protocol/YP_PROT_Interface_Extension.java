/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.protocol;

import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_PROT_Interface_Extension
extends YP_TCD_DCB_Interface_Extension {
    public String getCardAcceptorIdentificationCode();

    public String getSimpleD(YP_TCD_DesignAccesObject var1, String var2);
}

