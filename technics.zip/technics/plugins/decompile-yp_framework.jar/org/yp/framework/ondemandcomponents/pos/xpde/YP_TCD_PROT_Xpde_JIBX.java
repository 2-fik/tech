/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.xpde;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Account;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Context;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_3DSecure;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_EPayment;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_RetrievalReference;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Update;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_User;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.ZipUtils;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ReservationStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;
import org.yp.xml.jibx.xpde.ADF;
import org.yp.xml.jibx.xpde.Action;
import org.yp.xml.jibx.xpde.AmountData;
import org.yp.xml.jibx.xpde.CardData;
import org.yp.xml.jibx.xpde.ChequeData;
import org.yp.xml.jibx.xpde.Column;
import org.yp.xml.jibx.xpde.Context;
import org.yp.xml.jibx.xpde.Customer;
import org.yp.xml.jibx.xpde.EPayment;
import org.yp.xml.jibx.xpde.FilterCriteriaEnumeration;
import org.yp.xml.jibx.xpde.FilterData;
import org.yp.xml.jibx.xpde.FilterValue;
import org.yp.xml.jibx.xpde.GetDataBody;
import org.yp.xml.jibx.xpde.GetDataHeader;
import org.yp.xml.jibx.xpde.GetDataRequest;
import org.yp.xml.jibx.xpde.GetDataResponse;
import org.yp.xml.jibx.xpde.HeaderParameterFile;
import org.yp.xml.jibx.xpde.MeanOfPayment;
import org.yp.xml.jibx.xpde.MeanOfPaymentComplementaryData;
import org.yp.xml.jibx.xpde.MessageHeader;
import org.yp.xml.jibx.xpde.MessageTypeEnumeration;
import org.yp.xml.jibx.xpde.ParameterFile;
import org.yp.xml.jibx.xpde.PersonDetails;
import org.yp.xml.jibx.xpde.PrintOutput;
import org.yp.xml.jibx.xpde.ProtocolModeEnumeration;
import org.yp.xml.jibx.xpde.RequestBody;
import org.yp.xml.jibx.xpde.ResponseBody;
import org.yp.xml.jibx.xpde.ResultEnumeration;
import org.yp.xml.jibx.xpde.RetrievalReferenceData;
import org.yp.xml.jibx.xpde.Row;
import org.yp.xml.jibx.xpde.RowField;
import org.yp.xml.jibx.xpde.SbanData;
import org.yp.xml.jibx.xpde.SetDataBody;
import org.yp.xml.jibx.xpde.SetDataHeader;
import org.yp.xml.jibx.xpde.SetDataRequest;
import org.yp.xml.jibx.xpde.Status;
import org.yp.xml.jibx.xpde.SystemTransactionIdentifier;
import org.yp.xml.jibx.xpde.ThreeDSecure;
import org.yp.xml.jibx.xpde.TransactionData;
import org.yp.xml.jibx.xpde.TransactionDetails;
import org.yp.xml.jibx.xpde.TransactionIdentifierData;
import org.yp.xml.jibx.xpde.User;
import org.yp.xml.jibx.xpde.XPDERequest;
import org.yp.xml.jibx.xpde.XPDEResponse;

public class YP_TCD_PROT_Xpde_JIBX
extends YP_TCD_PosProtocol
implements YP_PROT_Interface_3DSecure,
YP_PROT_Context,
YP_PROT_Account,
YP_PROT_User,
YP_PROT_IHM,
YP_PROT_RetrievalReference,
YP_PROT_Update,
YP_PROT_Interface_EPayment {
    private XPDEResponse xpdeResponse = null;
    private XPDERequest xpdeRequest = null;
    private String initialRequest;
    private String paResDecrypted;

    public YP_TCD_PROT_Xpde_JIBX(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            this.setParserName("XPDEParserJIBX");
        }
    }

    @Override
    public String toString() {
        return "XPDE_JIBX";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public int loadInitialRequest(String string) {
        block5: {
            try {
                this.initialRequest = string;
                this.xpdeRequest = (XPDERequest)this.getParser().dealRequest(this, "xmlToObject", string);
                if (this.xpdeRequest != null) break block5;
                this.prepareErrorResponse(new ExtendedResult(7));
                return -1;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "load() :" + exception);
                }
                return -1;
            }
        }
        if (this.prepareDefaultResponse() <= 0) {
            this.prepareErrorResponse(new ExtendedResult(7));
            return -1;
        }
        return 1;
    }

    @Override
    public String getInitialRequest() {
        return this.initialRequest;
    }

    @Override
    public String getResponse() {
        try {
            return (String)this.getParser().dealRequest(this, "objectToXML", this.xpdeResponse);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getResponse() :" + exception);
            }
            return null;
        }
    }

    @Override
    public String getRequest(Object object) {
        try {
            return (String)this.getParser().dealRequest(this, "objectToXML", object);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getRequest() :" + exception);
            }
            return null;
        }
    }

    private int prepareDefaultResponse() {
        try {
            this.xpdeResponse = new XPDEResponse();
            this.xpdeResponse.setMessageHeader(new MessageHeader());
            this.xpdeResponse.getMessageHeader().setMerchantIdentifier(this.xpdeRequest.getMessageHeader().getMerchantIdentifier());
            this.xpdeResponse.getMessageHeader().setTerminalIdentifier(this.xpdeRequest.getMessageHeader().getTerminalIdentifier());
            this.xpdeResponse.getMessageHeader().setProtocolMode(this.xpdeRequest.getMessageHeader().getProtocolMode());
            this.xpdeResponse.getMessageHeader().setProtocolVersion(this.xpdeRequest.getMessageHeader().getProtocolVersion());
            this.xpdeResponse.getMessageHeader().setServiceSequenceNumber(this.xpdeRequest.getMessageHeader().getServiceSequenceNumber());
            this.xpdeResponse.getMessageHeader().setMessageType(this.xpdeRequest.getMessageHeader().getMessageType());
            this.xpdeResponse.getMessageHeader().setSubMessageType(this.xpdeRequest.getMessageHeader().getSubMessageType());
            this.xpdeResponse.getMessageHeader().setPaymentSystemIdentifier(Integer.toString(UtilsYP.getInstanceNumber()));
            this.xpdeResponse.setResponseBody(new ResponseBody());
            this.xpdeResponse.getResponseBody().setGlobalStatus(new Status());
            this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.ERROR.xmlValue());
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "prepareDefaultResponse()  " + exception);
            }
            return -1;
        }
    }

    private int prepareErrorResponse(ExtendedResult extendedResult) {
        try {
            List<Integer> list;
            this.xpdeResponse = new XPDEResponse();
            this.xpdeResponse.setMessageHeader(new MessageHeader());
            this.xpdeResponse.getMessageHeader().setMessageType(MessageTypeEnumeration.ERROR.xmlValue());
            this.xpdeResponse.getMessageHeader().setMerchantIdentifier("KERNEL");
            if (this.xpdeRequest != null && this.xpdeRequest.getMessageHeader() != null) {
                this.xpdeResponse.getMessageHeader().setTerminalIdentifier(this.xpdeRequest.getMessageHeader().getTerminalIdentifier());
            }
            this.xpdeResponse.getMessageHeader().setProtocolVersion("1");
            this.xpdeResponse.getMessageHeader().setServiceSequenceNumber("");
            this.xpdeResponse.getMessageHeader().setPaymentSystemIdentifier(Integer.toString(UtilsYP.getInstanceNumber()));
            this.xpdeResponse.setResponseBody(new ResponseBody());
            this.xpdeResponse.getResponseBody().setGlobalStatus(new Status());
            this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.ERROR.xmlValue());
            if (extendedResult != null && (list = extendedResult.getExtendedResultList()) != null && !list.isEmpty()) {
                List<String> list2 = this.xpdeResponse.getResponseBody().getGlobalStatus().getExtendedResultList();
                for (int n : list) {
                    list2.add(String.valueOf(n));
                }
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "prepareErrorResponse() " + exception);
            }
            return -1;
        }
    }

    @Override
    public YP_TCD_PosProtocol.SUB_REQUEST_TYPE getSubRequestType() {
        try {
            String string = this.xpdeRequest.getMessageHeader().getSubMessageType();
            if (string == null) {
                if (this.getLogLevel() >= 6) {
                    this.logger(6, "getSubRequestType(): unable to get Sub Message Type");
                }
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.None;
            }
            if (string.contentEquals("SummaryReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.SummaryReport;
            }
            if (string.contentEquals("TerminalSummaryReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalSummaryReport;
            }
            if (string.contentEquals("FunctionnalParameterReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.FunctionnalParameterReport;
            }
            if (string.contentEquals("ReconciliationReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ReconciliationReport;
            }
            if (string.contentEquals("ReferenceParameterReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ReferenceParameterReport;
            }
            if (string.contentEquals("RemoteParameterizationReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.RemoteParameterizationReport;
            }
            if (string.contentEquals("IncidentsReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.IncidentsReport;
            }
            if (string.contentEquals("HardwareReport")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.HardwareReport;
            }
            if (string.contentEquals("Diary")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Diary;
            }
            if (string.contentEquals("Reload")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Reload;
            }
            if (string.contentEquals("GetCustomerData")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.GetCustomerData;
            }
            if (string.contentEquals("AddCustomerData")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData;
            }
            if (string.contentEquals("DeleteCustomerData")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.DeleteCustomerData;
            }
            if (string.contentEquals("OpenTransaction")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction;
            }
            if (string.contentEquals("OpenTransactionAndTRM")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM;
            }
            if (string.contentEquals("TerminalRiskManagement")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalRiskManagement;
            }
            if (string.contentEquals("Authorization")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Authorization;
            }
            if (string.contentEquals("Completion")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion;
            }
            if (string.contentEquals("AuthorizationAndCompletion")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AuthorizationAndCompletion;
            }
            if (string.contentEquals("ForcedShutdown")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ForcedShutdown;
            }
            if (string.contentEquals("CloseCXAndShutdownWhenIdle")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.CloseCXAndShutdownWhenIdle;
            }
            if (string.contentEquals("ShutdownWhenIdle")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ShutdownWhenIdle;
            }
            if (string.contentEquals("Change")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Change;
            }
            if (string.contentEquals("Reset")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Reset;
            }
            if (string.contentEquals("ProcessNFC")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC;
            }
            if (string.contentEquals("ApduCommands")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ApduCommands;
            }
            if (string.contentEquals("GetBrandList")) {
                return YP_TCD_PosProtocol.SUB_REQUEST_TYPE.GetBrandList;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getSubRequestType(): unknown request:" + string);
            }
            return null;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getSubRequestType():" + exception);
            }
            return null;
        }
    }

    @Override
    public YP_TCD_PosProtocol.REQUEST_TYPE getRequestType() {
        try {
            String string = this.xpdeRequest.getMessageHeader().getMessageType();
            if (string.contentEquals(MessageTypeEnumeration.REPRINT.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Reprint;
            }
            if (string.contentEquals(MessageTypeEnumeration.REPRINT_LAST_TRS.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.ReprintLastTrs;
            }
            if (string.contentEquals(MessageTypeEnumeration.RECONCILIATION.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation;
            }
            if (string.contentEquals(MessageTypeEnumeration.REMOTE_PARAMETERIZATION.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.RemoteParameterization;
            }
            if (string.contentEquals(MessageTypeEnumeration.REPORT.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Report;
            }
            if (string.contentEquals(MessageTypeEnumeration.SYSTEM.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.System;
            }
            if (string.contentEquals(MessageTypeEnumeration.LOYALTY.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Loyalty;
            }
            if (string.contentEquals(MessageTypeEnumeration.LOGIN.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Login;
            }
            if (string.contentEquals(MessageTypeEnumeration.LOGOUT.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Logout;
            }
            if (string.contentEquals(MessageTypeEnumeration.GET_DATA.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.GetData;
            }
            if (string.contentEquals(MessageTypeEnumeration.SET_DATA.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.SetData;
            }
            if (string.contentEquals(MessageTypeEnumeration.CREATE_DATA.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.CreateData;
            }
            if (string.contentEquals(MessageTypeEnumeration.SHUTDOWN.xmlValue())) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.Shutdown;
            }
            if (string.contentEquals("GlobalSummaryReport")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.GlobalSummaryReport;
            }
            if (string.contentEquals("ENREGISTREMENT_PARI")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.EnregistrementPari;
            }
            if (string.contentEquals("AUTHENTICATION")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.TerminalAuthentication;
            }
            if (string.contentEquals("ANNULATION_PARI")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.AnnulationPari;
            }
            if (string.contentEquals("RECEPTION_SIGNAL")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.ReceptionSignal;
            }
            if (string.contentEquals("PAIEMENT_PARI")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.PaiementPari;
            }
            if (string.contentEquals("TRAITEMENT_TICKET")) {
                return YP_TCD_PosProtocol.REQUEST_TYPE.TraitementTicket;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getRequestType(): unknown request:");
            }
            return null;
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public boolean getTestMode() {
        try {
            return !this.xpdeRequest.getMessageHeader().getProtocolMode().contentEquals("Production");
        }
        catch (Exception exception) {
            return false;
        }
    }

    @Override
    public String createScheduledRequest(YP_Object yP_Object, String string) {
        XPDERequest xPDERequest = new XPDERequest();
        xPDERequest.setMessageHeader(new MessageHeader());
        xPDERequest.getMessageHeader().setProtocolMode(ProtocolModeEnumeration.PRODUCTION.xmlValue());
        xPDERequest.getMessageHeader().setProtocolVersion("1");
        xPDERequest.getMessageHeader().setServiceSequenceNumber("0");
        String string2 = yP_Object.getContractIdentifier();
        String[] stringArray = string2.split("_");
        if (stringArray.length != 4) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createScheduledRequest() bad contract name:" + string2);
            }
            return null;
        }
        String string3 = String.valueOf(stringArray[0]) + "_" + stringArray[1];
        String string4 = String.valueOf(stringArray[2]) + "_" + stringArray[3];
        xPDERequest.getMessageHeader().setMerchantIdentifier(string3);
        xPDERequest.setRequestBody(new RequestBody());
        TransactionData transactionData = new TransactionData();
        transactionData.setContext(new Context());
        transactionData.getContext().getPositiveApplicationIdentifierList().add(string4);
        xPDERequest.getRequestBody().getTransactionDataList().add(transactionData);
        if (string.contentEquals("TLC")) {
            xPDERequest.getMessageHeader().setMessageType(MessageTypeEnumeration.RECONCILIATION.xmlValue());
        } else if (string.contentEquals("TLP")) {
            xPDERequest.getMessageHeader().setMessageType(MessageTypeEnumeration.REMOTE_PARAMETERIZATION.xmlValue());
        } else if (string.contentEquals("GSR")) {
            xPDERequest.getMessageHeader().setMessageType("GlobalSummaryReport");
        } else {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createScheduledRequest() TODO:" + string);
            }
            return null;
        }
        return this.getRequest(xPDERequest);
    }

    private EPayment getEpaymentFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        EPayment ePayment = transactionData.getEPayment();
        if (ePayment == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getEpaymentFromRequest() ePayment not set");
            }
            return null;
        }
        return ePayment;
    }

    private EPayment getEPaymentFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        EPayment ePayment = transactionData.getEPayment();
        if (ePayment == null) {
            ePayment = new EPayment();
            EPayment ePayment2 = this.getEpaymentFromRequest();
            if (ePayment2 != null) {
                ePayment.setMerchantURLSuccess(ePayment2.getMerchantURLSuccess());
                ePayment.setMerchantURLError(ePayment2.getMerchantURLError());
                ePayment.setMerchantURLRefused(ePayment2.getMerchantURLRefused());
                ePayment.setMerchantURLStatus(ePayment2.getMerchantURLStatus());
            } else {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getEPaymentFromResponse() ePayment not set in request !!!");
                }
                ePayment.setMerchantURLSuccess("");
            }
            transactionData.setEPayment(ePayment);
        }
        return ePayment;
    }

    private ThreeDSecure getThreeDSecureFromRequest() {
        EPayment ePayment = this.getEpaymentFromRequest();
        if (ePayment == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getThreeDSecureFromRequest() ePayment not set");
            }
            return null;
        }
        ThreeDSecure threeDSecure = ePayment.getThreeDSecure();
        if (threeDSecure == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getThreeDSecureFromRequest() threeDSecure not set");
            }
            return null;
        }
        return threeDSecure;
    }

    private ThreeDSecure getThreeDSecureFromResponse() {
        EPayment ePayment = this.getEPaymentFromResponse();
        if (ePayment == null) {
            return null;
        }
        ThreeDSecure threeDSecure = ePayment.getThreeDSecure();
        if (threeDSecure == null) {
            threeDSecure = new ThreeDSecure();
            ePayment.setThreeDSecure(threeDSecure);
        }
        return threeDSecure;
    }

    @Override
    public int is3DSActive(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ThreeDSecure threeDSecure = this.getThreeDSecureFromRequest();
        if (threeDSecure == null) {
            return 0;
        }
        String string = threeDSecure.getMerchantURL();
        if (string != null && !string.isEmpty()) {
            return 1;
        }
        return 0;
    }

    @Override
    public int is3DSResponse(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ThreeDSecure threeDSecure = this.getThreeDSecureFromRequest();
        if (threeDSecure == null) {
            return 0;
        }
        String string = threeDSecure.getPaRes();
        if (string != null && !string.isEmpty()) {
            return 1;
        }
        return 0;
    }

    @Override
    public String getMerchantURL() {
        ThreeDSecure threeDSecure = this.getThreeDSecureFromRequest();
        if (threeDSecure == null) {
            return null;
        }
        String string = threeDSecure.getMerchantURL();
        if (string != null && !string.isEmpty()) {
            return string.trim();
        }
        return null;
    }

    @Override
    public int setPaReq(String string, String string2, String string3) {
        if (string2 == null || string2.isEmpty()) {
            return -1;
        }
        if (string == null || string.isEmpty()) {
            return -2;
        }
        if (string3 == null || string3.isEmpty()) {
            return -3;
        }
        ThreeDSecure threeDSecure = this.getThreeDSecureFromResponse();
        if (threeDSecure == null) {
            return -1;
        }
        threeDSecure.setAcsURL(string2);
        threeDSecure.setMerchantID(string3);
        threeDSecure.setPaReq(UtilsYP.base64Encode(ZipUtils.compressString(string)));
        threeDSecure.setStep("2");
        threeDSecure.setMerchantURL(this.getMerchantURL());
        return 0;
    }

    @Override
    public String getPaRes() {
        return this.paResDecrypted;
    }

    @Override
    public int readRequest(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        block25: {
            block24: {
                block23: {
                    block22: {
                        block21: {
                            YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE;
                            block20: {
                                YP_TCD_PosProtocol.REQUEST_TYPE rEQUEST_TYPE;
                                block19: {
                                    try {
                                        rEQUEST_TYPE = this.getRequestType();
                                        if (rEQUEST_TYPE != null) break block19;
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "readRequest() bad requestType ?");
                                        }
                                        return -1;
                                    }
                                    catch (Exception exception) {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "readRequest() " + exception);
                                        }
                                        return -1;
                                    }
                                }
                                yP_TCD_DC_Transaction.setRequestType(rEQUEST_TYPE);
                                sUB_REQUEST_TYPE = this.getSubRequestType();
                                if (sUB_REQUEST_TYPE != null) break block20;
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "readRequest() bad subRequestType ?");
                                }
                                return -1;
                            }
                            yP_TCD_DC_Transaction.setSubRequestType(sUB_REQUEST_TYPE);
                            if (yP_TCD_DC_Transaction.contextHandler.readRequest() >= 0) break block21;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "readRequest() contextHandler Bad request ???");
                            }
                            return -1;
                        }
                        if (yP_TCD_DC_Transaction.userHandler.readRequest() >= 0) break block22;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "readRequest() userHandler Bad request ???");
                        }
                        return -1;
                    }
                    if (yP_TCD_DC_Transaction.accountHandler.readRequest() >= 0) break block23;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "readRequest() accountHandler Bad request ???");
                    }
                    return -1;
                }
                if (yP_TCD_DC_Transaction.commonHandler.readRequest() >= 0) break block24;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "readRequest() commonHandler Bad request ???");
                }
                return -1;
            }
            if (yP_TCD_DC_Transaction.reservationHandler.readRequest() >= 0) break block25;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "readRequest() reservationHandler Bad request ???");
            }
            return -1;
        }
        if (this.map3DSecureData(yP_TCD_DC_Transaction) < 0) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "readRequest() 3DS Bad request ???");
            }
            return -1;
        }
        return 1;
    }

    @Override
    public int prepareResponse(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        block16: {
            block15: {
                block14: {
                    block13: {
                        try {
                            if (yP_TCD_DC_Transaction.contextHandler.prepareResponse() >= 0) break block13;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "prepareResponse() accountHandler Bad request ???");
                            }
                            return -1;
                        }
                        catch (Exception exception) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "prepareResponse() " + exception);
                            }
                            return -1;
                        }
                    }
                    if (yP_TCD_DC_Transaction.userHandler.prepareResponse() >= 0) break block14;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "prepareResponse() userHandler Bad request ???");
                    }
                    return -1;
                }
                if (yP_TCD_DC_Transaction.accountHandler.prepareResponse() >= 0) break block15;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "prepareResponse() accountHandler Bad request ???");
                }
                return -1;
            }
            if (yP_TCD_DC_Transaction.commonHandler.prepareResponse() >= 0) break block16;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "prepareResponse() commonHandler Bad request ???");
            }
            return -1;
        }
        if (yP_TCD_DC_Transaction.reservationHandler.prepareResponse() < 0) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "prepareResponse() reservationHandler Bad request ???");
            }
            return -1;
        }
        return 1;
    }

    private int map3DSecureData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        block8: {
            String string;
            block9: {
                ThreeDSecure threeDSecure;
                block7: {
                    try {
                        this.paResDecrypted = null;
                        threeDSecure = this.getThreeDSecureFromRequest();
                        if (threeDSecure != null) break block7;
                        if (this.getLogLevel() >= 6) {
                            this.logger(6, "map3DSecureData() threeDSecure not set");
                        }
                        return 0;
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "map3DSecureData() " + exception);
                        }
                        return -1;
                    }
                }
                string = threeDSecure.getPaRes();
                if (string == null || string.isEmpty()) break block8;
                String string2 = YP_TCD_DCC_Business.getExtendedIdentifier(yP_TCD_DC_Transaction);
                if (string2 != null && !string2.isEmpty()) break block9;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "map3DSecureData() extendedIdentifier is mandatory when there's a PaRes");
                }
                return -1;
            }
            this.paResDecrypted = ZipUtils.deCompress(UtilsYP.base64Decode(string));
            return 1;
        }
        return 0;
    }

    @Override
    public String getMerchantIdentifier() {
        String string = this.xpdeRequest.getMessageHeader().getMerchantIdentifier();
        if (string != null) {
            string = UtilsYP.decryptInfo(string);
        }
        return string;
    }

    @Override
    public int setMerchantIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        this.xpdeResponse.getMessageHeader().setMerchantIdentifier(UtilsYP.cryptInfo(string));
        return 1;
    }

    @Override
    public int setTerminalIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        this.xpdeResponse.getMessageHeader().setTerminalIdentifier(string);
        return 1;
    }

    @Override
    public String getTerminalIdentifier() {
        return this.xpdeRequest.getMessageHeader().getTerminalIdentifier();
    }

    @Override
    public String getApplicationIdentifier() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        String string = context.getApplicationIdentifier();
        if (string != null) {
            string = UtilsYP.decryptInfo(string);
        }
        return string;
    }

    @Override
    public String getExtendedIdentifier() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return null;
        }
        String string = messageHeader.getExtendedIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getExtendedIdentifier() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public String getServiceSequenceNumber() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return null;
        }
        String string = messageHeader.getServiceSequenceNumber();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getServiceSequenceNumber() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public String getPaymentSystemIdentifier() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return null;
        }
        String string = messageHeader.getPaymentSystemIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getPaymentSystemIdentifier() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public String getProtocolMode() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return null;
        }
        String string = messageHeader.getProtocolMode();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getProtocolMode() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public String getProtocolVersion() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return null;
        }
        String string = messageHeader.getProtocolVersion();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getProtocolVersion() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public long getTimeoutMS() {
        MessageHeader messageHeader = this.xpdeRequest.getMessageHeader();
        if (messageHeader == null) {
            return -1L;
        }
        BigDecimal bigDecimal = messageHeader.getTimeoutMS();
        if (bigDecimal == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTimeoutMS() not set");
            }
            return -1L;
        }
        return bigDecimal.longValue();
    }

    @Override
    public int setStatus(YP_TCD_PosProtocol.RESULT_TYPE rESULT_TYPE) {
        switch (rESULT_TYPE) {
            case Success: {
                this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.SUCCESS.xmlValue());
                break;
            }
            case Refused: {
                this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.REFUSED.xmlValue());
                break;
            }
            case Intermediate: {
                this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.INTERMEDIATE.xmlValue());
                break;
            }
            default: {
                this.xpdeResponse.getResponseBody().getGlobalStatus().setResult(ResultEnumeration.ERROR.xmlValue());
            }
        }
        return 1;
    }

    @Override
    public int setExtendedResult(ExtendedResult extendedResult) {
        List<Integer> list;
        if (extendedResult != null && (list = extendedResult.getExtendedResultList()) != null && !list.isEmpty()) {
            List<String> list2 = this.xpdeResponse.getResponseBody().getGlobalStatus().getExtendedResultList();
            for (int n : list) {
                boolean bl = false;
                for (String string : list2) {
                    if (!string.contentEquals(Integer.toString(n))) continue;
                    bl = true;
                    break;
                }
                if (bl) continue;
                list2.add(Integer.toString(n));
            }
        }
        return 1;
    }

    @Override
    public int setExtendedIdentifier(String string) {
        if (string != null && !string.isEmpty()) {
            this.xpdeResponse.getMessageHeader().setExtendedIdentifier(string);
        }
        return 0;
    }

    @Override
    public int setApplicationIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        Context context = this.getContextFromResponse();
        if (context == null) {
            return -1;
        }
        context.setApplicationIdentifier(string);
        return 1;
    }

    private Customer getCustomerFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        Customer customer = transactionData.getCustomer();
        if (customer == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerFromRequest() customer not set");
            }
            return null;
        }
        return customer;
    }

    private Customer getCustomerFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        Customer customer = transactionData.getCustomer();
        if (customer == null) {
            customer = new Customer();
            transactionData.setCustomer(customer);
        }
        return customer;
    }

    private PersonDetails getCustomerPersonDetailsFromRequest() {
        Customer customer = this.getCustomerFromRequest();
        if (customer == null) {
            return null;
        }
        PersonDetails personDetails = customer.getPersonDetails();
        if (personDetails == null && this.getLogLevel() >= 6) {
            this.logger(6, "getCustomerPersonDetailsFromRequest() personDetails not set");
        }
        return personDetails;
    }

    private PersonDetails getCustomerPersonDetailsFromResponse() {
        Customer customer = this.getCustomerFromResponse();
        if (customer == null) {
            return null;
        }
        PersonDetails personDetails = customer.getPersonDetails();
        if (personDetails == null) {
            personDetails = new PersonDetails();
            customer.setPersonDetails(personDetails);
        }
        return personDetails;
    }

    @Override
    public long getCustomerIdentifier() {
        Customer customer = this.getCustomerFromRequest();
        if (customer == null) {
            return -1L;
        }
        String string = customer.getIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerIdentifier() not set");
            }
            return -1L;
        }
        try {
            return Long.parseLong(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerIdentifier() bad value for customer identifier ???" + string + " " + exception);
            }
            return -1L;
        }
    }

    @Override
    public int setCustomerIdentifier(long l) {
        if (l <= 0L) {
            return 0;
        }
        Customer customer = this.getCustomerFromResponse();
        customer.setIdentifier(Long.toString(l));
        return 1;
    }

    @Override
    public String getCustomerMerchantIdentifier() {
        Customer customer = this.getCustomerFromRequest();
        if (customer == null) {
            return null;
        }
        String string = customer.getMerchantIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerMerchantIdentifier() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCustomerMerchantIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        Customer customer = this.getCustomerFromResponse();
        customer.setMerchantIdentifier(string);
        return 1;
    }

    @Override
    public String getCustomerName() {
        PersonDetails personDetails = this.getCustomerPersonDetailsFromRequest();
        if (personDetails == null) {
            return null;
        }
        String string = personDetails.getFirstName();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerName() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCustomerName(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getCustomerPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setFirstName(string);
        return 1;
    }

    @Override
    public String getCustomerMailAddress() {
        PersonDetails personDetails = this.getCustomerPersonDetailsFromRequest();
        if (personDetails == null) {
            return null;
        }
        String string = personDetails.getEmail();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerMailAddress() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCustomerMailAddress(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getCustomerPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setEmail(string);
        return 1;
    }

    @Override
    public String getCustomerIPAddress() {
        TransactionDetails transactionDetails = this.getTransactionDetailsFromRequest();
        if (transactionDetails == null) {
            return null;
        }
        String string = transactionDetails.getIp();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCustomerIpAddress() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCustomerIPAddress(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionDetails transactionDetails = this.getTransactionDetailsFromResponse();
        if (transactionDetails == null) {
            return -1;
        }
        transactionDetails.setIp(string);
        return 1;
    }

    @Override
    public String getCustomerPrimaryPhone() {
        PersonDetails personDetails;
        block3: {
            try {
                personDetails = this.getCustomerPersonDetailsFromRequest();
                if (personDetails != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return personDetails.getPrimaryPhone();
    }

    @Override
    public int setCustomerPrimaryPhone(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getCustomerPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setPrimaryPhone(string);
        return 1;
    }

    private MeanOfPayment getMeanOfPaymentFromRequest() {
        Customer customer = this.getCustomerFromRequest();
        if (customer == null) {
            return null;
        }
        List<MeanOfPayment> list = customer.getMeanOfPaymentList();
        if (list == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMeanOfPaymentFromRequest() MOP not set");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMeanOfPaymentFromRequest() MOP not set");
            }
            return null;
        }
        if (list.size() > 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMeanOfPaymentFromRequest() too many MOP");
            }
            return null;
        }
        MeanOfPayment meanOfPayment = list.get(0);
        return meanOfPayment;
    }

    private MeanOfPayment getMeanOfPaymentFromResponse(boolean bl) {
        MeanOfPayment meanOfPayment;
        Customer customer = this.getCustomerFromResponse();
        if (customer == null) {
            return null;
        }
        List<MeanOfPayment> list = customer.getMeanOfPaymentList();
        if (list == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMeanOfPaymentFromResponse() MOP not set");
            }
            return null;
        }
        if (list.isEmpty() || bl) {
            meanOfPayment = new MeanOfPayment();
            list.add(meanOfPayment);
        } else {
            meanOfPayment = list.get(list.size() - 1);
        }
        return meanOfPayment;
    }

    @Override
    public int addOneMeanOfPaymentInstance() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(true);
        if (meanOfPayment != null) {
            return 1;
        }
        return -1;
    }

    @Override
    public int setMeanOfPaymentIdentifier(long l) {
        if (l <= 0L) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setIdentifier(Long.toString(l));
        return 1;
    }

    @Override
    public long getMeanOfPaymentIdentifier() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return -1L;
        }
        String string = meanOfPayment.getIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMeanOfPaymentIdentifier() not set");
            }
            return -1L;
        }
        try {
            return Long.parseLong(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMeanOfPaymentIdentifier() bad value for meanOfPayment identifier ???" + meanOfPayment + " " + exception);
            }
            return -1L;
        }
    }

    @Override
    public String getAccountIdentifier() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getAccountIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountIdentifier() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setAccountIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setAccountIdentifier(string);
        return 1;
    }

    @Override
    public String getMaskedAccountIdentifier() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getMaskedAccountIdentifier();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMaskedAccountIdentifier() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setMaskedAccountIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setMaskedAccountIdentifier(string);
        return 1;
    }

    @Override
    public String getAccountHolderName() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getHolderName();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountHolderName() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setAccountHolderName(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setHolderName(string);
        return 1;
    }

    @Override
    public String getAccountAlias() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getAlias();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountAlias() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setAccountAlias(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setAlias(string);
        return 1;
    }

    @Override
    public Calendar getAccountExpirationDate() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getExpirationDate();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountExpirationDate() not set");
            }
            return null;
        }
        try {
            if (string.length() == 4) {
                return UtilsYP.parseMMAADate(string);
            }
            if (string.length() == 6) {
                return UtilsYP.parseAAMMJJDate(string);
            }
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getAccountExpirationDate() bad date format ?  :" + string);
            }
            return null;
        }
    }

    @Override
    public int setAccountExpirationDate(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setExpirationDate(UtilsYP.printDateTime(calendar));
        return 1;
    }

    @Override
    public Calendar getAccountEffectiveDate() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getEffectiveDate();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountEffectiveDate() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getAccountEffectiveDate() bad date format ? :" + string);
            }
            return null;
        }
    }

    @Override
    public int setAccountEffectiveDate(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setEffectiveDate(UtilsYP.printDateTime(calendar));
        return 1;
    }

    @Override
    public String getAccountType() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        String string = meanOfPayment.getType();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAccountType() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setAccountType(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        meanOfPayment.setType(string);
        return 1;
    }

    private CardData getCardDataFromRequest() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        MeanOfPaymentComplementaryData meanOfPaymentComplementaryData = meanOfPayment.getComplementaryData();
        if (meanOfPaymentComplementaryData == null) {
            return null;
        }
        CardData cardData = meanOfPaymentComplementaryData.getCardData();
        return cardData;
    }

    private CardData getCardDataFromResponse() {
        CardData cardData;
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        if (meanOfPayment == null) {
            return null;
        }
        MeanOfPaymentComplementaryData meanOfPaymentComplementaryData = meanOfPayment.getComplementaryData();
        if (meanOfPaymentComplementaryData == null) {
            meanOfPaymentComplementaryData = new MeanOfPaymentComplementaryData();
            meanOfPayment.setComplementaryData(meanOfPaymentComplementaryData);
        }
        if ((cardData = meanOfPaymentComplementaryData.getCardData()) == null) {
            cardData = new CardData();
            meanOfPaymentComplementaryData.setCardData(cardData);
        }
        return cardData;
    }

    @Override
    public String getCardType() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        String string = cardData.getCardType();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCardType() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCardType(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        CardData cardData = this.getCardDataFromResponse();
        cardData.setCardType(string);
        return 1;
    }

    @Override
    public String getCardCVV() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        String string = cardData.getCvv();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCardCVV() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public List<AccountHandler.ADF> getADFList(AccountHandler accountHandler) {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        List<ADF> list = cardData.getAdfList();
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getADFList() not set");
            }
            return null;
        }
        ArrayList<AccountHandler.ADF> arrayList = new ArrayList<AccountHandler.ADF>();
        for (ADF aDF : list) {
            AccountHandler.ADF aDF2 = accountHandler.new AccountHandler.ADF();
            aDF2.aid = aDF.getAid();
            aDF2.issuerCodeTableIndex = aDF.getIssuerCodeTableIndex();
            aDF2.issuerDiscretionaryData = aDF.getIssuerDiscretionaryData();
            aDF2.label = aDF.getLabel();
            aDF2.languagePreference = aDF.getLanguagePreference();
            aDF2.preferredName = aDF.getPreferredName();
            aDF2.priorityIndicator = aDF.getPriorityIndicator();
            aDF2.appTagsExtension = aDF.getAppTagsExtension();
            aDF2.emvTagsExtension = aDF.getEmvTagsExtension();
            arrayList.add(aDF2);
        }
        return arrayList;
    }

    @Override
    public void setADFList(List<AccountHandler.ADF> list) {
        CardData cardData = this.getCardDataFromResponse();
        if (cardData == null) {
            return;
        }
        List<ADF> list2 = cardData.getAdfList();
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setADFList()");
            }
            return;
        }
        for (AccountHandler.ADF aDF : list) {
            ADF aDF2 = new ADF();
            aDF2.setAid(aDF.aid);
            aDF2.setIssuerCodeTableIndex(aDF.issuerCodeTableIndex);
            aDF2.setIssuerDiscretionaryData(aDF.issuerDiscretionaryData);
            aDF2.setAppTagsExtension(aDF.appTagsExtension);
            aDF2.setEmvTagsExtension(aDF.emvTagsExtension);
            aDF2.setLabel(aDF.label);
            aDF2.setLanguagePreference(aDF.languagePreference);
            aDF2.setPreferredName(aDF.preferredName);
            aDF2.setPriorityIndicator(aDF.priorityIndicator);
            list2.add(aDF2);
        }
    }

    @Override
    public String getCardSequenceNumber() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        String string = cardData.getCardSequenceNumber();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCardSequenceNumber() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setCardSequenceNumber(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        CardData cardData = this.getCardDataFromResponse();
        cardData.setCardSequenceNumber(string);
        return 1;
    }

    @Override
    public String getTrack1() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        byte[] byArray = cardData.getTrack1();
        if (byArray == null || byArray.length == 0) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTrack1() not set");
            }
            return null;
        }
        return new String(byArray);
    }

    @Override
    public String getTrack2() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        byte[] byArray = cardData.getTrack2();
        if (byArray == null || byArray.length == 0) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTrack2() not set");
            }
            return null;
        }
        return new String(byArray);
    }

    @Override
    public String getTrack3() {
        CardData cardData = this.getCardDataFromRequest();
        if (cardData == null) {
            return null;
        }
        byte[] byArray = cardData.getTrack3();
        if (byArray == null || byArray.length == 0) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTrack3() not set");
            }
            return null;
        }
        return new String(byArray);
    }

    private SbanData getSBANDataFromRequest() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        MeanOfPaymentComplementaryData meanOfPaymentComplementaryData = meanOfPayment.getComplementaryData();
        if (meanOfPaymentComplementaryData == null) {
            return null;
        }
        SbanData sbanData = meanOfPaymentComplementaryData.getSbanData();
        return sbanData;
    }

    private SbanData getSBANDataFromResponse() {
        SbanData sbanData;
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        if (meanOfPayment == null) {
            return null;
        }
        MeanOfPaymentComplementaryData meanOfPaymentComplementaryData = meanOfPayment.getComplementaryData();
        if (meanOfPaymentComplementaryData == null) {
            meanOfPaymentComplementaryData = new MeanOfPaymentComplementaryData();
            meanOfPayment.setComplementaryData(meanOfPaymentComplementaryData);
        }
        if ((sbanData = meanOfPaymentComplementaryData.getSbanData()) == null) {
            sbanData = new SbanData();
            meanOfPaymentComplementaryData.setSbanData(sbanData);
        }
        return sbanData;
    }

    @Override
    public String getSBANCountryCode() {
        SbanData sbanData = this.getSBANDataFromRequest();
        if (sbanData == null) {
            return null;
        }
        String string = sbanData.getCountryCode();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getSBANCountryCode() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setSBANCountryCode(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        SbanData sbanData = this.getSBANDataFromResponse();
        sbanData.setCountryCode(string);
        return 1;
    }

    @Override
    public String getSBANKey() {
        SbanData sbanData = this.getSBANDataFromRequest();
        if (sbanData == null) {
            return null;
        }
        String string = sbanData.getKey();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getSBANKey() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setSBANKey(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        SbanData sbanData = this.getSBANDataFromResponse();
        sbanData.setKey(string);
        return 1;
    }

    @Override
    public String getSBANBIC() {
        SbanData sbanData = this.getSBANDataFromRequest();
        if (sbanData == null) {
            return null;
        }
        String string = sbanData.getBic();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getSBANBIC() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setSBANBIC(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        SbanData sbanData = this.getSBANDataFromResponse();
        sbanData.setBic(string);
        return 1;
    }

    @Override
    public String getSBANBBAN() {
        SbanData sbanData = this.getSBANDataFromRequest();
        if (sbanData == null) {
            return null;
        }
        String string = sbanData.getBban();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getSBANBBAN() not set");
            }
            return null;
        }
        return string;
    }

    private Context getContextFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        Context context = transactionData.getContext();
        if (context == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getContextFromRequest() context not set");
            }
            return null;
        }
        return context;
    }

    private Context getContextFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getContextFromResponse() pb with transactionData");
            }
            return null;
        }
        Context context = transactionData.getContext();
        if (context == null) {
            context = new Context();
            transactionData.setContext(context);
        }
        return context;
    }

    @Override
    public String getStoreIdentifier() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        return context.getStoreIdentifier();
    }

    @Override
    public int setStoreIdentifier(String string) {
        Context context = this.getContextFromResponse();
        if (context == null) {
            return -1;
        }
        context.setStoreIdentifier(string);
        return 1;
    }

    @Override
    public int getPosNumber() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return -1;
        }
        BigDecimal bigDecimal = context.getPosNumber();
        if (bigDecimal == null) {
            return -1;
        }
        return bigDecimal.intValue();
    }

    @Override
    public int setPosNumber(int n) {
        Context context = this.getContextFromResponse();
        if (context == null) {
            return -1;
        }
        context.setPosNumber(new BigDecimal(n));
        return 1;
    }

    @Override
    public List<String> getNegativeApplicationIdentifierList() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        List<String> list = context.getNegativeApplicationIdentifierList();
        if (list != null && !list.isEmpty()) {
            int n = 0;
            while (n < list.size()) {
                String string = list.get(n);
                if (string != null) {
                    list.set(n, UtilsYP.decryptInfo(string));
                }
                ++n;
            }
        }
        return list;
    }

    @Override
    public List<String> getPositiveApplicationIdentifierList() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        List<String> list = context.getPositiveApplicationIdentifierList();
        if (list != null && !list.isEmpty()) {
            int n = 0;
            while (n < list.size()) {
                String string = list.get(n);
                if (string != null) {
                    list.set(n, UtilsYP.decryptInfo(string));
                }
                ++n;
            }
        }
        return list;
    }

    @Override
    public int setPositiveApplicationIdentifierList(List<String> list) {
        if (list == null || list.isEmpty()) {
            return 0;
        }
        if (list.size() != 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setPositiveApplicationIdentifierList() only one value allowed");
            }
            return -1;
        }
        Context context = this.getContextFromResponse();
        if (context == null) {
            return -1;
        }
        context.getPositiveApplicationIdentifierList().add(list.get(0));
        return 1;
    }

    @Override
    public List<String> getNegativeMerchantIdentifierList() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        return context.getNegativeMerchantIdentifierList();
    }

    @Override
    public List<String> getPositiveMerchantIdentifierList() {
        Context context = this.getContextFromRequest();
        if (context == null) {
            return null;
        }
        return context.getPositiveMerchantIdentifierList();
    }

    @Override
    public int setPositiveMerchantIdentifierList(List<String> list) {
        if (list == null || list.isEmpty()) {
            return 0;
        }
        if (list.size() != 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setPositiveMerchantIdentifierList() only one value allowed");
            }
            return -1;
        }
        Context context = this.getContextFromResponse();
        if (context == null) {
            return -1;
        }
        context.getPositiveMerchantIdentifierList().add(list.get(0));
        return 1;
    }

    private TransactionData getTransactionDataFromRequest() {
        TransactionData transactionData;
        RequestBody requestBody = this.xpdeRequest.getRequestBody();
        if (requestBody == null) {
            return null;
        }
        List<TransactionData> list = requestBody.getTransactionDataList();
        if (list == null || list.isEmpty()) {
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getTransactionDataFromRequest() Only the first transactionData is handled");
        }
        if ((transactionData = list.get(0)) == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTransactionDataFromRequest() pb with transactionData");
            }
            return null;
        }
        return transactionData;
    }

    private TransactionData getTransactionDataFromResponse(boolean bl) {
        TransactionData transactionData;
        List<TransactionData> list;
        ResponseBody responseBody = this.xpdeResponse.getResponseBody();
        if (responseBody == null) {
            responseBody = new ResponseBody();
        }
        if ((list = responseBody.getTransactionDataList()) == null) {
            return null;
        }
        if (list.isEmpty() || bl) {
            transactionData = new TransactionData();
            list.add(transactionData);
        } else {
            transactionData = list.get(list.size() - 1);
        }
        return transactionData;
    }

    private TransactionDetails getTransactionDetailsFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        TransactionDetails transactionDetails = transactionData.getTransactionDetails();
        if (transactionDetails == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionDetailsFromRequest() transactionDetails not set");
            }
            return null;
        }
        return transactionDetails;
    }

    private TransactionDetails getTransactionDetailsFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        TransactionDetails transactionDetails = transactionData.getTransactionDetails();
        if (transactionDetails == null) {
            transactionDetails = new TransactionDetails();
            transactionData.setTransactionDetails(transactionDetails);
        }
        return transactionDetails;
    }

    @Override
    public int getDifferedFlag() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return -1;
        }
        String string = transactionData.getDifferedFlag();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getDifferedFlag() not set");
            }
            return -1;
        }
        try {
            return Integer.parseInt(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDifferedFlag() bad value for differedFlag ???" + string + " " + exception);
            }
            return -1;
        }
    }

    @Override
    public Calendar getUploadTimeStamp() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        String string = transactionData.getUploadTimeStamp();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getUploadTimeStamp() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getUploadTimeStamp() bad date format ? :" + string);
            }
            return null;
        }
    }

    @Override
    public int getShiftNumber() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return -1;
        }
        String string = transactionData.getShiftNumber();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getShiftNumber() not set");
            }
            return -1;
        }
        try {
            return Integer.parseInt(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getShiftNumber() bad value for shiftNumber ???" + string + " " + exception);
            }
            return -1;
        }
    }

    @Override
    public int getSessionNumber() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return -1;
        }
        String string = transactionData.getSessionNumber();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getSessionNumber() not set");
            }
            return -1;
        }
        try {
            return Integer.parseInt(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getSessionNumber() bad value for sessionNumber ???" + string + " " + exception);
            }
            return -1;
        }
    }

    @Override
    public int setDifferedFlag(int n) {
        if (n <= 0) {
            return 0;
        }
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return -1;
        }
        transactionData.setDifferedFlag(Integer.toString(n));
        return 1;
    }

    @Override
    public int setUploadTimeStamp(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return -1;
        }
        transactionData.setUploadTimeStamp(UtilsYP.printDateTime(calendar));
        return 1;
    }

    @Override
    public int setShiftNumber(int n) {
        if (n <= 0) {
            return 0;
        }
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return -1;
        }
        transactionData.setShiftNumber(Integer.toString(n));
        return 1;
    }

    @Override
    public int setSessionNumber(int n) {
        if (n <= 0) {
            return 0;
        }
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return -1;
        }
        transactionData.setSessionNumber(Integer.toString(n));
        return 1;
    }

    private AmountData getAmountDataFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        AmountData amountData = transactionData.getTransactionAmount();
        if (amountData == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getAmountDataFromRequest() amount not set");
            }
            return null;
        }
        return amountData;
    }

    private AmountData getAmountDataFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        AmountData amountData = transactionData.getTransactionAmount();
        if (amountData == null) {
            amountData = new AmountData();
            transactionData.setTransactionAmount(amountData);
        }
        return amountData;
    }

    @Override
    public long getTransactionAmount() {
        AmountData amountData = this.getAmountDataFromRequest();
        if (amountData == null) {
            return -1L;
        }
        BigDecimal bigDecimal = amountData.getAmount();
        if (bigDecimal == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionAmount() not set");
            }
            return -1L;
        }
        try {
            return bigDecimal.longValue();
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTransactionAmount() bad value for amount ???" + bigDecimal + " " + exception);
            }
            return -1L;
        }
    }

    @Override
    public int setTransactionAmount(long l) {
        if (l <= 0L) {
            return 0;
        }
        AmountData amountData = this.getAmountDataFromResponse();
        if (amountData == null) {
            return -1;
        }
        amountData.setAmount(new BigDecimal(l));
        return 1;
    }

    @Override
    public String getTransactionCurrencyAlpha() {
        AmountData amountData = this.getAmountDataFromRequest();
        if (amountData == null) {
            return null;
        }
        String string = amountData.getCurrencyAlpha();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionCurrencyAlpha() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setTransactionCurrencyAlpha(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        AmountData amountData = this.getAmountDataFromResponse();
        if (amountData == null) {
            return -1;
        }
        amountData.setCurrencyAlpha(string);
        return 1;
    }

    @Override
    public int getTransactionCurrencyNumerical() {
        AmountData amountData = this.getAmountDataFromRequest();
        if (amountData == null) {
            return -1;
        }
        BigDecimal bigDecimal = amountData.getCurrencyNumerical();
        if (bigDecimal == null) {
            return -1;
        }
        return bigDecimal.intValue();
    }

    @Override
    public int setTransactionCurrencyNumerical(int n) {
        if (n <= 0) {
            return 0;
        }
        AmountData amountData = this.getAmountDataFromResponse();
        if (amountData == null) {
            return -1;
        }
        amountData.setCurrencyNumerical(new BigDecimal(n));
        return 1;
    }

    @Override
    public int getTransactionCurrencyFraction() {
        AmountData amountData = this.getAmountDataFromRequest();
        if (amountData == null) {
            return -1;
        }
        BigDecimal bigDecimal = amountData.getCurrencyFraction();
        if (bigDecimal == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionCurrencyFraction() not set");
            }
            return -1;
        }
        try {
            return bigDecimal.intValue();
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTransactionCurrencyFraction() bad value for currencyFraction ???" + bigDecimal + " " + exception);
            }
            return -1;
        }
    }

    @Override
    public int setTransactionCurrencyFraction(int n) {
        if (n < 0) {
            return 0;
        }
        AmountData amountData = this.getAmountDataFromResponse();
        if (amountData == null) {
            return -1;
        }
        amountData.setCurrencyFraction(new BigDecimal(n));
        return 1;
    }

    @Override
    public String getTransactionAmountAlpha() {
        AmountData amountData = this.getAmountDataFromRequest();
        if (amountData == null) {
            return null;
        }
        String string = amountData.getAmountAlpha();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionAmountAlpha() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setTransactionAmountAlpha(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        AmountData amountData = this.getAmountDataFromResponse();
        if (amountData == null) {
            return -1;
        }
        amountData.setAmountAlpha(string);
        return 1;
    }

    private TransactionIdentifierData getTransactionIdentifierFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        TransactionIdentifierData transactionIdentifierData = transactionData.getTransactionIdentifierData();
        if (transactionIdentifierData == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionIdentifierFromRequest() transactionIdentifierData not set");
            }
            return null;
        }
        return transactionIdentifierData;
    }

    private TransactionIdentifierData getTransactionIdentifierFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        TransactionIdentifierData transactionIdentifierData = transactionData.getTransactionIdentifierData();
        if (transactionIdentifierData == null) {
            transactionIdentifierData = new TransactionIdentifierData();
            transactionData.setTransactionIdentifierData(transactionIdentifierData);
        }
        return transactionIdentifierData;
    }

    @Override
    public String getTransactionNumber() {
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        return systemTransactionIdentifier.getTransactionIdentifier();
    }

    @Override
    public int setTransactionNumber(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setPaymentTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionIdentifier(string);
        return 1;
    }

    @Override
    public Calendar getTransactionAppliLocalTime() {
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        String string = systemTransactionIdentifier.getTransactionLocalTime();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTransactionAppliLocalTime() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTransactionAppliLocalTime() bad date format ? :" + string);
            }
            return null;
        }
    }

    @Override
    public int setTransactionAppliLocalTime(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setPaymentTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionLocalTime(UtilsYP.printDateTime(calendar));
        if (systemTransactionIdentifier.getTransactionIdentifier() == null) {
            systemTransactionIdentifier.setTransactionIdentifier("");
        }
        return 1;
    }

    @Override
    public String getMerchantTransactionIdentifier() {
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        return systemTransactionIdentifier.getTransactionIdentifier();
    }

    @Override
    public int setMerchantTransactionIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setMerchantTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionIdentifier(string);
        return 1;
    }

    @Override
    public Calendar getMerchantTransactionTime() {
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        String string = systemTransactionIdentifier.getTransactionLocalTime();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMerchantTransactionTime() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMerchantTransactionTime() bad date format ? :" + string + " " + exception);
            }
            return null;
        }
    }

    @Override
    public int setMerchantTransactionTime(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setMerchantTransactionIdentifier(systemTransactionIdentifier);
            systemTransactionIdentifier.setTransactionIdentifier("");
        }
        systemTransactionIdentifier.setTransactionLocalTime(UtilsYP.printDateTime(calendar));
        return 1;
    }

    private TransactionIdentifierData getReferenceTransactionIdentifierFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        TransactionIdentifierData transactionIdentifierData = transactionData.getReferenceTransactionIdentifierData();
        if (transactionIdentifierData == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getReferenceTransactionIdentifierFromRequest() referenceTransactionIdentifier not set");
            }
            return null;
        }
        return transactionIdentifierData;
    }

    private TransactionIdentifierData getReferenceTransactionIdentifierFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        TransactionIdentifierData transactionIdentifierData = transactionData.getReferenceTransactionIdentifierData();
        if (transactionIdentifierData == null) {
            transactionIdentifierData = new TransactionIdentifierData();
            transactionData.setReferenceTransactionIdentifierData(transactionIdentifierData);
        }
        return transactionIdentifierData;
    }

    @Override
    public String getReferenceTransactionNumber() {
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        return systemTransactionIdentifier.getTransactionIdentifier();
    }

    @Override
    public int setReferenceTransactionNumber(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setPaymentTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionIdentifier(string);
        return 1;
    }

    @Override
    public Calendar getReferenceTransactionAppliLocalTime() {
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        String string = systemTransactionIdentifier.getTransactionLocalTime();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getReferenceTransactionAppliLocalTime() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getReferenceTransactionAppliLocalTime() bad date format ? :" + string);
            }
            return null;
        }
    }

    @Override
    public int setReferenceTransactionAppliLocalTime(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getPaymentTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setPaymentTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionLocalTime(UtilsYP.printDateTime(calendar));
        return 1;
    }

    @Override
    public String getReferenceMerchantTransactionIdentifier() {
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        return systemTransactionIdentifier.getTransactionIdentifier();
    }

    @Override
    public int setReferenceMerchantTransactionIdentifier(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setMerchantTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionIdentifier(string);
        return 1;
    }

    @Override
    public Calendar getReferenceMerchantTransactionTime() {
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromRequest();
        if (transactionIdentifierData == null) {
            return null;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            return null;
        }
        String string = systemTransactionIdentifier.getTransactionLocalTime();
        if (string == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getReferenceMerchantTransactionTime() not set");
            }
            return null;
        }
        try {
            return UtilsYP.parseDateTime(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getReferenceMerchantTransactionTime() bad date format ? :" + string);
            }
            return null;
        }
    }

    @Override
    public int setReferenceMerchantTransactionTime(Calendar calendar) {
        if (calendar == null || calendar.getTimeInMillis() == 0L) {
            return 0;
        }
        TransactionIdentifierData transactionIdentifierData = this.getReferenceTransactionIdentifierFromResponse();
        if (transactionIdentifierData == null) {
            return -1;
        }
        SystemTransactionIdentifier systemTransactionIdentifier = transactionIdentifierData.getMerchantTransactionIdentifier();
        if (systemTransactionIdentifier == null) {
            systemTransactionIdentifier = new SystemTransactionIdentifier();
            transactionIdentifierData.setMerchantTransactionIdentifier(systemTransactionIdentifier);
        }
        systemTransactionIdentifier.setTransactionLocalTime(UtilsYP.printDateTime(calendar));
        return 1;
    }

    @Override
    public int setTicket(String string) {
        byte[] byArray;
        byte[] byArray2;
        if (string == null || string.isEmpty()) {
            return 0;
        }
        try {
            byArray2 = string.getBytes("UTF-8");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            return -1;
        }
        PrintOutput printOutput = this.xpdeResponse.getResponseBody().getPrintOutput();
        if (printOutput == null) {
            this.xpdeResponse.getResponseBody().setPrintOutput(new PrintOutput());
        }
        if ((byArray = this.xpdeResponse.getResponseBody().getPrintOutput().getTicket()) == null) {
            this.xpdeResponse.getResponseBody().getPrintOutput().setTicket(byArray2);
        } else {
            byte[] byArray3 = new byte[byArray.length + string.length()];
            System.arraycopy(byArray, 0, byArray3, 0, byArray.length);
            System.arraycopy(byArray2, 0, byArray3, byArray.length, string.length());
            this.xpdeResponse.getResponseBody().getPrintOutput().setTicket(byArray3);
        }
        return 1;
    }

    @Override
    public String get(String string) {
        if (string.contentEquals("name")) {
            return this.xpdeRequest.getRequestBody().getAdminData().getDataContainerList().get(0).getName();
        }
        if (string.contentEquals("preferredName")) {
            return this.xpdeRequest.getRequestBody().getAdminData().getDataContainerList().get(0).getPreferredName();
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "get() unknown : " + string);
        }
        return null;
    }

    @Override
    public int setXMLResponse(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        byte[] byArray = this.xpdeResponse.getResponseBody().getXmlResponse();
        if (byArray == null) {
            this.xpdeResponse.getResponseBody().setXmlResponse(string.getBytes());
        } else {
            byte[] byArray2 = new byte[byArray.length + string.length()];
            System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
            System.arraycopy(string.getBytes(), 0, byArray2, byArray.length, string.length());
            this.xpdeResponse.getResponseBody().setXmlResponse(byArray2);
        }
        return 1;
    }

    private User getUserFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        User user = transactionData.getUser();
        if (user == null && this.getLogLevel() >= 6) {
            this.logger(6, "getUserFromRequest() user not set");
        }
        return user;
    }

    private User getUserFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        User user = transactionData.getUser();
        if (user == null) {
            user = new User();
            transactionData.setUser(user);
        }
        return user;
    }

    private PersonDetails getUserPersonDetailsFromRequest() {
        User user = this.getUserFromRequest();
        if (user == null) {
            return null;
        }
        PersonDetails personDetails = user.getPersonDetails();
        if (personDetails == null && this.getLogLevel() >= 6) {
            this.logger(6, "getUserPersonDetailsFromRequest() personDetails not set");
        }
        return personDetails;
    }

    private PersonDetails getUserPersonDetailsFromResponse() {
        if (this.getUserPersonDetailsFromRequest() == null) {
            return null;
        }
        User user = this.getUserFromResponse();
        if (user == null) {
            return null;
        }
        PersonDetails personDetails = user.getPersonDetails();
        if (personDetails == null) {
            personDetails = new PersonDetails();
            user.setPersonDetails(personDetails);
        }
        return personDetails;
    }

    @Override
    public String getUserUID() {
        User user;
        block3: {
            try {
                user = this.getUserFromRequest();
                if (user != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return user.getUid();
    }

    @Override
    public int setUserUID(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        User user = this.getUserFromResponse();
        if (user == null) {
            return -1;
        }
        user.setUid(string);
        return 1;
    }

    @Override
    public String getUserToken() {
        User user;
        block3: {
            try {
                user = this.getUserFromRequest();
                if (user != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return user.getToken();
    }

    @Override
    public int setUserToken(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        User user = this.getUserFromResponse();
        if (user == null) {
            return -1;
        }
        user.setToken(string);
        return 1;
    }

    @Override
    public String getUserPasswd() {
        User user;
        block3: {
            try {
                user = this.getUserFromRequest();
                if (user != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return user.getPasswd();
    }

    @Override
    public int setUserPasswd(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        User user = this.getUserFromResponse();
        if (user == null) {
            return -1;
        }
        user.setPasswd(string);
        return 1;
    }

    @Override
    public String getUserPreferredLanguage() {
        PersonDetails personDetails;
        block3: {
            try {
                personDetails = this.getUserPersonDetailsFromRequest();
                if (personDetails != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return personDetails.getLanguage();
    }

    @Override
    public int setUserPreferredLanguage(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getUserPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setLanguage(string);
        return 1;
    }

    @Override
    public String getUserFirstName() {
        PersonDetails personDetails;
        block3: {
            try {
                personDetails = this.getUserPersonDetailsFromRequest();
                if (personDetails != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return personDetails.getFirstName();
    }

    @Override
    public int setUserFirstName(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getUserPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setFirstName(string);
        return 1;
    }

    @Override
    public String getUserLastName() {
        PersonDetails personDetails;
        block3: {
            try {
                personDetails = this.getUserPersonDetailsFromRequest();
                if (personDetails != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return personDetails.getLastName();
    }

    @Override
    public int setUserLastName(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        PersonDetails personDetails = this.getUserPersonDetailsFromResponse();
        if (personDetails == null) {
            return -1;
        }
        personDetails.setLastName(string);
        return 1;
    }

    @Override
    public String getViewName() {
        SetDataRequest setDataRequest;
        if (this.xpdeRequest == null) {
            return null;
        }
        RequestBody requestBody = this.xpdeRequest.getRequestBody();
        if (requestBody == null) {
            return null;
        }
        String string = this.xpdeRequest.getMessageHeader().getMessageType();
        if (string.contentEquals(MessageTypeEnumeration.GET_DATA.xmlValue())) {
            GetDataRequest getDataRequest = requestBody.getGetDataRequest();
            if (getDataRequest != null) {
                return getDataRequest.getViewName();
            }
        } else if (string.contentEquals(MessageTypeEnumeration.SET_DATA.xmlValue())) {
            SetDataRequest setDataRequest2 = requestBody.getSetDataRequest();
            if (setDataRequest2 != null) {
                return setDataRequest2.getViewName();
            }
        } else if (string.contentEquals(MessageTypeEnumeration.CREATE_DATA.xmlValue()) && (setDataRequest = requestBody.getSetDataRequest()) != null) {
            return setDataRequest.getViewName();
        }
        return null;
    }

    @Override
    public int getStartIndex() {
        if (this.xpdeRequest == null) {
            return -1;
        }
        RequestBody requestBody = this.xpdeRequest.getRequestBody();
        if (requestBody == null) {
            return -1;
        }
        GetDataRequest getDataRequest = requestBody.getGetDataRequest();
        if (getDataRequest == null) {
            return -1;
        }
        Integer n = getDataRequest.getStartRecordNumber();
        if (n == null) {
            return 0;
        }
        return n;
    }

    @Override
    public int getMaxRecords() {
        if (this.xpdeRequest == null) {
            return -1;
        }
        RequestBody requestBody = this.xpdeRequest.getRequestBody();
        if (requestBody == null) {
            return -1;
        }
        GetDataRequest getDataRequest = requestBody.getGetDataRequest();
        if (getDataRequest == null) {
            return -1;
        }
        Integer n = getDataRequest.getMaxRecords();
        if (n == null) {
            return -1;
        }
        return n;
    }

    @Override
    public int createGetDataResponse(String string, int n, int n2, boolean bl) {
        String string2;
        if (this.xpdeResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createGetDataResponse()");
            }
            return -1;
        }
        ResponseBody responseBody = this.xpdeResponse.getResponseBody();
        if (responseBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createGetDataResponse()");
            }
            return -1;
        }
        GetDataResponse getDataResponse = new GetDataResponse();
        responseBody.setGetDataResponse(getDataResponse);
        getDataResponse.setMoreRecord(bl);
        getDataResponse.setNbRecords(n2);
        GetDataHeader getDataHeader = new GetDataHeader();
        getDataResponse.setHeader(getDataHeader);
        GetDataBody getDataBody = new GetDataBody();
        getDataResponse.setBody(getDataBody);
        if (this.xpdeRequest == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createGetDataResponse()");
            }
            return -1;
        }
        RequestBody requestBody = this.xpdeRequest.getRequestBody();
        if (requestBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createGetDataResponse()");
            }
            return -1;
        }
        getDataResponse.setViewName(string);
        GetDataRequest getDataRequest = requestBody.getGetDataRequest();
        if (getDataRequest != null && (string2 = getDataRequest.getIdRow()) != null) {
            getDataResponse.setIdRow(string2);
        }
        return 1;
    }

    @Override
    public int addColumnToResponse(int n, String string, String string2, String string3, Map<String, String> map) {
        if (this.xpdeResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addColumnToResponse()");
            }
            return -1;
        }
        ResponseBody responseBody = this.xpdeResponse.getResponseBody();
        if (responseBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addColumnToResponse()");
            }
            return -1;
        }
        GetDataResponse getDataResponse = responseBody.getGetDataResponse();
        if (getDataResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addColumnToResponse()");
            }
            return -1;
        }
        GetDataHeader getDataHeader = getDataResponse.getHeader();
        if (getDataHeader == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addColumnToResponse()");
            }
            return -1;
        }
        List<Column> list = getDataHeader.getColumnList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addColumnToResponse()");
            }
            return -1;
        }
        Column column = new Column();
        column.setRank(n);
        column.setFormat(string3);
        column.setId(string);
        column.setLabel(string2);
        if (map != null && !map.isEmpty()) {
            List<org.yp.xml.jibx.xpde.Property> list2 = column.getPropertyList();
            for (Map.Entry<String, String> entry : map.entrySet()) {
                org.yp.xml.jibx.xpde.Property property = new org.yp.xml.jibx.xpde.Property();
                property.setKey(entry.getKey());
                property.setValue(entry.getValue());
                list2.add(property);
            }
        }
        if (list.isEmpty()) {
            list.add(column);
        } else {
            boolean bl = false;
            int n2 = 0;
            while (n2 < list.size()) {
                if (list.get(n2).getRank() > column.getRank()) {
                    list.add(n2, column);
                    bl = true;
                    break;
                }
                ++n2;
            }
            if (!bl) {
                list.add(column);
            }
        }
        return 1;
    }

    @Override
    public int addRowToResponse(YP_Row yP_Row) {
        if (this.xpdeResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        ResponseBody responseBody = this.xpdeResponse.getResponseBody();
        if (responseBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        GetDataResponse getDataResponse = responseBody.getGetDataResponse();
        if (getDataResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        GetDataBody getDataBody = getDataResponse.getBody();
        if (getDataBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        List<Row> list = getDataBody.getRowList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        Row row = new Row();
        row.setId(UtilsYP.devHexa(this.idXOR(String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey()).getBytes()));
        List<RowField> list2 = row.getFieldList();
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addRowToResponse()");
            }
            return -1;
        }
        Field[] fieldArray = yP_Row.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            Field field = fieldArray[n2];
            RowField rowField = new RowField();
            rowField.setId(field.getName());
            rowField.setVal(yP_Row.getFieldStringValue(field));
            list2.add(rowField);
            ++n2;
        }
        list.add(row);
        return 1;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public int addViewContentToResponse(YP_View yP_View, int n, int n2) {
        Object object;
        if (this.xpdeResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        ResponseBody responseBody = this.xpdeResponse.getResponseBody();
        if (responseBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        GetDataResponse getDataResponse = responseBody.getGetDataResponse();
        if (getDataResponse == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        GetDataHeader getDataHeader = getDataResponse.getHeader();
        if (getDataHeader == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        GetDataBody getDataBody = getDataResponse.getBody();
        if (getDataBody == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        List<Row> list = getDataBody.getRowList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addViewContentToResponse()");
            }
            return -1;
        }
        boolean bl = false;
        try {
            MessageHeader messageHeader;
            if (this.xpdeRequest != null && (messageHeader = this.xpdeRequest.getMessageHeader()) != null && (object = this.xpdeRequest.getMessageHeader().getProtocolVersion()) != null && !((String)object).isEmpty() && Integer.parseInt((String)object) > 1) {
                bl = true;
            }
        }
        catch (Exception exception) {
            this.logger(2, "addViewContentToResponse() ignored " + exception);
        }
        int n3 = n;
        while (n3 < n + n2) {
            block63: {
                List<Object> list2;
                block61: {
                    List<org.yp.xml.jibx.xpde.Property> list3;
                    object = new Row();
                    ((Row)object).setId(UtilsYP.devHexa(this.idXOR(yP_View.getRowIDAt(n3)).getBytes()));
                    ((Row)object).setActionable(yP_View.isRowActionableAt(n3));
                    List<YP_TCD_DC_Context.Action> list4 = yP_View.getRowActionList(n3);
                    if (list4 != null) {
                        list2 = ((Row)object).getActionList();
                        for (YP_TCD_DC_Context.Action action : list4) {
                            Action action2 = new Action();
                            action2.setApplicationIdentifier(UtilsYP.cryptInfo(action.applicationIdentifier));
                            action2.setFormName(action.formName);
                            action2.setId(action.id);
                            action2.setLabel(action.label);
                            if (action.propertiesList != null) {
                                list3 = action2.getPropertyList();
                                for (Property property : action.propertiesList) {
                                    org.yp.xml.jibx.xpde.Property property2 = new org.yp.xml.jibx.xpde.Property();
                                    property2.setKey(property.getName());
                                    property2.setValue(property.getValue());
                                    list3.add(property2);
                                }
                            }
                            list2.add(action2);
                        }
                    }
                    if ((list2 = ((Row)object).getFieldList()) == null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "addViewContentToResponse()");
                        }
                        return -1;
                    }
                    if (bl) break block61;
                    for (Column column : getDataHeader.getColumnList()) {
                        void var16_26;
                        String string = yP_View.getFieldValueAt(n3, column.getId());
                        if (string == null && yP_View.isColumnOnlyIfNotNull(column.getId())) continue;
                        list3 = new RowField();
                        ((RowField)((Object)list3)).setId(column.getId());
                        switch (column.getId()) {
                            case "applicationName": 
                            case "merchantIdentifier": 
                            case "brandName": 
                            case "applicationIdentifier": 
                            case "contractIdentifier": 
                            case "merchantName": {
                                String string2 = UtilsYP.cryptInfo(string);
                            }
                        }
                        ((RowField)((Object)list3)).setVal((String)var16_26);
                        list2.add(list3);
                    }
                    break block63;
                }
                StringBuilder stringBuilder = new StringBuilder();
                boolean bl2 = true;
                for (Column column : getDataHeader.getColumnList()) {
                    void var18_38;
                    String string = yP_View.getFieldValueAt(n3, column.getId());
                    if (string == null) {
                        String string3 = "";
                    }
                    switch (column.getId()) {
                        case "applicationName": 
                        case "merchantIdentifier": 
                        case "brandName": 
                        case "applicationIdentifier": 
                        case "contractIdentifier": 
                        case "merchantName": {
                            void var18_36;
                            String string4 = UtilsYP.cryptInfo((String)var18_36);
                        }
                    }
                    if (!bl2) {
                        stringBuilder.append(",");
                    } else {
                        bl2 = false;
                    }
                    String string6 = var18_38.replace("/", "//");
                    string6 = string6.replace(",", "/.");
                    stringBuilder.append(string6);
                }
                RowField rowField = new RowField();
                rowField.setId("concatenatedFields");
                rowField.setVal(stringBuilder.toString());
                list2.add((Action)((Object)rowField));
            }
            list.add((Row)object);
            ++n3;
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<YP_Gabarit> getSearchGabarit() {
        try {
            if (this.xpdeRequest == null) {
                return null;
            }
            RequestBody requestBody = this.xpdeRequest.getRequestBody();
            if (requestBody == null) {
                return null;
            }
            GetDataRequest getDataRequest = requestBody.getGetDataRequest();
            if (getDataRequest == null) {
                return null;
            }
            ArrayList<YP_Gabarit> arrayList = new ArrayList<YP_Gabarit>();
            String string = getDataRequest.getIdRow();
            if (string != null && !string.isEmpty()) {
                String[] stringArray = (string = this.idXOR(new String(UtilsYP.redHexa(string)))).split("#");
                if (stringArray.length >= 3) {
                    YP_Gabarit yP_Gabarit = new YP_Gabarit(stringArray[1], YP_ComplexGabarit.OPERATOR.EQUAL, (Object)Long.parseLong(stringArray[2]));
                    yP_Gabarit.fullTableName = stringArray[0];
                    arrayList.add(yP_Gabarit);
                    return arrayList;
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSearchGabarit() bad idRow:" + string);
                }
                return null;
            }
            FilterData filterData = getDataRequest.getFilterData();
            if (filterData == null || filterData.getFilterValueList() == null || filterData.getFilterValueList().isEmpty()) {
                return arrayList;
            }
            block23: for (FilterValue filterValue : filterData.getFilterValueList()) {
                FilterCriteriaEnumeration filterCriteriaEnumeration = filterValue.getCondition();
                if (filterCriteriaEnumeration == null) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getSearchGabarit() bad filter");
                    continue;
                }
                List<RowField> list = filterValue.getFieldList();
                if (list == null || list.isEmpty()) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getSearchGabarit() bad filter");
                    continue;
                }
                RowField rowField = list.get(0);
                if (rowField == null) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getSearchGabarit() bad filter");
                    continue;
                }
                if (list.size() > 1 && filterCriteriaEnumeration != FilterCriteriaEnumeration.IN && filterCriteriaEnumeration != FilterCriteriaEnumeration.IN_AFTER_GROUP) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getSearchGabarit() Only IN can have more than one value");
                    continue;
                }
                String string2 = rowField.getId();
                if (string2 == null || string2.isEmpty()) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getSearchGabarit() bad filter name");
                    continue;
                }
                block1 : switch (filterCriteriaEnumeration) {
                    case CONTAINS: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.CONTAIN, (Object)rowField.getVal()));
                        break;
                    }
                    case EQUALS: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.EQUAL, (Object)rowField.getVal()));
                        break;
                    }
                    case EQUALS_IGNORE_CASE: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, (Object)rowField.getVal()));
                        break;
                    }
                    case IN: {
                        String[] stringArray = new String[list.size()];
                        int n = 0;
                        while (true) {
                            if (n >= stringArray.length) {
                                arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.IN, (Object)stringArray));
                                break block1;
                            }
                            stringArray[n] = list.get(n).getVal();
                            ++n;
                        }
                    }
                    case GREATER: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.GREATER, (Object)rowField.getVal()));
                        break;
                    }
                    case GREATER_OR_EQUAL: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, (Object)rowField.getVal()));
                        break;
                    }
                    case LESS: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.LESS, (Object)rowField.getVal()));
                        break;
                    }
                    case LESS_OR_EQUAL: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, (Object)rowField.getVal()));
                        break;
                    }
                    case MAX: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.MAX));
                        break;
                    }
                    case MIN: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.MIN));
                        break;
                    }
                    case STARTS_WITH: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.START_WITH, (Object)rowField.getVal()));
                        break;
                    }
                    case MATCH_BEGINING: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, (Object)rowField.getVal()));
                        break;
                    }
                    case DIFFERENT: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.DIFFERENT, (Object)rowField.getVal()));
                        break;
                    }
                    case ASC_ORDER: 
                    case ASC_ORDER1: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.ORDER_ASC));
                        break;
                    }
                    case DESC_ORDER: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.ORDER_DESC));
                        break;
                    }
                    case GROUP: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.GROUP));
                        break;
                    }
                    case EQUALS_AFTER_GROUP: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, (Object)rowField.getVal()));
                        break;
                    }
                    case DIFFERENT_AFTER_GROUP: {
                        arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, (Object)rowField.getVal()));
                        break;
                    }
                    case IN_AFTER_GROUP: {
                        String[] stringArray = new String[list.size()];
                        int n = 0;
                        while (true) {
                            if (n >= stringArray.length) {
                                arrayList.add(new YP_Gabarit(string2, YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, (Object)stringArray));
                                break block1;
                            }
                            stringArray[n] = list.get(n).getVal();
                            ++n;
                        }
                    }
                    default: {
                        if (this.getLogLevel() < 2) continue block23;
                        this.logger(2, "getSearchGabarit() unknown condition");
                    }
                }
            }
            return arrayList;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getSearchGabarit() " + exception);
            }
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int updateViewHeaderFromRequest(YP_View yP_View) {
        try {
            if (this.xpdeRequest == null) {
                return -1;
            }
            RequestBody requestBody = this.xpdeRequest.getRequestBody();
            if (requestBody == null) {
                return -1;
            }
            SetDataRequest setDataRequest = requestBody.getSetDataRequest();
            if (setDataRequest == null) {
                return -1;
            }
            SetDataHeader setDataHeader = setDataRequest.getHeader();
            if (setDataHeader == null) {
                return 0;
            }
            List<Column> list = setDataHeader.getColumnList();
            if (list == null) {
                return -1;
            }
            if (list.isEmpty()) {
                return 0;
            }
            int n = 0;
            while (true) {
                List<org.yp.xml.jibx.xpde.Property> list2;
                if (n >= list.size()) {
                    return 1;
                }
                Column column = list.get(n);
                Integer n2 = column.getRank();
                if (n2 != null) {
                    yP_View.setColumnRank(column.getId(), n2);
                }
                if ((list2 = column.getPropertyList()) != null && !list2.isEmpty()) {
                    Map<String, String> map = yP_View.getColumnProperties(column.getId());
                    if (map == null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "updateViewHeaderFromRequest() unable to get properties of column " + column.getId());
                        }
                        return -1;
                    }
                    for (org.yp.xml.jibx.xpde.Property property : list2) {
                        map.put(property.getKey(), property.getValue());
                    }
                }
                ++n;
            }
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateViewHeaderFromRequest()  " + exception);
            }
            return -1;
        }
    }

    @Override
    public int updateViewContentFromRequest(YP_View yP_View) {
        List<Row> list;
        block49: {
            block48: {
                SetDataBody setDataBody;
                block47: {
                    SetDataRequest setDataRequest;
                    block46: {
                        RequestBody requestBody;
                        block45: {
                            block44: {
                                if (this.xpdeRequest != null) break block44;
                                return -1;
                            }
                            requestBody = this.xpdeRequest.getRequestBody();
                            if (requestBody != null) break block45;
                            return -1;
                        }
                        setDataRequest = requestBody.getSetDataRequest();
                        if (setDataRequest != null) break block46;
                        return -1;
                    }
                    setDataBody = setDataRequest.getBody();
                    if (setDataBody != null) break block47;
                    return 0;
                }
                list = setDataBody.getRowList();
                if (list != null) break block48;
                return -1;
            }
            if (!list.isEmpty()) break block49;
            return 0;
        }
        try {
            int n = 0;
            while (n < list.size()) {
                List<Action> object22;
                Row row;
                block50: {
                    row = list.get(n);
                    String string = row.getId();
                    if (string == null || string.isEmpty()) {
                        yP_View.setRowID(n, string);
                    } else {
                        yP_View.setRowID(n, new String(this.idXOR(new String(UtilsYP.redHexa(string)))));
                    }
                    List<RowField> list2 = row.getFieldList();
                    if (list2 == null) break block50;
                    for (RowField rowField : list2) {
                        Object object = rowField.getVal();
                        switch (rowField.getId()) {
                            case "applicationName": 
                            case "merchantIdentifier": 
                            case "brandName": 
                            case "applicationIdentifier": 
                            case "idContract": 
                            case "idMerchant": 
                            case "value": 
                            case "contractIdentifier": 
                            case "merchantName": 
                            case "idBrand": 
                            case "idStore": {
                                object = UtilsYP.decryptInfo((String)object);
                            }
                        }
                        yP_View.addFieldValue(n, rowField.getId(), (String)object);
                    }
                }
                if ((object22 = row.getActionList()) != null && !object22.isEmpty()) {
                    ArrayList arrayList = new ArrayList();
                    yP_View.setRowActionList(n, arrayList);
                    for (Object object : object22) {
                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                        action.applicationIdentifier = UtilsYP.decryptInfo(((Action)object).getApplicationIdentifier());
                        action.formName = ((Action)object).getFormName();
                        action.id = ((Action)object).getId();
                        action.label = ((Action)object).getLabel();
                        List<org.yp.xml.jibx.xpde.Property> list2 = ((Action)object).getPropertyList();
                        if (list2 != null && !list2.isEmpty()) {
                            ArrayList<Property> arrayList2 = new ArrayList<Property>();
                            for (org.yp.xml.jibx.xpde.Property property : list2) {
                                Property property2 = new Property();
                                property2.setName(property.getKey());
                                property2.setValue(property.getValue());
                                arrayList2.add(property2);
                            }
                            action.propertiesList = arrayList2;
                        }
                        arrayList.add(action);
                    }
                }
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateViewContentFromRequest() " + exception);
            }
            return -1;
        }
    }

    private RetrievalReferenceData getRetrievalReferenceDataFromRequest() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        RetrievalReferenceData retrievalReferenceData = transactionData.getRetrievalReferenceData();
        if (retrievalReferenceData == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getRetrievalReferenceDataFromRequest() RetrievalReferenceData not set");
            }
            return null;
        }
        return retrievalReferenceData;
    }

    private RetrievalReferenceData getRetrievalReferenceDataFromResponse() {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return null;
        }
        RetrievalReferenceData retrievalReferenceData = transactionData.getRetrievalReferenceData();
        if (retrievalReferenceData == null) {
            retrievalReferenceData = new RetrievalReferenceData();
            transactionData.setRetrievalReferenceData(retrievalReferenceData);
        }
        return retrievalReferenceData;
    }

    @Override
    public String getReservationReference() {
        RetrievalReferenceData retrievalReferenceData = this.getRetrievalReferenceDataFromRequest();
        if (retrievalReferenceData == null) {
            return null;
        }
        String string = retrievalReferenceData.getReservationReference();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "reservationReference() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public int setReservationReference(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        RetrievalReferenceData retrievalReferenceData = this.getRetrievalReferenceDataFromResponse();
        retrievalReferenceData.setReservationReference(string);
        return 1;
    }

    @Override
    public ReservationStatusEnumeration getReservationStatus() {
        RetrievalReferenceData retrievalReferenceData = this.getRetrievalReferenceDataFromRequest();
        if (retrievalReferenceData == null) {
            return null;
        }
        String string = retrievalReferenceData.getStatus();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "reservationStatus() not set");
            }
            return null;
        }
        if (string.contentEquals(ReservationStatusEnumeration.ADDITIONAL.toString())) {
            return ReservationStatusEnumeration.ADDITIONAL;
        }
        if (string.contentEquals(ReservationStatusEnumeration.CANCELED.toString())) {
            return ReservationStatusEnumeration.CANCELED;
        }
        if (string.contentEquals(ReservationStatusEnumeration.CLOSED.toString())) {
            return ReservationStatusEnumeration.CLOSED;
        }
        if (string.contentEquals(ReservationStatusEnumeration.COMPLEMENTARY.toString())) {
            return ReservationStatusEnumeration.COMPLEMENTARY;
        }
        if (string.contentEquals(ReservationStatusEnumeration.INITIAL.toString())) {
            return ReservationStatusEnumeration.INITIAL;
        }
        if (string.contentEquals(ReservationStatusEnumeration.UNKNOWN.toString())) {
            return ReservationStatusEnumeration.UNKNOWN;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "reservationStatus() unknown :" + string);
        }
        return null;
    }

    @Override
    public int setReservationStatus(ReservationStatusEnumeration reservationStatusEnumeration) {
        if (reservationStatusEnumeration == null) {
            return 0;
        }
        RetrievalReferenceData retrievalReferenceData = this.getRetrievalReferenceDataFromResponse();
        retrievalReferenceData.setStatus(reservationStatusEnumeration.toString());
        return 1;
    }

    @Override
    public String getAppTags() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        return transactionData.getAppTags();
    }

    @Override
    public void setAppTags(String string) {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return;
        }
        transactionData.setAppTags(string);
    }

    @Override
    public String getEMVTags() {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        return transactionData.getEmvTags();
    }

    @Override
    public void setEMVTags(String string) {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return;
        }
        transactionData.setEmvTags(string);
    }

    @Override
    public EntryModeEnumeration getEntryMode() {
        String string;
        block23: {
            MeanOfPayment meanOfPayment;
            block22: {
                try {
                    meanOfPayment = this.getMeanOfPaymentFromRequest();
                    if (meanOfPayment != null) break block22;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            string = meanOfPayment.getEntryMode();
            if (string != null && !string.isEmpty()) break block23;
            return null;
        }
        if (string.toUpperCase().contentEquals("ENTRY_MODE_MANUAL")) {
            return EntryModeEnumeration.ENTRY_MODE_MANUAL;
        }
        if (string.contentEquals("ENTRY_MODE_RFID")) {
            return EntryModeEnumeration.ENTRY_MODE_RFID;
        }
        if (string.contentEquals("ENTRY_MODE_KEYED")) {
            return EntryModeEnumeration.ENTRY_MODE_KEYED;
        }
        if (string.contentEquals("ENTRY_MODE_FILE")) {
            return EntryModeEnumeration.ENTRY_MODE_FILE;
        }
        if (string.contentEquals("ENTRY_MODE_SCANNED")) {
            return EntryModeEnumeration.ENTRY_MODE_SCANNED;
        }
        if (string.contentEquals("ENTRY_MODE_MAGSTRIPE")) {
            return EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE;
        }
        if (string.contentEquals("ENTRY_MODE_MAGSTRIPE_FALLBACK")) {
            return EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE_FALLBACK;
        }
        if (string.contentEquals("ENTRY_MODE_ICC")) {
            return EntryModeEnumeration.ENTRY_MODE_ICC;
        }
        if (string.contentEquals("ENTRY_MODE_SYNC_ICC")) {
            return EntryModeEnumeration.ENTRY_MODE_SYNC_ICC;
        }
        if (string.contentEquals("ENTRY_MODE_TAPPED")) {
            return EntryModeEnumeration.ENTRY_MODE_TAPPED;
        }
        if (string.contentEquals("ENTRY_MODE_NFC")) {
            return EntryModeEnumeration.ENTRY_MODE_NFC;
        }
        if (string.contentEquals("ENTRY_MODE_EMV_CONTACTLESS")) {
            return EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS;
        }
        if (string.contentEquals("ENTRY_MODE_MOBILE")) {
            return EntryModeEnumeration.ENTRY_MODE_MOBILE;
        }
        if (string.contentEquals("ENTRY_MODE_CMC7")) {
            return EntryModeEnumeration.ENTRY_MODE_CMC7;
        }
        if (string.contentEquals("ENTRY_MODE_CMC7_KEYED")) {
            return EntryModeEnumeration.ENTRY_MODE_CMC7_KEYED;
        }
        if (string.contentEquals("ENTRY_MODE_CMC7_READED")) {
            return EntryModeEnumeration.ENTRY_MODE_CMC7;
        }
        if (string.contentEquals("ENTRY_MODE_CMC7_RECEIVED")) {
            return EntryModeEnumeration.ENTRY_MODE_CMC7;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getEntryMode() unknown :" + string);
        }
        return EntryModeEnumeration.UNKNOWN;
    }

    @Override
    public void setEntryMode(EntryModeEnumeration entryModeEnumeration) {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromResponse(false);
        if (meanOfPayment == null) {
            return;
        }
        meanOfPayment.setEntryMode(entryModeEnumeration.toString());
    }

    @Override
    public List<UpdateHandler.ParameterFile> getParameterFileList(UpdateHandler updateHandler) {
        TransactionData transactionData = this.getTransactionDataFromRequest();
        if (transactionData == null) {
            return null;
        }
        List<ParameterFile> list = transactionData.getParameterFileList();
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getParameterFileList() not set");
            }
            return null;
        }
        ArrayList<UpdateHandler.ParameterFile> arrayList = new ArrayList<UpdateHandler.ParameterFile>();
        for (ParameterFile parameterFile : list) {
            UpdateHandler.ParameterFile parameterFile2 = updateHandler.new UpdateHandler.ParameterFile();
            parameterFile2.headerParameterFile.checksum = parameterFile.getHeaderParameterFile().getChecksum();
            parameterFile2.headerParameterFile.checksumAlgorithm = parameterFile.getHeaderParameterFile().getChecksumAlgorithm();
            parameterFile2.headerParameterFile.creationTimestamp = parameterFile.getHeaderParameterFile().getCreationTimestamp();
            parameterFile2.headerParameterFile.status = parameterFile.getHeaderParameterFile().getStatus();
            parameterFile2.headerParameterFile.tableName = parameterFile.getHeaderParameterFile().getTableName();
            parameterFile2.headerParameterFile.tableVersion = parameterFile.getHeaderParameterFile().getTableVersion();
            List<String> list2 = parameterFile.getAppTagsList();
            if (list2 != null) {
                for (String string : list2) {
                    parameterFile2.appTagsList.add(string);
                }
            }
            arrayList.add(parameterFile2);
        }
        return arrayList;
    }

    @Override
    public void setParameterFileList(List<UpdateHandler.ParameterFile> list) {
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return;
        }
        List<ParameterFile> list2 = transactionData.getParameterFileList();
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setParameterFileList()");
            }
            return;
        }
        for (UpdateHandler.ParameterFile parameterFile : list) {
            ParameterFile parameterFile2 = new ParameterFile();
            HeaderParameterFile headerParameterFile = new HeaderParameterFile();
            parameterFile2.setHeaderParameterFile(headerParameterFile);
            headerParameterFile.setChecksum(parameterFile.headerParameterFile.checksum);
            headerParameterFile.setChecksumAlgorithm(parameterFile.headerParameterFile.checksumAlgorithm);
            headerParameterFile.setCreationTimestamp(parameterFile.headerParameterFile.creationTimestamp);
            headerParameterFile.setStatus(parameterFile.headerParameterFile.status);
            headerParameterFile.setTableName(parameterFile.headerParameterFile.tableName);
            headerParameterFile.setTableVersion(parameterFile.headerParameterFile.tableVersion);
            List<String> list3 = parameterFile.appTagsList;
            if (list3 != null) {
                for (String string : list3) {
                    parameterFile2.getAppTagsList().add(string);
                }
            }
            list2.add(parameterFile2);
        }
    }

    @Override
    public String getUserAgentHeader() {
        EPayment ePayment = this.getEpaymentFromRequest();
        if (ePayment == null) {
            return null;
        }
        String string = ePayment.getUserAgentHeader();
        if (string != null && !string.isEmpty()) {
            return string;
        }
        return null;
    }

    @Override
    public String getAcceptHeader() {
        EPayment ePayment = this.getEpaymentFromRequest();
        if (ePayment == null) {
            return null;
        }
        String string = ePayment.getAcceptHeader();
        if (string != null && !string.isEmpty()) {
            return string;
        }
        return null;
    }

    @Override
    public String getNewPasswd() {
        List<org.yp.xml.jibx.xpde.Property> list;
        block8: {
            User user;
            block7: {
                TransactionData transactionData;
                block6: {
                    transactionData = this.getTransactionDataFromRequest();
                    if (transactionData != null) break block6;
                    return null;
                }
                user = transactionData.getUser();
                if (user != null) break block7;
                return null;
            }
            list = user.getPropertyList();
            if (list != null && list.size() != 0) break block8;
            return null;
        }
        try {
            for (org.yp.xml.jibx.xpde.Property property : list) {
                if (!property.getKey().contentEquals("password")) continue;
                return property.getValue();
            }
            return null;
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public int setUserMessage(String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        TransactionData transactionData = this.getTransactionDataFromResponse(false);
        if (transactionData == null) {
            return -1;
        }
        User user = transactionData.getUser();
        if (user == null) {
            transactionData.setUser(new User());
            user = transactionData.getUser();
            if (user == null) {
                return -1;
            }
        }
        org.yp.xml.jibx.xpde.Property property = new org.yp.xml.jibx.xpde.Property();
        property.setKey("info");
        property.setValue(string);
        List<org.yp.xml.jibx.xpde.Property> list = user.getPropertyList();
        list.add(property);
        return 1;
    }

    private String idXOR(String string) {
        String string2 = "";
        int n = 0;
        int n2 = 0;
        while (n < string.length()) {
            string2 = String.valueOf(string2) + (char)(string.charAt(n) ^ "Just to prevent easy reading".charAt(n2));
            if (++n2 >= "Just to prevent easy reading".length()) {
                n2 = 0;
            }
            ++n;
        }
        return string2;
    }

    @Override
    public String getMerchantURLStatus() {
        EPayment ePayment = this.getEpaymentFromRequest();
        if (ePayment == null) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getMerchantURLStatus() ePayment not set");
            }
            return null;
        }
        return ePayment.getMerchantURLStatus();
    }

    private ChequeData getChequeDataFromRequest() {
        MeanOfPayment meanOfPayment = this.getMeanOfPaymentFromRequest();
        if (meanOfPayment == null) {
            return null;
        }
        MeanOfPaymentComplementaryData meanOfPaymentComplementaryData = meanOfPayment.getComplementaryData();
        if (meanOfPaymentComplementaryData == null) {
            return null;
        }
        ChequeData chequeData = meanOfPaymentComplementaryData.getChequeData();
        return chequeData;
    }

    @Override
    public String getCMC7Track() {
        ChequeData chequeData = this.getChequeDataFromRequest();
        if (chequeData == null) {
            return null;
        }
        String string = chequeData.getChequeTrackData();
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getCMC7Track() not set");
            }
            return null;
        }
        return string;
    }

    @Override
    public String getPrintFormat() {
        RequestBody requestBody;
        block3: {
            try {
                requestBody = this.xpdeRequest.getRequestBody();
                if (requestBody != null) break block3;
                return null;
            }
            catch (Exception exception) {
                return null;
            }
        }
        return requestBody.getPrintInput().getTicketFormat();
    }

    @Override
    public String getSecurityTrailer() {
        try {
            return this.xpdeRequest.getSecurityTrailer();
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public void setSecurityTrailer(String string) {
        this.xpdeResponse.setSecurityTrailer(string);
    }
}

