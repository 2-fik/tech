/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.thales;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_MacAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_CRYPTO_PayShield
extends YP_TCD_CRYPTO_Module
implements YP_TCD_CRYPTO_CipherSym_Interface,
YP_TCD_CRYPTO_MacAlgo_Interface {
    private static final int CX_TIMEOUT_MS = 3500;
    private static final int RECV_TIMEOUT_MS = 10000;
    private YP_TCD_DCC_Status dataContainerStatus = null;
    private YP_Row cryptoModuleRow = null;
    private final int TOKEN_ITERATIONS = 2;
    private final int TOKEN_SALTLENGTH = 10;
    private static final String MAC_METHOD_X9_19 = "1";
    private static final String HEADER_NEPTING = "0001";
    private static final String AES_IV = "00000000000000000000000000000000";
    private static final String DES_IV = "0000000000000000";
    private static final byte[] pad1 = new byte[]{1};
    private static final byte[] pad2 = new byte[]{2, 2};
    private static final byte[] pad3 = new byte[]{3, 3, 3};
    private static final byte[] pad4 = new byte[]{4, 4, 4, 4};
    private static final byte[] pad5 = new byte[]{5, 5, 5, 5, 5};
    private static final byte[] pad6 = new byte[]{6, 6, 6, 6, 6, 6};
    private static final byte[] pad7 = new byte[]{7, 7, 7, 7, 7, 7, 7};
    private static final byte[] pad8 = new byte[]{8, 8, 8, 8, 8, 8, 8, 8};
    private static final byte[] pad9 = new byte[]{9, 9, 9, 9, 9, 9, 9, 9, 9};
    private static final byte[] padA = new byte[]{10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
    private static final byte[] padB = new byte[]{11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11};
    private static final byte[] padC = new byte[]{12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12};
    private static final byte[] padD = new byte[]{13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13};
    private static final byte[] padE = new byte[]{14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14};
    private static final byte[] padF = new byte[]{15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15};
    private static final byte[] pad10 = new byte[]{16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16};

    public YP_TCD_CRYPTO_PayShield(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray.length > 0 && objectArray[0] instanceof YP_Row) {
            this.cryptoModuleRow = (YP_Row)objectArray[0];
        }
    }

    @Override
    public int initialize() {
        try {
            this.myCipherSym = this;
            this.myMAC = this;
            super.initialize();
            if (this.dataContainerStatus == null) {
                this.dataContainerStatus = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
            }
            return this.initializeContext();
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() " + exception);
            }
            return -1;
        }
    }

    private int initializeContext() {
        return 1;
    }

    private int closeContext() {
        return 1;
    }

    @Override
    public int shutdown() {
        this.closeContext();
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "CryptoPayShield";
    }

    @Override
    public String getVersion() {
        return "V1.3.9.3";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :" + exception);
            return null;
        }
    }

    @Override
    public String decrypt(String string, String string2, List<Property> list, String string3, String string4, String string5) throws Exception {
        byte[] byArray;
        byte[] byArray2;
        this.initializeContext();
        String string6 = this.getPropertie(list, "KEY_BLOCK");
        if (string6 == null || string6.isEmpty()) {
            this.logger(2, "decrypt() No Key block propertie found for " + string2);
            throw new Exception("decrypt() No Key block propertie found for " + string2);
        }
        try {
            byArray2 = UtilsYP.base64Decode(string);
        }
        catch (Exception exception) {
            this.logger(2, "decrypt() bad value to decrypt: " + string + " " + exception);
            throw exception;
        }
        switch (string3) {
            case "DESede/CBC/PKCS5Padding": {
                byArray = this.desDecrypt(string6, byArray2);
                break;
            }
            case "AES/CBC/PKCS5Padding": {
                byArray = this.aesDecrypt(string6, byArray2);
                break;
            }
            case "AES/CBC/NoPadding": {
                throw new Exception("decrypt() not yet implemented");
            }
            case "DUKPT/DATA": 
            case "DUKPT/": {
                byArray = this.dukptDecrypt(string6, string4, byArray2, string5);
                break;
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "decrypt() unknown algo:" + string3);
                }
                throw new Exception("decrypt() unknown algo:" + string3);
            }
        }
        String string7 = new String(byArray);
        return string7;
    }

    @Override
    public byte[] translatePIN(byte[] byArray, String string, String string2, String string3, List<Property> list, String string4, String string5, String string6, String string7, List<Property> list2, String string8, String string9) throws Exception {
        String string10 = this.getPropertie(list, "KEY_BLOCK");
        if (string10 == null || string10.isEmpty()) {
            this.logger(2, "decrypt() No Key block propertie found for " + string3);
            throw new Exception("decrypt() No Key block propertie found for " + string3);
        }
        String string11 = this.getPropertie(list2, "KEY_BLOCK");
        if (string11 == null || string11.isEmpty()) {
            this.logger(2, "decrypt() No Key block propertie found for " + string7);
            throw new Exception("decrypt() No Key block propertie found for " + string7);
        }
        switch (string4) {
            case "DUKPT/": {
                switch (string8) {
                    case "DESede/CBC/PKCS5Padding": {
                        if (string7.contains("TMK")) {
                            return this.dukptTranslatePINToTMK(string10, string11, string5, null, string, string6, string2, byArray);
                        }
                        return this.dukptTranslatePIN(string10, string11, string5, null, string, string6, string2, byArray);
                    }
                    case "DUKPT/": {
                        return this.dukptTranslatePIN(string10, string11, string5, string9, string, string6, string2, byArray);
                    }
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "decrypt() unknown algo:" + string4);
                }
                throw new Exception("decrypt() unknown algo:" + string4);
            }
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "decrypt() unknown algo:" + string4);
        }
        throw new Exception("decrypt() unknown algo:" + string4);
    }

    @Override
    public byte[] decrypt(byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        this.initializeContext();
        String string5 = this.getPropertie(list, "KEY_BLOCK");
        if (string5 == null || string5.isEmpty()) {
            this.logger(2, "decrypt() No Key block propertie found for " + string);
            throw new Exception("decrypt() No Key block propertie found for " + string);
        }
        switch (string2) {
            case "DESede/CBC/PKCS5Padding": {
                return this.desDecrypt(string5, byArray);
            }
            case "AES/CBC/PKCS5Padding": {
                return this.aesDecrypt(string5, byArray);
            }
            case "AES/CBC/NoPadding": {
                throw new Exception("decrypt() not yet implemented");
            }
            case "DUKPT/DATA": 
            case "DUKPT/": {
                return this.dukptDecrypt(string5, string3, byArray, string4);
            }
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "decrypt() unknown algo:" + string2);
        }
        throw new Exception("decrypt() unknown algo:" + string2);
    }

    @Override
    public String decryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        this.initializeContext();
        if (string2.startsWith("DUKPT/")) {
            this.logger(2, "decryptToken() is not implemented ");
            throw new Exception("decryptToken() is not implemented ");
        }
        switch (string2) {
            case "AES/CBC/NoPadding": 
            case "DUKPT/DATA": 
            case "DESede/CBC/PKCS5Padding": 
            case "DUKPT/": {
                this.logger(2, "decryptToken() is not implemented ");
                throw new Exception("decryptToken() is not implemented ");
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "decryptToken() unknown algo:" + string2);
                }
                throw new Exception("decryptToken() unknown algo:" + string2);
            }
            case "AES/CBC/PKCS5Padding": 
        }
        String string4 = this.getPropertie(list, "KEY_BLOCK");
        if (string4 == null || string4.isEmpty()) {
            this.logger(2, "decryptToken() No Key block propertie found for " + string);
            throw new Exception("decryptToken() No Key block propertie found for " + string);
        }
        String string5 = null;
        String string6 = string3;
        int n = 0;
        while (n < 2) {
            byte[] byArray = UtilsYP.base64Decode(string6);
            byte[] byArray2 = this.aesDecrypt(string4, byArray);
            string6 = string5 = new String(byArray2).substring(10);
            ++n;
        }
        return string5;
    }

    @Override
    public String[] encrypt(String string, String string2, List<Property> list, String string3, String string4) throws Exception {
        Object object;
        byte[] byArray;
        long l = 0L;
        if (this.getLogLevel() >= 5) {
            l = System.currentTimeMillis();
        }
        this.initializeContext();
        String string5 = this.getPropertie(list, "KEY_BLOCK");
        if (string5 == null || string5.isEmpty()) {
            this.logger(2, "encrypt() No Key block propertie found for " + string2);
            throw new Exception("encrypt() No Key block propertie found for " + string2);
        }
        switch (string3) {
            case "DESede/CBC/PKCS5Padding": {
                byArray = this.desEncrypt(string5, string.getBytes());
                break;
            }
            case "AES/CBC/PKCS5Padding": {
                byArray = this.aesEncrypt(string5, string.getBytes());
                break;
            }
            case "AES/CBC/NoPadding": {
                throw new Exception("encrypt() not yet implemented");
            }
            case "DUKPT/DATA": 
            case "DUKPT/": {
                object = string4.split("\\|");
                byArray = this.dukptEncrypt(string5, object[0], string.getBytes(), ((String[])object).length > 1 ? object[1] : null);
                break;
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "encrypt() unknown algo:" + string3);
                }
                throw new Exception("encrypt() unknown algo:" + string3);
            }
        }
        object = UtilsYP.base64Encode(byArray);
        String[] stringArray = new String[]{((String)object).replace(UtilsYP.lineSeparator, ""), string2};
        if (this.getLogLevel() >= 5) {
            long l2 = System.currentTimeMillis() - l;
            this.logger(5, "encrypt() done in " + l2);
        }
        return stringArray;
    }

    @Override
    public byte[][] encrypt(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        Object object;
        byte[] byArray2;
        this.initializeContext();
        String string4 = this.getPropertie(list, "KEY_BLOCK");
        if (string4 == null || string4.isEmpty()) {
            this.logger(2, "encrypt() No Key block propertie found for " + string);
            throw new Exception("encrypt() No Key block propertie found for " + string);
        }
        switch (string2) {
            case "DESede/CBC/PKCS5Padding": {
                byArray2 = this.desEncrypt(string4, byArray);
                break;
            }
            case "AES/CBC/PKCS5Padding": {
                byArray2 = this.aesEncrypt(string4, byArray);
                break;
            }
            case "AES/CBC/NoPadding": {
                throw new Exception("encrypt() not yet implemented");
            }
            case "DUKPT/DATA": 
            case "DUKPT/": {
                object = string3.split("\\|");
                byArray2 = this.dukptEncrypt(string4, object[0], byArray, ((String[])object).length > 1 ? object[1] : null);
                break;
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "encrypt() unknown algo:" + string2);
                }
                throw new Exception("encrypt() unknown algo:" + string2);
            }
        }
        object = new byte[2][];
        object[0] = byArray2;
        object[1] = string.getBytes();
        return object;
    }

    @Override
    public String[] encryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        int n;
        this.initializeContext();
        String string4 = this.getPropertie(list, "KEY_BLOCK");
        if (string4 == null || string4.isEmpty()) {
            this.logger(2, "encryptToken() No Key block propertie found for " + string);
            throw new Exception("encryptToken() No Key block propertie found for " + string);
        }
        StringBuilder stringBuilder = new StringBuilder(10);
        if (string3.length() >= 10) {
            n = 0;
            while (n < 10) {
                stringBuilder.append(string3.charAt(n));
                ++n;
            }
        } else {
            n = 0;
            while (n < string3.length()) {
                stringBuilder.append(string3.charAt(n));
                ++n;
            }
            while (stringBuilder.length() != 10) {
                stringBuilder.append("X");
            }
        }
        String string5 = string3;
        int n2 = 0;
        while (n2 < 2) {
            String string6 = stringBuilder + string5;
            byte[] byArray = this.aesEncrypt(string4, string6.getBytes());
            string5 = UtilsYP.base64Encode(byArray);
            ++n2;
        }
        String[] stringArray = new String[3];
        stringArray[0] = string5.replace(UtilsYP.lineSeparator, "");
        stringArray[1] = string;
        return stringArray;
    }

    @Override
    public int addKey(String string, List<Property> list, byte[] byArray, String string2) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "addKey() is not implemented");
        }
        throw new Exception("addKey() is not implemented");
    }

    @Override
    public int isCryptoSupported(String string) {
        int n = this.isCipherSymSupported(string);
        if (n >= 1) {
            return n;
        }
        n = this.isMACSupported(string);
        if (n >= 1) {
            return n;
        }
        return 0;
    }

    @Override
    public int isCipherSymSupported(String string) {
        switch (string) {
            case "AES/CBC/NoPadding": 
            case "AES/CBC/PKCS5Padding": 
            case "DUKPT/DATA": 
            case "DESede/CBC/PKCS5Padding": 
            case "DUKPT/": {
                return 1;
            }
        }
        return 0;
    }

    @Override
    public String computeMAC(String string, List<Property> list, byte[] byArray, Object ... objectArray) throws Exception {
        this.initializeContext();
        String string2 = this.getPropertie(list, "KEY_BLOCK");
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "computeMAC() No Key block propertie found for " + string);
            throw new Exception("computeMAC() No Key block propertie found for " + string);
        }
        if (objectArray == null || objectArray.length < 3 || objectArray[2] == null || !(objectArray[2] instanceof String)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "computeMAC() bad parameters");
            }
            throw new Exception("Bad parameters");
        }
        String string3 = string;
        String string4 = (String)objectArray[2];
        String string5 = this.dukptMacCompute(string4, string2, string3, byArray);
        return string5;
    }

    @Override
    public boolean verifyMAC(String string, List<Property> list, byte[] byArray, String string2, Object ... objectArray) throws Exception {
        String string3;
        block4: {
            this.initializeContext();
            try {
                string3 = this.computeMAC(string, list, byArray, objectArray[0], objectArray[1], objectArray[3]);
                if (string3 != null) break block4;
                return false;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "verifyMAC() " + exception);
                }
                throw exception;
            }
        }
        return string3.contentEquals(string2);
    }

    @Override
    public int isMACSupported(String string) {
        switch (string) {
            case "DUKPT/MAC/REQUEST": 
            case "DUKPT/MAC/RESPONSE": {
                return 1;
            }
        }
        return 0;
    }

    private byte[] aesDecrypt(String string, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatUnCipherMessage(string, byArray, InputFormatEnumeration.Text);
        byte[] byArray3 = this.payshieldRequest(byArray2, "aesDecrypt");
        return this.getDataFromUnCipherResponse(byArray3, InputFormatEnumeration.Text);
    }

    private byte[] aesEncrypt(String string, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatCipherMessage(string, byArray, InputFormatEnumeration.Text);
        byte[] byArray3 = this.payshieldRequest(byArray2, "aesEncrypt");
        return this.getEncryptedDataFromCipherResponse(byArray3);
    }

    private byte[] desDecrypt(String string, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatDesUnCipherMessage(string, byArray, InputFormatEnumeration.Text);
        byte[] byArray3 = this.payshieldRequest(byArray2, "desDecrypt");
        return this.getDataFromDesUnCipherResponse(byArray3, InputFormatEnumeration.Text);
    }

    private byte[] desEncrypt(String string, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatDesCipherMessage(string, byArray, InputFormatEnumeration.Text);
        byte[] byArray3 = this.payshieldRequest(byArray2, "desEncrypt");
        return this.getEncryptedDataFromDesCipherResponse(byArray3);
    }

    private byte[] dukptDecrypt(String string, String string2, byte[] byArray, String string3) throws Exception {
        byte[] byArray2 = this.formatDUKPTUnCipherMessage(string, UtilsYP.devHexa(byArray).getBytes(), string2, InputFormatEnumeration.HexEncodedBinary, string3);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptDecrypt");
        return this.getDataFromDUKPTUnCipherResponse(byArray3, InputFormatEnumeration.Text);
    }

    private byte[] dukptEncrypt(String string, String string2, byte[] byArray, String string3) throws Exception {
        byte[] byArray2 = this.formatDukptCipherMessage(string, UtilsYP.devHexa(byArray).getBytes(), string2, InputFormatEnumeration.HexEncodedBinary, string3);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptEncrypt");
        return this.getEncryptedDataFromDukptCipherResponse(byArray3);
    }

    private byte[] dukptTranslatePINToTMK(String string, String string2, String string3, String string4, String string5, String string6, String string7, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatDUKPTTranslatePINMessage(string, string2, string3, string4, string5, string6, string7, byArray);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptTranslatePIN");
        return this.getDataFromDUKPTTranslatePINResponse(byArray3);
    }

    private byte[] dukptTranslatePIN(String string, String string2, String string3, String string4, String string5, String string6, String string7, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatDUKPTTranslatePINMessage(string, string2, string3, string4, string5, string6, string7, byArray);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptTranslatePIN");
        return this.getDataFromDUKPTTranslatePINResponse(byArray3);
    }

    private String dukptMacCompute(String string, String string2, String string3, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatVerifyMacMessage(string, string2, string3, null, byArray);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptMacCompute");
        return this.getMACFomGenerateMacResponse(byArray3);
    }

    private boolean dukptMacVerify(String string, String string2, String string3, String string4, byte[] byArray) throws Exception {
        byte[] byArray2 = this.formatVerifyMacMessage(string, string2, string3, string4, byArray);
        byte[] byArray3 = this.payshieldRequest(byArray2, "dukptMacVerify");
        return this.analyzeVerifyMacResponse(byArray3);
    }

    private void printFormatedMessage(String string, byte[] byArray) {
        if (byArray == null) {
            return;
        }
        this.logger(6, String.valueOf(string) + new String(byArray));
        int n = 0;
        while (n < byArray.length) {
            string = String.valueOf(string) + "0x" + String.format("%02x", byArray[n]) + " ";
            ++n;
        }
        this.logger(6, string);
    }

    private byte[] formatCipherMessage(String string, byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.EncryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append(OutputFormatEnumeration.Binary.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append(AES_IV);
        byte[] byArray2 = YP_TCD_CRYPTO_PayShield.pad16ModPKCS5(byArray, inputFormatEnumeration);
        stringBuilder.append(String.format("%04x", byArray2.length));
        byte[] byArray3 = new byte[stringBuilder.length() + byArray2.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray3, 0, stringBuilder.length());
        System.arraycopy(byArray2, 0, byArray3, stringBuilder.length(), byArray2.length);
        return byArray3;
    }

    private byte[] formatDesCipherMessage(String string, byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.EncryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append(OutputFormatEnumeration.Binary.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append(DES_IV);
        byte[] byArray2 = YP_TCD_CRYPTO_PayShield.pad8ModPKCS5(byArray, inputFormatEnumeration);
        stringBuilder.append(String.format("%04x", byArray2.length));
        byte[] byArray3 = new byte[stringBuilder.length() + byArray2.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray3, 0, stringBuilder.length());
        System.arraycopy(byArray2, 0, byArray3, stringBuilder.length(), byArray2.length);
        return byArray3;
    }

    private void checkResponse(byte[] byArray, String string) throws Exception {
        if (byArray == null) {
            this.logger(2, "checkResponse() no response to analyse");
            throw new Exception("checkResponse() no response to analyse");
        }
        byte[] byArray2 = new byte[HEADER_NEPTING.length()];
        int n = 0;
        System.arraycopy(byArray, 0, byArray2, n, byArray2.length);
        n += byArray2.length;
        String string2 = new String(byArray2);
        if (!string2.contentEquals(HEADER_NEPTING)) {
            this.logger(2, "checkResponse() Bad header !!!");
            throw new Exception("checkResponse() Bad header !!!");
        }
        byte[] byArray3 = new byte[2];
        System.arraycopy(byArray, n, byArray3, 0, 2);
        n += 2;
        String string3 = new String(byArray3);
        if (!string3.contentEquals(string)) {
            this.logger(2, "checkResponse() Bad response: " + string3 + " vs " + string);
            throw new Exception("checkResponse() Bad response: " + string3 + " vs " + string);
        }
    }

    private byte[] getEncryptedDataFromCipherResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.EncryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[32];
            System.arraycopy(byArray, n, byArray3, 0, 32);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 32, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            return byArray5;
        }
        String string = "getEncryptedDataFromCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getEncryptedDataFromDesCipherResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.EncryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n, byArray3, 0, 16);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 16, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            return byArray5;
        }
        String string = "getEncryptedDataFromDesCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] formatUnCipherMessage(String string, byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.DecryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(InputFormatEnumeration.Binary.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append(AES_IV);
        stringBuilder.append(String.format("%04X", byArray.length));
        byte[] byArray2 = new byte[stringBuilder.length() + byArray.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray2, 0, stringBuilder.length());
        System.arraycopy(byArray, 0, byArray2, stringBuilder.length(), byArray.length);
        return byArray2;
    }

    private byte[] formatDesUnCipherMessage(String string, byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.DecryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(InputFormatEnumeration.Binary.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append(DES_IV);
        stringBuilder.append(String.format("%04X", byArray.length));
        byte[] byArray2 = new byte[stringBuilder.length() + byArray.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray2, 0, stringBuilder.length());
        System.arraycopy(byArray, 0, byArray2, stringBuilder.length(), byArray.length);
        return byArray2;
    }

    private byte[] formatDUKPTUnCipherMessage(String string, byte[] byArray, String string2, InputFormatEnumeration inputFormatEnumeration, String string3) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.DecryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append(OutputFormatEnumeration.Text.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append("A05");
        stringBuilder.append(string2);
        if (string3 == null) {
            string3 = DES_IV;
        }
        stringBuilder.append(string3);
        stringBuilder.append(String.format("%04X", byArray.length));
        byte[] byArray2 = new byte[stringBuilder.length() + byArray.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray2, 0, stringBuilder.length());
        System.arraycopy(byArray, 0, byArray2, stringBuilder.length(), byArray.length);
        return byArray2;
    }

    private byte[] formatDukptCipherMessage(String string, byte[] byArray, String string2, InputFormatEnumeration inputFormatEnumeration, String string3) {
        if (byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.EncryptRequest.getValue());
        stringBuilder.append(EncryptionModeEnumeration.CBC.getValue());
        stringBuilder.append(inputFormatEnumeration.getValue());
        stringBuilder.append(OutputFormatEnumeration.Binary.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string);
        stringBuilder.append("A05");
        stringBuilder.append(string2);
        if (string3 == null) {
            string3 = DES_IV;
        }
        stringBuilder.append(string3);
        stringBuilder.append(String.format("%04x", byArray.length));
        byte[] byArray2 = new byte[stringBuilder.length() + byArray.length];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray2, 0, stringBuilder.length());
        System.arraycopy(byArray, 0, byArray2, stringBuilder.length(), byArray.length);
        return byArray2;
    }

    private byte[] formatDUKPTTranslatePINMessage(String string, String string2, String string3, String string4, String string5, String string6, String string7, byte[] byArray) {
        String string8;
        String string9;
        if (byArray == null) {
            this.logger(2, "formatDUKPTTranslatePINMessage() PIN block to translate is null");
            return null;
        }
        byte[] byArray2 = UtilsYP.devHexa(byArray).getBytes();
        if (string7 == null || string7.length() < 13) {
            this.logger(2, "formatDUKPTTranslatePINMessage() PAN is null or too short (length < 13 is not yet supported)");
            return null;
        }
        switch (string5) {
            case "0": {
                string9 = "01";
                break;
            }
            case "3": {
                string9 = "47";
                break;
            }
            default: {
                this.logger(2, "formatDUKPTTranslatePINMessage() unsupported source Pin Block Format: " + string5);
                return null;
            }
        }
        switch (string6) {
            case "0": {
                string8 = "01";
                break;
            }
            case "3": {
                string8 = "47";
                break;
            }
            default: {
                this.logger(2, "formatDUKPTTranslatePINMessage() unsupported destination Pin Block Format: " + string6);
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.DUKPTTranslatePINRequest.getValue());
        stringBuilder.append(string);
        stringBuilder.append(string2);
        stringBuilder.append("A05");
        stringBuilder.append(string3);
        if (string4 != null && !string2.isEmpty()) {
            stringBuilder.append("A05");
            stringBuilder.append(string4);
        }
        byte[] byArray3 = new byte[stringBuilder.length() + byArray2.length + string9.length() + string8.length() + 12];
        int n = 0;
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray3, n, stringBuilder.length());
        System.arraycopy(byArray2, 0, byArray3, n += stringBuilder.length(), byArray2.length);
        System.arraycopy(string9.getBytes(), 0, byArray3, n += byArray2.length, string9.length());
        System.arraycopy(string8.getBytes(), 0, byArray3, n += string9.length(), string8.length());
        System.arraycopy(string7.getBytes(), string7.length() - 12 - 1, byArray3, n += string8.length(), 12);
        return byArray3;
    }

    private byte[] formatGeneratePINKeyMessage(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.GenerateKey.getValue());
        stringBuilder.append(MAC_METHOD_X9_19);
        stringBuilder.append("FFF");
        stringBuilder.append("S");
        stringBuilder.append(string);
        stringBuilder.append("X");
        byte[] byArray = new byte[stringBuilder.length()];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray, 0, stringBuilder.length());
        return byArray;
    }

    private byte[] formatExportPINKeyMessage(String string, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.ExportPINKeyRequest.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string2);
        stringBuilder.append(string);
        stringBuilder.append("X");
        byte[] byArray = new byte[stringBuilder.length()];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray, 0, stringBuilder.length());
        return byArray;
    }

    private byte[] formatImportKeyMessage(String string, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.ImportKeyRequest.getValue());
        stringBuilder.append("FFF");
        stringBuilder.append(string2);
        stringBuilder.append("X");
        if (string.length() == 48) {
            string = string.substring(0, 32);
        }
        stringBuilder.append(string);
        stringBuilder.append("S");
        byte[] byArray = new byte[stringBuilder.length()];
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray, 0, stringBuilder.length());
        return byArray;
    }

    private byte[] getDataFromUnCipherResponse(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.DecryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[32];
            System.arraycopy(byArray, n, byArray3, 0, 32);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 32, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            byte[] byArray6 = YP_TCD_CRYPTO_PayShield.unpadModPKCS5(byArray5, inputFormatEnumeration);
            return byArray6;
        }
        String string = "getDataFromUnCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromDesUnCipherResponse(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.DecryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n, byArray3, 0, 16);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 16, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            byte[] byArray6 = YP_TCD_CRYPTO_PayShield.unpadModPKCS5(byArray5, inputFormatEnumeration);
            return byArray6;
        }
        String string = "getDataFromDesUnCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromDUKPTUnCipherResponse(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.DecryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n, byArray3, 0, 16);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 16, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            return byArray5;
        }
        String string = "getDataFromDUKPTUnCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getEncryptedDataFromDukptCipherResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.EncryptResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n, byArray3, 0, 16);
            int n2 = 0;
            byte[] byArray4 = new byte[4];
            System.arraycopy(byArray, n += 16, byArray4, 0, 4);
            n2 = Integer.parseInt(new String(byArray4), 16);
            byte[] byArray5 = new byte[n2];
            System.arraycopy(byArray, n += 4, byArray5, 0, n2);
            return byArray5;
        }
        String string = "getEncryptedDataFromDukptCipherResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromDUKPTTranslatePINResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.DUKPTTranslatePINResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n += 2, byArray3, 0, 16);
            return byArray3;
        }
        String string = "getDataFromDUKPTTranslatePINResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromGeneratePINKeyResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.GenerateKeyResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            int n2 = byArray.length - (n += 2);
            byte[] byArray3 = new byte[n2];
            System.arraycopy(byArray, n, byArray3, 0, n2);
            return byArray3;
        }
        String string = "getDataFromGeneratePINKeyResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromExportPINKeyResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.ExportPINKeyResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            int n2 = byArray.length - ++n - 3;
            byte[] byArray3 = new byte[n2];
            System.arraycopy(byArray, n, byArray3, 0, n2);
            return byArray3;
        }
        String string = "getDataFromGeneratePINKeyResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] getDataFromImportKeyResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.ImportKeyResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            int n2 = byArray.length - n - 3;
            byte[] byArray3 = new byte[n2];
            System.arraycopy(byArray, n, byArray3, 0, n2);
            return byArray3;
        }
        String string = "getDataFromImportKeyResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1] + " " + this.getText(byArray2);
        this.logger(2, string);
        throw new Exception(string);
    }

    private byte[] formatVerifyMacMessage(String string, String string2, String string3, String string4, byte[] byArray) throws Exception {
        if (string3 == null || byArray == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(HEADER_NEPTING);
        stringBuilder.append(PayshieldCommandEnumeration.GenerateVerifyMACRequest.getValue());
        switch (string) {
            case "000000000000FF00000000000000FF00": {
                if (string4 == null) {
                    stringBuilder.append(MacModeEnumeration.Generate_8B_Mac_BD.getValue());
                    break;
                }
                stringBuilder.append(MacModeEnumeration.Verify_8B_Mac_BD.getValue());
                break;
            }
            case "00000000FF00000000000000FF000000": {
                if (string4 == null) {
                    stringBuilder.append(MacModeEnumeration.Generate_8B_Mac_UD.getValue());
                    break;
                }
                stringBuilder.append(MacModeEnumeration.Verify_8B_Mac_UD.getValue());
                break;
            }
            default: {
                throw new Exception("formatVerifyMacMessage() Unknown derivation " + string);
            }
        }
        stringBuilder.append(MAC_METHOD_X9_19);
        stringBuilder.append(string2);
        stringBuilder.append("A05");
        stringBuilder.append(string3);
        if (string4 != null) {
            stringBuilder.append(string4);
        }
        byte[] byArray2 = byArray;
        byte[] byArray3 = new byte[stringBuilder.length() + 4 + byArray2.length];
        int n = 0;
        System.arraycopy(stringBuilder.toString().getBytes(), 0, byArray3, n, stringBuilder.length());
        String string5 = String.format("%04d", byArray2.length);
        System.arraycopy(string5.getBytes(), 0, byArray3, n += stringBuilder.length(), string5.length());
        System.arraycopy(byArray2, 0, byArray3, n += string5.length(), byArray2.length);
        return byArray3;
    }

    private boolean analyzeVerifyMacResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.GenerateVerifyMACResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "analyzeVerifyMacResponse() MAC verification successful");
            }
            return true;
        }
        this.logger(2, "analyzeVerifyMacResponse()  MAC verification failed :" + (char)byArray2[0] + (char)byArray2[1]);
        return false;
    }

    private String getMACFomGenerateMacResponse(byte[] byArray) throws Exception {
        this.checkResponse(byArray, PayshieldCommandEnumeration.GenerateVerifyMACResponse.getValue());
        int n = 6;
        byte[] byArray2 = new byte[2];
        System.arraycopy(byArray, n, byArray2, 0, 2);
        n += 2;
        if (byArray2[0] == 48 && byArray2[1] == 48) {
            byte[] byArray3 = new byte[16];
            System.arraycopy(byArray, n, byArray3, 0, 16);
            return new String(byArray3);
        }
        this.logger(2, "getMACFomGenerateMacResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1]);
        throw new Exception("getMACFomGenerateMacResponse() Ciphering failed :" + (char)byArray2[0] + (char)byArray2[1]);
    }

    private int payshieldSend(OutputStream outputStream, byte[] byArray) throws Exception {
        try {
            outputStream.write(byArray);
            outputStream.flush();
            return 1;
        }
        catch (Exception exception) {
            this.sysLog(2, "payshieldSend() failed: " + exception);
            throw exception;
        }
    }

    private byte[] payshieldReceive(Socket socket, InputStream inputStream) throws Exception {
        byte[] byArray;
        block6: {
            int n;
            byte[] byArray2;
            block5: {
                try {
                    byArray2 = new byte[2];
                    n = this.recv(socket, inputStream, byArray2);
                    if (n == 1) break block5;
                    this.logger(2, "payshieldReceive() length not received");
                    String string = this.getCryptoPropertie("HOSTNAME");
                    String string2 = this.getCryptoPropertie("PORT");
                    if (string != null && string2 != null) {
                        this.logger(2, "payshieldRequest() " + string + ":" + string2);
                    }
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "payshieldReceive() " + exception);
                    throw exception;
                }
            }
            int n2 = (byArray2[0] & 0xFF) << 8 | byArray2[1] & 0xFF;
            byArray = new byte[n2];
            n = this.recv(socket, inputStream, byArray);
            if (n == 1) break block6;
            this.logger(2, "payshieldReceive() response not received");
            return null;
        }
        return byArray;
    }

    private byte[] payshieldRequest(byte[] byArray, String string) throws Exception {
        int n;
        if (this.getLogLevel() >= 6) {
            this.printFormatedMessage("Message to send :", byArray);
        }
        Socket socket = null;
        OutputStream outputStream = null;
        InputStream inputStream = null;
        int n2 = byArray.length;
        byte[] byArray2 = new byte[2 + byArray.length];
        byArray2[0] = (byte)(n2 >> 8 & 0xFF);
        byArray2[1] = (byte)(n2 & 0xFF);
        System.arraycopy(byArray, 0, byArray2, 2, n2);
        String string2 = this.getCryptoPropertie("HOSTNAME");
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "payshieldRequest() missing parameter HOSTNAME");
            return null;
        }
        String string3 = this.getCryptoPropertie("PORT");
        if (string3 == null || string3.isEmpty()) {
            this.logger(2, "payshieldRequest() missing parameter PORT");
            return null;
        }
        try {
            n = Integer.parseInt(string3);
        }
        catch (Exception exception) {
            this.logger(2, "payshieldRequest() bad parameter PORT:" + string3);
            return null;
        }
        boolean bl = false;
        long l = -1L;
        long l2 = -1L;
        try {
            long l3 = System.currentTimeMillis();
            socket = new Socket();
            socket.setSoTimeout(3500);
            socket.connect(new InetSocketAddress(string2, n));
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();
            l = System.currentTimeMillis() - l3;
            this.payshieldSend(outputStream, byArray2);
            byte[] byArray3 = this.payshieldReceive(socket, inputStream);
            if (this.getLogLevel() >= 5) {
                this.printFormatedMessage("Message received :", byArray3);
            }
            if (byArray3 != null && byArray3.length > 0) {
                l2 = System.currentTimeMillis() - l3 - l;
                bl = true;
            }
            byte[] byArray4 = byArray3;
            return byArray4;
        }
        catch (Exception exception) {
            this.logger(2, "payshieldRequest() " + string2 + "/" + string3 + " " + exception);
            throw exception;
        }
        finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                }
                catch (Exception exception) {
                    this.logger(2, "payshieldRequest() " + exception);
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                }
                catch (Exception exception) {
                    this.logger(2, "payshieldRequest() " + exception);
                }
            }
            if (socket != null) {
                try {
                    socket.close();
                }
                catch (Exception exception) {
                    this.logger(2, "payshieldRequest() " + exception);
                }
            }
            try {
                int n3 = this.dataContainerStatus.updateCryptoStatus(this.cryptoModuleRow, string, bl, l, l2);
                if (n3 != 1) {
                    this.logger(2, "payshieldRequest() unable to update status");
                }
            }
            catch (Exception exception) {
                this.logger(2, "payshieldRequest() " + exception);
            }
        }
    }

    private String getPropertie(List<Property> list, String string) {
        if (list != null) {
            for (Property property : list) {
                if (!property.getName().contentEquals(string)) continue;
                return property.getValue();
            }
        }
        return null;
    }

    private static byte[] padModPKCS5Bin(int n, byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n2 = n - byArray.length % n;
        byte[] byArray2 = new byte[byArray.length + n2];
        System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
        switch (n2) {
            case 1: {
                System.arraycopy(pad1, 0, byArray2, byArray.length, pad1.length);
                return byArray2;
            }
            case 2: {
                System.arraycopy(pad2, 0, byArray2, byArray.length, pad2.length);
                return byArray2;
            }
            case 3: {
                System.arraycopy(pad3, 0, byArray2, byArray.length, pad3.length);
                return byArray2;
            }
            case 4: {
                System.arraycopy(pad4, 0, byArray2, byArray.length, pad4.length);
                return byArray2;
            }
            case 5: {
                System.arraycopy(pad5, 0, byArray2, byArray.length, pad5.length);
                return byArray2;
            }
            case 6: {
                System.arraycopy(pad6, 0, byArray2, byArray.length, pad6.length);
                return byArray2;
            }
            case 7: {
                System.arraycopy(pad7, 0, byArray2, byArray.length, pad7.length);
                return byArray2;
            }
            case 8: {
                System.arraycopy(pad8, 0, byArray2, byArray.length, pad8.length);
                return byArray2;
            }
            case 9: {
                System.arraycopy(pad9, 0, byArray2, byArray.length, pad9.length);
                return byArray2;
            }
            case 10: {
                System.arraycopy(padA, 0, byArray2, byArray.length, padA.length);
                return byArray2;
            }
            case 11: {
                System.arraycopy(padB, 0, byArray2, byArray.length, padB.length);
                return byArray2;
            }
            case 12: {
                System.arraycopy(padC, 0, byArray2, byArray.length, padC.length);
                return byArray2;
            }
            case 13: {
                System.arraycopy(padD, 0, byArray2, byArray.length, padD.length);
                return byArray2;
            }
            case 14: {
                System.arraycopy(padE, 0, byArray2, byArray.length, padE.length);
                return byArray2;
            }
            case 15: {
                System.arraycopy(padF, 0, byArray2, byArray.length, padF.length);
                return byArray2;
            }
            case 16: {
                System.arraycopy(pad10, 0, byArray2, byArray.length, pad10.length);
                return byArray2;
            }
        }
        return null;
    }

    private static byte[] padModPKCS5Hex(int n, byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n2 = n - byArray.length % n;
        byte[] byArray2 = new byte[byArray.length + 2 * n2];
        System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
        switch (n2) {
            case 1: {
                System.arraycopy(UtilsYP.devHexa(pad1), 0, byArray2, 2 * byArray.length, pad1.length);
                return byArray2;
            }
            case 2: {
                System.arraycopy(UtilsYP.devHexa(pad2), 0, byArray2, byArray.length, 2 * pad2.length);
                return byArray2;
            }
            case 3: {
                System.arraycopy(UtilsYP.devHexa(pad3), 0, byArray2, byArray.length, 2 * pad3.length);
                return byArray2;
            }
            case 4: {
                System.arraycopy(UtilsYP.devHexa(pad4), 0, byArray2, byArray.length, 2 * pad4.length);
                return byArray2;
            }
            case 5: {
                System.arraycopy(UtilsYP.devHexa(pad5), 0, byArray2, byArray.length, 2 * pad5.length);
                return byArray2;
            }
            case 6: {
                System.arraycopy(UtilsYP.devHexa(pad6), 0, byArray2, byArray.length, 2 * pad6.length);
                return byArray2;
            }
            case 7: {
                System.arraycopy(UtilsYP.devHexa(pad7), 0, byArray2, byArray.length, 2 * pad7.length);
                return byArray2;
            }
            case 8: {
                System.arraycopy(UtilsYP.devHexa(pad8), 0, byArray2, byArray.length, 2 * pad8.length);
                return byArray2;
            }
            case 9: {
                System.arraycopy(UtilsYP.devHexa(pad9), 0, byArray2, byArray.length, 2 * pad9.length);
                return byArray2;
            }
            case 10: {
                System.arraycopy(UtilsYP.devHexa(padA), 0, byArray2, byArray.length, 2 * padA.length);
                return byArray2;
            }
            case 11: {
                System.arraycopy(UtilsYP.devHexa(padB), 0, byArray2, byArray.length, 2 * padB.length);
                return byArray2;
            }
            case 12: {
                System.arraycopy(UtilsYP.devHexa(padC), 0, byArray2, byArray.length, 2 * padC.length);
                return byArray2;
            }
            case 13: {
                System.arraycopy(UtilsYP.devHexa(padD), 0, byArray2, byArray.length, 2 * padD.length);
                return byArray2;
            }
            case 14: {
                System.arraycopy(UtilsYP.devHexa(padE), 0, byArray2, byArray.length, padE.length);
                return byArray2;
            }
            case 15: {
                System.arraycopy(UtilsYP.devHexa(padF), 0, byArray2, byArray.length, padF.length);
                return byArray2;
            }
            case 16: {
                System.arraycopy(UtilsYP.devHexa(pad10), 0, byArray2, byArray.length, pad10.length);
                return byArray2;
            }
        }
        return null;
    }

    private static byte[] pad16ModPKCS5(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        switch (inputFormatEnumeration) {
            case HexEncodedBinary: {
                return YP_TCD_CRYPTO_PayShield.padModPKCS5Hex(16, byArray);
            }
        }
        return YP_TCD_CRYPTO_PayShield.padModPKCS5Bin(16, byArray);
    }

    private static byte[] pad8ModPKCS5(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        switch (inputFormatEnumeration) {
            case HexEncodedBinary: {
                return YP_TCD_CRYPTO_PayShield.padModPKCS5Hex(8, byArray);
            }
        }
        return YP_TCD_CRYPTO_PayShield.padModPKCS5Bin(8, byArray);
    }

    private static byte[] unpadModPKCS5Bin(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        byte[] byArray2 = null;
        byte by = byArray[byArray.length - 1];
        byArray2 = new byte[byArray.length - by];
        System.arraycopy(byArray, 0, byArray2, 0, byArray2.length);
        return byArray2;
    }

    private static byte[] unpadModPKCS5Hex(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        byte[] byArray2 = null;
        int n = byArray[byArray.length];
        if (n == 0) {
            n = 16;
        }
        byArray2 = new byte[byArray.length - 2 * n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray2.length);
        return byArray2;
    }

    private static byte[] unpadModPKCS5(byte[] byArray, InputFormatEnumeration inputFormatEnumeration) {
        switch (inputFormatEnumeration) {
            case HexEncodedBinary: {
                return YP_TCD_CRYPTO_PayShield.unpadModPKCS5Hex(byArray);
            }
        }
        return YP_TCD_CRYPTO_PayShield.unpadModPKCS5Bin(byArray);
    }

    @Override
    public byte[] decryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        throw new Exception("decryptPIN() Not done");
    }

    private int recv(Socket socket, InputStream inputStream, byte[] byArray) {
        long l = System.currentTimeMillis();
        try {
            socket.setSoTimeout(10000);
        }
        catch (SocketException socketException) {
            this.logger(2, "recv() Timeout Initialisation error :" + socketException);
            return -1;
        }
        int n = 0;
        do {
            int n2;
            try {
                n2 = inputStream.read(byArray, n, byArray.length - n);
            }
            catch (IOException iOException) {
                this.logger(2, "recv() " + iOException);
                return -1;
            }
            if (n2 < 0) {
                this.logger(2, "recv() read returned:" + n2);
                return n2;
            }
            if (n2 == 0) {
                if (!UtilsYP.isTimeout(l, 10000)) continue;
                this.logger(2, "recv() timeout !!! " + n + " vs " + n);
                return 0;
            }
            n += n2;
        } while (byArray.length != n);
        return 1;
    }

    @Override
    public byte[] exportKey(String string, List<Property> list, String string2, List<Property> list2) {
        try {
            String string3 = this.getPropertie(list, "KEY_BLOCK");
            if (string3 == null || string3.isEmpty()) {
                this.logger(2, "exportKey() No Key block propertie found for " + string);
                throw new Exception("decrypt() No Key block propertie found for " + string);
            }
            String string4 = this.getPropertie(list2, "KEY_BLOCK");
            if (string4 == null || string4.isEmpty()) {
                this.logger(2, "exportKey() No Key block propertie found for " + string2);
                throw new Exception("decrypt() No Key block propertie found for " + string2);
            }
            byte[] byArray = this.formatExportPINKeyMessage(string3, string4);
            byte[] byArray2 = this.payshieldRequest(byArray, "exportKey");
            return this.getDataFromExportPINKeyResponse(byArray2);
        }
        catch (Exception exception) {
            this.logger(2, "exportKey: " + exception.toString());
            return null;
        }
    }

    @Override
    public byte[] importKey(String string, String string2, List<Property> list) {
        try {
            String string3 = this.getPropertie(list, "KEY_BLOCK");
            if (string3 == null || string3.isEmpty()) {
                this.logger(2, "importKey() No Key block propertie found for " + string2);
                throw new Exception("decrypt() No Key block propertie found for " + string2);
            }
            byte[] byArray = this.formatImportKeyMessage(string, string3);
            byte[] byArray2 = this.payshieldRequest(byArray, "importKey");
            return this.getDataFromImportKeyResponse(byArray2);
        }
        catch (Exception exception) {
            this.logger(2, "importKey: " + exception.toString());
            return null;
        }
    }

    private String getText(byte[] byArray) {
        switch (new String(byArray)) {
            case "00": {
                return "No error";
            }
            case "01": {
                return "Verification failure or warning of imported key parity error";
            }
            case "02": {
                return "Key inappropriate length for algorithm";
            }
            case "04": {
                return "Invalid key type code";
            }
            case "05": {
                return "Invalid key length flag";
            }
            case "10": {
                return "Source key parity error";
            }
            case "11": {
                return "Destination key parity error or key all zeros";
            }
            case "12": {
                return "Contents of user storage not available. Reset, power-down or overwrite";
            }
            case "13": {
                return "Invalid LMK Identifier";
            }
            case "14": {
                return "PIN encrypted under LMK pair 02-03 is invalid";
            }
            case "15": {
                return "Invalid input data (invalid format, invalid characters, or not enough data provided)";
            }
            case "16": {
                return "Console or printer not ready or not connected";
            }
            case "17": {
                return "HSM not in the Authorised state, or not enabled for clear PIN output, or both";
            }
            case "18": {
                return "Document format definition not loaded";
            }
            case "19": {
                return "Specified Diebold Table is invalid";
            }
            case "20": {
                return "PIN block does not contain valid values";
            }
            case "21": {
                return "Invalid index value, or index/block count would cause an overflow condition";
            }
            case "22": {
                return "Invalid account number";
            }
            case "23": {
                return "Invalid PIN block format code";
            }
            case "24": {
                return "PIN is fewer than 4 or more than 12 digits in length";
            }
            case "25": {
                return "Decimalisation Table error";
            }
            case "26": {
                return "Invalid key scheme";
            }
            case "27": {
                return "Incompatible key length";
            }
            case "28": {
                return "Invalid key type";
            }
            case "29": {
                return "Key function not permitted";
            }
            case "30": {
                return "Invalid reference number";
            }
            case "31": {
                return "Insufficient solicitation entries for batch";
            }
            case "33": {
                return "LMK key change storage is corrupted";
            }
            case "39": {
                return "Fraud detection";
            }
            case "40": {
                return "Invalid checksum";
            }
            case "41": {
                return "Internal hardware/software error: bad RAM, invalid error codes, etc.";
            }
            case "42": {
                return "DES failure";
            }
            case "47": {
                return "Algorithm not licensed Thales \u2013 Information Technology Security 469";
            }
            case "49": {
                return "Private key error, report to supervisor";
            }
            case "51": {
                return "Invalid message header";
            }
            case "65": {
                return "Transaction Key Scheme set to None";
            }
            case "67": {
                return "Command not licensed";
            }
            case "68": {
                return "Command has been disabled";
            }
            case "69": {
                return "PIN block format has been disabled";
            }
            case "74": {
                return "Invalid digest info syntax (no hash mode only)";
            }
            case "75": {
                return "Single length key masquerading as double or triple length key";
            }
            case "76": {
                return "Public key length error";
            }
            case "77": {
                return "Clear data block error";
            }
            case "78": {
                return "Private key length error";
            }
            case "79": {
                return "Hash algorithm object identifier error";
            }
            case "80": {
                return "Data length error. The amount of MAC data (or other data) is greater than or less than the expected amount.";
            }
            case "81": {
                return "Invalid certificate header";
            }
            case "82": {
                return "Invalid check value length";
            }
            case "83": {
                return "Key block format error";
            }
            case "84": {
                return "Key block check value error";
            }
            case "85": {
                return "Invalid OAEP Mask Generation Function";
            }
            case "86": {
                return "Invalid OAEP MGF Hash Function";
            }
            case "87": {
                return "OAEP Parameter Error";
            }
            case "90": {
                return "Data parity error in the request message received by the HSM";
            }
            case "91": {
                return "Longitudinal Redundancy Check (LRC) character does not match the value computed over the input data (when the HSM has received a transparent async packet)";
            }
            case "92": {
                return "The Count value (for the Command/Data field) is not between limits, or is not correct (when the HSM has received a transparent async packet)";
            }
            case "A1": {
                return "Incompatible LMK schemes";
            }
            case "A2": {
                return "Incompatible LMK identifiers";
            }
            case "A3": {
                return "Incompatible keyblock LMK identifiers";
            }
            case "A4": {
                return "Key block authentication failure";
            }
            case "A5": {
                return "Incompatible key length";
            }
            case "A6": {
                return "Invalid key usage";
            }
            case "A7": {
                return "Invalid algorithm";
            }
            case "A8": {
                return "Invalid mode of use";
            }
            case "A9": {
                return "Invalid key version number";
            }
            case "AA": {
                return "Invalid export field";
            }
            case "AB": {
                return "Invalid number of optional blocks";
            }
            case "AC": {
                return "Optional header block error";
            }
            case "AD": {
                return "Key status optional block error";
            }
            case "AE": {
                return "Invalid start date/time";
            }
            case "AF": {
                return "Invalid end date/time";
            }
            case "B0": {
                return "Invalid encryption mode";
            }
            case "B1": {
                return "Invalid authentication mode";
            }
            case "B2": {
                return "Miscellaneous keyblock error";
            }
            case "B3": {
                return "Invalid number of optional blocks";
            }
            case "B4": {
                return "Optional block data error";
            }
            case "B5": {
                return "Incompatible components";
            }
            case "B6": {
                return "Incompatible key status optional blocks";
            }
            case "B7": {
                return "Invalid change field";
            }
            case "B8": {
                return "Invalid old value";
            }
            case "B9": {
                return "Invalid new value";
            }
            case "BA": {
                return "No key status block in the keyblock";
            }
            case "BB": {
                return "Invalid wrapping key";
            }
            case "BC": {
                return "Repeated optional block";
            }
            case "BD": {
                return "Incompatible key types";
            }
        }
        return "UNKNOWN !!!";
    }

    @Override
    public byte[][] encryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        throw new Exception("encryptPIN() Not done");
    }

    private static enum EncryptionModeEnumeration {
        ECB("00"),
        CBC("01"),
        CFB8("02"),
        CFB64("03");

        private String encryptionMode;

        private EncryptionModeEnumeration(String string2) {
            this.encryptionMode = string2;
        }

        public String getValue() {
            return this.encryptionMode;
        }
    }

    private static enum InputFormatEnumeration {
        Binary("0"),
        HexEncodedBinary("1"),
        Text("2");

        private String inputFormat;

        private InputFormatEnumeration(String string2) {
            this.inputFormat = string2;
        }

        public String getValue() {
            return this.inputFormat;
        }
    }

    private static enum MacModeEnumeration {
        Verify_8B_Mac_BD("1"),
        Verify_8B_Mac_UD("A"),
        Verify_4BL_Approval_Mac_BD("2"),
        Verify_4BL_Approval_Mac_UD("B"),
        Verify_4BR_Decline_Mac_BD("3"),
        Verify_4BR_Decline_Mac_UD("C"),
        Generate_8B_Mac_BD("4"),
        Generate_8B_Mac_UD("D"),
        Generate_4BL_Approval_Mac_BD("5"),
        Generate_4BL_Approval_Mac_UD("E"),
        Generate_4BR_Decline_Mac_BD("6"),
        Generate_4BR_Decline_Mac_UD("F");

        private String macMode;

        private MacModeEnumeration(String string2) {
            this.macMode = string2;
        }

        public String getValue() {
            return this.macMode;
        }
    }

    private static enum OutputFormatEnumeration {
        Binary("0"),
        HexEncodedBinary("1"),
        Text("2");

        private String outputFormat;

        private OutputFormatEnumeration(String string2) {
            this.outputFormat = string2;
        }

        public String getValue() {
            return this.outputFormat;
        }
    }

    private static enum PayshieldCommandEnumeration {
        EncryptRequest("M0"),
        EncryptResponse("M1"),
        DecryptRequest("M2"),
        DecryptResponse("M3"),
        GenerateVerifyMACRequest("GW"),
        GenerateVerifyMACResponse("GX"),
        GenerateKey("A0"),
        GenerateKeyResponse("A1"),
        Diagnostics("NC"),
        DiagnosticsResponse("ND"),
        DUKPTTranslatePINRequest("G0"),
        DUKPTTranslatePINResponse("G1"),
        ImportKeyRequest("A6"),
        ImportKeyResponse("A7"),
        ExportPINKeyRequest("A8"),
        ExportPINKeyResponse("A9");

        private String commandCode;

        private PayshieldCommandEnumeration(String string2) {
            this.commandCode = string2;
        }

        public String getValue() {
            return this.commandCode;
        }
    }
}

