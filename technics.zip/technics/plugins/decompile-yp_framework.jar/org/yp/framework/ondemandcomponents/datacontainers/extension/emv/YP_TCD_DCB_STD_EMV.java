/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.emv;

import java.lang.reflect.Field;
import java.util.List;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.transaction.DAO_TRS_EXT_Emv;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects.DAO_EMV_AID;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects.DAO_EMV_AID_Parameters;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects.DAO_EMV_KEYS;
import org.yp.utils.ByteBuilder;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCB_STD_EMV
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_EMV {
    private YP_TCD_DCC_Business dataContainer;
    private YP_TCD_DesignAccesObject emv_AID;
    private long cksEMV_AID = -1L;
    private YP_TCD_DesignAccesObject emv_AID_Parameters;
    private long cksEMV_AID_Parameters = -1L;
    private YP_TCD_DesignAccesObject emv_KEYS;
    private long cksEMV_emv_KEYS = -1L;

    public YP_TCD_DCB_STD_EMV(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
            if (this.dataContainer.transaction != null) {
                this.dataContainer.extendTransactionDAO(new DAO_TRS_EXT_Emv());
            }
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.emv_AID = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_EMV_AID.class, 0, 0, null);
                this.emv_AID_Parameters = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_EMV_AID_Parameters.class, 0, 0, null);
                this.emv_KEYS = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_EMV_KEYS.class, 0, 0, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "initialize()" + exception);
            }
        }
        return 1;
    }

    @Override
    public long getAIDTableChecksum() {
        if (this.cksEMV_AID == -1L) {
            try {
                this.lock();
                if (this.cksEMV_AID == -1L) {
                    this.cksEMV_AID = this.getCKS(this.emv_AID);
                }
            }
            finally {
                this.unlock();
            }
        }
        return this.cksEMV_AID;
    }

    @Override
    public long getAIDParametersTableChecksum() {
        if (this.cksEMV_AID_Parameters == -1L) {
            try {
                this.lock();
                if (this.cksEMV_AID_Parameters == -1L) {
                    this.cksEMV_AID_Parameters = this.getCKS(this.emv_AID_Parameters);
                }
            }
            finally {
                this.unlock();
            }
        }
        return this.cksEMV_AID_Parameters;
    }

    @Override
    public long getKeysTableChecksum() {
        if (this.cksEMV_emv_KEYS == -1L) {
            try {
                this.lock();
                if (this.cksEMV_emv_KEYS == -1L) {
                    this.cksEMV_emv_KEYS = this.getCKS(this.emv_KEYS);
                }
            }
            finally {
                this.unlock();
            }
        }
        return this.cksEMV_emv_KEYS;
    }

    protected long getCKS(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        Object object2;
        if (yP_TCD_DesignAccesObject == null) {
            return 0L;
        }
        ByteBuilder byteBuilder = new ByteBuilder();
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        for (Object object2 : yP_TCD_DesignAccesObject) {
            ((YP_Row)object2).serialize(byteBuilder, fieldArray);
        }
        if (byteBuilder.size() == 0) {
            return 0L;
        }
        object2 = new CRC32();
        object2.update(byteBuilder.data(), 0, byteBuilder.size());
        long l = object2.getValue();
        return l;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.emv_AID) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() emv_AID");
            }
            this.cksEMV_AID = -1L;
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.emv_AID_Parameters) {
            this.cksEMV_AID_Parameters = -1L;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() emv_AID_Parameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.emv_KEYS) {
            this.cksEMV_emv_KEYS = -1L;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() emv_KEYS");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.emv_AID) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() emv_AID");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.emv_AID_Parameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() emv_AID_Parameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.emv_KEYS) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() emv_KEYS");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.emv_AID != null && clazz == this.emv_AID.getRowClass()) {
            this.cksEMV_AID = -1L;
        } else if (this.emv_AID_Parameters != null && clazz == this.emv_AID_Parameters.getRowClass()) {
            this.cksEMV_AID_Parameters = -1L;
        } else if (this.emv_KEYS != null && clazz == this.emv_KEYS.getRowClass()) {
            this.cksEMV_emv_KEYS = -1L;
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionEMV";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public YP_TCD_DesignAccesObject getAIDTable() {
        return this.emv_AID;
    }

    @Override
    public YP_TCD_DesignAccesObject getAIDParametersTable() {
        return this.emv_AID_Parameters;
    }

    @Override
    public YP_TCD_DesignAccesObject getKeysTable() {
        return this.emv_KEYS;
    }

    @Override
    public YP_Row getAIDParameters(String string) {
        if (string == null || string.length() < 10) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.emv_AID_Parameters);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string.substring(0, 10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.substring(10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list = this.emv_AID_Parameters.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getAIDParameters() not found :" + string);
            }
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<YP_Row> getAIDList(String string) {
        if (string == null || string.length() < 10) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.emv_AID);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string.substring(0, 10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.substring(10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        return this.emv_AID.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public List<Integer> getTAVNList(String string) {
        if (string == null || string.length() < 10) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.emv_AID);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string.substring(0, 10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.substring(10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        return this.emv_AID.getDistinctValueListSuchAs("terminalApplicationVersionNumber", yP_ComplexGabarit);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int setTVR(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n, int n2) {
        if (n < 1 || n > 5) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setTVR() bad paremters : " + n + " " + n2);
            }
            return -1;
        }
        if (n2 < 1 || n2 > 8) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setTVR() bad paremters : " + n + " " + n2);
            }
            return -1;
        }
        try {
            String string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("tvr"));
            if (string == null || string.isEmpty()) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "setTVR() we create a new empty TVR");
                }
                yP_TCD_DC_Transaction.setExtensionValue("tvr", "0000000000");
                string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("tvr"));
                if (string == null || string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setTVR() unable to retrieve TVR");
                    }
                    return -1;
                }
            }
            byte[] byArray = UtilsYP.redHexa(string);
            switch (n2) {
                case 1: {
                    if ((byArray[n - 1] & 1) == 1) {
                        return 0;
                    }
                    int n3 = n - 1;
                    byArray[n3] = (byte)(byArray[n3] | 1);
                    break;
                }
                case 2: {
                    if ((byArray[n - 1] & 2) == 2) {
                        return 0;
                    }
                    int n4 = n - 1;
                    byArray[n4] = (byte)(byArray[n4] | 2);
                    break;
                }
                case 3: {
                    if ((byArray[n - 1] & 4) == 4) {
                        return 0;
                    }
                    int n5 = n - 1;
                    byArray[n5] = (byte)(byArray[n5] | 4);
                    break;
                }
                case 4: {
                    if ((byArray[n - 1] & 8) == 8) {
                        return 0;
                    }
                    int n6 = n - 1;
                    byArray[n6] = (byte)(byArray[n6] | 8);
                    break;
                }
                case 5: {
                    if ((byArray[n - 1] & 0x10) == 16) {
                        return 0;
                    }
                    int n7 = n - 1;
                    byArray[n7] = (byte)(byArray[n7] | 0x10);
                    break;
                }
                case 6: {
                    if ((byArray[n - 1] & 0x20) == 32) {
                        return 0;
                    }
                    int n8 = n - 1;
                    byArray[n8] = (byte)(byArray[n8] | 0x20);
                    break;
                }
                case 7: {
                    if ((byArray[n - 1] & 0x40) == 64) {
                        return 0;
                    }
                    int n9 = n - 1;
                    byArray[n9] = (byte)(byArray[n9] | 0x40);
                    break;
                }
                case 8: {
                    if ((byArray[n - 1] & 0xFFFFFF80) == -128) {
                        return 0;
                    }
                    int n10 = n - 1;
                    byArray[n10] = (byte)(byArray[n10] | 0xFFFFFF80);
                    break;
                }
            }
            yP_TCD_DC_Transaction.setExtensionValue("tvr", UtilsYP.devHexa(byArray));
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setTVR() " + exception);
            }
            return -1;
        }
    }

    @Override
    public int resetTVR(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            yP_TCD_DC_Transaction.setExtensionValue("tvr", "0000000000");
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "resetTVR() " + exception);
            }
            return -1;
        }
    }

    @Override
    public YP_Row getAIDData(String string) {
        if (string == null || string.length() < 10) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.emv_AID);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string.substring(0, 10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.substring(10).toUpperCase());
        yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list = this.emv_AID.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getAIDData() not found :" + string);
            }
            return null;
        }
        return list.get(0);
    }
}

