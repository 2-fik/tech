/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import javax.net.ServerSocketFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_HTTP_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private final String USER_AGENT = "Mozilla/5.0";
    private String PROTOCOL_PROPERTIES;
    private final int connectionPort = 0;
    private DataOutputStream outputStream = null;
    private BufferedReader inputStream = null;
    private ServerSocket serverSocket = null;
    private final ServerSocketFactory serversocketfactory = null;
    private String ipServer = null;
    private int portServer = 0;
    private String ressource = null;
    private int connectionTimeoutMS = 3499;
    private String sessionTimeOut = null;
    private URL url = null;
    private HttpURLConnection conHttp = null;
    private String proxyType = null;
    private String proxyHost = null;
    private int proxyPort = 0;
    private final byte[] cleanMessage = new byte[1024];

    public YP_TCD_PHYS_HTTP_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int close() {
        this.outputStream = null;
        this.inputStream = null;
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server HTTP closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server HTTP close failed  :" + iOException);
                return -1;
            }
        }
        if (this.conHttp != null) {
            try {
                if (this.outputStream != null) {
                    this.outputStream.flush();
                    this.outputStream.close();
                    this.outputStream = null;
                }
                if (this.inputStream != null) {
                    this.inputStream.close();
                    this.inputStream = null;
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Client HTTP closed...");
                }
                this.conHttp = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() HTTP close error :" + iOException);
                this.conHttp = null;
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "HTTPConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int openServer() {
        if (this.serverSocket != null) {
            return 1;
        }
        try {
            this.serverSocket = this.serversocketfactory.createServerSocket(0);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "openServer() Waiting for connections on port" + this.serverSocket.getLocalPort() + "...");
            }
            if (this.getLogLevel() >= 4) {
                this.printServerSocketInfo(this.serverSocket);
            }
            return 1;
        }
        catch (IOException iOException) {
            this.logger(1, "openServer() Can't connect a socket to port 0 " + iOException);
            return -1;
        }
    }

    @Override
    public Object waitConnection() {
        try {
            this.serverSocket.setSoTimeout(this.getConnectionTimeout());
        }
        catch (SocketException socketException) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() setSoTimeout " + socketException);
            }
            return null;
        }
        try {
            Socket socket = this.serverSocket.accept();
            if (this.getLogLevel() >= 4) {
                this.printSocketInfo(this.conHttp);
            }
            return socket;
        }
        catch (IOException iOException) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() Timeout " + iOException);
            }
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public int recv(byte[] var1_1, int var2_2, int var3_3, int var4_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 6[DOLOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public int clean(int n) {
        long l = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder();
        this.conHttp.setReadTimeout(n);
        do {
            try {
                String string;
                while ((string = this.inputStream.readLine()) != null) {
                    stringBuilder.append(string);
                }
                if (this.inputStream != null) {
                    this.inputStream.close();
                    this.inputStream = null;
                }
                if (stringBuilder.length() > 0) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, UtilsYP.getFormattedLog(2, this.cleanMessage, 0, stringBuilder.length()));
                        continue;
                    }
                    if (this.getLogLevel() < 4) continue;
                    this.logger(4, "clean() bytes cleaned :" + stringBuilder.length());
                    continue;
                }
                if (stringBuilder.length() == 0) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "clean() nothing...");
                    continue;
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "clean() error :" + stringBuilder.length());
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "clean() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "clean() Read error..." + exception);
                return -1;
            }
        } while (!UtilsYP.isTimeout(l, n));
        return 1;
    }

    @Override
    public int available() {
        try {
            if (this.inputStream.ready()) {
                return 1;
            }
        }
        catch (IOException iOException) {
            this.logger(2, "available() Error..." + iOException);
        }
        return 0;
    }

    @Override
    public int send(byte[] byArray, int n) {
        int n2;
        block16: {
            try {
                this.outputStream = new DataOutputStream(this.conHttp.getOutputStream());
            }
            catch (IOException iOException) {
                this.logger(2, "initialize():" + iOException);
                return -1;
            }
            try {
                this.outputStream.write(byArray, 0, n);
                this.outputStream.flush();
                n2 = this.conHttp.getResponseCode();
                if (n2 >= 200 && n2 < 300) break block16;
                if (this.getLogLevel() >= 6) {
                    this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
                }
                try {
                    InputStream inputStream = this.conHttp.getInputStream();
                    if (inputStream == null) {
                        inputStream = this.conHttp.getErrorStream();
                    }
                    if (inputStream != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                        String string = null;
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((string = bufferedReader.readLine()) != null) {
                            stringBuilder.append(String.valueOf(string) + "\n");
                        }
                        bufferedReader.close();
                        this.logger(4, "send() Content: " + stringBuilder.toString());
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "send() " + exception);
                }
                this.logger(2, "send() HTTP Post: " + n2);
                return -1;
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "send() Write error..." + iOException);
                }
                return -1;
            }
        }
        if (n2 != 200) {
            this.logger(3, "send() HTTP Post: " + n2);
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
        } else if (this.getLogLevel() >= 4) {
            this.logger(4, "send() bytes sent :" + n);
        }
        return n;
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        try {
            return this.conHttp.getURL().getHost();
        }
        catch (Exception exception) {
            this.logger(2, "getIP() " + exception);
            return null;
        }
    }

    @Override
    public int openClient(Object ... objectArray) {
        block35: {
            block34: {
                if (objectArray != null) break block34;
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                if (this.ipServer == null) {
                    this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                }
                this.ressource = ((YP_Row)objectArray[0]).getFieldStringValueByName("ressource");
                if (this.connectionTimeoutMS == 3499) {
                    this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                }
                if (this.sessionTimeOut == null) {
                    this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
                }
                if (this.proxyType == null) {
                    this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
                }
                if (this.proxyHost == null) {
                    this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
                }
                if (this.proxyPort == 0) {
                    this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
                }
                this.PROTOCOL_PROPERTIES = ((YP_Row)objectArray[0]).getExtensionValueAsString("protocolProperties");
            } else if (objectArray.length >= 3 && objectArray[0] instanceof String && objectArray[1] instanceof String && objectArray[2] instanceof String) {
                if (this.ipServer == null) {
                    this.ipServer = (String)objectArray[0];
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt((String)objectArray[1]);
                }
                if (this.ressource == null) {
                    this.ressource = (String)objectArray[2];
                }
                if (objectArray.length > 3 && objectArray[3] instanceof Integer) {
                    this.connectionTimeoutMS = (Integer)objectArray[3];
                }
            }
            if (this.ipServer != null && this.portServer != 0) break block35;
            this.logger(2, "openClient() missing parameters");
            return -1;
        }
        try {
            try {
                Object object;
                this.url = new URL("http", this.ipServer, this.portServer, this.ressource);
                if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "openClient() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
                    }
                    object = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.proxyHost, this.proxyPort));
                    this.conHttp = (HttpURLConnection)this.url.openConnection((Proxy)object);
                } else {
                    this.conHttp = (HttpURLConnection)this.url.openConnection();
                }
                this.conHttp.setDoOutput(true);
                this.conHttp.setDoInput(true);
                this.conHttp.setRequestMethod("POST");
                this.conHttp.setUseCaches(false);
                if (this.PROTOCOL_PROPERTIES != null && !this.PROTOCOL_PROPERTIES.isEmpty()) {
                    try {
                        object = new JSONObject(this.PROTOCOL_PROPERTIES);
                        JSONArray jSONArray = object.getJSONArray("httpHeaders");
                        if (jSONArray != null) {
                            int n = 0;
                            while (n < jSONArray.length()) {
                                Object object2 = jSONArray.get(n);
                                if (object2 instanceof JSONObject) {
                                    JSONObject jSONObject = (JSONObject)object2;
                                    String string = jSONObject.getString("name");
                                    String string2 = jSONObject.getString("value");
                                    if (string != null && !string.isEmpty() && string2 != null && !string2.isEmpty()) {
                                        this.conHttp.setRequestProperty(string, string2);
                                    }
                                }
                                ++n;
                            }
                        }
                    }
                    catch (JSONException jSONException) {
                        this.logger(2, "openClient()  protocolProperties mal forme : ", (Exception)((Object)jSONException));
                    }
                }
                this.conHttp.setRequestProperty("User-Agent", "Mozilla/5.0");
                this.conHttp.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
                object = ((YP_Row)objectArray[0]).getFieldStringValueByName("serviceRequested");
                if (((String)object).contentEquals("IPN")) {
                    this.conHttp.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                } else {
                    this.conHttp.setRequestProperty("Content-Type", "application/xml");
                }
                this.conHttp.setConnectTimeout(this.connectionTimeoutMS);
                this.conHttp.connect();
            }
            catch (MalformedURLException malformedURLException) {
                this.logger(2, "openClient() URL Mal formee : " + malformedURLException);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + " " + exception);
            this.ipServer = null;
            this.conHttp = null;
            this.portServer = 0;
            this.ressource = null;
            this.connectionTimeoutMS = 3499;
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return -1;
        }
        if (this.getLogLevel() >= 4) {
            this.printSocketInfo(this.conHttp);
        }
        return this.initialize();
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for HTTP !!!");
        return null;
    }

    private void printServerSocketInfo(ServerSocket serverSocket) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printServerSocketInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Server socket class: ");
            stringBuilder.append(serverSocket.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker address = ");
            stringBuilder.append(serverSocket.getInetAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker port = ");
            stringBuilder.append(serverSocket.getLocalPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append(UtilsYP.lineSeparator);
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    private void printSocketInfo(HttpURLConnection httpURLConnection) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printHttpConnectionInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Https class: ");
            stringBuilder.append(httpURLConnection.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(httpURLConnection.getURL().getHost());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote port = ");
            stringBuilder.append(httpURLConnection.getURL().getPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Host = ");
            stringBuilder.append(httpURLConnection.getURL().getHost());
            stringBuilder.append("   File = ");
            stringBuilder.append(httpURLConnection.getURL().getFile());
            stringBuilder.append("   Local socket address = ");
            stringBuilder.append(UtilsYP.lineSeparator);
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return;
        }
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }
}

