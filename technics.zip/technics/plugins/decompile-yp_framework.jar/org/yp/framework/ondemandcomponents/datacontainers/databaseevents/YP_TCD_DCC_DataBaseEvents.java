/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.databaseevents;

import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;

public abstract class YP_TCD_DCC_DataBaseEvents
extends YP_TCD_DC_Context {
    public YP_TCD_DCC_DataBaseEvents(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }
}

