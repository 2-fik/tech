/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DAO_LOC_Memory
extends YP_TCD_DAO_LOC {
    private final List<String> memoryList = new ArrayList<String>();

    public YP_TCD_DAO_LOC_Memory(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public String toString() {
        return "DAO_Memory";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int reload() {
        this.isLoadedInMemory = 1;
        this.memoryList.clear();
        int n = this.getDataBaseConnector().sql_Formater.sqlReloadMemory(this);
        if (n == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reload() No result from database");
            }
        } else if (n < 0) {
            this.logger(2, "reload() Error during sqlSelectAll");
            this.isLoadedInMemory = 0;
            return -1;
        }
        this.setIsItAModifiedDAO(false);
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "reload() onChange" + exception);
        }
        this.notifyWatcher();
        this.loadedSinceGMTTime = UtilsYP.getSystemGMTTime();
        this.nbtimeUsedSinceReload.set(0);
        this.isLoadedInMemory = 2;
        return 1;
    }

    @Override
    public int persist() {
        this.prepare();
        boolean bl = false;
        this.lock();
        this.persistInProcess = true;
        if (this.nbConcurrentReadAccess.get() > 0) {
            long l = System.currentTimeMillis();
            while (this.nbConcurrentReadAccess.get() > 0) {
                this.logger(3, "persist() nbConcurrentReadAccess:" + this.nbConcurrentReadAccess);
                UtilsYP.sleep(1);
                if (!UtilsYP.isTimeout(l, 30000)) continue;
                this.logger(2, "persist() nbConcurrentReadAccess reseted to avoid endless loop!!!!!:");
                this.nbConcurrentReadAccess.set(0);
            }
        }
        try {
            try {
                if (this.isItAModifiedDAO()) {
                    try {
                        this.getDataContainerContext().onSaveBefore(this, null, null);
                    }
                    catch (Exception exception) {
                        this.logger(3, "persist() onSaveBefore" + exception);
                    }
                    this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
                    this.getDataBaseConnector().sql_Formater.sqlFillTable(this);
                    this.setIsItAModifiedDAO(false);
                    bl = true;
                }
                if (bl) {
                    this.reload();
                }
            }
            catch (Exception exception) {
                this.logger(3, "persist() : " + exception);
                this.persistInProcess = false;
                this.unlock();
                return -1;
            }
        }
        finally {
            this.persistInProcess = false;
            this.unlock();
        }
        if (bl) {
            this.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            this.getDataContainerContext().updateTableStatus(this);
            try {
                this.getDataContainerContext().onSaveAfter(this, null, null);
            }
            catch (Exception exception) {
                this.logger(3, "persist() onSaveAfter" + exception);
            }
            try {
                this.getDataContainerContext().onChange(this);
            }
            catch (Exception exception) {
                this.logger(2, "persist() onChange" + exception);
            }
            this.notifyWatcher();
            return 1;
        }
        this.logger(3, "persist() : Nothing to do");
        return 0;
    }

    @Override
    public int persist(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        this.prepare();
        if (this.isItAClonedDAO()) {
            this.logger(2, "persist() : can't persist a cloned Object");
            return -1;
        }
        this.lock();
        this.persistInProcess = true;
        if (this.nbConcurrentReadAccess.get() > 0) {
            long l = System.currentTimeMillis();
            while (this.nbConcurrentReadAccess.get() > 0) {
                this.logger(3, "persist() nbConcurrentReadAccess:" + this.nbConcurrentReadAccess);
                UtilsYP.sleep(1);
                if (!UtilsYP.isTimeout(l, 30000)) continue;
                this.logger(2, "persist() nbConcurrentReadAccess reseted to avoid endless loop!!!!!:");
                this.nbConcurrentReadAccess.set(0);
            }
        }
        try {
            try {
                try {
                    this.getDataContainerContext().onSaveBefore(this, yP_TCD_DAO_LOC_Table.generique, null);
                }
                catch (Exception exception) {
                    this.logger(3, "persist() onSaveBefore" + exception);
                }
                int n = yP_TCD_DAO_LOC_Table.generique.size();
                while (n > 0) {
                    if (yP_TCD_DAO_LOC_Table.generique.get(n - 1).getModifierFlag() == 1) {
                        yP_TCD_DAO_LOC_Table.generique.remove(n - 1);
                    }
                    --n;
                }
                this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
                this.getDataBaseConnector().sql_Formater.sqlFillTable(this);
                this.setIsItAModifiedDAO(false);
                this.reload();
            }
            catch (Exception exception) {
                this.logger(3, "persist() : " + exception);
                this.persistInProcess = false;
                this.unlock();
                return -1;
            }
        }
        finally {
            this.persistInProcess = false;
            this.unlock();
        }
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 1;
    }

    @Override
    public int addRow(YP_Row yP_Row) {
        this.prepare();
        String string = yP_Row.serialize();
        this.lock();
        try {
            this.memoryList.add(string);
            this.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "addRow() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int addRow(YP_Row yP_Row, boolean bl) {
        return this.addRow(yP_Row);
    }

    @Override
    public int updateRowSuchAs(YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRowSuchAs() is not allowed !!!");
        }
        List<YP_Row> list = this.getRowListSuchAs(0, n, yP_ComplexGabaritArray);
        if (list == null || list.isEmpty()) {
            this.logger(3, "updateRowSuchAs() no row to update");
            return 0;
        }
        int n2 = YP_Row.updateRowList(list, yP_Row);
        if (n2 == 1) {
            for (YP_Row yP_Row2 : list) {
                yP_Row2.setIsItAClonedRow(false);
            }
            YP_Row.persistList(list);
            this.reload();
            return list.size();
        }
        return n2;
    }

    @Override
    public int deleteRows(boolean bl) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRows() is not allowed !!!");
        }
        this.prepare();
        try {
            this.lock();
            this.setIsItAModifiedDAO(true);
            this.memoryList.clear();
            if (bl) {
                int n = this.persist();
                return n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deleteRows() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int deleteRowsSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRowsSuchAs() is not allowed !!!");
        }
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            return this.deleteRows(true);
        }
        this.prepare();
        try {
            this.lock();
            List<YP_Row> list = this.getRowListSuchAs(yP_ComplexGabaritArray);
            if (list == null || list.isEmpty()) {
                return 0;
            }
            int n = this.memoryList.size() - 1;
            while (n >= 0) {
                YP_Row yP_Row = this.getPrivateRowAt(n);
                int n2 = 0;
                while (n2 < list.size()) {
                    YP_Row yP_Row2 = list.get(n2);
                    if (yP_Row2.equals(yP_Row)) {
                        list.remove(n2);
                        this.memoryList.remove(n);
                        break;
                    }
                    ++n2;
                }
                --n;
            }
            this.setIsItAModifiedDAO(true);
            this.persist();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deleteRowsSuchAs() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    private YP_Row getPrivateRowAt(int n) {
        String string = this.memoryList.get(n);
        YP_Row yP_Row = this.getNewRow();
        yP_Row.deserialize(string);
        yP_Row.setModifierFlag(0);
        return yP_Row;
    }

    @Override
    public YP_Row getRowAt(int n) {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            YP_Row yP_Row = this.getPrivateRowAt(n);
            return yP_Row;
        }
        catch (Exception exception) {
            if (n >= this.size()) {
                this.logger(3, "getRowAt() index too big:" + n + " " + this.size());
            } else {
                this.logger(2, "getRowAt() " + exception);
            }
            return null;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    protected YP_Row getRowAt(int n, boolean bl) {
        this.prepare();
        if (bl) {
            return this.getRowAt(n);
        }
        try {
            return this.getPrivateRowAt(n);
        }
        catch (Exception exception) {
            this.logger(2, "getRowAt() " + exception);
            if (n >= this.size()) {
                this.logger(2, "getRowAt() index too big");
            }
            return null;
        }
    }

    @Override
    public int size() {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            int n = this.memoryList.size();
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "size() " + exception);
            return -1;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    public YP_Row getRowByPrimaryKey(long l) {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            int n = 0;
            while (n < this.size()) {
                YP_Row yP_Row = this.getPrivateRowAt(n);
                if (l == yP_Row.getPrimaryKey()) {
                    YP_Row yP_Row2 = yP_Row;
                    return yP_Row2;
                }
                ++n;
            }
            this.logger(2, "getRowByPrimaryKey() not found " + l + " " + this.getFullTableName());
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getRowByPrimaryKey() " + exception);
            return null;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        try {
            this.memoryList.clear();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "shutdown() error :" + exception);
            return -1;
        }
    }

    public List<String> getMemoryList() {
        return this.memoryList;
    }

    @Override
    public int unload() {
        try {
            this.lock();
            if (this.isLoadedInMemory != 2) {
                return 0;
            }
            this.isLoadedInMemory = 3;
            this.memoryList.clear();
            this.loadedSinceGMTTime = null;
            this.nbtimeUsedSinceReload.set(0);
            this.isLoadedInMemory = 0;
            return 1;
        }
        catch (Exception exception) {
            this.logger(3, "unload()" + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public boolean isEmpty() {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            boolean bl2 = this.memoryList.isEmpty();
            return bl2;
        }
        catch (Exception exception) {
            this.logger(2, "isEmpty() " + exception);
            return true;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }
}

