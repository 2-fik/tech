/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.CardHolderAuthenticationEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.RealisationModeEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class DAO_SmartTPE_Transaction
extends YP_Row {
    @PrimaryKey
    public long idSmartTPE_Transaction = 0L;
    public byte[] merchantTransactionIdentifier = new byte[20];
    public TransactionTypeEnumeration type;
    public long amount = 0L;
    public byte[] currency = new byte[3];
    public Timestamp datetime = new Timestamp(0L);
    public RealisationModeEnumeration status;
    public byte[] maskedPAN = new byte[19];
    public byte[] userName = new byte[32];
    public byte[] merchantContractIdentifier = new byte[10];
    public CardHolderAuthenticationEnumeration verificationMethod;
    public byte[] authorizationNumber = new byte[6];
    public byte[] authorizationRespCode = new byte[3];
    public byte[] nepSAServerResponse = new byte[32];
    public byte[] dongle_serial = new byte[32];
    public byte[] dongle_model = new byte[32];
    public byte[] scheme = new byte[32];
    public EntryModeEnumeration entryCondition;
    public byte[] applicationType = new byte[32];
    public byte[] customerTillReceipt = new byte[1024];
    public byte[] merchantTillReceipt = new byte[1024];
    public byte[] customerTillReceiptSms = new byte[160];
    public byte[] cardToken = new byte[64];
    public byte[] privateData = new byte[64];
    public int responseCode = 0;
    public byte[] responseMessage = new byte[128];
    public byte[] responseContent = new byte[256];
    public int currentTry = 0;
}

