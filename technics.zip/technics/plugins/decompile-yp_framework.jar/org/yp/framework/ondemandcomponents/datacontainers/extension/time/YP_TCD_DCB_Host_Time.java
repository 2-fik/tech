/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.time;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.YP_TCD_DCB_Interface_Time;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.designaccesobjects.DAO_STD_Time;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCB_Host_Time
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Time {
    private YP_TCD_DCC_Business dataContainer;
    public YP_TCD_DesignAccesObject time;
    private Long systemToGMTOffsetInMS = null;

    public YP_TCD_DCB_Host_Time(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.time = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_STD_Time.class, 0, 0, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "YP_TCD_DCB_Host_Time" + exception);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionHost_Time";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.time) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() time");
            }
            this.systemToGMTOffsetInMS = null;
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.time) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() time");
            }
            this.systemToGMTOffsetInMS = null;
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.time) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() time");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public Calendar getAppliGMTTime() {
        Calendar calendar = UtilsYP.getSystemGMTTime();
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getSystemToGMTOffsetInMS());
        return calendar;
    }

    @Override
    public Calendar getAppliGMTTime(long l) {
        Calendar calendar = UtilsYP.getSystemGMTTime(l);
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getSystemToGMTOffsetInMS());
        return calendar;
    }

    @Override
    public Calendar getAppliLocalTime() {
        Calendar calendar = this.getAppliGMTTime();
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getGMTToAppliOffsetInMS(calendar.getTimeInMillis()));
        return calendar;
    }

    @Override
    public Calendar getAppliLocalTime(long l) {
        Calendar calendar = this.getAppliGMTTime(l);
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getGMTToAppliOffsetInMS(calendar.getTimeInMillis()));
        return calendar;
    }

    @Override
    public long getGMTToAppliOffsetInMS(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.time);
        Timestamp timestamp = new Timestamp(l);
        yP_ComplexGabarit.set("lowerGMTPeriod", YP_ComplexGabarit.OPERATOR.LESS, timestamp);
        yP_ComplexGabarit.set("upperGMTPeriod", YP_ComplexGabarit.OPERATOR.GREATER, timestamp);
        List<YP_Row> list = this.time.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            String string;
            YP_Row yP_Row = this.dataContainer.getContractRow();
            if (yP_Row != null && (string = yP_Row.getFieldStringValueByName("timeZone")) != null && !string.isEmpty()) {
                TimeZone timeZone = TimeZone.getTimeZone(string);
                if (!timeZone.getID().contentEquals(string)) {
                    this.logger(3, "getGMTToAppliOffsetInMS() unknown time zone:" + string + " Use UTC");
                    return 0L;
                }
                return timeZone.getOffset(l);
            }
            return 0L;
        }
        if (list.size() > 1) {
            this.logger(3, "getGMTToAppliOffsetInMS() too many rows");
        }
        return (Long)list.get(0).getFieldValueByName("timeOffsetInMS");
    }

    @Override
    public void resetSystemToGMTOffsetInMS() {
        block2: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.time);
                yP_ComplexGabarit.set("timeZone", YP_ComplexGabarit.OPERATOR.EQUAL, "SystemToGMTOffsetInMS");
                this.time.deleteRowsSuchAs(yP_ComplexGabarit);
                this.time.persist();
                this.systemToGMTOffsetInMS = null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "resetSystemToGMTOffsetInMS() " + exception);
            }
        }
    }

    @Override
    public void setSystemToGMTOffsetInMS(long l) {
        block6: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.time);
                yP_ComplexGabarit.set("timeZone", YP_ComplexGabarit.OPERATOR.EQUAL, "SystemToGMTOffsetInMS");
                List<YP_Row> list = this.time.getRowListSuchAs(yP_ComplexGabarit);
                if (list == null || list.isEmpty()) {
                    YP_Row yP_Row = this.time.getNewRow();
                    yP_Row.set("timeZone", "SystemToGMTOffsetInMS");
                    yP_Row.set("timeOffsetInMS", l);
                    this.time.addRow(yP_Row);
                    this.time.persist();
                } else {
                    long l2;
                    if (list.size() > 1) {
                        this.logger(3, "setSystemToGMTOffsetInMS() too many rows");
                    }
                    if (Math.abs((l2 = ((Long)list.get(0).getFieldValueByName("timeOffsetInMS")).longValue()) - l) > 2000L) {
                        list.get(0).set("timeOffsetInMS", l);
                        this.time.persist();
                    }
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block6;
                this.logger(2, "setSystemToGMTOffsetInMS() " + exception);
            }
        }
        this.systemToGMTOffsetInMS = null;
    }

    @Override
    public long getSystemToGMTOffsetInMS() {
        block7: {
            try {
                if (this.systemToGMTOffsetInMS == null) {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.time);
                    yP_ComplexGabarit.set("timeZone", YP_ComplexGabarit.OPERATOR.EQUAL, "SystemToGMTOffsetInMS");
                    List<YP_Row> list = this.time.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null || list.isEmpty()) {
                        this.systemToGMTOffsetInMS = new Long(0L);
                    } else {
                        if (list.size() > 1) {
                            this.logger(3, "getSystemToGMTOffset() too many rows");
                        }
                        this.systemToGMTOffsetInMS = (Long)list.get(0).getFieldValueByName("timeOffsetInMS");
                    }
                }
                if (this.systemToGMTOffsetInMS != null) {
                    return this.systemToGMTOffsetInMS;
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block7;
                this.logger(2, "getSystemToGMTOffsetInMS() " + exception);
            }
        }
        this.systemToGMTOffsetInMS = null;
        this.logger(3, "getSystemToGMTOffset() system not horodated");
        return 0L;
    }

    @Override
    public Calendar getSystemGMTTime(long l) {
        Calendar calendar = UtilsYP.getSystemGMTTime(l);
        calendar.setTimeInMillis(calendar.getTimeInMillis() - this.getSystemToGMTOffsetInMS() - this.getGMTToAppliOffsetInMS(l));
        if (this.getLogLevel() >= 6) {
            this.logger(6, "getSystemGMTTime() : " + UtilsYP.traceDateAndTime(calendar));
        }
        return calendar;
    }
}

