/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Account;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Context;
import org.yp.utils.ExtendedResult;
import org.yp.utils.enums.TransactionStatusEnumeration;

public class ContextHandler
implements HandlerInterface {
    private static final String CONTRACT_LABEL_TAG = "CONTRACTLABEL:";
    private YP_TCD_DC_Transaction dataContainerTransaction;
    private List<String> positiveApplicationIdentifierList;
    private List<String> negativeApplicationIdentifierList;
    private List<String> positiveMerchantIdentifierList;
    private List<String> negativeMerchantIdentifierList;
    private int t_InstanceNumber = 0;
    private String t_ServiceSequenceNumber = "";
    private String t_ExtendedIdentifier = "";
    private String t_StoreIdentifier = "";
    private long v_TimeoutMS = -1L;
    private String v_ContractLabel;
    public List<YP_TCD_DCC_Group> groupContainers;
    public List<YP_TCD_DCC_Brand> brandContainers;
    public List<YP_TCD_DCC_Merchant> merchantContainers;
    public List<YP_TCD_DCC_Business> businessContainers;
    public HashMap<YP_TCD_DCC_Merchant, List<YP_Row>> storeMap;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        return 1;
    }

    @Override
    public int clear() {
        return 1;
    }

    public List<String> getPositiveApplicationIdentifierList() {
        return this.positiveApplicationIdentifierList;
    }

    public void setPositiveApplicationIdentifierList(List<String> list) {
        this.positiveApplicationIdentifierList = list;
    }

    public List<String> getNegativeApplicationIdentifierList() {
        return this.negativeApplicationIdentifierList;
    }

    public void setNegativeApplicationIdentifierList(List<String> list) {
        this.negativeApplicationIdentifierList = list;
    }

    public List<String> getPositiveMerchantIdentifierList() {
        return this.positiveMerchantIdentifierList;
    }

    public void setPositiveMerchantIdentifierList(List<String> list) {
        this.positiveMerchantIdentifierList = list;
    }

    public List<String> getNegativeMerchantIdentifierList() {
        return this.negativeMerchantIdentifierList;
    }

    public void setNegativeMerchantIdentifierList(List<String> list) {
        this.negativeMerchantIdentifierList = list;
    }

    public void setInstanceNumber(int n) {
        this.t_InstanceNumber = n;
    }

    public int getInstanceNumber() {
        return this.t_InstanceNumber;
    }

    public ContextHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public String getServiceSequenceNumber() {
        return this.t_ServiceSequenceNumber;
    }

    public void setServiceSequenceNumber(String string) {
        this.t_ServiceSequenceNumber = string;
    }

    public void setExtendedIdentifier(String string) {
        this.t_ExtendedIdentifier = string;
    }

    public String getExtendedIdentifier() {
        return this.t_ExtendedIdentifier;
    }

    public void setTimeoutMS(long l) {
        this.v_TimeoutMS = l;
    }

    public long getTimeoutMS() {
        return this.v_TimeoutMS;
    }

    public void setStoreIdentifier(String string) {
        this.t_StoreIdentifier = string;
    }

    public String getStoreIdentifier() {
        return this.t_StoreIdentifier;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int readRequest() {
        String string;
        List<String> list;
        List<String> list2;
        List<String> list3;
        String[] stringArray;
        String[] stringArray2;
        YP_PROT_Context yP_PROT_Context;
        block55: {
            String string2;
            String string3;
            block60: {
                block62: {
                    block61: {
                        block59: {
                            block58: {
                                block57: {
                                    block56: {
                                        Object object;
                                        block54: {
                                            String string4;
                                            int n;
                                            YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
                                            if (!(yP_TCD_PosProtocol instanceof YP_PROT_Context)) {
                                                if (this.dataContainerTransaction.getLogLevel() < 5) return 0;
                                                this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with context");
                                                return 0;
                                            }
                                            yP_PROT_Context = (YP_PROT_Context)((Object)yP_TCD_PosProtocol);
                                            long l = yP_PROT_Context.getTimeoutMS();
                                            if (l >= 0L) {
                                                this.setTimeoutMS(l);
                                            }
                                            if ((n = yP_PROT_Context.getPosNumber()) >= 0) {
                                                this.dataContainerTransaction.setNLPA(n);
                                            }
                                            if ((string3 = yP_PROT_Context.getMerchantIdentifier()) != null && !string3.isEmpty()) {
                                                this.dataContainerTransaction.setContractIdentifier(string3);
                                            }
                                            if ((string4 = yP_PROT_Context.getTerminalIdentifier()) != null && !string4.isEmpty()) {
                                                if (string3 != null && !string3.isEmpty() && this.dataContainerTransaction.getLogLevel() >= 5) {
                                                    this.dataContainerTransaction.logger(5, "readRequest() both merchantIdentifier and terminalIdentifier received");
                                                }
                                                if ((object = this.dataContainerTransaction.getPluginByName("Dispatcher")) != null) {
                                                    try {
                                                        string3 = (String)((YP_Object)object).dealRequest(this.dataContainerTransaction, "getMerchantIdentifier", string4);
                                                        if (string3 == null) {
                                                            YP_TCD_DCC_Business.setGlobalResult(this.dataContainerTransaction, YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                                            YP_TCD_DCC_Business.setExtendedResult(this.dataContainerTransaction, new ExtendedResult(70));
                                                            return -1;
                                                        }
                                                        this.dataContainerTransaction.setContractIdentifier(string3);
                                                        yP_PROT_Context.setMerchantIdentifier(string3);
                                                    }
                                                    catch (Exception exception) {
                                                        if (this.dataContainerTransaction.getLogLevel() < 2) break block54;
                                                        this.dataContainerTransaction.logger(2, "readRequest() getMerchantIdentifier() -> " + exception);
                                                    }
                                                }
                                            }
                                        }
                                        if (string3 == null || string3.isEmpty()) {
                                            if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                            this.dataContainerTransaction.logger(2, "readRequest() no merchant identifier");
                                            return -1;
                                        }
                                        object = yP_PROT_Context.getStoreIdentifier();
                                        if (object != null && !((String)object).isEmpty()) {
                                            if (((String)object).contains("_")) {
                                                object = ((String)object).substring(((String)object).lastIndexOf("_") + 1);
                                            }
                                            this.setStoreIdentifier((String)object);
                                        }
                                        if ((string2 = yP_PROT_Context.getApplicationIdentifier()) != null && string2.startsWith(CONTRACT_LABEL_TAG)) {
                                            this.v_ContractLabel = string2.substring(CONTRACT_LABEL_TAG.length());
                                            string2 = "";
                                        }
                                        if (string2 == null || string2.isEmpty()) break block55;
                                        stringArray2 = string2.split("_");
                                        if (stringArray2.length > 4) {
                                            if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                            this.dataContainerTransaction.logger(2, "readRequest() bad identifier received:" + string2);
                                            return -1;
                                        }
                                        if (!string3.contentEquals("KERNEL")) break block56;
                                        this.dataContainerTransaction.setContractIdentifier(string2);
                                        break block55;
                                    }
                                    if (!string2.startsWith(string3)) break block57;
                                    this.dataContainerTransaction.setContractIdentifier(string2);
                                    break block55;
                                }
                                if (stringArray2.length == 4) {
                                    if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                    this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                                    return -1;
                                }
                                stringArray = this.dataContainerTransaction.getContractIdentifier().split("_");
                                if (stringArray.length > 4) {
                                    if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                    this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                                    return -1;
                                }
                                if (stringArray.length != 4) break block58;
                                if (!string3.contains(string2)) {
                                    if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                    this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                                    return -1;
                                }
                                break block55;
                            }
                            if (stringArray.length != 3) break block59;
                            if (stringArray2.length == 3) {
                                if (stringArray2[0].contentEquals(stringArray[1]) && stringArray2[1].contentEquals(stringArray[2])) {
                                    this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[2]);
                                    break block55;
                                } else {
                                    if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                    this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                                    return -1;
                                }
                            }
                            if (stringArray2.length == 2) {
                                if (!stringArray2[0].contentEquals(stringArray[1]) || !stringArray2[1].contentEquals(stringArray[2])) {
                                    if (!stringArray2[0].contentEquals(stringArray[2])) {
                                        if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                                        this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                                        return -1;
                                    }
                                    this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[1]);
                                }
                                break block55;
                            } else if (stringArray2.length == 1 && !stringArray2[0].contentEquals(stringArray[2])) {
                                this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[0]);
                            }
                            break block55;
                        }
                        if (stringArray.length != 2) break block60;
                        if (stringArray2.length != 3) break block61;
                        if (!stringArray2[0].contentEquals(stringArray[1])) {
                            if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                            this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                            return -1;
                        }
                        this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[1] + '_' + stringArray2[2]);
                        break block55;
                    }
                    if (stringArray2.length != 2) break block62;
                    boolean bl = false;
                    try {
                        Integer.parseInt(stringArray2[1]);
                        bl = true;
                    }
                    catch (Exception exception) {}
                    if (bl) {
                        this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + string2);
                        break block55;
                    } else {
                        if (!stringArray2[0].contentEquals(stringArray[1])) {
                            if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                            this.dataContainerTransaction.logger(2, "readRequest() incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                            return -1;
                        }
                        this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[1]);
                    }
                    break block55;
                }
                if (stringArray2.length == 1) {
                    if (string3.startsWith(stringArray2[0])) {
                        this.dataContainerTransaction.setContractIdentifier(string3);
                        break block55;
                    } else {
                        this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + stringArray2[0]);
                    }
                }
                break block55;
            }
            if (stringArray.length == 1) {
                if (stringArray2.length == 3) {
                    this.dataContainerTransaction.setContractIdentifier(String.valueOf(string3) + '_' + string2);
                } else {
                    if (stringArray2.length == 2) {
                        if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                        this.dataContainerTransaction.logger(2, "readRequest() case not yet handle incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                        return -1;
                    }
                    if (stringArray2.length == 1) {
                        if (this.dataContainerTransaction.getLogLevel() < 2) return -1;
                        this.dataContainerTransaction.logger(2, "readRequest() case not yet handle incompatible identifiers:" + this.dataContainerTransaction.getContractIdentifier() + " " + string2);
                        return -1;
                    }
                }
            }
        }
        if ((stringArray2 = yP_PROT_Context.getServiceSequenceNumber()) != null && !stringArray2.isEmpty()) {
            this.setServiceSequenceNumber((String)stringArray2);
        }
        if ((stringArray = yP_PROT_Context.getNegativeApplicationIdentifierList()) != null && !stringArray.isEmpty()) {
            this.setNegativeApplicationIdentifierList((List<String>)stringArray);
        }
        if ((list3 = yP_PROT_Context.getPositiveApplicationIdentifierList()) != null && !list3.isEmpty()) {
            this.setPositiveApplicationIdentifierList(list3);
        }
        if ((list2 = yP_PROT_Context.getNegativeMerchantIdentifierList()) != null && !list2.isEmpty()) {
            this.setNegativeMerchantIdentifierList(list2);
        }
        if ((list = yP_PROT_Context.getPositiveMerchantIdentifierList()) != null && !list.isEmpty()) {
            this.setPositiveMerchantIdentifierList(list);
        }
        if ((string = yP_PROT_Context.getExtendedIdentifier()) == null) return 0;
        if (string.isEmpty()) return 0;
        YP_TCD_DCC_Business.setExtendedIdentifier(this.dataContainerTransaction, string);
        try {
            Object object2;
            List<Object> list4;
            List list5 = (List)this.dataContainerTransaction.getPluginByName("DataContainerManager").dealRequest(this.dataContainerTransaction, "getDataContainerList", this.dataContainerTransaction.getTransactionProcessFather(), this.dataContainerTransaction.getContractIdentifier(), "");
            if (list5 == null || list5.isEmpty()) {
                this.dataContainerTransaction.logger(2, "readRequest() there's should be at least one DCC ");
                return -1;
            }
            if (list5.size() != 1) {
                this.dataContainerTransaction.logger(2, "readRequest() there's should be only one DCC ");
                return -1;
            }
            YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list5.get(0);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
            yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.PENDING);
            if (string.trim().startsWith("ffffffff")) {
                string = string.substring(8);
            }
            yP_ComplexGabarit.set("extendedIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string.trim());
            List<YP_Row> list6 = yP_TCD_DCC_Business.transaction.getRowListSuchAs(yP_ComplexGabarit);
            if (list6 == null || list6.isEmpty()) {
                this.dataContainerTransaction.logger(5, "readRequest(): not found ...");
                return -1;
            }
            if (list6.size() > 1) {
                this.dataContainerTransaction.logger(2, "readRequest(): too many transactions found. For the moment, we take the first one, but this case probably need to be handled ...");
            }
            if ((list4 = yP_TCD_DCC_Business.transaction.getExtensionList()) != null && !list4.isEmpty()) {
                for (Object object2 : list4) {
                    this.dataContainerTransaction.addExtension(object2.getClass().newInstance());
                }
            }
            object2 = list6.get(0);
            yP_TCD_DCC_Business.loadTransaction(this.dataContainerTransaction, (YP_Row)object2);
            this.dataContainerTransaction.commonHandler.setTransactionPrimaryKey(0L);
            return 0;
        }
        catch (Exception exception) {
            this.dataContainerTransaction.logger(2, "readRequest() failed to get data container for merchant:" + this.dataContainerTransaction.getContractIdentifier() + " " + exception);
        }
        return 0;
    }

    @Override
    public int prepareResponse() {
        Object object;
        String[] stringArray;
        String string;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with account");
            }
            return 0;
        }
        YP_PROT_Context yP_PROT_Context = (YP_PROT_Context)((Object)yP_TCD_PosProtocol);
        YP_TCD_PosProtocol.RESULT_TYPE rESULT_TYPE = YP_TCD_DCC_Business.getGlobalResult(this.dataContainerTransaction);
        if (rESULT_TYPE == YP_TCD_PosProtocol.RESULT_TYPE.Unknown) {
            rESULT_TYPE = YP_TCD_PosProtocol.RESULT_TYPE.Error;
        }
        yP_PROT_Context.setStatus(rESULT_TYPE);
        yP_PROT_Context.setExtendedResult(YP_TCD_DCC_Business.getExtendedResult(this.dataContainerTransaction));
        int n = this.dataContainerTransaction.getRealNLPA();
        if (n > 0) {
            yP_PROT_Context.setPosNumber(n);
        }
        if ((string = this.getStoreIdentifier()) != null && !string.isEmpty()) {
            yP_PROT_Context.setStoreIdentifier(string);
        }
        if ((stringArray = this.dataContainerTransaction.getContractIdentifier().split("_")).length == 4) {
            object = String.valueOf(stringArray[2]) + "_" + stringArray[3];
            yP_PROT_Context.setApplicationIdentifier((String)object);
        }
        if ((object = this.dataContainerTransaction.getRequestType()) == null) {
            this.dataContainerTransaction.logger(2, "prepareResponse() unknown request type");
            return -1;
        }
        switch (object) {
            case Login: {
                yP_PROT_Context.setMerchantIdentifier(this.dataContainerTransaction.getContractIdentifier());
                break;
            }
        }
        String string2 = YP_TCD_DCC_Business.getExtendedIdentifier(this.dataContainerTransaction);
        if (string2 != null && !string2.isEmpty()) {
            yP_PROT_Context.setExtendedIdentifier(string2);
        }
        return 1;
    }

    @Override
    public int load(YP_Row yP_Row) {
        return 0;
    }

    @Override
    public int persist() {
        return 0;
    }

    public String getContractLabel() {
        return this.v_ContractLabel;
    }
}

