/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.time;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.YP_TCD_DCB_Interface_Time;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCB_STD_Time
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Time {
    private YP_TCD_DCC_Business dataContainer;

    public YP_TCD_DCB_STD_Time(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionSTD_Time";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return 0;
    }

    @Override
    public Calendar getAppliGMTTime() {
        return UtilsYP.getSystemGMTTime();
    }

    @Override
    public Calendar getAppliGMTTime(long l) {
        return UtilsYP.getSystemGMTTime(l);
    }

    @Override
    public Calendar getAppliLocalTime() {
        Calendar calendar = this.getAppliGMTTime();
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getGMTToAppliOffsetInMS());
        return calendar;
    }

    @Override
    public Calendar getAppliLocalTime(long l) {
        Calendar calendar = this.getAppliGMTTime(l);
        calendar.setTimeInMillis(calendar.getTimeInMillis() + this.getGMTToAppliOffsetInMS(l));
        return calendar;
    }

    @Override
    public long getGMTToAppliOffsetInMS(long l) {
        String string = this.dataContainer.getContractRow().getFieldStringValueByName("timeZone");
        if (string == null || string.isEmpty()) {
            return 0L;
        }
        return TimeZone.getTimeZone(string).getOffset(l);
    }

    private long getGMTToAppliOffsetInMS() {
        return this.getGMTToAppliOffsetInMS(UtilsYP.getSystemGMTTime().getTimeInMillis());
    }

    @Override
    public void resetSystemToGMTOffsetInMS() {
        if (this.getLogLevel() >= 3) {
            this.logger(3, "resetSystemToGMTOffsetInMS() Nothing to reset...");
        }
    }

    @Override
    public void setSystemToGMTOffsetInMS(long l) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "setSystemToGMTOffsetInMS() You should probably use a plugin which can handle offset!");
        }
    }

    @Override
    public long getSystemToGMTOffsetInMS() {
        if (this.getLogLevel() >= 3) {
            this.logger(3, "getSystemToGMTOffsetInMS() No offset...");
        }
        return 0L;
    }

    @Override
    public Calendar getSystemGMTTime(long l) {
        Calendar calendar = UtilsYP.getSystemGMTTime(l);
        calendar.setTimeInMillis(calendar.getTimeInMillis() - this.getGMTToAppliOffsetInMS(l));
        return calendar;
    }
}

