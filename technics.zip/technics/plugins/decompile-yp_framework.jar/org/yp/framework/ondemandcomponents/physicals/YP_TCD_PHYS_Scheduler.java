/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.net.Socket;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_Scheduler
extends YP_TCD_PHYS_Interface {
    private YP_Row scheduleRow = null;

    public YP_TCD_PHYS_Scheduler(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_Row) {
            this.scheduleRow = (YP_Row)objectArray[0];
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int close() {
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "CronConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int openServer() {
        return 1;
    }

    @Override
    public Object waitConnection() {
        try {
            YP_Row yP_Row = (YP_Row)this.getPluginByName("Scheduler").dealRequest(this, "getCronAction", new Object[0]);
            if (yP_Row != null) {
                this.logger(4, "waitConnection() Something todo... ");
                return yP_Row;
            }
            UtilsYP.sleep(this.getConnectionTimeout());
        }
        catch (Exception exception) {
            this.logger(2, "waitConnection() :" + exception);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "waitConnection() Timeout ");
        }
        return null;
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        block5: {
            if (this.scheduleRow != null) break block5;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "recv() nothing...");
            }
            return 0;
        }
        try {
            this.getPluginByName("Scheduler").dealRequest(this, "setCronCurrentThreadID", this.scheduleRow);
        }
        catch (Exception exception) {
            this.logger(2, "recv() :" + exception);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "recv() something:");
        }
        return UtilsYP.strcpy(byArray, this.scheduleRow.serialize());
    }

    @Override
    public int send(byte[] byArray, int n) {
        if (this.getLogLevel() >= 5) {
            this.logger(5, "send() nothing...");
        }
        return 0;
    }

    @Override
    public int closeHandle(Object object) {
        this.logger(2, "closeHandle() TODO !!!");
        return 0;
    }

    @Override
    public int available() {
        try {
            if (this.scheduleRow != null) {
                String string = this.scheduleRow.getFieldStringValueByName("requestXML");
                return string.length();
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "available() " + exception);
            return -1;
        }
    }

    @Override
    public String getIP() {
        return null;
    }

    @Override
    public int openClient(Object ... objectArray) {
        this.logger(2, "openClient() for scheduler !!!");
        return -1;
    }

    @Override
    public int clean(int n) {
        this.logger(3, "clean() meanningLess !!!");
        return 0;
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for scheduler !!!");
        return null;
    }

    @Override
    public int peek(byte[] byArray, int n, int n2, int n3) {
        return -1;
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }
}

