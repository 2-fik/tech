/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols;

import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public interface YP_PROT_Interface_Prot {
    public int transactionDatasToObjectFactory(YP_Object var1, SERVICEDEMANDE var2);

    public int objectFactoryToTransactionsData(YP_Object var1, SERVICEDEMANDE var2);

    public ConnectionParameters getConnectionParameters(SERVICEDEMANDE var1, int var2, boolean var3);

    public int shutdown();

    public byte[] extraAPDUFormat(YP_Object var1, Object var2, byte[] var3);

    public boolean extraAPDUCheck(YP_Object var1, Object var2, byte[] var3);

    public boolean setOneField(Object var1, SERVICEDEMANDE var2, int var3);

    public boolean dealOneField(Object var1, SERVICEDEMANDE var2, int var3);

    public int setParameters(YP_TCD_DCC_Business var1, YP_TCD_DC_Transaction var2);

    public static class ConnectionParameters {
        public String ip;
        public String port;
        public String ert;
        public String pseudoSessionId;
    }

    public static enum SERVICEDEMANDE {
        ServiceTlc,
        ServiceTlp,
        ServiceTlm,
        ServiceAuto,
        ServiceTransactionStatus,
        ServiceGuarantee,
        ServiceGetCurrencyRate,
        ServiceTlcFile;

    }
}

