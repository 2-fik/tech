/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.epas;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import javax.xml.datatype.XMLGregorianCalendar;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.xml.jaxb.epas.AdminRequestType;
import org.yp.xml.jaxb.epas.AdminResponseType;
import org.yp.xml.jaxb.epas.AmountsReqType;
import org.yp.xml.jaxb.epas.AmountsRespType;
import org.yp.xml.jaxb.epas.CardDataType;
import org.yp.xml.jaxb.epas.MessageHeaderType;
import org.yp.xml.jaxb.epas.OriginalTransactionType;
import org.yp.xml.jaxb.epas.OutputContentType;
import org.yp.xml.jaxb.epas.POIDataType;
import org.yp.xml.jaxb.epas.PaymentAcquirerDataType;
import org.yp.xml.jaxb.epas.PaymentDataType;
import org.yp.xml.jaxb.epas.PaymentInstrumentDataType;
import org.yp.xml.jaxb.epas.PaymentRequestType;
import org.yp.xml.jaxb.epas.PaymentResponseType;
import org.yp.xml.jaxb.epas.PaymentResultType;
import org.yp.xml.jaxb.epas.PaymentTransactionType;
import org.yp.xml.jaxb.epas.PrintOutputType;
import org.yp.xml.jaxb.epas.ReconciliationRequestType;
import org.yp.xml.jaxb.epas.ReconciliationResponseType;
import org.yp.xml.jaxb.epas.ResponseType;
import org.yp.xml.jaxb.epas.ReversalRequestType;
import org.yp.xml.jaxb.epas.ReversalResponseType;
import org.yp.xml.jaxb.epas.SaleDataType;
import org.yp.xml.jaxb.epas.SaleToPOIRequest;
import org.yp.xml.jaxb.epas.SaleToPOIResponse;
import org.yp.xml.jaxb.epas.SensitiveCardDataType;
import org.yp.xml.jaxb.epas.TrackDataType;
import org.yp.xml.jaxb.epas.TransactionIdentificationType;

public class YP_TCD_PROT_Epas
extends YP_TCD_PosProtocol {
    private SaleToPOIResponse saleToPOIResponse = null;
    private SaleToPOIRequest saleToPOIRequest = null;
    private String initialRequest;

    public YP_TCD_PROT_Epas(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setParserName("EPASParser");
    }

    @Override
    public String toString() {
        return "EPAS";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int loadInitialRequest(String string) {
        try {
            this.initialRequest = string;
            this.saleToPOIRequest = (SaleToPOIRequest)this.getParser().dealRequest(this, "xmlToObject", string);
            this.prepareDefaultResponse();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "load() :" + exception);
            return -1;
        }
    }

    @Override
    public String getInitialRequest() {
        return this.initialRequest;
    }

    @Override
    public String getResponse() {
        try {
            return (String)this.getParser().dealRequest(this, "objectToXML", this.saleToPOIResponse);
        }
        catch (Exception exception) {
            this.logger(2, "getResponse() :" + exception);
            return null;
        }
    }

    @Override
    public String getRequest(Object object) {
        try {
            return (String)this.getParser().dealRequest(this, "objectToXML", object);
        }
        catch (Exception exception) {
            this.logger(2, "getRequest() :" + exception);
            return null;
        }
    }

    private int prepareDefaultResponse() {
        block8: {
            block7: {
                block6: {
                    try {
                        this.saleToPOIResponse = new SaleToPOIResponse();
                        this.saleToPOIResponse.setMessageHeader(new MessageHeaderType());
                        this.saleToPOIResponse.getMessageHeader().setMessageClass(this.saleToPOIRequest.getMessageHeader().getMessageClass());
                        this.saleToPOIResponse.getMessageHeader().setMessageCategory(this.saleToPOIRequest.getMessageHeader().getMessageCategory());
                        this.saleToPOIResponse.getMessageHeader().setMessageType("Response");
                        this.saleToPOIResponse.getMessageHeader().setServiceID(this.saleToPOIRequest.getMessageHeader().getServiceID());
                        this.saleToPOIResponse.getMessageHeader().setWorkstationID(this.saleToPOIRequest.getMessageHeader().getWorkstationID());
                        this.saleToPOIResponse.getMessageHeader().setPOIID(this.saleToPOIRequest.getMessageHeader().getPOIID());
                        this.saleToPOIResponse.setPrintOutput(new PrintOutputType());
                        this.saleToPOIResponse.getPrintOutput().setOutputContent(new OutputContentType());
                        PaymentRequestType paymentRequestType = this.saleToPOIRequest.getPaymentRequest();
                        if (paymentRequestType == null) break block6;
                        this.saleToPOIResponse.setPaymentResponse(new PaymentResponseType());
                        this.saleToPOIResponse.getPaymentResponse().setResponse(new ResponseType());
                        this.saleToPOIResponse.getPaymentResponse().getResponse().setResult("Failure");
                        this.saleToPOIResponse.getPaymentResponse().setPOIData(new POIDataType());
                        this.saleToPOIResponse.getPaymentResponse().getPOIData().setPOITransactionID(new TransactionIdentificationType());
                        this.saleToPOIResponse.getPaymentResponse().getPOIData().getPOITransactionID().setTransactionID("000000");
                        this.saleToPOIResponse.getPaymentResponse().getPOIData().getPOITransactionID().setTimeStamp(this.saleToPOIRequest.getPaymentRequest().getSaleData().getSaleTransactionID().getTimeStamp());
                        this.saleToPOIResponse.getPaymentResponse().setPaymentResult(new PaymentResultType());
                        this.saleToPOIResponse.getPaymentResponse().getPaymentResult().setAmountsResp(new AmountsRespType());
                        this.saleToPOIResponse.getPaymentResponse().getPaymentResult().getAmountsResp().setAuthorizedAmount(paymentRequestType.getPaymentTransaction().getAmountsReq().getRequestedAmount());
                        return 1;
                    }
                    catch (Exception exception) {
                        this.logger(2, "prepareDefaultResponse() " + exception);
                        return -1;
                    }
                }
                ReversalRequestType reversalRequestType = this.saleToPOIRequest.getReversalRequest();
                if (reversalRequestType == null) break block7;
                this.saleToPOIResponse.setReversalResponse(new ReversalResponseType());
                this.saleToPOIResponse.getReversalResponse().setResponse(new ResponseType());
                this.saleToPOIResponse.getReversalResponse().getResponse().setResult("Failure");
                return 1;
            }
            ReconciliationRequestType reconciliationRequestType = this.saleToPOIRequest.getReconciliationRequest();
            if (reconciliationRequestType == null) break block8;
            this.saleToPOIResponse.setReconciliationResponse(new ReconciliationResponseType());
            this.saleToPOIResponse.getReconciliationResponse().setResponse(new ResponseType());
            this.saleToPOIResponse.getReconciliationResponse().getResponse().setResult("Failure");
            return 1;
        }
        AdminRequestType adminRequestType = this.saleToPOIRequest.getAdminRequest();
        if (adminRequestType != null) {
            this.saleToPOIResponse.setAdminResponse(new AdminResponseType());
            this.saleToPOIResponse.getAdminResponse().setResponse(new ResponseType());
            this.saleToPOIResponse.getAdminResponse().getResponse().setResult("Failure");
            return 1;
        }
        this.logger(2, "prepareDefaultResponse() unknown");
        return 0;
    }

    @Override
    public YP_TCD_PosProtocol.SUB_REQUEST_TYPE getSubRequestType() {
        this.logger(2, "getSubRequestType() TODO");
        return null;
    }

    @Override
    public YP_TCD_PosProtocol.REQUEST_TYPE getRequestType() {
        PaymentRequestType paymentRequestType = this.saleToPOIRequest.getPaymentRequest();
        if (paymentRequestType != null) {
            PaymentDataType paymentDataType = paymentRequestType.getPaymentData();
            if (paymentDataType == null) {
                this.logger(2, "getRequestType(): mandatory paymentDataType missing");
                return null;
            }
            String string = paymentDataType.getPaymentType();
            if (string == null || string.isEmpty()) {
                this.logger(2, "getRequestType(): mandatory paymentType missing");
                return null;
            }
            this.logger(2, "getRequestType(): paymentType unknown:" + string);
            return null;
        }
        ReconciliationRequestType reconciliationRequestType = this.saleToPOIRequest.getReconciliationRequest();
        if (reconciliationRequestType != null) {
            return YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation;
        }
        AdminRequestType adminRequestType = this.saleToPOIRequest.getAdminRequest();
        if (adminRequestType != null) {
            return YP_TCD_PosProtocol.REQUEST_TYPE.RemoteParameterization;
        }
        this.logger(2, "getRequestType(): unknown request");
        return null;
    }

    @Override
    public boolean getTestMode() {
        return false;
    }

    private EntryModeEnumeration getCorrespondingPaymentTechnology(String string) {
        if (string == null || string.isEmpty()) {
            return EntryModeEnumeration.ENTRY_MODE_MANUAL;
        }
        if (string.toUpperCase().contentEquals("MANUAL")) {
            return EntryModeEnumeration.ENTRY_MODE_MANUAL;
        }
        if (string.toUpperCase().contentEquals("RFID")) {
            return EntryModeEnumeration.ENTRY_MODE_RFID;
        }
        if (string.toUpperCase().contentEquals("KEYED")) {
            return EntryModeEnumeration.ENTRY_MODE_KEYED;
        }
        if (string.toUpperCase().contentEquals("FILE")) {
            return EntryModeEnumeration.ENTRY_MODE_FILE;
        }
        if (string.toUpperCase().contentEquals("SCANNED")) {
            return EntryModeEnumeration.ENTRY_MODE_SCANNED;
        }
        if (string.toUpperCase().contentEquals("MAGSTRIPE")) {
            return EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE;
        }
        if (string.toUpperCase().contentEquals("ICC")) {
            return EntryModeEnumeration.ENTRY_MODE_ICC;
        }
        if (string.toUpperCase().contentEquals("SYNCHRONOUSICC")) {
            return EntryModeEnumeration.ENTRY_MODE_SYNC_ICC;
        }
        if (string.toUpperCase().contentEquals("TAPPED")) {
            return EntryModeEnumeration.ENTRY_MODE_TAPPED;
        }
        if (string.toUpperCase().contentEquals("EMVCONTACTLESS")) {
            return EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS;
        }
        if (string.toUpperCase().contentEquals("MOBILE")) {
            return EntryModeEnumeration.ENTRY_MODE_MOBILE;
        }
        return EntryModeEnumeration.ENTRY_MODE_MANUAL;
    }

    @Override
    public int readRequest(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        Object object;
        Object object2;
        Object object3;
        Object object4;
        Object object5;
        yP_TCD_DC_Transaction.setRequestType(this.getRequestType());
        yP_TCD_DC_Transaction.setSubRequestType(this.getSubRequestType());
        yP_TCD_DC_Transaction.setContractIdentifier(this.saleToPOIRequest.getMessageHeader().getWorkstationID());
        PaymentRequestType paymentRequestType = this.saleToPOIRequest.getPaymentRequest();
        if (paymentRequestType != null) {
            object5 = paymentRequestType.getPaymentData();
            if (object5 != null && (object4 = ((PaymentDataType)object5).getPaymentInstrumentData()) != null && (object3 = ((PaymentInstrumentDataType)object4).getCardData()) != null) {
                try {
                    object2 = ((CardDataType)object3).getEntryMethod();
                    YP_TCD_DCC_Business.setPaymentTechnology(yP_TCD_DC_Transaction, this.getCorrespondingPaymentTechnology((String)object2.get(0)));
                }
                catch (Exception exception) {}
                object2 = ((CardDataType)object3).getSensitiveCardData();
                if (object2 != null) {
                    try {
                        yP_TCD_DC_Transaction.accountHandler.setAccountIdentifier(((SensitiveCardDataType)object2).getPAN());
                        yP_TCD_DC_Transaction.accountHandler.setMaskedAccountIdentifier(UtilsYP.maskPAN(yP_TCD_DC_Transaction.accountHandler.getAccountIdentifier()));
                        yP_TCD_DC_Transaction.accountHandler.setCardSequenceNumber(((SensitiveCardDataType)object2).getCardSeqNumb());
                        yP_TCD_DC_Transaction.accountHandler.setAccountExpirationDate(((SensitiveCardDataType)object2).getExpirationDate());
                        yP_TCD_DC_Transaction.accountHandler.setCardCVV(((SensitiveCardDataType)object2).getCVV());
                        object = ((SensitiveCardDataType)object2).getTrackData();
                        Iterator iterator = object.iterator();
                        while (iterator.hasNext()) {
                            TrackDataType trackDataType = (TrackDataType)iterator.next();
                            if (trackDataType.getTrackNumb() != 2) continue;
                            yP_TCD_DC_Transaction.accountHandler.setTrack2(trackDataType.getValue());
                            break;
                        }
                    }
                    catch (Exception exception) {}
                }
            }
            if ((object4 = paymentRequestType.getPaymentTransaction()) != null) {
                object3 = ((PaymentTransactionType)object4).getAmountsReq();
                if (object3 != null) {
                    try {
                        YP_TCD_DCC_Business.setTransactionAmount(yP_TCD_DC_Transaction, ((AmountsReqType)object3).getRequestedAmount().longValue());
                        YP_TCD_DCC_Business.setTransactionCurrencyAlpha(yP_TCD_DC_Transaction, ((AmountsReqType)object3).getCurrency());
                    }
                    catch (Exception exception) {}
                }
                try {
                    yP_TCD_DC_Transaction.setMerchantCategoryCode(((PaymentTransactionType)object4).getTransactionConditions().getMerchantCategoryCode());
                }
                catch (Exception exception) {}
            }
            if ((object3 = paymentRequestType.getSaleData()) != null) {
                object2 = ((SaleDataType)object3).getSaleTransactionID();
                if (object2 != null) {
                    try {
                        YP_TCD_DCC_Business.setMerchantTransactionIdentifier(yP_TCD_DC_Transaction, ((TransactionIdentificationType)object2).getTransactionID());
                        YP_TCD_DCC_Business.setMerchantTransactionTime(yP_TCD_DC_Transaction, new Timestamp(((TransactionIdentificationType)object2).getTimeStamp().toGregorianCalendar().getTimeInMillis()));
                    }
                    catch (Exception exception) {}
                }
                try {
                    YP_TCD_DCC_Business.setReferenceMerchantTransactionIdentifier(yP_TCD_DC_Transaction, ((SaleDataType)object3).getSaleReferenceID());
                    object = ((SaleDataType)object3).getShiftNumber();
                    if (object != null) {
                        YP_TCD_DCC_Business.setShiftNumber(yP_TCD_DC_Transaction, Integer.parseInt((String)object));
                    }
                }
                catch (Exception exception) {}
            }
        }
        if ((object5 = this.saleToPOIRequest.getReversalRequest()) != null) {
            try {
                object4 = ((ReversalRequestType)object5).getOriginalTransaction();
                if (object4 != null && (object3 = ((OriginalTransactionType)object4).getPOITransactionID()) != null) {
                    object2 = ((TransactionIdentificationType)object3).getTimeStamp();
                    if (object2 != null) {
                        YP_TCD_DCC_Business.setReferenceTransactionAppliLocalTime(yP_TCD_DC_Transaction, new Timestamp(((XMLGregorianCalendar)object2).toGregorianCalendar().getTimeInMillis()));
                    }
                    if ((object = ((TransactionIdentificationType)object3).getTransactionID()) != null) {
                        YP_TCD_DCC_Business.setReferenceTransactionNumber(yP_TCD_DC_Transaction, Integer.parseInt((String)object));
                    }
                }
            }
            catch (Exception exception) {}
        }
        return 0;
    }

    @Override
    public int prepareResponse(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        String string = yP_TCD_DC_Transaction.getTicket();
        if (string != null && !string.isEmpty()) {
            this.saleToPOIResponse.getPrintOutput().getOutputContent().setOutputXHTML(string.getBytes());
        }
        if (this.saleToPOIResponse.getReversalResponse() != null) {
            try {
                switch (YP_TCD_DCC_Business.getGlobalResult(yP_TCD_DC_Transaction)) {
                    case Success: {
                        this.saleToPOIResponse.getReversalResponse().getResponse().setResult("Success");
                        break;
                    }
                    case Refused: {
                        this.saleToPOIResponse.getReversalResponse().getResponse().setResult("Failure");
                        break;
                    }
                    default: {
                        this.saleToPOIResponse.getReversalResponse().getResponse().setResult("Failure");
                        break;
                    }
                }
            }
            catch (Exception exception) {}
        } else if (this.saleToPOIResponse.getPaymentResponse() != null) {
            try {
                switch (YP_TCD_DCC_Business.getGlobalResult(yP_TCD_DC_Transaction)) {
                    case Success: {
                        this.saleToPOIResponse.getPaymentResponse().getResponse().setResult("Success");
                        break;
                    }
                    case Refused: {
                        this.saleToPOIResponse.getPaymentResponse().getResponse().setResult("Failure");
                        break;
                    }
                    default: {
                        this.saleToPOIResponse.getPaymentResponse().getResponse().setResult("Failure");
                    }
                }
                this.saleToPOIResponse.getPaymentResponse().getPaymentResult().setPaymentAcquirerData(new PaymentAcquirerDataType());
                this.saleToPOIResponse.getPaymentResponse().getPaymentResult().getPaymentAcquirerData().setAcquirerID(yP_TCD_DC_Transaction.getAcquiringInstitutionIdentificationCode());
                this.saleToPOIResponse.getPaymentResponse().getPaymentResult().getPaymentAcquirerData().setApprovalCode(yP_TCD_DC_Transaction.getAuthorisationApprovalCode());
            }
            catch (Exception exception) {}
        }
        return 0;
    }

    @Override
    public String createScheduledRequest(YP_Object yP_Object, String string) {
        if (string.contentEquals("TLC")) {
            SaleToPOIRequest saleToPOIRequest = new SaleToPOIRequest();
            saleToPOIRequest.setMessageHeader(new MessageHeaderType());
            saleToPOIRequest.getMessageHeader().setPOIID("POIServer");
            saleToPOIRequest.getMessageHeader().setWorkstationID(yP_Object.getContractIdentifier());
            saleToPOIRequest.getMessageHeader().setServiceID("617");
            saleToPOIRequest.getMessageHeader().setMessageType("Request");
            saleToPOIRequest.getMessageHeader().setMessageCategory("Reconciliation");
            saleToPOIRequest.getMessageHeader().setMessageClass("Service");
            saleToPOIRequest.setReconciliationRequest(new ReconciliationRequestType());
            saleToPOIRequest.getReconciliationRequest().setReconciliationType("SaleReconciliation");
            return this.getRequest(saleToPOIRequest);
        }
        if (string.contentEquals("TLP")) {
            SaleToPOIRequest saleToPOIRequest = new SaleToPOIRequest();
            saleToPOIRequest.setMessageHeader(new MessageHeaderType());
            saleToPOIRequest.getMessageHeader().setPOIID("POITerm1");
            saleToPOIRequest.getMessageHeader().setWorkstationID(yP_Object.getContractIdentifier());
            saleToPOIRequest.getMessageHeader().setServiceID("613");
            saleToPOIRequest.getMessageHeader().setMessageType("Request");
            saleToPOIRequest.getMessageHeader().setMessageCategory("Admin");
            saleToPOIRequest.getMessageHeader().setMessageClass("Service");
            saleToPOIRequest.setAdminRequest(new AdminRequestType());
            saleToPOIRequest.getAdminRequest().setServiceIdentification("Init");
            return this.getRequest(saleToPOIRequest);
        }
        this.logger(2, "createRequest() TODO:" + string);
        return null;
    }

    @Override
    public int getDifferedFlag() {
        return 0;
    }

    @Override
    public int setDifferedFlag(int n) {
        return 0;
    }

    @Override
    public Calendar getUploadTimeStamp() {
        return null;
    }

    @Override
    public int setUploadTimeStamp(Calendar calendar) {
        return 0;
    }

    @Override
    public int getShiftNumber() {
        return 0;
    }

    @Override
    public int setShiftNumber(int n) {
        return 0;
    }

    @Override
    public int getSessionNumber() {
        return 0;
    }

    @Override
    public int setSessionNumber(int n) {
        return 0;
    }

    @Override
    public long getTransactionAmount() {
        return 0L;
    }

    @Override
    public int setTransactionAmount(long l) {
        return 0;
    }

    @Override
    public String getTransactionCurrencyAlpha() {
        return null;
    }

    @Override
    public int setTransactionCurrencyAlpha(String string) {
        return 0;
    }

    @Override
    public int getTransactionCurrencyNumerical() {
        return -1;
    }

    @Override
    public int setTransactionCurrencyNumerical(int n) {
        return 0;
    }

    @Override
    public int setTransactionAmountAlpha(String string) {
        return 0;
    }

    @Override
    public int getTransactionCurrencyFraction() {
        return 0;
    }

    @Override
    public int setTransactionCurrencyFraction(int n) {
        return 0;
    }

    @Override
    public String getTransactionAmountAlpha() {
        return null;
    }

    @Override
    public String getTransactionNumber() {
        return null;
    }

    @Override
    public int setTransactionNumber(String string) {
        return 0;
    }

    @Override
    public Calendar getTransactionAppliLocalTime() {
        return null;
    }

    @Override
    public int setTransactionAppliLocalTime(Calendar calendar) {
        return 0;
    }

    @Override
    public String getMerchantTransactionIdentifier() {
        return null;
    }

    @Override
    public int setMerchantTransactionIdentifier(String string) {
        return 0;
    }

    @Override
    public Calendar getMerchantTransactionTime() {
        return null;
    }

    @Override
    public int setMerchantTransactionTime(Calendar calendar) {
        return 0;
    }

    @Override
    public String getReferenceTransactionNumber() {
        return null;
    }

    @Override
    public int setReferenceTransactionNumber(String string) {
        return 0;
    }

    @Override
    public Calendar getReferenceTransactionAppliLocalTime() {
        return null;
    }

    @Override
    public int setReferenceTransactionAppliLocalTime(Calendar calendar) {
        return 0;
    }

    @Override
    public String getReferenceMerchantTransactionIdentifier() {
        return null;
    }

    @Override
    public int setReferenceMerchantTransactionIdentifier(String string) {
        return 0;
    }

    @Override
    public Calendar getReferenceMerchantTransactionTime() {
        return null;
    }

    @Override
    public int setReferenceMerchantTransactionTime(Calendar calendar) {
        return 0;
    }

    @Override
    public int setTicket(String string) {
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int setXMLResponse(String string) {
        return 0;
    }

    @Override
    public String getAppTags() {
        return null;
    }

    @Override
    public void setAppTags(String string) {
    }

    @Override
    public String getEMVTags() {
        return null;
    }

    @Override
    public void setEMVTags(String string) {
    }

    @Override
    public String getPrintFormat() {
        return null;
    }

    @Override
    public String getSecurityTrailer() {
        return null;
    }

    @Override
    public void setSecurityTrailer(String string) {
    }
}

