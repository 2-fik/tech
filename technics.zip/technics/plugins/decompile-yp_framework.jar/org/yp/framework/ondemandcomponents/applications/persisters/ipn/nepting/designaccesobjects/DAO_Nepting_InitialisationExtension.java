/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects;

public class DAO_Nepting_InitialisationExtension {
}

