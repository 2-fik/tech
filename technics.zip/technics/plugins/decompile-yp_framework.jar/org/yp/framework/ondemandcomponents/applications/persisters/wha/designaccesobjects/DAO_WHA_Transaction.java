/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.CardHolderAuthenticationEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.RealisationModeEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class DAO_WHA_Transaction
extends YP_Row {
    @PrimaryKey
    public long idWHA_Transaction = 0L;
    public byte[] merchantTransactionIdentifier = new byte[20];
    public TransactionTypeEnumeration type;
    public long amount = 0L;
    public byte[] currency = new byte[3];
    public Timestamp timestamp = new Timestamp(0L);
    public RealisationModeEnumeration status;
    public byte[] maskedPAN = new byte[19];
    public byte[] userName = new byte[32];
    public byte[] merchantContractIdentifier = new byte[10];
    public CardHolderAuthenticationEnumeration verificationMethod;
    public byte[] authorizationNumber = new byte[6];
    public byte[] authorizationRespCode = new byte[3];
    public byte[] nepSAServerResponse = new byte[32];
    public byte[] terminalSerialNumber = new byte[32];
    public byte[] scheme = new byte[32];
    public EntryModeEnumeration entryCondition;
    public byte[] applicationType = new byte[32];
    public byte[] customerTillReceipt = new byte[1024];
    public int responseCode = 0;
    public int currentTry = 0;
}

