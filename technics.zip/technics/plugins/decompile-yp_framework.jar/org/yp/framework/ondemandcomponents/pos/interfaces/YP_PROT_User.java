/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

public interface YP_PROT_User {
    public String getUserUID();

    public int setUserUID(String var1);

    public String getUserToken();

    public int setUserToken(String var1);

    public String getUserPasswd();

    public int setUserPasswd(String var1);

    public String getNewPasswd();

    public String getUserPreferredLanguage();

    public int setUserPreferredLanguage(String var1);

    public String getUserFirstName();

    public int setUserFirstName(String var1);

    public String getUserLastName();

    public int setUserLastName(String var1);

    public int setUserMessage(String var1);
}

