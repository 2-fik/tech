/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_WHA_MerchantAccess
extends YP_Row {
    @PrimaryKey
    public long idMerchantAccess = 0L;
    public long idMerchant = 0L;
}

