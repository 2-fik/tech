/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.UserStatusEnumeration;

@TableExtensionName(masterExtension="")
public class DAO_User
extends YP_Row {
    @PrimaryKey
    public long pkUser = 0L;
    @Index
    public long idUser = 0L;
    public Timestamp lastGMTTime = new Timestamp(0L);
    @Index
    public byte[] login = new byte[64];
    public byte[] mail = new byte[64];
    public byte[] firstName = new byte[20];
    public byte[] lastName = new byte[20];
    public UserStatusEnumeration userStatus;
    public int accessLevel = 0;
    public byte[] authPluginName = new byte[32];
    public long idLDAP = 0L;
    public int currentAttempt = 0;
    public byte[] preferredLanguage = new byte[2];
    @ForeignKey(name=DAO_User.class, column="idUser")
    public long idFather = 0L;
    public byte[] token = new byte[32];
    public Timestamp tokenExpirationSystemTime = new Timestamp(0L);
    public byte[] permanentToken = new byte[32];
    public Boolean vadAllowed;
    public Boolean merchantTicketAllowed;
    public Boolean cashierCreationAllowed;
}

