/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  oracle.sql.TIMESTAMP
 */
package org.yp.framework.ondemandcomponents.databaseconnectors;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import oracle.sql.TIMESTAMP;
import org.yp.designaccesobjects.YP_PreparedValue;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.status.DAO_ConnectionStatus;
import org.yp.designaccesobjects.technic.status.DAO_ContractStatus;
import org.yp.designaccesobjects.technic.status.DAO_CryptoModuleStatus;
import org.yp.designaccesobjects.technic.status.DAO_PluginStatus;
import org.yp.designaccesobjects.technic.status.DAO_ServiceStatus;
import org.yp.designaccesobjects.technic.status.DAO_TerminalStatus;
import org.yp.designaccesobjects.technic.status.DAO_UserStatus;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.token.designaccesobjects.DAO_TokenTable;
import org.yp.utils.Bitmap;
import org.yp.utils.UtilsYP;

public class YP_TCD_DBC_JDBC
extends YP_TCD_DataBaseConnector {
    private final int howManyTries = 20;
    private final int PATCH_TIMEOUT = 60000;
    private final int SQL_QUERY_TIMEOUT = 90;
    private final int SQL_SLOW_QUERY_DELAY = 2000;

    public YP_TCD_DBC_JDBC(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    private String forXML(String string) {
        if (string == null) {
            return null;
        }
        int n = string.length();
        int n2 = 0;
        while (n2 < n) {
            char c = string.charAt(n2);
            if (c == '<' || c == '>' || c == '\"' || c == '\'' || c == '&') {
                string = string.replace("&", "&amp;");
                string = string.replace("'", "&#039;");
                string = string.replace("\"", "&quot;");
                string = string.replace(">", "&gt;");
                string = string.replace("<", "&lt;");
                return string;
            }
            ++n2;
        }
        return string;
    }

    private boolean isDumping() {
        StackTraceElement[] stackTraceElementArray = new Throwable().getStackTrace();
        int n = 0;
        while (n < stackTraceElementArray.length) {
            if (stackTraceElementArray[n].getMethodName().startsWith("create2017DumpFor")) {
                return true;
            }
            ++n;
        }
        return false;
    }

    private boolean createTableMayBeNeeded(Exception exception) {
        String string = exception.getMessage();
        if (string.contains("doesn't exist") || string.contains("not found in schema") || string.contains("does not exist") || string.contains("Unknown database") || string.contains("Unknown column") || string.contains("different number of columns") || string.contains(": invalid identifier") || string.contains(" n'existe pas") || string.contains("Data too long") || string.contains(" non valide") || string.contains(" cannot be null") || string.contains("Incorrect integer value")) {
            return true;
        }
        return string.contains("Invalid object name ") || string.contains("Invalid column name ") || string.contains("would be truncated");
    }

    private int createTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == null) {
            return 0;
        }
        if ((yP_TCD_DesignAccesObject.getTableType() & 1) != 0) {
            return 0;
        }
        try {
            yP_TCD_DesignAccesObject.lock();
            StackTraceElement[] stackTraceElementArray = new Throwable().getStackTrace();
            boolean bl = false;
            int n = 0;
            while (n < stackTraceElementArray.length) {
                if (stackTraceElementArray[n].getMethodName().contentEquals("sqlCreateTable")) {
                    bl = true;
                    break;
                }
                ++n;
            }
            if (bl) {
                return 0;
            }
            if (yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlCreateTable(yP_TCD_DesignAccesObject, true) == 1) {
                return 1;
            }
            return 0;
        }
        finally {
            yP_TCD_DesignAccesObject.unlock();
        }
    }

    private int dealReloadForTablePrivate(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, Connection connection, String string) throws SQLException {
        ResultSet resultSet;
        Statement statement;
        block36: {
            statement = null;
            resultSet = null;
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) break block36;
            this.closeStatement(statement, resultSet);
            return 0;
        }
        try {
            Field[] fieldArray;
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n + 1];
            int n2 = 1;
            while (n2 <= n) {
                stringArray[n2] = resultSetMetaData.getColumnLabel(n2);
                ++n2;
            }
            YP_Row yP_Row = yP_TCD_DAO_LOC_Table.getNewRow();
            Field[] fieldArray2 = new Field[n + 1];
            int n3 = 1;
            while (n3 <= n) {
                try {
                    fieldArray2[n3] = yP_TCD_DAO_LOC_Table.getFieldByName(stringArray[n3], true);
                }
                catch (Exception exception) {
                    this.logger(2, "dealReloadForTablePrivate() " + exception);
                }
                ++n3;
            }
            Field[] fieldArray3 = fieldArray = yP_TCD_DAO_LOC_Table.getFieldList();
            int n4 = fieldArray.length;
            int n5 = 0;
            while (n5 < n4) {
                Field field = fieldArray3[n5];
                boolean bl = false;
                String string2 = field.getName();
                int n6 = 1;
                while (n6 <= n) {
                    if (stringArray[n6].contentEquals(string2)) {
                        bl = true;
                        break;
                    }
                    ++n6;
                }
                if (!bl) {
                    this.logger(3, "dealReloadForTablePrivate() changes detected ");
                    this.createTable(yP_TCD_DAO_LOC_Table);
                    break;
                }
                ++n5;
            }
            while (resultSet.next()) {
                int n7 = 1;
                while (n7 <= n) {
                    if (fieldArray2[n7] != null) {
                        try {
                            Object object = resultSet.getObject(n7);
                            if (object instanceof String) {
                                if (fieldArray2[n7].getType().isEnum()) {
                                    yP_Row.setFieldValue(fieldArray2[n7], (String)object);
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n7], ((String)object).getBytes());
                                }
                            } else if (object instanceof BigDecimal) {
                                if (((BigDecimal)object).scale() > 0) {
                                    yP_Row.setFieldValue(fieldArray2[n7], ((BigDecimal)object).floatValue());
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n7], ((BigDecimal)object).longValue());
                                }
                            } else if (object instanceof BigInteger) {
                                yP_Row.setFieldValue(fieldArray2[n7], ((BigInteger)object).longValue());
                            } else if (object instanceof TIMESTAMP) {
                                yP_Row.setFieldValue(fieldArray2[n7], ((TIMESTAMP)object).timestampValue());
                            } else if (object == null) {
                                if (fieldArray2[n7].getType() == Bitmap.class) {
                                    yP_Row.setFieldValue(fieldArray2[n7], (Bitmap)null);
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n7], "");
                                }
                            } else if (object instanceof Long) {
                                if (fieldArray2[n7].getType() == Bitmap.class) {
                                    yP_Row.setFieldValue(fieldArray2[n7], new Bitmap((Long)object));
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n7], (Long)object);
                                }
                            } else {
                                yP_Row.setFieldValue(fieldArray2[n7], object);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealReloadForTablePrivate() " + exception);
                        }
                    }
                    ++n7;
                }
                yP_TCD_DAO_LOC_Table.addRowDuringReload(yP_Row);
            }
            this.closeStatement(statement, resultSet);
            return 1;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    private boolean checkRequest(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        String string2;
        if (yP_TCD_DesignAccesObject == null) {
            return true;
        }
        String string3 = yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DesignAccesObject);
        if (string3 != null && !string3.isEmpty() && string.indexOf(string3) < 0 && string.indexOf("exec showCreateTable") < 0 && string.indexOf("CREATE TABLE ") < 0 && string.indexOf("CREATE SCHEMA ") < 0 && string.indexOf("ALTER TABLE ") < 0 && string.indexOf("CREATE INDEX ") < 0 && string.indexOf("DROP TRIGGER ") < 0 && string.indexOf("MERGE INTO ") < 0 && string.indexOf("FROM sys.triggers t") < 0 && string.indexOf("DROP INDEX ") < 0 && string.indexOf("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS") < 0 && string.indexOf(string2 = yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.getContractKeyClauseUsedForGlobalTransaction(yP_TCD_DesignAccesObject)) < 0) {
            this.logger(1, "checkRequest() bad request ( no contract key ) " + string);
            return false;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int dealReloadForTable(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, String string) {
        if (!this.checkRequest(yP_TCD_DAO_LOC_Table, string)) {
            return -1;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealReloadForTable() unable to get a connection");
                        break block21;
                    }
                    int n2 = this.dealReloadForTablePrivate(yP_TCD_DAO_LOC_Table, connection, string);
                    return n2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealReloadForTable() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (UtilsYP.getInstanceRole() != 1) return 0;
                        if (this.isDumping()) {
                            return 0;
                        }
                        if (this.createTable(yP_TCD_DAO_LOC_Table) != 1) {
                            return -1;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealReloadForTable() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealReloadForTable()");
        return -1;
    }

    private List<YP_Row> dealSelectPrivate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_PreparedValue> list, Connection connection, String string) throws SQLException {
        ArrayList<YP_Row> arrayList;
        ResultSet resultSet;
        Statement statement;
        block31: {
            statement = null;
            resultSet = null;
            arrayList = new ArrayList<YP_Row>();
            if (list.isEmpty()) {
                statement = connection.createStatement(1003, 1007, 2);
                statement.setQueryTimeout(90);
                long l = System.currentTimeMillis();
                resultSet = statement.executeQuery(string);
                this.logSlowQuery(l, string);
            } else {
                statement = connection.prepareStatement(string, 1003, 1007);
                int n = 1;
                for (YP_PreparedValue yP_PreparedValue : list) {
                    ((PreparedStatement)statement).setObject(n, yP_PreparedValue.value, yP_PreparedValue.type);
                    ++n;
                }
                statement.setQueryTimeout(90);
                long l = System.currentTimeMillis();
                resultSet = ((PreparedStatement)statement).executeQuery();
                this.logSlowQuery(l, string);
            }
            if (resultSet.isBeforeFirst()) break block31;
            ArrayList<YP_Row> arrayList2 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList2;
        }
        try {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n + 1];
            int n2 = 1;
            while (n2 <= n) {
                stringArray[n2] = resultSetMetaData.getColumnLabel(n2);
                ++n2;
            }
            Field[] fieldArray = new Field[n + 1];
            int n3 = 0;
            int n4 = 1;
            while (n4 <= n) {
                try {
                    Field field = yP_TCD_DesignAccesObject.getFieldByName(stringArray[n4], true);
                    if (field != null) {
                        fieldArray[n4] = field;
                        ++n3;
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "dealSelectPrivate() " + exception);
                }
                ++n4;
            }
            if ((yP_TCD_DesignAccesObject.getTableType() & 1) == 0 && n3 != yP_TCD_DesignAccesObject.getFieldList().length) {
                this.logger(3, "dealSelectPrivate() changes detected ");
                this.createTable(yP_TCD_DesignAccesObject);
            }
            while (resultSet.next()) {
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                int n5 = 1;
                while (n5 <= n) {
                    if (fieldArray[n5] != null) {
                        try {
                            Object object = resultSet.getObject(n5);
                            if (object instanceof String) {
                                if (fieldArray[n5].getType().isEnum()) {
                                    yP_Row.setFieldValue(fieldArray[n5], (String)object);
                                } else {
                                    yP_Row.setFieldValue(fieldArray[n5], ((String)object).getBytes());
                                }
                            } else if (object instanceof BigDecimal) {
                                if (((BigDecimal)object).scale() > 0) {
                                    yP_Row.setFieldValue(fieldArray[n5], ((BigDecimal)object).floatValue());
                                } else {
                                    yP_Row.setFieldValue(fieldArray[n5], ((BigDecimal)object).longValue());
                                }
                            } else if (object instanceof BigInteger) {
                                yP_Row.setFieldValue(fieldArray[n5], ((BigInteger)object).longValue());
                            } else if (object instanceof TIMESTAMP) {
                                yP_Row.setFieldValue(fieldArray[n5], ((TIMESTAMP)object).timestampValue());
                            } else if (object == null) {
                                yP_Row.setFieldValue(fieldArray[n5], "");
                            } else {
                                yP_Row.setFieldValue(fieldArray[n5], object);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealSelectPrivate() " + exception);
                        }
                    }
                    ++n5;
                }
                yP_Row.setModifierFlag(0);
                yP_Row.setIsItAClonedRow(false);
                arrayList.add(yP_Row);
            }
            ArrayList<YP_Row> arrayList3 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList3;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<YP_Row> dealSelect(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_PreparedValue> list, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealSelect() unable to get a connection");
                        break block21;
                    }
                    List<YP_Row> list2 = this.dealSelectPrivate(yP_TCD_DesignAccesObject, list, connection, string);
                    return list2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealSelect() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (UtilsYP.getInstanceRole() != 1) return null;
                        if (this.isDumping()) {
                            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
                            return arrayList;
                        }
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealSelect() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealSelect()");
        return null;
    }

    private List<YP_Row> dealSelectPrivate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Connection connection, String string) throws SQLException {
        ArrayList<YP_Row> arrayList;
        ResultSet resultSet;
        Statement statement;
        block30: {
            statement = null;
            resultSet = null;
            arrayList = new ArrayList<YP_Row>();
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) break block30;
            ArrayList<YP_Row> arrayList2 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList2;
        }
        try {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n + 1];
            int n2 = 1;
            while (n2 <= n) {
                stringArray[n2] = resultSetMetaData.getColumnLabel(n2);
                ++n2;
            }
            Field[] fieldArray = new Field[n + 1];
            int n3 = 0;
            int n4 = 1;
            while (n4 <= n) {
                try {
                    Field field = yP_TCD_DesignAccesObject.getFieldByName(stringArray[n4], true);
                    if (field != null) {
                        fieldArray[n4] = field;
                        ++n3;
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "dealSelectPrivate() " + exception);
                }
                ++n4;
            }
            if ((yP_TCD_DesignAccesObject.getTableType() & 1) == 0 && n3 != yP_TCD_DesignAccesObject.getFieldList().length) {
                this.logger(3, "dealSelectPrivate() changes detected ");
                this.createTable(yP_TCD_DesignAccesObject);
            }
            while (resultSet.next()) {
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                int n5 = 1;
                while (n5 <= n) {
                    if (fieldArray[n5] != null) {
                        try {
                            Object object = resultSet.getObject(n5);
                            if (object instanceof String) {
                                if (fieldArray[n5].getType().isEnum()) {
                                    yP_Row.setFieldValue(fieldArray[n5], (String)object);
                                } else {
                                    yP_Row.setFieldValue(fieldArray[n5], ((String)object).getBytes());
                                }
                            } else if (object instanceof BigDecimal) {
                                if (((BigDecimal)object).scale() > 0) {
                                    yP_Row.setFieldValue(fieldArray[n5], ((BigDecimal)object).floatValue());
                                } else {
                                    yP_Row.setFieldValue(fieldArray[n5], ((BigDecimal)object).longValue());
                                }
                            } else if (object instanceof BigInteger) {
                                yP_Row.setFieldValue(fieldArray[n5], ((BigInteger)object).longValue());
                            } else if (object instanceof TIMESTAMP) {
                                yP_Row.setFieldValue(fieldArray[n5], ((TIMESTAMP)object).timestampValue());
                            } else if (object == null) {
                                if (fieldArray[n5].getType().equals(Long.TYPE)) {
                                    yP_Row.setFieldValue(fieldArray[n5], 0);
                                } else {
                                    yP_Row.setFieldValue(fieldArray[n5], "");
                                }
                            } else {
                                yP_Row.setFieldValue(fieldArray[n5], object);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealSelectPrivate() " + exception);
                        }
                    }
                    ++n5;
                }
                yP_Row.setModifierFlag(0);
                yP_Row.setIsItAClonedRow(false);
                arrayList.add(yP_Row);
            }
            ArrayList<YP_Row> arrayList3 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList3;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    @Override
    public List<YP_Row> dealSelect(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        return this.dealSelect(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject, string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<YP_Row> dealSelect(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealSelect() unable to get a connection");
                        break block21;
                    }
                    List<YP_Row> list = this.dealSelectPrivate(yP_TCD_DesignAccesObject2, connection, string);
                    return list;
                }
                catch (Exception exception) {
                    this.logger(3, "dealSelect() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (UtilsYP.getInstanceRole() != 1) return null;
                        if (this.isDumping()) {
                            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
                            return arrayList;
                        }
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealSelect() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealSelect()");
        return null;
    }

    private List<YP_Row> dealSelectForTwoPrivate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2, Connection connection, String string) throws SQLException {
        ArrayList<YP_Row> arrayList;
        ResultSet resultSet;
        Statement statement;
        block34: {
            statement = null;
            resultSet = null;
            arrayList = new ArrayList<YP_Row>();
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) break block34;
            ArrayList<YP_Row> arrayList2 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList2;
        }
        try {
            Object object;
            int n = resultSet.findColumn("myTableIndex");
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n2 = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n2 + 1];
            int n3 = 1;
            while (n3 <= n2) {
                stringArray[n3] = resultSetMetaData.getColumnLabel(n3);
                ++n3;
            }
            Field[] fieldArray = new Field[n2 + 1];
            int n4 = 0;
            int n5 = 1;
            while (n5 <= n2) {
                if (n5 != n) {
                    try {
                        object = yP_TCD_DesignAccesObject.getFieldByName(stringArray[n5], true);
                        if (object != null) {
                            fieldArray[n5] = object;
                            ++n4;
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "dealSelectForTwoPrivate() " + exception);
                    }
                }
                ++n5;
            }
            if ((yP_TCD_DesignAccesObject.getTableType() & 1) == 0 && n4 != yP_TCD_DesignAccesObject.getFieldList().length) {
                this.logger(3, "dealSelectForTwoPrivate() changes detected ");
                this.createTable(yP_TCD_DesignAccesObject);
            }
            if ((yP_TCD_DesignAccesObject2.getTableType() & 1) == 0 && n4 != yP_TCD_DesignAccesObject2.getFieldList().length) {
                this.logger(3, "dealSelectForTwoPrivate() changes detected ");
                this.createTable(yP_TCD_DesignAccesObject2);
            }
            while (resultSet.next()) {
                n5 = resultSet.getInt(n);
                if (n5 == 1) {
                    object = yP_TCD_DesignAccesObject.getNewRow();
                } else if (n5 == 2) {
                    object = yP_TCD_DesignAccesObject2.getNewRow();
                } else {
                    this.logger(2, "dealSelectForTwoPrivate() row ignored because of bad tableIndex" + n5);
                    continue;
                }
                int n6 = 1;
                while (n6 <= n2) {
                    if (n6 != n && fieldArray[n6] != null) {
                        try {
                            Object object2 = resultSet.getObject(n6);
                            if (object2 instanceof String) {
                                if (fieldArray[n6].getType().isEnum()) {
                                    ((YP_Row)object).setFieldValue(fieldArray[n6], (String)object2);
                                } else {
                                    ((YP_Row)object).setFieldValue(fieldArray[n6], ((String)object2).getBytes());
                                }
                            } else if (object2 instanceof BigDecimal) {
                                if (((BigDecimal)object2).scale() > 0) {
                                    ((YP_Row)object).setFieldValue(fieldArray[n6], ((BigDecimal)object2).floatValue());
                                } else {
                                    ((YP_Row)object).setFieldValue(fieldArray[n6], ((BigDecimal)object2).longValue());
                                }
                            } else if (object2 instanceof BigInteger) {
                                ((YP_Row)object).setFieldValue(fieldArray[n6], ((BigInteger)object2).longValue());
                            } else if (object2 instanceof TIMESTAMP) {
                                ((YP_Row)object).setFieldValue(fieldArray[n6], ((TIMESTAMP)object2).timestampValue());
                            } else if (object2 == null) {
                                ((YP_Row)object).setFieldValue(fieldArray[n6], "");
                            } else {
                                ((YP_Row)object).setFieldValue(fieldArray[n6], object2);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealSelectForTwoPrivate() " + exception);
                        }
                    }
                    ++n6;
                }
                ((YP_Row)object).setModifierFlag(0);
                ((YP_Row)object).setIsItAClonedRow(false);
                arrayList.add((YP_Row)object);
            }
            ArrayList<YP_Row> arrayList3 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList3;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    @Override
    public List<YP_Row> dealSelectForTwo(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealSelectForTwo() unable to get a connection");
                        break block21;
                    }
                    List<YP_Row> list = this.dealSelectForTwoPrivate(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject2, connection, string);
                    return list;
                }
                catch (Exception exception) {
                    this.logger(3, "dealSelectForTwo() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                        if (this.createTable(yP_TCD_DesignAccesObject2) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealSelectForTwo() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealSelectForTwo()");
        return null;
    }

    private int dealReloadForMemoryPrivate(YP_TCD_DAO_LOC_Memory yP_TCD_DAO_LOC_Memory, Connection connection, String string) throws SQLException {
        ResultSet resultSet;
        Statement statement;
        block26: {
            statement = null;
            resultSet = null;
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) break block26;
            this.closeStatement(statement, resultSet);
            return 0;
        }
        try {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n + 1];
            int n2 = 1;
            while (n2 <= n) {
                stringArray[n2] = resultSetMetaData.getColumnLabel(n2);
                ++n2;
            }
            YP_Row yP_Row = yP_TCD_DAO_LOC_Memory.getNewRow();
            Field[] fieldArray = yP_TCD_DAO_LOC_Memory.getFieldList();
            Field[] fieldArray2 = new Field[n + 1];
            int n3 = 1;
            while (n3 <= n) {
                try {
                    fieldArray2[n3] = yP_TCD_DAO_LOC_Memory.getFieldByName(stringArray[n3], true);
                }
                catch (Exception exception) {
                    this.logger(2, "dealReloadForMemoryPrivate() " + exception);
                }
                ++n3;
            }
            while (resultSet.next()) {
                n3 = 1;
                while (n3 <= n) {
                    if (fieldArray2[n3] != null) {
                        try {
                            Object object = resultSet.getObject(n3);
                            if (object instanceof String) {
                                if (fieldArray2[n3].getType().isEnum()) {
                                    yP_Row.setFieldValue(fieldArray2[n3], (String)object);
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n3], ((String)object).getBytes());
                                }
                            } else if (object instanceof BigDecimal) {
                                if (((BigDecimal)object).scale() > 0) {
                                    yP_Row.setFieldValue(fieldArray2[n3], ((BigDecimal)object).floatValue());
                                } else {
                                    yP_Row.setFieldValue(fieldArray2[n3], ((BigDecimal)object).longValue());
                                }
                            } else if (object instanceof BigInteger) {
                                yP_Row.setFieldValue(fieldArray2[n3], ((BigInteger)object).longValue());
                            } else if (object instanceof TIMESTAMP) {
                                yP_Row.setFieldValue(fieldArray2[n3], ((TIMESTAMP)object).timestampValue());
                            } else if (object == null) {
                                yP_Row.setFieldValue(fieldArray2[n3], "");
                            } else {
                                yP_Row.setFieldValue(fieldArray2[n3], object);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealReloadForMemoryPrivate()  " + exception);
                        }
                    }
                    ++n3;
                }
                yP_TCD_DAO_LOC_Memory.getMemoryList().add(yP_Row.serialize(fieldArray));
            }
            this.closeStatement(statement, resultSet);
            return 1;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int dealReloadForMemory(YP_TCD_DAO_LOC_Memory yP_TCD_DAO_LOC_Memory, String string) {
        if (!this.checkRequest(yP_TCD_DAO_LOC_Memory, string)) {
            return -1;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealReloadForMemory() unable to get a connection");
                        break block21;
                    }
                    int n2 = this.dealReloadForMemoryPrivate(yP_TCD_DAO_LOC_Memory, connection, string);
                    return n2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealReloadForMemory() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (this.isDumping()) {
                            return 0;
                        }
                        if (UtilsYP.getInstanceRole() != 1) return 0;
                        if (this.createTable(yP_TCD_DAO_LOC_Memory) != 1) {
                            return -1;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealReloadForMemory() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealReloadForMemory()");
        return -1;
    }

    private StringBuilder dealQueryPrivate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Connection connection, String string, int n) throws SQLException {
        ResultSet resultSet;
        Statement statement;
        block35: {
            block42: {
                block39: {
                    block40: {
                        block41: {
                            block36: {
                                block37: {
                                    block38: {
                                        block34: {
                                            statement = null;
                                            resultSet = null;
                                            statement = connection.createStatement(1003, 1007, 2);
                                            statement.setQueryTimeout(90);
                                            long l = System.currentTimeMillis();
                                            resultSet = statement.executeQuery(string);
                                            this.logSlowQuery(l, string);
                                            if (resultSet.isBeforeFirst()) break block34;
                                            this.closeStatement(statement, resultSet);
                                            return null;
                                        }
                                        if (!string.startsWith("SHOW ")) break block35;
                                        if (!string.startsWith("SHOW COLUMNS")) break block36;
                                        if (!string.contains(" like ")) break block37;
                                        if (!resultSet.next()) break block38;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append(resultSet.getString("Type"));
                                        String string2 = resultSet.getString("Null");
                                        if (string2.contentEquals("NO")) {
                                            stringBuilder.append(" NOT NULL");
                                        }
                                        stringBuilder.append(" DEFAULT ");
                                        String string3 = resultSet.getString("Default");
                                        if (string3 == null) {
                                            stringBuilder.append("NULL");
                                        } else {
                                            stringBuilder.append('\'');
                                            stringBuilder.append(string3);
                                            stringBuilder.append('\'');
                                        }
                                        stringBuilder.append('#');
                                        stringBuilder.append(resultSet.getString("Key"));
                                        stringBuilder.append('\n');
                                        StringBuilder stringBuilder2 = stringBuilder;
                                        this.closeStatement(statement, resultSet);
                                        return stringBuilder2;
                                    }
                                    StringBuilder stringBuilder = new StringBuilder("");
                                    this.closeStatement(statement, resultSet);
                                    return stringBuilder;
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                while (resultSet.next()) {
                                    stringBuilder.append('#');
                                    stringBuilder.append(resultSet.getString("Field"));
                                    stringBuilder.append('#');
                                    stringBuilder.append(resultSet.getString("Type"));
                                    String string4 = resultSet.getString("Null");
                                    if (string4.contentEquals("NO")) {
                                        stringBuilder.append(" NOT NULL");
                                    }
                                    String string5 = resultSet.getString("Key");
                                    String string6 = resultSet.getString("Extra");
                                    if (string5.contentEquals("PRI") && string6.contentEquals("auto_increment")) {
                                        stringBuilder.append(" AUTO_INCREMENT");
                                    } else {
                                        stringBuilder.append(" DEFAULT ");
                                        String string7 = resultSet.getString("Default");
                                        if (string7 == null) {
                                            stringBuilder.append("NULL");
                                        } else {
                                            stringBuilder.append('\'');
                                            stringBuilder.append(string7);
                                            stringBuilder.append('\'');
                                        }
                                    }
                                    stringBuilder.append('\n');
                                }
                                StringBuilder stringBuilder3 = stringBuilder;
                                this.closeStatement(statement, resultSet);
                                return stringBuilder3;
                            }
                            if (!string.startsWith("SHOW INDEX FROM ")) break block39;
                            if (!string.contains(" WHERE ")) break block40;
                            if (!resultSet.next()) break block41;
                            StringBuilder stringBuilder = new StringBuilder(resultSet.getString("Key_Name"));
                            this.closeStatement(statement, resultSet);
                            return stringBuilder;
                        }
                        StringBuilder stringBuilder = new StringBuilder("");
                        this.closeStatement(statement, resultSet);
                        return stringBuilder;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    while (resultSet.next()) {
                        stringBuilder.append('#');
                        stringBuilder.append(resultSet.getString("Key_Name"));
                        stringBuilder.append('#');
                    }
                    StringBuilder stringBuilder4 = stringBuilder;
                    this.closeStatement(statement, resultSet);
                    return stringBuilder4;
                }
                if (!string.startsWith("SHOW CREATE")) break block35;
                if (!resultSet.next()) break block42;
                StringBuilder stringBuilder = new StringBuilder(resultSet.getString("Create Table"));
                this.closeStatement(statement, resultSet);
                return stringBuilder;
            }
            StringBuilder stringBuilder = new StringBuilder("");
            this.closeStatement(statement, resultSet);
            return stringBuilder;
        }
        try {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int n2 = resultSetMetaData.getColumnCount();
            String[] stringArray = new String[n2 + 1];
            int n3 = 1;
            while (n3 <= n2) {
                stringArray[n3] = resultSetMetaData.getColumnLabel(n3);
                ++n3;
            }
            n3 = 1;
            while (n3 <= n2) {
                stringArray[n3] = resultSetMetaData.getColumnLabel(n3);
                ++n3;
            }
            if (yP_TCD_DesignAccesObject != null) {
                n3 = 1;
                while (n3 <= n2) {
                    try {
                        Field field = yP_TCD_DesignAccesObject.getFieldByName(stringArray[n3], true);
                        if (field != null) {
                            stringArray[n3] = field.getName();
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "dealQueryPrivate() " + exception);
                    }
                    ++n3;
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n<table>");
            while (resultSet.next()) {
                stringBuilder.append("\n<row");
                int n4 = 1;
                while (n4 <= n2) {
                    stringBuilder.append(' ');
                    stringBuilder.append(stringArray[n4]);
                    stringBuilder.append("=\"");
                    if (n == 1) {
                        stringBuilder.append(this.forXML(resultSet.getString(n4)));
                    } else {
                        stringBuilder.append(resultSet.getString(n4));
                    }
                    stringBuilder.append("\"");
                    ++n4;
                }
                stringBuilder.append("/>");
            }
            stringBuilder.append("\n</table>");
            int n5 = stringBuilder.length();
            if (n5 > 500) {
                n5 = 500;
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, stringBuilder.toString().substring(0, n5));
            }
            StringBuilder stringBuilder5 = stringBuilder;
            this.closeStatement(statement, resultSet);
            return stringBuilder5;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    @Override
    public StringBuilder dealQuery(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n2 = 0;
        while (n2 < 20) {
            block19: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealQuery() unable to get a connection");
                        break block19;
                    }
                    StringBuilder stringBuilder = this.dealQueryPrivate(yP_TCD_DesignAccesObject, connection, string, n);
                    return stringBuilder;
                }
                catch (Exception exception) {
                    this.logger(3, "dealQuery() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealQuery() give up after timeout !!!" + exception);
                                n2 = 20;
                            } else {
                                --n2;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n2;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealQuery()");
        return null;
    }

    /*
     * Loose catch block
     */
    @Override
    public int dealCustomQuery(String string) {
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection;
                block19: {
                    ResultSet resultSet;
                    Statement statement;
                    block20: {
                        connection = null;
                        connection = this.getConnection();
                        if (connection == null) {
                            this.logger(2, "dealCustomQuery() unable to get a connection");
                            break block19;
                        }
                        statement = null;
                        resultSet = null;
                        statement = connection.createStatement(1003, 1007, 2);
                        statement.setQueryTimeout(90);
                        statement.execute(string);
                        this.logSlowQuery(l, string);
                        this.closeStatement(statement, resultSet);
                        if (connection == null) break block20;
                        this.releaseConnection(connection);
                    }
                    return 1;
                    {
                        catch (Throwable throwable) {
                            try {
                                this.closeStatement(statement, resultSet);
                                throw throwable;
                            }
                            catch (Exception exception) {
                                this.logger(3, "dealCustomQuery() " + exception);
                                if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                                    if (connection != null) {
                                        this.releaseConnection(connection);
                                    }
                                    return -1;
                                }
                                try {
                                    this.closeConnection(connection);
                                    connection = null;
                                    if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                                        UtilsYP.sleep(10);
                                        if (UtilsYP.isTimeout(l, 60000)) {
                                            this.logger(1, "dealCustomQuery() give up after timeout !!!" + exception);
                                            n = 20;
                                        } else {
                                            --n;
                                        }
                                    } else {
                                        UtilsYP.sleep(1000);
                                    }
                                    break block21;
                                }
                                catch (Throwable throwable2) {
                                    throw throwable2;
                                }
                                finally {
                                    if (connection != null) {
                                        this.releaseConnection(connection);
                                    }
                                }
                            }
                        }
                    }
                }
                if (connection != null) {
                    this.releaseConnection(connection);
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealQuery()");
        return -1;
    }

    private List<String> dealStringListQueryPrivate(Connection connection, String string) throws SQLException {
        Statement statement = null;
        ResultSet resultSet = null;
        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    arrayList.add(resultSet.getString(1));
                }
            }
            ArrayList<String> arrayList2 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList2;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<String> dealStringListQuery(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block21: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealStringListQuery() unable to get a connection");
                        break block21;
                    }
                    List<String> list = this.dealStringListQueryPrivate(connection, string);
                    return list;
                }
                catch (Exception exception) {
                    this.logger(3, "dealStringListQuery() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (UtilsYP.getInstanceRole() != 1) return null;
                        if (this.isDumping()) {
                            ArrayList<String> arrayList = new ArrayList<String>();
                            return arrayList;
                        }
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealStringListQuery() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealStringListQuery()");
        return null;
    }

    private List<Object> dealListQueryPrivate(Connection connection, Field field, String string) throws SQLException {
        Statement statement = null;
        ResultSet resultSet = null;
        ArrayList<Object> arrayList = new ArrayList<Object>();
        try {
            statement = connection.createStatement(1003, 1007, 2);
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            resultSet = statement.executeQuery(string);
            this.logSlowQuery(l, string);
            if (resultSet.isBeforeFirst()) {
                while (resultSet.next()) {
                    Object object = resultSet.getObject(1);
                    if (object instanceof String) {
                        if (field.getType().isEnum()) {
                            arrayList.add(object);
                            continue;
                        }
                        arrayList.add(((String)object).getBytes());
                        continue;
                    }
                    if (object instanceof BigDecimal) {
                        if (((BigDecimal)object).scale() > 0) {
                            arrayList.add(Float.valueOf(((BigDecimal)object).floatValue()));
                            continue;
                        }
                        arrayList.add(((BigDecimal)object).longValue());
                        continue;
                    }
                    if (object instanceof BigInteger) {
                        arrayList.add(((BigInteger)object).longValue());
                        continue;
                    }
                    if (object instanceof TIMESTAMP) {
                        arrayList.add(((TIMESTAMP)object).timestampValue());
                        continue;
                    }
                    if (object == null) {
                        arrayList.add("");
                        continue;
                    }
                    arrayList.add(object);
                }
            }
            ArrayList<Object> arrayList2 = arrayList;
            this.closeStatement(statement, resultSet);
            return arrayList2;
        }
        catch (Throwable throwable) {
            this.closeStatement(statement, resultSet);
            throw throwable;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<Object> dealListQuery(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, String string2) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string2)) {
            return null;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block19: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealListQuery() unable to get a connection");
                        break block19;
                    }
                    List<Object> list = this.dealListQueryPrivate(connection, yP_TCD_DesignAccesObject.getFieldByName(string), string2);
                    return list;
                }
                catch (Exception exception) {
                    this.logger(3, "dealListQuery() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return null;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (UtilsYP.getInstanceRole() != 1) return null;
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return null;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealListQuery() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string2 + " dealListQuery()");
        return null;
    }

    private long dealCountQueryPrivate(Connection connection, String string) throws SQLException {
        ResultSet resultSet;
        Statement statement;
        block4: {
            statement = null;
            resultSet = null;
            try {
                statement = connection.createStatement(1003, 1007, 2);
                statement.setQueryTimeout(90);
                long l = System.currentTimeMillis();
                resultSet = statement.executeQuery(string);
                this.logSlowQuery(l, string);
                if (resultSet.isBeforeFirst()) break block4;
                this.closeStatement(statement, resultSet);
                return -1L;
            }
            catch (Throwable throwable) {
                this.closeStatement(statement, resultSet);
                throw throwable;
            }
        }
        resultSet.next();
        long l = string.indexOf("EXPLAIN") != -1 ? (long)resultSet.getInt("rows") : resultSet.getLong("count");
        if (resultSet.next()) {
            this.logger(1, "dealCountQueryPrivate() there is more than one res for " + string);
        }
        long l2 = l;
        this.closeStatement(statement, resultSet);
        return l2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public long dealCountQuery(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) throws Exception {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return -1L;
        }
        Exception exception = null;
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block18: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealCountQuery() unable to get a connection");
                        break block18;
                    }
                    long l2 = this.dealCountQueryPrivate(connection, string);
                    return l2;
                }
                catch (Exception exception2) {
                    exception = exception2;
                    this.logger(3, "dealCountQuery() " + exception2);
                    if (exception2.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        throw exception2;
                    }
                    if (this.createTableMayBeNeeded(exception2)) {
                        if (UtilsYP.getInstanceRole() != 1) return 0L;
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            throw exception2;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception2.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealCountQuery() give up after timeout !!!" + exception2);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealCountQuery()");
        if (exception == null) return -1L;
        throw exception;
    }

    private int dealUpdatePrivate(Connection connection, String string) throws SQLException {
        Statement statement = null;
        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            int n = statement.executeUpdate(string);
            this.logSlowQuery(l, string);
            int n2 = n;
            return n2;
        }
        finally {
            this.closeStatement(statement, null);
        }
    }

    @Override
    public int dealUpdate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        if (!this.checkRequest(yP_TCD_DesignAccesObject, string)) {
            return -1;
        }
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block19: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealUpdate() unable to get a connection");
                        break block19;
                    }
                    int n2 = this.dealUpdatePrivate(connection, string);
                    this.sqlLogs(yP_TCD_DesignAccesObject, string);
                    int n3 = n2;
                    return n3;
                }
                catch (Exception exception) {
                    this.logger(3, "dealUpdate() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return -1;
                        }
                    } else {
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealUpdate() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealUpdate()");
        return -1;
    }

    private int dealCreatePrivate(Connection connection, String string) throws SQLException {
        Statement statement = null;
        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(90);
            long l = System.currentTimeMillis();
            int n = statement.executeUpdate(string);
            this.logSlowQuery(l, string);
            int n2 = n;
            return n2;
        }
        finally {
            this.closeStatement(statement, null);
        }
    }

    @Override
    public int dealCreate(String string, YP_TCD_DesignAccesObject ... yP_TCD_DesignAccesObjectArray) {
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block24: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealCreate() unable to get a connection");
                        break block24;
                    }
                    int n2 = this.dealCreatePrivate(connection, string);
                    this.sqlLogs(string, yP_TCD_DesignAccesObjectArray);
                    int n3 = n2;
                    return n3;
                }
                catch (Exception exception) {
                    this.logger(3, "dealCreate() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (yP_TCD_DesignAccesObjectArray == null || yP_TCD_DesignAccesObjectArray.length == 0 || this.createTable(yP_TCD_DesignAccesObjectArray[0]) != 1) {
                            return -1;
                        }
                        if (yP_TCD_DesignAccesObjectArray.length == 2 && this.createTable(yP_TCD_DesignAccesObjectArray[1]) != 1) {
                            return -1;
                        }
                    } else {
                        if (exception.getMessage().contains("Duplicate entry")) {
                            this.logger(2, "dealCreate() TODO verif if the row we want to insert is the same than the one in the DB ???");
                            return -1;
                        }
                        if (exception.getMessage().contains("Cannot insert duplicate key")) {
                            this.logger(2, "dealCreate() TODO verif if the row we want to insert is the same than the one in the DB ???");
                            return -1;
                        }
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealCreate() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealCreate()");
        return -1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    private int releaseConnection(Connection connection) {
        block3: {
            try {
                if (connection != null) break block3;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "releaseConnection() " + exception);
                return -1;
            }
        }
        return (Integer)this.getPluginByName("JDBC_ConnectionManager").dealRequest(this, "releaseConnection", connection);
    }

    private int closeConnection(Connection connection) {
        block3: {
            try {
                if (connection != null) break block3;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "closeConnection() " + exception);
                return -1;
            }
        }
        return (Integer)this.getPluginByName("JDBC_ConnectionManager").dealRequest(this, "closeConnection", connection);
    }

    private Connection getConnection() throws Exception {
        return (Connection)this.getPluginByName("JDBC_ConnectionManager").dealRequest(this, "getConnection", new Object[0]);
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataBaseConnectorJDBC";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.14";
    }

    private void closeStatement(Statement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
        }
        catch (Exception exception) {}
        try {
            if (statement != null) {
                statement.close();
            }
        }
        catch (Exception exception) {}
    }

    private int dealBatchInsertPrivate(Connection connection, String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) throws SQLException {
        int n;
        PreparedStatement preparedStatement = null;
        boolean bl = connection.getAutoCommit();
        try {
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(string);
            preparedStatement.setQueryTimeout(90);
            int n2 = 0;
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                long l = yP_Row.getPrimaryKey();
                if (l == 0L) {
                    yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                }
                int n3 = 1;
                while (n3 <= fieldArray.length) {
                    Field field = fieldArray[n3 - 1];
                    Object object = yP_Row.getFieldValue(field);
                    if (object instanceof byte[]) {
                        String string2 = YP_Row.getStringValue((byte[])object);
                        preparedStatement.setObject(n3, (Object)string2, 12);
                    } else if (object instanceof Integer) {
                        int n4 = (Integer)object;
                        preparedStatement.setObject(n3, (Object)n4, 4);
                    } else if (object instanceof Long) {
                        long l2 = (Long)object;
                        preparedStatement.setObject(n3, (Object)l2, -5);
                    } else if (object instanceof Float) {
                        float f = ((Float)object).floatValue();
                        preparedStatement.setObject(n3, (Object)Float.valueOf(f), 6);
                    } else if (object instanceof Timestamp) {
                        preparedStatement.setObject(n3, object, 93);
                    } else if (object instanceof Date) {
                        preparedStatement.setObject(n3, object, 91);
                    } else if (object instanceof Boolean) {
                        int n5 = (Boolean)object != false ? 1 : 0;
                        preparedStatement.setObject(n3, (Object)n5, -6);
                    } else if (object instanceof Enum) {
                        String string3 = object.toString();
                        preparedStatement.setObject(n3, (Object)string3, 12);
                    } else if (object instanceof Bitmap) {
                        long l3 = ((Bitmap)object).getBitmap();
                        preparedStatement.setObject(n3, (Object)l3, -5);
                    } else if (object == null) {
                        preparedStatement.setObject(n3, null);
                    } else {
                        this.logger(2, "dealBatchInsertPrivate() unknown type for " + field.getName());
                        preparedStatement.setString(n3, yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue(object));
                    }
                    ++n3;
                }
                preparedStatement.addBatch();
                if (++n2 % 20000 != 0) continue;
                long l4 = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l4, string);
                preparedStatement.clearBatch();
            }
            if (n2 % 20000 != 0) {
                long l = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l, string);
            }
            n = n2;
            this.closeStatement(preparedStatement, null);
        }
        catch (Throwable throwable) {
            this.closeStatement(preparedStatement, null);
            connection.setAutoCommit(bl);
            throw throwable;
        }
        connection.setAutoCommit(bl);
        return n;
    }

    @Override
    public int dealBatchInsert(String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block20: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealBatchInsert() unable to get a connection");
                        break block20;
                    }
                    int n2 = this.dealBatchInsertPrivate(connection, string, yP_TCD_DesignAccesObject);
                    return n2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealBatchInsert() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (yP_TCD_DesignAccesObject == null || this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return -1;
                        }
                    } else {
                        if (exception.getMessage().contains("Duplicate entry")) {
                            this.logger(2, "dealBatchInsert() TODO verif if the row we want to insert is the same than the one in the DB ???");
                            return -1;
                        }
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealBatchInsert() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealBatchInsert()");
        return -1;
    }

    private int dealBatchUpdatePrivate(Connection connection, String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray) throws SQLException {
        int n;
        PreparedStatement preparedStatement = null;
        boolean bl = connection.getAutoCommit();
        try {
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(string);
            preparedStatement.setQueryTimeout(90);
            int n2 = 0;
            for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                long l = yP_Row.getPrimaryKey();
                if (l == 0L) {
                    yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                }
                int n3 = 1;
                while (n3 <= fieldArray.length) {
                    Field field = fieldArray[n3 - 1];
                    Object object = yP_Row.getFieldValue(field);
                    if (object instanceof byte[]) {
                        String string2 = YP_Row.getStringValue((byte[])object);
                        preparedStatement.setObject(n3, (Object)string2, 12);
                    } else if (object instanceof Integer) {
                        int n4 = (Integer)object;
                        preparedStatement.setObject(n3, (Object)n4, 4);
                    } else if (object instanceof Long) {
                        long l2 = (Long)object;
                        preparedStatement.setObject(n3, (Object)l2, -5);
                    } else if (object instanceof Float) {
                        float f = ((Float)object).floatValue();
                        preparedStatement.setObject(n3, (Object)Float.valueOf(f), 6);
                    } else if (object instanceof Timestamp) {
                        preparedStatement.setObject(n3, object, 93);
                    } else if (object instanceof Date) {
                        preparedStatement.setObject(n3, object, 91);
                    } else if (object instanceof Boolean) {
                        int n5 = (Boolean)object != false ? 1 : 0;
                        preparedStatement.setObject(n3, (Object)n5, -6);
                    } else if (object instanceof Enum) {
                        String string3 = object.toString();
                        preparedStatement.setObject(n3, (Object)string3, 12);
                    } else if (object instanceof Bitmap) {
                        long l3 = ((Bitmap)object).getBitmap();
                        preparedStatement.setObject(n3, (Object)l3, -5);
                    } else if (object == null) {
                        preparedStatement.setObject(n3, null);
                    } else {
                        this.logger(2, "dealBatchUpdatePrivate() unknown type for " + field.getName());
                        preparedStatement.setString(n3, yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue(object));
                    }
                    ++n3;
                }
                preparedStatement.addBatch();
                if (++n2 % 20000 != 0) continue;
                long l4 = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l4, string);
                preparedStatement.clearBatch();
            }
            if (n2 % 20000 != 0) {
                long l = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l, string);
            }
            n = n2;
            this.closeStatement(preparedStatement, null);
        }
        catch (Throwable throwable) {
            this.closeStatement(preparedStatement, null);
            connection.setAutoCommit(bl);
            throw throwable;
        }
        connection.setAutoCommit(bl);
        return n;
    }

    @Override
    public int dealBatchUpdate(String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray, Field[] fieldArray2) {
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block20: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealBatchUpdate() unable to get a connection");
                        break block20;
                    }
                    Field[] fieldArray3 = Arrays.copyOf(fieldArray, fieldArray.length + fieldArray2.length);
                    System.arraycopy(fieldArray2, 0, fieldArray3, fieldArray.length, fieldArray2.length);
                    int n2 = this.dealBatchUpdatePrivate(connection, string, yP_TCD_DesignAccesObject, fieldArray3);
                    return n2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealBatchInsert() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (yP_TCD_DesignAccesObject == null || this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return -1;
                        }
                    } else {
                        if (exception.getMessage().contains("Duplicate entry")) {
                            this.logger(2, "dealBatchUpdate() TODO verif if the row we want to insert is the same than the one in the DB ???");
                            return -1;
                        }
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealBatchUpdate() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealBatchInsert()");
        return -1;
    }

    private int dealBatchDeletePrivate(Connection connection, String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray) throws SQLException {
        int n;
        PreparedStatement preparedStatement = null;
        boolean bl = connection.getAutoCommit();
        try {
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(string);
            preparedStatement.setQueryTimeout(90);
            int n2 = 0;
            for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                long l = yP_Row.getPrimaryKey();
                if (l == 0L) {
                    yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                }
                int n3 = 1;
                while (n3 <= fieldArray.length) {
                    Field field = fieldArray[n3 - 1];
                    Object object = yP_Row.getFieldValue(field);
                    if (object instanceof byte[]) {
                        String string2 = YP_Row.getStringValue((byte[])object);
                        preparedStatement.setObject(n3, (Object)string2, 12);
                    } else if (object instanceof Integer) {
                        int n4 = (Integer)object;
                        preparedStatement.setObject(n3, (Object)n4, 4);
                    } else if (object instanceof Long) {
                        long l2 = (Long)object;
                        preparedStatement.setObject(n3, (Object)l2, -5);
                    } else if (object instanceof Float) {
                        float f = ((Float)object).floatValue();
                        preparedStatement.setObject(n3, (Object)Float.valueOf(f), 6);
                    } else if (object instanceof Timestamp) {
                        preparedStatement.setObject(n3, object, 93);
                    } else if (object instanceof Date) {
                        preparedStatement.setObject(n3, object, 91);
                    } else if (object instanceof Boolean) {
                        int n5 = (Boolean)object != false ? 1 : 0;
                        preparedStatement.setObject(n3, (Object)n5, -6);
                    } else if (object instanceof Enum) {
                        String string3 = object.toString();
                        preparedStatement.setObject(n3, (Object)string3, 12);
                    } else if (object instanceof Bitmap) {
                        long l3 = ((Bitmap)object).getBitmap();
                        preparedStatement.setObject(n3, (Object)l3, -5);
                    } else if (object == null) {
                        preparedStatement.setObject(n3, null);
                    } else {
                        this.logger(2, "dealBatchDeletePrivate() unknown type for " + field.getName());
                        preparedStatement.setString(n3, yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue(object));
                    }
                    ++n3;
                }
                preparedStatement.addBatch();
                if (++n2 % 20000 != 0) continue;
                long l4 = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l4, string);
                preparedStatement.clearBatch();
            }
            if (n2 % 20000 != 0) {
                long l = System.currentTimeMillis();
                preparedStatement.executeBatch();
                this.logSlowQuery(l, string);
            }
            n = n2;
            this.closeStatement(preparedStatement, null);
        }
        catch (Throwable throwable) {
            this.closeStatement(preparedStatement, null);
            connection.setAutoCommit(bl);
            throw throwable;
        }
        connection.setAutoCommit(bl);
        return n;
    }

    @Override
    public int dealBatchDelete(String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray) {
        long l = System.currentTimeMillis();
        int n = 0;
        while (n < 20) {
            block20: {
                Connection connection = null;
                try {
                    connection = this.getConnection();
                    if (connection == null) {
                        this.logger(2, "dealBatchDelete() unable to get a connection");
                        break block20;
                    }
                    int n2 = this.dealBatchDeletePrivate(connection, string, yP_TCD_DesignAccesObject, fieldArray);
                    return n2;
                }
                catch (Exception exception) {
                    this.logger(3, "dealBatchInsert() " + exception);
                    if (exception.getMessage().contains("Communications link failure") && UtilsYP.getInstanceRole() == 1 && this.getSiteIdentifier() != UtilsYP.getInstanceNumber()) {
                        return -1;
                    }
                    if (this.createTableMayBeNeeded(exception)) {
                        if (yP_TCD_DesignAccesObject == null || this.createTable(yP_TCD_DesignAccesObject) != 1) {
                            return -1;
                        }
                    } else {
                        if (exception.getMessage().contains("Duplicate entry")) {
                            this.logger(2, "dealBatchDelete() TODO verif if the row we want to insert is the same than the one in the DB ???");
                            return -1;
                        }
                        this.closeConnection(connection);
                        connection = null;
                        if (exception.getMessage().contains("Connection reset by peer: socket write error")) {
                            UtilsYP.sleep(10);
                            if (UtilsYP.isTimeout(l, 60000)) {
                                this.logger(1, "dealBatchDelete() give up after timeout !!!" + exception);
                                n = 20;
                            } else {
                                --n;
                            }
                        } else {
                            UtilsYP.sleep(1000);
                        }
                    }
                }
                finally {
                    if (connection != null) {
                        this.releaseConnection(connection);
                    }
                }
            }
            ++n;
        }
        this.sysLog(1, "Database connection aborted after 20 tries. Request:" + string + " dealBatchInsert()");
        return -1;
    }

    private void sqlLogs(String string, YP_TCD_DesignAccesObject ... yP_TCD_DesignAccesObjectArray) {
        this.sqlLogs(yP_TCD_DesignAccesObjectArray != null && yP_TCD_DesignAccesObjectArray.length > 0 ? yP_TCD_DesignAccesObjectArray[0] : null, string);
    }

    private void sqlLogs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(-4, string);
        } else {
            Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
            if (clazz != DAO_ConnectionStatus.class && clazz != DAO_ContractStatus.class && clazz != DAO_CryptoModuleStatus.class && clazz != DAO_PluginStatus.class && clazz != DAO_ServiceStatus.class && clazz != DAO_TerminalStatus.class && clazz != DAO_UserStatus.class) {
                if (clazz == DAO_TokenTable.class) {
                    this.logger(-5, string);
                } else {
                    this.logger(-4, string);
                }
            }
        }
    }

    private void logSlowQuery(long l, String string) {
        if (UtilsYP.isTimeout(l, 2000)) {
            try {
                long l2 = System.currentTimeMillis() - l;
                this.logger(-6, String.valueOf(l2) + "ms - " + string);
            }
            catch (Exception exception) {}
        }
    }
}

