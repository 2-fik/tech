/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test8
extends YP_Row {
    @PrimaryKey
    public long idTest8 = 0L;
    public byte[] test8CharArray = new byte[60];
}

