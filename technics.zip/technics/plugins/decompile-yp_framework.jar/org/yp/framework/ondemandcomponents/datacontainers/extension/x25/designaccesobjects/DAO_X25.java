/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.x25.designaccesobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Group;

public class DAO_X25
extends YP_Row {
    @PrimaryKey
    public long idX25 = 0L;
    public byte[] adresseX25 = new byte[64];
    public byte[] ert = new byte[2];
    public byte[] serviceRequested = new byte[15];
    public long idConnection = 0L;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
}

