/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.utils.UtilsYP;

public class YP_TCD_ConnectionHandler
extends YP_OnDemandComponent {
    YP_PHYS_Interface physicalInterface;
    YP_PROT_Interface_Com communicationInterface;

    public YP_TCD_ConnectionHandler(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    public int waitRequest(int n) {
        if (this.physicalInterface == null) {
            return -1;
        }
        byte[] byArray = new byte[10];
        return this.physicalInterface.peek(byArray, 0, 10, n);
    }

    @Deprecated
    public int waitRequest() {
        return this.waitRequest(300000);
    }

    public byte[] getInitialRequest() {
        if (this.physicalInterface == null) {
            return null;
        }
        if (this.communicationInterface != null) {
            try {
                return this.communicationInterface.receive(false);
            }
            catch (YP_PROT_Interface_Com.BadFormatException | YP_PROT_Interface_Com.DisconnectionException | YP_PROT_Interface_Com.TimeOutException exception) {
                this.logger(2, "getInitialRequest() " + exception);
                return null;
            }
        }
        byte[] byArray = new byte[100];
        int n = this.physicalInterface.peek(byArray, 0, byArray.length, 3000);
        if (n <= 0) {
            this.logger(2, "getInitialRequest() nothing received");
            return null;
        }
        if (n <= 3) {
            this.logger(2, "getInitialRequest() too few received");
            this.logger(4, UtilsYP.getFormattedLog(0, byArray, 0, n));
            return null;
        }
        if ((byArray[0] & 0xFF) == 207 && (byArray[1] & 0xFF) == 188 && (byArray[2] & 0xFF) == 189) {
            this.communicationInterface = (YP_PROT_Interface_Com)((Object)this.newPluginByName("WSDE", this.physicalInterface));
            try {
                return this.communicationInterface.receive(false);
            }
            catch (YP_PROT_Interface_Com.BadFormatException | YP_PROT_Interface_Com.DisconnectionException | YP_PROT_Interface_Com.TimeOutException exception) {
                this.logger(2, "getInitialRequest() 2  " + exception);
                return null;
            }
        }
        this.logger(2, "getInitialRequest() unknown mess");
        this.logger(4, UtilsYP.getFormattedLog(0, byArray, 0, n));
        return null;
    }

    public int send(String string) {
        if (string == null) {
            return -1;
        }
        return this.send(string.getBytes());
    }

    public int send(byte[] byArray) {
        if (this.communicationInterface != null) {
            try {
                this.communicationInterface.send(byArray, false);
                return 1;
            }
            catch (YP_PROT_Interface_Com.DisconnectionException | YP_PROT_Interface_Com.TimeOutException exception) {
                this.logger(2, "send() " + exception);
                return -1;
            }
        }
        this.logger(2, "send() TODO !!!");
        return -1;
    }

    public YP_PHYS_Interface getPhysicalInterface() {
        return this.physicalInterface;
    }

    public void setPhysicalInterface(YP_PHYS_Interface yP_PHYS_Interface) {
        this.physicalInterface = yP_PHYS_Interface;
    }

    public YP_PROT_Interface_Com getCommunicationInterface() {
        return this.communicationInterface;
    }

    public void setCommunicationInterface(YP_PROT_Interface_Com yP_PROT_Interface_Com) {
        this.communicationInterface = yP_PROT_Interface_Com;
    }

    @Override
    public int shutdown() {
        if (this.communicationInterface != null) {
            this.communicationInterface.shutdown();
            this.communicationInterface = null;
        }
        if (this.physicalInterface != null) {
            this.physicalInterface.shutdown();
            this.physicalInterface = null;
        }
        super.shutdown();
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    @Override
    public String toString() {
        return "ConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }
}

