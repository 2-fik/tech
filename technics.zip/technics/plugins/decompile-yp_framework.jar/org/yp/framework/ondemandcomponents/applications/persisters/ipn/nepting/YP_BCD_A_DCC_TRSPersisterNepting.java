/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting;

import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_KRN_InitialisationParameters;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects.DAO_Nepting_BrandAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects.DAO_Nepting_ContractAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects.DAO_Nepting_InitialisationExtension;
import org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects.DAO_Nepting_MerchantAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects.DAO_Nepting_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister.YP_TCD_DCB_Interface_TRSPersister;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_HTTPS_Network;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_EPayment;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.utils.CryptoUtils;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.xml.simplexml.xpde.ResultEnumeration;

public class YP_BCD_A_DCC_TRSPersisterNepting
extends YP_TCD_DCC_Business
implements YP_TCD_DCB_Interface_TRSPersister {
    private YP_TCD_DesignAccesObject neptingTransaction;
    private YP_TCD_DesignAccesObject brandAccess;
    private YP_TCD_DesignAccesObject merchantAccess;
    private YP_TCD_DesignAccesObject contractAccess;
    private YP_Service connectionManager = null;
    private static final int IPN_STANDARD = 1;
    private static final int IPN_CULTURA_BUGGED = 2;
    private static final int IPN_CULTURA_OK = 3;
    private static final int IPN_BK = 4;

    public YP_BCD_A_DCC_TRSPersisterNepting(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    private YP_Service getConnectionManager() {
        if (this.connectionManager == null) {
            this.connectionManager = (YP_Service)this.getPluginByName("ConnectionManager");
        }
        return this.connectionManager;
    }

    @Override
    public int initialize() {
        this.setContainerBusinessType(this.getContainerBusinessType() | 1);
        super.initialize();
        try {
            this.neptingTransaction = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Nepting_Transaction.class, 0, 0, null);
            this.brandAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Nepting_BrandAccess.class, 0, 0, null);
            this.merchantAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Nepting_MerchantAccess.class, 0, 0, null);
            this.contractAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Nepting_ContractAccess.class, 0, 0, null);
            if (this.initialisationParameters == null) {
                this.initialisationParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_InitialisationParameters.class, 0, 0, null);
            }
            this.initialisationParameters.addExtension(new DAO_Nepting_InitialisationExtension());
            this.getInitialisationRow();
            this.loadBrands();
            this.loadMerchants();
            this.loadContracts();
        }
        catch (Exception exception) {
            this.logger(2, "initialize()", exception);
        }
        return 1;
    }

    private int loadBrands() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.brandAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idBrand");
                if (l <= 0L) {
                    this.logger(2, "loadBrands() bad value for idBrand:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBrand", l);
                if (yP_TCD_DC_Context == null) {
                    this.logger(2, "loadBrands() unable to get datacontainer for idBrand:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl) continue;
                this.logger(3, "loadBrands() datacontainer already added for idBrand:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadBrands()", exception);
            return -1;
        }
    }

    private int loadMerchants() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.merchantAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idMerchant");
                if (l <= 0L) {
                    this.logger(2, "loadMerchants() bad value for idMerchant:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerMerchant", l);
                if (yP_TCD_DC_Context == null) {
                    this.logger(2, "loadMerchants() unable to get datacontainer for idMerchant:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl) continue;
                this.logger(3, "loadMerchants() datacontainer already added for idMerchant:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadMerchants()", exception);
            return -1;
        }
    }

    private int loadContracts() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.contractAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idContract");
                if (l <= 0L) {
                    this.logger(2, "loadContracts() bad value for idContract:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBusiness", l);
                if (yP_TCD_DC_Context == null) {
                    this.logger(2, "loadContracts() unable to get datacontainer for idContract:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl) continue;
                this.logger(3, "loadContracts() datacontainer already added for idContract:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadContracts()", exception);
            return -1;
        }
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.neptingTransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() neptingTransaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() brandAccess");
            }
            this.loadBrands();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() merchantAccess");
            }
            this.loadMerchants();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contractAccess");
            }
            this.loadContracts();
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.neptingTransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() neptingTransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.neptingTransaction != null && (yP_TCD_DesignAccesObject == this.neptingTransaction || clazz == this.neptingTransaction.getRowClass())) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() neptingTransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int persistTransaction(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (YP_TCD_DCC_Business.getTransactionStatus(yP_TCD_DC_Transaction) == TransactionStatusEnumeration.PENDING) {
            return 0;
        }
        if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) {
            this.logger(2, "persistTransaction() only for ETF busines ");
            return -1;
        }
        String string = this.getMerchantURLStatus(yP_TCD_DC_Transaction);
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "persistTransaction() No URL status");
            }
            return 0;
        }
        this.logger(4, "persistTransaction() Needed");
        YP_Row yP_Row = this.getTransactionRow((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business, yP_TCD_DC_Transaction, string);
        if (yP_Row == null) {
            this.logger(2, "persistTransaction() unable to get transactionRow");
            return -1;
        }
        return this.dealOneTransaction(yP_Row);
    }

    private YP_Row getTransactionRow(YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        Object object;
        String string2;
        String[] stringArray;
        YP_Row yP_Row;
        block35: {
            try {
                yP_Row = this.neptingTransaction.getNewRow();
                yP_Row.set("urlStatus", string);
                stringArray = yP_TCD_DC_Transaction.getContractIdentifier().split("_");
                if (stringArray.length >= 2) break block35;
                this.logger(2, "getTransactionRow() bad contract identifier :" + this.getContractIdentifier());
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTransactionRow() ", exception);
                return null;
            }
        }
        String string3 = String.valueOf(stringArray[0]) + "_" + stringArray[1];
        yP_Row.set("nep_MerchantID", string3);
        yP_Row.set("nep_TransactionID", yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionIdentifier());
        yP_Row.set("nep_Result", yP_TCD_DC_Transaction.commonHandler.getTransactionStatus());
        yP_Row.set("nep_ExtendedResult", yP_TCD_DC_Transaction.commonHandler.getExtendedResult().toString());
        String string4 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("numDossier"));
        if (string4 != null && !string4.isEmpty()) {
            yP_Row.set("nep_MerchantReference", string4);
        }
        yP_Row.set("nep_SystemDateTime", yP_TCD_DC_Transaction.commonHandler.getTransactionAppliLocalTime());
        yP_Row.set("nep_Amount", yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
        yP_Row.set("nep_CurrencyCode", yP_TCD_DC_Transaction.commonHandler.getTransactionCurrencyNumerical());
        yP_Row.set("nep_APIVersion", "1.1");
        String string5 = yP_TCD_DC_Transaction.accountHandler.getScheme();
        if (string5 == null || string5.isEmpty()) {
            string5 = "CB";
        }
        yP_Row.set("nep_PaymentScheme", string5);
        yP_Row.set("nep_TestMode", yP_TCD_DC_Transaction.commonHandler.isTestMode());
        yP_Row.set("nep_Ticket", yP_TCD_DCC_EFT_Business.getTransactionTicket(yP_TCD_DC_Transaction, false, 1));
        yP_Row.set("nep_Email", yP_TCD_DC_Transaction.accountHandler.getCustomerMailAddress());
        int n = this.getIPNMode(yP_TCD_DC_Transaction);
        yP_Row.set("nep_Mode", n);
        try {
            String string6 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("veresEnrolled"));
            if (string6 == null || string6.isEmpty() || !string6.contentEquals("Y")) {
                yP_Row.set("nep_RealisationMode", "0");
            } else {
                yP_Row.set("nep_RealisationMode", "1");
            }
        }
        catch (Exception exception) {
            yP_Row.set("nep_RealisationMode", "0");
        }
        long l = yP_TCD_DC_Transaction.accountHandler.getIDMeanOfPayment();
        if (l > 0L) {
            yP_Row.set("nep_MopID", l);
            yP_Row.set("nep_MaskedPan", yP_TCD_DC_Transaction.accountHandler.getMaskedAccountIdentifier());
            yP_Row.set("nep_EndOfValidity", yP_TCD_DC_Transaction.accountHandler.getAccountExpirationDate());
        }
        try {
            string2 = yP_TCD_DC_Transaction.getTokenHash();
            if (string2 != null && !string2.isEmpty()) {
                yP_Row.set("nep_CardToken", string2);
            }
        }
        catch (Exception exception) {
            this.logger(2, "getTransactionRow() nep_CardToken " + exception);
        }
        if ((string2 = yP_Row.getFieldStringValueByName("nep_Result")) != null && !string2.isEmpty()) {
            string2 = this.modifyNepResultIfNeeded(n, string2);
        }
        String string7 = yP_Row.getFieldStringValueByName("nep_MerchantReference");
        String string8 = yP_Row.getFieldStringValueByName("nep_MerchantID");
        String string9 = yP_Row.getFieldStringValueByName("nep_TransactionID");
        Boolean bl = (Boolean)yP_Row.getFieldValueByName("nep_TestMode");
        if (n == 2 && !bl.booleanValue()) {
            this.logger(4, "getTransactionRow() test mode forced");
            bl = true;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (n == 2 || n == 3) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "IPN_CULTURA");
            }
            stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string2.getBytes("UTF-8"))) + '|');
            stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string7.getBytes("UTF-8"))) + '|');
            if (this.getLogLevel() >= 5) {
                object = new StringBuilder();
                ((StringBuilder)object).append(String.valueOf(string2) + '|');
                ((StringBuilder)object).append(String.valueOf(string7) + '|');
                if (bl != null && bl.booleanValue()) {
                    ((StringBuilder)object).append("01234567890");
                } else {
                    ((StringBuilder)object).append("?????????");
                }
                this.logger(5, "getTransactionRow() Buffer to sign (without Base 64 encoding): " + ((StringBuilder)object).toString());
            }
        } else {
            if (n == 1) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "IPN_STANDARD");
                }
            } else if (n == 4 && this.getLogLevel() >= 5) {
                this.logger(5, "IPN_BK");
            }
            stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string8.getBytes("UTF-8"))) + '|');
            stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string9.getBytes("UTF-8"))) + '|');
            stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string2.getBytes("UTF-8"))) + '|');
            if (this.getLogLevel() >= 5) {
                object = new StringBuilder();
                ((StringBuilder)object).append(String.valueOf(string8) + '|');
                ((StringBuilder)object).append(String.valueOf(string9) + '|');
                ((StringBuilder)object).append(String.valueOf(string2) + '|');
                if (bl != null && bl.booleanValue()) {
                    ((StringBuilder)object).append("01234567890");
                } else {
                    ((StringBuilder)object).append("?????????");
                }
                this.logger(5, "getTransactionRow() Buffer to sign (without Base 64 encoding): " + ((StringBuilder)object).toString());
            }
        }
        if (this.getLogLevel() >= 5) {
            if (bl != null && bl.booleanValue()) {
                this.logger(5, "getTransactionRow() Buffer to sign: " + stringBuilder.toString() + "01234567890");
            } else {
                this.logger(5, "getTransactionRow() Buffer to sign: " + stringBuilder.toString() + "?????????");
            }
        }
        if ((object = (Object)CryptoUtils.getNepSign(bl, string8, stringBuilder)) != null) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getTransactionRow() nep_Sign: " + UtilsYP.devHexa((byte[])object));
            }
            String string10 = UtilsYP.base64Encode((byte[])object);
            yP_Row.set("nep_Sign", string10);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getTransactionRow() nep_Sign base64: " + string10);
            }
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(-538803943, (long)n);
            tLVHandler.addASCII(-538738408, string10);
            yP_TCD_DC_Transaction.commonHandler.setResponseAppTags(String.valueOf(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags()) + tLVHandler.toString());
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getTransactionRow() Apptags: " + yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
            }
        }
        return yP_Row;
    }

    private YP_PHYS_Interface connect(URL uRL) {
        YP_PHYS_Interface yP_PHYS_Interface;
        block9: {
            YP_Row yP_Row;
            block8: {
                block7: {
                    if (uRL != null) break block7;
                    this.logger(2, "connect() connection URL null");
                    return null;
                }
                yP_Row = (YP_Row)this.getConnectionManager().dealRequest(this, "getConnectionRow", "IPN", uRL.getProtocol(), uRL.getHost(), uRL.getPort(), uRL.getPath(), null);
                if (yP_Row != null) break block8;
                this.logger(2, "connect() unable to find connection row");
                return null;
            }
            try {
                yP_PHYS_Interface = (YP_PHYS_Interface)this.connectionManager.dealRequest(this, "openConnection", yP_Row);
                if (yP_PHYS_Interface != null) break block9;
                this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                return null;
            }
            catch (Exception exception) {
                try {
                    this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                    return null;
                }
                catch (Exception exception2) {
                    this.logger(2, "connect() ", exception2);
                    return null;
                }
            }
        }
        return yP_PHYS_Interface;
    }

    /*
     * Could not resolve type clashes
     * Loose catch block
     */
    private int dealOneTransaction(YP_Row yP_Row) {
        YP_PHYS_Interface yP_PHYS_Interface;
        block78: {
            int n;
            block76: {
                block77: {
                    URL uRL;
                    String string;
                    Object object;
                    Object object22;
                    Boolean bl;
                    String string2;
                    String string3;
                    String string4;
                    String string5;
                    String string6;
                    String string7;
                    String string8;
                    String string9;
                    String string10;
                    String string11;
                    String string12;
                    String string13;
                    if (yP_Row == null) {
                        this.logger(2, "dealOneTransaction() no transactionRow");
                        return -1;
                    }
                    yP_PHYS_Interface = null;
                    int n2 = (Integer)yP_Row.getFieldValueByName("nep_Mode");
                    if (n2 != 0) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Mode: " + n2);
                        }
                    } else {
                        n2 = 1;
                    }
                    HashMap<String, String> hashMap = new HashMap<String, String>();
                    String string14 = yP_Row.getFieldStringValueByName("nep_MerchantID");
                    if (string14 != null && !string14.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_MerchantID: " + string14);
                        }
                        hashMap.put("nep_MerchantID", UtilsYP.base64Encode(string14.getBytes("UTF-8")));
                    }
                    if ((string13 = yP_Row.getFieldStringValueByName("nep_TransactionID")) != null && !string13.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_TransactionID: " + string13);
                        }
                        hashMap.put("nep_TransactionID", UtilsYP.base64Encode(string13.getBytes("UTF-8")));
                    }
                    if ((string12 = yP_Row.getFieldStringValueByName("nep_Result")) != null && !string12.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Result: " + string12);
                        }
                        string12 = this.modifyNepResultIfNeeded(n2, string12);
                        hashMap.put("nep_Result", UtilsYP.base64Encode(string12.getBytes("UTF-8")));
                    }
                    if ((string11 = yP_Row.getFieldStringValueByName("nep_ExtendedResult")) != null && !string11.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_ExtendedResult: " + string11);
                        }
                        hashMap.put("nep_ExtendedResult", UtilsYP.base64Encode(string11.getBytes("UTF-8")));
                    }
                    if ((string10 = yP_Row.getFieldStringValueByName("nep_MerchantReference")) != null && !string10.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_MerchantReference: " + string10);
                        }
                        hashMap.put("nep_MerchantReference", UtilsYP.base64Encode(string10.getBytes("UTF-8")));
                    }
                    if ((string9 = yP_Row.getFieldStringValueByName("nep_Amount")) != null && !string9.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Amount: " + string9);
                        }
                        hashMap.put("nep_Amount", string9);
                    }
                    if ((string8 = yP_Row.getFieldStringValueByName("nep_CurrencyCode")) != null && !string8.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_CurrencyCode: " + string8);
                        }
                        hashMap.put("nep_CurrencyCode", string8);
                    }
                    if ((string7 = yP_Row.getFieldStringValueByName("nep_SystemDateTime")) != null && !string7.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_SystemDateTime: " + string7);
                        }
                        hashMap.put("nep_SystemDateTime", string7);
                    }
                    if ((string6 = yP_Row.getFieldStringValueByName("nep_APIVersion")) != null && !string6.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_APIVersion: " + string6);
                        }
                        hashMap.put("nep_APIVersion", UtilsYP.base64Encode(string6.getBytes("UTF-8")));
                    }
                    if ((string5 = yP_Row.getFieldStringValueByName("nep_PaymentScheme")) != null && !string5.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_PaymentScheme: " + string5);
                        }
                        hashMap.put("nep_PaymentScheme", UtilsYP.base64Encode(string5.getBytes("UTF-8")));
                    }
                    if ((string4 = yP_Row.getFieldStringValueByName("nep_RealisationMode")) != null && !string4.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_RealisationMode: " + string4);
                        }
                        hashMap.put("nep_RealisationMode", string4);
                    }
                    if ((string3 = yP_Row.getFieldStringValueByName("nep_Ticket")) != null && !string3.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Ticket: " + string3);
                        }
                        hashMap.put("nep_Ticket", UtilsYP.base64Encode(string3.getBytes("UTF-8")));
                    }
                    if ((string2 = yP_Row.getFieldStringValueByName("nep_Email")) != null && !string2.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Email: " + string2);
                        }
                        hashMap.put("nep_Email", UtilsYP.base64Encode(string2.getBytes("UTF-8")));
                    }
                    if ((bl = (Boolean)yP_Row.getFieldValueByName("nep_TestMode")) != null && this.getLogLevel() >= 5) {
                        this.logger(5, "dealOneTransaction() nep_TestMode: " + bl);
                    }
                    if (n2 == 4) {
                        long l = (Long)yP_Row.getFieldValueByName("nep_MopID");
                        if (l != 0L) {
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "dealOneTransaction() nep_MopID: " + l);
                            }
                            hashMap.put("nep_MopID", UtilsYP.base64Encode(Long.toString(l).getBytes()));
                            object22 = yP_Row.getFieldStringValueByName("nep_MaskedPan");
                            if (object22 != null && !((String)object22).isEmpty()) {
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, "dealOneTransaction() nep_MaskedPan: " + (String)object22);
                                }
                                hashMap.put("nep_MaskedPan", UtilsYP.base64Encode(((String)object22).getBytes("UTF-8")));
                            }
                            if ((object = yP_Row.getFieldStringValueByName("nep_EndOfValidity")) != null && !((String)object).isEmpty()) {
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, "dealOneTransaction() nep_EndOfValidity: " + (String)object);
                                }
                                try {
                                    object = ((String)object).substring(0, 10);
                                    hashMap.put("nep_EndOfValidity", UtilsYP.base64Encode(((String)object).getBytes("UTF-8")));
                                }
                                catch (Exception exception) {}
                            }
                        }
                        if ((object22 = yP_Row.getFieldStringValueByName("nep_CardToken")) != null && !((String)object22).isEmpty()) {
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "dealOneTransaction() nep_CardToken: " + (String)object22);
                            }
                            hashMap.put("nep_CardToken", UtilsYP.base64Encode(((String)object22).getBytes("UTF-8")));
                        }
                    }
                    if ((string = yP_Row.getFieldStringValueByName("nep_Sign")) != null && !string.isEmpty()) {
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() nep_Sign: " + string);
                        }
                        hashMap.put("nep_Sign", string);
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    for (Object object22 : hashMap.entrySet()) {
                        if (stringBuilder.length() != 0) {
                            stringBuilder.append('&');
                        }
                        if (n2 == 2 || n2 == 3) {
                            stringBuilder.append((String)object22.getKey());
                            stringBuilder.append('=');
                            stringBuilder.append(String.valueOf(object22.getValue()));
                            continue;
                        }
                        stringBuilder.append(URLEncoder.encode((String)object22.getKey(), "UTF-8"));
                        stringBuilder.append('=');
                        stringBuilder.append(URLEncoder.encode(String.valueOf(object22.getValue()), "UTF-8"));
                    }
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "Data to send: " + stringBuilder.toString());
                    }
                    object22 = stringBuilder.toString().getBytes("UTF-8");
                    object = yP_Row.getFieldStringValueByName("urlStatus");
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "dealOneTransaction() URL status: " + (String)object);
                    }
                    if ((yP_PHYS_Interface = this.connect(uRL = new URL((String)object))) == null) {
                        this.logger(2, "dealOneTransaction() connect failed: " + (String)object);
                        throw new YP_PROT_Interface_Com.ConnectionException();
                    }
                    n = -1;
                    try {
                        int n3 = yP_PHYS_Interface.send((byte[])object22, ((Object)object22).length);
                        if (n3 < 0) {
                            this.logger(2, "dealOneTransaction() send failed " + n3);
                            if (yP_PHYS_Interface instanceof YP_TCD_PHYS_HTTPS_Network) {
                                n = ((YP_TCD_PHYS_HTTPS_Network)yP_PHYS_Interface).getLastHTTPResponseCode();
                            }
                            if (n == 0) {
                                n = -1;
                            }
                        } else {
                            n = 0;
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "Failed to send data ", exception);
                    }
                    if (n != 0) break block76;
                    this.logger(4, "dealOneTransaction() OK  ");
                    if (!yP_Row.isItAClonedRow()) {
                        yP_Row.delete();
                        yP_Row.persist();
                    }
                    if (yP_PHYS_Interface == null) break block77;
                    try {
                        this.getConnectionManager().dealRequest(this, "closeConnection", yP_PHYS_Interface);
                    }
                    catch (Exception exception) {
                        this.logger(2, "dealOneTransaction() impossible to release the connection plugin ", exception);
                    }
                    yP_PHYS_Interface = null;
                }
                return 1;
            }
            String string = "";
            if (yP_Row.isItAClonedRow()) {
                yP_Row.setIsItAClonedRow(false);
            }
            yP_Row.set("responseMessage", string);
            yP_Row.set("responseCode", n);
            yP_Row.set("currentTry", (Integer)yP_Row.getFieldValueByName("currentTry") + 1);
            yP_Row.persist();
            if (yP_PHYS_Interface == null) break block78;
            try {
                this.getConnectionManager().dealRequest(this, "closeConnection", yP_PHYS_Interface);
            }
            catch (Exception exception) {
                this.logger(2, "dealOneTransaction() impossible to release the connection plugin ", exception);
            }
            yP_PHYS_Interface = null;
        }
        return -1;
        catch (Exception exception) {
            block79: {
                try {
                    this.logger(2, "dealOneTransaction() 1 ", exception);
                    if (yP_Row.isItAClonedRow()) {
                        yP_Row.setIsItAClonedRow(false);
                    }
                    yP_Row.set("responseMessage", exception.getMessage());
                    yP_Row.set("responseCode", -1);
                    int n = (Integer)yP_Row.getFieldValueByName("currentTry");
                    if (n == 0) {
                        yP_Row.set("currentTry", (Integer)yP_Row.getFieldValueByName("currentTry") + 1);
                    }
                    try {
                        yP_Row.persist();
                    }
                    catch (Exception exception2) {
                        this.logger(2, "dealOneTransaction() 2 ", exception2);
                    }
                    if (yP_PHYS_Interface == null) break block79;
                }
                catch (Throwable throwable) {
                    if (yP_PHYS_Interface != null) {
                        try {
                            this.getConnectionManager().dealRequest(this, "closeConnection", yP_PHYS_Interface);
                        }
                        catch (Exception exception3) {
                            this.logger(2, "dealOneTransaction() impossible to release the connection plugin ", exception3);
                        }
                        yP_PHYS_Interface = null;
                    }
                    throw throwable;
                }
                try {
                    this.getConnectionManager().dealRequest(this, "closeConnection", yP_PHYS_Interface);
                }
                catch (Exception exception4) {
                    this.logger(2, "dealOneTransaction() impossible to release the connection plugin ", exception4);
                }
                yP_PHYS_Interface = null;
            }
            return -1;
        }
    }

    private String modifyNepResultIfNeeded(int n, String string) {
        if (n == 2 || n == 3 || n == 4) {
            TransactionStatusEnumeration transactionStatusEnumeration = TransactionStatusEnumeration.valueOf(string);
            switch (transactionStatusEnumeration) {
                case ACCEPTED: {
                    string = ResultEnumeration.SUCCESS.xmlValue();
                    break;
                }
                case PENDING: {
                    string = ResultEnumeration.INTERMEDIATE.xmlValue();
                    break;
                }
                case REFUSED: {
                    string = ResultEnumeration.REFUSED.xmlValue();
                    break;
                }
                default: {
                    string = ResultEnumeration.ERROR.xmlValue();
                }
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "modifyNepResultIfNeeded() nep_Result modified: " + string);
            }
        }
        return string;
    }

    private int dealTransactionsUpload() {
        if (UtilsYP.getInstanceRole() != 1) {
            return 0;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.neptingTransaction);
        yP_ComplexGabarit.set("currentTry", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
        yP_ComplexGabarit.set(this.neptingTransaction.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 400);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 403);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 404);
        yP_ComplexGabarit.set("currentTry", YP_ComplexGabarit.OPERATOR.LESS, 10);
        List<YP_Row> list = this.neptingTransaction.getRowListSuchAs(0, 1000, yP_ComplexGabarit);
        if (list == null) {
            this.logger(2, "dealTransactionsUpload() unable to get transation list");
            return -1;
        }
        if (list.isEmpty()) {
            this.logger(4, "dealTransactionsUpload() nothing to do");
        } else {
            for (YP_Row yP_Row : list) {
                int n = this.dealOneTransaction(yP_Row);
                if (n == 1) continue;
                this.logger(2, "dealTransactionsUpload() unable to upload transaction");
                return -1;
            }
            this.logger(4, "dealTransactionsUpload() all transactions have been uploaded");
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            block9: {
                if (string == null || string.isEmpty()) break block9;
                switch (string) {
                    case "dealTransactionsUpload": {
                        return this.dealTransactionsUpload();
                    }
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : ", exception);
            return null;
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerTRSPersisterNepting";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.1";
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    private String getMerchantURLStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        String string;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_TCD_DC_Transaction.getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return null;
        }
        if (yP_TCD_PosProtocol instanceof YP_PROT_Interface_EPayment && (string = ((YP_PROT_Interface_EPayment)((Object)yP_TCD_PosProtocol)).getMerchantURLStatus()) != null && !string.isEmpty()) {
            return string;
        }
        string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
        if (string == null || string.isEmpty()) {
            if (yP_TCD_DC_Transaction.getLogLevel() >= 6) {
                yP_TCD_DC_Transaction.logger(6, "getMerchantURLStatus() no app tags");
            }
        } else {
            try {
                TLVHandler tLVHandler = new TLVHandler(string);
                TLV tLV = tLVHandler.getTLV(-538738413);
                if (tLV != null) {
                    return new String(tLV.value);
                }
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "getMerchantURLStatus() ", exception);
            }
        }
        return null;
    }

    private int getIPNMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        int n = 1;
        String string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
        if (string == null || string.isEmpty()) {
            if (yP_TCD_DC_Transaction.getLogLevel() >= 6) {
                yP_TCD_DC_Transaction.logger(6, "getIPNMode() no app tags");
            }
        } else {
            try {
                TLVHandler tLVHandler = new TLVHandler(string);
                TLV tLV = tLVHandler.getTLV(-538803943);
                if (tLV != null) {
                    n = TLVHandler.getDCBInt(tLV.value);
                }
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "getIPNMode() ", exception);
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getIPNMode() " + n);
        }
        return n;
    }
}

