/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

public class YP_ThreeDSecureEvent {
    protected THREEDSEVENT myEvent;

    public THREEDSEVENT getEventThreeDS() {
        return this.myEvent;
    }

    public void setEventThreeDS(THREEDSEVENT tHREEDSEVENT) {
        this.myEvent = tHREEDSEVENT;
    }

    public static enum THREEDSEVENT {
        OuvertureDialogue,
        ServiceRefuse,
        RefusAccepteur,
        RefusAcquereur,
        RepOk,
        RepKo,
        AttenteOd,
        synchroRequest,
        tlpInitTransfer,
        tlpDataTransfer,
        tlpActivateTable,
        tlpDealFunctionState,
        echoTest,
        giveTalk,
        dealGiveTalk,
        closeDialog,
        closeDialogReq,
        tlpInitTransferKo,
        openService,
        tlpAckFunctionalState,
        synchroLastRequest,
        synchroCloseDialog,
        askTableState,
        askSAState,
        askPAState,
        autoAnswer,
        autoEnd,
        autoprocess,
        fichierVide,
        askConsolidation,
        askRetry,
        askNewSession,
        dealInitTransactionUpload;

    }
}

