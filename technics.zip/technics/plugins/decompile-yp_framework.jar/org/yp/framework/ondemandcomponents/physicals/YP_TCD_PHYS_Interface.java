/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;

public abstract class YP_TCD_PHYS_Interface
extends YP_OnDemandComponent
implements YP_PHYS_Interface {
    private int connectionTimeout = 1000;

    public YP_TCD_PHYS_Interface(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        String string;
        super.initialize();
        if (this.getPropertyFileName() != null && (string = this.getProperty(this.getPropertyFileName(), "connectionTimeout")) != null) {
            this.setConnectionTimeout(Integer.parseInt(string));
        }
        return 1;
    }

    @Override
    public abstract int openClient(Object ... var1);

    @Override
    public abstract int openServer();

    @Override
    public abstract Object waitConnection();

    @Override
    public abstract int recv(byte[] var1, int var2, int var3, int var4);

    @Override
    public abstract int send(byte[] var1, int var2);

    @Override
    public abstract int available();

    @Override
    public abstract int clean(int var1);

    @Override
    public abstract int close();

    @Override
    public abstract int closeHandle(Object var1);

    @Override
    public abstract String getIP();

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    public void setConnectionTimeout(int n) {
        this.connectionTimeout = n;
    }

    public int getConnectionTimeout() {
        return this.connectionTimeout;
    }

    @Override
    public int peek(byte[] byArray, int n, int n2, int n3) {
        this.logger(2, "peek() is not supported yet");
        return -1;
    }

    protected void doTunnelHandshake(Socket socket, String string, int n) throws IOException {
        String string2;
        OutputStream outputStream = socket.getOutputStream();
        String string3 = "CONNECT " + string + ":" + n + " HTTP/1.0\n" + "User-Agent: BoardPad Server" + "\r\n\r\n";
        byte[] byArray = null;
        try {
            byArray = string3.getBytes("ASCII7");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            byArray = string3.getBytes();
        }
        outputStream.write(byArray);
        outputStream.flush();
        byte[] byArray2 = new byte[200];
        int n2 = 0;
        int n3 = 0;
        boolean bl = false;
        InputStream inputStream = socket.getInputStream();
        while (n3 < 2) {
            int n4 = inputStream.read();
            if (n4 < 0) {
                throw new IOException("Unexpected EOF from proxy");
            }
            if (n4 == 10) {
                bl = true;
                ++n3;
                continue;
            }
            if (n4 == 13) continue;
            n3 = 0;
            if (bl || n2 >= byArray2.length) continue;
            byArray2[n2++] = (byte)n4;
        }
        try {
            string2 = new String(byArray2, 0, n2, "ASCII7");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            string2 = new String(byArray2, 0, n2);
        }
        if (string2.toLowerCase().indexOf("200 connection established") == -1) {
            throw new IOException("Unable to tunnel through. Proxy returns \"" + string2 + "\"");
        }
    }
}

