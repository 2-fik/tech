/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Interface;

public interface YP_TCD_CRYPTO_RandomNumberGenerator_Interface
extends YP_TCD_CRYPTO_Interface {
    public void setSeed(int var1, String var2, byte[] var3) throws Exception;

    public byte[] generateSeed(int var1, String var2, int var3) throws Exception;

    public byte[] generateRandomBytes(int var1, String var2, byte[] var3, int var4) throws Exception;

    public int isRandomSupported(String var1);
}

