/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.hosts;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.YP_TCD_DCB_Interface_Hosts;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.designaccesobjects.DAO_STD_Hosts_Connections;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.designaccesobjects.DAO_STD_Hosts_Parameters;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TableStatusEnumeration;

public final class YP_TCD_DCB_STD_Hosts
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Hosts {
    private YP_TCD_DCC_Business dataContainer;
    public YP_TCD_DesignAccesObject hostsConnections;
    public YP_TCD_DesignAccesObject hostsParameters;

    public YP_TCD_DCB_STD_Hosts(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.hostsConnections = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_STD_Hosts_Connections.class, 0, 0, null);
                this.hostsParameters = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_STD_Hosts_Parameters.class, 0, 0, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "initialize()" + exception);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionSTD_Hosts";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.hostsConnections) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() hostsConnections");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.hostsParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() hostsParameters");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.hostsConnections) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() hostsConnections");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.hostsParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() hostsParameters");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.hostsConnections) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() hostsConnections");
            }
            this.checkConnections();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.hostsParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() hostsParameters");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public boolean isTLCNeeded() {
        Calendar calendar;
        Calendar calendar2;
        String string;
        block13: {
            Timestamp timestamp;
            block12: {
                block11: {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.hostsParameters);
                    yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, "TLC");
                    List<YP_Row> list = this.hostsParameters.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null || list.isEmpty()) {
                        this.logger(2, "isTLCNeeded() no row in TLC table ");
                        return false;
                    }
                    if (list.size() > 1) {
                        this.logger(3, "isTLCNeeded() too may rows");
                    }
                    YP_Row yP_Row = list.get(0);
                    string = yP_Row.getFieldStringValueByName("frequencyExtendedInYYMMWWDDHHMMSS");
                    timestamp = this.dataContainer.eventsInterface.getLastEventAppliLocalTime("TLC");
                    if (timestamp != null) break block11;
                    if (this.getLogLevel() >= 3) {
                        this.logger(3, "isTLCNeeded() probably the first TLC");
                    }
                    return true;
                }
                if (this.dataContainer.eventsInterface.getLastEventStatus("TLC") == 1) break block12;
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "isTLCNeeded() The last TLC failed. We have to try again");
                }
                return true;
            }
            calendar2 = UtilsYP.getCalendar(timestamp);
            calendar = this.dataContainer.timeInterface.getAppliLocalTime();
            calendar2.add(1, Integer.parseInt(string.substring(0, 2)));
            calendar2.add(2, Integer.parseInt(string.substring(2, 4)));
            calendar2.add(3, Integer.parseInt(string.substring(4, 6)));
            calendar2.add(6, Integer.parseInt(string.substring(6, 8)));
            calendar2.set(10, 0);
            calendar2.set(12, 0);
            calendar2.set(13, 0);
            if (!calendar2.before(calendar)) break block13;
            if (this.getLogLevel() >= 4) {
                this.logger(4, "isTLCNeeded() no transaction but we have to connect to the host");
            }
            return true;
        }
        try {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "isTLCNeeded() no transaction we don't need to connect to the host");
                this.logger(4, "isTLCNeeded() last TLC: " + UtilsYP.traceDateAndTime(calendar2));
                this.logger(4, "isTLCNeeded() current TLC: " + UtilsYP.traceDateAndTime(calendar));
            }
        }
        catch (Exception exception) {
            this.logger(2, "isTLCNeeded() Invalid value for frequencyExtendedInYYMMWWDDHHMMSS:  " + string + " " + exception);
        }
        return false;
    }

    @Override
    public YP_PROT_Interface_Prot.ConnectionParameters getConnectionParameters(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, int n, boolean bl) {
        YP_Row yP_Row;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.hostsConnections);
        String string = this.getName(sERVICEDEMANDE);
        if (string == null || string.isEmpty()) {
            this.logger(2, "getConnectionParameters() unknown service " + (Object)((Object)sERVICEDEMANDE));
            return null;
        }
        yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("rank", YP_ComplexGabarit.OPERATOR.EQUAL, n);
        List<YP_Row> list = this.hostsConnections.getRowListSuchAs(yP_ComplexGabarit);
        if (bl && (list == null || list.isEmpty())) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.hostsConnections);
            yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            list = this.hostsConnections.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(3, "getConnectionParameters() unable to retrieve hostRow");
                return null;
            }
            int n2 = list.size();
            yP_Row = list.get(n % n2);
        } else {
            if (list == null || list.isEmpty()) {
                this.logger(3, "getConnectionParameters() unable to retrieve hostRow");
                return null;
            }
            yP_Row = list.get(0);
        }
        return this.createConnectionParameters(yP_Row);
    }

    private YP_PROT_Interface_Prot.ConnectionParameters createConnectionParameters(YP_Row yP_Row) {
        YP_PROT_Interface_Prot.ConnectionParameters connectionParameters = new YP_PROT_Interface_Prot.ConnectionParameters();
        String string = yP_Row.getFieldStringValueByName("type");
        if (string.contentEquals("IP_V4")) {
            connectionParameters.ip = yP_Row.getFieldStringValueByName("ipAddress");
            connectionParameters.port = yP_Row.getFieldStringValueByName("port");
        } else if (string.contentEquals("X25")) {
            connectionParameters.ip = yP_Row.getFieldStringValueByName("connectionTelNumber");
            connectionParameters.port = yP_Row.getFieldStringValueByName("x25Address");
        } else {
            this.logger(2, "createConnectionParameters() unknown type:" + string);
            return null;
        }
        connectionParameters.ert = "";
        return connectionParameters;
    }

    private void checkConnections() {
        YP_Object yP_Object = this.getPluginByName("ConnectionManager");
        for (YP_Row yP_Row : this.hostsConnections) {
            YP_PROT_Interface_Prot.ConnectionParameters connectionParameters = this.createConnectionParameters(yP_Row);
            try {
                String string = yP_Row.getFieldStringValueByName("name");
                if (string.startsWith("TLM")) continue;
                yP_Object.dealRequest(this, "getConnectionRow", string, connectionParameters.ip, connectionParameters.port, connectionParameters.ert);
            }
            catch (Exception exception) {
                this.logger(2, "checkConnections() " + connectionParameters.ip + ":" + connectionParameters.port + " " + exception);
            }
        }
    }

    @Override
    public int deleteTLPHosts() {
        return this.deleteHosts(YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceTlp);
    }

    @Override
    public int deleteHosts(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        String string = this.getName(sERVICEDEMANDE);
        if (string == null || string.isEmpty()) {
            this.logger(2, "deleteHosts() unknown service " + (Object)((Object)sERVICEDEMANDE));
            return -1;
        }
        this.deleteOneTable(this.hostsConnections, string);
        this.deleteOneTable(this.hostsParameters, string);
        return 1;
    }

    private int deleteOneTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        List<YP_Row> list;
        YP_ComplexGabarit yP_ComplexGabarit;
        block7: {
            try {
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block7;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "deleteOneTable() " + exception);
                return -1;
            }
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = null;
        String string2 = list.get(0).getFieldStringValueByName("externalReference");
        if (string2 != null && !string2.isEmpty()) {
            int n = Integer.parseInt(string2);
            if (n > 0 && (yP_TCD_DesignAccesObject2 = this.dataContainer.getDesignAccesObject_ByNumber(n)) != null) {
                yP_TCD_DesignAccesObject2.setTableVersion("0000");
                yP_TCD_DesignAccesObject2.setTableCksum("0000");
                yP_TCD_DesignAccesObject2.setTableStatus(TableStatusEnumeration.INACTIVE);
                yP_TCD_DesignAccesObject2.deleteRows(true);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) {
                    this.logger(2, "deleteOneTable() " + yP_TCD_DesignAccesObject.getTableName() + " should be empty");
                }
            }
        } else {
            yP_TCD_DesignAccesObject.deleteRowsSuchAs(yP_ComplexGabarit);
            yP_TCD_DesignAccesObject.persist();
        }
        return 1;
    }

    @Override
    public int addHost(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, int n, String string, String string2, String string3, String string4) {
        String string5;
        block5: {
            try {
                string5 = this.getName(sERVICEDEMANDE);
                if (string5 != null && !string5.isEmpty()) break block5;
                this.logger(2, "addHost() unknown service " + (Object)((Object)sERVICEDEMANDE));
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "addHost() " + exception);
                return -1;
            }
        }
        YP_Row yP_Row = this.hostsConnections.getNewRow();
        yP_Row.set("name", string5);
        yP_Row.set("padType", string);
        if (string2.indexOf(46) >= 0) {
            yP_Row.set("type", "IP_V4");
            yP_Row.set("ipAddress", string2);
            yP_Row.set("port", Integer.parseInt(string3));
        } else {
            yP_Row.set("type", "X25");
            yP_Row.set("connectionTelNumber", string2);
            yP_Row.set("x25Address", string3);
        }
        yP_Row.set("rank", n);
        yP_Row.set("externalReference", string4);
        this.hostsConnections.addRow(yP_Row);
        this.hostsConnections.persist();
        return 1;
    }

    @Override
    public int getNbHost(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.hostsConnections);
        String string = this.getName(sERVICEDEMANDE);
        if (string == null || string.isEmpty()) {
            this.logger(2, "getNbHost() unknown service " + (Object)((Object)sERVICEDEMANDE));
            return -1;
        }
        yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        List<YP_Row> list = this.hostsConnections.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            return -1;
        }
        return list.size();
    }

    @Override
    public String get(String string) {
        return null;
    }

    public String getName(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        switch (sERVICEDEMANDE) {
            case ServiceAuto: 
            case ServiceTransactionStatus: 
            case ServiceGetCurrencyRate: {
                return "AUTO";
            }
            case ServiceGuarantee: {
                return "GUAR";
            }
            case ServiceTlc: {
                return "TLC";
            }
            case ServiceTlp: {
                return "TLP";
            }
            case ServiceTlm: {
                return "TLM";
            }
        }
        this.logger(2, "getName() unknown service " + (Object)((Object)sERVICEDEMANDE));
        return null;
    }
}

