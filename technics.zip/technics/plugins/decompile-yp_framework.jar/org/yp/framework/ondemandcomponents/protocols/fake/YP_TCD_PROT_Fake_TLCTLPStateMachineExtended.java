/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.fake;

import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachineExtended;
import org.yp.framework.ondemandcomponents.protocols.fake.YP_TCD_PROT_Fake_TLCTLPStateMachine;

public class YP_TCD_PROT_Fake_TLCTLPStateMachineExtended
extends YP_TCD_PROT_Fake_TLCTLPStateMachine
implements YP_PROT_Interface_StateMachineExtended {
    public YP_TCD_PROT_Fake_TLCTLPStateMachineExtended(YP_Object yP_Object, Object[] objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "SM_FAKE_TLCTLP_Extended";
    }

    @Override
    public int getErrorCode() {
        return 0;
    }

    @Override
    public int getTransactionStatus() {
        return 0;
    }
}

