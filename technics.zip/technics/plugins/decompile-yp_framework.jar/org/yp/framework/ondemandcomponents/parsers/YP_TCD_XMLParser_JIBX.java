/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jibx.runtime.BindingDirectory
 *  org.jibx.runtime.IBindingFactory
 *  org.jibx.runtime.IMarshallingContext
 *  org.jibx.runtime.IUnmarshallingContext
 */
package org.yp.framework.ondemandcomponents.parsers;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import org.jibx.runtime.BindingDirectory;
import org.jibx.runtime.IBindingFactory;
import org.jibx.runtime.IMarshallingContext;
import org.jibx.runtime.IUnmarshallingContext;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.parsers.YP_TCD_XMLParser_Interface;
import org.yp.xml.jibx.xpde.XPDERequest;
import org.yp.xml.jibx.xpde.XPDEResponse;

public final class YP_TCD_XMLParser_JIBX
extends YP_OnDemandComponent
implements YP_TCD_XMLParser_Interface {
    private IMarshallingContext globalMarshallerResponse;
    private IMarshallingContext globalMarshallerRequest;
    private IUnmarshallingContext globalUnmarshaller;
    private String schema = null;
    private String xsdFile = null;

    public YP_TCD_XMLParser_JIBX(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        if (this.getPropertyFileName() != null) {
            String string = this.getProperty(this.getPropertyFileName(), "schema");
            if (string != null) {
                this.schema = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "xsdFile")) != null) {
                this.xsdFile = string;
            }
        }
        if (this.schema == null) {
            this.logger(2, "initialize() missing mandatory parameter : schema");
            return -1;
        }
        if (this.xsdFile == null) {
            this.logger(2, "initialize() missing mandatory parameter : xsdFile");
            return -1;
        }
        try {
            IBindingFactory iBindingFactory = BindingDirectory.getFactory(XPDERequest.class);
            IBindingFactory iBindingFactory2 = BindingDirectory.getFactory(XPDEResponse.class);
            this.globalUnmarshaller = iBindingFactory.createUnmarshallingContext();
            this.globalMarshallerRequest = iBindingFactory.createMarshallingContext();
            this.globalMarshallerResponse = iBindingFactory2.createMarshallingContext();
        }
        catch (Exception exception) {
            this.logger(2, "initialize()  " + exception);
        }
        return 1;
    }

    @Override
    public final String toString() {
        return "XMLParserJIBX";
    }

    @Override
    public final String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    @Override
    public String objectToXML(Object object) {
        try {
            StringWriter stringWriter = new StringWriter();
            if (object instanceof XPDEResponse) {
                this.globalMarshallerResponse.marshalDocument(object, "UTF-8", null, (Writer)stringWriter);
            } else {
                this.globalMarshallerRequest.marshalDocument(object, "UTF-8", null, (Writer)stringWriter);
            }
            return stringWriter.toString();
        }
        catch (Exception exception) {
            this.logger(2, "objectToXML() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(String string) {
        try {
            StringReader stringReader = new StringReader(string);
            return this.globalUnmarshaller.unmarshalDocument((Reader)stringReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(byte[] byArray) {
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(byArray));
            return this.globalUnmarshaller.unmarshalDocument((Reader)inputStreamReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }
}

