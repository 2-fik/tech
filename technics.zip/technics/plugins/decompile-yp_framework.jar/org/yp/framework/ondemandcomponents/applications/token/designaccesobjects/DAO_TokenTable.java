/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.token.designaccesobjects;

import java.sql.Date;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_TokenTable
extends YP_Row {
    @PrimaryKey
    public long idToken = 0L;
    @Index
    public long hashedIndex = 0L;
    public byte[] hashedValue = new byte[128];
    public byte[] cryptedValue = new byte[128];
    public byte[] keyIdentifier = new byte[64];
    public Date endOfValidity = new Date(0L);

    @Override
    public final Object getFieldValueByName(String string) {
        try {
            if (string.contentEquals("idToken")) {
                return this.idToken;
            }
            if (string.contentEquals("hashedIndex")) {
                return this.hashedIndex;
            }
            if (string.contentEquals("hashedValue")) {
                return this.hashedValue;
            }
            if (string.contentEquals("cryptedValue")) {
                return this.cryptedValue;
            }
            if (string.contentEquals("keyIdentifier")) {
                return this.keyIdentifier;
            }
            return super.getFieldValueByName(string);
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldValueByName() " + exception);
            }
            return null;
        }
    }
}

