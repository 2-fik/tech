/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.extendedapplication;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.applications.YP_ApplicationEvent;
import org.yp.framework.ondemandcomponents.applications.extendedapplication.YP_BCD_A_DCC_Template;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters.YP_TCD_DCB_Interface_CallParameters;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.protocols.posmate.PosmateMessageAdaptor;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.ImageUtils;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TicketTypeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class XPDE_Template {
    protected final YP_Application application;
    protected final TransactionTypeEnumeration paymentType;
    protected final YP_TCD_PosProtocol.SUB_REQUEST_TYPE subRequestType;
    protected final YP_BCD_A_DCC_Template dataContainer;
    protected final YP_TCD_DCB_Interface_EMV emvExtension;
    protected final YP_ApplicationEvent myEvent;
    private boolean isAuthMandatory = true;
    private boolean isAuthRequested = true;
    private boolean isAutoCall = true;
    private boolean isAdditionalAuthRequested = false;
    protected Bitmap ticketType = new Bitmap().set(TicketTypeEnumeration.MERCHANT.getValue()).set(TicketTypeEnumeration.CUSTOMER.getValue());
    protected boolean posMateMessage = false;

    public XPDE_Template(YP_Application yP_Application, TransactionTypeEnumeration transactionTypeEnumeration, YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE, YP_BCD_A_DCC_Template yP_BCD_A_DCC_Template, YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV, YP_ApplicationEvent yP_ApplicationEvent) {
        this.application = yP_Application;
        this.paymentType = transactionTypeEnumeration;
        this.subRequestType = sUB_REQUEST_TYPE;
        this.dataContainer = yP_BCD_A_DCC_Template;
        this.emvExtension = yP_TCD_DCB_Interface_EMV;
        this.myEvent = yP_ApplicationEvent;
    }

    public void selection() {
        EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction());
        if (entryModeEnumeration != null) {
            switch (entryModeEnumeration) {
                case ENTRY_MODE_ICC: 
                case ENTRY_MODE_EMV_CONTACTLESS: {
                    break;
                }
                case ENTRY_MODE_KEYED: 
                case ENTRY_MODE_SCANNED: 
                case ENTRY_MODE_MAGSTRIPE: 
                case ENTRY_MODE_TAPPED: {
                    this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.nextStepEvent);
                    return;
                }
                default: {
                    this.application.logger(2, "selection() Entry mode not handled " + (Object)((Object)entryModeEnumeration));
                    this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                    this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                    return;
                }
            }
        }
        List<AccountHandler.ADF> list = this.application.getDataContainerTransaction().accountHandler.getADFList();
        try {
            List list2 = null;
            for (YP_App_Interface_Selection yP_App_Interface_Selection : this.dataContainer.selectorList) {
                if (yP_App_Interface_Selection.canHandle(entryModeEnumeration) && (list2 = (List)((YP_Object)((Object)yP_App_Interface_Selection)).dealRequest(this.application, "selectAID", list)) != null && !list2.isEmpty()) break;
            }
            if (list2 == null) {
                this.application.logger(2, "selection() 1");
                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                return;
            }
            if (list2.isEmpty()) {
                this.application.logger(2, "selection() 2");
                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                return;
            }
            if (list2.size() > 1) {
                this.application.logger(4, "selection() selection will be needed");
            }
            this.application.getDataContainerTransaction().accountHandler.setADFList(list2);
        }
        catch (Exception exception) {
            this.application.logger(2, "selection() ", exception);
            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
            return;
        }
        this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.nextStepEvent);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected String getNotForcableTVR() {
        try {
            if (YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_ICC && YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) {
                byte[] byArray = new byte[5];
                return UtilsYP.devHexa(byArray);
            }
            byte[] byArray = new byte[5];
            byArray[0] = -36;
            byArray[1] = 112;
            byArray[2] = -72;
            byte[] byArray2 = byArray;
            String string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("terminalActionCodeOnline"));
            if (string == null || string.isEmpty()) {
                TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction());
                if (transactionStatusEnumeration == TransactionStatusEnumeration.UNKNOWN || transactionStatusEnumeration == TransactionStatusEnumeration.ACCEPTED) {
                    this.application.logger(2, "notForcableTVR() bad terminalActionCodeOnline!!!");
                }
                return null;
            }
            byte[] byArray3 = UtilsYP.redHexa(string);
            byte[] byArray4 = UtilsYP.redHexa(YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerActionCodeOnline")));
            int n = 0;
            while (true) {
                if (n >= byArray2.length) {
                    byArray2[0] = (byte)(byArray2[0] | 0x4C);
                    return UtilsYP.devHexa(byArray2);
                }
                int n2 = n;
                byArray2[n2] = (byte)(byArray2[n2] & (byArray3[n] | byArray4[n]));
                ++n;
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "getNotForcableTVR() ", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected String getNotForcableExtendedTVR() {
        try {
            ExtendedTVR extendedTVR = new ExtendedTVR();
            if (YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_ICC && YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) {
                extendedTVR.add(ExtendedTVREnumeration.ONLINE_CARD_ISSUER_SERVICE_CODE);
                extendedTVR.add(ExtendedTVREnumeration.BIN_UNKNOWN);
                extendedTVR.add(ExtendedTVREnumeration.BIN_WATCHED);
                extendedTVR.add(ExtendedTVREnumeration.CARD_WATCHED);
                extendedTVR.add(ExtendedTVREnumeration.PRE_AUTO);
                return extendedTVR.toString();
            }
            String string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("terminalActionCodeOnline"));
            if (string == null || string.isEmpty()) {
                TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction());
                if (transactionStatusEnumeration != TransactionStatusEnumeration.UNKNOWN) {
                    if (transactionStatusEnumeration != TransactionStatusEnumeration.ACCEPTED) return null;
                }
                this.application.logger(2, "getNotForcableExtendedTVR() bad terminalActionCodeOnline!!!");
                return null;
            }
            byte[] byArray = UtilsYP.redHexa(string);
            byte[] byArray2 = UtilsYP.redHexa(YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerActionCodeOnline")));
            int n = 0;
            while (true) {
                if (n >= byArray2.length) {
                    if ((byArray2[3] & 0x80) != 0) {
                        extendedTVR.add(ExtendedTVREnumeration.BIN_UNKNOWN);
                        extendedTVR.add(ExtendedTVREnumeration.BIN_WATCHED);
                        extendedTVR.add(ExtendedTVREnumeration.CARD_WATCHED);
                    }
                    if ((byArray2[0] & 0x10) != 0) {
                        extendedTVR.add(ExtendedTVREnumeration.BIN_FORBIDDEN);
                        extendedTVR.add(ExtendedTVREnumeration.BIN_REFUSED);
                        extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                        extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                    }
                    extendedTVR.add(ExtendedTVREnumeration.PRE_AUTO);
                    return extendedTVR.toString();
                }
                int n2 = n;
                byArray2[n2] = (byte)(byArray2[n2] | byArray[n]);
                ++n;
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "getNotForcableExtendedTVR() " + exception);
            return null;
        }
    }

    protected String computeProcessingCode() {
        try {
            switch (YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())) {
                case DEBIT: 
                case REVERSAL_DEBIT: 
                case INITIAL_RESERVATION: 
                case ADDITIONAL_RESERVATION: 
                case ONE_TIME_RESERVATION: 
                case CLOSING_PAYMENT: 
                case COMPLEMENTARY_PAYMENT: 
                case ADVICE_DEBIT: 
                case ADVICE_REVERSAL: 
                case DEBIT_DIFFERED: 
                case REVERSAL_QUASI_CASH: {
                    return "00";
                }
                case CREDIT: 
                case ADVICE_REFUND: 
                case COMPLEMENTARY_REFUND: {
                    return "20";
                }
                case CASH_ADVANCE: {
                    return "01";
                }
                case QUASI_CASH: {
                    return "11";
                }
                case REFUND_QUASI_CASH: {
                    return "28";
                }
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "computeProcessingCode() " + exception);
            return "57";
        }
        this.application.logger(2, "computeProcessingCode() unhandled transaction type: " + (Object)((Object)YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())));
        return "57";
    }

    protected void fillOpenTransactionResponseDatas() {
        CharSequence charSequence;
        String string;
        String string2;
        Object object2;
        int n;
        long l;
        long l2;
        long l3;
        Object object3;
        TLVHandler tLVHandler = new TLVHandler();
        if (this.paymentType == TransactionTypeEnumeration.DEBIT || this.paymentType == TransactionTypeEnumeration.DEBIT_DIFFERED || this.paymentType == TransactionTypeEnumeration.INITIAL_RESERVATION || this.paymentType == TransactionTypeEnumeration.QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0E9F0F9F179F219F339F349F399F419F42");
            tLVHandler.add(14672660, "575A828E959A9B9C5F245F255F2A5F349F029F069F079F089F099F0D9F0E9F0F9F109F179F219F269F279F339F349F359F369F379F399F419F42");
            tLVHandler.add(14672661, "57505A717282898A8E8F91959A9B9C5F245F255F2A5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F339F349F359F369F379F399F415F28");
        } else if (this.paymentType == TransactionTypeEnumeration.REVERSAL_DEBIT || this.paymentType == TransactionTypeEnumeration.REVERSAL_QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0E9F0F9F179F219F339F399F419F42");
            if (this.isAuthRequested) {
                tLVHandler.add(14672660, "575A828E959A9B9C5F245F255F2A5F349F029F069F079F089F099F0D9F0E9F0F9F109F179F219F269F279F339F349F359F369F379F399F419F42");
            }
            tLVHandler.add(14672661, "9A9F21");
        } else if (this.paymentType == TransactionTypeEnumeration.CREDIT || this.paymentType == TransactionTypeEnumeration.REFUND_QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0E9F0F9F179F219F339F349F399F419F42");
            tLVHandler.add(14672661, "57505A717282898A8E8F91959A9B9C5F245F255F2A5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F339F349F359F369F379F399F415F28");
        }
        tLVHandler.add(14672642, this.application.getDataContainerTransaction().getExtendedTVR().toString());
        if (this.paymentType == TransactionTypeEnumeration.DEBIT) {
            object3 = this.dataContainer.getTransactionTypeAllowed(this.application.getDataContainerTransaction());
            if (object3 != null && ((Bitmap)object3).isSet(TransactionTypeEnumeration.DEBIT_DIFFERED.getValue())) {
                if (YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) == EntryModeEnumeration.ENTRY_MODE_ICC || YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) == EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE || YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction()) == EntryModeEnumeration.ENTRY_MODE_KEYED) {
                    tLVHandler.add(14672129, 1L);
                } else {
                    tLVHandler.add(14672129, 0L);
                }
            } else {
                tLVHandler.add(14672129, 0L);
            }
        }
        if (this.paymentType == TransactionTypeEnumeration.QUASI_CASH) {
            tLVHandler.add(14672129, 0L);
        }
        if ((object3 = this.dataContainer.getEndUserLangageList(this.application.getDataContainerTransaction())) != null) {
            int n2 = 0;
            while (n2 < ((String)object3).length() - 1) {
                tLVHandler.add(14672657, UtilsYP.devHexa(((String)object3).substring(n2, n2 + 2).getBytes()));
                n2 += 2;
            }
        }
        TLVHandler tLVHandler2 = new TLVHandler();
        int n3 = 0;
        try {
            n3 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction());
            if (n3 > 0) {
                tLVHandler2.add(-538803964, (long)n3);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionResponseDatas() pb with stan!!!: " + exception);
        }
        this.fillAdditionalTRMTagsInOpenResponse(tLVHandler2);
        if (!tLVHandler2.isEmpty()) {
            tLVHandler.add(-2064111, tLVHandler2.toString());
        }
        TLVHandler tLVHandler3 = new TLVHandler();
        if (n3 > 0) {
            tLVHandler3.add(-538803964, (long)n3);
        }
        if ((l3 = YP_TCD_DCC_Business.getConvertedAmount(this.application.getDataContainerTransaction())) > 0L) {
            tLVHandler3.add(14672449, l3);
            tLVHandler3.add(14672450, (long)YP_TCD_DCC_Business.getConvertedCurrencyNumerical(this.application.getDataContainerTransaction()));
            tLVHandler3.add(14672451, (long)YP_TCD_DCC_Business.getConvertedAmountFraction(this.application.getDataContainerTransaction()));
            tLVHandler3.addASCII(14672708, YP_TCD_DCC_Business.getConvertedCurrencyAlpha(this.application.getDataContainerTransaction()));
        }
        if ((l2 = System.currentTimeMillis() - this.application.getDataContainerTransaction().getTransactionProcessFather().getStartTime()) > 0L) {
            tLVHandler3.add(-538803967, l2);
        }
        if ((l = YP_TCD_DCC_Business.getTransactionSystemGMTTimeMS(this.application.getDataContainerTransaction())) > 0L) {
            tLVHandler3.add(-538803914, l);
        }
        this.fillAdditionalCompletionTagsInOpenResponse(tLVHandler3);
        if (!tLVHandler3.isEmpty()) {
            tLVHandler.add(16769856, tLVHandler3.toString());
        }
        if ((n = this.dataContainer.getInterCharacterTimeout(this.application.getDataContainerTransaction(), this.application.getDataContainerTransaction().accountHandler.getAccountIdentifier())) > 0) {
            tLVHandler.add(14672456, (long)n);
        } else {
            tLVHandler.add(14672456, 20L);
        }
        try {
            object2 = String.valueOf(this.dataContainer.currencyInterface.formatAmount(YP_TCD_DCC_Business.getTransactionAmount(this.application.getDataContainerTransaction()), YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.application.getDataContainerTransaction()))) + ' ' + YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.application.getDataContainerTransaction());
            tLVHandler.addASCII(14672716, (String)object2);
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionResponseDatas() formated amount " + exception);
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_CURRENCY)) {
            object2 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
        } else if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            object2 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
        } else {
            object2 = this.dataContainer.callParametersInterface.getThresholds(this.application.getDataContainerTransaction());
            if (object2 == null) {
                object2 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
            }
        }
        tLVHandler.add(14672485, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object2).defaultThreshold);
        tLVHandler.add(14672486, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object2).pinThreshold);
        tLVHandler.add(14672487, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object2).manualThreshold);
        tLVHandler.add(14672488, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object2).signatureThreshold);
        tLVHandler.add(14672489, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object2).pinAndSignatureThreshold);
        TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction());
        if (transactionStatusEnumeration == TransactionStatusEnumeration.UNKNOWN) {
            tLVHandler.add(14672409, (long)TransactionStatusEnumeration.ACCEPTED.code);
        } else {
            tLVHandler.add(14672409, (long)transactionStatusEnumeration.code);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        TLVHandler tLVHandler4 = new TLVHandler();
        String string3 = UtilsYP.getAAAAMMJJHHMMSSTime(UtilsYP.getCalendar(YP_TCD_DCC_Business.getTransactionAppliLocalTime(this.application.getDataContainerTransaction())));
        tLVHandler4.add("9A", string3.substring(2, 8));
        String string4 = this.dataContainer.getAcquiringInstitutionIdentificationCode();
        if (string4 != null && !string4.isEmpty()) {
            tLVHandler4.addASCII("9F01", string4);
        }
        if ((string2 = this.dataContainer.getMerchantCategoryCode()) != null && !string2.isEmpty()) {
            tLVHandler4.add("9F15", string2);
        }
        if ((string = this.dataContainer.getMerchantContract()) != null && !string.isEmpty()) {
            charSequence = new StringBuilder(15);
            ((StringBuilder)charSequence).append(string);
            while (((StringBuilder)charSequence).length() < 15) {
                ((StringBuilder)charSequence).append(' ');
            }
            tLVHandler4.addASCII("9F16", ((StringBuilder)charSequence).substring(0, 15));
        }
        if ((charSequence = this.dataContainer.getMerchantName()) != null) {
            ((String)charSequence).isEmpty();
        }
        tLVHandler4.add("9F21", string3.substring(8, 14));
        tLVHandler4.add("9F41", String.format("%08d", YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction())));
        tLVHandler4.add("9C", this.computeProcessingCode());
        EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction());
        if (entryModeEnumeration != null) {
            switch (entryModeEnumeration) {
                case ENTRY_MODE_ICC: {
                    tLVHandler4.add("9F39", "09");
                    break;
                }
                case ENTRY_MODE_MAGSTRIPE: 
                case ENTRY_MODE_MAGSTRIPE_FALLBACK: {
                    tLVHandler4.add("9F39", "02");
                    break;
                }
                case ENTRY_MODE_KEYED: {
                    tLVHandler4.add("9F39", "01");
                    break;
                }
                default: {
                    this.application.logger(2, "fillOpenTransactionResponseDatas() unknown entryMode" + (Object)((Object)entryModeEnumeration));
                    this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                    break;
                }
            }
        } else {
            this.application.logger(2, "fillOpenTransactionResponseDatas() no entryMode");
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        tLVHandler4.add("5F2A", String.format("%04d", YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.application.getDataContainerTransaction())));
        tLVHandler4.add("5F36", String.format("%02d", YP_TCD_DCC_Business.getTransactionAmountFraction(this.application.getDataContainerTransaction())));
        tLVHandler4.add("9F02", String.format("%012d", YP_TCD_DCC_Business.getTransactionAmount(this.application.getDataContainerTransaction())));
        String string5 = this.dataContainer.getCountryCode(this.application.getDataContainerTransaction());
        while (string5.length() < 4) {
            string5 = String.valueOf('0') + string5;
        }
        tLVHandler4.add("9F1A", string5);
        long l4 = 0L;
        if (!this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_CURRENCY) && !this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY) && (l4 = entryModeEnumeration != null && entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC ? this.dataContainer.callParametersInterface.getMaxThresholdCall(this.application.getDataContainerTransaction()) : this.dataContainer.callParametersInterface.getThresholdCall(this.application.getDataContainerTransaction())) < 0L) {
            l4 = 0L;
        }
        tLVHandler4.add("9F1B", String.format("%8s", Long.toHexString(l4)).replace(' ', '0'));
        tLVHandler4.addASCII("9F1C", this.dataContainer.getTerminalIdentification());
        try {
            Long object4 = (Long)this.application.getDataContainerTransaction().getTemporaryValue("pinFloor");
            if (object4 != null) {
                tLVHandler.add(-538738348, (long)object4);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionResponseDatas() " + exception);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(tLVHandler4.toString());
        if (entryModeEnumeration != null && entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC) {
            try {
                for (AccountHandler.ADF aDF : this.application.getDataContainerTransaction().accountHandler.getADFList()) {
                    Object object;
                    List<Integer> list;
                    int n2;
                    int n4;
                    long l5;
                    int n5;
                    String string6;
                    String string7;
                    YP_Row yP_Row = this.emvExtension.getAIDParameters(aDF.aid);
                    if (yP_Row == null) continue;
                    String string8 = yP_Row.getFieldStringValueByName("specificData");
                    if (string8 != null && !string8.isEmpty()) {
                        aDF.emvTagsExtension = string8;
                    }
                    TLVHandler tLVHandler5 = new TLVHandler();
                    tLVHandler5.add(14672675, yP_Row.getFieldStringValueByName("tacDenial"));
                    tLVHandler5.add(14672676, yP_Row.getFieldStringValueByName("tacOnline"));
                    tLVHandler5.add(14672677, yP_Row.getFieldStringValueByName("tacDefault"));
                    String string9 = yP_Row.getFieldStringValueByName("defaultDDOL");
                    if (string9 != null && !string9.isEmpty()) {
                        tLVHandler5.add(14672678, string9);
                    }
                    if ((string7 = yP_Row.getFieldStringValueByName("defaultPDOL")) != null && !string7.isEmpty()) {
                        tLVHandler5.add(14672679, string7);
                    }
                    if ((string6 = yP_Row.getFieldStringValueByName("defaultTDOL")) != null && !string6.isEmpty()) {
                        tLVHandler5.add(14672680, string6);
                    }
                    if ((n5 = ((Integer)yP_Row.getFieldValueByName("currencyNumericalCode")).intValue()) >= 0) {
                        tLVHandler5.add(14672425, (long)n5);
                    }
                    if ((l5 = ((Long)yP_Row.getFieldValueByName("thresholdCall")).longValue()) >= 0L) {
                        tLVHandler5.add(14672426, l5);
                    }
                    if ((n4 = ((Integer)yP_Row.getFieldValueByName("randomCallCoefficient")).intValue()) >= 0) {
                        tLVHandler5.add(14672427, (long)n4);
                    }
                    if ((n2 = ((Integer)yP_Row.getFieldValueByName("randomCallMaximumCoefficient")).intValue()) >= 0) {
                        tLVHandler5.add(14672428, (long)n2);
                    }
                    if ((list = this.emvExtension.getTAVNList(aDF.aid)) != null && !list.isEmpty()) {
                        object = new StringBuilder();
                        for (int n6 : list) {
                            String string10 = Integer.toHexString(n6);
                            if (string10.length() == 1) {
                                ((StringBuilder)object).append("000");
                            } else if (string10.length() == 2) {
                                ((StringBuilder)object).append("00");
                            } else if (string10.length() == 3) {
                                ((StringBuilder)object).append('0');
                            } else if (string10.length() != 4) {
                                this.application.logger(2, "fillOpenTransactionResponseDatas() bad tavn:" + string10);
                                continue;
                            }
                            ((StringBuilder)object).append(string10);
                        }
                        tLVHandler5.add(14672685, ((StringBuilder)object).toString());
                    }
                    if ((object = this.emvExtension.getAIDData(aDF.aid)) != null) {
                        int n6;
                        n6 = (Integer)((YP_Row)object).getFieldValueByName("priority");
                        if (n6 == 254 || n6 == 255) {
                            tLVHandler5.add(14672223, (Boolean)true);
                        } else {
                            tLVHandler5.add(14672223, (Boolean)false);
                        }
                    } else {
                        tLVHandler5.add(14672223, (Boolean)false);
                    }
                    aDF.appTagsExtension = tLVHandler5.toString();
                }
            }
            catch (Exception exception) {
                this.application.logger(2, "fillOpenTransactionResponseDatas()  " + exception);
            }
        }
        if (this.posMateMessage) {
            PosmateMessageAdaptor posmateMessageAdaptor = new PosmateMessageAdaptor();
            String string11 = entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC ? posmateMessageAdaptor.getTransactionAndApplicationDataMsg(this.application.getDataContainerTransaction(), false, true) : posmateMessageAdaptor.getSwipedTransactionDataMsg(this.application.getDataContainerTransaction());
            if (string11 != null) {
                tLVHandler.addASCII(14672756, string11);
                this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
            }
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PROCESSING_ERROR)) {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
    }

    protected void fillAdditionalTRMTagsInOpenResponse(TLVHandler tLVHandler) {
    }

    protected void fillAdditionalCompletionTagsInOpenResponse(TLVHandler tLVHandler) {
    }

    protected void fillTerminalRiskManagementDatas() {
        PosmateMessageAdaptor posmateMessageAdaptor;
        String string;
        TransactionStatusEnumeration transactionStatusEnumeration;
        String string2;
        Timestamp timestamp;
        int n;
        String string3;
        TLVHandler tLVHandler = new TLVHandler();
        tLVHandler.add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        tLVHandler.add(14672642, this.application.getDataContainerTransaction().getExtendedTVR().toString());
        if (this.isAuthMandatory) {
            tLVHandler.add(14672160, 0L);
        } else {
            tLVHandler.add(14672160, 1L);
        }
        if (this.isAutoCall) {
            tLVHandler.add(14672161, 1L);
        } else {
            tLVHandler.add(14672161, 0L);
        }
        String string4 = this.getNotForcableTVR();
        if (string4 != null) {
            tLVHandler.add(14672697, string4);
        }
        if ((string3 = this.getNotForcableExtendedTVR()) != null) {
            tLVHandler.add(14672698, string3);
        }
        switch (YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())) {
            case DEBIT: 
            case REVERSAL_DEBIT: 
            case CREDIT: 
            case INITIAL_RESERVATION: 
            case DEBIT_DIFFERED: 
            case REVERSAL_QUASI_CASH: 
            case REFUND_QUASI_CASH: {
                if (this.isAuthRequested) {
                    tLVHandler.add(14672205, 1L);
                    break;
                }
                tLVHandler.add(14672205, 0L);
                break;
            }
            case QUASI_CASH: {
                tLVHandler.add(14672205, 1L);
                break;
            }
            default: {
                this.application.logger(2, "fillTerminalRiskManagementDatas() auto ? for unknown transaction type ");
            }
        }
        TLV tLV = this.getDukptTrack2TLVFromRequest();
        TLVHandler tLVHandler2 = new TLVHandler();
        if (tLV != null) {
            tLVHandler2.add(tLV);
        }
        tLVHandler2.add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        int n2 = 0;
        try {
            n2 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction());
            if (n2 > 0) {
                tLVHandler2.add(-538803964, (long)n2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillTerminalRiskManagementDatas() pb with stan!!!: " + exception);
        }
        this.fillAdditionalAuthorizationTagsInTRMResponse(tLVHandler2);
        if (!tLVHandler2.isEmpty()) {
            tLVHandler.add(16769870, tLVHandler2.toString());
        }
        TLVHandler tLVHandler3 = new TLVHandler();
        if (tLV != null) {
            tLVHandler3.add(tLV);
        }
        if ((n = YP_TCD_DCC_Business.getReferenceTransactionNumber(this.application.getDataContainerTransaction())) > 0) {
            tLVHandler3.add(14672443, (long)n);
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceTransactionAppliLocalTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler3.addASCII(14672700, timestamp.toString());
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceMerchantTransactionTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler3.addASCII(14672701, timestamp.toString());
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceTerminalTransactionTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler3.addASCII(14672702, timestamp.toString());
        }
        if ((string2 = YP_TCD_DCC_Business.getReferenceMerchantTransactionIdentifier(this.application.getDataContainerTransaction())) != null && !string2.isEmpty()) {
            tLVHandler3.addASCII(14672703, string2);
        }
        tLVHandler3.add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        long l = System.currentTimeMillis() - this.application.getDataContainerTransaction().getTransactionProcessFather().getStartTime();
        if (l > 0L) {
            tLVHandler3.add(-538803967, l);
        }
        if (n2 > 0) {
            tLVHandler3.add(-538803964, (long)n2);
        }
        this.fillAdditionalCompletionTagsInTRMResponse(tLVHandler3);
        tLVHandler.add(16769856, tLVHandler3.toString());
        tLVHandler.add(14672162, 1L);
        String string5 = this.application.getDataContainerBusiness().getMerchantContract();
        if (string5 != null && !string5.isEmpty()) {
            tLVHandler.add(14672713, UtilsYP.devHexa(string5.getBytes()));
        }
        if ((transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction())) == TransactionStatusEnumeration.UNKNOWN) {
            tLVHandler.add(14672409, (long)TransactionStatusEnumeration.ACCEPTED.code);
        } else {
            tLVHandler.add(14672409, (long)transactionStatusEnumeration.code);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        TLVHandler tLVHandler4 = new TLVHandler();
        long l2 = 0L;
        if (!this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_CURRENCY) && !this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            l2 = this.dataContainer.callParametersInterface.getThresholdCall(this.application.getDataContainerTransaction());
        }
        if (l2 < 0L) {
            l2 = 0L;
        }
        tLVHandler4.add("9F1B", String.format("%8s", Long.toHexString(l2)).replace(' ', '0'));
        try {
            tLVHandler4.add("95", YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("tvr")));
        }
        catch (Exception exception) {
            this.application.logger(2, "fillTerminalRiskManagementDatas() " + exception);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(tLVHandler4.toString());
        if (this.posMateMessage && (string = (posmateMessageAdaptor = new PosmateMessageAdaptor()).getTerminalRiskManagementMsg(this.application.getDataContainerTransaction())) != null) {
            tLVHandler.addASCII(14672756, string);
            this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PROCESSING_ERROR)) {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
    }

    protected void fillAdditionalCompletionTagsInTRMResponse(TLVHandler tLVHandler) {
    }

    protected void fillAdditionalAuthorizationTagsInTRMResponse(TLVHandler tLVHandler) {
    }

    protected void fillOpenTransactionAndTRMResponseDatas() {
        Object object;
        Object object2;
        CharSequence charSequence;
        String string;
        Object object3;
        TransactionStatusEnumeration transactionStatusEnumeration;
        String string2;
        Timestamp timestamp;
        int n;
        long l;
        long l2;
        Object object4;
        Object object5;
        String string3;
        Object object6;
        int n2;
        Object object7;
        TLVHandler tLVHandler = new TLVHandler();
        if (this.paymentType == TransactionTypeEnumeration.DEBIT || this.paymentType == TransactionTypeEnumeration.DEBIT_DIFFERED || this.paymentType == TransactionTypeEnumeration.QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0F9F179F219F339F349F399F41");
            tLVHandler.add(14672660, "575A828E959A9B9C5F245F255F2A5F349F029F069F079F089F099F0D9F0E9F0F9F109F179F219F269F279F339F349F359F369F379F399F41");
            tLVHandler.add(14672661, "57505A717282898A8E8F91959A9B9C5F245F255F2A5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F339F349F359F369F379F399F415F28");
        } else if (this.paymentType == TransactionTypeEnumeration.REVERSAL_DEBIT || this.paymentType == TransactionTypeEnumeration.REVERSAL_QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0F9F179F219F339F399F41");
            tLVHandler.add(14672661, "9A9F21");
        } else if (this.paymentType == TransactionTypeEnumeration.CREDIT || this.paymentType == TransactionTypeEnumeration.REFUND_QUASI_CASH) {
            tLVHandler.add(14672659, "575A828C8D8E959A9B9C5F245F255F2A5F305F349F029F069F079F089F0F9F179F219F339F349F399F41");
            tLVHandler.add(14672661, "57505A717282898A8E8F91959A9B9C5F245F255F2A5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F339F349F359F369F379F399F415F28");
        }
        tLVHandler.add(14672642, this.application.getDataContainerTransaction().getExtendedTVR().toString());
        if (this.paymentType == TransactionTypeEnumeration.DEBIT) {
            object7 = this.dataContainer.getTransactionTypeAllowed(this.application.getDataContainerTransaction());
            if (object7 != null && ((Bitmap)object7).isSet(TransactionTypeEnumeration.DEBIT_DIFFERED.getValue())) {
                tLVHandler.add(14672129, 1L);
            } else {
                tLVHandler.add(14672129, 0L);
            }
        } else if (this.paymentType == TransactionTypeEnumeration.INITIAL_RESERVATION || this.paymentType == TransactionTypeEnumeration.QUASI_CASH) {
            tLVHandler.add(14672129, 0L);
        }
        object7 = this.dataContainer.getEndUserLangageList(this.application.getDataContainerTransaction());
        if (object7 != null) {
            n2 = 0;
            while (n2 < ((String)object7).length() - 1) {
                tLVHandler.add(14672657, UtilsYP.devHexa(((String)object7).substring(n2, n2 + 2).getBytes()));
                n2 += 2;
            }
        }
        if ((n2 = this.dataContainer.getInterCharacterTimeout(this.application.getDataContainerTransaction(), this.application.getDataContainerTransaction().accountHandler.getAccountIdentifier())) > 0) {
            tLVHandler.add(14672456, (long)n2);
        } else {
            tLVHandler.add(14672456, 20L);
        }
        try {
            object6 = String.valueOf(this.dataContainer.currencyInterface.formatAmount(YP_TCD_DCC_Business.getTransactionAmount(this.application.getDataContainerTransaction()), YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.application.getDataContainerTransaction()))) + ' ' + YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.application.getDataContainerTransaction());
            tLVHandler.addASCII(14672716, (String)object6);
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() formated amount " + exception);
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_CURRENCY)) {
            object6 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
        } else if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            object6 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
        } else {
            object6 = this.dataContainer.callParametersInterface.getThresholds(this.application.getDataContainerTransaction());
            if (object6 == null) {
                object6 = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
            }
        }
        tLVHandler.add(14672485, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object6).defaultThreshold);
        tLVHandler.add(14672486, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object6).pinThreshold);
        tLVHandler.add(14672487, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object6).manualThreshold);
        tLVHandler.add(14672488, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object6).signatureThreshold);
        tLVHandler.add(14672489, ((YP_TCD_DCB_Interface_CallParameters.Thresholds)object6).pinAndSignatureThreshold);
        tLVHandler.add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        if (this.isAuthMandatory) {
            tLVHandler.add(14672160, 0L);
        } else {
            tLVHandler.add(14672160, 1L);
        }
        if (this.isAutoCall) {
            tLVHandler.add(14672161, 1L);
        } else {
            tLVHandler.add(14672161, 0L);
        }
        String string4 = this.getNotForcableTVR();
        if (string4 != null) {
            tLVHandler.add(14672697, string4);
        }
        if ((string3 = this.getNotForcableExtendedTVR()) != null) {
            tLVHandler.add(14672698, string3);
        }
        switch (YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())) {
            case DEBIT: 
            case REVERSAL_DEBIT: 
            case CREDIT: 
            case INITIAL_RESERVATION: 
            case DEBIT_DIFFERED: 
            case REVERSAL_QUASI_CASH: 
            case REFUND_QUASI_CASH: {
                if (this.isAuthRequested) {
                    tLVHandler.add(14672205, 1L);
                    break;
                }
                tLVHandler.add(14672205, 0L);
                break;
            }
            case QUASI_CASH: {
                tLVHandler.add(14672205, 1L);
                break;
            }
            default: {
                this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() auto ? for unknown transaction type ");
            }
        }
        String string5 = null;
        try {
            string5 = (String)this.application.getDataContainerTransaction().getTemporaryValue("qrCode");
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() Pb with qrcode ", exception);
        }
        String string6 = null;
        try {
            string6 = (String)this.application.getDataContainerTransaction().getTemporaryValue("qrcodeImage");
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() Pb when retrieving qrcodeImage ", exception);
        }
        if (string5 != null || string6 != null) {
            object5 = new TLVHandler();
            try {
                object4 = new StringBuilder();
                YP_TCD_DC_Transaction yP_TCD_DC_Transaction = this.application.getDataContainerTransaction();
                String string7 = yP_TCD_DC_Transaction.accountHandler.getScheme();
                ((StringBuilder)object4).append(string7);
                ((StringBuilder)object4).append('\n');
                int n3 = YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_TCD_DC_Transaction);
                long l3 = YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction);
                String string8 = YP_TCD_DCC_Business.getTransactionCurrencyAlpha(yP_TCD_DC_Transaction);
                if (string8 != null) {
                    ((StringBuilder)object4).append(this.dataContainer.currencyInterface.formatAmount(l3, n3));
                    ((StringBuilder)object4).append(' ');
                    ((StringBuilder)object4).append(string8);
                }
                ((TLVHandler)object5).add(-538738332, ((StringBuilder)object4).toString().getBytes("UTF-8"));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
            }
            if (string5 != null) {
                ((TLVHandler)object5).addASCII(-538738309, string5);
                if (string6 == null) {
                    try {
                        object4 = ImageUtils.getQRCodeImage(string5, 180, 180);
                        if (object4 != null) {
                            string6 = UtilsYP.devHexa((byte[])object4);
                            if (this.application.getLogLevel() >= 6) {
                                this.application.logger(6, "QRCode (base64): " + UtilsYP.base64Encode((byte[])object4));
                            }
                        }
                    }
                    catch (Exception exception) {
                        this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() Pb when building qrcodeImage ", exception);
                    }
                }
            }
            if (string6 != null) {
                ((TLVHandler)object5).add(-538738308, string6);
            }
            tLVHandler.add(-2064006, ((TLVHandler)object5).toString());
        }
        object5 = this.getDukptTrack2TLVFromRequest();
        object4 = new TLVHandler();
        if (object5 != null) {
            ((TLVHandler)object4).add((TLV)object5);
        }
        ((TLVHandler)object4).add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        int n4 = 0;
        try {
            n4 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction());
            if (n4 > 0) {
                ((TLVHandler)object4).add(-538803964, (long)n4);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() pb with stan!!!: ", exception);
        }
        if ((l2 = YP_TCD_DCC_Business.getTransactionSystemGMTTimeMS(this.application.getDataContainerTransaction())) > 0L) {
            ((TLVHandler)object4).add(-538803914, l2);
        }
        this.fillAdditionalAuthorizationTagsInOpenAndTRMResponse((TLVHandler)object4);
        if (!((TLVHandler)object4).isEmpty()) {
            tLVHandler.add(16769870, ((TLVHandler)object4).toString());
        }
        TLVHandler tLVHandler2 = new TLVHandler();
        if (object5 != null) {
            tLVHandler2.add((TLV)object5);
        }
        if ((l = YP_TCD_DCC_Business.getConvertedAmount(this.application.getDataContainerTransaction())) > 0L) {
            tLVHandler2.add(14672449, l);
            tLVHandler2.add(14672450, (long)YP_TCD_DCC_Business.getConvertedCurrencyNumerical(this.application.getDataContainerTransaction()));
            tLVHandler2.add(14672451, (long)YP_TCD_DCC_Business.getConvertedAmountFraction(this.application.getDataContainerTransaction()));
            tLVHandler2.addASCII(14672708, YP_TCD_DCC_Business.getConvertedCurrencyAlpha(this.application.getDataContainerTransaction()));
        }
        if ((n = YP_TCD_DCC_Business.getReferenceTransactionNumber(this.application.getDataContainerTransaction())) > 0) {
            tLVHandler2.add(14672443, (long)n);
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceTransactionAppliLocalTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler2.addASCII(14672700, timestamp.toString());
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceMerchantTransactionTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler2.addASCII(14672701, timestamp.toString());
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceTerminalTransactionTime(this.application.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            tLVHandler2.addASCII(14672702, timestamp.toString());
        }
        if ((string2 = YP_TCD_DCC_Business.getReferenceMerchantTransactionIdentifier(this.application.getDataContainerTransaction())) != null && !string2.isEmpty()) {
            tLVHandler2.addASCII(14672703, string2);
        }
        tLVHandler2.add(14672406, YP_TCD_DCC_Business.getCumulatedAmount(this.application.getDataContainerTransaction()));
        long l4 = System.currentTimeMillis() - this.application.getDataContainerTransaction().getTransactionProcessFather().getStartTime();
        if (l4 > 0L) {
            tLVHandler2.add(-538803967, l4);
        }
        if (l2 > 0L) {
            tLVHandler2.add(-538803914, l2);
        }
        if (n4 > 0) {
            tLVHandler2.add(-538803964, (long)n4);
        }
        this.fillAdditionalCompletionTagsInOpenAndTRMResponse(tLVHandler2);
        tLVHandler.add(16769856, tLVHandler2.toString());
        tLVHandler.add(14672162, 1L);
        String string9 = this.application.getDataContainerBusiness().getMerchantContract();
        if (string9 != null && !string9.isEmpty()) {
            tLVHandler.add(14672713, UtilsYP.devHexa(string9.getBytes()));
        }
        if ((transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction())) == TransactionStatusEnumeration.UNKNOWN) {
            tLVHandler.add(14672409, (long)TransactionStatusEnumeration.ACCEPTED.code);
        } else {
            tLVHandler.add(14672409, (long)transactionStatusEnumeration.code);
        }
        try {
            object3 = (Long)this.application.getDataContainerTransaction().getTemporaryValue("pinFloor");
            if (object3 != null) {
                tLVHandler.add(-538738348, ((Long)object3).longValue());
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() ", exception);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        object3 = new TLVHandler();
        String string10 = UtilsYP.getAAAAMMJJHHMMSSTime(UtilsYP.getCalendar(YP_TCD_DCC_Business.getTransactionAppliLocalTime(this.application.getDataContainerTransaction())));
        ((TLVHandler)object3).add("9A", string10.substring(2, 8));
        String string11 = this.dataContainer.getAcquiringInstitutionIdentificationCode();
        if (string11 != null && !string11.isEmpty()) {
            ((TLVHandler)object3).addASCII("9F01", string11);
        }
        if ((string = this.dataContainer.getMerchantCategoryCode()) != null && !string.isEmpty()) {
            ((TLVHandler)object3).add("9F15", string);
        }
        if (string9 != null && !string9.isEmpty()) {
            charSequence = new StringBuilder(15);
            ((StringBuilder)charSequence).append(string9);
            while (((StringBuilder)charSequence).length() < 15) {
                ((StringBuilder)charSequence).append(' ');
            }
            ((TLVHandler)object3).addASCII("9F16", ((StringBuilder)charSequence).substring(0, 15));
        }
        if ((charSequence = this.dataContainer.getMerchantName()) != null) {
            ((String)charSequence).isEmpty();
        }
        ((TLVHandler)object3).add("9F21", string10.substring(8, 14));
        ((TLVHandler)object3).add("9F41", String.format("%08d", YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction())));
        ((TLVHandler)object3).add("9C", this.computeProcessingCode());
        EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction());
        if (entryModeEnumeration != null) {
            switch (entryModeEnumeration) {
                case ENTRY_MODE_ICC: {
                    ((TLVHandler)object3).add("9F39", "09");
                    break;
                }
                case ENTRY_MODE_MAGSTRIPE: 
                case ENTRY_MODE_MAGSTRIPE_FALLBACK: {
                    ((TLVHandler)object3).add("9F39", "02");
                    break;
                }
                case ENTRY_MODE_KEYED: 
                case ENTRY_MODE_SCANNED: {
                    ((TLVHandler)object3).add("9F39", "01");
                    break;
                }
                case ENTRY_MODE_EMV_CONTACTLESS: {
                    ((TLVHandler)object3).add("9F39", "07");
                    break;
                }
                case ENTRY_MODE_TAPPED: {
                    ((TLVHandler)object3).add("9F39", "91");
                    break;
                }
                default: {
                    this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() unknown entryMode " + (Object)((Object)entryModeEnumeration));
                    this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                    break;
                }
            }
        } else {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() no entryMode");
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        ((TLVHandler)object3).add("5F2A", String.format("%04d", YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.application.getDataContainerTransaction())));
        ((TLVHandler)object3).add("5F36", String.format("%02d", YP_TCD_DCC_Business.getTransactionAmountFraction(this.application.getDataContainerTransaction())));
        ((TLVHandler)object3).add("9F02", String.format("%012d", YP_TCD_DCC_Business.getTransactionAmount(this.application.getDataContainerTransaction())));
        String string12 = this.dataContainer.getCountryCode(this.application.getDataContainerTransaction());
        while (string12.length() < 4) {
            string12 = String.valueOf('0') + string12;
        }
        ((TLVHandler)object3).add("9F1A", string12);
        long l5 = 0L;
        if (!this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_CURRENCY) && !this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY) && (l5 = entryModeEnumeration != null && entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC ? this.dataContainer.callParametersInterface.getMaxThresholdCall(this.application.getDataContainerTransaction()) : this.dataContainer.callParametersInterface.getThresholdCall(this.application.getDataContainerTransaction())) < 0L) {
            l5 = 0L;
        }
        ((TLVHandler)object3).add("9F1B", String.format("%8s", Long.toHexString(l5)).replace(' ', '0'));
        ((TLVHandler)object3).addASCII("9F1C", this.dataContainer.getTerminalIdentification());
        try {
            ((TLVHandler)object3).add("95", YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("tvr")));
        }
        catch (Exception exception) {
            this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() ", exception);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(((TLVHandler)object3).toString());
        if (entryModeEnumeration != null && entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC) {
            try {
                object2 = this.application.getDataContainerTransaction().accountHandler.getADFList().iterator();
                while (object2.hasNext()) {
                    Object object8;
                    List<Integer> list;
                    int n5;
                    int n6;
                    long l6;
                    int n7;
                    String string13;
                    String string14;
                    object = object2.next();
                    YP_Row yP_Row = this.emvExtension.getAIDParameters(((AccountHandler.ADF)object).aid);
                    if (yP_Row == null) continue;
                    String string15 = yP_Row.getFieldStringValueByName("specificData");
                    if (string15 != null && !string15.isEmpty()) {
                        ((AccountHandler.ADF)object).emvTagsExtension = string15;
                    }
                    TLVHandler tLVHandler3 = new TLVHandler();
                    tLVHandler3.add(14672675, yP_Row.getFieldStringValueByName("tacDenial"));
                    tLVHandler3.add(14672676, yP_Row.getFieldStringValueByName("tacOnline"));
                    tLVHandler3.add(14672677, yP_Row.getFieldStringValueByName("tacDefault"));
                    String string16 = yP_Row.getFieldStringValueByName("defaultDDOL");
                    if (string16 != null && !string16.isEmpty()) {
                        tLVHandler3.add(14672678, string16);
                    }
                    if ((string14 = yP_Row.getFieldStringValueByName("defaultPDOL")) != null && !string14.isEmpty()) {
                        tLVHandler3.add(14672679, string14);
                    }
                    if ((string13 = yP_Row.getFieldStringValueByName("defaultTDOL")) != null && !string13.isEmpty()) {
                        tLVHandler3.add(14672680, string13);
                    }
                    if ((n7 = ((Integer)yP_Row.getFieldValueByName("currencyNumericalCode")).intValue()) >= 0) {
                        tLVHandler3.add(14672425, (long)n7);
                    }
                    if ((l6 = ((Long)yP_Row.getFieldValueByName("thresholdCall")).longValue()) >= 0L) {
                        tLVHandler3.add(14672426, l6);
                    }
                    if ((n6 = ((Integer)yP_Row.getFieldValueByName("randomCallCoefficient")).intValue()) >= 0) {
                        tLVHandler3.add(14672427, (long)n6);
                    }
                    if ((n5 = ((Integer)yP_Row.getFieldValueByName("randomCallMaximumCoefficient")).intValue()) >= 0) {
                        tLVHandler3.add(14672428, (long)n5);
                    }
                    if ((list = this.emvExtension.getTAVNList(((AccountHandler.ADF)object).aid)) != null && !list.isEmpty()) {
                        object8 = new StringBuilder();
                        for (int n8 : list) {
                            String string17 = Integer.toHexString(n8);
                            if (string17.length() == 1) {
                                ((StringBuilder)object8).append("000");
                            } else if (string17.length() == 2) {
                                ((StringBuilder)object8).append("00");
                            } else if (string17.length() == 3) {
                                ((StringBuilder)object8).append('0');
                            } else if (string17.length() != 4) {
                                this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas() bad tavn:" + string17);
                                continue;
                            }
                            ((StringBuilder)object8).append(string17);
                        }
                        tLVHandler3.add(14672685, ((StringBuilder)object8).toString());
                    }
                    if ((object8 = this.emvExtension.getAIDData(((AccountHandler.ADF)object).aid)) != null) {
                        int n8;
                        n8 = (Integer)((YP_Row)object8).getFieldValueByName("priority");
                        if (n8 == 254 || n8 == 255) {
                            tLVHandler3.add(14672223, (Boolean)true);
                        } else {
                            tLVHandler3.add(14672223, (Boolean)false);
                        }
                    } else {
                        tLVHandler3.add(14672223, (Boolean)false);
                    }
                    ((AccountHandler.ADF)object).appTagsExtension = tLVHandler3.toString();
                }
            }
            catch (Exception exception) {
                this.application.logger(2, "fillOpenTransactionAndTRMResponseDatas()  ", exception);
            }
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(((TLVHandler)object3).toString());
        if (this.posMateMessage && (object2 = ((PosmateMessageAdaptor)(object = new PosmateMessageAdaptor())).getSwipedTransactionDataMsg(this.application.getDataContainerTransaction())) != null) {
            tLVHandler.addASCII(14672756, (String)object2);
            this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PROCESSING_ERROR)) {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
    }

    protected void fillAdditionalCompletionTagsInOpenAndTRMResponse(TLVHandler tLVHandler) {
    }

    protected void fillAdditionalAuthorizationTagsInOpenAndTRMResponse(TLVHandler tLVHandler) {
    }

    protected TLV getDukptTrack2TLVFromRequest() {
        String string;
        block3: {
            try {
                string = this.application.getDataContainerTransaction().commonHandler.getRequestAppTags();
                if (string != null && !string.isEmpty()) break block3;
                return null;
            }
            catch (Exception exception) {
                this.application.logger(2, "getDukptTrack2TLVFromRequest() " + exception);
                return null;
            }
        }
        TLVHandler tLVHandler = new TLVHandler(string);
        return tLVHandler.getTLV(16769892);
    }

    protected void fillAuthorizationDatas() {
        String string;
        Object object;
        TransactionStatusEnumeration transactionStatusEnumeration;
        long l;
        long l2;
        int n;
        String string2;
        String string3;
        Object object2;
        String string4;
        TLVHandler tLVHandler = new TLVHandler();
        if (this.isAuthMandatory) {
            tLVHandler.add(14672160, 0L);
        } else {
            tLVHandler.add(14672160, 1L);
        }
        tLVHandler.add(14672642, this.application.getDataContainerTransaction().getExtendedTVR().toString());
        String string5 = this.getNotForcableTVR();
        if (string5 != null) {
            tLVHandler.add(14672697, string5);
        }
        if ((string4 = this.getNotForcableExtendedTVR()) != null) {
            tLVHandler.add(14672698, string4);
        }
        try {
            object2 = new TLVHandler(this.application.getDataContainerTransaction().getAuthResponseBuffer());
            string3 = "";
            string2 = "";
            Iterator<TLV> iterator = ((TLVHandler)object2).iterator();
            while (iterator.hasNext()) {
                TLV tLV = iterator.next();
                block6 : switch (tLV.tag) {
                    case 187: {
                        tLVHandler.add(14672646, UtilsYP.devHexa(tLV.value));
                        break;
                    }
                    case 188: {
                        if (tLV.value.length <= 1) break;
                        String string6 = UtilsYP.devHexa(new String(tLV.value, 1, tLV.value.length - 1, "ISO-8859-1").getBytes("UTF-8"));
                        switch (tLV.value[0]) {
                            case 53: 
                            case 54: {
                                if (!string3.isEmpty()) {
                                    string3 = String.valueOf(string3) + "0A";
                                }
                                string3 = String.valueOf(string3) + string6;
                                break block6;
                            }
                            case 56: 
                            case 57: {
                                if (!string2.isEmpty()) {
                                    string2 = String.valueOf(string2) + "0A";
                                }
                                string2 = String.valueOf(string2) + string6;
                                break block6;
                            }
                            case 50: 
                            case 51: 
                            case 66: 
                            case 67: 
                            case 98: 
                            case 99: {
                                if (!string2.isEmpty()) {
                                    string2 = String.valueOf(string2) + "0A";
                                }
                                string2 = String.valueOf(string2) + string6;
                                if (!string3.isEmpty()) {
                                    string3 = String.valueOf(string3) + "0A";
                                }
                                string3 = String.valueOf(string3) + string6;
                                break block6;
                            }
                        }
                    }
                }
            }
            tLVHandler.add(14672647, string2);
            tLVHandler.add(14672648, string3);
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() " + exception);
        }
        try {
            object2 = (String)this.application.getDataContainerTransaction().getTemporaryValue("issuerScriptBefore");
            if (object2 != null) {
                tLVHandler.add(14672710, (String)object2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() " + exception);
        }
        try {
            object2 = (String)this.application.getDataContainerTransaction().getTemporaryValue("issuerScriptAfter");
            if (object2 != null) {
                tLVHandler.add(14672711, (String)object2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() " + exception);
        }
        object2 = new TLVHandler();
        string3 = this.application.getDataContainerTransaction().getAuthResponseBuffer();
        if (string3 != null && !string3.isEmpty()) {
            ((TLVHandler)object2).add(14672709, string3);
        }
        if ((string2 = this.application.getDataContainerTransaction().getAuthorisationResponseCode()) != null && !string2.isEmpty()) {
            ((TLVHandler)object2).addASCII(14672734, string2);
        }
        if ((n = this.application.getDataContainerTransaction().commonHandler.getAuthorisationTime()) > 0) {
            ((TLVHandler)object2).add(-538803968, (long)n);
        }
        if ((l2 = System.currentTimeMillis() - this.application.getDataContainerTransaction().getTransactionProcessFather().getStartTime()) > 0L) {
            ((TLVHandler)object2).add(-538803967, l2);
        }
        try {
            int n2 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction());
            if (n2 > 0) {
                ((TLVHandler)object2).add(-538803964, (long)n2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() pb with stan!!!: " + exception);
        }
        try {
            String string7 = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("acquirerTransmissionTime"));
            if (string7 != null && !string7.isEmpty()) {
                ((TLVHandler)object2).addASCII(-538738375, string7);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() ACQUIRER_TRANSMISSION_TIME!!!: " + exception);
        }
        if (this.isAdditionalAuthRequested) {
            tLVHandler.add(14672205, 1L);
        }
        if ((l = YP_TCD_DCC_Business.getConvertedAmount(this.application.getDataContainerTransaction())) > 0L) {
            ((TLVHandler)object2).add(14672449, l);
            ((TLVHandler)object2).add(14672450, (long)YP_TCD_DCC_Business.getConvertedCurrencyNumerical(this.application.getDataContainerTransaction()));
            ((TLVHandler)object2).add(14672451, (long)YP_TCD_DCC_Business.getConvertedAmountFraction(this.application.getDataContainerTransaction()));
            ((TLVHandler)object2).addASCII(14672708, YP_TCD_DCC_Business.getConvertedCurrencyAlpha(this.application.getDataContainerTransaction()));
        }
        this.fillAdditionalCompletionTagsInAuthorizationResponse((TLVHandler)object2);
        if (!((TLVHandler)object2).isEmpty()) {
            tLVHandler.add(16769856, ((TLVHandler)object2).toString());
        }
        if ((transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction())) == TransactionStatusEnumeration.UNKNOWN) {
            if (!this.isAdditionalAuthRequested) {
                tLVHandler.add(14672409, (long)TransactionStatusEnumeration.ACCEPTED.code);
            } else {
                tLVHandler.add(14672409, (long)transactionStatusEnumeration.code);
            }
        } else {
            tLVHandler.add(14672409, (long)transactionStatusEnumeration.code);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        TLVHandler tLVHandler2 = new TLVHandler();
        try {
            object = this.application.getDataContainerTransaction().getAuthorisationApprovalCode();
            if (object != null && !((String)object).isEmpty()) {
                while (((String)object).length() < 6) {
                    object = String.valueOf(object) + ' ';
                }
                tLVHandler2.add("89", UtilsYP.devHexa(((String)object).getBytes()));
            }
            if (string2 != null && string2.length() >= 2) {
                tLVHandler2.add("8A", UtilsYP.devHexa(string2.substring(string2.length() - 2).getBytes()));
            }
            if ((string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerAuthenticationData"))) != null && !string.isEmpty()) {
                tLVHandler2.add("91", string);
            }
            tLVHandler2.add("95", YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("tvr")));
        }
        catch (Exception exception) {
            this.application.logger(2, "fillAuthorizationDatas() " + exception);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(tLVHandler2.toString());
        if (this.posMateMessage && (string = ((PosmateMessageAdaptor)(object = new PosmateMessageAdaptor())).getGoOnlineMsg(this.application.getDataContainerTransaction())) != null) {
            tLVHandler.addASCII(14672756, string);
            this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PROCESSING_ERROR)) {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
    }

    protected void fillAdditionalCompletionTagsInAuthorizationResponse(TLVHandler tLVHandler) {
    }

    protected void fillCompletionDatas() {
        String string;
        YP_TCD_DC_Transaction yP_TCD_DC_Transaction = this.application.getDataContainerTransaction();
        TLVHandler tLVHandler = new TLVHandler();
        block5 : switch (YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())) {
            case DEBIT: 
            case QUASI_CASH: 
            case INITIAL_RESERVATION: 
            case DEBIT_DIFFERED: {
                switch (YP_TCD_DCC_Business.getCardHolderAuthentication(yP_TCD_DC_Transaction)) {
                    case SIGNATURE: 
                    case OFFLINE_PIN_AND_SIGNATURE: 
                    case ONLINE_PIN_AND_SIGNATURE: {
                        tLVHandler.add(14672131, 1L);
                        break block5;
                    }
                }
                tLVHandler.add(14672131, 0L);
                break;
            }
            case REVERSAL_DEBIT: 
            case CREDIT: 
            case REVERSAL_QUASI_CASH: 
            case REFUND_QUASI_CASH: {
                tLVHandler.add(14672131, 0L);
                break;
            }
            default: {
                tLVHandler.add(14672131, 0L);
                this.application.logger(2, "fillCompletionDatas() unknown trs type:" + (Object)((Object)YP_TCD_DCC_Business.getTransactionType(this.application.getDataContainerTransaction())));
            }
        }
        if (!this.application.getDataContainerTransaction().transactionPersisted) {
            this.application.logger(3, "fillCompletionDatas() TRS has not been persisted");
        } else {
            if (this.ticketType.isSet(TicketTypeEnumeration.CUSTOMER.getValue())) {
                try {
                    tLVHandler.addASCII(14672663, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 1).getBytes("UTF-8")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    tLVHandler.addASCII(14672663, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 1).getBytes()));
                }
            }
            if (this.ticketType.isSet(TicketTypeEnumeration.MERCHANT.getValue())) {
                try {
                    tLVHandler.addASCII(14672664, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 2).getBytes("UTF-8")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    tLVHandler.addASCII(14672664, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 2).getBytes()));
                }
            }
            if (this.ticketType.isSet(TicketTypeEnumeration.CUSTOMER_HANDWRITTEN.getValue())) {
                try {
                    tLVHandler.addASCII(14672755, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 3).getBytes("UTF-8")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    tLVHandler.addASCII(14672755, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 3).getBytes()));
                }
            }
            if (this.ticketType.isSet(TicketTypeEnumeration.SMS_TICKET.getValue())) {
                try {
                    tLVHandler.addASCII(-538738382, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 4).getBytes("UTF-8")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    tLVHandler.addASCII(-538738382, UtilsYP.base64Encode(this.dataContainer.getTransactionTicket(yP_TCD_DC_Transaction, false, 4).getBytes()));
                }
            }
        }
        tLVHandler.add(14672409, (long)YP_TCD_DCC_Business.getTransactionStatus((YP_TCD_DC_Transaction)yP_TCD_DC_Transaction).code);
        tLVHandler.add(14672642, yP_TCD_DC_Transaction.getExtendedTVR().toString());
        try {
            string = String.valueOf(this.dataContainer.currencyInterface.formatAmount(YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction), YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_TCD_DC_Transaction))) + ' ' + YP_TCD_DCC_Business.getTransactionCurrencyAlpha(yP_TCD_DC_Transaction);
            tLVHandler.addASCII(14672716, string);
        }
        catch (Exception exception) {
            this.application.logger(2, "fillCompletionDatas() formated amount " + exception);
        }
        string = yP_TCD_DC_Transaction.accountHandler.getScheme();
        if (string != null && !string.isEmpty()) {
            tLVHandler.addASCII(-538738387, string);
        }
        yP_TCD_DC_Transaction.commonHandler.setResponseEMVTags("");
        String string2 = yP_TCD_DC_Transaction.commonHandler.getResponseAppTags();
        yP_TCD_DC_Transaction.commonHandler.setResponseAppTags(String.valueOf(string2) + tLVHandler.toString());
        if (this.posMateMessage) {
            PosmateMessageAdaptor posmateMessageAdaptor = new PosmateMessageAdaptor();
            EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
            String string3 = entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_TAPPED ? posmateMessageAdaptor.getCompleteTransactionMsg(yP_TCD_DC_Transaction) : posmateMessageAdaptor.getProcessSwipedCardMsg(yP_TCD_DC_Transaction);
            if (string3 != null) {
                tLVHandler.addASCII(14672756, string3);
                yP_TCD_DC_Transaction.commonHandler.setResponseAppTags(String.valueOf(string2) + tLVHandler.toString());
            }
        }
    }

    protected void fillProcessNFCDatas() {
        String string;
        Object object;
        long l;
        long l2;
        int n;
        String string2;
        String string3;
        Object object2;
        String string4;
        Object object32;
        TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.application.getDataContainerTransaction());
        if (transactionStatusEnumeration != TransactionStatusEnumeration.REFUSED && transactionStatusEnumeration != TransactionStatusEnumeration.ERROR) {
            transactionStatusEnumeration = TransactionStatusEnumeration.ACCEPTED;
            for (Object object32 : this.application.getDataContainerTransaction().getExtendedTVR()) {
                switch (XPDE_Template.$SWITCH_TABLE$org$yp$utils$enums$ExtendedTVREnumeration()[((Enum)object32).ordinal()]) {
                    case 1: 
                    case 11: 
                    case 12: 
                    case 13: 
                    case 14: 
                    case 15: 
                    case 16: 
                    case 19: 
                    case 22: 
                    case 23: 
                    case 24: 
                    case 25: 
                    case 26: 
                    case 27: 
                    case 31: 
                    case 32: 
                    case 33: 
                    case 34: 
                    case 39: 
                    case 42: 
                    case 45: 
                    case 46: 
                    case 49: 
                    case 50: 
                    case 51: 
                    case 54: 
                    case 55: 
                    case 58: 
                    case 59: 
                    case 60: 
                    case 61: 
                    case 97: {
                        break;
                    }
                    case 35: 
                    case 47: {
                        transactionStatusEnumeration = TransactionStatusEnumeration.ERROR;
                        this.application.logger(3, "fillProcessNFCDatas() Status set to ERROR because of " + object32);
                        break;
                    }
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: 
                    case 7: 
                    case 8: 
                    case 9: 
                    case 10: 
                    case 17: 
                    case 18: 
                    case 20: 
                    case 21: 
                    case 28: 
                    case 29: 
                    case 30: 
                    case 36: 
                    case 37: 
                    case 38: 
                    case 40: 
                    case 41: 
                    case 43: 
                    case 44: 
                    case 48: 
                    case 52: 
                    case 53: 
                    case 56: 
                    case 57: {
                        transactionStatusEnumeration = TransactionStatusEnumeration.REFUSED;
                        this.application.logger(3, "fillProcessNFCDatas() Status set to REFUSED because of " + object32);
                        break;
                    }
                }
            }
            YP_TCD_DCC_Business.setTransactionStatus(this.application.getDataContainerTransaction(), transactionStatusEnumeration);
        }
        object32 = new TLVHandler();
        if (this.isAuthMandatory) {
            ((TLVHandler)object32).add(14672160, 0L);
        } else {
            ((TLVHandler)object32).add(14672160, 1L);
        }
        ((TLVHandler)object32).add(14672642, this.application.getDataContainerTransaction().getExtendedTVR().toString());
        String string5 = this.getNotForcableTVR();
        if (string5 != null) {
            ((TLVHandler)object32).add(14672697, string5);
        }
        if ((string4 = this.getNotForcableExtendedTVR()) != null) {
            ((TLVHandler)object32).add(14672698, string4);
        }
        try {
            object2 = new TLVHandler(this.application.getDataContainerTransaction().getAuthResponseBuffer());
            string3 = "";
            string2 = "";
            Iterator<TLV> iterator = ((TLVHandler)object2).iterator();
            while (iterator.hasNext()) {
                TLV tLV = iterator.next();
                block10 : switch (tLV.tag) {
                    case 187: {
                        ((TLVHandler)object32).add(14672646, UtilsYP.devHexa(tLV.value));
                        break;
                    }
                    case 188: {
                        if (tLV.value.length <= 1) break;
                        String string6 = UtilsYP.devHexa(new String(tLV.value, 1, tLV.value.length - 1, "ISO-8859-1").getBytes("UTF-8"));
                        switch (tLV.value[0]) {
                            case 53: 
                            case 54: {
                                if (!string3.isEmpty()) {
                                    string3 = String.valueOf(string3) + "0A";
                                }
                                string3 = String.valueOf(string3) + string6;
                                break block10;
                            }
                            case 56: 
                            case 57: {
                                if (!string2.isEmpty()) {
                                    string2 = String.valueOf(string2) + "0A";
                                }
                                string2 = String.valueOf(string2) + string6;
                                break block10;
                            }
                            case 50: 
                            case 51: 
                            case 66: 
                            case 67: 
                            case 98: 
                            case 99: {
                                if (!string2.isEmpty()) {
                                    string2 = String.valueOf(string2) + "0A";
                                }
                                string2 = String.valueOf(string2) + string6;
                                if (!string3.isEmpty()) {
                                    string3 = String.valueOf(string3) + "0A";
                                }
                                string3 = String.valueOf(string3) + string6;
                                break block10;
                            }
                        }
                    }
                }
            }
            ((TLVHandler)object32).add(14672647, string2);
            ((TLVHandler)object32).add(14672648, string3);
        }
        catch (Exception exception) {
            this.application.logger(2, "fillProcessNFCDatas() " + exception);
        }
        try {
            object2 = (String)this.application.getDataContainerTransaction().getTemporaryValue("issuerScriptBefore");
            if (object2 != null) {
                ((TLVHandler)object32).add(14672710, (String)object2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillProcessNFCDatas() " + exception);
        }
        try {
            object2 = (String)this.application.getDataContainerTransaction().getTemporaryValue("issuerScriptAfter");
            if (object2 != null) {
                ((TLVHandler)object32).add(14672711, (String)object2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillProcessNFCDatas() " + exception);
        }
        object2 = new TLVHandler();
        string3 = this.application.getDataContainerTransaction().getAuthResponseBuffer();
        if (string3 != null && !string3.isEmpty()) {
            ((TLVHandler)object2).add(14672709, string3);
        }
        if ((string2 = this.application.getDataContainerTransaction().getAuthorisationResponseCode()) != null && !string2.isEmpty()) {
            ((TLVHandler)object2).addASCII(14672734, string2);
        }
        if ((n = this.application.getDataContainerTransaction().commonHandler.getAuthorisationTime()) > 0) {
            ((TLVHandler)object2).add(-538803968, (long)n);
        }
        if ((l2 = System.currentTimeMillis() - this.application.getDataContainerTransaction().getTransactionProcessFather().getStartTime()) > 0L) {
            ((TLVHandler)object2).add(-538803967, l2);
        }
        if ((l = YP_TCD_DCC_Business.getTransactionSystemGMTTimeMS(this.application.getDataContainerTransaction())) > 0L) {
            ((TLVHandler)object2).add(-538803914, l);
        }
        try {
            int n2 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction());
            if (n2 > 0) {
                ((TLVHandler)object2).add(-538803964, (long)n2);
            }
        }
        catch (Exception exception) {
            this.application.logger(2, "fillProcessNFCDatas() pb with stan!!!: " + exception);
        }
        if (!((TLVHandler)object2).isEmpty()) {
            ((TLVHandler)object32).add(16769856, ((TLVHandler)object2).toString());
        }
        ((TLVHandler)object32).add(14672409, (long)transactionStatusEnumeration.code);
        String string7 = this.dataContainer.getEndUserLangageList(this.application.getDataContainerTransaction());
        if (string7 != null) {
            int n3 = 0;
            while (n3 < string7.length() - 1) {
                ((TLVHandler)object32).add(14672657, UtilsYP.devHexa(string7.substring(n3, n3 + 2).getBytes()));
                n3 += 2;
            }
        }
        ((TLVHandler)object32).add(14672162, 1L);
        String string8 = this.application.getDataContainerBusiness().getMerchantContract();
        if (string8 != null && !string8.isEmpty()) {
            ((TLVHandler)object32).add(14672713, UtilsYP.devHexa(string8.getBytes()));
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(((TLVHandler)object32).toString());
        TLVHandler tLVHandler = new TLVHandler();
        try {
            object = this.application.getDataContainerTransaction().getAuthorisationApprovalCode();
            if (object != null && !((String)object).isEmpty()) {
                while (((String)object).length() < 6) {
                    object = String.valueOf(object) + ' ';
                }
                tLVHandler.add("89", UtilsYP.devHexa(((String)object).getBytes()));
            }
            if (string2 != null && string2.length() >= 2) {
                tLVHandler.add("8A", UtilsYP.devHexa(string2.substring(string2.length() - 2).getBytes()));
            }
            if ((string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerAuthenticationData"))) != null && !string.isEmpty()) {
                tLVHandler.add("91", string);
            }
            tLVHandler.add("95", YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("tvr")));
        }
        catch (Exception exception) {
            this.application.logger(2, "fillProcessNFCDatas() " + exception);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        this.application.getDataContainerTransaction().commonHandler.setResponseEMVTags(tLVHandler.toString());
        if (this.posMateMessage && (string = ((PosmateMessageAdaptor)(object = new PosmateMessageAdaptor())).getGoOnlineMsg(this.application.getDataContainerTransaction())) != null) {
            ((TLVHandler)object32).addASCII(14672756, string);
            this.application.getDataContainerTransaction().commonHandler.setResponseAppTags(((TLVHandler)object32).toString());
        }
        if (this.application.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PROCESSING_ERROR)) {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.application.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
    }

    public void fillResponseDatas() {
        if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction) {
            this.fillOpenTransactionResponseDatas();
        } else if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalRiskManagement) {
            this.fillTerminalRiskManagementDatas();
        } else if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM) {
            this.fillOpenTransactionAndTRMResponseDatas();
        } else if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Authorization) {
            this.fillAuthorizationDatas();
        } else if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion) {
            this.fillCompletionDatas();
        } else if (this.subRequestType == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC) {
            this.fillProcessNFCDatas();
        } else {
            this.application.logger(2, "fillResponseDatas() unknown subRequestType " + (Object)((Object)this.subRequestType));
            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
            return;
        }
        this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.nextStepEvent);
    }

    public void getDataFromProtocol() {
        PosmateMessageAdaptor posmateMessageAdaptor;
        int n;
        int n2;
        Object object;
        Object object2;
        this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.nextStepEvent);
        String string = this.application.getDataContainerTransaction().commonHandler.getRequestAppTags();
        if (string == null || string.isEmpty()) {
            if (this.application.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction) {
                this.application.logger(2, "getDataFromProtocol() ");
                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                return;
            }
        } else {
            try {
                object2 = new TLVHandler(string);
                this.fillAppDatas((TLVHandler)object2);
            }
            catch (Exception exception) {
                this.application.logger(2, "getDataFromProtocol() apptags" + exception);
            }
        }
        if ((object2 = this.application.getDataContainerTransaction().commonHandler.getRequestEMVTags()) == null || ((String)object2).isEmpty()) {
            if (!(this.application.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction || this.application.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM || (object = this.application.getDataContainerTransaction().accountHandler.getAccountType()) != null && ((String)object).contentEquals("QRCode"))) {
                this.application.logger(2, "getDataFromProtocol() ");
                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                return;
            }
        } else {
            try {
                object = new TLVHandler((String)object2);
                this.fillEmvDatas((TLVHandler)object);
                if (this.myEvent.getEvent() == YP_ApplicationEvent.APPLICATIONEVENT.errorEvent) {
                    return;
                }
            }
            catch (Exception exception) {
                this.application.logger(2, "getDataFromProtocol() emvTags " + exception);
            }
        }
        if ((n2 = YP_TCD_DCC_Business.getTransactionNumber(this.application.getDataContainerTransaction())) == 0) {
            try {
                this.application.logger(2, "getDataFromProtocol() TLV Stan not received use 9F41 for compatibility!!!");
                YP_TCD_DCC_Business.setTransactionNumber(this.application.getDataContainerTransaction(), Integer.parseInt(YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("transactionSequenceCounter"))));
            }
            catch (Exception exception) {
                this.application.logger(2, "getDataFromProtocol() transactionSequenceCounter: " + exception);
            }
        }
        if ((n = (posmateMessageAdaptor = new PosmateMessageAdaptor()).checkPosMateMessage(this.application)) == -2) {
            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.MAC_ERROR);
            YP_TCD_DCC_Business.getExtendedResult(this.application.getDataContainerTransaction()).add(91);
        } else if (n < 0) {
            this.application.logger(2, "getDataFromProtocol() ");
            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
        }
        try {
            YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("tvr"));
        }
        catch (Exception exception) {}
    }

    protected void fillAdditionalEmvDatas() {
        String string;
        EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(this.application.getDataContainerTransaction());
        switch (entryModeEnumeration) {
            case ENTRY_MODE_TAPPED: 
            case ENTRY_MODE_EMV_CONTACTLESS: {
                break;
            }
            default: {
                return;
            }
        }
        try {
            string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerActionCodeOnline"));
            if (string == null || string.isEmpty()) {
                this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeOnline", "0000000000");
            }
        }
        catch (Exception exception) {
            this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeOnline", "0000000000");
        }
        try {
            string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerActionCodeDefault"));
            if (string == null || string.isEmpty()) {
                this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDefault", "0000000000");
            }
        }
        catch (Exception exception) {
            this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDefault", "0000000000");
        }
        try {
            string = YP_Row.getStringValue(this.application.getDataContainerTransaction().getExtensionValue("issuerActionCodeDenial"));
            if (string == null || string.isEmpty()) {
                this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDenial", "0000000000");
            }
        }
        catch (Exception exception) {
            this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDenial", "0000000000");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected boolean fillEmvDatas(TLVHandler tLVHandler) {
        try {
            Object object;
            Object object22;
            String string = null;
            String string2 = null;
            boolean bl = false;
            block98: for (Object object22 : tLVHandler) {
                block7 : switch (((TLV)object22).tag) {
                    case 79: {
                        break;
                    }
                    case 87: {
                        this.application.getDataContainerTransaction().accountHandler.setTrack2(UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 90: {
                        String string3 = UtilsYP.devHexa(((TLV)object22).value);
                        while (true) {
                            if (string3.length() <= 0 || string3.charAt(string3.length() - 1) != 'F') {
                                this.application.getDataContainerTransaction().accountHandler.setAccountIdentifier(string3);
                                bl = true;
                                this.application.getDataContainerTransaction().accountHandler.setMaskedAccountIdentifier(UtilsYP.maskPAN(string3));
                                break block7;
                            }
                            string3 = string3.substring(0, string3.length() - 1);
                        }
                    }
                    case 113: {
                        this.application.getDataContainerTransaction().setTemporaryValue("issuerScriptBefore", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 114: {
                        this.application.getDataContainerTransaction().setTemporaryValue("issuerScriptAfter", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 130: {
                        this.application.getDataContainerTransaction().setExtensionValue("appInterchangeProfile", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 132: {
                        List<AccountHandler.ADF> list;
                        try {
                            String string4;
                            list = this.application.getDataContainerTransaction().accountHandler.getADFList();
                            if (list == null || list.isEmpty() || (object = list.get(0)) == null || ((AccountHandler.ADF)object).aid == null || ((AccountHandler.ADF)object).aid.isEmpty() || (string4 = UtilsYP.devHexa(((TLV)object22).value)).contentEquals(((AccountHandler.ADF)object).aid) || this.application.getLogLevel() < 2) continue block98;
                            this.application.logger(2, "fillEmvDatas() : adf don't match " + ((AccountHandler.ADF)object).aid + " vs " + string4);
                        }
                        catch (Exception exception) {
                            if (this.application.getLogLevel() < 2) continue block98;
                            this.application.logger(2, "fillEmvDatas() :" + exception);
                        }
                        break;
                    }
                    case 135: {
                        List<AccountHandler.ADF> list;
                        try {
                            list = this.application.getDataContainerTransaction().accountHandler.getADFList();
                            if (list == null || list.isEmpty() || (object = list.get(0)) == null || ((AccountHandler.ADF)object).priorityIndicator == null || ((AccountHandler.ADF)object).priorityIndicator.isEmpty()) continue block98;
                            int n = Integer.parseInt(((AccountHandler.ADF)object).priorityIndicator);
                            int n2 = Integer.parseInt(UtilsYP.devHexa(((TLV)object22).value));
                            if (n2 == n || this.application.getLogLevel() < 2) continue block98;
                            this.application.logger(2, "fillEmvDatas() : priority Indicators don't match " + n + " vs " + n2);
                        }
                        catch (Exception exception) {
                            if (this.application.getLogLevel() < 2) continue block98;
                            this.application.logger(2, "fillEmvDatas() :" + exception);
                        }
                        break;
                    }
                    case 137: {
                        this.application.getDataContainerTransaction().setAuthorisationApprovalCode(new String(((TLV)object22).value));
                        break;
                    }
                    case 138: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerResponseCode", new String(((TLV)object22).value));
                        break;
                    }
                    case 140: {
                        break;
                    }
                    case 141: {
                        break;
                    }
                    case 142: {
                        this.application.getDataContainerTransaction().setExtensionValue("cvmList", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 143: {
                        break;
                    }
                    case 145: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerAuthenticationData", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 149: {
                        this.application.getDataContainerTransaction().setExtensionValue("tvr", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 154: {
                        string = UtilsYP.devHexa(((TLV)object22).value);
                        break;
                    }
                    case 155: {
                        this.application.getDataContainerTransaction().setExtensionValue("transactionStatusInformation", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 156: {
                        break;
                    }
                    case 24352: {
                        break;
                    }
                    case 24356: {
                        List<AccountHandler.ADF> list = UtilsYP.devHexa(((TLV)object22).value);
                        this.application.getDataContainerTransaction().accountHandler.setAccountExpirationDate((String)((Object)list));
                        break;
                    }
                    case 24357: {
                        object = UtilsYP.devHexa(((TLV)object22).value);
                        if (((String)object).length() == 4) {
                            this.application.getDataContainerTransaction().accountHandler.setAccountEffectiveDate(new Timestamp(UtilsYP.parseAAMMDate((String)object).getTimeInMillis()));
                            break;
                        }
                        if (((String)object).length() != 6) continue block98;
                        this.application.getDataContainerTransaction().accountHandler.setAccountEffectiveDate(new Timestamp(UtilsYP.parseAAMMJJDate((String)object).getTimeInMillis()));
                        break;
                    }
                    case 24360: {
                        int n = TLVHandler.getDCBInt(((TLV)object22).value);
                        if (n <= 0) continue block98;
                        this.application.getDataContainerTransaction().setExtensionValue("issuerCountryCode", n);
                        break;
                    }
                    case 24362: {
                        String string5 = UtilsYP.devHexa(((TLV)object22).value);
                        int n = this.application.getDataContainerTransaction().commonHandler.getTransactionCurrencyNumerical();
                        try {
                            if (n != 0) {
                                if (n == Integer.parseInt(string5)) continue block98;
                                this.application.logger(2, "fillEmvDatas() bad transaction currency code " + string5 + " vs current" + n);
                                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                                return false;
                            }
                            this.application.getDataContainerTransaction().commonHandler.setTransactionCurrencyNumerical(Integer.parseInt(string5));
                            continue block98;
                        }
                        catch (Exception exception) {
                            this.application.logger(2, "fillEmvDatas() 5F2A: Transaction currency code" + exception);
                            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                            return false;
                        }
                    }
                    case 24365: {
                        break;
                    }
                    case 24368: {
                        String string6 = UtilsYP.devHexa(((TLV)object22).value);
                        String string7 = this.application.getDataContainerTransaction().accountHandler.getCardServiceCode();
                        if (string7 != null && !string7.isEmpty() && string6.contentEquals(string7)) {
                            this.application.logger(2, "fillEmvDatas() bad service code ?" + string6 + " vs current " + string7);
                        }
                        if (string6 == null || string6.length() != 4) {
                            this.application.logger(2, "fillEmvDatas() bad service code ?" + string6);
                            break;
                        }
                        this.application.getDataContainerTransaction().accountHandler.setCardServiceCode(string6.substring(1));
                        break;
                    }
                    case 24372: {
                        this.application.getDataContainerTransaction().accountHandler.setCardSequenceNumber(UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40706: {
                        String string8 = UtilsYP.devHexa(((TLV)object22).value);
                        this.application.getDataContainerTransaction().setExtensionValue("emvAuthorizedAmount", string8);
                        long l = this.application.getDataContainerTransaction().commonHandler.getTransactionAmount();
                        try {
                            if (l != 0L) {
                                if (l == Long.parseLong(string8)) continue block98;
                                this.application.logger(2, "fillEmvDatas() bad amount ?" + string8 + " vs current " + l);
                                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                                return false;
                            }
                            this.application.getDataContainerTransaction().commonHandler.setTransactionAmount(Long.parseLong(string8));
                            continue block98;
                        }
                        catch (Exception exception) {
                            this.application.logger(2, "fillEmvDatas() 9F02: Amount Authorised (Numeric)" + exception);
                            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                            return false;
                        }
                    }
                    case 40707: {
                        break;
                    }
                    case 40710: {
                        String string9 = UtilsYP.devHexa(((TLV)object22).value);
                        this.application.getDataContainerTransaction().setExtensionValue("aid", string9);
                        YP_Row yP_Row = this.emvExtension.getAIDParameters(string9);
                        if (yP_Row == null) continue block98;
                        this.application.getDataContainerTransaction().setExtensionValue("terminalActionCodeDefault", yP_Row.getFieldStringValueByName("tacDefault"));
                        this.application.getDataContainerTransaction().setExtensionValue("terminalActionCodeDenial", yP_Row.getFieldStringValueByName("tacDenial"));
                        this.application.getDataContainerTransaction().setExtensionValue("terminalActionCodeOnline", yP_Row.getFieldStringValueByName("tacOnline"));
                        break;
                    }
                    case 40711: {
                        this.application.getDataContainerTransaction().setExtensionValue("appUsageControl", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40712: {
                        this.application.getDataContainerTransaction().setExtensionValue("applicationVersionNumberIcc", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40713: {
                        this.application.getDataContainerTransaction().setExtensionValue("applicationVersionNumber", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40717: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDefault", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40718: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeDenial", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40719: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerActionCodeOnline", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40720: {
                        this.application.getDataContainerTransaction().setExtensionValue("issuerAppData", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 80: {
                        this.application.getDataContainerTransaction().setExtensionValue("applicationLabel", ((TLV)object22).value);
                        break;
                    }
                    case 40721: {
                        break;
                    }
                    case 40722: {
                        Object object3;
                        int n = 1;
                        try {
                            object3 = this.application.getDataContainerTransaction().accountHandler.getADFList();
                            if (object3 != null && !object3.isEmpty()) {
                                Object object4 = (AccountHandler.ADF)object3.get(0);
                                if (((AccountHandler.ADF)object4).issuerCodeTableIndex != null && !((AccountHandler.ADF)object4).issuerCodeTableIndex.isEmpty()) {
                                    n = Integer.parseInt(((AccountHandler.ADF)object4).issuerCodeTableIndex);
                                }
                            }
                        }
                        catch (Exception exception) {
                            this.application.logger(2, "fillEmvDatas() :" + exception);
                        }
                        if (n != true) continue block98;
                        this.application.getDataContainerTransaction().setExtensionValue("applicationPreferredName", ((TLV)object22).value);
                        break;
                    }
                    case 40727: {
                        break;
                    }
                    case 40730: {
                        break;
                    }
                    case 40737: {
                        string2 = UtilsYP.devHexa(((TLV)object22).value);
                        break;
                    }
                    case 40742: {
                        this.application.getDataContainerTransaction().setExtensionValue("appCryptogram", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40743: {
                        this.application.getDataContainerTransaction().setExtensionValue("cryptoInformationData", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 220: 
                    case 40746: {
                        this.application.logger(2, "fillEmvDatas() " + ((TLV)object22).tag + " KernelID received: " + UtilsYP.devHexa(((TLV)object22).value));
                        this.application.getDataContainerTransaction().setExtensionValue("kernelID", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40755: {
                        this.application.getDataContainerTransaction().setExtensionValue("terminalCapabilities", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40756: {
                        this.application.getDataContainerTransaction().setExtensionValue("cvmResult", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40757: {
                        this.application.getDataContainerTransaction().setExtensionValue("terminalType", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40758: {
                        this.application.getDataContainerTransaction().setExtensionValue("appTransactionCounter", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40759: {
                        this.application.getDataContainerTransaction().setExtensionValue("unpredictableNumber", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40761: {
                        Object object3;
                        switch (object3 = UtilsYP.devHexa(((TLV)object22).value)) {
                            case "01": {
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_KEYED);
                                break block7;
                            }
                            case "02": {
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE);
                                break block7;
                            }
                            case "05": 
                            case "07": {
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS);
                                break block7;
                            }
                            case "32": {
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                                this.application.logger(3, "fillResponseDatas() TODO unknown value 32 !!!!!!");
                            }
                            case "09": {
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_ICC);
                                break block7;
                            }
                            case "80": {
                                this.application.logger(2, "fillEmvDatas() posEntryMode is set to 80 !!!");
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE_FALLBACK);
                                break block7;
                            }
                            case "91": {
                                YP_TCD_DCC_Business.setPaymentTechnology(this.application.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_TAPPED);
                                break block7;
                            }
                        }
                        this.application.logger(2, "fillEmvDatas() bad posEntryMode :" + (String)object3);
                        this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                        this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                        return false;
                    }
                    case 40768: {
                        break;
                    }
                    case 40769: {
                        String string10 = UtilsYP.devHexa(((TLV)object22).value);
                        if (this.application.getDataContainerTransaction().setExtensionValue("transactionSequenceCounter", string10) >= 0) continue block98;
                        this.application.logger(2, "fillEmvDatas() problem set tag 9F41 EMV extension");
                        break;
                    }
                    case 40780: {
                        break;
                    }
                    case 40782: {
                        try {
                            if (this.application.getLogLevel() < 5) continue block98;
                            this.application.logger(5, "fillEmvDatas() : Merchant name and location received: " + new String(((TLV)object22).value));
                        }
                        catch (Exception exception) {}
                        break;
                    }
                    case 40784: 
                    case 40797: {
                        String string11 = UtilsYP.devHexa(((TLV)object22).value);
                        if (string11.length() >= 16 || this.application.getDataContainerTransaction().setExtensionValue("availableOfflineSpendingAmount", string11) >= 0) continue block98;
                        this.application.logger(2, "CTCL fillEmvDatas() problem set tag 9F5D/9F50 EMV extension");
                        break;
                    }
                    case 40806: {
                        if (this.application.getDataContainerTransaction().setExtensionValue("terminalTransactionQualifiers", UtilsYP.devHexa(((TLV)object22).value)) < 0) {
                            this.application.logger(2, "fillEmvDatas() problem set tag 9F66 EMV extension");
                            break;
                        }
                        if (this.application.getLogLevel() < 5) continue block98;
                        this.application.logger(5, "9F66 TTQ TerminalTransationQualifer(): " + UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40809: {
                        if (this.application.getDataContainerTransaction().setExtensionValue("cardAuthenticationRelatedData", UtilsYP.devHexa(((TLV)object22).value)) >= 0) continue block98;
                        this.application.logger(2, "fillEmvDatas() problem set tag 9F69 cardAuthenticationRelatedData EMV extension");
                        break;
                    }
                    case 40810: {
                        break;
                    }
                    case 40812: {
                        if (this.application.getDataContainerTransaction().setExtensionValue("cardTransactionQualifier", UtilsYP.devHexa(((TLV)object22).value)) < 0) {
                            this.application.logger(2, "fillEmvDatas() problem set tag (CTQ) 9F6C EMV extension");
                            break;
                        }
                        if (this.application.getLogLevel() < 5) continue block98;
                        this.application.logger(5, "9F6C CTQ CardTransationQualifer(): " + UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    case 40828: {
                        if (this.application.getDataContainerTransaction().setExtensionValue("customerExclusiveData", UtilsYP.devHexa(((TLV)object22).value)) >= 0) continue block98;
                        this.application.logger(2, "fillEmvDatas() problem set tag 9F7C EMV extension");
                        break;
                    }
                    case 221: {
                        this.application.logger(2, "fillEmvDatas() DD nonAchievedReason received: " + UtilsYP.devHexa(((TLV)object22).value));
                        this.application.getDataContainerTransaction().setExtensionValue("nonAchievedReason", UtilsYP.devHexa(((TLV)object22).value));
                        break;
                    }
                    default: {
                        if (this.application.getLogLevel() < 3) continue block98;
                        this.application.logger(3, "fillEmvDatas() not Handled :" + Integer.toHexString(((TLV)object22).tag));
                    }
                }
            }
            this.fillAdditionalEmvDatas();
            if (string == null || string2 == null) {
                this.application.logger(2, "fillEmvDatas() Mandatory parameters missing");
                YP_TCD_DCC_Business.getExtendedResult(this.application.getDataContainerTransaction()).add(4);
                this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                return false;
            }
            object22 = String.valueOf(string) + string2;
            Timestamp timestamp = new Timestamp(UtilsYP.parseAAMMJJHHMMSSDateTime((String)object22).getTimeInMillis());
            long l = this.application.getDataContainerBusiness().timeInterface.getSystemGMTTime(timestamp.getTime()).getTimeInMillis();
            object = new Timestamp(this.application.getDataContainerBusiness().timeInterface.getAppliGMTTime(l).getTimeInMillis());
            YP_TCD_DCC_Business.setTransactionAppliLocalTime(this.application.getDataContainerTransaction(), timestamp);
            if (YP_TCD_DCC_Business.getTransactionSystemGMTTimeMS(this.application.getDataContainerTransaction()) == 0L) {
                YP_TCD_DCC_Business.setTransactionSystemGMTTimeMS(this.application.getDataContainerTransaction(), l);
            }
            YP_TCD_DCC_Business.setTransactionAppliGMTTime(this.application.getDataContainerTransaction(), (Timestamp)object);
            if (!bl) return true;
            this.application.getDataContainerTransaction().accountHandler.updateToken(this.application.getDataContainerTransaction().accountHandler.getAccountIdentifier(), this.application.getDataContainerTransaction().accountHandler.getAccountExpirationDate());
            return true;
        }
        catch (Exception exception) {
            this.application.logger(2, "fillEmvDatas() " + exception);
            YP_TCD_DCC_Business.getExtendedResult(this.application.getDataContainerTransaction()).add(4);
            this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
            this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
            return false;
        }
    }

    protected void fillAppDatas(TLVHandler tLVHandler) {
        block38: for (TLV tLV : tLVHandler) {
            switch (tLV.tag) {
                case 14672642: {
                    String string = UtilsYP.devHexa(tLV.value);
                    ExtendedTVR extendedTVR = new ExtendedTVR(string);
                    this.application.getDataContainerTransaction().setExtendedTVR(extendedTVR);
                    for (ExtendedTVREnumeration extendedTVREnumeration : extendedTVR) {
                        switch (extendedTVREnumeration) {
                            case TEST_CARD: {
                                YP_TCD_DCC_Business.setTestTransactionIndicator(this.application.getDataContainerTransaction(), 1);
                                break;
                            }
                        }
                    }
                    continue block38;
                }
                case 14672409: {
                    Object object;
                    int n = TLVHandler.getDCBInt(tLV.value);
                    boolean bl = false;
                    TransactionStatusEnumeration[] transactionStatusEnumerationArray = TransactionStatusEnumeration.values();
                    int n2 = transactionStatusEnumerationArray.length;
                    int n3 = 0;
                    while (n3 < n2) {
                        object = transactionStatusEnumerationArray[n3];
                        if (((TransactionStatusEnumeration)((Object)object)).code == n) {
                            this.application.getDataContainerTransaction().commonHandler.setTransactionStatus((TransactionStatusEnumeration)((Object)object));
                            bl = true;
                            break;
                        }
                        ++n3;
                    }
                    if (bl) continue block38;
                    this.application.logger(2, "fillAppDatas() unknown status :" + n);
                    YP_TCD_DCC_Business.getExtendedResult(this.application.getDataContainerTransaction()).add(4);
                    this.myEvent.setEvent(YP_ApplicationEvent.APPLICATIONEVENT.errorEvent);
                    this.application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PROCESSING_ERROR);
                    break;
                }
                case 14672658: {
                    Object object = UtilsYP.devHexa(tLV.value);
                    this.application.getDataContainerTransaction().setExtensionValue("issuerScriptResults", object);
                    break;
                }
                case 14672406: {
                    YP_TCD_DCC_Business.setCumulatedAmount(this.application.getDataContainerTransaction(), TLVHandler.getDCBLong(tLV.value));
                    break;
                }
                case 14672443: {
                    int n3 = TLVHandler.getDCBInt(tLV.value);
                    YP_TCD_DCC_Business.setReferenceTransactionNumber(this.application.getDataContainerTransaction(), n3);
                    break;
                }
                case 14672700: {
                    String string = new String(tLV.value);
                    YP_TCD_DCC_Business.setReferenceTransactionAppliLocalTime(this.application.getDataContainerTransaction(), Timestamp.valueOf(string));
                    break;
                }
                case 14672701: {
                    TransactionStatusEnumeration[] transactionStatusEnumerationArray = new String(tLV.value);
                    YP_TCD_DCC_Business.setReferenceMerchantTransactionTime(this.application.getDataContainerTransaction(), Timestamp.valueOf((String)transactionStatusEnumerationArray));
                    break;
                }
                case 14672702: {
                    String string = new String(tLV.value);
                    YP_TCD_DCC_Business.setReferenceTerminalTransactionTime(this.application.getDataContainerTransaction(), Timestamp.valueOf(string));
                    break;
                }
                case 14672703: {
                    String string = new String(tLV.value);
                    YP_TCD_DCC_Business.setReferenceMerchantTransactionIdentifier(this.application.getDataContainerTransaction(), string);
                    break;
                }
                case -538738399: {
                    String string = new String(tLV.value);
                    YP_TCD_DCC_Business.setMerchantTransactionIdentifier(this.application.getDataContainerTransaction(), string);
                    break;
                }
                case -538803934: {
                    YP_TCD_DCC_Business.setTransactionAmount(this.application.getDataContainerTransaction(), TLVHandler.getDCBLong(tLV.value));
                    break;
                }
                case 14672449: {
                    long l = TLVHandler.getDCBLong(tLV.value);
                    YP_TCD_DCC_Business.setConvertedAmount(this.application.getDataContainerTransaction(), l);
                    break;
                }
                case 14672450: {
                    int n = TLVHandler.getDCBInt(tLV.value);
                    YP_TCD_DCC_Business.setConvertedCurrencyNumerical(this.application.getDataContainerTransaction(), n);
                    break;
                }
                case 14672451: {
                    int n = TLVHandler.getDCBInt(tLV.value);
                    YP_TCD_DCC_Business.setConvertedAmountFraction(this.application.getDataContainerTransaction(), n);
                    break;
                }
                case 14672708: {
                    String string = new String(tLV.value);
                    YP_TCD_DCC_Business.setConvertedCurrencyAlpha(this.application.getDataContainerTransaction(), string);
                    break;
                }
                case 14672709: {
                    String string = UtilsYP.devHexa(tLV.value);
                    this.application.getDataContainerTransaction().setAuthResponseBuffer(string);
                    break;
                }
                case 14672734: {
                    String string = new String(tLV.value);
                    this.application.getDataContainerTransaction().setAuthorisationResponseCode(string);
                    break;
                }
                case -538803968: {
                    int n = TLVHandler.getDCBInt(tLV.value);
                    this.application.getDataContainerTransaction().commonHandler.setAuthorisationTime(n);
                    break;
                }
                case -538803967: {
                    int n = TLVHandler.getDCBInt(tLV.value);
                    int n4 = this.application.getDataContainerTransaction().commonHandler.getTransactionTime();
                    this.application.getDataContainerTransaction().commonHandler.setTransactionTime(n4 + n);
                    break;
                }
                case -538803914: {
                    long l = TLVHandler.getDCBLong(tLV.value);
                    this.application.getDataContainerTransaction().commonHandler.setTransactionSystemGMTTimeMS(l);
                    break;
                }
                case 16769892: {
                    this.decryptDUKPTTrack2(tLV);
                    break;
                }
                case -2064126: {
                    this.decryptDukptPinBlock(tLV);
                    break;
                }
                case 16769901: {
                    try {
                        TLVHandler tLVHandler2 = new TLVHandler(tLV.value);
                        TLV tLV2 = tLVHandler2.getTLV(14672497);
                        if (tLV2 == null) continue block38;
                        this.ticketType = new Bitmap(TLVHandler.getDCBLong(tLV2.value));
                    }
                    catch (Exception exception) {
                        this.application.logger(2, "fillAppDatas() " + exception);
                    }
                    continue block38;
                }
                case 14672756: {
                    this.posMateMessage = true;
                    this.application.getDataContainerTransaction().setMPosTrs(true);
                    break;
                }
                case -538803943: 
                case -538738413: 
                case -538738412: 
                case -538738411: 
                case -538738410: 
                case -538738409: 
                case -538738408: {
                    break;
                }
                case -538869478: 
                case -538803873: 
                case -538738383: 
                case 16769147: {
                    break;
                }
                case -538738381: 
                case -2064071: 
                case 16769880: {
                    break;
                }
                case -538803964: {
                    YP_TCD_DCC_Business.setTransactionNumber(this.application.getDataContainerTransaction(), Integer.parseInt(UtilsYP.devHexa(tLV.value)));
                    break;
                }
                case 40757: {
                    this.application.getDataContainerTransaction().setExtensionValue("terminalType", UtilsYP.devHexa(tLV.value));
                    break;
                }
                case -538738375: {
                    this.application.getDataContainerTransaction().setExtensionValue("acquirerTransmissionTime", tLV.value);
                    break;
                }
                case -538738355: {
                    break;
                }
                default: {
                    this.application.logger(3, "fillAppDatas() not Handled :" + Integer.toHexString(tLV.tag));
                }
            }
        }
    }

    protected int decryptDUKPTTrack2(TLV tLV) {
        String string;
        String string2;
        int n;
        String string3;
        block13: {
            string3 = this.application.getDataContainerTransaction().accountHandler.getTrack2();
            if (string3 != null && !string3.isEmpty()) {
                if (this.application.getLogLevel() >= 6) {
                    this.application.logger(6, "decryptDUKPTTrack2() already done");
                }
                return 0;
            }
            n = -1;
            string2 = null;
            string = null;
            try {
                TLVHandler tLVHandler = new TLVHandler(UtilsYP.devHexa(tLV.value));
                for (TLV tLV2 : tLVHandler) {
                    switch (tLV2.tag) {
                        case 14672737: {
                            string2 = UtilsYP.devHexa(tLV2.value);
                            break;
                        }
                        case 14672738: {
                            string = UtilsYP.devHexa(tLV2.value);
                            break;
                        }
                        case 14672483: {
                            n = TLVHandler.getDCBInt(tLV2.value);
                        }
                    }
                }
                if (string2 != null && string != null) break block13;
                return -1;
            }
            catch (Exception exception) {
                this.application.logger(2, "decryptDUKPTTrack2() DUKPT_TRACK2 " + exception);
                return -1;
            }
        }
        string3 = n <= 0 ? DUKPT.decryptData(string2, string) : DUKPT.decryptData(string2, string, n);
        if (string3 != null && string3.length() > 2 && string3.startsWith("3B")) {
            int n2 = string3.indexOf("3F");
            if (n2 > 0) {
                string3 = string3.substring(0, n2);
            }
            string3 = new String(UtilsYP.redHexa(string3));
        }
        this.application.getDataContainerTransaction().accountHandler.setTrack2(string3);
        return 1;
    }

    protected int decryptDukptPinBlock(TLV tLV) {
        Object object2;
        byte[] byArray;
        String string;
        block8: {
            string = null;
            byArray = null;
            try {
                TLVHandler tLVHandler = new TLVHandler(UtilsYP.devHexa(tLV.value));
                for (Object object2 : tLVHandler) {
                    switch (((TLV)object2).tag) {
                        case 14672737: {
                            string = UtilsYP.devHexa(((TLV)object2).value);
                            break;
                        }
                        case 14672738: {
                            byArray = ((TLV)object2).value;
                            break;
                        }
                    }
                }
                if (string != null && byArray != null) break block8;
                return -1;
            }
            catch (Exception exception) {
                this.application.logger(2, "decryptDukptPinBlock() " + exception);
                return -1;
            }
        }
        object2 = this.application.getPluginByName("CryptoManager");
        UtilsYP.devHexa((byte[])((YP_Object)object2).dealRequest(null, "decryptPIN", string, byArray));
        return 1;
    }

    public boolean isAuthMandatory() {
        return this.isAuthMandatory;
    }

    public void setAuthMandatory(boolean bl) {
        this.isAuthMandatory = bl;
    }

    public boolean isAuthRequested() {
        return this.isAuthRequested;
    }

    public void setAuthRequested(boolean bl) {
        this.isAuthRequested = bl;
    }

    public boolean isAutoCall() {
        return this.isAutoCall;
    }

    public void setAutoCall(boolean bl) {
        this.isAutoCall = bl;
    }

    public boolean isAdditionalAuthRequested() {
        return this.isAdditionalAuthRequested;
    }

    public void setAdditionalAuthRequested(boolean bl) {
        this.isAdditionalAuthRequested = bl;
    }

    public static void extractAppTags(YP_Application yP_Application) {
        try {
            String string = yP_Application.getDataContainerTransaction().commonHandler.getRequestAppTags();
            if (string != null && !string.isEmpty()) {
                YP_ApplicationEvent yP_ApplicationEvent = new YP_ApplicationEvent();
                YP_BCD_A_DCC_Template yP_BCD_A_DCC_Template = (YP_BCD_A_DCC_Template)yP_Application.getDataContainerBusiness();
                XPDE_Template xPDE_Template = new XPDE_Template(yP_Application, YP_TCD_DCC_Business.getTransactionType(yP_Application.getDataContainerTransaction()), yP_Application.getDataContainerTransaction().getSubRequestType(), yP_BCD_A_DCC_Template, yP_BCD_A_DCC_Template.emvExtension, yP_ApplicationEvent);
                TLVHandler tLVHandler = new TLVHandler(string);
                xPDE_Template.fillAppDatas(tLVHandler);
            }
        }
        catch (Exception exception) {
            yP_Application.logger(2, "extractAppTags() " + exception);
        }
    }
}

