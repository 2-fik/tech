/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.databaseevents;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.event.DAO_ManagementEvent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEvents;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCC_DataBaseEventsMGT
extends YP_TCD_DCC_DataBaseEvents {
    private YP_TCD_DesignAccesObject managementEvent;
    private Timestamp previousManagementEventTime;
    private List<YP_Row> previousManagementEventList;
    private YP_TCD_DCC_Technique dataContainerTechnique;
    private long nextPurgeTime = 0L;
    private final int NB_DAYS_OF_EVENTS = 10;
    private String currentDBUser = null;

    public YP_TCD_DCC_DataBaseEventsMGT(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
            this.managementEvent = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ManagementEvent.class, 0, 4, null);
            this.previousManagementEventTime = this.getLastManagementEventTime();
            this.previousManagementEventList = this.getNewerManagementEvents(this.previousManagementEventTime, null);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataBaseEventsMGT";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.managementEvent) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() managementEvent");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    public boolean isThereManagementChanges() {
        List<YP_Row> list;
        if (System.currentTimeMillis() >= this.nextPurgeTime) {
            this.deleteOldManagementEvents();
            this.nextPurgeTime = System.currentTimeMillis() + 86400000L;
        }
        return (list = this.getNewerManagementEvents(this.previousManagementEventTime, this.previousManagementEventList)) != null && !list.isEmpty();
    }

    public void reLoadManagement() {
        try {
            try {
                this.managementEvent.lock();
                List<YP_Row> list = this.getNewerManagementEvents(this.previousManagementEventTime, this.previousManagementEventList);
                if (list != null && list.size() > 0) {
                    this.previousManagementEventTime = (Timestamp)list.get(0).getFieldValueByName("timestamp");
                    this.previousManagementEventList = list;
                    int n = list.size() - 1;
                    while (n >= 0) {
                        YP_Row yP_Row = list.get(n);
                        String string = yP_Row.getFieldStringValueByName("DB_Name");
                        if (string == null) {
                            this.logger(2, "reLoadManagement() DB_Name not found...");
                        } else if ("management".compareTo(string) != 0) {
                            this.logger(2, "reLoadManagement() bad name:" + string);
                        } else {
                            this.dataContainerTechnique.dealParameterUpdate(yP_Row);
                        }
                        if (((Timestamp)yP_Row.getFieldValueByName("timestamp")).getTime() != this.previousManagementEventTime.getTime()) {
                            this.previousManagementEventList.remove(n);
                        }
                        --n;
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "reLoadManagement() " + exception);
                this.managementEvent.unlock();
            }
        }
        finally {
            this.managementEvent.unlock();
        }
    }

    private String getCurrentDBUser() {
        List<YP_Row> list;
        if (this.currentDBUser == null && (list = this.getDataBaseConnector().dealSelect(this.managementEvent, "SELECT null AS " + this.getDataBaseConnector().sql_Formater.sqlColumnName("timestamp") + ", 0 AS idManagementEvent, null AS DB_Name, null AS DB_Table, " + this.getDataBaseConnector().sql_Formater.sqlUser() + " AS " + this.getDataBaseConnector().sql_Formater.sqlColumnName("user") + ", 0 AS primaryKeyValue, null AS changeType")) != null && !list.isEmpty()) {
            this.currentDBUser = list.get(0).getFieldStringValueByName("user");
        }
        return this.currentDBUser;
    }

    private Timestamp getLastManagementEventTime() {
        Timestamp timestamp = null;
        List<YP_Row> list = this.getDataBaseConnector().dealSelect(this.managementEvent, "SELECT MAX(timestamp) AS " + this.getDataBaseConnector().sql_Formater.sqlColumnName("timestamp") + ", 0 AS idManagementEvent, null AS DB_Name, null AS DB_Table, null AS " + this.getDataBaseConnector().sql_Formater.sqlColumnName("user") + ", 0 AS primaryKeyValue, null AS changeType  FROM " + this.managementEvent.getFullTableName() + " WHERE DB_Name = " + this.getDataBaseConnector().sql_Formater.sqlValue("management") + " AND " + this.getDataBaseConnector().sql_Formater.sqlColumnName("user") + " <> " + this.getDataBaseConnector().sql_Formater.sqlValue(this.getCurrentDBUser()));
        if (list != null && !list.isEmpty()) {
            timestamp = (Timestamp)list.get(0).getFieldValueByName("timestamp");
        }
        if (timestamp == null) {
            timestamp = new Timestamp(0L);
        }
        return timestamp;
    }

    private List<YP_Row> getNewerManagementEvents(Timestamp timestamp, List<YP_Row> list) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.managementEvent);
        yP_ComplexGabarit.set("DB_Name", YP_ComplexGabarit.OPERATOR.EQUAL, "management");
        if (UtilsYP.getInstanceRole() == 1) {
            yP_ComplexGabarit.set("user", YP_ComplexGabarit.OPERATOR.DIFFERENT, this.getCurrentDBUser());
        }
        yP_ComplexGabarit.set("timestamp", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, timestamp);
        yP_ComplexGabarit.set(this.managementEvent.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list2 = this.managementEvent.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null) {
            block0: for (YP_Row yP_Row : list) {
                int n = 0;
                while (n < list2.size()) {
                    YP_Row yP_Row2 = list2.get(n);
                    if (yP_Row2.getPrimaryKey() == yP_Row.getPrimaryKey()) {
                        list2.remove(n);
                        continue block0;
                    }
                    ++n;
                }
            }
        }
        return list2;
    }

    private int deleteOldManagementEvents() {
        if (UtilsYP.getInstanceRole() != 1) {
            return 0;
        }
        try {
            this.managementEvent.lock();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.managementEvent);
            Calendar calendar = UtilsYP.getCalendar(System.currentTimeMillis());
            calendar.add(5, -10);
            Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
            yP_ComplexGabarit.set("timestamp", YP_ComplexGabarit.OPERATOR.LESS, timestamp);
            int n = this.managementEvent.deleteRowsSuchAs(yP_ComplexGabarit);
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "deleteOldManagementEvents() " + exception);
            return -1;
        }
        finally {
            this.managementEvent.unlock();
        }
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

