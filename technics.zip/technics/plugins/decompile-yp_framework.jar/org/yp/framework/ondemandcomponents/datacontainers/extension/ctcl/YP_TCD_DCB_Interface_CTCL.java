/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;

public interface YP_TCD_DCB_Interface_CTCL
extends YP_TCD_DCB_Interface_EMV {
    public long getCTCLChecksum();

    public YP_TCD_DesignAccesObject getCTCLTable();

    public YP_TCD_DesignAccesObject getDRLTable();

    public YP_TCD_DesignAccesObject getProductListTable();

    public String getForbiddenProduct(String var1);

    public List<YP_Row> getAIDKIDList();

    public List<YP_Row> getAIDKIDAmountList(String var1);

    public YP_Row getAIDKIDAmountRow(String var1, String var2, String var3);

    public YP_Row getProgramIDKIDDrlRow(String var1, String var2, String var3);

    public List<YP_Row> getDynamicReaderLimitsList();

    public List<String> getKIDList();

    public List<YP_Row> getAIDKIDList(String var1);

    public void setActive(boolean var1);

    public boolean isActive();
}

