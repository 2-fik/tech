/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.extendedapplication;

public interface YP_Interface_StateMachine {
    public int openTransactionForClosingPaymentStep();

    public int yp_ClosingPaymentStep();

    public int yp_ComplementaryPaymentStep();

    public int yp_ComplementaryRefundStep();

    public int yp_ReversalStep();

    public int yp_DebitStep();

    public int yp_RefundStep();

    public int openTransactionStep();

    public int terminalRiskManagementStepForDebit();

    public int terminalRiskManagementStepForCredit();

    public int terminalRiskManagementStepForReversal();

    public int openTransactionAndTRMStepForDebit();

    public int openTransactionAndTRMStepForCredit();

    public int openTransactionAndTRMStepForReversal();

    public int authorizationStep();

    public int authorizationStepForReversal();

    public int authorizationStepForRefund();

    public int completionStep();

    public int completionRefundReversalStep();

    public int processNFCStep();

    public int processNFCStepForCredit();

    public int processNFCStepForReversal();

    public int logger(int var1, String var2);
}

