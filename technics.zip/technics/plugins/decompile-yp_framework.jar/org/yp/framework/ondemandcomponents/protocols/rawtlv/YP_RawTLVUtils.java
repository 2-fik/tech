/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.rawtlv;

import java.io.UnsupportedEncodingException;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.protocols.rawtlv.YP_RawTLVException;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.rawtlv.RawTLVLengthType;
import org.yp.xml.jaxb.rawtlv.RawTLVMessage;

public class YP_RawTLVUtils {
    public static final char ISOTrackStx = '%';
    public static final char ISOTrackFormatCode = 'B';
    public static final char ISOTrackSeparator = '^';
    public static final char ISOTrackEtx = '?';
    private final YP_Object father;
    private String myTag;
    private int myFormatedLength;
    private String myValue;
    private FieldFormat myFieldFormat;
    private DataFormat myDataFormat;
    private byte[] myFormatedData;
    private byte[] myValueFromTLV;
    private int myParsingIndex;
    private int lengthOfTag;
    private int lengthOfLength;
    private int lengthOfFieldLength;
    public RawTLVMessage myRawTLVMessage;
    private int myEndTlvIndex;

    public static DataFormat getMyDataFormat(String string) {
        if (string == null) {
            return null;
        }
        switch (string) {
            case "RawTLVAlpha": {
                return DataFormat.ALPHA;
            }
            case "RawTLVNum": {
                return DataFormat.NUMERIC;
            }
            case "RawTLVAlphaNum": {
                return DataFormat.ALPHANUM;
            }
        }
        return DataFormat.NUMERIC;
    }

    public static FieldFormat getMyFieldFormat(RawTLVLengthType rawTLVLengthType) {
        return YP_RawTLVUtils.getMyFieldFormat(rawTLVLengthType.name());
    }

    private static FieldFormat getMyFieldFormat(String string) {
        switch (string) {
            case "TTTLLLLV_C": {
                return FieldFormat.TTTLLLLV_c;
            }
            case "TTTTLLLLV_C": {
                return FieldFormat.TTTTLLLLV_c;
            }
        }
        String string2 = string.toUpperCase();
        if (!string2.contentEquals(string)) {
            return YP_RawTLVUtils.getMyFieldFormat(string2);
        }
        return FieldFormat.TTTLLLLV_c;
    }

    public YP_RawTLVUtils(YP_Object yP_Object, FieldFormat fieldFormat, DataFormat dataFormat, DataFormat dataFormat2, int n) {
        this.father = yP_Object;
        this.YP_SetFormat(fieldFormat, dataFormat, dataFormat2, n);
        this.myEndTlvIndex = -1;
    }

    public YP_RawTLVUtils(YP_Object yP_Object) {
        this.father = yP_Object;
    }

    public void YP_SetFieldFormat(DataFormat dataFormat) {
        this.myDataFormat = dataFormat;
    }

    public final void YP_SetFormat(FieldFormat fieldFormat, DataFormat dataFormat, DataFormat dataFormat2, int n) {
        this.myFieldFormat = fieldFormat;
        switch (this.myFieldFormat) {
            case TTTLLLLV_c: {
                this.lengthOfTag = 3;
                this.lengthOfLength = 4;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case TTTTLLLLV_c: {
                this.lengthOfLength = 4;
                this.lengthOfTag = 4;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            default: {
                this.father.logger(2, "YP_SetFormat() Unknown format");
                return;
            }
        }
        this.YP_SetFieldFormat(dataFormat);
    }

    public void YP_SetTag(String string) {
        if (string != null && string.length() != 0) {
            this.myTag = string;
        }
    }

    public String YP_GetTag() {
        return this.myTag;
    }

    public void setValue(String string) {
        if (string != null && string.length() != 0) {
            this.myValue = string;
        }
    }

    public String getValue() throws YP_RawTLVException {
        return this.myValue;
    }

    public void YP_ResetFormatedTLV() {
        this.myFormatedData = new byte[0];
    }

    public void YP_SetFormatedTLV(byte[] byArray) {
        if (byArray != null && byArray.length != 0) {
            this.myFormatedData = byArray;
        }
    }

    public byte[] YP_GetFormatedData() {
        return this.myFormatedData;
    }

    public byte[] YP_GetValueFromTLV() {
        return this.myValueFromTLV;
    }

    public int YP_GetFormatedLength() {
        return this.myFormatedLength;
    }

    public int YP_FormatData() throws YP_RawTLVException {
        if (!this.isDataFormatValid()) {
            this.father.logger(2, "YP_FormatData() data format not valid");
            throw new YP_RawTLVException(YP_RawTLVException.ErrorType.syntaxError, null, null, null);
        }
        switch (this.myFieldFormat) {
            case TTTLLLLV_c: 
            case TTTTLLLLV_c: {
                this.YP_Set_TLV_c();
                return 1;
            }
        }
        this.father.logger(2, "YP_FormatData() unknown format:" + (Object)((Object)this.myFieldFormat));
        return -1;
    }

    public int YP_FormatTLVData(byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            this.father.logger(2, "YP_FormatTLVData() null or empty");
            return -1;
        }
        switch (this.myFieldFormat) {
            case TTTLLLLV_c: 
            case TTTTLLLLV_c: {
                this.YP_Set_TLV_c(byArray);
                return 1;
            }
        }
        this.father.logger(2, "YP_FormatTLVData() bad field format " + (Object)((Object)this.myFieldFormat));
        return 0;
    }

    public int YP_ParseData(boolean bl) throws YP_RawTLVException {
        if (bl) {
            this.myParsingIndex = 0;
        }
        if (this.myParsingIndex >= this.myFormatedData.length) {
            return 0;
        }
        switch (this.myFieldFormat) {
            case TTTLLLLV_c: 
            case TTTTLLLLV_c: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    this.myEndTlvIndex = this.myParsingIndex + this.ConvertByteToDecimal(byArray);
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                if (this.YP_Get_TLV_c() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_TLV_c error ");
                return -1;
            }
            default: {
                this.father.logger(2, "YP_ParseData() bad field format " + (Object)((Object)this.myFieldFormat));
                return -1;
            }
        }
        if (!this.isDataFormatValid()) {
            this.father.logger(2, "YP_ParseData() data format not valid");
            throw new YP_RawTLVException(YP_RawTLVException.ErrorType.syntaxError, null, null, null);
        }
        return 1;
    }

    public static boolean YP_IsNumeric(String string) {
        if (string == null) {
            return false;
        }
        int n = string.length();
        if (n == 0) {
            return false;
        }
        int n2 = 0;
        while (n2 < n) {
            char c = string.charAt(n2);
            if (c < '0' || c > '9') {
                return false;
            }
            ++n2;
        }
        return true;
    }

    public static boolean YP_IsAlpha(String string) {
        int n = 0;
        while (n < string.length()) {
            if (!Character.isLetter(string.charAt(n))) {
                return false;
            }
            ++n;
        }
        return true;
    }

    public static boolean YP_IsNumericOrAlpha(String string) {
        int n = 0;
        while (n < string.length()) {
            if (!Character.isLetterOrDigit(string.charAt(n))) {
                return false;
            }
            ++n;
        }
        return true;
    }

    public boolean isDataFormatValid() {
        switch (this.myDataFormat) {
            case NUMERIC: {
                return YP_RawTLVUtils.YP_IsNumeric(this.myValue);
            }
            case ALPHA: {
                return YP_RawTLVUtils.YP_IsAlpha(this.myValue);
            }
            case ALPHANUM: {
                return YP_RawTLVUtils.YP_IsNumericOrAlpha(this.myValue);
            }
        }
        this.father.logger(2, "isDataFormatValid() unknown format" + (Object)((Object)this.myDataFormat));
        return false;
    }

    public static StringBuilder YP_FormatPaddingTag(int n, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = n - string.length();
        int n3 = 0;
        while (n3 < n2) {
            stringBuilder.append('0');
            ++n3;
        }
        stringBuilder.append(string);
        return stringBuilder;
    }

    private static StringBuilder YP_FormatPadding(int n, int n2) {
        String string = Integer.toString(n2);
        StringBuilder stringBuilder = new StringBuilder(n);
        int n3 = n - string.length();
        int n4 = 0;
        while (n4 < n3) {
            stringBuilder.append('0');
            ++n4;
        }
        stringBuilder.append(string);
        return stringBuilder;
    }

    private static String YP_TrimLeadingZeroes(String string) {
        int n = 0;
        while (n < string.length()) {
            if (string.charAt(n) != '0' || string.charAt(n + 1) != '0') {
                return string.substring(n);
            }
            n += 2;
        }
        return null;
    }

    private byte[] YP_ExtractData(byte[] byArray, int n, int n2) {
        if (n < 0 || n2 < 0) {
            this.father.logger(2, "YP_ExtractData() bad indexes");
            return null;
        }
        if (n > n2) {
            this.father.logger(2, "YP_ExtractData() bad indexes");
            return null;
        }
        byte[] byArray2 = new byte[n2 - n];
        int n3 = 0;
        while (n3 < n2 - n) {
            byArray2[n3] = byArray[n3 + n];
            ++n3;
        }
        return byArray2;
    }

    private static byte[] ConvertDecimalToByte(int n, int n2) {
        Object object;
        String string = Integer.toHexString(n);
        int n3 = 2 * n2 - string.length();
        if (n3 > 0) {
            object = new StringBuilder("");
            int n4 = 0;
            while (n4 < n3) {
                ((StringBuilder)object).append('0');
                ++n4;
            }
            ((StringBuilder)object).append(string);
            string = ((StringBuilder)object).toString();
        }
        object = new byte[string.length() / 2];
        UtilsYP.redHexa((byte[])object, string, string.length() / 2);
        return object;
    }

    public int ConvertByteToDecimal(byte[] byArray) {
        return Integer.parseInt(UtilsYP.devHexa(byArray), 16);
    }

    public int ConvertByteDCBToDecimal(byte[] byArray) {
        return Integer.parseInt(UtilsYP.devHexa(byArray));
    }

    private byte[] YP_AppendFormatedData(byte[] byArray, byte[] byArray2, int n, boolean bl) {
        if (byArray == null) {
            byArray = new byte[n + byArray2.length];
            System.arraycopy(byArray2, 0, byArray, n, byArray2.length);
            if (n > 0) {
                byte[] byArray3 = bl ? String.format("%03d", byArray2.length).getBytes() : YP_RawTLVUtils.ConvertDecimalToByte(byArray2.length, n);
                System.arraycopy(byArray3, 0, byArray, 0, n);
            }
        } else {
            byte[] byArray4 = byArray;
            byArray = new byte[byArray4.length + byArray2.length];
            System.arraycopy(byArray4, 0, byArray, 0, byArray4.length);
            System.arraycopy(byArray2, 0, byArray, byArray4.length, byArray2.length);
            if (n > 0) {
                byte[] byArray5 = bl ? String.format("%03d", byArray4.length + byArray2.length - n).getBytes() : YP_RawTLVUtils.ConvertDecimalToByte(byArray4.length + byArray2.length - n, n);
                System.arraycopy(byArray5, 0, byArray, 0, n);
            }
        }
        return byArray;
    }

    private byte[] YP_AppendFormatedData(byte[] byArray, byte[] byArray2, int n) {
        return this.YP_AppendFormatedData(byArray, byArray2, n, false);
    }

    private byte[] YP_Set_TLV_c(byte[] byArray) {
        byte[] byArray2;
        StringBuilder stringBuilder = YP_RawTLVUtils.YP_FormatPaddingTag(this.lengthOfTag, this.myTag);
        StringBuilder stringBuilder2 = YP_RawTLVUtils.YP_FormatPadding(this.lengthOfLength, byArray.length);
        stringBuilder.append((CharSequence)stringBuilder2);
        try {
            byArray2 = stringBuilder.toString().getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray2 = stringBuilder.toString().getBytes();
        }
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray2, 0);
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_c() {
        StringBuilder stringBuilder = YP_RawTLVUtils.YP_FormatPaddingTag(this.lengthOfTag, this.myTag);
        StringBuilder stringBuilder2 = YP_RawTLVUtils.YP_FormatPadding(this.lengthOfLength, this.myValue.length());
        stringBuilder.append((CharSequence)stringBuilder2);
        stringBuilder.append(this.myValue);
        try {
            stringBuilder.toString().getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            stringBuilder.toString().getBytes();
        }
        this.myFormatedData = stringBuilder.toString().getBytes();
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private int YP_Get_TLV_c() {
        try {
            byte[] byArray = new byte[this.lengthOfTag];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfTag);
            this.myParsingIndex += this.lengthOfTag;
            this.myTag = new String(byArray, "ISO-8859-1");
            this.myTag = YP_RawTLVUtils.YP_TrimLeadingZeroes(this.myTag);
            byArray = new byte[this.lengthOfLength];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfLength);
            this.myParsingIndex += this.lengthOfLength;
            int n = Integer.parseInt(new String(byArray, "ISO-8859-1"));
            this.myValueFromTLV = new byte[n];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, this.myValueFromTLV, 0, n);
            this.myParsingIndex += n;
            this.myValue = new String(this.myValueFromTLV, "ISO-8859-1");
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "YP_Get_TLV_c() " + exception);
            return -1;
        }
    }

    public static enum DataFormat {
        NUMERIC,
        ALPHA,
        ALPHANUM;

    }

    public static enum FieldFormat {
        TTTLLLLV_c,
        TTTTLLLLV_c;

    }
}

