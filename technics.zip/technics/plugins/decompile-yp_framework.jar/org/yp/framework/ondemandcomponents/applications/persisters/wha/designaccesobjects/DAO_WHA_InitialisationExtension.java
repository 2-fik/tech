/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects;

public class DAO_WHA_InitialisationExtension {
    public byte[] webServiceURL = new byte[128];
    public byte[] method = new byte[12];
}

