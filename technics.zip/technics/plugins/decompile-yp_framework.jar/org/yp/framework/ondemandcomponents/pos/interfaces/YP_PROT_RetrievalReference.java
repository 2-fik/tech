/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import org.yp.utils.enums.ReservationStatusEnumeration;

public interface YP_PROT_RetrievalReference {
    public String getReservationReference();

    public int setReservationReference(String var1);

    public ReservationStatusEnumeration getReservationStatus();

    public int setReservationStatus(ReservationStatusEnumeration var1);
}

