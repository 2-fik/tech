/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.crypto.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.KeyStatusEnumeration;

public class DAO_CryptoKey
extends YP_Row {
    @PrimaryKey
    public long idCryptoKey = 0L;
    public byte[] keyLabel = new byte[100];
    public byte[] kcv = new byte[32];
    public byte[] idSM = new byte[120];
    public byte[] algorithm = new byte[200];
    public byte[] ownerProcess = new byte[200];
    public byte[] ownerPreferredName = new byte[200];
    public byte[] ownerBrandName = new byte[120];
    public long ownerMerchantId = 0L;
    public long ownerApplicationId = 0L;
    public byte[] ownerApplicationName = new byte[120];
    public byte[] properties = new byte[1024];
    public KeyStatusEnumeration keyStatus;
    public Timestamp effectiveDate = new Timestamp(0L);
    public Timestamp expirationDate = new Timestamp(0L);
}

