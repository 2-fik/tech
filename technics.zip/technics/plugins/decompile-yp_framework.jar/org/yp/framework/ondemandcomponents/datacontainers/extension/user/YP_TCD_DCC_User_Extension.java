/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.user;

import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_UserParameters;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCC_User_Extension
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Extension {
    private YP_TCD_DCC_Technique dataContainer;
    private YP_TCD_DAO_SQL_Transaction user;
    private YP_TCD_DesignAccesObject userArchive;
    private YP_TCD_DesignAccesObject userParameters;

    public YP_TCD_DCC_User_Extension(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Technique) {
            this.dataContainer = (YP_TCD_DCC_Technique)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.user = (YP_TCD_DAO_SQL_Transaction)this.dataContainer.newPluginByName("DAO_Transaction", DAO_User.class, 0, 0, null);
                this.userArchive = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Disk", DAO_User.class, 0, 8, null);
                this.userParameters = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Disk", DAO_UserParameters.class, 0, 0, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "initialize()" + exception);
            }
        }
        return 1;
    }

    public YP_Row getUserRowByID(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.user);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("lastGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.user.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getUserRowByID() unable to get userList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getUserRowByID() user not found :" + l);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 2) {
            this.logger(2, "getUserRowByID() too many users found :" + l);
        }
        return list.get(0);
    }

    public YP_Row getUserRowByLogin(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.user);
        yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("lastGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.user.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getUserRowByLogin() unable to get userList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getUserRowByLogin() user not found :" + string);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 2) {
            this.logger(2, "getUserRowByLogin() too many users found :" + string);
        }
        return list.get(0);
    }

    public List<YP_Row> getUserParameters(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userParameters);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        return this.userParameters.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.user) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() user");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() userParameters");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if ((this.user == null || clazz != this.user.getRowClass()) && this.userParameters != null) {
            this.userParameters.getRowClass();
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionUser";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public int archiveUser() {
        if (UtilsYP.getInstanceRole() != 1) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "archiveUser() only on master !!!");
            }
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" INNER JOIN\r\n");
        stringBuilder.append("( SELECT idUser AS idUserTMP, MAX(lastGMTTime) AS lastGMTTimeTMP\r\n");
        stringBuilder.append("FROM ");
        stringBuilder.append(this.user.getFullTableName());
        stringBuilder.append(" GROUP BY idUser\r\n");
        stringBuilder.append(") tmp\r\n");
        stringBuilder.append("ON idUser = idUserTMP\r\n");
        stringBuilder.append("AND lastGMTTime <> lastGMTTimeTMP");
        int n = this.user.archiveRowsSuchAs(this.userArchive, true, stringBuilder.toString());
        return n;
    }
}

