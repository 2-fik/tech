/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.Bitmap;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TicketFormatEnumeration;
import org.yp.utils.enums.TicketLineFeedEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;

public abstract class YP_Print {
    protected YP_TCD_DC_Transaction dataContainerTransaction;
    protected YP_TCD_DCC_EFT_Business dataContainer;
    protected TicketFormatEnumeration ticketFormat;
    protected TicketLineFeedEnumeration ticketLineFeed;
    protected boolean ticketNeedTrailingSpaces;
    protected int ticketTRSMaxColumnsNumber;
    protected int ticketReportMaxColumnsNumber;
    public static final int CUSTOMER_TICKET = 1;
    public static final int MERCHANT_TICKET = 2;
    public static final int CUSTOMER_HANDWRITTEN_TICKET = 3;
    public static final int CUSTOMER_SMS_TICKET = 4;
    public static final int MERCHANT_TICKET_MASKED = 5;
    private YP_Object internationalizationPlugin;
    private static final String TEMPLATE_MERCHANT_TRS_ID = "[MERCHANT_TRS_ID]";
    private static final String TEMPLATE_MERCHANT_PRIVATE_DATA = "[MERCHANT_PRIVATE_DATA]";

    public YP_Print(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        block19: {
            block20: {
                this.ticketFormat = TicketFormatEnumeration.HTML;
                this.ticketLineFeed = TicketLineFeedEnumeration.LF;
                this.ticketNeedTrailingSpaces = false;
                this.ticketTRSMaxColumnsNumber = 24;
                this.ticketReportMaxColumnsNumber = 40;
                this.dataContainer = (YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business;
                this.dataContainerTransaction = yP_TCD_DC_Transaction;
                try {
                    this.ticketFormat = YP_TCD_DCC_Business.getPaymentTechnology(this.dataContainerTransaction) == EntryModeEnumeration.ENTRY_MODE_MANUAL ? TicketFormatEnumeration.HTML : TicketFormatEnumeration.TEXT;
                }
                catch (Exception exception) {
                    this.ticketFormat = TicketFormatEnumeration.TEXT;
                }
                String string = yP_TCD_DC_Transaction.commonHandler.getPrintFormat();
                if (string == null) break block20;
                switch (string) {
                    case "TXT": {
                        this.ticketFormat = TicketFormatEnumeration.TEXT;
                        break;
                    }
                    case "HTML": {
                        this.ticketFormat = TicketFormatEnumeration.HTML;
                    }
                }
            }
            try {
                TLVHandler tLVHandler;
                TLV tLV;
                String string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (string != null && !string.isEmpty() && (tLV = (tLVHandler = new TLVHandler(string)).getTLV(16769901)) != null) {
                    TLV tLV2;
                    TLV tLV3;
                    TLV tLV4;
                    TLVHandler tLVHandler2 = new TLVHandler(tLV.value);
                    TLV tLV5 = tLVHandler2.getTLV(14672750);
                    if (tLV5 != null) {
                        this.ticketFormat = TicketFormatEnumeration.valueOf(new String(tLV5.value));
                    }
                    if ((tLV4 = tLVHandler2.getTLV(14672751)) != null) {
                        this.ticketLineFeed = TicketLineFeedEnumeration.valueOf(new String(tLV4.value));
                    }
                    if ((tLV3 = tLVHandler2.getTLV(14672496)) != null) {
                        this.ticketTRSMaxColumnsNumber = TLVHandler.getDCBInt(tLV3.value);
                        this.ticketReportMaxColumnsNumber = TLVHandler.getDCBInt(tLV3.value);
                    }
                    if ((tLV2 = tLVHandler2.getTLV(14672242)) != null) {
                        this.ticketNeedTrailingSpaces = TLVHandler.getBool(tLV2.value);
                    }
                    TLV tLV6 = tLVHandler2.getTLV(14672497);
                }
            }
            catch (Exception exception) {
                if (this.dataContainer == null) break block19;
                this.dataContainer.logger(2, "YP_Print() ", exception);
            }
        }
    }

    protected final void appendLineFeed(StringBuilder stringBuilder) {
        block0 : switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<br>");
                break;
            }
            default: {
                switch (this.ticketLineFeed) {
                    case CR: {
                        stringBuilder.append('\r');
                        break block0;
                    }
                    case CRLF: {
                        stringBuilder.append('\r');
                        stringBuilder.append('\n');
                        break block0;
                    }
                    case NONE: {
                        break block0;
                    }
                }
                stringBuilder.append('\n');
            }
        }
    }

    public final String reformatLineFeed(String string) {
        switch (this.ticketFormat) {
            case HTML: {
                return string.replace("\n", "<br>");
            }
        }
        switch (this.ticketLineFeed) {
            case CR: {
                return string.replace("\n", "\r");
            }
            case CRLF: {
                return string.replace("\n", "\r\n");
            }
            case NONE: {
                return string.replace("\n", "");
            }
        }
        return string;
    }

    protected final void startStrong(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<strong>");
                break;
            }
        }
    }

    protected final void stopStrong(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</strong>");
                break;
            }
        }
    }

    protected final void startCenter(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<p align=\"center\">");
                break;
            }
        }
    }

    protected final void stopCenter(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</p>");
                break;
            }
        }
    }

    protected void startTicket(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<pre>");
                break;
            }
        }
    }

    protected void stopTicket(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</pre>");
                break;
            }
        }
    }

    protected void startCenterH2(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<h2 align=\"center\">");
                break;
            }
        }
    }

    protected void stopCenterH2(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</h2>");
                break;
            }
        }
    }

    protected void startCenterH3(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<h3 align=\"center\">");
                break;
            }
        }
    }

    protected void stopCenterH3(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</h3>");
                break;
            }
        }
    }

    protected void startAlignLeft(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("<p align=\"left\">");
                break;
            }
        }
    }

    protected void stopAlignLeft(StringBuilder stringBuilder) {
        switch (this.ticketFormat) {
            case HTML: {
                stringBuilder.append("</p>");
                break;
            }
        }
    }

    public abstract String ticket(boolean var1, int var2);

    protected abstract String summaryReport(YP_TCD_PosProtocol.SUB_REQUEST_TYPE var1, List<YP_Row> var2);

    private long getTransactionSystemGMTTimeMSFromRequest() {
        TLV tLV;
        block5: {
            String string;
            block4: {
                try {
                    string = this.dataContainerTransaction.commonHandler.getRequestAppTags();
                    if (string != null && !string.isEmpty()) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    this.dataContainer.logger(2, "getTransactionSystemGMTTimeMSFromRequest() " + exception);
                    return -1L;
                }
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            tLV = tLVHandler.getTLV(-538803914);
            if (tLV != null) break block5;
            return -1L;
        }
        return TLVHandler.getDCBLong(tLV.value);
    }

    private int addCurrentTimeToResponse() {
        String string;
        block3: {
            try {
                string = this.dataContainerTransaction.commonHandler.getResponseAppTags();
                TLVHandler tLVHandler = new TLVHandler(string);
                if (tLVHandler.getTLV(-538803914) == null) break block3;
                return 0;
            }
            catch (Exception exception) {
                this.dataContainer.logger(2, "addCurrentTimeToResponse()  " + exception);
                return -1;
            }
        }
        TLVHandler tLVHandler = new TLVHandler();
        tLVHandler.add(-538803914, UtilsYP.getSystemGMTTime().getTimeInMillis());
        this.dataContainerTransaction.commonHandler.setResponseAppTags(String.valueOf(string) + tLVHandler.toString());
        return 1;
    }

    protected String summaryReport(YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE) {
        List<YP_Row> list;
        List<String> list2;
        String string = null;
        long l = -1L;
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainer.transaction);
        yP_ComplexGabarit.set("sessionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, -1);
        yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.UPLOADABLE);
        if (sUB_REQUEST_TYPE == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalSummaryReport) {
            string = this.dataContainerTransaction.getNLPA3_6();
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            l = this.getTransactionSystemGMTTimeMSFromRequest();
            if (l >= 0L) {
                yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.GREATER, l);
            }
            this.addCurrentTimeToResponse();
        }
        if ((list2 = this.dataContainer.transaction.getDistinctStringValueListSuchAs("transactionCurrencyAlpha", yP_ComplexGabarit)) != null && list2.size() > 0) {
            for (String object22 : list2) {
                YP_Row yP_Row;
                try {
                    yP_Row = this.dataContainerTransaction.getDataContainerBrand().getSession(this.dataContainer, -1);
                }
                catch (Exception exception) {
                    this.dataContainer.logger(2, "summaryReport() unable to get a new session " + exception);
                    return null;
                }
                if (yP_Row == null) {
                    this.dataContainer.logger(2, "summaryReport() unable to get a new session");
                    return null;
                }
                this.dataContainer.fillSession(yP_Row, -1, null, object22, string, l);
                arrayList.add(yP_Row);
            }
        }
        try {
            list = this.dataContainerTransaction.getDataContainerBrand().getSessionListToUpload(this.dataContainer.getContractIdentifier());
        }
        catch (Exception exception) {
            this.dataContainer.logger(2, "summaryReport() " + exception);
            return null;
        }
        if (list != null && !list.isEmpty()) {
            if (sUB_REQUEST_TYPE == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalSummaryReport) {
                for (Object yP_Row : list) {
                    int n = (Integer)((YP_Row)yP_Row).getFieldValueByName("sessionNumber");
                    String string2 = ((YP_Row)yP_Row).getFieldStringValueByName("currencyAlphabeticalCode");
                    try {
                        YP_Row yP_Row2 = this.dataContainerTransaction.getDataContainerBrand().getSession(this.dataContainer, -1);
                        if (yP_Row2 == null) {
                            this.dataContainer.logger(2, "summaryReport() unable to get a new session");
                            continue;
                        }
                        this.dataContainer.fillSession(yP_Row2, n, null, string2, string, l);
                        arrayList.add(yP_Row2);
                    }
                    catch (Exception exception) {
                        this.dataContainer.logger(2, "summaryReport() unable to get a new session " + exception);
                    }
                }
            } else {
                arrayList.addAll(list);
            }
        }
        if (arrayList.isEmpty()) {
            return "";
        }
        if (sUB_REQUEST_TYPE == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalSummaryReport) {
            boolean bl = false;
            for (YP_Row yP_Row : arrayList) {
                int n = (Integer)yP_Row.getFieldValueByName("nbTRS");
                if (n <= 0) continue;
                bl = true;
                break;
            }
            if (!bl) {
                return "";
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        list2 = YP_TCD_DesignAccesObject.getDistinctStringValueList(arrayList, "currencyAlphabeticalCode");
        if (list2 != null && list2.size() > 0) {
            for (String string3 : list2) {
                yP_ComplexGabarit = new YP_ComplexGabarit(((YP_Row)arrayList.get(0)).getFather());
                yP_ComplexGabarit.set("currencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                String string4 = this.summaryReport(sUB_REQUEST_TYPE, YP_TCD_DesignAccesObject.getRowListSuchAs(arrayList, yP_ComplexGabarit));
                stringBuilder.append(string4);
                this.appendLineFeed(stringBuilder);
            }
        }
        return stringBuilder.toString();
    }

    protected int ticketSubMerchantName(StringBuilder stringBuilder) {
        String string = this.dataContainerTransaction.contextHandler.getStoreIdentifier();
        if (string == null || string.isEmpty()) {
            return 0;
        }
        YP_Row yP_Row = this.dataContainerTransaction.getDataContainerBrand().getStore(this.dataContainer.getDataContainerMerchant().getIDMerchant(), string);
        if (yP_Row == null) {
            return 0;
        }
        String string2 = yP_Row.getFieldStringValueByName("storeTitle").replace("\\\n", "\n");
        String string3 = yP_Row.getFieldStringValueByName("storeCity").replace("\\\n", "\n");
        String string4 = yP_Row.getFieldStringValueByName("storeZIPCode").replace("\\\n", "\n");
        String string5 = yP_Row.getFieldStringValueByName("facilitatorAlias").replace("\\\n", "\n");
        String string6 = yP_Row.getFieldStringValueByName("storeLabel").replace("\\\n", "\n");
        if (string2.isEmpty() && string3.isEmpty() && string4.isEmpty() && string6.isEmpty() && string5.isEmpty()) {
            return 0;
        }
        String string7 = this.dataContainer.getParameter("PrintSubMerchantName", true);
        if (string7 != null && string7.contentEquals("0")) {
            return 0;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        if (!(string2.isEmpty() && string3.isEmpty() && string4.isEmpty())) {
            if (!string2.isEmpty()) {
                stringBuilder2.append(string2);
            }
            if (!string3.isEmpty() || !string4.isEmpty()) {
                if (!string2.isEmpty()) {
                    stringBuilder2.append("\\");
                }
                if (!string4.isEmpty()) {
                    stringBuilder2.append(string4);
                }
                if (!string3.isEmpty()) {
                    if (!string4.isEmpty()) {
                        stringBuilder2.append("\\");
                    }
                    stringBuilder2.append(string3);
                }
            }
        }
        if (!(string5.isEmpty() && string6.isEmpty() || string2 != null && !string2.isEmpty() && string6.contentEquals(string2))) {
            if (stringBuilder2.length() > 0) {
                this.appendLineFeed(stringBuilder2);
            }
            stringBuilder2.append(string5);
            if (!string6.isEmpty()) {
                stringBuilder2.append("\\");
                stringBuilder2.append(string6);
            }
        }
        stringBuilder.append(this.reformatLineFeed(stringBuilder2.toString()));
        return 1;
    }

    protected String additionalReport() {
        StringBuilder stringBuilder = new StringBuilder();
        this.ticketAppliLocalDateTime(stringBuilder);
        this.appendLineFeed(stringBuilder);
        this.ticketTypeTransactionAccepted(stringBuilder);
        this.appendLineFeed(stringBuilder);
        this.ticketForcedAllowed(stringBuilder);
        this.appendLineFeed(stringBuilder);
        this.ticketTimeOffset(stringBuilder);
        this.appendLineFeed(stringBuilder);
        this.additionalReportExtension(stringBuilder);
        return stringBuilder.toString();
    }

    protected int ticketTimeOffset(StringBuilder stringBuilder) {
        stringBuilder.append("D\u00e9calage actuel : ");
        long l = this.dataContainer.timeInterface.getGMTToAppliOffsetInMS(System.currentTimeMillis());
        if (l == 0L) {
            stringBuilder.append("Pas de d\u00e9calage");
        } else {
            long l2 = l / 1000L;
            int n = (int)l2 / 3600;
            int n2 = (int)l2 - n * 3600;
            int n3 = n2 / 60;
            stringBuilder.append(String.valueOf(n) + "h " + n3 + "m");
        }
        this.appendLineFeed(stringBuilder);
        return 1;
    }

    protected int ticketForcedAllowed(StringBuilder stringBuilder) {
        YP_Row yP_Row = this.dataContainer.applicationParameters.getUniqueRow();
        if (yP_Row == null) {
            return 0;
        }
        boolean bl = (Boolean)yP_Row.getFieldValueByName("isForcedAllowed");
        if (bl) {
            stringBuilder.append("Forcage autoris\u00e9");
        } else {
            stringBuilder.append("Forcage refus\u00e9");
        }
        this.appendLineFeed(stringBuilder);
        return 1;
    }

    protected int ticketTypeTransactionAccepted(StringBuilder stringBuilder) {
        Bitmap bitmap;
        block11: {
            try {
                bitmap = this.dataContainer.getTransactionTypeAllowed(this.dataContainerTransaction);
                if (bitmap != null) break block11;
                return -1;
            }
            catch (Exception exception) {
                this.dataContainer.logger(2, "ticketTypeTransactionAccepted() ", exception);
                return 0;
            }
        }
        stringBuilder.append("Transactions accept\u00e9es : ");
        this.appendLineFeed(stringBuilder);
        if (bitmap.isSet(TransactionTypeEnumeration.DEBIT.getValue())) {
            stringBuilder.append("D\u00e9bit");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.CREDIT.getValue())) {
            stringBuilder.append("Cr\u00e9dit");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.REVERSAL_DEBIT.getValue())) {
            stringBuilder.append("Annulation");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.DEBIT_DIFFERED.getValue())) {
            stringBuilder.append("D\u00e9bit - Diff\u00e9r\u00e9 de recouvrement");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.INFORMATION.getValue())) {
            stringBuilder.append("Demande de renseignement");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.INITIAL_RESERVATION.getValue())) {
            stringBuilder.append("Reservation");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT.getValue())) {
            stringBuilder.append("Facture complementaire");
            this.appendLineFeed(stringBuilder);
        }
        if (bitmap.isSet(TransactionTypeEnumeration.NO_SHOW.getValue())) {
            stringBuilder.append("Facture no show");
            this.appendLineFeed(stringBuilder);
        }
        return 1;
    }

    protected int ticketAppliLocalDateTime(StringBuilder stringBuilder) {
        try {
            Calendar calendar = this.dataContainer.timeInterface.getAppliLocalTime();
            int n = calendar.get(1);
            int n2 = calendar.get(2) + 1;
            int n3 = calendar.get(5);
            int n4 = calendar.get(11);
            int n5 = calendar.get(12);
            int n6 = calendar.get(13);
            stringBuilder.append("Le ");
            if (n3 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n3);
            stringBuilder.append('/');
            if (n2 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n2);
            stringBuilder.append('/');
            stringBuilder.append(n);
            stringBuilder.append(' ');
            stringBuilder.append("A ");
            if (n4 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n4);
            stringBuilder.append(':');
            if (n5 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n5);
            stringBuilder.append(':');
            if (n6 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n6);
            this.appendLineFeed(stringBuilder);
            return 1;
        }
        catch (Exception exception) {
            this.dataContainer.logger(2, "ticketAppliLocalDateTime() ", exception);
            return -1;
        }
    }

    public String getTicket() {
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.dataContainerTransaction.getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.dataContainer.logger(2, "getTicket() no sub request");
            return null;
        }
        switch (sUB_REQUEST_TYPE) {
            case AdditionalReport: {
                return this.additionalReport();
            }
        }
        this.dataContainer.logger(2, "getTicket() ticket not handle :" + (Object)((Object)sUB_REQUEST_TYPE));
        return null;
    }

    protected int additionalReportExtension(StringBuilder stringBuilder) {
        return 0;
    }

    protected String getLabelTranslated(String string, String string2) {
        try {
            Object object;
            String string3 = this.dataContainer.getCountryCode(this.dataContainerTransaction);
            if (string3 != null && string3.contentEquals("250")) {
                return string2;
            }
            if (this.internationalizationPlugin == null) {
                this.internationalizationPlugin = this.dataContainer.getPluginByName("Internationalization");
            }
            if (this.internationalizationPlugin == null) {
                this.dataContainer.logger(2, "getLabelTranslated() unable to retrieve Internationalization plugin!!!");
                return string2;
            }
            String string4 = this.dataContainerTransaction.userHandler.getUserPreferredLanguage();
            if (string4 == null && (object = this.dataContainerTransaction.getTerminalRow()) != null) {
                string4 = ((YP_Row)object).getFieldStringValueByName("terminalLanguage");
            }
            if (string4 == null || string4.isEmpty()) {
                string4 = "fr";
            }
            if ((object = (String)this.internationalizationPlugin.dealRequest(this.dataContainer, "getTranslatedText", string, string4)) == null || ((String)object).contentEquals(string)) {
                this.dataContainer.logger(2, "getLabelTranslated() Label missing: " + string + " in " + string4);
                return string2;
            }
            return object;
        }
        catch (Exception exception) {
            this.dataContainer.logger(2, "getLabelTranslated() ", exception);
            return string2;
        }
    }

    protected void appendTrailerToTransactionTicket(StringBuilder stringBuilder, int n) {
        try {
            String string = this.dataContainer.getDataContainerMerchant().getTrailerTrsTicketTemplate(n);
            if (string != null && !string.isEmpty()) {
                String string2 = this.dataContainerTransaction.commonHandler.getMerchantTransactionIdentifier();
                if (string2 == null) {
                    string2 = "";
                }
                string = string.replace(TEMPLATE_MERCHANT_TRS_ID, string2);
                String string3 = this.dataContainerTransaction.commonHandler.getMerchantPrivateData();
                if (string3 == null) {
                    string3 = "";
                }
                string = string.replace(TEMPLATE_MERCHANT_PRIVATE_DATA, string3);
            }
            if (string != null && !string.isEmpty()) {
                stringBuilder.append(string);
                this.appendLineFeed(stringBuilder);
            }
        }
        catch (Exception exception) {
            this.dataContainer.logger(2, "appendTrailerToTransactionTicket() ", exception);
        }
    }

    protected void appendWarningLogo(StringBuilder stringBuilder) {
        if (this.ticketFormat == TicketFormatEnumeration.HTML) {
            try {
                long l;
                YP_Row yP_Row;
                if (this.dataContainerTransaction != null && (yP_Row = this.dataContainerTransaction.getTerminalRow()) != null && ((l = ((Long)yP_Row.getFieldValueByName("idTerminalReference")).longValue()) == 30001L || l == 30002L)) {
                    return;
                }
            }
            catch (Exception exception) {}
            stringBuilder.append("<img style=\"vertical-align:middle; height:30px;\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAAyAgMAAAB0c/DrAAAACVBMVEUAABIAAAD///9znEI1AAAAAXRSTlMAQObYZgAAAAFiS0dEAIgFHUgAAAAJcEhZcwAACxMAAAsTAQCanBgAAACfSURBVCjPhdLBDcMwCAVQfPAI7OMROOD9VylgGxAqrS/JS9D/UgKAnUmQz94/OGiunnMN6okA3JPtSUPNSU2F0pOb5pqUiICcmgpZiQ0lRehNhXIj9KZCCRF6UyEf4ldqhvI2FepFeZsKNUJ5mwr5/W50jvUY38yaCuN724sz4nMYi8SP1gtefoiPZxhfj0Vpal6Zv4S0nNuWNY5OhAg+7uMqx8xgp5gAAAAASUVORK5CYII=\">");
        }
    }

    protected String compressedSMSTicket(StringBuilder stringBuilder) {
        String string = stringBuilder.toString();
        if (string.length() > 140 && (string = string.replace("############", "####")).length() > 140 && (string = string.replace("####", "##")).length() > 140 && (string = string.replace("C @", "C@")).length() > 140 && (string = string.replace(" EUR", "EUR")).length() > 140 && (string = string.replace("AUT:", "")).length() > 140) {
            string = string.replace("MASTERCARD", "MC");
        }
        return string;
    }
}

