/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.time;

import java.util.Calendar;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_Time
extends YP_TCD_DCB_Interface_Extension {
    public Calendar getAppliGMTTime();

    public Calendar getAppliGMTTime(long var1);

    public Calendar getAppliLocalTime();

    public Calendar getAppliLocalTime(long var1);

    public long getGMTToAppliOffsetInMS(long var1);

    public void resetSystemToGMTOffsetInMS();

    public void setSystemToGMTOffsetInMS(long var1);

    public long getSystemToGMTOffsetInMS();

    public Calendar getSystemGMTTime(long var1);
}

