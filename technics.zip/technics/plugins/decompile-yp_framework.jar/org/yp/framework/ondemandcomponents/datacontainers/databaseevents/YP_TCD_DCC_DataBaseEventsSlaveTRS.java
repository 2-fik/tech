/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.databaseevents;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.event.DAO_TransactionSlaveEvent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEvents;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCC_DataBaseEventsSlaveTRS
extends YP_TCD_DCC_DataBaseEvents {
    private YP_TCD_DesignAccesObject transactionSlaveEvent;

    public YP_TCD_DCC_DataBaseEventsSlaveTRS(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.transactionSlaveEvent = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_TransactionSlaveEvent.class, 0, 132, null);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataBaseEventsSlaveTRS";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.transactionSlaveEvent) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() transactionSlaveEvent");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    public boolean isThereSlaveTransaction() {
        if (UtilsYP.getInstanceRole() == 1 && UtilsYP.getTableCreationMode() == 0) {
            this.logger(4, "isThereSlaveTransaction() is not activated ");
            return false;
        }
        return this.transactionSlaveEvent.size() > 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int updateTransactions(YP_TCD_DataContainer yP_TCD_DataContainer) {
        if (UtilsYP.getInstanceRole() == 1 && UtilsYP.getTableCreationMode() == 0) {
            if (this.getLogLevel() < 5) return 0;
            this.logger(5, "updateTransactions() is not activated ");
            return 0;
        }
        try {
            int n = 0;
            List<YP_TCD_DesignAccesObject> list = yP_TCD_DataContainer.getDAOList();
            if (list == null) return n;
            if (list.isEmpty()) {
                return n;
            }
            ArrayList<YP_TCD_DAO_SQL_Transaction> arrayList = new ArrayList<YP_TCD_DAO_SQL_Transaction>();
            for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : list) {
                if (!(yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction)) continue;
                arrayList.add((YP_TCD_DAO_SQL_Transaction)yP_TCD_DesignAccesObject);
            }
            if (arrayList.isEmpty()) {
                return n;
            }
            for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : yP_TCD_DataContainer.getDataBaseConnectorList()) {
                boolean bl;
                if (yP_TCD_DataBaseConnector.getSiteIdentifier() == UtilsYP.getInstanceNumber()) continue;
                try {
                    bl = YP_TCD_DAO_SQL_Transaction.synchronizationNeeded(yP_TCD_DataBaseConnector, arrayList);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) return -1;
                    this.logger(2, "updateTransactions() pb during synchronizationNeeded");
                    return -1;
                }
                if (!bl) continue;
                for (YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction : arrayList) {
                    int n2 = yP_TCD_DAO_SQL_Transaction.synchronizeAllTransaction(yP_TCD_DataBaseConnector);
                    if (n2 < 0) {
                        if (this.getLogLevel() < 2) return -1;
                        this.logger(2, "updateTransactions() pb during synchronizeAllTransaction");
                        return -1;
                    }
                    if (n2 != 1) continue;
                    n = 1;
                }
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transactionSlaveEvent);
            yP_ComplexGabarit.set("DB_Name", YP_ComplexGabarit.OPERATOR.EQUAL, ((YP_TCD_DAO_SQL_Transaction)arrayList.get(0)).getSchemaName());
            try {
                this.transactionSlaveEvent.lock();
                this.transactionSlaveEvent.deleteRowsSuchAs(yP_ComplexGabarit);
                return n;
            }
            finally {
                this.transactionSlaveEvent.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateTransactions() " + exception);
            return -1;
        }
    }

    public void updateTransactions() {
        block11: {
            if (UtilsYP.getInstanceRole() == 1 && UtilsYP.getTableCreationMode() == 0) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "updateTransactions() is not activated ");
                }
                return;
            }
            try {
                this.transactionSlaveEvent.lock();
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transactionSlaveEvent);
                List<String> list = this.transactionSlaveEvent.getDistinctStringValueListSuchAs("DB_Name", yP_ComplexGabarit);
                if (list == null || list.size() <= 0) break block11;
                YP_TS_DataContainerManager yP_TS_DataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                for (String string : list) {
                    YP_TCD_DataContainer yP_TCD_DataContainer = null;
                    try {
                        yP_TCD_DataContainer = string.contentEquals("management") ? yP_TS_DataContainerManager.getDataContainerTechnique() : (YP_TCD_DataContainer)yP_TS_DataContainerManager.dealRequest(this, "getDataContainer", string);
                    }
                    catch (Exception exception) {
                        this.logger(2, "updateTransactions() " + exception);
                    }
                    if (yP_TCD_DataContainer == null) {
                        this.logger(2, "updateTransactions() ");
                        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(this.transactionSlaveEvent);
                        yP_ComplexGabarit2.set("DB_Name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                        try {
                            this.transactionSlaveEvent.deleteRowsSuchAs(yP_ComplexGabarit2);
                        }
                        catch (Exception exception) {
                            this.logger(2, "updateTransactions() " + exception);
                        }
                        continue;
                    }
                    this.updateTransactions(yP_TCD_DataContainer);
                }
            }
            finally {
                this.transactionSlaveEvent.unlock();
            }
        }
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

