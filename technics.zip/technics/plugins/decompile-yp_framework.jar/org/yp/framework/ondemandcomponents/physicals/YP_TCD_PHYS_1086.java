/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Date;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSessionContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_1086
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private static final String PROTOCOL = "SSL";
    private static final String KEYSTOREALGORITHM = "SunX509";
    private static final String TRUSTSTOREALGORITHM = "SunX509";
    private final String KEYSTORETYPE_JCEKS = "JCEKS";
    private final String TRUSTSTORETYPE_JCEKS = "JCEKS";
    private final String KEYSTORETYPE_JKS = "jks";
    private final String TRUSTSTORETYPE_JKS = "jks";
    private OutputStream outputStream = null;
    private InputStream inputStream = null;
    private PushbackInputStream pushbackInputStream = null;
    private SSLServerSocket serverSocket = null;
    private SSLSocket clientSocket = null;
    private SSLSocketFactory sslsocketfactory = null;
    private String ipServer = null;
    private int portServer = 0;
    private int connectionTimeoutMS = 3499;
    private String trustStorePath = null;
    private String trustStorePasswd = null;
    private String keyStorePath = null;
    private String keyStorePasswd = null;
    private String keyAlias = null;
    private String enabledCipherSuites = null;
    private String enabledProtocols = null;
    private String authentificationNeeded = null;
    private String sessionTimeOut = null;
    private String proxyType = null;
    private String proxyHost = null;
    private int proxyPort = 0;
    private String x25Adress = null;
    private final byte[] cleanMessage = new byte[1024];

    public YP_TCD_PHYS_1086(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof SSLSocket) {
            this.clientSocket = (SSLSocket)objectArray[0];
        }
    }

    private SSLContext getSSLContext(String string, String string2, String string3, String string4, String string5) {
        block23: {
            TrustManagerFactory trustManagerFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            TrustManager[] trustManagerArray = null;
            try {
                KeyStore keyStore;
                SSLContext sSLContext = SSLContext.getInstance(PROTOCOL);
                if (string != null && !string.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string), string2.toCharArray());
                    keyManagerFactory.init(keyStore, string2.toCharArray());
                }
                if (string4 != null && !string4.isEmpty()) {
                    trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string4.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string4), string5.toCharArray());
                    trustManagerFactory.init(keyStore);
                } else {
                    trustManagerArray = new X509TrustManager[]{new X509TrustManager(){

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }
                    }};
                }
                if (keyManagerFactory == null && trustManagerFactory == null) {
                    sSLContext.init(null, trustManagerArray, null);
                } else if (keyManagerFactory == null && trustManagerFactory != null) {
                    sSLContext.init(null, trustManagerFactory.getTrustManagers(), null);
                } else if (keyManagerFactory != null && trustManagerFactory == null) {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerArray, null);
                } else {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                }
                return sSLContext;
            }
            catch (FileNotFoundException fileNotFoundException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() FileNotFoundException:" + fileNotFoundException);
                }
            }
            catch (KeyStoreException keyStoreException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() KeyStoreException:" + keyStoreException);
                }
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() NoSuchAlgorithmException:" + noSuchAlgorithmException);
                }
            }
            catch (CertificateException certificateException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() CertificateException:" + certificateException);
                }
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() IOException:" + iOException);
                }
            }
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() UnrecoverableKeyException:" + unrecoverableKeyException);
                }
            }
            catch (KeyManagementException keyManagementException) {
                if (this.getLogLevel() < 2) break block23;
                this.logger(2, "getSSLContext() KeyManagementException:" + keyManagementException);
            }
        }
        return null;
    }

    private int enabledCipherSuites(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledCipherSuites() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledCipherSuites == null || this.enabledCipherSuites.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedCipherSuites() : ((SSLServerSocket)object).getSupportedCipherSuites();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledCipherSuites, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledCipherSuites() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledCipherSuites() not added " + string);
                }
                if (arrayList.size() <= 0) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledCipherSuites() bad cipher list ? " + this.enabledCipherSuites);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledCipherSuites() " + exception);
            }
        }
        return -1;
    }

    private int enabledProtocols(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledProtocols() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledProtocols == null || this.enabledProtocols.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedProtocols() : ((SSLServerSocket)object).getSupportedProtocols();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledProtocols, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledProtocols() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledProtocols() not added " + string);
                }
                if (arrayList.isEmpty()) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledProtocols() bad protocol list ? " + this.enabledProtocols);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledProtocols() " + exception);
            }
        }
        return -1;
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public int close() {
        this.outputStream = null;
        this.inputStream = null;
        this.pushbackInputStream = null;
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server Socket closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server socket close failed  :" + iOException);
                return -1;
            }
        }
        if (this.clientSocket != null) {
            try {
                this.clientSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Client Socket closed...");
                }
                this.clientSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Socket close error :" + iOException);
                this.clientSocket = null;
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "1086ConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int openServer() {
        this.logger(2, "openServer() not done");
        return -1;
    }

    @Override
    public Object waitConnection() {
        this.logger(2, "openServer() not done");
        return null;
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        int n4;
        int n5;
        long l = System.currentTimeMillis();
        byte[] byArray2 = new byte[4];
        int n6 = 0;
        do {
            if ((n5 = this.recvPrivate(byArray2, n6, byArray2.length - n6, n3)) >= 0) continue;
            this.logger(2, "recv() Receive error 1 " + n5);
            return -1;
        } while ((n6 += n5) != byArray2.length && !UtilsYP.isTimeout(l, n3));
        if (n6 == 0) {
            this.logger(3, "recv() Nothing received 1");
            return 0;
        }
        if (n6 != byArray2.length) {
            this.logger(2, "recv() Too few received " + n6);
            return -1;
        }
        if (byArray2[0] != 3 || byArray2[1] != 0) {
            this.logger(2, "recv() Bad message received");
            return -1;
        }
        n5 = (byArray2[2] & 0xFF) * 256 + (byArray2[3] & 0xFF);
        if ((n5 -= 4) > n2) {
            this.logger(2, "recv() Not enough space:" + n2 + " vs " + n5);
            return -1;
        }
        int n7 = 0;
        l = System.currentTimeMillis();
        do {
            if ((n4 = this.recvPrivate(byArray, n + n7, n5 - n7, n3)) >= 0) continue;
            this.logger(2, "recv() Receive error 2 " + n4);
            return -1;
        } while ((n7 += n4) != n5 && !UtilsYP.isTimeout(l, n3));
        if (n7 != n5) {
            this.logger(2, "recv() Message not completly received:" + n7 + " vs " + n5);
            return -1;
        }
        return n7;
    }

    private int recvPrivate(byte[] byArray, int n, int n2, int n3) {
        int n4 = 0;
        long l = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(n3);
        }
        catch (SocketException socketException) {
            this.logger(2, "recvPrivate() Timeout Initialisation error :" + socketException);
            return -1;
        }
        do {
            try {
                if (this.pushbackInputStream == null) {
                    n4 = this.inputStream.read(byArray, n, n2);
                    continue;
                }
                n4 = this.pushbackInputStream.read(byArray, n, n2);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "recvPrivate() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "recvPrivate() Read error..." + exception);
                return -1;
            }
        } while (n4 == 0 && !UtilsYP.isTimeout(l, n3));
        if (n4 > 0) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, UtilsYP.getFormattedLog(0, byArray, n, n4));
            } else if (this.getLogLevel() >= 4) {
                this.logger(4, "recvPrivate() bytes received :" + n4);
            }
        } else if (n4 == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "recvPrivate() nothing...");
            }
        } else if (this.getLogLevel() >= 5) {
            this.logger(5, "recvPrivate() error :" + n4);
        }
        if (n == 0 && n4 == 1 && n2 > 1) {
            int n5 = this.recvPrivate(byArray, 1, n2 - 1, 100);
            if (n5 <= 0) {
                return 1;
            }
            return n5 + 1;
        }
        return n4;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public int peek(byte[] var1_1, int var2_2, int var3_3, int var4_4) {
        if (!this.inputStream.markSupported()) {
            try {
                this.pushbackInputStream = new PushbackInputStream(this.inputStream, 100);
            }
            catch (Exception var5_5) {
                this.logger(3, "peek() mark is not supported !!!" + var5_5);
                return -1;
            }
        }
        var5_6 = 0;
        var6_7 = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(var4_4);
        }
        catch (SocketException var8_8) {
            this.logger(2, "peek() Timeout Initialisation error :" + var8_8);
            return -1;
        }
        do {
            try {
                if (this.pushbackInputStream == null) {
                    this.inputStream.mark(var3_3 + 1);
                    var5_6 = this.inputStream.read(var1_1, var2_2, var3_3);
                    this.inputStream.reset();
                    continue;
                }
                var5_6 = this.pushbackInputStream.read(var1_1, var2_2, var3_3);
                if (var5_6 <= 0) continue;
                this.pushbackInputStream.unread(var1_1, var2_2, var5_6);
                continue;
            }
            catch (SocketTimeoutException var8_9) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "peek() Read timeout" + var8_9);
                }
                return 0;
            }
            catch (SocketException var8_10) {
                var9_12 = new Throwable().getStackTrace();
                var10_13 = 0;
                ** while (var10_13 < var9_12.length)
            }
lbl-1000:
            // 1 sources

            {
                if (var9_12[var10_13].getMethodName().contentEquals("waitRequest")) {
                    this.logger(4, "peek() socket closed :" + var8_10);
                    return -1;
                }
                ++var10_13;
                continue;
            }
lbl44:
            // 1 sources

            this.logger(2, "peek() Read error..." + var8_10);
            return -1;
            catch (Exception var8_11) {
                this.logger(2, "peek() Read error..." + var8_11);
                return -1;
            }
        } while (var5_6 == 0 && !UtilsYP.isTimeout(var6_7, var4_4));
        if (var5_6 <= 0) {
            if (var5_6 == 0) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "peek() nothing...");
                }
            } else if (this.getLogLevel() >= 5) {
                this.logger(5, "peek() error :" + var5_6);
            }
        }
        return var5_6;
    }

    @Override
    public int clean(int n) {
        long l = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(n);
        }
        catch (SocketException socketException) {
            this.logger(2, "clean() Timeout Initialisation error :" + socketException);
            return -1;
        }
        do {
            try {
                int n2 = this.inputStream.read(this.cleanMessage);
                if (n2 > 0) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, UtilsYP.getFormattedLog(2, this.cleanMessage, 0, n2));
                        continue;
                    }
                    this.logger(4, "clean() bytes cleaned :" + n2);
                    continue;
                }
                if (n2 == 0) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "clean() nothing...");
                    continue;
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "clean() error :" + n2);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "clean() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "clean() Read error..." + exception);
                return -1;
            }
        } while (!UtilsYP.isTimeout(l, n));
        return 1;
    }

    @Override
    public int available() {
        try {
            return this.inputStream.available();
        }
        catch (Exception exception) {
            this.logger(2, "available() available error..." + exception);
            return -1;
        }
    }

    @Override
    public int send(byte[] byArray, int n) {
        return this.send(byArray, n, true);
    }

    private int send(byte[] byArray, int n, boolean bl) {
        try {
            byte[] byArray2;
            int n2;
            if (bl) {
                n2 = 4 + n;
                byArray2 = new byte[n2];
                byArray2[0] = 3;
                byArray2[1] = 0;
                byArray2[2] = (byte)((byte)(n2 / 256) & 0xFF);
                byArray2[3] = (byte)((byte)(n2 % 256) & 0xFF);
                int n3 = 0;
                while (n3 < n) {
                    byArray2[4 + n3] = byArray[n3];
                    ++n3;
                }
            } else {
                n2 = n;
                byArray2 = byArray;
            }
            this.outputStream.write(byArray2, 0, n2);
            this.outputStream.flush();
            if (this.getLogLevel() >= 6) {
                this.logger(6, UtilsYP.getFormattedLog(1, byArray2, 0, n2));
            } else {
                this.logger(4, "send() bytes sent :" + n2);
            }
            return n;
        }
        catch (IOException iOException) {
            this.logger(3, "send() Write error..." + iOException);
            return -1;
        }
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        try {
            SocketAddress socketAddress = this.clientSocket.getRemoteSocketAddress();
            String string = socketAddress.toString();
            int n = string.indexOf(":");
            string = string.substring(1, n);
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getIP() " + exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int openClient(Object ... objectArray) {
        try {
            if (objectArray == null) {
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            if (!(objectArray[0] instanceof YP_Row)) {
                this.logger(2, "openClient() bad parameters");
                return -1;
            }
            this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
            this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
            this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
            this.trustStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePath");
            this.trustStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePasswd");
            this.keyStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePath");
            this.keyStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePasswd");
            this.keyAlias = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyAlias");
            this.enabledCipherSuites = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledCipherSuites");
            this.enabledCipherSuites = this.enabledCipherSuites.trim();
            this.enabledProtocols = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledProtocols");
            this.enabledProtocols = this.enabledProtocols.trim();
            this.authentificationNeeded = ((YP_Row)objectArray[0]).getFieldStringValueByName("authentificationNeeded");
            this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
            SSLContext sSLContext = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd);
            this.sslsocketfactory = sSLContext.getSocketFactory();
            this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
            this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
            this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
            this.x25Adress = ((YP_Row)objectArray[0]).getExtensionValueAsString("x25Adress");
            if (this.ipServer == null || this.portServer == 0 || this.x25Adress == null || this.x25Adress.isEmpty() || this.sslsocketfactory == null) {
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            this.logger(4, "openClient() " + this.x25Adress + " via " + this.ipServer + ":" + this.portServer);
            if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
                this.logger(4, "openClient() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
                this.clientSocket = this.tunnelThroughProxy(this.sslsocketfactory, this.proxyType, this.proxyHost, this.proxyPort, this.ipServer, this.portServer);
                if (this.openClientInternal() == 1) {
                    return 1;
                }
                this.close();
            } else {
                InetAddress[] inetAddressArray;
                try {
                    inetAddressArray = InetAddress.getAllByName(this.ipServer);
                }
                catch (UnknownHostException unknownHostException) {
                    this.logger(2, "openClient() " + this.ipServer + " " + unknownHostException);
                    return -1;
                }
                if (inetAddressArray == null || inetAddressArray.length == 0) {
                    this.logger(2, "openClient() nothing found for " + this.ipServer);
                    return -1;
                }
                int n = 0;
                while (n < inetAddressArray.length) {
                    try {
                        this.clientSocket = (SSLSocket)this.sslsocketfactory.createSocket(inetAddressArray[n], this.portServer);
                        if (this.openClientInternal() == 1) {
                            return 1;
                        }
                        this.logger(3, "openClient() create socket failed for " + this.ipServer + ":" + this.portServer);
                    }
                    catch (Exception exception) {
                        this.logger(3, "openClient() create socket failed for " + this.ipServer + ":" + this.portServer + " " + exception);
                    }
                    this.close();
                    ++n;
                }
            }
            this.logger(2, "openClient() create socket failed for " + this.ipServer + ":" + this.portServer);
            return -1;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + "  " + exception);
            this.close();
            this.ipServer = null;
            this.clientSocket = null;
            this.portServer = 0;
            this.connectionTimeoutMS = 3499;
            this.sslsocketfactory = null;
            this.trustStorePath = null;
            this.trustStorePasswd = null;
            this.keyStorePath = null;
            this.keyStorePasswd = null;
            this.keyAlias = null;
            this.enabledCipherSuites = null;
            this.enabledProtocols = null;
            this.authentificationNeeded = null;
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return -1;
        }
    }

    private int openClientInternal() {
        this.enabledCipherSuites(this.clientSocket);
        this.enabledProtocols(this.clientSocket);
        try {
            int n = this.clientSocket.getSoTimeout();
            this.clientSocket.setSoTimeout(this.connectionTimeoutMS);
            this.clientSocket.startHandshake();
            this.clientSocket.setSoTimeout(n);
        }
        catch (Exception exception) {
            this.logger(2, "openClientInternal().startHandshake failed: " + exception);
            return -1;
        }
        SSLSession sSLSession = this.clientSocket.getSession();
        SSLSessionContext sSLSessionContext = sSLSession.getSessionContext();
        if (sSLSessionContext != null) {
            int n = 0;
            if (this.sessionTimeOut != null) {
                try {
                    n = Integer.parseInt(this.sessionTimeOut);
                }
                catch (Exception exception) {}
            }
            sSLSessionContext.setSessionTimeout(n);
            this.printSocketInfo(this.clientSocket);
        }
        try {
            X509Certificate[] x509CertificateArray;
            X509Certificate[] x509CertificateArray2 = x509CertificateArray = (X509Certificate[])this.clientSocket.getSession().getPeerCertificates();
            int n = x509CertificateArray.length;
            int n2 = 0;
            while (n2 < n) {
                X509Certificate x509Certificate = x509CertificateArray2[n2];
                x509Certificate.checkValidity();
                ++n2;
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClientInternal() " + exception);
            return -1;
        }
        try {
            this.outputStream = this.clientSocket.getOutputStream();
            this.inputStream = this.clientSocket.getInputStream();
        }
        catch (IOException iOException) {
            this.logger(2, "openClientInternal():" + iOException);
            return -1;
        }
        try {
            this.clientSocket.setSoTimeout(100);
        }
        catch (SocketException socketException) {
            this.logger(2, "openClientInternal():" + socketException);
            return -1;
        }
        if (this.connect1086(this.x25Adress) != 1) {
            return -1;
        }
        return 1;
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() not done");
        return null;
    }

    private void printSocketInfo(SSLSocket sSLSocket) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printSocketInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Socket class: ");
            stringBuilder.append(sSLSocket.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(sSLSocket.getInetAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote port = ");
            stringBuilder.append(sSLSocket.getPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local socket address = ");
            stringBuilder.append(sSLSocket.getLocalSocketAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local address = ");
            stringBuilder.append(sSLSocket.getLocalAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local port = ");
            stringBuilder.append(sSLSocket.getLocalPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Need client authentication = ");
            stringBuilder.append(sSLSocket.getNeedClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            SSLSession sSLSession = sSLSocket.getSession();
            stringBuilder.append("   Cipher suite = ");
            stringBuilder.append(sSLSession.getCipherSuite());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Protocol = ");
            stringBuilder.append(sSLSession.getProtocol());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Creation date = ");
            stringBuilder.append(new java.util.Date(sSLSession.getCreationTime()));
            try {
                Certificate[] certificateArray;
                Date date = new Date(System.currentTimeMillis() + 864000000L);
                Certificate[] certificateArray2 = certificateArray = sSLSession.getPeerCertificates();
                int n = certificateArray.length;
                int n2 = 0;
                while (n2 < n) {
                    Certificate certificate = certificateArray2[n2];
                    X509Certificate x509Certificate = (X509Certificate)certificate;
                    stringBuilder.append(UtilsYP.lineSeparator);
                    stringBuilder.append("   End of validity = ");
                    stringBuilder.append(x509Certificate.getNotAfter());
                    if (x509Certificate.getNotAfter().before(date)) {
                        this.logger(2, "printSocketInfo() Certicate for " + sSLSocket.getInetAddress().toString() + ":" + sSLSocket.getPort() + " will soon expire");
                    }
                    ++n2;
                }
            }
            catch (Exception exception) {}
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    private SSLSocket tunnelThroughProxy(SSLSocketFactory sSLSocketFactory, String string, String string2, int n, String string3, int n2) throws UnknownHostException, IOException {
        Socket socket;
        if (string == null || string.isEmpty()) {
            this.logger(2, "tunnelThroughProxy() tunnelType missing. Assuming HTTP");
            string = "HTTP";
        }
        if (string.equalsIgnoreCase("SOCKS")) {
            socket = new Socket(new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(string2, n)));
            socket.connect(new InetSocketAddress(string3, n2));
        } else if (string.equalsIgnoreCase("HTTP")) {
            socket = new Socket(string2, n);
            this.doTunnelHandshake(socket, string3, n2);
        } else {
            this.logger(2, "tunnelThroughProxy() unknown tunnelType " + string);
            throw new UnknownHostException("unknown tunnelType");
        }
        SSLSocket sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(socket, string3, n2, true);
        return sSLSocket;
    }

    private int connect1086(String string) {
        if (string.length() > 16) {
            this.logger(2, "connect1086() x25 adress too long " + string);
            return -1;
        }
        this.clean(1);
        byte[] byArray = new byte[49];
        byArray[0] = 1;
        byArray[2] = 3;
        int n = 0;
        while (n < string.length()) {
            byArray[3 + n] = (byte)string.charAt(n);
            ++n;
        }
        byArray[19] = (byte)string.length();
        byArray[25] = 1;
        byArray[41] = 4;
        if (this.send(byArray, byArray.length, false) > 0) {
            return 1;
        }
        return -1;
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }
}

