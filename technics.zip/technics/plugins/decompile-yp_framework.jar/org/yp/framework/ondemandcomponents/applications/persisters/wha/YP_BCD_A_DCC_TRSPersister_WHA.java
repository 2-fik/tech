/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.ws.BindingProvider
 *  javax.xml.ws.Holder
 */
package org.yp.framework.ondemandcomponents.applications.persisters.wha;

import com.nepting.customers.api.wha.TechnicalException;
import com.nepting.customers.api.wha.WhamPosService;
import com.nepting.customers.api.wha.WhamPosSrv;
import com.wha.appli.mpos.ws.service.RecordBusinessResponse;
import com.wha.appli.mpos.ws.service.TTransaction;
import com.wha.appli.mpos.ws.service.exceptions.RecordTrxExceptions;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_KRN_InitialisationParameters;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects.DAO_WHA_BrandAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects.DAO_WHA_ContractAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects.DAO_WHA_InitialisationExtension;
import org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects.DAO_WHA_MerchantAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.wha.designaccesobjects.DAO_WHA_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister.YP_TCD_DCB_Interface_TRSPersister;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class YP_BCD_A_DCC_TRSPersister_WHA
extends YP_TCD_DCC_Business
implements YP_TCD_DCB_Interface_TRSPersister {
    private YP_TCD_DesignAccesObject whaTransaction;
    private YP_TCD_DesignAccesObject brandAccess;
    private YP_TCD_DesignAccesObject merchantAccess;
    private YP_TCD_DesignAccesObject contractAccess;

    public YP_BCD_A_DCC_TRSPersister_WHA(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        block3: {
            this.setContainerBusinessType(this.getContainerBusinessType() | 1);
            super.initialize();
            try {
                this.whaTransaction = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_WHA_Transaction.class, 0, 0, null);
                this.brandAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_WHA_BrandAccess.class, 0, 0, null);
                this.merchantAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_WHA_MerchantAccess.class, 0, 0, null);
                this.contractAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_WHA_ContractAccess.class, 0, 0, null);
                if (this.initialisationParameters == null) {
                    this.initialisationParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_InitialisationParameters.class, 0, 0, null);
                }
                this.initialisationParameters.addExtension(new DAO_WHA_InitialisationExtension());
                this.getInitialisationRow();
                this.loadBrands();
                this.loadMerchants();
                this.loadContracts();
            }
            catch (Exception exception) {
                exception.printStackTrace();
                if (this.getLogLevel() < 2) break block3;
                this.logger(2, "initialize()" + exception);
            }
        }
        return 1;
    }

    private int loadBrands() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.brandAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idBrand");
                if (l <= 0L) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadBrands() bad value for idBrand:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBrand", l);
                if (yP_TCD_DC_Context == null) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadBrands() unable to get datacontainer for idBrand:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl || this.getLogLevel() < 3) continue;
                this.logger(3, "loadBrands() datacontainer already added for idBrand:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadBrands()" + exception);
            }
            return -1;
        }
    }

    private int loadMerchants() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.merchantAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idMerchant");
                if (l <= 0L) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadMerchants() bad value for idMerchant:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerMerchant", l);
                if (yP_TCD_DC_Context == null) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadMerchants() unable to get datacontainer for idMerchant:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl || this.getLogLevel() < 3) continue;
                this.logger(3, "loadMerchants() datacontainer already added for idMerchant:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadMerchants()" + exception);
            }
            return -1;
        }
    }

    private int loadContracts() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.contractAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idContract");
                if (l <= 0L) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadContracts() bad value for idContract:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBusiness", l);
                if (yP_TCD_DC_Context == null) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "loadContracts() unable to get datacontainer for idContract:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl || this.getLogLevel() < 3) continue;
                this.logger(3, "loadContracts() datacontainer already added for idContract:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadContracts()" + exception);
            }
            return -1;
        }
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.whaTransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() whaTransaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() brandAccess");
            }
            this.loadBrands();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() merchantAccess");
            }
            this.loadMerchants();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contractAccess");
            }
            this.loadContracts();
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.whaTransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() whaTransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.whaTransaction != null && (yP_TCD_DesignAccesObject == this.whaTransaction || clazz == this.whaTransaction.getRowClass())) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() whaTransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int persistTransaction(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "persistTransaction() only for ETF busines");
            }
            return -1;
        }
        YP_Row yP_Row = this.getTransactionRow((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "persistTransaction() unable to get transactionRow");
            }
            return -1;
        }
        return this.dealOneTransaction(yP_Row);
    }

    private YP_Row getTransactionRow(YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            YP_Row yP_Row;
            block8: {
                String string;
                yP_Row = this.whaTransaction.getNewRow();
                yP_Row.set("merchantTransactionIdentifier", yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionIdentifier());
                TransactionTypeEnumeration transactionTypeEnumeration = yP_TCD_DC_Transaction.commonHandler.getTransactionType();
                yP_Row.set("type", transactionTypeEnumeration);
                yP_Row.set("amount", yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
                yP_Row.set("currency", yP_TCD_DC_Transaction.commonHandler.getTransactionCurrencyAlpha());
                yP_Row.set("timestamp", yP_TCD_DC_Transaction.commonHandler.getTransactionAppliLocalTime());
                yP_Row.set("status", yP_TCD_DC_Transaction.commonHandler.getRealisationMode());
                yP_Row.set("maskedPAN", UtilsYP.maskPAN_6Point4(yP_TCD_DC_Transaction.accountHandler.getAccountIdentifier()));
                yP_Row.set("userName", yP_TCD_DC_Transaction.userHandler.getUserUID());
                yP_Row.set("merchantContractIdentifier", yP_TCD_DCC_EFT_Business.getMerchantContract());
                yP_Row.set("verificationMethod", yP_TCD_DC_Transaction.commonHandler.getCardHolderAuthentication());
                String string2 = yP_TCD_DC_Transaction.getAuthorisationApprovalCode();
                if (string2 != null && !string2.isEmpty()) {
                    yP_Row.set("authorizationNumber", string2);
                }
                if ((string = yP_TCD_DC_Transaction.getAuthorisationResponseCode()) != null && !string.isEmpty()) {
                    yP_Row.set("authorizationRespCode", string);
                }
                yP_Row.set("nepSAServerResponse", yP_TCD_DC_Transaction.commonHandler.getExtendedResult().toString());
                try {
                    yP_TCD_DC_Transaction.getRealNLPA();
                    YP_Row yP_Row2 = yP_TCD_DC_Transaction.getTerminalRow();
                    if (yP_Row2 != null) {
                        yP_Row.set("terminalSerialNumber", yP_Row2.getFieldStringValueByName("terminalSerialNumber"));
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) break block8;
                    this.logger(2, "getTransactionRow()" + exception);
                }
            }
            yP_Row.set("scheme", yP_TCD_DC_Transaction.accountHandler.getScheme());
            yP_Row.set("entryCondition", yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology());
            yP_Row.set("applicationType", yP_TCD_DCC_EFT_Business.getApplicationPlugin().getApplicationRow().getFieldStringValueByName("applicationName"));
            yP_Row.set("customerTillReceipt", yP_TCD_DCC_EFT_Business.getTransactionTicket(yP_TCD_DC_Transaction, false, 1));
            return yP_Row;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTransactionRow() " + exception);
            }
            return null;
        }
    }

    private TTransaction getWSObject(YP_Row yP_Row) {
        TTransaction tTransaction = new TTransaction();
        tTransaction.setMerchantTransactionIdentifier(yP_Row.getFieldStringValueByName("merchantTransactionIdentifier"));
        tTransaction.setType(yP_Row.getFieldStringValueByName("type"));
        tTransaction.setAmount(yP_Row.getFieldStringValueByName("amount"));
        tTransaction.setCurrency(yP_Row.getFieldStringValueByName("currency"));
        tTransaction.setTimestamp(yP_Row.getFieldStringValueByName("timestamp"));
        tTransaction.setStatus(yP_Row.getFieldStringValueByName("status"));
        tTransaction.setMaskedPAN(yP_Row.getFieldStringValueByName("maskedPAN"));
        tTransaction.setUserName(yP_Row.getFieldStringValueByName("userName"));
        tTransaction.setMerchantContractIdentifier(yP_Row.getFieldStringValueByName("merchantContractIdentifier"));
        tTransaction.setVerificationMethod(yP_Row.getFieldStringValueByName("verificationMethod"));
        tTransaction.setAuthorizationNumber(yP_Row.getFieldStringValueByName("authorizationNumber"));
        tTransaction.setAuthorizationRespCode(yP_Row.getFieldStringValueByName("authorizationRespCode"));
        tTransaction.setNepSAServerResponse(yP_Row.getFieldStringValueByName("nepSAServerResponse"));
        tTransaction.setTerminalSerialNumber(yP_Row.getFieldStringValueByName("terminalSerialNumber"));
        tTransaction.setScheme(yP_Row.getFieldStringValueByName("scheme"));
        tTransaction.setEntryCondition(yP_Row.getFieldStringValueByName("entryCondition"));
        tTransaction.setApplicationType(yP_Row.getFieldStringValueByName("applicationType"));
        tTransaction.setCustomerTillReceipt(yP_Row.getFieldStringValueByName("customerTillReceipt"));
        return tTransaction;
    }

    public void callWS(String string, TTransaction tTransaction, Holder<RecordBusinessResponse> holder, Holder<RecordTrxExceptions> holder2) throws Exception {
        TrustManager[] trustManagerArray = new TrustManager[]{new X509TrustManager(){

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            @Override
            public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) throws CertificateException {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) throws CertificateException {
            }
        }};
        SSLContext sSLContext = SSLContext.getInstance("SSL");
        sSLContext.init(null, trustManagerArray, null);
        WhamPosService whamPosService = new WhamPosService(this.getClass().getResource("WhamPosSrv.wsdl"));
        WhamPosSrv whamPosSrv = whamPosService.getWhamPosSrv();
        Map map = ((BindingProvider)whamPosSrv).getRequestContext();
        map.put("javax.xml.ws.service.endpoint.address", string);
        HostnameVerifier hostnameVerifier = new HostnameVerifier(){

            @Override
            public boolean verify(String string, SSLSession sSLSession) {
                return true;
            }
        };
        map.put("com.sun.xml.internal.ws.transport.https.client.hostname.verifier", hostnameVerifier);
        map.put("com.sun.xml.ws.transport.https.client.hostname.verifier", hostnameVerifier);
        map.put("com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory", sSLContext.getSocketFactory());
        map.put("com.sun.xml.ws.transport.https.client.SSLSocketFactory", sSLContext.getSocketFactory());
        whamPosSrv.recordTransactionInfos(tTransaction.getMerchantTransactionIdentifier(), tTransaction.getType(), tTransaction.getAmount(), tTransaction.getCurrency(), tTransaction.getTimestamp(), tTransaction.getStatus(), tTransaction.getMaskedPAN(), tTransaction.getUserName(), tTransaction.getMerchantContractIdentifier(), tTransaction.getVerificationMethod(), tTransaction.getAuthorizationNumber(), tTransaction.getAuthorizationRespCode(), tTransaction.getNepSAServerResponse(), tTransaction.getTerminalSerialNumber(), tTransaction.getScheme(), tTransaction.getEntryCondition(), tTransaction.getApplicationType(), tTransaction.getCustomerTillReceipt(), holder, holder2);
    }

    private int dealOneTransaction(YP_Row yP_Row) {
        block18: {
            block17: {
                Holder holder;
                block16: {
                    if (yP_Row == null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealOneTransaction() no transactionRow");
                        }
                        return -1;
                    }
                    YP_Row yP_Row2 = this.getInitialisationRow();
                    if (yP_Row2 == null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealOneTransaction() no initialisationRow");
                        }
                        return -1;
                    }
                    TTransaction tTransaction = this.getWSObject(yP_Row);
                    String string = yP_Row2.getFieldStringValueByName("webServiceURL");
                    Holder holder2 = new Holder();
                    holder = new Holder();
                    this.callWS(string, tTransaction, (Holder<RecordBusinessResponse>)holder2, (Holder<RecordTrxExceptions>)holder);
                    if (holder2.value == null) break block16;
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "dealOneTransaction() trs persisted");
                    }
                    if (!yP_Row.isItAClonedRow()) {
                        yP_Row.delete();
                        yP_Row.persist();
                    }
                    return 1;
                }
                try {
                    if (holder.value != null) {
                        this.logger(2, "dealOneTransaction() Exception received ");
                    } else {
                        this.logger(2, "dealOneTransaction() Nothing received");
                    }
                }
                catch (TechnicalException | IOException | KeyManagementException | NoSuchAlgorithmException exception) {
                    exception.printStackTrace();
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealOneTransaction() " + exception);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    if (this.getLogLevel() < 2) break block17;
                    this.logger(2, "dealOneTransaction() " + exception);
                }
            }
            if (yP_Row.isItAClonedRow()) {
                yP_Row.setIsItAClonedRow(false);
            }
            yP_Row.set("currentTry", (Integer)yP_Row.getFieldValueByName("currentTry") + 1);
            try {
                yP_Row.persist();
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block18;
                this.logger(2, "dealOneTransaction() " + exception);
            }
        }
        return 0;
    }

    private int dealTransactionsUpload() {
        if (UtilsYP.getInstanceRole() != 1) {
            return 0;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.whaTransaction);
        yP_ComplexGabarit.set(this.whaTransaction.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1234);
        yP_ComplexGabarit.set("currentTry", YP_ComplexGabarit.OPERATOR.LESS, 10);
        List<YP_Row> list = this.whaTransaction.getRowListSuchAs(0, 1000, yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealTransactionsUpload() unable to get transation list");
            }
            return -1;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "dealTransactionsUpload() nothing to do");
            }
        } else {
            for (YP_Row yP_Row : list) {
                int n = this.dealOneTransaction(yP_Row);
                if (n == 1) continue;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealTransactionsUpload() unable to upload transaction");
                }
                return -1;
            }
            if (this.getLogLevel() >= 4) {
                this.logger(4, "dealTransactionsUpload() all transactions have been uploaded");
            }
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            block11: {
                if (string == null || string.isEmpty()) break block11;
                switch (string) {
                    case "dealTransastionsUpload": 
                    case "dealTransactionsUpload": {
                        return this.dealTransactionsUpload();
                    }
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerTRSPersister_WHA";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

