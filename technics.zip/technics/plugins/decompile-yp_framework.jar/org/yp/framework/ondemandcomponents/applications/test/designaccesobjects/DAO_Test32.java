/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test32
extends YP_Row {
    @PrimaryKey
    public long idTest32 = 0L;
    @Index
    public byte[] test32Array = new byte[18];
}

