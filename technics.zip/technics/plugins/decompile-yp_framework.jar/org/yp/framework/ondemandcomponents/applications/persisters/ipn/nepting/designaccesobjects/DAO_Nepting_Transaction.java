/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.ipn.nepting.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.TransactionStatusEnumeration;

public class DAO_Nepting_Transaction
extends YP_Row {
    @PrimaryKey
    public long idNepting_Transaction = 0L;
    public byte[] urlStatus = new byte[256];
    public byte[] nep_MerchantID = new byte[20];
    public byte[] nep_TransactionID = new byte[20];
    public TransactionStatusEnumeration nep_Result;
    public byte[] nep_ExtendedResult = new byte[32];
    public byte[] nep_MerchantReference = new byte[20];
    public Timestamp nep_SystemDateTime = new Timestamp(0L);
    public long nep_Amount = 0L;
    public byte[] nep_APIVersion = new byte[5];
    public int nep_RealisationMode = 0;
    public Boolean nep_TestMode;
    public byte[] nep_PaymentScheme = new byte[50];
    public byte[] nep_Ticket = new byte[1024];
    public int responseCode = 0;
    public byte[] responseMessage = new byte[128];
    public int currentTry = 0;
    public byte[] nep_Email = new byte[250];
    public int nep_CurrencyCode = 0;
    public int nep_Mode = 0;
    public byte[] nep_Sign = new byte[64];
    public long nep_MopID = 0L;
    public byte[] nep_MaskedPan = new byte[64];
    public Timestamp nep_EndOfValidity = new Timestamp(0L);
    public byte[] nep_CardToken = new byte[64];
}

