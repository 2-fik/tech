/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Process;
import org.yp.framework.globalcomponents.YP_TCG_XMLParser;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_DigestAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_MacAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_RandomNumberGenerator_Interface;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.xml.jaxb.ypproperties.Properties;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_TCD_CRYPTO_Module
extends YP_OnDemandComponent {
    private String cryptoModuleName;
    private YP_Row cryptoModuleRow = null;
    private List<Property> cryptoProperties;
    protected YP_TCD_CRYPTO_CipherSym_Interface myCipherSym;
    protected YP_TCD_CRYPTO_DigestAlgo_Interface myDigest;
    protected YP_TCD_CRYPTO_RandomNumberGenerator_Interface myRandomData;
    protected YP_TCD_CRYPTO_MacAlgo_Interface myMAC;
    private String providerName = "";
    private String mySerialNumber = "";
    private String myJarFile = "";
    private String interfaceType = "";
    private String ownerProcess;
    private String ownerContractIdentifier;
    private String ownerPreferredName;
    private int securityLevel = 0;
    private int priority = 0;
    private final List<CategoryElement> categoryList = new ArrayList<CategoryElement>();

    private boolean addOneCategoryElement(String string, String string2, String string3) {
        Integer n;
        try {
            n = Integer.parseInt(string3);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addOneCategoryElement() bad value for efficiencyValue:" + string3);
            }
            n = -1;
        }
        AlgoSupported algoSupported = new AlgoSupported(string2, n);
        for (CategoryElement categoryElement : this.categoryList) {
            if (!categoryElement.categoryName.contentEquals(string)) continue;
            try {
                categoryElement.algoList.add(algoSupported);
                return true;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "addOneCategoryElement()" + exception);
                }
                return false;
            }
        }
        try {
            CategoryElement categoryElement;
            categoryElement = new CategoryElement(string);
            this.categoryList.add(categoryElement);
            categoryElement.algoList.add(algoSupported);
            return true;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addOneCategoryElement()" + exception);
            }
            return false;
        }
    }

    private int addOneCategory(String string, String string2) {
        String[] stringArray;
        block25: {
            stringArray = string2.split("#");
            if (stringArray.length % 2 != 1) break block25;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addOneCategory() even size");
            }
            return -1;
        }
        try {
            int n = 0;
            while (n < stringArray.length) {
                block26: {
                    try {
                        boolean bl = false;
                        switch (string) {
                            case "cipherSym": {
                                if (this.myCipherSym.isCipherSymSupported(stringArray[n]) > 0) {
                                    bl = true;
                                    break;
                                }
                                if (this.getLogLevel() < 3) break;
                                this.logger(3, "addOneCategory() cipher not supported:" + stringArray[n]);
                                break;
                            }
                            case "digestAlgo": {
                                if (this.myDigest.isDigestSupported(stringArray[n]) > 0) {
                                    bl = true;
                                    break;
                                }
                                if (this.getLogLevel() < 3) break;
                                this.logger(3, "addOneCategory() digest not supported:" + stringArray[n]);
                                break;
                            }
                            case "macAlgo": {
                                if (this.myMAC.isMACSupported(stringArray[n]) > 0) {
                                    bl = true;
                                    break;
                                }
                                if (this.getLogLevel() < 3) break;
                                this.logger(3, "addOneCategory() mac not supported:" + stringArray[n]);
                                break;
                            }
                            default: {
                                if (this.getLogLevel() < 2) break;
                                this.logger(2, "addOneCategory() unknown category :" + string);
                            }
                        }
                        if (bl) {
                            this.addOneCategoryElement(string, stringArray[n], stringArray[n + 1]);
                        }
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 3) break block26;
                        this.logger(3, "addOneCategory() algo not supported:" + stringArray[n] + " " + exception);
                    }
                }
                n += 2;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addOneCategory() " + exception);
            }
            return -2;
        }
    }

    public YP_TCD_CRYPTO_Module(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray == null || objectArray.length < 1 || !(objectArray[0] instanceof YP_Row)) {
                this.logger(2, "YP_TCD_CRYPTO_Module() first parameter must be a row");
                throw new Exception("YP_TCD_CRYPTO_Module() first parameter must be a row");
            }
            this.cryptoModuleRow = (YP_Row)objectArray[0];
            String string = this.cryptoModuleRow.getFieldStringValueByName("properties");
            if (string != null && !string.isEmpty()) {
                try {
                    YP_TCG_XMLParser yP_TCG_XMLParser = (YP_TCG_XMLParser)this.getPluginByName("YPPropertiesParser");
                    Properties properties = (Properties)yP_TCG_XMLParser.xmlToObject(string);
                    this.cryptoProperties = properties.getProperty();
                }
                catch (Exception exception) {
                    this.logger(2, "YP_TCD_CRYPTO_Module() bad properties ??? " + string + " " + exception);
                }
            }
            this.setSecurityLevel((Integer)this.cryptoModuleRow.getFieldValueByName("securityLevel"));
            this.setPriority((Integer)this.cryptoModuleRow.getFieldValueByName("priority"));
        }
    }

    private boolean isRequestorAllowedToUseCryptoModule() {
        YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
        String string = yP_Process.toString();
        String string2 = yP_Process.getContractIdentifier();
        String string3 = yP_Process.getPreferredName();
        if (!(this.ownerProcess == null || this.ownerProcess.isEmpty() || this.ownerProcess.trim().isEmpty() || this.ownerProcess.contains(string))) {
            return false;
        }
        if (this.ownerPreferredName != null && !this.ownerPreferredName.isEmpty() && !this.ownerPreferredName.trim().isEmpty()) {
            if (string3 == null || string3.isEmpty() || string3.trim().isEmpty()) {
                return false;
            }
            if (!this.ownerPreferredName.contains(string3)) {
                return false;
            }
        }
        if (this.ownerContractIdentifier != null && !this.ownerContractIdentifier.isEmpty() && !this.ownerContractIdentifier.trim().contentEquals("00")) {
            if (string2 == null || string2.isEmpty() || string2.trim().isEmpty()) {
                return false;
            }
            if (!this.ownerContractIdentifier.contains(string2)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() no DCC_Technique...");
            }
            return -1;
        }
        this.setCryptoModuleName(this.cryptoModuleRow.getFieldStringValueByName("idSM"));
        this.securityLevel = (Integer)this.cryptoModuleRow.getFieldValueByName("securityLevel");
        this.priority = (Integer)this.cryptoModuleRow.getFieldValueByName("priority");
        try {
            this.mySerialNumber = this.cryptoModuleRow.getFieldStringValueByName("serialNumber");
        }
        catch (Exception exception) {
            this.mySerialNumber = "";
        }
        try {
            this.myJarFile = this.cryptoModuleRow.getFieldStringValueByName("jarFile");
        }
        catch (Exception exception) {
            this.myJarFile = "";
        }
        try {
            this.providerName = this.cryptoModuleRow.getFieldStringValueByName("providerName");
        }
        catch (Exception exception) {
            this.providerName = "";
        }
        try {
            this.interfaceType = this.cryptoModuleRow.getFieldStringValueByName("interfaceType");
        }
        catch (Exception exception) {
            this.interfaceType = "";
        }
        try {
            this.ownerProcess = this.cryptoModuleRow.getFieldStringValueByName("ownerProcessCrypto");
        }
        catch (Exception exception) {
            this.ownerProcess = "";
        }
        try {
            this.ownerContractIdentifier = String.valueOf(this.cryptoModuleRow.getFieldStringValueByName("ownerBrandNameCrypto")) + this.cryptoModuleRow.getFieldStringValueByName("ownerMerchantIdCrypto") + this.cryptoModuleRow.getFieldStringValueByName("ownerApplicationIdCrypto");
        }
        catch (Exception exception) {
            this.ownerContractIdentifier = "";
        }
        try {
            this.ownerPreferredName = this.cryptoModuleRow.getFieldStringValueByName("ownerPreferredNameCrypto");
        }
        catch (Exception exception) {
            this.ownerPreferredName = "";
        }
        try {
            String string;
            String string2;
            String string3;
            String string4;
            String string5;
            String string6;
            String string7 = this.cryptoModuleRow.getFieldStringValueByName("prng");
            if (string7 != null && !string7.trim().isEmpty()) {
                this.addOneCategory("prng", string7);
            }
            if ((string6 = this.cryptoModuleRow.getFieldStringValueByName("rng")) != null && !string6.trim().isEmpty()) {
                this.addOneCategory("rng", string6);
            }
            if ((string5 = this.cryptoModuleRow.getFieldStringValueByName("cipherSym")) != null && !string5.trim().isEmpty()) {
                this.addOneCategory("cipherSym", string5);
            }
            if ((string4 = this.cryptoModuleRow.getFieldStringValueByName("cipherAsym")) != null && !string4.trim().isEmpty()) {
                this.addOneCategory("cipherAsym", string4);
            }
            if ((string3 = this.cryptoModuleRow.getFieldStringValueByName("macAlgo")) != null && !string3.trim().isEmpty()) {
                this.addOneCategory("macAlgo", string3);
            }
            if ((string2 = this.cryptoModuleRow.getFieldStringValueByName("signatureAlgo")) != null && !string2.trim().isEmpty()) {
                this.addOneCategory("signatureAlgo", string2);
            }
            if ((string = this.cryptoModuleRow.getFieldStringValueByName("digestAlgo")) != null && !string.trim().isEmpty()) {
                this.addOneCategory("digestAlgo", string);
            }
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() " + exception);
            }
            return -1;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    public int isCryptoSupported(String string, String string2) {
        if (!this.isRequestorAllowedToUseCryptoModule()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "isCryptoSupported() user not allowed to use this cryptomodule");
            }
            return -1;
        }
        for (CategoryElement categoryElement : this.categoryList) {
            if (!categoryElement.categoryName.contentEquals(string)) continue;
            for (AlgoSupported algoSupported : categoryElement.algoList) {
                if (!algoSupported.algoName.contentEquals(string2)) continue;
                return algoSupported.efficiency;
            }
        }
        return -1;
    }

    public int getSecurityLevel() {
        return this.securityLevel;
    }

    public void setSecurityLevel(int n) {
        this.securityLevel = this.securityLevel >= 0 ? n : 0;
    }

    public int getPriority() {
        return this.priority;
    }

    public void setPriority(int n) {
        this.priority = n;
    }

    public String getProviderName() {
        return this.providerName;
    }

    public void setProviderName(String string) {
        this.providerName = string;
    }

    public String getCryptoModuleName() {
        return this.cryptoModuleName;
    }

    public void setCryptoModuleName(String string) {
        this.cryptoModuleName = string;
    }

    protected final String getCryptoPropertie(String string) {
        if (this.cryptoProperties != null) {
            for (Property property : this.cryptoProperties) {
                if (!property.getName().contentEquals(string)) continue;
                return property.getValue();
            }
        }
        return null;
    }

    private class AlgoSupported {
        private final String algoName;
        private final int efficiency;

        public AlgoSupported(String string, int n) {
            this.algoName = string;
            this.efficiency = n;
        }
    }

    private class CategoryElement {
        public final String categoryName;
        public final List<AlgoSupported> algoList = new ArrayList<AlgoSupported>();

        public CategoryElement(String string) {
            this.categoryName = string;
        }
    }
}

