/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.utils.GlobalSummaryReport;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.enums.TransactionStatusEnumeration;

public final class YP_TCD_DCC_Merchant
extends YP_TCD_DC_Context {
    private YP_Row merchantRow;
    private String merchantName;
    private long idMerchant = 0L;
    private YP_TCD_DCC_Brand dataContainerBrand;
    public List<YP_TCD_DCC_Business> dataContainerBusinessList = new ArrayList<YP_TCD_DCC_Business>();
    private static final String CLI_TRAILER_MERCHANT_TT_TEMPLATE = "CLI_TRAILER_MERCHANT_TT_TEMPLATE";
    private static final String CLI_TRAILER_CUSTOMER_TT_TEMPLATE = "CLI_TRAILER_CUSTOMER_TT_TEMPLATE";
    public static final String DUPLICATES_CHECK_MODE = "duplicatesCheckMode";
    private Map<String, AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row>> pendingTransactions;

    public YP_TCD_DCC_Merchant(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray != null && objectArray.length > 1 && objectArray[0] != null && objectArray[0] instanceof YP_Row && objectArray[1] != null && objectArray[1] instanceof YP_TCD_DCC_Brand) {
            this.dataContainerBrand = (YP_TCD_DCC_Brand)objectArray[1];
            this.setMerchantRow((YP_Row)objectArray[0]);
        }
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    public final void setMerchantRow(YP_Row yP_Row) {
        this.merchantRow = yP_Row;
        this.idMerchant = this.merchantRow.getPrimaryKey();
        this.merchantName = this.merchantRow.getFieldStringValueByName("merchantName");
        String string = String.valueOf(this.dataContainerBrand.getBrandName()) + '_' + this.merchantName;
        this.setContractIdentifier(string);
        try {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : this.dataContainerBusinessList) {
                yP_TCD_DCC_Business.setContractRow(yP_TCD_DCC_Business.getContractRow());
            }
        }
        catch (Exception exception) {}
        this.storedParameters = null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int shutdown() {
        if (this.dataContainerBrand != null) {
            this.dataContainerBrand.dataContainerMerchantList.remove(this);
            this.dataContainerBrand = null;
        }
        this.merchantRow = null;
        this.dataContainerBusinessList.clear();
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerMerchant";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "dealRequest() unhnwown request: " + string);
        }
        return null;
    }

    public YP_TCD_DCC_Brand getDataContainerBrand() {
        return this.dataContainerBrand;
    }

    public String getMerchantName() {
        return this.merchantName;
    }

    public String getMerchantLabel() {
        if (this.merchantRow == null) {
            return null;
        }
        return this.merchantRow.getFieldStringValueByName("merchantLabel");
    }

    public String getMerchantURL() {
        if (this.merchantRow == null) {
            return null;
        }
        return this.merchantRow.getFieldStringValueByName("merchantURL");
    }

    public YP_Row getMerchantRow() {
        return this.merchantRow;
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    public long getIDMerchant() {
        return this.idMerchant;
    }

    public AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row> getPendingTransaction(YP_Transaction yP_Transaction, boolean bl) {
        if (this.pendingTransactions == null) {
            return null;
        }
        AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row> simpleEntry = this.pendingTransactions.remove(this.getTerminalIdentifier(yP_Transaction.getDataContainerTransaction().getTerminalRow()));
        return simpleEntry;
    }

    public Map<String, AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row>> getPendingTransactions() {
        return this.pendingTransactions;
    }

    public int addPendingTransaction(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        if (this.pendingTransactions == null) {
            this.pendingTransactions = new ConcurrentHashMap<String, AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row>>();
        }
        YP_Row yP_Row = yP_Transaction.getDataContainerTransaction().getTerminalRow();
        String string = this.getTerminalIdentifier(yP_Row);
        YP_Row yP_Row2 = yP_TCD_DCC_Business.saveTransaction(yP_Transaction.getDataContainerTransaction());
        AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row> simpleEntry = new AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row>(yP_TCD_DCC_Business, yP_Row2);
        this.pendingTransactions.put(string, simpleEntry);
        return 1;
    }

    public boolean pendingTransactionExists(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        if (this.pendingTransactions == null) {
            return false;
        }
        YP_Row yP_Row = yP_Transaction.getDataContainerTransaction().getTerminalRow();
        if (yP_Row == null) {
            return false;
        }
        String string = this.getTerminalIdentifier(yP_Row);
        return this.pendingTransactions.containsKey(string);
    }

    public void flushPendingTransactions(long l) {
        if (this.pendingTransactions == null) {
            return;
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Map.Entry<String, AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row>> entry : this.pendingTransactions.entrySet()) {
            AbstractMap.SimpleEntry<YP_TCD_DCC_Business, YP_Row> simpleEntry = entry.getValue();
            YP_Row yP_Row = simpleEntry.getValue();
            long l2 = (Long)yP_Row.getFieldValueByName("transactionSystemGMTTimeMS");
            if (l <= l2 + 60000L) continue;
            TransactionStatusEnumeration transactionStatusEnumeration = (TransactionStatusEnumeration)((Object)yP_Row.getFieldValueByName("transactionStatus"));
            if (transactionStatusEnumeration != TransactionStatusEnumeration.PENDING) {
                yP_Row.set("transactionStatus", TransactionStatusEnumeration.PENDING);
                try {
                    yP_Row.getFather().addRow(yP_Row, true);
                }
                catch (Exception exception) {
                    this.logger(2, "flushPendingTransactions() Failed to persist transaction", exception);
                }
            }
            if (transactionStatusEnumeration != TransactionStatusEnumeration.PENDING || l <= l2 + 3600000L) continue;
            arrayList.add(entry.getKey());
        }
        try {
            for (String string : arrayList) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "flushPendingTransactions() Removing pending transaction entry: " + string);
                }
                this.pendingTransactions.remove(string);
            }
            arrayList.clear();
        }
        catch (Exception exception) {
            this.logger(2, "flushPendingTransactions() Exception when removing pending transaction entry", exception);
        }
    }

    private String getTerminalIdentifier(YP_Row yP_Row) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(yP_Row.getFieldStringValueByName("terminalManufacturerID"));
        stringBuilder.append('_');
        stringBuilder.append(yP_Row.getFieldStringValueByName("terminalSerialNumber"));
        return stringBuilder.toString();
    }

    public String getTrailerTrsTicketTemplate(int n) {
        if (n == 2 || n == 5) {
            return this.getParameter(CLI_TRAILER_MERCHANT_TT_TEMPLATE, true);
        }
        if (n == 1) {
            return this.getParameter(CLI_TRAILER_CUSTOMER_TT_TEMPLATE, true);
        }
        return "";
    }

    public String getDuplicatesCheckMode() {
        return this.getParameter(DUPLICATES_CHECK_MODE, true);
    }

    public void doGlobalReport(YP_Transaction yP_Transaction, String string, String string2) {
        GlobalSummaryReport globalSummaryReport = new GlobalSummaryReport(this, yP_Transaction.getDataContainerTransaction());
        globalSummaryReport.doReport(yP_Transaction, string, string2);
    }
}

