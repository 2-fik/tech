/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_InternationalizationLabel
extends YP_Row {
    @PrimaryKey
    public long idLabel = 0L;
    public byte[] key = new byte[48];
}

