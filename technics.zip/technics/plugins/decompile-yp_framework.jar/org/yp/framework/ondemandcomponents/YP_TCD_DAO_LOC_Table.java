/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.ByteBuilder;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DAO_LOC_Table
extends YP_TCD_DAO_LOC {
    protected final List<YP_Row> generique = new ArrayList<YP_Row>();

    public YP_TCD_DAO_LOC_Table(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public String toString() {
        return "DAO_Table";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int reload() {
        return this.reload(true);
    }

    private int reload(boolean bl) {
        this.isLoadedInMemory = 1;
        this.generique.clear();
        int n = this.getDataBaseConnector().sql_Formater.sqlReloadTable(this);
        if (n == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reload() No result from database");
            }
        } else if (n < 0) {
            this.logger(2, "reload() Error during sqlSelectAll");
            this.isLoadedInMemory = 0;
            return -1;
        }
        this.setIsItAModifiedDAO(false);
        for (YP_Row yP_Row : this.generique) {
            yP_Row.setModifierFlag(0);
            yP_Row.setIsItAClonedRow(false);
        }
        if ((1 & this.getTableType()) == 0 && bl) {
            try {
                this.getDataContainerContext().onChange(this);
            }
            catch (Exception exception) {
                this.logger(2, "reload() onChange" + exception);
            }
            this.notifyWatcher();
        }
        this.loadedSinceGMTTime = UtilsYP.getSystemGMTTime();
        this.nbtimeUsedSinceReload.set(0);
        this.isLoadedInMemory = 2;
        return 1;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public int persist() {
        if ((this.getTableType() & 1) != 0) {
            if (!this.isItAModifiedDAO()) {
                return 0;
            }
            return ((YP_TCD_DesignAccesObject)this.getFather()).persist(this);
        }
        var1_1 = false;
        this.prepare();
        var2_2 = false;
        if (this.isItAClonedDAO()) {
            this.logger(2, "persist() : can't persist a cloned Object");
            return -1;
        }
        this.lock();
        this.persistInProcess = true;
        if (this.nbConcurrentReadAccess.get() > 0) {
            var3_3 = System.currentTimeMillis();
            while (this.nbConcurrentReadAccess.get() > 0) {
                this.logger(3, "persist() nbConcurrentReadAccess:" + this.nbConcurrentReadAccess);
                UtilsYP.sleep(1);
                if (!UtilsYP.isTimeout(var3_3, 30000)) continue;
                this.logger(2, "persist() nbConcurrentReadAccess reseted to avoid endless loop!!!!!:");
                this.nbConcurrentReadAccess.set(0);
            }
        }
        try {
            block29: {
                block28: {
                    if (!this.isItAModifiedDAO()) ** GOTO lbl80
                    try {
                        this.getDataContainerContext().onSaveBefore(this, null, null);
                    }
                    catch (Exception var3_4) {
                        this.logger(3, "persist() onSaveBefore" + var3_4);
                    }
                    var3_5 = new ArrayList<YP_Row>();
                    var4_10 = false;
                    for (YP_Row var5_13 : this.generique) {
                        if (var5_13.getModifierFlag() == 1) {
                            var4_10 = true;
                            break;
                        }
                        if (var5_13.getModifierFlag() == 0) continue;
                        var3_5.add(var5_13);
                    }
                    if (!var4_10) break block28;
                    var5_14 = this.size();
                    while (var5_14 > 0) {
                        if (this.generique.get(var5_14 - 1).getModifierFlag() == 1) {
                            this.generique.remove(var5_14 - 1);
                        }
                        --var5_14;
                    }
                    this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
                    this.getDataBaseConnector().sql_Formater.sqlFillTable(this);
                    ** GOTO lbl77
                }
                if (var3_5.size() <= 100) break block29;
                this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
                this.getDataBaseConnector().sql_Formater.sqlFillTable(this);
                ** GOTO lbl77
            }
            if (this.getDataBaseConnector().sql_Formater.sqlUpdateRowList(this, var3_5) < 0) {
                this.reload(false);
                return -1;
            }
            try {
                block30: {
                    var1_1 = true;
                    for (YP_Row var5_13 : this.generique) {
                        var5_13.setModifierFlag(0);
                    }
lbl77:
                    // 3 sources

                    this.setIsItAModifiedDAO(false);
                    var2_2 = true;
                    break block30;
lbl80:
                    // 1 sources

                    var3_6 = this.size();
                    var4_11 = 0;
                    while (var4_11 < var3_6) {
                        if (this.generique.get(var4_11).persist() > 0) {
                            var2_2 = true;
                        }
                        ++var4_11;
                    }
                }
                if (!var1_1 && var2_2) {
                    this.reload(false);
                }
            }
            catch (Exception var3_7) {
                this.logger(3, "persist() : " + var3_7);
                return -1;
            }
        }
        finally {
            this.persistInProcess = false;
            this.unlock();
        }
        if (var2_2) {
            this.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            this.getDataContainerContext().updateTableStatus(this);
            try {
                this.getDataContainerContext().onSaveAfter(this, null, null);
            }
            catch (Exception var3_8) {
                this.logger(3, "persist() onSaveAfter" + var3_8);
            }
            try {
                this.getDataContainerContext().onChange(this);
            }
            catch (Exception var3_9) {
                this.logger(2, "persist() onChange" + var3_9);
            }
            this.notifyWatcher();
            return 1;
        }
        this.logger(3, "persist() : Nothing to do");
        return 0;
    }

    @Override
    public int persist(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        this.prepare();
        if (this.isItAClonedDAO()) {
            this.logger(2, "persist() : can't persist a cloned Object");
            return -1;
        }
        this.lock();
        this.persistInProcess = true;
        if (this.nbConcurrentReadAccess.get() > 0) {
            long l = System.currentTimeMillis();
            while (this.nbConcurrentReadAccess.get() > 0) {
                this.logger(3, "persist() nbConcurrentReadAccess:" + this.nbConcurrentReadAccess);
                UtilsYP.sleep(1);
                if (!UtilsYP.isTimeout(l, 30000)) continue;
                this.logger(2, "persist() nbConcurrentReadAccess reseted to avoid endless loop!!!!!:");
                this.nbConcurrentReadAccess.set(0);
            }
        }
        try {
            try {
                this.generique.clear();
                this.generique.addAll(yP_TCD_DAO_LOC_Table.generique);
                try {
                    this.getDataContainerContext().onSaveBefore(this, null, null);
                }
                catch (Exception exception) {
                    this.logger(3, "persist() onSaveBefore" + exception);
                }
                int n = this.generique.size();
                while (n > 0) {
                    if (this.generique.get(n - 1).getModifierFlag() == 1) {
                        this.generique.remove(n - 1);
                    }
                    --n;
                }
                this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
                this.getDataBaseConnector().sql_Formater.sqlFillTable(this);
                this.setIsItAModifiedDAO(false);
                for (YP_Row yP_Row : this.generique) {
                    yP_Row.setModifierFlag(0);
                }
            }
            catch (Exception exception) {
                this.logger(3, "persist() : " + exception);
                this.persistInProcess = false;
                this.unlock();
                return -1;
            }
        }
        finally {
            this.persistInProcess = false;
            this.unlock();
        }
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, null, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 1;
    }

    @Override
    public int addRow(YP_Row yP_Row) {
        this.prepare();
        YP_Row yP_Row2 = (YP_Row)yP_Row.clone();
        yP_Row2.setIsItAClonedRow(false);
        yP_Row2.setModifierFlag(2);
        this.lock();
        try {
            this.generique.add(yP_Row2);
            this.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "addRow() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int addRow(YP_Row yP_Row, boolean bl) {
        if (!bl) {
            return this.addRow(yP_Row);
        }
        this.prepare();
        this.lock();
        yP_Row.setIsItAClonedRow(false);
        yP_Row.setModifierFlag(2);
        try {
            this.generique.add(yP_Row);
            this.setIsItAModifiedDAO(true);
        }
        catch (Throwable throwable) {
            try {
                this.unlock();
                throw throwable;
            }
            catch (Exception exception) {
                this.logger(2, "addRow() " + exception);
                return -1;
            }
        }
        this.unlock();
        return 1;
    }

    @Override
    public int updateRowSuchAs(YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRowSuchAs() is not allowed !!!");
        }
        List<YP_Row> list = this.getRowListSuchAs(0, n, yP_ComplexGabaritArray);
        if (list == null || list.isEmpty()) {
            this.logger(3, "updateRowSuchAs() no row to update");
            return 0;
        }
        int n2 = YP_Row.updateRowList(list, yP_Row);
        if (n2 == 1) {
            return list.size();
        }
        return n2;
    }

    @Override
    public int deleteRows(boolean bl) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRows() is not allowed !!!");
        }
        this.prepare();
        try {
            this.lock();
            if ((this.getTableType() & 1) != 0) {
                this.generique.clear();
                if (bl) {
                    this.setIsItAModifiedDAO(true);
                } else {
                    this.setIsItAModifiedDAO(false);
                }
            } else {
                int n = this.size();
                if (n == 0 && !bl) {
                    return 0;
                }
                int n2 = 0;
                while (n2 < n) {
                    this.generique.get(n2).delete();
                    ++n2;
                }
                this.setIsItAModifiedDAO(true);
            }
            if (bl) {
                int n = this.persist();
                return n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deleteRows() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int deleteRowsSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRowsSuchAs() is not allowed !!!");
        }
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            return this.deleteRows(true);
        }
        this.prepare();
        try {
            this.lock();
            List<YP_Row> list = this.getRowListSuchAs(yP_ComplexGabaritArray);
            if (list == null || list.isEmpty()) {
                return 0;
            }
            int n = 0;
            while (n < list.size()) {
                list.get(n).delete();
                ++n;
            }
            this.setIsItAModifiedDAO(true);
            if ((this.getTableType() & 1) == 0) {
                this.persist();
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deleteRowsSuchAs() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public YP_Row getRowAt(int n) {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            YP_Row yP_Row = this.generique.get(n);
            return yP_Row;
        }
        catch (Exception exception) {
            if (n >= this.size()) {
                this.logger(3, "getRowAt() index too big:" + n + " " + this.size());
            } else {
                this.logger(2, "getRowAt() " + exception);
            }
            return null;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    protected YP_Row getRowAt(int n, boolean bl) {
        if (bl) {
            return this.getRowAt(n);
        }
        try {
            this.prepare();
            return this.generique.get(n);
        }
        catch (Exception exception) {
            this.logger(2, "getRowAt() " + exception);
            if (n >= this.size()) {
                this.logger(2, "getRowAt() index too big");
            }
            return null;
        }
    }

    @Override
    public int size() {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            int n = this.generique.size();
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "size() " + exception);
            return -1;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    public YP_Row getRowByPrimaryKey(long l) {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            int n = 0;
            while (n < this.size()) {
                YP_Row yP_Row = this.generique.get(n);
                if (l == yP_Row.getPrimaryKey()) {
                    YP_Row yP_Row2 = yP_Row;
                    return yP_Row2;
                }
                ++n;
            }
            this.logger(2, "getRowByPrimaryKey() not found " + l + " " + this.getFullTableName());
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getRowByPrimaryKey() " + exception);
            return null;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        try {
            this.generique.clear();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "shutdown() error :" + exception);
            return -1;
        }
    }

    @Override
    public Object clone() {
        YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table;
        block4: {
            yP_TCD_DAO_LOC_Table = (YP_TCD_DAO_LOC_Table)super.clone();
            if (yP_TCD_DAO_LOC_Table != null) break block4;
            return null;
        }
        try {
            yP_TCD_DAO_LOC_Table.generique.clear();
            int n = 0;
            while (n < this.size()) {
                yP_TCD_DAO_LOC_Table.generique.add((YP_Row)this.generique.get(n).clone());
                ++n;
            }
            yP_TCD_DAO_LOC_Table.setIsItAClonedDAO(true);
            return yP_TCD_DAO_LOC_Table;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public int addRowDuringReload(YP_Row yP_Row) {
        YP_Row yP_Row2 = (YP_Row)yP_Row.clone();
        this.generique.add(yP_Row2);
        return 1;
    }

    public final YP_Row binarySearch(String string, long l, YP_ComplexGabarit.OPERATOR oPERATOR) {
        int n;
        int n2;
        Field field;
        boolean bl;
        block10: {
            block9: {
                bl = !this.isLockedByMe();
                field = this.getFieldByName(string);
                if (field.getAnnotation(PrimaryKey.class) != null) break block9;
                this.logger(2, "binarySearch() is only for primaryKey");
                return null;
            }
            n2 = 0;
            n = this.size() - 1;
            if (n >= 0) break block10;
            return null;
        }
        try {
            YP_Row yP_Row = null;
            YP_Row yP_Row2 = null;
            while (n2 <= n) {
                int n3 = (n2 + n) / 2;
                YP_Row yP_Row3 = this.getRowAt(n3, bl);
                long l2 = (Long)yP_Row3.getFieldValue(field);
                if (l2 < l) {
                    yP_Row = yP_Row3;
                    n2 = n3 + 1;
                    continue;
                }
                if (l2 > l) {
                    yP_Row2 = yP_Row3;
                    n = n3 - 1;
                    continue;
                }
                return yP_Row3;
            }
            if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER) {
                return yP_Row2;
            }
            if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS) {
                return yP_Row;
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "binarySearch() " + exception);
            return null;
        }
    }

    public final YP_Row binarySearch(String string, String string2, YP_ComplexGabarit.OPERATOR oPERATOR) {
        int n;
        int n2;
        Field field;
        boolean bl;
        block10: {
            block9: {
                bl = !this.isLockedByMe();
                field = this.getFieldByName(string);
                if (field.getAnnotation(PrimaryKey.class) != null) break block9;
                this.logger(2, "binarySearch() is only for primaryKey");
                return null;
            }
            n2 = 0;
            n = this.size() - 1;
            if (n >= 0) break block10;
            return null;
        }
        try {
            byte[] byArray = string2.getBytes();
            YP_Row yP_Row = null;
            YP_Row yP_Row2 = null;
            while (n2 <= n) {
                int n3 = (n2 + n) / 2;
                YP_Row yP_Row3 = this.getRowAt(n3, bl);
                int n4 = UtilsYP.strcmp((byte[])yP_Row3.getFieldValue(field), byArray);
                if (n4 < 0) {
                    yP_Row = yP_Row3;
                    n2 = n3 + 1;
                    continue;
                }
                if (n4 > 0) {
                    yP_Row2 = yP_Row3;
                    n = n3 - 1;
                    continue;
                }
                return yP_Row3;
            }
            if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER) {
                return yP_Row2;
            }
            if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS) {
                return yP_Row;
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "binarySearch() " + exception);
            return null;
        }
    }

    @Override
    public int unload() {
        try {
            this.lock();
            if (this.isLoadedInMemory != 2) {
                return 0;
            }
            this.isLoadedInMemory = 3;
            this.generique.clear();
            this.loadedSinceGMTTime = null;
            this.nbtimeUsedSinceReload.set(0);
            this.isLoadedInMemory = 0;
            return 1;
        }
        catch (Exception exception) {
            this.logger(3, "unload()" + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public boolean isEmpty() {
        this.prepare();
        boolean bl = false;
        try {
            if (this.persistInProcess) {
                this.lock();
                bl = true;
            }
            this.nbConcurrentReadAccess.incrementAndGet();
            boolean bl2 = this.generique.isEmpty();
            return bl2;
        }
        catch (Exception exception) {
            this.logger(2, "isEmpty() " + exception);
            return true;
        }
        finally {
            this.nbConcurrentReadAccess.decrementAndGet();
            if (bl) {
                this.unlock();
            }
        }
    }

    public int computeCksum() {
        try {
            Object object2;
            this.lock();
            if (this.size() == 0) {
                this.setTableCksum("0000");
                return 1;
            }
            ByteBuilder byteBuilder = new ByteBuilder();
            Field[] fieldArray = this.getFieldList();
            for (Object object2 : this) {
                ((YP_Row)object2).serialize(byteBuilder, fieldArray);
            }
            object2 = new CRC32();
            object2.update(byteBuilder.data(), 0, byteBuilder.size());
            long l = object2.getValue();
            if ((l %= 65536L) == 0L) {
                l = 65535L;
            }
            this.setTableCksum(String.format("%04x", l));
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "computeCksum() " + exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }
}

