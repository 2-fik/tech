/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.rawtlv;

public class YP_RawTLVEvent {
    protected RawTLVEVENT myEvent;

    public RawTLVEVENT getEventRawTLV() {
        return this.myEvent;
    }

    public void setEventRawTLV(RawTLVEVENT rawTLVEVENT) {
        this.myEvent = rawTLVEVENT;
    }

    public static enum RawTLVEVENT {
        OuvertureDialogue,
        ServiceRefuse,
        RefusAccepteur,
        RefusAcquereur,
        RepOk,
        RepKo,
        AttenteOd,
        synchroRequest,
        tlpInitTransfer,
        tlpDataTransfer,
        tlpActivateTable,
        tlpDealFunctionState,
        echoTest,
        giveTalk,
        dealGiveTalk,
        closeDialog,
        closeDialogReq,
        tlpInitTransferKo,
        openService,
        tlpAckFunctionalState,
        synchroLastRequest,
        synchroCloseDialog,
        askTableState,
        askSAState,
        askPAState,
        autoAnswer,
        autoEnd,
        autoprocess,
        fichierVide,
        askConsolidation,
        askEndOfDay,
        askRetry,
        askNewSession,
        dealInitTransactionUpload,
        error,
        hostEnd,
        dealSynchro;

    }
}

