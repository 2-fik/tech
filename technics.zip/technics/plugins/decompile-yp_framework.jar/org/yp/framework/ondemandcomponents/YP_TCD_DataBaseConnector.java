/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.List;
import org.yp.designaccesobjects.YP_PreparedValue;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.globalcomponents.sqlformaters.YP_TCG_SQL_Formater;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.services.YP_TS_DataContainerManager;

public abstract class YP_TCD_DataBaseConnector
extends YP_OnDemandComponent {
    private YP_Row dataBaseConnectorRow = null;
    private String sDAOConnectorProperties;
    private String sDAOConnectorName;
    private String dataBaseName;
    public YP_TCG_SQL_Formater sql_Formater;
    private int siteIdentifier = -1;
    private String dbc_Path = null;
    private String dbc_Properties = null;
    private String dbc_Password = null;
    private String dbc_User = null;
    private byte[] dbc_UserArray = null;
    private String sql_Plugin = null;
    private int connectorType = -1;

    public YP_TCD_DataBaseConnector(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length == 1 && objectArray[0] != null && objectArray[0] instanceof YP_Row) {
            this.dataBaseConnectorRow = (YP_Row)objectArray[0];
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.getPropertyFileName() != null) {
            String string = this.getProperty(this.getPropertyFileName(), "dataBaseName");
            if (string != null) {
                this.dataBaseName = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "daoConnectorName")) != null) {
                this.sDAOConnectorName = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "daoConnectorProperties")) != null) {
                this.sDAOConnectorProperties = string;
            }
            try {
                this.dataBaseConnectorRow = (YP_Row)Class.forName(this.sDAOConnectorName).newInstance();
                this.dataBaseConnectorRow.initializeFromPropertyFile(this.sDAOConnectorProperties);
            }
            catch (Exception exception) {
                this.logger(2, "initialize() ..." + exception);
                return -1;
            }
        }
        if (this.dataBaseConnectorRow == null) {
            return -1;
        }
        this.getSqlPlugin();
        this.sql_Formater = (YP_TCG_SQL_Formater)((Object)this.getPluginByName(this.sql_Plugin));
        return 1;
    }

    public abstract StringBuilder dealQuery(YP_TCD_DesignAccesObject var1, String var2, int var3) throws SQLException;

    public abstract int dealCustomQuery(String var1);

    public abstract int dealReloadForTable(YP_TCD_DAO_LOC_Table var1, String var2) throws SQLException;

    public abstract int dealReloadForMemory(YP_TCD_DAO_LOC_Memory var1, String var2) throws SQLException;

    public abstract List<YP_Row> dealSelect(YP_TCD_DesignAccesObject var1, String var2);

    public abstract List<YP_Row> dealSelect(YP_TCD_DesignAccesObject var1, List<YP_PreparedValue> var2, String var3);

    public abstract List<YP_Row> dealSelect(YP_TCD_DesignAccesObject var1, YP_TCD_DesignAccesObject var2, String var3);

    public abstract List<YP_Row> dealSelectForTwo(YP_TCD_DesignAccesObject var1, YP_TCD_DesignAccesObject var2, String var3);

    public abstract int dealUpdate(YP_TCD_DesignAccesObject var1, String var2);

    public abstract int dealCreate(String var1, YP_TCD_DesignAccesObject ... var2);

    public abstract long dealCountQuery(YP_TCD_DesignAccesObject var1, String var2) throws Exception;

    public abstract List<String> dealStringListQuery(YP_TCD_DesignAccesObject var1, String var2);

    public abstract List<Object> dealListQuery(YP_TCD_DesignAccesObject var1, String var2, String var3);

    public abstract int dealBatchInsert(String var1, YP_TCD_DesignAccesObject var2);

    public final String getDataBaseName() {
        return this.dataBaseName;
    }

    public final void setDataBaseName(String string) {
        this.dataBaseName = string;
    }

    public int getSiteIdentifier() {
        if (this.siteIdentifier < 0) {
            this.siteIdentifier = (Integer)this.dataBaseConnectorRow.getFieldValueByName("siteIdentifier");
        }
        return this.siteIdentifier;
    }

    public String getDBC_Path() {
        return this.getDBC_Path(true);
    }

    private String getDBC_Path(boolean bl) {
        if (this.dbc_Path == null) {
            this.dbc_Path = this.dataBaseConnectorRow.getFieldStringValueByName("DBC_Path");
            if (this.dbc_Path != null && this.dbc_Path.isEmpty() && bl) {
                YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                this.getDBC_User();
                List<YP_TCD_DataBaseConnector> list = yP_TCD_DCC_Technique.getDataBaseConnectorList();
                if (this.dbc_User != null && list != null) {
                    String string = null;
                    for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : list) {
                        if (string == null) {
                            string = yP_TCD_DataBaseConnector.getDBC_Path(false);
                            continue;
                        }
                        if (string.contentEquals(yP_TCD_DataBaseConnector.getDBC_Path(false))) continue;
                        string = null;
                        this.logger(2, "getDBC_Path() : path can be left empty only if there is only one path");
                        break;
                    }
                    if (string != null) {
                        this.dbc_Path = string;
                    }
                }
            }
        }
        return this.dbc_Path;
    }

    public String getDBC_Properties() {
        if (this.dbc_Properties == null) {
            this.dbc_Properties = this.dataBaseConnectorRow.getFieldStringValueByName("DBC_Properties");
        }
        return this.dbc_Properties;
    }

    public String getDBC_User() {
        return this.getDBC_User(true);
    }

    private String getDBC_User(boolean bl) {
        if (this.dbc_User == null) {
            YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
            List<YP_TCD_DataBaseConnector> list;
            this.dbc_User = this.dataBaseConnectorRow.getFieldStringValueByName("DBC_User");
            if ((this.dbc_User == null || this.dbc_User.isEmpty()) && bl && (list = (yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique()).getDataBaseConnectorList()) != null && !list.isEmpty()) {
                this.dbc_User = list.get(0).getDBC_User(false);
            }
        }
        return this.dbc_User;
    }

    public byte[] getDBC_UserArray() {
        return this.getDBC_UserArray(true);
    }

    private byte[] getDBC_UserArray(boolean bl) {
        if (this.dbc_UserArray == null) {
            YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
            List<YP_TCD_DataBaseConnector> list;
            this.dbc_UserArray = (byte[])this.dataBaseConnectorRow.getFieldValueByName("DBC_User");
            if ((this.dbc_UserArray == null || this.dbc_UserArray.length == 0) && bl && (list = (yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique()).getDataBaseConnectorList()) != null && !list.isEmpty()) {
                this.dbc_UserArray = list.get(0).getDBC_UserArray(false);
            }
        }
        return this.dbc_UserArray;
    }

    public String getDBC_Password() {
        return this.getDBC_Password(true);
    }

    private String getDBC_Password(boolean bl) {
        if (this.dbc_Password == null) {
            this.dbc_Password = this.dataBaseConnectorRow.getFieldStringValueByName("DBC_Password");
            if ((this.dbc_Password == null || this.dbc_Password.isEmpty()) && bl) {
                YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                this.getDBC_User();
                this.getDBC_Path();
                List<YP_TCD_DataBaseConnector> list = yP_TCD_DCC_Technique.getDataBaseConnectorList();
                if (this.dbc_Path != null && this.dbc_User != null && list != null) {
                    String string;
                    for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : list) {
                        string = yP_TCD_DataBaseConnector.getDBC_Password(false);
                        if (string == null || string.isEmpty() || !this.dbc_Path.contentEquals(yP_TCD_DataBaseConnector.getDBC_Path()) || !this.dbc_User.contentEquals(yP_TCD_DataBaseConnector.getDBC_User())) continue;
                        this.dbc_Password = string;
                        break;
                    }
                    for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : list) {
                        string = yP_TCD_DataBaseConnector.getDBC_Password(false);
                        if (string == null || string.isEmpty() || !this.dbc_User.contentEquals(yP_TCD_DataBaseConnector.getDBC_User())) continue;
                        this.dbc_Password = string;
                        break;
                    }
                }
            }
        }
        return this.dbc_Password;
    }

    public int getConnectorType() {
        if (this.connectorType < 0) {
            this.connectorType = (Integer)this.dataBaseConnectorRow.getFieldValueByName("connectorType");
        }
        return this.connectorType;
    }

    public String getSqlPlugin() {
        return this.getSqlPlugin(true);
    }

    private String getSqlPlugin(boolean bl) {
        if (this.sql_Plugin == null) {
            YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
            List<YP_TCD_DataBaseConnector> list;
            this.sql_Plugin = this.dataBaseConnectorRow.getFieldStringValueByName("sql_Plugin");
            if ((this.sql_Plugin == null || this.sql_Plugin.isEmpty()) && bl && (list = (yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique()).getDataBaseConnectorList()) != null && !list.isEmpty()) {
                this.sql_Plugin = list.get(0).getSqlPlugin(false);
            }
        }
        return this.sql_Plugin;
    }

    public int dealBatchUpdate(String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray, Field[] fieldArray2) {
        return 0;
    }

    public int dealBatchDelete(String string, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field[] fieldArray) {
        return 0;
    }
}

