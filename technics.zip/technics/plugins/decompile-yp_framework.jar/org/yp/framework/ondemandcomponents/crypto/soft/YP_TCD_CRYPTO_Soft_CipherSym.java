/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.soft;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.interfaces.RSAPrivateKey;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_CRYPTO_Soft_CipherSym
implements YP_TCD_CRYPTO_CipherSym_Interface {
    private final String keyStorePassword = "slpc1515";
    private final String keyStorePath = "\\keystore\\secret\\secretKey.keystore";
    private final String KEYSTORETYPE = "JCEKS";
    private final YP_TCD_CRYPTO_Module father;
    private final List<MyCipher> encryptCipherList = new ArrayList<MyCipher>();
    private final ReentrantLock encryptCipherListMutex = new ReentrantLock();
    private final List<MyCipher> decryptCipherList = new ArrayList<MyCipher>();
    private final ReentrantLock decryptCipherListMutex = new ReentrantLock();
    private final int TOKEN_ITERATIONS = 2;
    private final int TOKEN_SALTLENGTH = 10;

    public YP_TCD_CRYPTO_Soft_CipherSym(YP_Object yP_Object) {
        this.father = (YP_TCD_CRYPTO_Module)yP_Object;
    }

    private boolean isSecretKey(String string) {
        if (string == null || string.isEmpty()) {
            return true;
        }
        return !string.startsWith("RSA");
    }

    private Key getKeyValue(String string, String string2) {
        Object object;
        KeyStore keyStore;
        block12: {
            block13: {
                if (string == null || string.isEmpty()) {
                    return null;
                }
                try {
                    FileInputStream fileInputStream;
                    keyStore = KeyStore.getInstance("JCEKS");
                    try {
                        fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + "\\keystore\\secret\\secretKey.keystore");
                    }
                    catch (FileNotFoundException fileNotFoundException) {
                        fileInputStream = null;
                    }
                    keyStore.load(fileInputStream, "slpc1515".toCharArray());
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (this.isSecretKey(string2)) break block12;
                    if (keyStore.containsAlias(string)) break block13;
                    this.father.logger(2, "getKeyValue() " + string + " not found inside " + "\\keystore\\secret\\secretKey.keystore");
                    return null;
                }
                catch (Exception exception) {
                    this.father.logger(2, "getKeyValue()" + exception);
                    return null;
                }
            }
            if (keyStore.isCertificateEntry(string)) {
                return keyStore.getCertificate(string).getPublicKey();
            }
            if (keyStore.isKeyEntry(string)) {
                Key key = keyStore.getKey(string, "slpc1515".toCharArray());
                if (string2.contentEquals("RSA")) {
                    ((RSAPrivateKey)key).getModulus().bitLength();
                }
                return keyStore.getKey(string, "slpc1515".toCharArray());
            }
            this.father.logger(2, "getKeyValue() " + string + " is neither a key or a certificate");
            return null;
        }
        if (!keyStore.containsAlias(string)) {
            this.father.logger(2, "getKeyValue() to remove");
            object = KeyGenerator.getInstance("AES");
            SecretKey secretKey = ((KeyGenerator)object).generateKey();
            keyStore.setKeyEntry(string, secretKey, "slpc1515".toCharArray(), null);
            keyStore.store(new FileOutputStream(String.valueOf(UtilsYP.getPath()) + "\\keystore\\secret\\secretKey.keystore"), "slpc1515".toCharArray());
        }
        object = keyStore.getKey(string, "slpc1515".toCharArray());
        return object;
    }

    private Cipher createCipher(Key key, int n, String string, String string2) {
        try {
            Cipher cipher = Cipher.getInstance(string);
            if (string2 == null) {
                if (string.contentEquals("AES/CBC/PKCS5Padding")) {
                    cipher.init(n, key, new IvParameterSpec(new byte[16]));
                } else if (string.startsWith("DESede/CBC/")) {
                    cipher.init(n, key, new IvParameterSpec(new byte[8]));
                } else {
                    cipher.init(n, key);
                }
            } else {
                cipher.init(n, key, new IvParameterSpec(string2.getBytes()));
            }
            return cipher;
        }
        catch (Exception exception) {
            this.father.logger(2, "createCipher()" + exception);
            return null;
        }
    }

    private MyCipher createCipher(String string, int n, String string2, String string3) {
        Key key;
        block4: {
            try {
                key = this.getKeyValue(string, string2);
                if (key != null) break block4;
                return null;
            }
            catch (Exception exception) {
                this.father.logger(2, "createCipher()" + exception);
                return null;
            }
        }
        Cipher cipher = this.createCipher(key, n, string2, string3);
        int n2 = Integer.MAX_VALUE;
        if (string2.startsWith("RSA")) {
            n2 = ((RSAPrivateKey)key).getModulus().bitLength();
        }
        return new MyCipher(cipher, string2, string, n, 1, n2, string3);
    }

    private int recreateCipher(MyCipher myCipher) {
        try {
            Key key = this.getKeyValue(myCipher.keyLabel, myCipher.algo);
            Cipher cipher = this.createCipher(key, myCipher.opMode, myCipher.algo, myCipher.parameters);
            myCipher.cipher = cipher;
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "recreateCipher()" + exception);
            return 0;
        }
    }

    /*
     * Exception decompiling
     */
    private MyCipher getEncryptCipher(String var1_1, String var2_2, String var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [18[DOLOOP]], but top level block is 5[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private int releaseEncryptCipher(MyCipher myCipher) {
        myCipher.status = 0;
        return 1;
    }

    /*
     * Exception decompiling
     */
    private MyCipher getDecryptCipher(String var1_1, String var2_2, String var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [12[DOLOOP]], but top level block is 3[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private int releaseDecryptCipher(MyCipher myCipher) {
        myCipher.status = 0;
        return 1;
    }

    @Override
    public String[] encrypt(String string, String string2, List<Property> list, String string3, String string4) throws Exception {
        MyCipher myCipher = this.getEncryptCipher(string2, string3, string4);
        if (myCipher == null) {
            this.father.logger(2, "encrypt() not found :" + string2 + " " + string3);
            return null;
        }
        try {
            byte[] byArray = string.getBytes();
            if (byArray.length > myCipher.getMaxCipheredLength()) {
                this.father.logger(2, "encrypt!!! value to encrypt is too big regarding the keylength and algo");
                return null;
            }
            byte[] byArray2 = myCipher.cipher.doFinal(byArray);
            String string5 = UtilsYP.base64Encode(byArray2);
            byte[] byArray3 = myCipher.cipher.getIV();
            if (byArray3 != null) {
                String[] stringArray = new String[]{string5.replace(UtilsYP.lineSeparator, ""), string2, new String(byArray3)};
                String[] stringArray2 = stringArray;
                return stringArray2;
            }
            String[] stringArray = new String[]{string5.replace(UtilsYP.lineSeparator, ""), string2};
            String[] stringArray3 = stringArray;
            return stringArray3;
        }
        catch (Exception exception) {
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseEncryptCipher(myCipher);
        }
    }

    @Override
    public byte[][] encrypt(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        MyCipher myCipher = this.getEncryptCipher(string, string2, string3);
        if (myCipher == null) {
            this.father.logger(2, "encrypt() not found :" + string + " " + string2);
            return null;
        }
        try {
            if (byArray.length > myCipher.getMaxCipheredLength()) {
                this.father.logger(2, "encrypt!!! value to encrypt is too big regarding the keylength and algo");
                return null;
            }
            byte[] byArray2 = myCipher.cipher.doFinal(byArray);
            byte[] byArray3 = myCipher.cipher.getIV();
            if (byArray3 != null) {
                byte[][] byArrayArray = new byte[][]{byArray2, string.getBytes(), byArray3};
                byte[][] byArrayArray2 = byArrayArray;
                return byArrayArray2;
            }
            byte[][] byArrayArray = new byte[][]{byArray2, string.getBytes()};
            byte[][] byArrayArray3 = byArrayArray;
            return byArrayArray3;
        }
        catch (Exception exception) {
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseEncryptCipher(myCipher);
        }
    }

    @Override
    public String[] encryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        MyCipher myCipher = this.getEncryptCipher(string, string2, null);
        if (myCipher == null) {
            this.father.logger(2, "encryptToken() not found :" + string + " " + string2);
            return null;
        }
        try {
            int n;
            StringBuilder stringBuilder = new StringBuilder(10);
            if (string3.length() >= 10) {
                n = 0;
                while (n < 10) {
                    stringBuilder.append(string3.charAt(n));
                    ++n;
                }
            } else {
                n = 0;
                while (n < string3.length()) {
                    stringBuilder.append(string3.charAt(n));
                    ++n;
                }
                while (stringBuilder.length() != 10) {
                    stringBuilder.append("X");
                }
            }
            String string4 = string3;
            int n2 = 0;
            while (n2 < 2) {
                if (string3.length() > myCipher.getMaxCipheredLength()) {
                    this.father.logger(2, "encryptToken!!! value to encrypt is too big regarding the keylength and algo");
                    return null;
                }
                String string5 = stringBuilder + string4;
                byte[] byArray = myCipher.cipher.doFinal(string5.getBytes());
                string4 = UtilsYP.base64Encode(byArray);
                ++n2;
            }
            String[] stringArray = new String[3];
            stringArray[0] = string4.replace(UtilsYP.lineSeparator, "");
            stringArray[1] = string;
            String[] stringArray2 = stringArray;
            return stringArray2;
        }
        catch (Exception exception) {
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseEncryptCipher(myCipher);
        }
    }

    @Override
    public String decryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        MyCipher myCipher = this.getDecryptCipher(string, string2, null);
        if (myCipher == null) {
            this.father.logger(2, "decryptToken() not found :" + string + " " + string2);
            return null;
        }
        try {
            String string4 = null;
            String string5 = string3;
            int n = 0;
            while (n < 2) {
                byte[] byArray = UtilsYP.base64Decode(string5);
                byte[] byArray2 = myCipher.cipher.doFinal(byArray);
                string5 = string4 = new String(byArray2).substring(10);
                ++n;
            }
            String string6 = string4;
            return string6;
        }
        catch (Exception exception) {
            this.father.logger(2, "decryptToken() " + exception);
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseDecryptCipher(myCipher);
        }
    }

    @Override
    public String decrypt(String string, String string2, List<Property> list, String string3, String string4, String string5) throws Exception {
        MyCipher myCipher = this.getDecryptCipher(string2, string3, string4);
        if (myCipher == null) {
            this.father.logger(2, "decrypt() not found :" + string2 + " " + string3);
            return null;
        }
        try {
            String string6;
            byte[] byArray = UtilsYP.base64Decode(string);
            byte[] byArray2 = myCipher.cipher.doFinal(byArray);
            String string7 = string6 = new String(byArray2);
            return string7;
        }
        catch (Exception exception) {
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseDecryptCipher(myCipher);
        }
    }

    @Override
    public byte[] decrypt(byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        MyCipher myCipher = this.getDecryptCipher(string, string2, string3);
        if (myCipher == null) {
            this.father.logger(2, "decrypt() not found :" + string + " " + string2);
            return null;
        }
        try {
            byte[] byArray2 = myCipher.cipher.doFinal(byArray);
            return byArray2;
        }
        catch (Exception exception) {
            this.recreateCipher(myCipher);
            throw exception;
        }
        finally {
            this.releaseDecryptCipher(myCipher);
        }
    }

    @Override
    public int isCryptoSupported(String string) {
        try {
            Cipher.getInstance(string, this.father.getProviderName());
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 3) {
                this.father.logger(3, "isCryptoSupported() algo not supported:" + string + " " + exception);
            }
            return -1;
        }
        return 1;
    }

    @Override
    public int isCipherSymSupported(String string) {
        return this.isCryptoSupported(string);
    }

    @Override
    public int addKey(String string, List<Property> list, byte[] byArray, String string2) throws Exception {
        KeyStore keyStore;
        block16: {
            block18: {
                Key key;
                block17: {
                    if (string == null || string.isEmpty()) {
                        if (this.father.getLogLevel() >= 2) {
                            this.father.logger(2, "addKey() ");
                        }
                        return -1;
                    }
                    if (byArray == null || byArray.length == 0) {
                        if (this.father.getLogLevel() >= 2) {
                            this.father.logger(2, "addKey() ");
                        }
                        return -1;
                    }
                    if (string2 == null || string2.isEmpty()) {
                        if (this.father.getLogLevel() >= 2) {
                            this.father.logger(2, "addKey() ");
                        }
                        return -1;
                    }
                    if (string2.contains("/")) {
                        string2 = string2.substring(0, string2.indexOf(47));
                    }
                    try {
                        keyStore = KeyStore.getInstance("JCEKS");
                        FileInputStream fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + "\\keystore\\secret\\secretKey.keystore");
                        keyStore.load(fileInputStream, "slpc1515".toCharArray());
                        fileInputStream.close();
                        if (!keyStore.containsAlias(string)) break block16;
                        key = keyStore.getKey(string, "slpc1515".toCharArray());
                        if (key.getAlgorithm().contentEquals(string2)) break block17;
                        if (this.father.getLogLevel() >= 2) {
                            this.father.logger(2, "addKey() trying to add same key name with different algo :" + string + ":" + key.getAlgorithm() + " adding " + string2);
                        }
                        return -1;
                    }
                    catch (Exception exception) {
                        if (this.father.getLogLevel() >= 2) {
                            this.father.logger(2, "addKey() " + exception);
                        }
                        throw exception;
                    }
                }
                SecretKeySpec secretKeySpec = new SecretKeySpec(byArray, string2);
                if (((Object)secretKeySpec).equals(key)) break block18;
                if (this.father.getLogLevel() >= 2) {
                    this.father.logger(2, "addKey() trying to add differents key with same name :" + string);
                }
                return -1;
            }
            if (this.father.getLogLevel() >= 3) {
                this.father.logger(3, "addKey() trying to add the same key");
            }
            return 0;
        }
        SecretKeySpec secretKeySpec = new SecretKeySpec(byArray, string2);
        keyStore.setKeyEntry(string, secretKeySpec, "slpc1515".toCharArray(), null);
        keyStore.store(new FileOutputStream(String.valueOf(UtilsYP.getPath()) + "\\keystore\\secret\\secretKey.keystore"), "slpc1515".toCharArray());
        return 1;
    }

    @Override
    public byte[] decryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.decrypt(byArray, string, list, string2, string3, null);
    }

    @Override
    public byte[] translatePIN(byte[] byArray, String string, String string2, String string3, List<Property> list, String string4, String string5, String string6, String string7, List<Property> list2, String string8, String string9) throws Exception {
        throw new Exception("translatePIN() Not done");
    }

    @Override
    public byte[] exportKey(String string, List<Property> list, String string2, List<Property> list2) {
        this.father.logger(2, "exportKey() Not done");
        return null;
    }

    @Override
    public byte[] importKey(String string, String string2, List<Property> list) {
        this.father.logger(2, "importKey() Not done");
        return null;
    }

    @Override
    public byte[][] encryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.encrypt(byArray, string, list, string2, string3);
    }

    private class MyCipher {
        private Cipher cipher;
        private final String algo;
        private final String keyLabel;
        private final String parameters;
        private int keyLength;
        public int status;
        private final int opMode;

        public MyCipher(Cipher cipher, String string, String string2, int n, int n2, int n3, String string3) {
            this.cipher = cipher;
            this.opMode = n;
            this.status = n2;
            this.algo = string;
            this.keyLabel = string2;
            this.keyLength = n3;
            this.parameters = string3;
        }

        public void setMaxCipheredLength(int n) {
            this.keyLength = n;
        }

        public int getMaxCipheredLength() {
            if (this.algo.startsWith("RSA")) {
                return this.keyLength / 8 - 11;
            }
            return Integer.MAX_VALUE;
        }
    }
}

