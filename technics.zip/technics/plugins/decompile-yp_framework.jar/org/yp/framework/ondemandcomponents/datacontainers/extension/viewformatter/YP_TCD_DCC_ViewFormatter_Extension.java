/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnEnum;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCC_ViewFormatter_Extension
extends YP_OnDemandComponent
implements YP_TCD_DCC_Interface_View {
    private YP_TCD_DCC_Technique dataContainer;
    public YP_TCD_DesignAccesObject view;
    public YP_TCD_DesignAccesObject viewColumn;
    public YP_TCD_DesignAccesObject viewColumnEnum;
    public YP_TCD_DesignAccesObject viewColumnCustomization;

    public YP_TCD_DCC_ViewFormatter_Extension(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Technique) {
            this.dataContainer = (YP_TCD_DCC_Technique)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.view = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_View.class, 0, 0, null);
                this.viewColumn = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_ViewColumn.class, 0, 0, null);
                this.viewColumnEnum = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_ViewColumnEnum.class, 0, 0, null);
                this.viewColumnCustomization = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Disk", DAO_ViewColumnCustomization.class, 0, 512, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "initialize()" + exception);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.view) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() view");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumn) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() viewColumn");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnEnum) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() viewColumnEnum");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnCustomization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() viewColumnCustomization");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.view) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() view");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumn) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() viewColumn");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnEnum) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() viewColumnEnum");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnCustomization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() viewColumnCustomization");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.view) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() view");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumn) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() viewColumn");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnEnum) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() viewColumnEnum");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.viewColumnCustomization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() viewColumnCustomization");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionViewFormatter";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public long getIdView(String string) {
        List<YP_Row> list;
        block9: {
            block8: {
                try {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.view);
                    yP_ComplexGabarit.set("viewName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                    list = this.view.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null) break block8;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getIdView() error with view :" + string);
                    }
                    return -1L;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getIdView()" + string + exception);
                    }
                    return -1L;
                }
            }
            if (!list.isEmpty()) break block9;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getIdView() unable to find view :" + string);
            }
            return 0L;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getIdView() too many view found !!! :" + string);
        }
        DAO_View dAO_View = (DAO_View)list.get(0);
        return dAO_View.idView;
    }

    @Override
    public DAO_View getViewRow(String string) {
        List<YP_Row> list;
        block9: {
            block8: {
                try {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.view);
                    yP_ComplexGabarit.set("viewName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                    list = this.view.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null) break block8;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getViewRow() error with view :" + string);
                    }
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getViewRow()" + string + exception);
                    }
                    return null;
                }
            }
            if (!list.isEmpty()) break block9;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getViewRow() unable to find view :" + string);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getViewRow() too many view found !!! :" + string);
        }
        return (DAO_View)list.get(0);
    }

    @Override
    public List<DAO_ViewColumn> getColumns(String string, int n) {
        long l = this.getIdView(string);
        if (l <= 0L) {
            return null;
        }
        return this.getColumns(l, n);
    }

    @Override
    public boolean isWriteAllowed(long l, int n) {
        if (n <= 0) {
            return false;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.view);
        yP_ComplexGabarit.set("idView", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("writeAccessList", YP_ComplexGabarit.OPERATOR.CONTAIN, n);
        List<YP_Row> list = this.view.getRowListSuchAs(yP_ComplexGabarit);
        return list != null && !list.isEmpty();
    }

    @Override
    public List<DAO_ViewColumn> getColumns(long l, int n) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.viewColumn);
        yP_ComplexGabarit.set("idView", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("readAccessList", YP_ComplexGabarit.OPERATOR.CONTAIN, n);
        List<YP_Row> list = this.viewColumn.getRowListSuchAs(yP_ComplexGabarit);
        return list;
    }

    @Override
    public long getIdEnum(long l) {
        List<YP_Row> list;
        block10: {
            block9: {
                try {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.viewColumnEnum);
                    yP_ComplexGabarit.set("idViewColumn", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                    list = this.viewColumnEnum.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null) break block9;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getIdEnum() error with view :" + l);
                    }
                    return -1L;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getIdEnum()" + l + exception);
                    }
                    return -1L;
                }
            }
            if (!list.isEmpty()) break block10;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getIdEnum() unable to find enum of column :" + l);
            }
            if (UtilsYP.getInstanceRole() == 1) {
                YP_Row yP_Row = this.viewColumnEnum.getNewRow();
                yP_Row.set("idViewColumn", l);
                yP_Row.set("idEnum", 0);
                this.viewColumnEnum.addRow(yP_Row, true);
                this.viewColumnEnum.persist();
            }
            return 0L;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getIdEnum() too many view found !!! :" + l);
        }
        DAO_ViewColumnEnum dAO_ViewColumnEnum = (DAO_ViewColumnEnum)list.get(0);
        return dAO_ViewColumnEnum.idEnum;
    }

    @Override
    public List<DAO_ViewColumnCustomization> getColumnCustomization(long l) {
        return this.getColumnCustomization(l, null);
    }

    @Override
    public List<DAO_ViewColumnCustomization> getColumnCustomization(long l, List<DAO_ViewColumn> list) {
        ArrayList<DAO_ViewColumnCustomization> arrayList;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.viewColumnCustomization);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        if (list != null && !list.isEmpty()) {
            arrayList = new ArrayList();
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                arrayList.add((DAO_ViewColumnCustomization)((Object)Long.valueOf(dAO_ViewColumn.idViewColumn)));
            }
            yP_ComplexGabarit.set("idViewColumn", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        }
        arrayList = this.viewColumnCustomization.getRowListSuchAs(yP_ComplexGabarit);
        return arrayList;
    }

    @Override
    public DAO_ViewColumnCustomization createColumnCustomization(long l, long l2) {
        DAO_ViewColumnCustomization dAO_ViewColumnCustomization = (DAO_ViewColumnCustomization)this.viewColumnCustomization.getNewRow();
        dAO_ViewColumnCustomization.idUser = l;
        dAO_ViewColumnCustomization.idViewColumn = l2;
        return dAO_ViewColumnCustomization;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAOColumn() {
        return this.viewColumn;
    }

    @Override
    public List<String> getViewList(int n) {
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            for (YP_Row yP_Row : this.view) {
                DAO_View dAO_View = (DAO_View)yP_Row;
                if (dAO_View.readAccessList == null || !dAO_View.readAccessList.isSet(n)) continue;
                arrayList.add(YP_Row.getStringValue(dAO_View.viewName));
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(3, "getViewList() " + exception);
            return null;
        }
    }
}

