/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.EntryModeEnumeration;

public class DAO_Test10
extends YP_Row {
    @PrimaryKey
    public long idTest10 = 0L;
    public EntryModeEnumeration test10Enumeration;
}

