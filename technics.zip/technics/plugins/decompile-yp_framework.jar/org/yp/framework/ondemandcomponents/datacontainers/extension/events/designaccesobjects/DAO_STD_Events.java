/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.events.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_Events
extends YP_Row {
    @PrimaryKey
    public long idEvents = 0L;
    @Index
    public Timestamp eventSystemGMTTime = new Timestamp(0L);
    public Timestamp eventAppliLocalTime = new Timestamp(0L);
    public byte[] eventName = new byte[50];
    public int status = 0;
    public byte[] datas = new byte[256];
    public int isDeleted = 0;
}

