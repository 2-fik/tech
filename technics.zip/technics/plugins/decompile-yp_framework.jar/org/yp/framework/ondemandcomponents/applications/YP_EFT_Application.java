/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.applications.YP_Print;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.YP_TCD_DCB_STD_Hosts;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public abstract class YP_EFT_Application
extends YP_Application {
    public static final long ALEA_CALL = 1L;
    public static final long ONLINE_ACCEPTOR = 2L;
    public static final long ONLINE_FOR_UPDATE = 4L;
    public static final long ONLINE_TERMINAL = 8L;
    public static final long ONLINE_CARD_ISSUER_SERVICE_CODE = 16L;
    public static final long AMOUNT_ABOVE_FLOOR_LIMIT = 32L;
    public static final long MERCHANT_SUSPICION = 64L;
    public static final long BIN_FORBIDDEN = 128L;
    public static final long CARD_FORBIDDEN = 256L;
    public static final long CUMULATIVE_THRESHOLD = 512L;
    public static final long BIN_WATCHED = 1024L;
    public static final long BIN_UNKNOWN = 2048L;
    public static final long CARD_WATCHED = 4096L;
    public static final long PRE_AUTHORIZATION = 8192L;
    public static final long ONLINE_CARD_ISSUER_FLOW = 16384L;
    public static final long FOREIGN_CURRENCY = 32768L;
    public static final long UNKNOWN_CURRENCY = 65536L;
    public static final long CARD_REFUSED = 131072L;
    public static final long ARQC_CARD = 262144L;
    public static final long PRE_AUTHORIZATION_115 = 524288L;
    public static final long BIN_REFUSED = 0x100000L;
    public static final long REVERSAL = 0x200000L;
    public static final long AMOUNT_ABOVE_CONSULTATION_LIMIT = 0x400000L;
    public static final long AMOUNT_ABOVE_GUARANTEE_LIMIT = 0x800000L;
    public static final long CTCL_MAGSTRIPE = 0x1000000L;
    public static final long SDA_SELECTED = 0x2000000L;

    public YP_EFT_Application(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public YP_TCD_DCC_EFT_Business getDataContainerBusiness() {
        return (YP_TCD_DCC_EFT_Business)this.dataContainerBusiness;
    }

    @Override
    public abstract YP_TCD_DCC_Business getNewDataContainer(YP_Service var1);

    @Override
    public abstract Object dealRequest(YP_Object var1, String var2, Object ... var3);

    @Override
    public abstract int applicationSelection(YP_Object var1, YP_TCD_DCC_Business var2, YP_TCD_DC_Transaction var3);

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int updateCronTable(YP_Object yP_Object, String string, int n) {
        String string2 = this.dataContainerBusiness.getContractIdentifier();
        try {
            String string3;
            Object object;
            Object object2;
            Object object3;
            int n2;
            Cloneable cloneable;
            String string4 = "HOST";
            if (!(string.contentEquals("TLP") || string.contentEquals("TLC") || string.contentEquals("TLM"))) {
                this.logger(2, "updateCronTable() unknown cron type" + string);
                return -1;
            }
            if ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface == null) {
                this.logger(2, "updateCronTable() no host interface !!!");
                return -1;
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters);
            yP_ComplexGabarit.set("name", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                if (n == 0) {
                    this.logger(3, "updateCronTable() no host parameter for " + string);
                    yP_Object.dealRequest(this, "deleteCron", string2, string, string4);
                    return -1;
                }
                this.logger(4, "updateCronTable() no row in host table for " + string);
                return 0;
            }
            if (list.size() > 1) {
                this.logger(3, "updateCronTable() too many rows for " + string);
            }
            YP_Row yP_Row = list.get(0);
            int n3 = (Integer)yP_Row.getFieldValueByName("maxTries");
            int n4 = (Integer)yP_Row.getFieldValueByName("delayInterCallInSec");
            String string5 = yP_Row.getFieldStringValueByName("frequencyInYYMMWWDDHHMMSS");
            String string6 = yP_Row.getFieldStringValueByName("dateToCallCenterAAAAMMJJ");
            String string7 = yP_Row.getFieldStringValueByName("timeToCallCenterHHMMSS");
            int n5 = (Integer)yP_Row.getFieldValueByName("aleaInSec");
            List list2 = (List)yP_Object.dealRequest(this, "getCronList", string2, string, string4);
            if (list2 != null && !list2.isEmpty()) {
                if (list2.size() > 1) {
                    yP_Object.dealRequest(this, "deleteCron", string2, string, string4);
                    list2.clear();
                } else if (n == 1) {
                    cloneable = (YP_Row)list2.get(0);
                    int n6 = (Integer)((YP_Row)cloneable).getFieldValueByName("maxTries");
                    n2 = (Integer)((YP_Row)cloneable).getFieldValueByName("delayInterCallInSec");
                    object3 = ((YP_Row)cloneable).getFieldStringValueByName("frequencyInYYMMWWDDHHMMSS");
                    String string8 = ((YP_Row)cloneable).getFieldStringValueByName("referenceDate");
                    object2 = ((YP_Row)cloneable).getFieldStringValueByName("referenceTime");
                    int n7 = (Integer)((YP_Row)cloneable).getFieldValueByName("aleaInSec");
                    if (n6 == n3 && n2 == n4 && ((String)object3).contentEquals(string5) && string8.contentEquals(string6) && ((String)object2).contentEquals(string7) && n7 == n5) {
                        if (this.getLogLevel() < 4) return 0;
                        this.logger(4, "updateCronTable() nothing to do");
                        return 0;
                    }
                    yP_Object.dealRequest(this, "deleteCron", string2, string, string4);
                    list2.clear();
                    if (this.getLogLevel() >= 3) {
                        this.logger(3, "updateCronTable() something has changed");
                    }
                }
            }
            cloneable = UtilsYP.getSystemGMTTime();
            if (string5.length() == 0 || Long.parseLong(string5) == 0L) {
                object = UtilsYP.getCalendarTime(String.valueOf(string6) + string7);
                if (object != null) {
                    object = this.dataContainerBusiness.timeInterface.getSystemGMTTime(((Calendar)object).getTimeInMillis());
                }
                if (object == null || string6.length() != 8 || string7.length() != 6 || string6.contentEquals("00000000")) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "updateCronTable() invalid date or frequency null, let's delete cron");
                    }
                    if ((n2 = ((Integer)yP_Object.dealRequest(this, "deleteCron", string2, string, string4)).intValue()) == 0) {
                        return 0;
                    }
                    if (n2 == 1) {
                        if (this.getLogLevel() < 4) return 1;
                        this.logger(4, "updateCronTable() cron deleted:" + string);
                        return 1;
                    }
                    if (this.getLogLevel() < 2) return -1;
                    this.logger(2, "updateCronTable() error during cron delete :" + string);
                    return -1;
                }
                if (((Calendar)object).before(cloneable)) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "updateCronTable() invalid date let's delete cron");
                        this.logger(4, "updateCronTable() date appel programme: " + UtilsYP.traceDateAndTime((Calendar)object));
                        this.logger(4, "updateCronTable() date courante: " + UtilsYP.traceDateAndTime((Calendar)cloneable));
                    }
                    if ((n2 = ((Integer)yP_Object.dealRequest(this, "deleteCron", string2, string, string4)).intValue()) == 0) {
                        return 0;
                    }
                    if (n2 == 1) {
                        if (this.getLogLevel() < 4) return 1;
                        this.logger(4, "updateCronTable() cron deleted:" + string);
                        return 1;
                    }
                    if (this.getLogLevel() < 2) return -1;
                    this.logger(2, "updateCronTable() error during cron delete :" + string);
                    return -1;
                }
            } else {
                String string9 = UtilsYP.getAAAAMMJJTime(this.dataContainerBusiness.timeInterface.getAppliGMTTime());
                object = UtilsYP.getCalendarTime(String.valueOf(string9) + string7);
                if (object != null) {
                    object = this.dataContainerBusiness.timeInterface.getSystemGMTTime(((Calendar)object).getTimeInMillis());
                }
                if (((Calendar)object).before(cloneable)) {
                    do {
                        long l;
                        ((Calendar)object).add(1, Integer.parseInt(string5.substring(0, 2)));
                        ((Calendar)object).add(2, Integer.parseInt(string5.substring(2, 4)));
                        ((Calendar)object).add(3, Integer.parseInt(string5.substring(4, 6)));
                        ((Calendar)object).add(6, Integer.parseInt(string5.substring(6, 8)));
                        ((Calendar)object).add(10, Integer.parseInt(string5.substring(8, 10)));
                        ((Calendar)object).add(12, Integer.parseInt(string5.substring(10, 12)));
                        ((Calendar)object).add(13, Integer.parseInt(string5.substring(12, 14)));
                        long l2 = this.dataContainerBusiness.timeInterface.getGMTToAppliOffsetInMS(this.dataContainerBusiness.timeInterface.getAppliGMTTime().getTimeInMillis());
                        long l3 = this.dataContainerBusiness.timeInterface.getGMTToAppliOffsetInMS(this.dataContainerBusiness.timeInterface.getAppliGMTTime(((Calendar)object).getTimeInMillis()).getTimeInMillis());
                        if (l2 == l3) continue;
                        if (this.getLogLevel() >= 3) {
                            this.logger(3, "updateCronTable() the offset changed " + l2 + " " + l3);
                        }
                        if ((l = ((Calendar)object).getTimeInMillis() - l3 + l2) > ((Calendar)cloneable).getTimeInMillis()) {
                            ((Calendar)object).setTimeInMillis(l);
                            continue;
                        }
                        if (this.getLogLevel() < 3) continue;
                        this.logger(3, "updateCronTable() endless loop could have occured without this protection");
                    } while (((Calendar)object).before(cloneable));
                }
                if (string6.compareTo(string9) > 0) {
                    object3 = UtilsYP.getCalendarTime(String.valueOf(string6) + string7);
                    if (object3 != null) {
                        object3 = this.dataContainerBusiness.timeInterface.getSystemGMTTime(((Calendar)object3).getTimeInMillis());
                    }
                    if (((Calendar)object3).after(cloneable) && ((Calendar)object3).before(object)) {
                        object = object3;
                    }
                }
            }
            if (n5 > 0) {
                Random random = new Random();
                long l = random.nextLong() % (long)n5;
                if (l < 0L) {
                    l *= -1L;
                }
                ((Calendar)object).setTimeInMillis(((Calendar)object).getTimeInMillis() + l);
            }
            if ((string3 = this.getTransaction().getDataContainerTransaction().createScheduledRequest(this.dataContainerBusiness, string)) == null) {
                if (this.getLogLevel() < 2) return -1;
                this.logger(2, "updateCronTable() unable to create the request");
                return -1;
            }
            int n8 = 1;
            object2 = new Timestamp(((Calendar)object).getTimeInMillis());
            int n9 = (Integer)yP_Object.dealRequest(this, "updateCronAction", object2, string2, "", string, string4, string6, string7, n5, string5, n4, n8, n3, string3);
            if (n9 == 1) return 0;
            if (this.getLogLevel() < 2) return 0;
            this.logger(2, "updateCronTable() error during update schedule:" + n9);
            return 0;
        }
        catch (Exception exception) {
            if (this.getLogLevel() < 2) return -1;
            this.logger(2, "updateCronTable() error during update schedule: " + exception);
            return -1;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int updateCronTable(String var1_1) {
        try {
            if (this.dataContainerBusiness.getActivationCode().contentEquals("0") && (var2_2 = this.dataContainerBusiness.getContractRow()) != null && (var3_5 = var2_2.getFieldStringValueByName("detailedStatus")).contentEquals("Automatically deactivated (21)")) {
                this.logger(2, "updateCronTable() Not done as application have been automatically deactivated");
                return 0;
            }
            ** GOTO lbl11
        }
        catch (Exception var2_3) {
            try {
                this.logger(2, "updateCronTable() error during deactivation 21 check:" + var2_3);
lbl11:
                // 2 sources

                if ((var2_2 = this.getPluginByName("Scheduler")) == null) {
                    this.logger(2, "updateCronTable() unable to get the scheduler");
                    return -1;
                }
                if (var1_1.contentEquals("TLP")) {
                    this.updateCronTable((YP_Object)var2_2, "TLC", 1);
                    this.updateCronTable((YP_Object)var2_2, "TLM", 1);
                    return this.updateCronTable((YP_Object)var2_2, "TLP", 0);
                }
                if (var1_1.contentEquals("TLC")) {
                    this.updateCronTable((YP_Object)var2_2, "TLP", 1);
                    this.updateCronTable((YP_Object)var2_2, "TLM", 1);
                    return this.updateCronTable((YP_Object)var2_2, "TLC", 0);
                }
                if (var1_1.contentEquals("TLM")) {
                    this.updateCronTable((YP_Object)var2_2, "TLC", 1);
                    this.updateCronTable((YP_Object)var2_2, "TLP", 1);
                    return this.updateCronTable((YP_Object)var2_2, "TLM", 0);
                }
                if (var1_1.contentEquals("NONE")) {
                    this.updateCronTable((YP_Object)var2_2, "TLC", 1);
                    this.updateCronTable((YP_Object)var2_2, "TLP", 1);
                    return this.updateCronTable((YP_Object)var2_2, "TLM", 1);
                }
                this.logger(2, "updateCronTable() unknown cron type" + var1_1);
                return -1;
            }
            catch (Exception var2_4) {
                this.logger(2, "updateCronTable() error during update schedule:" + var2_4);
                return -1;
            }
        }
    }

    protected boolean reprintOneRow(YP_Print yP_Print, YP_Row yP_Row) {
        TransactionTypeEnumeration transactionTypeEnumeration = (TransactionTypeEnumeration)((Object)yP_Row.getFieldValueByName("transactionType"));
        if (transactionTypeEnumeration == null) {
            this.logger(3, "reprintOneRow(): transaction type unknown !!!");
            return false;
        }
        switch (transactionTypeEnumeration) {
            case DEBIT: 
            case REVERSAL_DEBIT: 
            case CREDIT: 
            case QUASI_CASH: 
            case INITIAL_RESERVATION: 
            case ONE_TIME_RESERVATION: 
            case CLOSING_PAYMENT: 
            case COMPLEMENTARY_PAYMENT: 
            case ADVICE_DEBIT: 
            case DEBIT_DIFFERED: 
            case COMPLEMENTARY_REFUND: 
            case REVERSAL_QUASI_CASH: 
            case REFUND_QUASI_CASH: {
                TransactionStatusEnumeration transactionStatusEnumeration = (TransactionStatusEnumeration)((Object)yP_Row.getFieldValueByName("transactionStatus"));
                if (transactionStatusEnumeration == null) {
                    this.logger(3, "reprintOneRow(): transaction status unknown !!!");
                    return false;
                }
                switch (transactionStatusEnumeration) {
                    case ACCEPTED: 
                    case REFUSED: {
                        int n = this.getDataContainerTransaction().getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.ReprintCustomer ? 1 : (this.getDataContainerTransaction().getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Reprint ? 5 : (this.getDataContainerTransaction().getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.ReprintMerchant ? 2 : 2));
                        this.getDataContainerBusiness().loadTransaction(this.getDataContainerTransaction(), yP_Row);
                        String string = yP_Print.ticket(true, n);
                        if (n != 2 && this.getLogLevel() >= 5) {
                            this.logger(5, "reprintOneRow(): " + string);
                        }
                        this.getDataContainerTransaction().setTicket(String.valueOf(this.getDataContainerTransaction().getTicket()) + string);
                        this.getDataContainerTransaction().getTransactionList().add(yP_Row);
                        return true;
                    }
                    case ERROR: 
                    case PENDING: {
                        return false;
                    }
                }
                this.logger(3, "reprintOneRow(): transaction status not handled :" + (Object)((Object)transactionStatusEnumeration));
                return false;
            }
        }
        this.logger(3, "reprintOneRow(): transaction type not handled :" + (Object)((Object)transactionTypeEnumeration));
        return false;
    }

    protected static AcceptationLevelEnumeration getHighestAcceptationLevelEnumeration(YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        EntryModeEnumeration entryModeEnumeration = yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology();
        AcceptationLevelEnumeration acceptationLevelEnumeration = null;
        block8: for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_EFT_Business.selectorList) {
            if (!yP_App_Interface_Selection.canHandle(entryModeEnumeration)) continue;
            AcceptationLevelEnumeration acceptationLevelEnumeration2 = yP_App_Interface_Selection.getAcceptationLevel(yP_TCD_DC_Transaction);
            switch (acceptationLevelEnumeration2) {
                case ACCEPTED: {
                    acceptationLevelEnumeration = AcceptationLevelEnumeration.ACCEPTED;
                    break;
                }
                case WATCHED: {
                    if (acceptationLevelEnumeration != null && acceptationLevelEnumeration == AcceptationLevelEnumeration.ACCEPTED) continue block8;
                    acceptationLevelEnumeration = AcceptationLevelEnumeration.WATCHED;
                    break;
                }
                case FORBIDDEN: {
                    if (acceptationLevelEnumeration != null && (acceptationLevelEnumeration == AcceptationLevelEnumeration.ACCEPTED || acceptationLevelEnumeration == AcceptationLevelEnumeration.WATCHED)) continue block8;
                    acceptationLevelEnumeration = AcceptationLevelEnumeration.FORBIDDEN;
                    break;
                }
                case REFUSED: {
                    if (acceptationLevelEnumeration != null && (acceptationLevelEnumeration == AcceptationLevelEnumeration.ACCEPTED || acceptationLevelEnumeration == AcceptationLevelEnumeration.WATCHED || acceptationLevelEnumeration == AcceptationLevelEnumeration.FORBIDDEN)) continue block8;
                    acceptationLevelEnumeration = AcceptationLevelEnumeration.REFUSED;
                    break;
                }
                case UNKNOWN: {
                    if (acceptationLevelEnumeration != null && (acceptationLevelEnumeration == AcceptationLevelEnumeration.ACCEPTED || acceptationLevelEnumeration == AcceptationLevelEnumeration.WATCHED || acceptationLevelEnumeration == AcceptationLevelEnumeration.FORBIDDEN || acceptationLevelEnumeration == AcceptationLevelEnumeration.REFUSED)) continue block8;
                    acceptationLevelEnumeration = AcceptationLevelEnumeration.UNKNOWN;
                    break;
                }
                case REJECTED: {
                    yP_TCD_DCC_EFT_Business.logger(4, "getHighestAcceptationLevelEnumeration() No need to go further as a selector as rejected the transaction");
                    return null;
                }
                default: {
                    yP_TCD_DCC_EFT_Business.logger(2, "getHighestAcceptationLevelEnumeration() Level not handled:" + (Object)((Object)acceptationLevelEnumeration2));
                }
            }
        }
        return acceptationLevelEnumeration;
    }
}

