/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.appselectors;

import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;

public interface YP_App_Interface_Selection {
    public AcceptationLevelEnumeration getAcceptationLevel(YP_TCD_DC_Transaction var1);

    public boolean canHandle(EntryModeEnumeration var1);

    public int shutdown();
}

