/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Update;

public class UpdateHandler
implements HandlerInterface {
    YP_TCD_DC_Transaction dataContainerTransaction;
    private List<ParameterFile> v_ParameterFileList;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        if (this.v_ParameterFileList != null) {
            this.v_ParameterFileList.clear();
        }
        return 1;
    }

    @Override
    public int clear() {
        return 1;
    }

    public UpdateHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    @Override
    public int readRequest() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Update)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with update");
            }
            return 0;
        }
        YP_PROT_Update yP_PROT_Update = (YP_PROT_Update)((Object)yP_TCD_PosProtocol);
        this.v_ParameterFileList = yP_PROT_Update.getParameterFileList(this);
        return 1;
    }

    @Override
    public int prepareResponse() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Update)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with update");
            }
            return 0;
        }
        YP_PROT_Update yP_PROT_Update = (YP_PROT_Update)((Object)yP_TCD_PosProtocol);
        if (this.v_ParameterFileList != null) {
            yP_PROT_Update.setParameterFileList(this.v_ParameterFileList);
        }
        return 0;
    }

    @Override
    public int load(YP_Row yP_Row) {
        return 0;
    }

    @Override
    public int persist() {
        return 0;
    }

    public List<ParameterFile> getParameterFileList() {
        return this.v_ParameterFileList;
    }

    public void setParameterFileList(List<ParameterFile> list) {
        this.v_ParameterFileList = list;
    }

    public class HeaderParameterFile {
        public String tableName;
        public String tableVersion;
        public String creationTimestamp;
        public String checksumAlgorithm;
        public String checksum;
        public String status;
    }

    public class ParameterFile {
        public HeaderParameterFile headerParameterFile;
        public List<String> appTagsList;

        public ParameterFile() {
            this.headerParameterFile = new HeaderParameterFile();
            this.appTagsList = new ArrayList<String>();
        }
    }
}

