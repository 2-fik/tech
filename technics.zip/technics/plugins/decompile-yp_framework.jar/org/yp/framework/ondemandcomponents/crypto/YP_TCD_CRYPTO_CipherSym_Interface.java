/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import java.util.List;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Interface;
import org.yp.xml.jaxb.ypproperties.Property;

public interface YP_TCD_CRYPTO_CipherSym_Interface
extends YP_TCD_CRYPTO_Interface {
    public String[] encrypt(String var1, String var2, List<Property> var3, String var4, String var5) throws Exception;

    public byte[][] encrypt(byte[] var1, String var2, List<Property> var3, String var4, String var5) throws Exception;

    public byte[][] encryptPIN(byte[] var1, String var2, List<Property> var3, String var4, String var5) throws Exception;

    public String decrypt(String var1, String var2, List<Property> var3, String var4, String var5, String var6) throws Exception;

    public byte[] decrypt(byte[] var1, String var2, List<Property> var3, String var4, String var5, String var6) throws Exception;

    public byte[] decryptPIN(byte[] var1, String var2, List<Property> var3, String var4, String var5) throws Exception;

    public String[] encryptToken(String var1, List<Property> var2, String var3, String var4) throws Exception;

    public String decryptToken(String var1, List<Property> var2, String var3, String var4) throws Exception;

    public int addKey(String var1, List<Property> var2, byte[] var3, String var4) throws Exception;

    public int isCipherSymSupported(String var1);

    public byte[] translatePIN(byte[] var1, String var2, String var3, String var4, List<Property> var5, String var6, String var7, String var8, String var9, List<Property> var10, String var11, String var12) throws Exception;

    public byte[] exportKey(String var1, List<Property> var2, String var3, List<Property> var4);

    public byte[] importKey(String var1, String var2, List<Property> var3);
}

