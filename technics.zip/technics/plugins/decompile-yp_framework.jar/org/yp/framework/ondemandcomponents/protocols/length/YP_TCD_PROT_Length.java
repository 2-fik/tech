/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.length;

import java.util.Arrays;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.services.YP_TS_GlobalProcessManager;

public class YP_TCD_PROT_Length
extends YP_OnDemandComponent
implements YP_PROT_Interface_Com {
    private static final int DEFAULT_TNR_MS = 30000;
    private static final int DEFAULT_TSI_MS = 90000;
    private static final int DEFAULT_TMA_MS = 90000;
    private YP_PHYS_Interface physicalInterface;
    private int physicalInterfaceToShutdown = 0;
    private int lengthPrefix = 2;
    private int tnrMS = 30000;
    private int tsiMS = 90000;
    private int tmaMS = 90000;
    private byte[] ipduBuffer = new byte[10000];
    private byte[] apduBuffer;
    private byte[] tempoBuffer;
    private YP_PROT_Interface_Com.ComStateMachine myState;
    private boolean timeoutOccured = false;
    private String timerName = null;
    private long timeoutTime = 0L;

    public YP_TCD_PROT_Length(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PHYS_Interface) {
            this.physicalInterface = (YP_PHYS_Interface)objectArray[0];
        }
    }

    @Override
    public int setParameters(Object ... objectArray) {
        if (objectArray == null || objectArray.length < 1) {
            this.logger(2, "setParameters() missing parameters");
            return -1;
        }
        this.lengthPrefix = (Integer)objectArray[0];
        if (this.lengthPrefix != 2 && this.lengthPrefix != 4) {
            this.logger(2, "setParameters() length must be 2 or 4");
            return -1;
        }
        if (objectArray.length > 4) {
            this.tnrMS = (Integer)objectArray[4];
        }
        if (objectArray.length > 5) {
            this.tsiMS = (Integer)objectArray[5];
        }
        if (objectArray.length > 6) {
            this.tmaMS = (Integer)objectArray[6];
        }
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        return 1;
    }

    private boolean isTimeoutOccured() {
        if (this.timeoutTime != 0L && System.currentTimeMillis() > this.timeoutTime) {
            System.out.println("Time's up!: " + this.timerName);
            this.timeoutOccured = true;
        }
        return this.timeoutOccured;
    }

    private void resetTimer() {
        this.timeoutOccured = false;
        this.timerName = null;
        this.timeoutTime = 0L;
    }

    private void setTimer(String string) {
        this.timeoutOccured = false;
        this.timerName = string;
        this.timeoutTime = 0L;
        if (string.compareTo("TNR") == 0) {
            this.timeoutTime = System.currentTimeMillis() + (long)this.tnrMS;
        }
        if (string.compareTo("TSI") == 0) {
            this.timeoutTime = System.currentTimeMillis() + (long)this.tsiMS;
        }
        if (string.compareTo("TGR") == 0) {
            this.timeoutTime = System.currentTimeMillis() + (long)this.tmaMS;
        }
    }

    private byte[] ipduCode(byte[] byArray, int n) {
        byte[] byArray2 = new byte[n + this.lengthPrefix];
        if (this.lengthPrefix == 2) {
            byArray2[0] = (byte)(n + this.lengthPrefix >> 8 & 0xFF);
            byArray2[1] = (byte)(n + this.lengthPrefix & 0xFF);
        } else if (this.lengthPrefix == 4) {
            byArray2[0] = (byte)(n + this.lengthPrefix >> 24 & 0xFF);
            byArray2[1] = (byte)(n + this.lengthPrefix >> 16 & 0xFF);
            byArray2[2] = (byte)(n + this.lengthPrefix >> 8 & 0xFF);
            byArray2[3] = (byte)(n + this.lengthPrefix & 0xFF);
        }
        System.arraycopy(byArray, 0, byArray2, this.lengthPrefix, n);
        return byArray2;
    }

    private int ipduDecode(byte[] byArray, int n) {
        if (n < this.lengthPrefix) {
            this.logger(3, "ipduDecode() trame incomplete");
            return 0;
        }
        int n2 = 0;
        int n3 = 0;
        while (n3 < this.lengthPrefix) {
            n2 |= (byArray[n3] & 0xFF) << (this.lengthPrefix - 1 - n3) * 8;
            ++n3;
        }
        if (n2 > n) {
            this.logger(3, "ipduDecode() trame incomplete :" + n2 + " vs " + n);
            return 0;
        }
        this.apduBuffer = new byte[n2 - this.lengthPrefix];
        System.arraycopy(byArray, this.lengthPrefix, this.apduBuffer, 0, this.apduBuffer.length);
        if (n2 == n) {
            return 1;
        }
        this.tempoBuffer = new byte[n - n2];
        System.arraycopy(byArray, n2, this.tempoBuffer, 0, this.tempoBuffer.length);
        return 2;
    }

    @Override
    public int waitConnection() {
        this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
        this.setTimer("TSI");
        return 1;
    }

    @Override
    public int connect(YP_Row yP_Row) {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.WAIT_CONNECTION) {
            return 0;
        }
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 1;
        }
        if (this.physicalInterface != null) {
            return 0;
        }
        try {
            YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
            this.physicalInterface = (YP_PHYS_Interface)yP_Service.dealRequest(this, "openConnection", yP_Row);
            if (this.physicalInterface == null) {
                this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
            return -1;
        }
        this.physicalInterfaceToShutdown = 1;
        this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
        return 1;
    }

    @Override
    public void send(byte[] byArray, boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException {
        byte[] byArray2 = this.ipduCode(byArray, byArray.length);
        int n = this.physicalInterface.send(byArray2, byArray2.length);
        if (n < 0) {
            this.logger(2, "send() broken connection");
            throw new YP_PROT_Interface_Com.DisconnectionException();
        }
        this.resetTimer();
        if (bl) {
            this.setTimer("TNR");
        } else {
            this.setTimer("TSI");
        }
    }

    @Override
    public byte[] receive(boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException, YP_PROT_Interface_Com.BadFormatException {
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
            this.logger(2, "receive() not connected !!!");
            return null;
        }
        int n = 0;
        int n2 = 0;
        if (this.timeoutTime == 0L) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "receive() no TimeOut specified, let's use one !!!");
            }
            if (bl) {
                this.setTimer("TSI");
            } else {
                this.setTimer("TNR");
            }
        }
        if (this.tempoBuffer != null) {
            if (this.ipduBuffer.length < this.tempoBuffer.length + 10000) {
                this.ipduBuffer = new byte[this.tempoBuffer.length + 10000];
            }
            System.arraycopy(this.tempoBuffer, 0, this.ipduBuffer, 0, this.tempoBuffer.length);
            n2 = this.tempoBuffer.length;
            this.tempoBuffer = null;
            n = this.ipduDecode(this.ipduBuffer, n2);
        }
        while (n == 0) {
            Object object;
            int n3 = 0;
            while (!this.isTimeoutOccured() && n3 == 0) {
                if (this.ipduBuffer.length < n2 + 10000) {
                    object = this.ipduBuffer;
                    this.ipduBuffer = Arrays.copyOf(object, n2 + 10000);
                }
                n3 = this.physicalInterface.recv(this.ipduBuffer, n2, this.ipduBuffer.length - n2, 300000);
            }
            if (this.timeoutOccured && n3 == 0) {
                this.logger(2, "receive() TimeOut " + this.timerName);
                object = new YP_PROT_Interface_Com.TimeOutException();
                object.timerName = this.timerName;
                this.resetTimer();
                throw object;
            }
            if (n3 < 0) {
                this.logger(2, "receive() broken connection");
                throw new YP_PROT_Interface_Com.DisconnectionException();
            }
            if (n3 == 0) {
                this.logger(2, "receive() TimeOut");
                return new byte[0];
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "receive() Received Data: " + n3);
            }
            n = this.ipduDecode(this.ipduBuffer, n2 += n3);
        }
        this.resetTimer();
        if (n < 0) {
            this.logger(2, "receive() reception pb");
            throw new YP_PROT_Interface_Com.BadFormatException();
        }
        if (bl) {
            this.setTimer("TGR");
        }
        return this.apduBuffer;
    }

    @Override
    public int disconnect() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 0;
        }
        this.resetTimer();
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        this.resetTimer();
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public String toString() {
        return "LENGTHPROTOCOL";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String getParameter(String string) {
        return null;
    }

    @Override
    public int waitDisconnection() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 1;
        }
        this.myState = YP_PROT_Interface_Com.ComStateMachine.WAIT_DISCONNECTION;
        int n = 0;
        this.setTimer("TNR");
        while (!this.isTimeoutOccured()) {
            n = 0;
            while (!this.isTimeoutOccured() && n == 0) {
                n = this.physicalInterface.recv(this.ipduBuffer, 0, this.ipduBuffer.length, 3000);
            }
            if (n < 0) {
                this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
                return 1;
            }
            if (this.isTimeoutOccured()) {
                this.resetTimer();
                this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
                return 1;
            }
            this.logger(3, "waitDisconnection() message trashed");
        }
        this.resetTimer();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "waitDisconnection() disconnected");
        }
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        return 1;
    }

    @Override
    public int setComParameter(String string, String string2) {
        return 0;
    }
}

