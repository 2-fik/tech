/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_User;

public class UserHandler
implements HandlerInterface {
    YP_TCD_DC_Transaction dataContainerTransaction;
    private YP_Row currentUserRow;
    private long t_UserIdentifier = 0L;
    private long v_UserFatherIdentifier = 0L;
    private String v_UserUID = "";
    private String v_UserPasswd = "";
    private String v_NewPasswd = "";
    private String v_UserToken = "";
    private String v_UserPreferredLanguage = "";
    private String v_UserFirstName = "";
    private String v_UserLastName = "";
    private int v_UserAccessLevel = 0;
    private String v_UserMessage = "";
    private String v_PermanentToken = "";
    private Boolean v_vadAllowed = false;
    private Boolean v_merchantTicketAllowed = false;
    private Boolean v_cashierCreationAllowed = false;
    public List<YP_Row> userParameters;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        return 1;
    }

    @Override
    public int clear() {
        return 1;
    }

    public UserHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public void setUserIdentifier(long l) {
        this.t_UserIdentifier = l;
    }

    public long getUserIdentifier() {
        return this.t_UserIdentifier;
    }

    public void setUserFatherIdentifier(long l) {
        this.v_UserFatherIdentifier = l;
    }

    public long getUserFatherIdentifier() {
        return this.v_UserFatherIdentifier;
    }

    public String getUserUID() {
        return this.v_UserUID;
    }

    public void setUserUID(String string) {
        if (string != null) {
            string = string.trim();
        }
        this.v_UserUID = string;
    }

    public String getUserPasswd() {
        return this.v_UserPasswd;
    }

    public void setUserPasswd(String string) {
        this.v_UserPasswd = string;
    }

    public String getNewPasswd() {
        return this.v_NewPasswd;
    }

    public void setNewPasswd(String string) {
        this.v_NewPasswd = string;
    }

    public String getUserToken() {
        return this.v_UserToken;
    }

    public void setUserToken(String string) {
        this.v_UserToken = string;
    }

    public String getUserPreferredLanguage() {
        return this.v_UserPreferredLanguage;
    }

    public void setUserPreferredLanguage(String string) {
        this.v_UserPreferredLanguage = string;
    }

    public int getUserAccessLevel() {
        return this.v_UserAccessLevel;
    }

    public void setUserAccessLevel(int n) {
        this.v_UserAccessLevel = n;
    }

    public String getUserFirstName() {
        return this.v_UserFirstName;
    }

    public void setUserFirstName(String string) {
        this.v_UserFirstName = string;
    }

    public String getUserLastName() {
        return this.v_UserLastName;
    }

    public void setUserLastName(String string) {
        this.v_UserLastName = string;
    }

    public Boolean isVadAllowed() {
        return this.v_vadAllowed != null ? this.v_vadAllowed : false;
    }

    public void setVadAllowed(Boolean bl) {
        this.v_vadAllowed = bl;
    }

    public Boolean isMerchantTicketAllowed() {
        return this.v_merchantTicketAllowed != null ? this.v_merchantTicketAllowed : false;
    }

    public void setMerchantTicketAllowed(Boolean bl) {
        this.v_merchantTicketAllowed = bl;
    }

    public Boolean isCashierCreationAllowed() {
        return this.v_cashierCreationAllowed != null ? this.v_cashierCreationAllowed : false;
    }

    public void setCashierCreationAllowed(Boolean bl) {
        this.v_cashierCreationAllowed = bl;
    }

    @Override
    public int readRequest() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_User)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with user");
            }
            return 0;
        }
        YP_PROT_User yP_PROT_User = (YP_PROT_User)((Object)yP_TCD_PosProtocol);
        this.setUserUID(yP_PROT_User.getUserUID());
        this.setUserPasswd(yP_PROT_User.getUserPasswd());
        this.setUserToken(yP_PROT_User.getUserToken());
        this.setUserPreferredLanguage(yP_PROT_User.getUserPreferredLanguage());
        this.setUserFirstName(yP_PROT_User.getUserFirstName());
        this.setUserLastName(yP_PROT_User.getUserLastName());
        this.setNewPasswd(yP_PROT_User.getNewPasswd());
        return 1;
    }

    @Override
    public int prepareResponse() {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_User)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with user");
            }
            return 0;
        }
        YP_PROT_User yP_PROT_User = (YP_PROT_User)((Object)yP_TCD_PosProtocol);
        String string6 = this.getUserUID();
        if (string6 != null && !string6.isEmpty()) {
            yP_PROT_User.setUserUID(string6);
        }
        if ((string5 = this.getUserToken()) != null && !string5.isEmpty()) {
            yP_PROT_User.setUserToken(string5);
        }
        if ((string4 = this.getUserPreferredLanguage()) != null && !string4.isEmpty()) {
            yP_PROT_User.setUserPreferredLanguage(string4);
        }
        if ((string3 = this.getUserFirstName()) != null && !string3.isEmpty()) {
            yP_PROT_User.setUserFirstName(string3);
        }
        if ((string2 = this.getUserLastName()) != null && !string2.isEmpty()) {
            yP_PROT_User.setUserLastName(string2);
        }
        if ((string = this.getUserMessage()) != null && !string.isEmpty()) {
            yP_PROT_User.setUserMessage(string);
        }
        if (this.dataContainerTransaction.getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Login && this.userParameters != null) {
            Iterator<YP_Row> iterator = this.userParameters.iterator();
            while (iterator.hasNext()) {
                iterator.next();
            }
        }
        return 0;
    }

    @Override
    public int load(YP_Row yP_Row) {
        this.dataContainerTransaction.logger(2, "load() TODO !!!");
        return 0;
    }

    private int fillCurrentUserRow() {
        block3: {
            try {
                if (this.currentUserRow != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        this.currentUserRow.set("idUser", this.getUserIdentifier());
        return 1;
    }

    private int unMapCurrentUserRow() {
        block3: {
            try {
                if (this.currentUserRow != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        this.setUserIdentifier((Long)this.currentUserRow.getFieldValueByName("idCustomer"));
        return 1;
    }

    @Override
    public int persist() {
        if (this.currentUserRow != null) {
            this.fillCurrentUserRow();
            return 1;
        }
        if (this.dataContainerTransaction.getLogLevel() >= 2) {
            this.dataContainerTransaction.logger(2, "persist() TODO");
        }
        return 0;
    }

    public String getUserMessage() {
        return this.v_UserMessage;
    }

    public void setUserMessage(String string) {
        this.v_UserMessage = string;
    }

    public String getPermanentToken() {
        return this.v_PermanentToken;
    }

    public void setPermanentToken(String string) {
        this.v_PermanentToken = string;
    }
}

