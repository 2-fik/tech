/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import java.util.Random;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_ThreeDSecureEvent;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.threeds.PAReq;
import org.yp.xml.jaxb.threeds.PARes;
import org.yp.xml.jaxb.threeds.ThreeDSecure;
import org.yp.xml.jaxb.threeds.VEReq;
import org.yp.xml.jaxb.threeds.VERes;

public class YP_TCD_PROT_ThreeDSecure_Host_Auto
extends YP_OnDemandComponent {
    private YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine stateMachineThreeDS;
    private YP_TCD_PROT_ThreeDSecure protocolThreeDS = null;
    private YP_TCD_DCC_Business dataContainerBusiness = null;
    private YP_TCD_DC_Transaction dataContainerTransaction = null;
    private String PANReceived;
    private YP_ThreeDSecureEvent eventThreeDS;

    public YP_TCD_PROT_ThreeDSecure_Host_Auto(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine) {
            this.stateMachineThreeDS = (YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine)yP_Object;
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_TCD_DCC_Business) {
                this.dataContainerBusiness = (YP_TCD_DCC_Business)objectArray[0];
            }
            if (objectArray != null && objectArray.length > 1 && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                this.dataContainerTransaction = (YP_TCD_DC_Transaction)objectArray[1];
            }
            if (objectArray != null && objectArray.length > 2 && objectArray[2] instanceof YP_TCD_PROT_ThreeDSecure) {
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)objectArray[2];
            }
            if (objectArray != null && objectArray.length > 3 && objectArray[3] instanceof YP_ThreeDSecureEvent) {
                this.eventThreeDS = (YP_ThreeDSecureEvent)objectArray[3];
            }
        }
    }

    @Override
    public String toString() {
        return "THREEDSECURE_HOST_AUTO";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public void YP_ThreeDSAutoReceive() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.autoAnswer);
        switch (this.protocolThreeDS.YP_Receive()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSAutoReceive() message received");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSAutoReceive() nothing received ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSAutoReceive() Something wrong has been received ");
                return;
            }
            case -2: {
                this.logger(2, "YP_ThreeDSAutoReceive() The state is not correct ");
                return;
            }
            case -3: {
                this.logger(2, "YP_ThreeDSAutoReceive() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSAutoReceive() unknown status");
                return;
            }
        }
    }

    public void YP_ThreeDSAutoAnalyseResponse() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepKo);
        this.stateMachineThreeDS.getProtocolInterface().objectFactoryToTransactionsData(this.protocolThreeDS, this.stateMachineThreeDS.getServiceRequested());
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.RepOk);
    }

    public void YP_ThreeDSAutoEnd() {
        this.protocolThreeDS.YP_Disconnect();
    }

    public void YP_ThreeDSAnswerAuto() {
        this.eventThreeDS.setEventThreeDS(YP_ThreeDSecureEvent.THREEDSEVENT.autoEnd);
        this.YP_PrepareAutoResponseData();
        switch (this.protocolThreeDS.YP_Send()) {
            case 1: {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "YP_ThreeDSAutoProcess() message sent");
                break;
            }
            case 0: {
                this.logger(2, "YP_ThreeDSAutoProcess() Nothing has been sent ( a timeout has expired) ");
                return;
            }
            case -1: {
                this.logger(2, "YP_ThreeDSAutoProcess() The connection is dead ");
                return;
            }
            default: {
                this.logger(2, "YP_ThreeDSAutoProcess() unknown status");
                return;
            }
        }
    }

    private int YP_PrepareAutoResponseData() {
        ThreeDSecure threeDSecure = this.protocolThreeDS.YP_GetReceiveFactoryObject();
        VEReq vEReq = threeDSecure.getMessage().get(0).getVEReq();
        if (vEReq != null) {
            ThreeDSecure threeDSecure2 = this.protocolThreeDS.YP_GetNewSendFactoryObject("/technics/xml/threeds/veres.xml");
            VERes vERes = threeDSecure2.getMessage().get(0).getVERes();
            this.PANReceived = threeDSecure.getMessage().get(0).getVEReq().getPan();
            if (this.PANReceived.length() > 4) {
                byte[] byArray = new byte[this.PANReceived.length() - 4];
                int n = 0;
                while (n < this.PANReceived.length() - 4) {
                    byArray[n] = 48;
                    ++n;
                }
                this.PANReceived = String.valueOf(new String(byArray)) + this.PANReceived.substring(this.PANReceived.length() - 4, this.PANReceived.length());
            }
            vERes.setVersion(threeDSecure.getMessage().get(0).getVEReq().getVersion());
            vERes.getCH().setEnrolled("Y");
            vERes.getCH().setAcctID("4444333322221111");
            vERes.setUrl("https://testserver.datacash.com/acs");
            vERes.setUrl("https://acs-3dsecure.creditmutuel.fr");
            vERes.setUrl("credit_mutuel.php");
            vERes.setUrl("http://192.168.1.28/3DS/");
            vERes.setUrl("http://127.0.0.1:8080/YPPAReq/PaReq");
            vERes.getProtocol().set(0, "ThreeDSecure");
            threeDSecure2.getMessage().get(0).setId("ve.40543951");
        } else {
            PAReq pAReq = threeDSecure.getMessage().get(0).getPAReq();
            if (pAReq != null) {
                ThreeDSecure threeDSecure3 = this.protocolThreeDS.YP_GetNewSendFactoryObject("/technics/xml/threeds/pares.xml");
                PARes pARes = threeDSecure3.getMessage().get(0).getPARes();
                pARes.setVersion("1.0.2");
                Random random = new Random();
                String string = "pa." + Integer.toString(random.nextInt(Integer.MAX_VALUE));
                string = string.replaceAll("-", "0");
                threeDSecure3.getMessage().get(0).setId(string);
                pARes.setId(String.valueOf(string) + ".signed");
                pARes.getMerchant().setAcqBIN(pAReq.getMerchant().getAcqBIN());
                pARes.getMerchant().setMerID(pAReq.getMerchant().getMerID());
                pARes.getPurchase().setXid(pAReq.getPurchase().getXid());
                pARes.getPurchase().setDate(pAReq.getPurchase().getDate());
                pARes.getPurchase().setPurchAmount(pAReq.getPurchase().getPurchAmount());
                pARes.getPurchase().setCurrency(pAReq.getPurchase().getCurrency());
                pARes.getPurchase().setExponent(pAReq.getPurchase().getExponent());
                if (!this.PANReceived.isEmpty()) {
                    pARes.setPan(this.PANReceived);
                }
                String string2 = UtilsYP.getAAAAMMJJHHMMSSTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                pARes.getTX().setTime(String.valueOf(string2.substring(0, 8)) + " " + string2.substring(8, 10) + ":" + string2.substring(10, 12) + ":" + string2.substring(12, 14));
                pARes.getTX().setStatus("Y");
                pARes.getTX().setCavv("AAABBJg0VhI0VniQEjRWAAAAAAA=".getBytes());
                pARes.getTX().setEci("03");
                pARes.getTX().setCavvAlgorithm("2");
                this.protocolThreeDS.YP_FormatAndSendPARes(threeDSecure3);
            }
        }
        return 1;
    }
}

