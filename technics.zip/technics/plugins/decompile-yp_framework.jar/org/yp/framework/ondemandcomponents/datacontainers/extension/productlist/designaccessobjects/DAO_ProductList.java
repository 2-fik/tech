/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.designaccessobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ProductList
extends YP_Row {
    @PrimaryKey
    public long idDAO_ProductList = 0L;
    public byte[] emvApplicationAID = new byte[32];
    public byte[] startBIN = new byte[19];
    public byte[] endBIN = new byte[19];
    public byte[] electronicProductIdentification = new byte[4];
    public byte[] codeProduit = new byte[10];
    public byte[] libelleProduit = new byte[50];
    public byte[] action = new byte[20];
    public byte[] reserved = new byte[20];
    public byte[] externalReference = new byte[30];
}

