/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Enumeration
extends YP_Row {
    @PrimaryKey
    public long idEnumeration = 0L;
    public byte[] enumerationName = new byte[32];
}

