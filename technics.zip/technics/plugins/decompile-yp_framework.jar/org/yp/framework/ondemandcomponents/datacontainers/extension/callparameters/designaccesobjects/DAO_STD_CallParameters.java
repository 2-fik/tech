/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_CallParameters
extends YP_Row {
    @PrimaryKey
    public long idCallParameters = 0L;
    public long thresholdCall = 0L;
    public int numericalCurrencyCode = 0;
    public int reduceCallCoefficient = 0;
    public byte[] validationMode = new byte[1];
    public byte[] startTimeHHMM = new byte[4];
    public byte[] endTimeHHMM = new byte[4];
    public byte[] externalReference = new byte[30];
}

