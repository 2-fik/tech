/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.rawtlv;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.rawtlv.RawTLVMessageObject;
import org.yp.framework.ondemandcomponents.protocols.rawtlv.YP_RawTLVException;
import org.yp.framework.ondemandcomponents.protocols.rawtlv.YP_RawTLVUtils;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.rawtlv.RawTLVField;
import org.yp.xml.jaxb.rawtlv.RawTLVFieldPresence;
import org.yp.xml.jaxb.rawtlv.RawTLVFieldTraceType;
import org.yp.xml.jaxb.rawtlv.RawTLVMessage;
import org.yp.xml.jaxb.rawtlv.RawTLVMessageDirection;
import org.yp.xml.jaxb.rawtlv.RawTLVMessageInfo;
import org.yp.xml.jaxb.rawtlv.RawTLVPresence;
import org.yp.xml.jaxb.rawtlv.RawTLVTLVElement;
import org.yp.xml.jaxb.rawtlv.RawTLVTLVPresence;
import org.yp.xml.jaxb.rawtlv.RawTLVTLVStructure;

public class YP_TCD_PROT_RawTLV
extends YP_OnDemandComponent {
    private long parsingTimeInNano = 0L;
    private long formatTimeInNano = 0L;
    private StringBuilder tlvReceivedOrder = new StringBuilder("");
    private YP_GlobalComponent parserXML = null;
    public RawTLVStateMachine myState = RawTLVStateMachine.DISCONNECTED;
    private YP_PROT_Interface_Com myIpduLayer;
    private byte[] apduBuffer;
    private final Map<String, RawTLVPresence> rawTLVSendPresenceObjectList = new HashMap<String, RawTLVPresence>();
    private final Map<String, RawTLVPresence> rawTLVReceivePresenceObjectList = new HashMap<String, RawTLVPresence>();
    private RawTLVPresence myRawTLVSendPresence;
    private RawTLVPresence myRawTLVReceivePresence;
    private static List<RawTLVMessageObject> rawTLVSendMessageObjectList = new ArrayList<RawTLVMessageObject>();
    private static final ReentrantLock rawTLVSendMessageObjectListMutex = new ReentrantLock();
    private static List<RawTLVMessageObject> rawTLVReceiveMessageObjectList = new ArrayList<RawTLVMessageObject>();
    private static final ReentrantLock rawTLVReceiveMessageObjectListMutex = new ReentrantLock();
    private RawTLVMessageObject myRawTLVSendMessage = null;
    private RawTLVMessageObject myRawTLVReceiveMessage = null;
    private String messageTypeIndicator;
    private YP_RawTLVException myErrorData;
    public byte[] dataToSeal = new byte[0];

    public YP_TCD_PROT_RawTLV(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            this.parserXML = (YP_GlobalComponent)this.getPluginByName("RawTLVParser");
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PROT_Interface_Com) {
                this.myIpduLayer = (YP_PROT_Interface_Com)objectArray[0];
            }
        }
    }

    public YP_RawTLVException YP_GetLastError() {
        return this.myErrorData;
    }

    private static RawTLVField getMessageField(RawTLVMessage rawTLVMessage, int n) {
        switch (n) {
            case 1: {
                return rawTLVMessage.getField1();
            }
            case 2: {
                return rawTLVMessage.getField2();
            }
            case 3: {
                return rawTLVMessage.getField3();
            }
            case 4: {
                return rawTLVMessage.getField4();
            }
            case 5: {
                return rawTLVMessage.getField5();
            }
            case 6: {
                return rawTLVMessage.getField6();
            }
            case 7: {
                return rawTLVMessage.getField7();
            }
            case 8: {
                return rawTLVMessage.getField8();
            }
            case 9: {
                return rawTLVMessage.getField9();
            }
            case 10: {
                return rawTLVMessage.getField10();
            }
            case 11: {
                return rawTLVMessage.getField11();
            }
            case 12: {
                return rawTLVMessage.getField12();
            }
            case 13: {
                return rawTLVMessage.getField13();
            }
            case 14: {
                return rawTLVMessage.getField14();
            }
            case 15: {
                return rawTLVMessage.getField15();
            }
            case 16: {
                return rawTLVMessage.getField16();
            }
            case 17: {
                return rawTLVMessage.getField17();
            }
            case 18: {
                return rawTLVMessage.getField18();
            }
            case 19: {
                return rawTLVMessage.getField19();
            }
            case 20: {
                return rawTLVMessage.getField20();
            }
            case 21: {
                return rawTLVMessage.getField21();
            }
            case 22: {
                return rawTLVMessage.getField22();
            }
            case 23: {
                return rawTLVMessage.getField23();
            }
            case 24: {
                return rawTLVMessage.getField24();
            }
            case 25: {
                return rawTLVMessage.getField25();
            }
            case 26: {
                return rawTLVMessage.getField26();
            }
            case 27: {
                return rawTLVMessage.getField27();
            }
            case 28: {
                return rawTLVMessage.getField28();
            }
            case 29: {
                return rawTLVMessage.getField29();
            }
            case 30: {
                return rawTLVMessage.getField30();
            }
            case 31: {
                return rawTLVMessage.getField31();
            }
            case 32: {
                return rawTLVMessage.getField32();
            }
            case 33: {
                return rawTLVMessage.getField33();
            }
            case 34: {
                return rawTLVMessage.getField34();
            }
            case 35: {
                return rawTLVMessage.getField35();
            }
            case 36: {
                return rawTLVMessage.getField36();
            }
            case 37: {
                return rawTLVMessage.getField37();
            }
            case 38: {
                return rawTLVMessage.getField38();
            }
            case 39: {
                return rawTLVMessage.getField39();
            }
            case 40: {
                return rawTLVMessage.getField40();
            }
            case 41: {
                return rawTLVMessage.getField41();
            }
            case 42: {
                return rawTLVMessage.getField42();
            }
            case 43: {
                return rawTLVMessage.getField43();
            }
            case 44: {
                return rawTLVMessage.getField44();
            }
            case 45: {
                return rawTLVMessage.getField45();
            }
            case 46: {
                return rawTLVMessage.getField46();
            }
            case 47: {
                return rawTLVMessage.getField47();
            }
            case 48: {
                return rawTLVMessage.getField48();
            }
            case 49: {
                return rawTLVMessage.getField49();
            }
            case 50: {
                return rawTLVMessage.getField50();
            }
            case 52: {
                return rawTLVMessage.getField52();
            }
            case 53: {
                return rawTLVMessage.getField53();
            }
            case 54: {
                return rawTLVMessage.getField54();
            }
            case 55: {
                return rawTLVMessage.getField55();
            }
            case 56: {
                return rawTLVMessage.getField56();
            }
            case 59: {
                return rawTLVMessage.getField59();
            }
            case 60: {
                return rawTLVMessage.getField60();
            }
            case 61: {
                return rawTLVMessage.getField61();
            }
            case 62: {
                return rawTLVMessage.getField62();
            }
            case 63: {
                return rawTLVMessage.getField63();
            }
            case 64: {
                return rawTLVMessage.getField64();
            }
            case 65: {
                return rawTLVMessage.getField65();
            }
            case 66: {
                return rawTLVMessage.getField66();
            }
            case 67: {
                return rawTLVMessage.getField67();
            }
            case 68: {
                return rawTLVMessage.getField68();
            }
            case 69: {
                return rawTLVMessage.getField69();
            }
            case 70: {
                return rawTLVMessage.getField70();
            }
            case 71: {
                return rawTLVMessage.getField71();
            }
            case 72: {
                return rawTLVMessage.getField72();
            }
            case 73: {
                return rawTLVMessage.getField73();
            }
            case 74: {
                return rawTLVMessage.getField74();
            }
            case 76: {
                return rawTLVMessage.getField76();
            }
            case 80: {
                return rawTLVMessage.getField80();
            }
            case 81: {
                return rawTLVMessage.getField81();
            }
            case 82: {
                return rawTLVMessage.getField82();
            }
            case 83: {
                return rawTLVMessage.getField83();
            }
            case 84: {
                return rawTLVMessage.getField84();
            }
            case 85: {
                return rawTLVMessage.getField85();
            }
            case 86: {
                return rawTLVMessage.getField86();
            }
            case 201: {
                return rawTLVMessage.getField201();
            }
            case 202: {
                return rawTLVMessage.getField202();
            }
            case 203: {
                return rawTLVMessage.getField203();
            }
            case 204: {
                return rawTLVMessage.getField204();
            }
            case 205: {
                return rawTLVMessage.getField205();
            }
            case 206: {
                return rawTLVMessage.getField206();
            }
            case 301: {
                return rawTLVMessage.getField301();
            }
            case 302: {
                return rawTLVMessage.getField302();
            }
            case 303: {
                return rawTLVMessage.getField303();
            }
            case 304: {
                return rawTLVMessage.getField304();
            }
            case 305: {
                return rawTLVMessage.getField305();
            }
            case 306: {
                return rawTLVMessage.getField306();
            }
            case 307: {
                return rawTLVMessage.getField307();
            }
            case 308: {
                return rawTLVMessage.getField308();
            }
            case 309: {
                return rawTLVMessage.getField309();
            }
            case 310: {
                return rawTLVMessage.getField310();
            }
            case 311: {
                return rawTLVMessage.getField311();
            }
            case 312: {
                return rawTLVMessage.getField312();
            }
            case 313: {
                return rawTLVMessage.getField313();
            }
            case 314: {
                return rawTLVMessage.getField314();
            }
            case 401: {
                return rawTLVMessage.getField401();
            }
        }
        return null;
    }

    public static RawTLVFieldPresence getFieldTypePresence(RawTLVPresence rawTLVPresence, int n) {
        switch (n) {
            case 1: {
                return rawTLVPresence.getField1();
            }
            case 2: {
                return rawTLVPresence.getField2();
            }
            case 3: {
                return rawTLVPresence.getField3();
            }
            case 4: {
                return rawTLVPresence.getField4();
            }
            case 5: {
                return rawTLVPresence.getField5();
            }
            case 6: {
                return rawTLVPresence.getField6();
            }
            case 7: {
                return rawTLVPresence.getField7();
            }
            case 8: {
                return rawTLVPresence.getField8();
            }
            case 9: {
                return rawTLVPresence.getField9();
            }
            case 10: {
                return rawTLVPresence.getField10();
            }
            case 11: {
                return rawTLVPresence.getField11();
            }
            case 12: {
                return rawTLVPresence.getField12();
            }
            case 13: {
                return rawTLVPresence.getField13();
            }
            case 14: {
                return rawTLVPresence.getField14();
            }
            case 15: {
                return rawTLVPresence.getField15();
            }
            case 16: {
                return rawTLVPresence.getField16();
            }
            case 17: {
                return rawTLVPresence.getField17();
            }
            case 18: {
                return rawTLVPresence.getField18();
            }
            case 19: {
                return rawTLVPresence.getField19();
            }
            case 20: {
                return rawTLVPresence.getField20();
            }
            case 21: {
                return rawTLVPresence.getField21();
            }
            case 22: {
                return rawTLVPresence.getField22();
            }
            case 23: {
                return rawTLVPresence.getField23();
            }
            case 24: {
                return rawTLVPresence.getField24();
            }
            case 25: {
                return rawTLVPresence.getField25();
            }
            case 26: {
                return rawTLVPresence.getField26();
            }
            case 27: {
                return rawTLVPresence.getField27();
            }
            case 28: {
                return rawTLVPresence.getField28();
            }
            case 29: {
                return rawTLVPresence.getField29();
            }
            case 30: {
                return rawTLVPresence.getField30();
            }
            case 31: {
                return rawTLVPresence.getField31();
            }
            case 32: {
                return rawTLVPresence.getField32();
            }
            case 33: {
                return rawTLVPresence.getField33();
            }
            case 34: {
                return rawTLVPresence.getField34();
            }
            case 35: {
                return rawTLVPresence.getField35();
            }
            case 36: {
                return rawTLVPresence.getField36();
            }
            case 37: {
                return rawTLVPresence.getField37();
            }
            case 38: {
                return rawTLVPresence.getField38();
            }
            case 39: {
                return rawTLVPresence.getField39();
            }
            case 40: {
                return rawTLVPresence.getField40();
            }
            case 41: {
                return rawTLVPresence.getField41();
            }
            case 42: {
                return rawTLVPresence.getField42();
            }
            case 43: {
                return rawTLVPresence.getField43();
            }
            case 44: {
                return rawTLVPresence.getField44();
            }
            case 45: {
                return rawTLVPresence.getField45();
            }
            case 46: {
                return rawTLVPresence.getField46();
            }
            case 47: {
                return rawTLVPresence.getField47();
            }
            case 48: {
                return rawTLVPresence.getField48();
            }
            case 49: {
                return rawTLVPresence.getField49();
            }
            case 50: {
                return rawTLVPresence.getField50();
            }
            case 52: {
                return rawTLVPresence.getField52();
            }
            case 53: {
                return rawTLVPresence.getField53();
            }
            case 54: {
                return rawTLVPresence.getField54();
            }
            case 55: {
                return rawTLVPresence.getField55();
            }
            case 56: {
                return rawTLVPresence.getField56();
            }
            case 59: {
                return rawTLVPresence.getField59();
            }
            case 60: {
                return rawTLVPresence.getField60();
            }
            case 61: {
                return rawTLVPresence.getField61();
            }
            case 62: {
                return rawTLVPresence.getField62();
            }
            case 63: {
                return rawTLVPresence.getField63();
            }
            case 64: {
                return rawTLVPresence.getField64();
            }
            case 65: {
                return rawTLVPresence.getField65();
            }
            case 66: {
                return rawTLVPresence.getField66();
            }
            case 67: {
                return rawTLVPresence.getField67();
            }
            case 68: {
                return rawTLVPresence.getField68();
            }
            case 69: {
                return rawTLVPresence.getField69();
            }
            case 70: {
                return rawTLVPresence.getField70();
            }
            case 71: {
                return rawTLVPresence.getField71();
            }
            case 72: {
                return rawTLVPresence.getField72();
            }
            case 73: {
                return rawTLVPresence.getField73();
            }
            case 74: {
                return rawTLVPresence.getField74();
            }
            case 76: {
                return rawTLVPresence.getField76();
            }
            case 80: {
                return rawTLVPresence.getField80();
            }
            case 81: {
                return rawTLVPresence.getField81();
            }
            case 82: {
                return rawTLVPresence.getField82();
            }
            case 83: {
                return rawTLVPresence.getField83();
            }
            case 84: {
                return rawTLVPresence.getField84();
            }
            case 85: {
                return rawTLVPresence.getField85();
            }
            case 86: {
                return rawTLVPresence.getField86();
            }
            case 201: {
                return rawTLVPresence.getField201();
            }
            case 202: {
                return rawTLVPresence.getField202();
            }
            case 203: {
                return rawTLVPresence.getField203();
            }
            case 204: {
                return rawTLVPresence.getField204();
            }
            case 205: {
                return rawTLVPresence.getField205();
            }
            case 206: {
                return rawTLVPresence.getField206();
            }
            case 301: {
                return rawTLVPresence.getField301();
            }
            case 302: {
                return rawTLVPresence.getField302();
            }
            case 303: {
                return rawTLVPresence.getField303();
            }
            case 304: {
                return rawTLVPresence.getField304();
            }
            case 305: {
                return rawTLVPresence.getField305();
            }
            case 306: {
                return rawTLVPresence.getField306();
            }
            case 307: {
                return rawTLVPresence.getField307();
            }
            case 308: {
                return rawTLVPresence.getField308();
            }
            case 309: {
                return rawTLVPresence.getField309();
            }
            case 310: {
                return rawTLVPresence.getField310();
            }
            case 311: {
                return rawTLVPresence.getField311();
            }
            case 312: {
                return rawTLVPresence.getField312();
            }
            case 313: {
                return rawTLVPresence.getField313();
            }
            case 314: {
                return rawTLVPresence.getField314();
            }
            case 401: {
                return rawTLVPresence.getField401();
            }
        }
        return null;
    }

    private static boolean isItATlv(YP_RawTLVUtils.FieldFormat fieldFormat) {
        switch (fieldFormat) {
            case TTTLLLLV_c: 
            case TTTTLLLLV_c: {
                return true;
            }
        }
        return false;
    }

    public String formatTagName(YP_RawTLVUtils.FieldFormat fieldFormat, int n) {
        String string = null;
        switch (fieldFormat) {
            case TTTLLLLV_c: {
                string = String.format("%03d", n);
                break;
            }
            case TTTTLLLLV_c: {
                string = String.format("%04d", n);
            }
        }
        return string;
    }

    public String formatTagLength(YP_RawTLVUtils.FieldFormat fieldFormat, String string) {
        String string2 = null;
        switch (fieldFormat) {
            case TTTLLLLV_c: 
            case TTTTLLLLV_c: {
                string2 = String.format("%04d", string.length());
            }
        }
        return string2;
    }

    public int YP_SetFieldValue(RawTLVMessage rawTLVMessage, int n, String string) {
        RawTLVField rawTLVField;
        block11: {
            block10: {
                block9: {
                    block8: {
                        block7: {
                            try {
                                if (rawTLVMessage != null) break block7;
                                this.logger(2, "YP_SetFieldValue() myRawTLVData null");
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                            catch (Exception exception) {
                                this.logger(2, "YP_SetFieldValue() " + exception);
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                        }
                        if (n > 0 && n <= 401) break block8;
                        this.logger(2, "YP_SetFieldValue() FieldNumber out of range");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    if (!string.isEmpty()) break block9;
                    this.logger(2, "YP_SetTLVValue() value is null");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return -1;
                }
                rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                if (rawTLVField != null) break block10;
                this.logger(2, "YP_SetFieldValue() pb with dataField");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return -1;
            }
            YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
            if (fieldFormat != null) break block11;
            this.logger(2, "YP_SetFieldValue() pb with fieldFormat");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        rawTLVField.setFieldValue(string);
        return 1;
    }

    public int YP_SetFieldValue(RawTLVMessage rawTLVMessage, int n, String string, String string2) {
        block13: {
            RawTLVTLVElement rawTLVTLVElement;
            block14: {
                YP_RawTLVUtils.FieldFormat fieldFormat;
                RawTLVField rawTLVField;
                block12: {
                    block11: {
                        block10: {
                            block9: {
                                block8: {
                                    try {
                                        if (rawTLVMessage != null) break block8;
                                        this.logger(2, "YP_SetTLVValue() myRawTLVData null");
                                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                        return -1;
                                    }
                                    catch (Exception exception) {
                                        this.logger(2, "YP_SetFieldValue() " + exception);
                                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                        return -1;
                                    }
                                }
                                if (n > 0 && n <= 401) break block9;
                                this.logger(2, "YP_SetTLVValue() FieldNumber out of range");
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                return -1;
                            }
                            if (string2 != null) break block10;
                            this.logger(2, "YP_SetTLVValue() value is null");
                            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                            return -1;
                        }
                        rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                        if (rawTLVField != null) break block11;
                        this.logger(2, "YP_SetTLVValue() pb with dataField");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
                    if (fieldFormat != null) break block12;
                    this.logger(2, "YP_SetTLVValue() pb with fieldFormat");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return -1;
                }
                if (!YP_TCD_PROT_RawTLV.isItATlv(fieldFormat)) break block13;
                rawTLVTLVElement = YP_TCD_PROT_RawTLV.getRawTLVTLVElementByName(rawTLVField, string);
                if (rawTLVTLVElement != null) break block14;
                this.logger(2, "YP_SetTLVValue() TLV Name not found:" + string);
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return -1;
            }
            rawTLVTLVElement.getTLVValue().add(string2);
        }
        return 1;
    }

    public int YP_BuildField(RawTLVMessage rawTLVMessage, int n) {
        YP_RawTLVUtils.FieldFormat fieldFormat;
        RawTLVField rawTLVField;
        block13: {
            block12: {
                block11: {
                    block10: {
                        if (rawTLVMessage != null) break block10;
                        this.logger(2, "YP_SetTLVValue() myRawTLVData null");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    if (n > 0 && n <= 401) break block11;
                    this.logger(2, "YP_SetTLVValue() FieldNumber out of range");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return -1;
                }
                rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                if (rawTLVField != null) break block12;
                this.logger(2, "YP_SetTLVValue() pb with dataField");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return -1;
            }
            fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
            if (fieldFormat != null) break block13;
            this.logger(2, "YP_SetTLVValue() pb with fieldFormat");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        try {
            if (YP_TCD_PROT_RawTLV.isItATlv(fieldFormat)) {
                Object object;
                String string = new String();
                List<RawTLVTLVElement> list = rawTLVField.getTlv();
                if (list != null) {
                    object = null;
                    for (RawTLVTLVElement rawTLVTLVElement : list) {
                        object = rawTLVTLVElement.getTLVValue();
                        Iterator iterator = object.iterator();
                        while (iterator.hasNext()) {
                            String string2 = (String)iterator.next();
                            string = String.valueOf(string) + string2;
                        }
                    }
                }
                object = this.formatTagName(fieldFormat, n);
                object = String.valueOf(object) + this.formatTagLength(fieldFormat, string);
                object = String.valueOf(object) + string;
                rawTLVField.setFieldValue((String)object);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetFieldValue() " + exception);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
    }

    public String YP_GetFieldValue(RawTLVMessage rawTLVMessage, int n) {
        RawTLVField rawTLVField;
        block10: {
            block9: {
                block8: {
                    block7: {
                        try {
                            if (rawTLVMessage != null) break block7;
                            this.logger(2, "YP_GetFieldValue() myRawTLVData null");
                            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                            return null;
                        }
                        catch (Exception exception) {
                            this.logger(2, "YP_GetFieldValue() " + exception);
                            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                            return null;
                        }
                    }
                    if (n > 0 && n <= 401) break block8;
                    this.logger(2, "YP_GetFieldValue() FieldNumber out of range");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return null;
                }
                rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                if (rawTLVField != null) break block9;
                this.logger(2, "YP_GetFieldValue() pb with dataField");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return null;
            }
            YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
            if (fieldFormat != null) break block10;
            this.logger(2, "YP_GetFieldValue() pb with fieldFormat");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return null;
        }
        String string = rawTLVField.getFieldValue();
        if (string != null) {
            return string;
        }
        return "";
    }

    public List<String> YP_GetFieldValue(RawTLVMessage rawTLVMessage, int n, String string) {
        List<String> list;
        block13: {
            RawTLVTLVElement rawTLVTLVElement;
            block12: {
                RawTLVField rawTLVField;
                block11: {
                    block10: {
                        block9: {
                            block8: {
                                try {
                                    if (rawTLVMessage != null) break block8;
                                    this.logger(2, "YP_GetFieldValue() myRawTLVData null");
                                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                    return null;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "YP_GetFieldValue() " + exception);
                                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                    return null;
                                }
                            }
                            if (n > 0 && n <= 401) break block9;
                            this.logger(2, "YP_GetFieldValue() FieldNumber out of range");
                            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                            return null;
                        }
                        rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                        if (rawTLVField != null) break block10;
                        this.logger(2, "YP_GetFieldValue() pb with dataField");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return null;
                    }
                    YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
                    if (fieldFormat != null) break block11;
                    this.logger(2, "YP_GetFieldValue() pb with fieldFormat");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return null;
                }
                rawTLVTLVElement = YP_TCD_PROT_RawTLV.getRawTLVTLVElementByName(rawTLVField, string);
                if (rawTLVTLVElement != null) break block12;
                this.logger(2, "YP_GetTLVValueList() TLV Name not found:" + string);
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return null;
            }
            list = rawTLVTLVElement.getTLVValue();
            if (list != null && !list.isEmpty()) break block13;
            return null;
        }
        return list;
    }

    private void YP_ParseRawTLVSubField() {
        try {
            int n = 1;
            while (n < 401) {
                List<RawTLVTLVElement> list;
                RawTLVField rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVReceiveMessage.rawtTLVMessage, n);
                if (rawTLVField != null && rawTLVField.getFieldValue() != null && !(list = rawTLVField.getTlv()).isEmpty()) {
                    int n2 = 0;
                    int n3 = rawTLVField.getFieldValue().length();
                    while (n2 < n3) {
                        String string = rawTLVField.getFieldValue().subSequence(n2, n2 + 4).toString();
                        int n4 = Integer.parseInt(rawTLVField.getFieldValue().subSequence(n2 += 4, n2 + 4).toString());
                        String string2 = rawTLVField.getFieldValue().subSequence(n2 += 4, n2 + n4).toString();
                        n2 += n4;
                        this.YP_SetFieldValue(this.myRawTLVReceiveMessage.rawtTLVMessage, n, string, string2);
                    }
                }
                ++n;
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_ParseRawTLVSubField() ", exception);
        }
    }

    public void YP_SetXMLSendMessage(String string) {
        try {
            if (this.myRawTLVSendMessage != null) {
                this.myRawTLVSendMessage.onUse = 0;
                this.myRawTLVSendMessage = null;
            }
            if (string == null) {
                this.logger(2, "YP_SetXMLSendMessage() No presence file given...");
                return;
            }
            RawTLVMessageObject rawTLVMessageObject = null;
            try {
                rawTLVSendMessageObjectListMutex.lock();
                for (RawTLVMessageObject object2 : rawTLVSendMessageObjectList) {
                    if (object2 == null || object2.onUse != 0 || !object2.name.contentEquals(string)) continue;
                    object2.onUse = 1;
                    rawTLVMessageObject = object2;
                    break;
                }
            }
            finally {
                rawTLVSendMessageObjectListMutex.unlock();
            }
            if (rawTLVMessageObject != null) {
                this.myRawTLVSendMessage = rawTLVMessageObject;
                this.emptyRawTLVMessage(this.myRawTLVSendMessage.rawtTLVMessage);
            }
            RawTLVMessage rawTLVMessage = (RawTLVMessage)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.myRawTLVSendMessage = new RawTLVMessageObject(string, rawTLVMessage);
            try {
                rawTLVSendMessageObjectListMutex.lock();
                rawTLVSendMessageObjectList.add(this.myRawTLVSendMessage);
            }
            finally {
                rawTLVSendMessageObjectListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLSendMessage() " + exception + string);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLSendPresence(String string) {
        try {
            if (string == null) {
                this.logger(2, "YP_SetXMLRequestPresence() No presence file given...");
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_SetXMLSendPresence() " + string);
            }
            this.myRawTLVSendPresence = this.rawTLVSendPresenceObjectList.get(string);
            if (this.myRawTLVSendPresence != null) {
                return;
            }
            this.myRawTLVSendPresence = (RawTLVPresence)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.rawTLVSendPresenceObjectList.put(string, this.myRawTLVSendPresence);
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLSendPresence() " + exception + string);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLReceiveMessage(String string) {
        try {
            if (this.myRawTLVReceiveMessage != null) {
                this.myRawTLVReceiveMessage.onUse = 0;
                this.myRawTLVReceiveMessage = null;
            }
            if (string == null) {
                this.logger(2, "YP_SetXMLReceiveMessage() No presence file given...");
                return;
            }
            RawTLVMessageObject rawTLVMessageObject = null;
            try {
                rawTLVReceiveMessageObjectListMutex.lock();
                for (RawTLVMessageObject object2 : rawTLVReceiveMessageObjectList) {
                    if (object2 == null || object2.onUse != 0 || !object2.name.contentEquals(string)) continue;
                    object2.onUse = 1;
                    rawTLVMessageObject = object2;
                    break;
                }
            }
            finally {
                rawTLVReceiveMessageObjectListMutex.unlock();
            }
            if (rawTLVMessageObject != null) {
                this.myRawTLVReceiveMessage = rawTLVMessageObject;
                this.emptyRawTLVMessage(this.myRawTLVReceiveMessage.rawtTLVMessage);
                return;
            }
            RawTLVMessage rawTLVMessage = (RawTLVMessage)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.myRawTLVReceiveMessage = new RawTLVMessageObject(string, rawTLVMessage);
            try {
                rawTLVReceiveMessageObjectListMutex.lock();
                rawTLVReceiveMessageObjectList.add(this.myRawTLVReceiveMessage);
            }
            finally {
                rawTLVReceiveMessageObjectListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLReceiveMessage() " + exception + string);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
        }
    }

    public void YP_SetXMLReceivePresence(String string) {
        try {
            if (string == null) {
                this.logger(2, "YP_SetXMLReceivePresence() No presence file given...");
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_SetXMLReceivePresence() " + string);
            }
            this.myRawTLVReceivePresence = this.rawTLVReceivePresenceObjectList.get(string);
            if (this.myRawTLVReceivePresence != null) {
                return;
            }
            this.myRawTLVReceivePresence = (RawTLVPresence)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
            this.rawTLVReceivePresenceObjectList.put(string, this.myRawTLVReceivePresence);
        }
        catch (Exception exception) {
            this.logger(2, "YP_SetXMLReceivePresence() " + exception + string);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
        }
    }

    public RawTLVMessage YP_GetNewSendFactoryObject() {
        this.emptyRawTLVMessage(this.myRawTLVSendMessage.rawtTLVMessage);
        return this.myRawTLVSendMessage.rawtTLVMessage;
    }

    public RawTLVMessage YP_GetSendFactoryObject() {
        return this.myRawTLVSendMessage.rawtTLVMessage;
    }

    public RawTLVPresence YP_GetSendPresenceFactoryObject() {
        return this.myRawTLVSendPresence;
    }

    public RawTLVPresence YP_GetReceivePresenceFactoryObject() {
        return this.myRawTLVReceivePresence;
    }

    public RawTLVMessage YP_GetReceiveFactoryObject() {
        return this.myRawTLVReceiveMessage.rawtTLVMessage;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public int YP_BuildRawTLVMessage() {
        int n = 0;
        try {
            Object object;
            StringBuilder stringBuilder = new StringBuilder();
            System.nanoTime();
            if (this.myRawTLVSendMessage == null) {
                this.logger(2, "YP_FormatRawTLVMessage() RawTLVMessage null!!!");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return -1;
            }
            n = 1;
            while (n < 401) {
                object = YP_TCD_PROT_RawTLV.getFieldTypePresence(this.myRawTLVSendPresence, n);
                if (object != null) {
                    List<RawTLVTLVElement> list;
                    RawTLVField rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVSendMessage.rawtTLVMessage, n);
                    YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
                    if (fieldFormat == null) {
                        this.logger(2, "YP_SetFieldValue() pb with fieldFormat");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return -1;
                    }
                    String string = rawTLVField.getFieldValue();
                    if (string == null) {
                        list = rawTLVField.getTlv();
                        if (list != null && !list.isEmpty()) {
                            String string2 = new String();
                            List<String> list2 = null;
                            for (RawTLVTLVElement rawTLVTLVElement : list) {
                                list2 = rawTLVTLVElement.getTLVValue();
                                YP_RawTLVUtils.FieldFormat fieldFormat2 = YP_RawTLVUtils.getMyFieldFormat(rawTLVTLVElement.getLengthType());
                                for (String string3 : list2) {
                                    if (string3 == null || string3.isEmpty()) continue;
                                    string2 = String.valueOf(string2) + rawTLVTLVElement.getName();
                                    string2 = String.valueOf(string2) + this.formatTagLength(fieldFormat2, string3);
                                    string2 = String.valueOf(string2) + string3;
                                }
                            }
                            string = string2;
                        } else {
                            ((RawTLVFieldPresence)object).getPresence().contentEquals("R");
                        }
                    }
                    if (string != null && string.length() > 0) {
                        list = this.formatTagName(fieldFormat, n);
                        list = String.valueOf(list) + this.formatTagLength(fieldFormat, string);
                        list = String.valueOf(list) + string;
                        stringBuilder.append((String)((Object)list));
                    }
                }
                ++n;
            }
            object = "BA";
            object = String.valueOf(object) + String.format("%04d", stringBuilder.length());
            object = String.valueOf(object) + stringBuilder.toString();
            this.apduBuffer = ((String)object).getBytes();
        }
        catch (Exception exception) {
            this.logger(2, "YP_BuildRawTLVMessage() error???  " + n + " " + exception);
            if (this.getLogLevel() >= 6) {
                this.logger(6, "YP_BuildRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVSendMessage.rawtTLVMessage, null, true, this.getLogLevel() < 5));
            } else {
                this.logger(4, "YP_BuildRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVSendMessage.rawtTLVMessage, null, false, this.getLogLevel() < 5));
            }
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVSendMessage.rawtTLVMessage, null, true, this.getLogLevel() < 5));
        } else {
            this.logger(4, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVSendMessage.rawtTLVMessage, null, false, this.getLogLevel() < 5));
        }
        return 1;
    }

    public int YP_ParseRawTLVMessage(byte[] byArray) {
        int n;
        String string;
        int n2;
        block10: {
            n2 = 0;
            this.emptyRawTLVMessage(this.myRawTLVReceiveMessage.rawtTLVMessage);
            string = new String(byArray, StandardCharsets.UTF_8);
            n = 0;
            String string2 = string.subSequence(n, 2).toString();
            n += 2;
            if (string2.equals("BA")) break block10;
            this.logger(2, "YP_ParseRawTLVMessage() Message non BA");
            return -1;
        }
        try {
            int n3 = Integer.parseInt(string.subSequence(n, n + 4).toString());
            n += 4;
            while (n < n3 + 6) {
                int n4 = Integer.parseInt(string.subSequence(n, n + 3).toString());
                int n5 = Integer.parseInt(string.subSequence(n += 3, n + 4).toString());
                String string3 = string.subSequence(n += 4, n + n5).toString();
                n += n5;
                this.YP_SetFieldValue(this.myRawTLVReceiveMessage.rawtTLVMessage, n4, string3);
            }
            RawTLVField rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVReceiveMessage.rawtTLVMessage, 2);
            this.YP_SetMessageTypeIndicator(rawTLVField.getFieldValue());
            this.YP_ParseRawTLVSubField();
        }
        catch (Exception exception) {
            this.logger(2, "YP_ParseRawTLVMessage() error???  " + n2 + " " + exception);
            if (this.getLogLevel() >= 6) {
                this.logger(6, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVReceiveMessage.rawtTLVMessage, null, true, this.getLogLevel() < 5));
            } else {
                this.logger(4, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVReceiveMessage.rawtTLVMessage, null, false, this.getLogLevel() < 5));
            }
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVReceiveMessage.rawtTLVMessage, null, true, this.getLogLevel() < 5));
        } else if (this.getLogLevel() == 4 && this.messageTypeIndicator != null && this.messageTypeIndicator.contentEquals("0360")) {
            this.logger(4, "YP_ParseRawTLVMessage() 0360 not logged");
        } else {
            this.logger(4, "YP_ParseRawTLVMessage() " + this.getRawTLVlog(this.myRawTLVReceiveMessage.rawtTLVMessage, null, false, this.getLogLevel() < 5));
        }
        return 1;
    }

    public void YP_SetMessageTypeIndicator(String string) {
        this.messageTypeIndicator = string;
    }

    public String YP_GetMessageTypeIndicator() {
        return this.messageTypeIndicator;
    }

    private boolean checkIfEquals(String string, String string2, YP_RawTLVUtils.DataFormat dataFormat) {
        int n = string.length() - string2.length();
        if (n == 0) {
            return string.contentEquals(string2);
        }
        String string3 = string;
        String string4 = string2;
        switch (dataFormat) {
            case NUMERIC: {
                if (n > 0) {
                    char[] cArray = new char[n];
                    Arrays.fill(cArray, '0');
                    string4 = String.valueOf(new String(cArray)) + string4;
                    break;
                }
                char[] cArray = new char[n *= -1];
                Arrays.fill(cArray, '0');
                string3 = String.valueOf(new String(cArray)) + string3;
                break;
            }
            case ALPHA: 
            case ALPHANUM: {
                if (n > 0) {
                    char[] cArray = new char[n];
                    Arrays.fill(cArray, ' ');
                    string4 = String.valueOf(string4) + new String(cArray);
                    break;
                }
                char[] cArray = new char[n *= -1];
                Arrays.fill(cArray, ' ');
                string3 = String.valueOf(string3) + new String(cArray);
                break;
            }
            default: {
                this.logger(3, "checkIfEquals() not equals :" + string3 + " vs " + string4 + " for unknown format :" + dataFormat.toString());
                return false;
            }
        }
        if (string3.contentEquals(string4)) {
            return true;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "checkIfEquals() not equals :" + string3 + " vs " + string4 + " for format :" + dataFormat.toString());
        }
        return false;
    }

    private static RawTLVTLVElement getRawTLVTLVElementByName(RawTLVField rawTLVField, String string) {
        List<RawTLVTLVElement> list = rawTLVField.getTlv();
        for (RawTLVTLVElement rawTLVTLVElement : list) {
            if (!rawTLVTLVElement.getName().contentEquals(string)) continue;
            return rawTLVTLVElement;
        }
        return null;
    }

    private RawTLVTLVElement YP_GetTlvByName(RawTLVMessage rawTLVMessage, int n, String string) {
        try {
            RawTLVField rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
            if (rawTLVField != null) {
                return YP_TCD_PROT_RawTLV.getRawTLVTLVElementByName(rawTLVField, string);
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_GetTlvByName()" + exception);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
        }
        return null;
    }

    private boolean YP_CheckTLV(RawTLVMessage rawTLVMessage, RawTLVMessage rawTLVMessage2, int n, String string, String string2) {
        try {
            return this.YP_CheckTLV(this.YP_GetTlvByName(rawTLVMessage, n, string), rawTLVMessage2, n, string, string2);
        }
        catch (Exception exception) {
            this.logger(2, "YP_CheckTLV()  " + exception);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return false;
        }
    }

    private boolean YP_CheckTLV(RawTLVTLVElement rawTLVTLVElement, RawTLVMessage rawTLVMessage, int n, String string, String string2) {
        YP_RawTLVUtils.DataFormat dataFormat;
        String string3;
        List<String> list;
        RawTLVTLVElement rawTLVTLVElement2;
        String string4;
        block13: {
            block12: {
                List<String> list2;
                block11: {
                    block10: {
                        try {
                            if (rawTLVTLVElement != null) break block10;
                            if (string2.contains("R")) {
                                this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but not found");
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), string, null);
                                return false;
                            }
                            return true;
                        }
                        catch (Exception exception) {
                            this.logger(2, "YP_CheckTLV()  " + exception);
                            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                            return false;
                        }
                    }
                    list2 = rawTLVTLVElement.getTLVValue();
                    if (list2 != null && !list2.isEmpty()) break block11;
                    if (string2.contains("R")) {
                        this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but missing");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), string, null);
                        return false;
                    }
                    return true;
                }
                string4 = list2.get(0);
                if (string4 != null && !string4.isEmpty()) break block12;
                if (string2.contains("R")) {
                    this.logger(2, "YP_CheckTLV() Field " + n + " TLV " + string + " required but really missing");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), string, null);
                    return false;
                }
                return true;
            }
            if (rawTLVMessage != null) break block13;
            return true;
        }
        if (string2.contains("=") && (rawTLVTLVElement2 = this.YP_GetTlvByName(rawTLVMessage, n, string)) != null && (list = rawTLVTLVElement2.getTLVValue()) != null && !list.isEmpty() && (string3 = list.get(0)) != null && !string3.isEmpty() && !this.checkIfEquals(string3, string4, dataFormat = YP_RawTLVUtils.getMyDataFormat(rawTLVTLVElement.getFormat()))) {
            this.logger(2, "YP_CheckTLV()  Field TLV" + n + string + ": Response field: " + string4 + " different from request field: " + string3);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.wrongEqualityField, Integer.toString(n), string, null);
            return false;
        }
        return true;
    }

    public boolean YP_CheckField(RawTLVMessage rawTLVMessage, RawTLVFieldPresence rawTLVFieldPresence, RawTLVMessage rawTLVMessage2, int n) {
        block17: {
            YP_RawTLVUtils.DataFormat dataFormat;
            RawTLVField rawTLVField;
            String string;
            RawTLVField rawTLVField2;
            block21: {
                block20: {
                    block18: {
                        block19: {
                            block16: {
                                block15: {
                                    if (rawTLVFieldPresence != null) break block15;
                                    return true;
                                }
                                rawTLVField2 = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
                                if (rawTLVField2 != null) break block16;
                                if (rawTLVFieldPresence.getPresence().contains("R")) {
                                    this.logger(2, "YP_CheckField : mandatory field " + n + " missing");
                                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), null, null);
                                    return false;
                                }
                                return true;
                            }
                            try {
                                YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField2.getFieldLengthType());
                                if (YP_TCD_PROT_RawTLV.isItATlv(fieldFormat)) {
                                    if (fieldFormat.equals((Object)YP_RawTLVUtils.FieldFormat.TTTLLLLV_c) || fieldFormat.equals((Object)YP_RawTLVUtils.FieldFormat.TTTTLLLLV_c)) {
                                        for (RawTLVTLVPresence rawTLVTLVPresence : rawTLVFieldPresence.getTlv()) {
                                            String string2 = rawTLVTLVPresence.getPresence();
                                            if (string2.contains("R")) {
                                                this.YP_CheckTLV(rawTLVMessage, rawTLVMessage2, n, rawTLVTLVPresence.getName(), string2);
                                                continue;
                                            }
                                            if (!string2.contains("=") || rawTLVMessage2 == null) continue;
                                            this.YP_CheckTLV(rawTLVMessage, rawTLVMessage2, n, rawTLVTLVPresence.getName(), string2);
                                        }
                                    } else {
                                        this.logger(2, "YP_CheckField : just for a debug log");
                                    }
                                    break block17;
                                }
                                string = rawTLVField2.getFieldValue();
                                if (!rawTLVFieldPresence.getPresence().contains("R")) break block18;
                                if (string != null) break block19;
                                this.logger(2, "YP_CheckField : mandatory field " + n + " null value");
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), null, null);
                                return false;
                            }
                            catch (Exception exception) {
                                this.logger(2, "YP_CheckField() " + exception);
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, Integer.toString(n), null, null);
                                return false;
                            }
                        }
                        if (!string.isEmpty()) break block18;
                        this.logger(2, "YP_CheckField : mandatory field " + n + " empty");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), null, null);
                        return false;
                    }
                    if (!rawTLVFieldPresence.getPresence().contains("=")) break block17;
                    if (rawTLVMessage2 != null) break block20;
                    return true;
                }
                if (string == null) break block17;
                rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVSendMessage.rawtTLVMessage, n);
                if (rawTLVField != null) break block21;
                this.logger(2, "YP_CheckField() Field " + n + " is set and = but not present in request ");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.syntaxError, Integer.toString(n), null, null);
                return false;
            }
            String string3 = rawTLVField.getFieldValue();
            if (string3 != null && !this.checkIfEquals(string3, string, dataFormat = YP_RawTLVUtils.getMyDataFormat(rawTLVField2.getFieldFormat()))) {
                this.logger(2, "YP_CheckField() Field " + n + ": Response field: " + string + " different from request field: " + string3);
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.wrongEqualityField, Integer.toString(n), null, null);
                return false;
            }
        }
        return true;
    }

    public boolean YP_PrepareFieldResponse(int n) {
        String string;
        RawTLVField rawTLVField;
        RawTLVField rawTLVField2;
        RawTLVFieldPresence rawTLVFieldPresence;
        block6: {
            block5: {
                try {
                    rawTLVFieldPresence = YP_TCD_PROT_RawTLV.getFieldTypePresence(this.myRawTLVSendPresence, n);
                    if (rawTLVFieldPresence != null) break block5;
                    return true;
                }
                catch (Exception exception) {
                    this.logger(2, "YP_PrepareFieldResponse() " + exception);
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, Integer.toString(n), null, null);
                    return false;
                }
            }
            rawTLVField2 = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVSendMessage.rawtTLVMessage, n);
            if (rawTLVField2 != null || !rawTLVFieldPresence.getPresence().contains("R")) break block6;
            this.logger(2, "YP_PrepareFieldResponse : mandatory field " + n + " missing");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.fieldMissing, Integer.toString(n), null, null);
            return false;
        }
        YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField2.getFieldLengthType());
        if (!YP_TCD_PROT_RawTLV.isItATlv(fieldFormat) && rawTLVFieldPresence.getPresence().contentEquals("R=") && (rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVReceiveMessage.rawtTLVMessage, n)) != null && (string = rawTLVField.getFieldValue()) != null && !string.isEmpty()) {
            rawTLVField2.setFieldValue(string);
            return true;
        }
        return true;
    }

    public int getFieldLength(int n, String string) {
        RawTLVTLVElement rawTLVTLVElement;
        block11: {
            RawTLVField rawTLVField;
            block10: {
                YP_RawTLVUtils.FieldFormat fieldFormat;
                block9: {
                    block8: {
                        block7: {
                            try {
                                if (n > 0 && n <= 128) break block7;
                                this.logger(2, "getFieldLength() FieldNumber out of range");
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                return 0;
                            }
                            catch (Exception exception) {
                                this.logger(2, "getFieldLength() " + exception);
                                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                                return 0;
                            }
                        }
                        rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(this.myRawTLVSendMessage.rawtTLVMessage, n);
                        if (rawTLVField != null) break block8;
                        this.logger(2, "getFieldLength() pb with dataField");
                        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                        return 0;
                    }
                    fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
                    if (fieldFormat != null) break block9;
                    this.logger(2, "getFieldLength() pb with fieldFormat");
                    this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                    return 0;
                }
                if (YP_TCD_PROT_RawTLV.isItATlv(fieldFormat)) break block10;
                this.logger(2, "getFieldLength() It's not a tlv field...");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return 0;
            }
            rawTLVTLVElement = YP_TCD_PROT_RawTLV.getRawTLVTLVElementByName(rawTLVField, string);
            if (rawTLVTLVElement != null) break block11;
            this.logger(2, "getFieldLength() TLV Name not found:" + string);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return 0;
        }
        return rawTLVTLVElement.getLength() + 2 + 2;
    }

    public boolean checkMessageReceived() {
        String string;
        boolean bl;
        long l = System.currentTimeMillis();
        boolean bl2 = true;
        RawTLVMessage rawTLVMessage = null;
        if (this.myRawTLVReceivePresence == null) {
            this.logger(2, "checkMessageReceived() Pb State machine receivePresence");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return false;
        }
        RawTLVMessageInfo rawTLVMessageInfo = this.myRawTLVReceivePresence.getInfo();
        if (rawTLVMessageInfo == null) {
            this.logger(2, "checkMessageReceived() Pb State machine messageInfo");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return false;
        }
        RawTLVMessageDirection rawTLVMessageDirection = rawTLVMessageInfo.getMessageDirection();
        if (rawTLVMessageDirection == null) {
            this.logger(2, "checkMessageReceived() Pb State machine messageDirection");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return false;
        }
        switch (rawTLVMessageDirection) {
            case REQUEST: {
                bl = true;
                break;
            }
            case RESPONSE: {
                bl = false;
                break;
            }
            default: {
                this.logger(2, "checkMessageReceived() Pb State machine messageDirection value");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return false;
            }
        }
        if (!(bl || (string = this.myRawTLVSendPresence.getInfo().getResponseVerificationLevel()) == null || string.isEmpty() || string.contentEquals("0") || string.contentEquals("1"))) {
            if (string.contentEquals("2")) {
                rawTLVMessage = this.myRawTLVSendMessage.rawtTLVMessage;
            } else if (string.contentEquals("3")) {
                rawTLVMessage = this.myRawTLVSendMessage.rawtTLVMessage;
            } else {
                this.logger(3, "checkMessageReceived() unknown value for responseVerificationLevel :" + string);
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "checkMessageReceived() " + this.myRawTLVReceivePresence.getInfo().getMessageName() + "  MTI: " + this.myRawTLVReceivePresence.getInfo().getMessageType());
        }
        int n = 1;
        while (n < 401) {
            if (!this.YP_CheckField(this.myRawTLVReceiveMessage.rawtTLVMessage, YP_TCD_PROT_RawTLV.getFieldTypePresence(this.myRawTLVReceivePresence, n), rawTLVMessage, n)) {
                bl2 = false;
            }
            ++n;
        }
        if (this.getLogLevel() >= 5) {
            long l2 = System.currentTimeMillis();
            this.logger(5, "checkMessageReceived() Checkin Time = " + (l2 - l));
        }
        return bl2;
    }

    public boolean YP_PrepareResponseMessage() {
        long l = System.currentTimeMillis();
        boolean bl = true;
        this.emptyRawTLVMessage(this.myRawTLVSendMessage.rawtTLVMessage);
        if (this.myRawTLVReceivePresence.getInfo().getMessageDirection() == RawTLVMessageDirection.RESPONSE) {
            this.logger(2, "YP_PrepareResponseMessage() receive message is not a request");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return false;
        }
        int n = 2;
        while (n < 129) {
            if (!this.YP_PrepareFieldResponse(n)) {
                bl = false;
            }
            ++n;
        }
        if (this.getLogLevel() >= 5) {
            long l2 = System.currentTimeMillis();
            this.logger(5, "YP_PrepareResponseMessage() Checkin Time = " + (l2 - l));
        }
        return bl;
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public String toString() {
        return "RawTLV";
    }

    public int YP_WaitConnection() {
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_WaitConnection()");
        }
        if (this.myState == RawTLVStateMachine.CONNECTED) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_WaitConnection() Connected");
            }
            return 1;
        }
        if (this.myState != RawTLVStateMachine.DISCONNECTED) {
            this.logger(2, "YP_WaitConnection() Pb State machine");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        this.myState = RawTLVStateMachine.WAIT_CONNECTION;
        int n = this.getIPDULayer().waitConnection();
        if (n == 1) {
            this.myState = RawTLVStateMachine.CONNECTED;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_WaitConnection() Connected");
            }
            return 1;
        }
        this.logger(2, "YP_WaitConnection() Connection closed ? before anything have been received ");
        return -1;
    }

    public int connect(YP_Row yP_Row) {
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "connect() Start Connection");
        }
        if (this.myState == RawTLVStateMachine.CONNECTED) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "connect() Connected");
            }
            return 1;
        }
        if (this.myState != RawTLVStateMachine.DISCONNECTED) {
            this.logger(2, "connect() Pb state machine");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        if (this.getIPDULayer().connect(yP_Row) < 0) {
            this.logger(2, "connect() IPDU lost connection?");
            return -1;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "connect() Connected transmitter");
        }
        this.myState = RawTLVStateMachine.CONNECTED;
        return 1;
    }

    public int send(boolean bl) {
        block6: {
            if (this.apduBuffer != null && this.apduBuffer.length > 0) break block6;
            this.logger(2, "formatAndSend() Pb data missing");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -1;
        }
        try {
            this.getIPDULayer().send(this.apduBuffer, bl);
        }
        catch (YP_PROT_Interface_Com.TimeOutException timeOutException) {
            this.logger(2, "formatAndSend() Timer expiration" + timeOutException.timerName);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.timeOut, null, null, timeOutException.timerName);
            return 0;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException disconnectionException) {
            this.logger(2, "formatAndSend() Pb IPDU connection lost");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -3;
        }
        catch (Exception exception) {
            this.logger(2, "formatAndSend() " + exception);
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "formatAndSend() message sent");
        }
        return 1;
    }

    public int formatAndSend(YP_PROT_Interface_Prot yP_PROT_Interface_Prot) {
        boolean bl;
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "formatAndSend()");
        }
        if (this.myState != RawTLVStateMachine.CONNECTED) {
            this.logger(2, "formatAndSend() Pb State machine");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        if (this.myRawTLVSendPresence == null) {
            this.logger(2, "formatAndSend() Pb State machine sendPresence");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        RawTLVMessageInfo rawTLVMessageInfo = this.myRawTLVSendPresence.getInfo();
        if (rawTLVMessageInfo == null) {
            this.logger(2, "formatAndSend() Pb State machine messageInfo");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        RawTLVMessageDirection rawTLVMessageDirection = rawTLVMessageInfo.getMessageDirection();
        if (rawTLVMessageDirection == null) {
            this.logger(2, "formatAndSend() Pb State machine messageDirection");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        switch (rawTLVMessageDirection) {
            case REQUEST: {
                bl = true;
                break;
            }
            case RESPONSE: {
                bl = false;
                break;
            }
            default: {
                this.logger(2, "formatAndSend() Pb State machine messageDirection value");
                this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
                return -2;
            }
        }
        if (this.YP_BuildRawTLVMessage() < 0) {
            this.logger(2, "formatAndSend() Pb Format RawTLV message");
            return -1;
        }
        return this.send(bl);
    }

    public int YP_Disconnect() {
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.myState == RawTLVStateMachine.DISCONNECTED) {
            return 0;
        }
        this.getIPDULayer().disconnect();
        this.myState = RawTLVStateMachine.DISCONNECTED;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_Disconnect()");
        }
        return 1;
    }

    public int YP_WaitDisconnection() {
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.myState == RawTLVStateMachine.DISCONNECTED) {
            return 0;
        }
        this.getIPDULayer().waitDisconnection();
        this.myState = RawTLVStateMachine.DISCONNECTED;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_WaitDisconnection()");
        }
        return 1;
    }

    /*
     * Unable to fully structure code
     */
    public int receiveAndParse(boolean var1_1, YP_PROT_Interface_Prot var2_2) {
        this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.noError, null, null, null);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "receiveAndParse()");
        }
        if (this.myState != RawTLVStateMachine.CONNECTED) {
            this.logger(2, "receiveAndParse() Pb State machine");
            this.myErrorData = new YP_RawTLVException(YP_RawTLVException.ErrorType.internalError, null, null, null);
            return -2;
        }
        try {
            this.setApduBuffer(this.getIPDULayer().receive(var1_1));
        }
        catch (YP_PROT_Interface_Com.TimeOutException var3_3) {
            this.logger(2, "receiveAndParse() Timer expiration" + var3_3.timerName);
            return 0;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException v0) {
            var3_4 = this.getIPDULayer().getParameter("STATUT");
            if (var3_4 != null && var3_4.contentEquals(YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED.toString())) {
                this.logger(4, "receiveAndParse() Connection closed by peer");
                return -4;
            }
            var4_5 = new Throwable().getStackTrace();
            var5_6 = 0;
            ** while (var5_6 < var4_5.length)
        }
lbl-1000:
        // 1 sources

        {
            if (var4_5[var5_6].getMethodName().contentEquals("YP_WaitRequest")) {
                this.logger(4, "receiveAndParse() Pb IPDU connection lost?");
                return -3;
            }
            ++var5_6;
            continue;
        }
lbl32:
        // 1 sources

        this.logger(2, "receiveAndParse() Pb IPDU connection lost?");
        return -3;
        catch (YP_PROT_Interface_Com.BadFormatException v1) {
            this.logger(2, "receiveAndParse() BadFormatException !");
            return -3;
        }
        if (this.getApduBuffer() == null) {
            this.logger(2, "receiveAndParse() Pb context no data received");
            return -3;
        }
        if (this.getApduBuffer().length == 0) {
            this.logger(2, "receiveAndParse() Nothing received");
            return 0;
        }
        if (this.YP_ParseRawTLVMessage(this.getApduBuffer()) < 0) {
            this.logger(2, "receiveAndParse() Pb parsing RawTLV message");
            return -1;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "receiveAndParse() message received");
        }
        return 1;
    }

    private static void logOneField(StringBuilder stringBuilder, RawTLVPresence rawTLVPresence, RawTLVField rawTLVField, int n, boolean bl, boolean bl2) {
        if (rawTLVField == null) {
            return;
        }
        RawTLVFieldPresence rawTLVFieldPresence = null;
        boolean bl3 = true;
        if (rawTLVPresence != null) {
            rawTLVFieldPresence = YP_TCD_PROT_RawTLV.getFieldTypePresence(rawTLVPresence, n);
            if (rawTLVFieldPresence == null) {
                bl3 = false;
            } else if (rawTLVFieldPresence.getPresence() == null) {
                bl3 = false;
            }
        }
        String string = rawTLVField.getFieldValue();
        if (bl && string != null && string.length() == 0) {
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   [");
            if (n < 10) {
                stringBuilder.append("00");
            } else if (n < 100) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n);
            stringBuilder.append("]");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   XXX");
            stringBuilder.append(UtilsYP.lineSeparator);
        }
        if (string != null && string.length() != 0) {
            boolean bl4 = true;
            if (rawTLVPresence != null) {
                if (bl3) {
                    if (!bl2) {
                        stringBuilder.append("   >>>   ");
                    }
                } else if (bl) {
                    if (!bl2) {
                        stringBuilder.append("   XXX   ");
                    }
                } else {
                    bl4 = false;
                }
            } else if (!bl2) {
                stringBuilder.append("   <<<   ");
            }
            if (bl4) {
                String string2;
                CharSequence charSequence;
                stringBuilder.append("[");
                if (n < 10) {
                    stringBuilder.append("00");
                } else if (n < 100) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(n);
                stringBuilder.append("]:[");
                if (!bl) {
                    RawTLVFieldTraceType rawTLVFieldTraceType = rawTLVField.getFieldTrace();
                    switch (rawTLVFieldTraceType) {
                        case CVV_MASK: 
                        case END_OF_VALIDITY_MASK: {
                            charSequence = new StringBuilder(string.length());
                            int n2 = 0;
                            while (n2 < string.length()) {
                                charSequence.append('#');
                                ++n2;
                            }
                            string = charSequence.toString();
                            break;
                        }
                        case ISO_1_MASK: {
                            string = UtilsYP.maskISO1Track(string);
                            break;
                        }
                        case ISO_2_MASK: 
                        case ISO_3_MASK: {
                            string = UtilsYP.maskISOTrack(string);
                            break;
                        }
                        case PAN_MASK: {
                            string = UtilsYP.maskPAN(string);
                            break;
                        }
                    }
                }
                if (n == 48) {
                    int n3 = string.indexOf("P92003");
                    if (n3 == -1) {
                        stringBuilder.append(string);
                    } else {
                        stringBuilder.append(string.replaceFirst("P92003[0-9][0-9][0-9]", "P92003###"));
                    }
                } else if (n == 72) {
                    if ((string.startsWith("1100") || string.startsWith("1220")) && string.length() > 50) {
                        int n4 = string.indexOf(42);
                        if (n4 > 16 && n4 < 36) {
                            charSequence = string.substring(16, n4);
                            stringBuilder.append(string.replaceFirst((String)charSequence, UtilsYP.maskPAN((String)charSequence)));
                        } else {
                            stringBuilder.append(string.substring(14));
                        }
                    } else {
                        stringBuilder.append(string);
                    }
                } else {
                    stringBuilder.append(string);
                }
                stringBuilder.append("]");
                if (!bl2 && (string2 = rawTLVField.getFieldWording()) != null) {
                    stringBuilder.append(" \"");
                    stringBuilder.append(string2);
                    stringBuilder.append("\"");
                }
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            return;
        }
        List<RawTLVTLVElement> list = rawTLVField.getTlv();
        if (list == null || list.isEmpty()) {
            return;
        }
        boolean bl5 = false;
        for (RawTLVTLVElement rawTLVTLVElement : list) {
            List<RawTLVTLVStructure> list2;
            int n5;
            List<String> list4 = rawTLVTLVElement.getTLVValue();
            String string3 = rawTLVTLVElement.getName();
            if (list4 != null && !list4.isEmpty()) {
                boolean bl6 = false;
                for (String string4 : list4) {
                    if (string4 == null || string4.isEmpty()) continue;
                    bl6 = true;
                }
                if (bl6) {
                    for (String string4 : list4) {
                        String string2;
                        if (!bl5) {
                            n5 = 1;
                            bl5 = true;
                            if (rawTLVPresence != null) {
                                if (bl3) {
                                    if (!bl2) {
                                        stringBuilder.append("   >>>   ");
                                    }
                                } else if (bl) {
                                    if (!bl2) {
                                        stringBuilder.append("   XXX   ");
                                    }
                                } else {
                                    n5 = 0;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (n5 != 0) {
                                String string5;
                                stringBuilder.append("[");
                                if (n < 10) {
                                    stringBuilder.append("00");
                                } else if (n < 100) {
                                    stringBuilder.append('0');
                                }
                                stringBuilder.append(n);
                                stringBuilder.append("]");
                                if (!bl2 && (string5 = rawTLVField.getFieldWording()) != null) {
                                    stringBuilder.append(": \"");
                                    stringBuilder.append(string5);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                        stringBuilder.append(UtilsYP.lineSeparator);
                        n5 = 1;
                        if (rawTLVPresence != null) {
                            if (bl3) {
                                List<RawTLVTLVPresence> list3 = rawTLVFieldPresence.getTlv();
                                if (list3 == null || list3.isEmpty()) {
                                    if (bl) {
                                        if (!bl2) {
                                            stringBuilder.append("   XXX   ");
                                        }
                                    } else {
                                        n5 = 0;
                                    }
                                } else {
                                    boolean bl4 = false;
                                    for (List<String> list5 : list3) {
                                        if (!string3.contentEquals(((RawTLVTLVPresence)((Object)list5)).getName())) continue;
                                        if (((RawTLVTLVPresence)((Object)list5)).getPresence() != null) {
                                            if (!bl2) {
                                                stringBuilder.append("   >>>   ");
                                            }
                                            bl4 = true;
                                            break;
                                        }
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            n5 = 0;
                                        }
                                        bl4 = true;
                                        break;
                                    }
                                    if (!bl4) {
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            n5 = 0;
                                        }
                                    }
                                }
                            } else if (bl) {
                                if (!bl2) {
                                    stringBuilder.append("   XXX   ");
                                }
                            } else {
                                n5 = 0;
                            }
                        } else if (!bl2) {
                            stringBuilder.append("   <<<   ");
                        }
                        if (n5 == 0) continue;
                        if (!bl2) {
                            stringBuilder.append("      ");
                        } else {
                            stringBuilder.append(" ");
                        }
                        stringBuilder.append("(");
                        stringBuilder.append(string3);
                        stringBuilder.append("):");
                        if (string4 == null) {
                            stringBuilder.append("null");
                            continue;
                        }
                        stringBuilder.append("(");
                        if (bl) {
                            stringBuilder.append(string4);
                        } else {
                            RawTLVFieldTraceType rawTLVFieldTraceType = rawTLVTLVElement.getFieldTrace();
                            switch (rawTLVFieldTraceType) {
                                case CVV_MASK: 
                                case END_OF_VALIDITY_MASK: {
                                    StringBuilder stringBuilder2 = new StringBuilder(string4.length());
                                    int n2 = 0;
                                    while (n2 < string4.length()) {
                                        stringBuilder2.append('#');
                                        ++n2;
                                    }
                                    stringBuilder.append(stringBuilder2.toString());
                                    break;
                                }
                                case ISO_1_MASK: 
                                case ISO_2_MASK: 
                                case ISO_3_MASK: {
                                    try {
                                        int n3 = string4.indexOf(68);
                                        if (n3 <= 0 || n3 <= 4) break;
                                        StringBuilder stringBuilder3 = new StringBuilder(string4);
                                        int n4 = 0;
                                        while (n4 < n3 - 4) {
                                            stringBuilder3.setCharAt(n4, '#');
                                            ++n4;
                                        }
                                        n4 = n3 + 1;
                                        while (n4 < string4.length()) {
                                            stringBuilder3.setCharAt(n4, '#');
                                            ++n4;
                                        }
                                        stringBuilder.append((CharSequence)stringBuilder3);
                                    }
                                    catch (Exception exception) {
                                        stringBuilder.append("null");
                                    }
                                    break;
                                }
                                case PAN_MASK: {
                                    stringBuilder.append(UtilsYP.maskPAN(string4));
                                    break;
                                }
                                default: {
                                    stringBuilder.append(string4);
                                }
                            }
                        }
                        stringBuilder.append(")");
                        if (bl2 || (string2 = rawTLVTLVElement.getWording()) == null) continue;
                        stringBuilder.append(" \"");
                        stringBuilder.append(string2);
                        stringBuilder.append("\"");
                    }
                    continue;
                }
            }
            if ((list2 = rawTLVTLVElement.getTLVStructureElt()) == null || list2.isEmpty()) continue;
            boolean bl8 = true;
            int n9 = list2.get(0).getTLVStructureValue().size();
            n5 = 0;
            while (n5 < n9) {
                for (RawTLVTLVStructure rawTLVTLVStructure : list2) {
                    Object object;
                    Object object2;
                    boolean bl6;
                    List<String> list5;
                    list5 = rawTLVTLVStructure.getTLVStructureValue();
                    if (list5 == null || list5.size() <= n5) continue;
                    boolean bl7 = true;
                    String string6 = list5.get(n5);
                    if (string6 != null && string6.length() > 0) {
                        if (!bl5) {
                            bl6 = true;
                            if (rawTLVPresence != null) {
                                if (bl3) {
                                    if (!bl2) {
                                        stringBuilder.append("   >>>   ");
                                    }
                                } else if (bl) {
                                    if (!bl2) {
                                        stringBuilder.append("   XXX   ");
                                    }
                                } else {
                                    bl6 = false;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (bl6) {
                                stringBuilder.append("[");
                                if (n < 10) {
                                    stringBuilder.append("00");
                                } else if (n < 100) {
                                    stringBuilder.append('0');
                                }
                                stringBuilder.append(n);
                                stringBuilder.append("]");
                                if (!bl2 && (object2 = rawTLVField.getFieldWording()) != null) {
                                    stringBuilder.append(":  \"");
                                    stringBuilder.append((String)object2);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                        if (!bl5 || bl8) {
                            bl6 = true;
                            stringBuilder.append(UtilsYP.lineSeparator);
                            if (rawTLVPresence != null) {
                                if (bl3) {
                                    object2 = rawTLVFieldPresence.getTlv();
                                    if (object2 == null) {
                                        if (bl) {
                                            if (!bl2) {
                                                stringBuilder.append("   XXX   ");
                                            }
                                        } else {
                                            bl6 = false;
                                        }
                                        bl7 = false;
                                    } else {
                                        boolean bl9 = false;
                                        object = object2.iterator();
                                        while (object.hasNext()) {
                                            RawTLVTLVPresence rawTLVTLVPresence = object.next();
                                            if (!string3.contentEquals(rawTLVTLVPresence.getName())) continue;
                                            if (rawTLVTLVPresence.getPresence() != null) {
                                                if (!bl2) {
                                                    stringBuilder.append("   >>>   ");
                                                }
                                                bl9 = true;
                                                break;
                                            }
                                            if (bl) {
                                                if (!bl2) {
                                                    stringBuilder.append("   XXX   ");
                                                }
                                            } else {
                                                bl6 = false;
                                            }
                                            bl9 = true;
                                            bl7 = false;
                                            break;
                                        }
                                        if (!bl9) {
                                            if (bl) {
                                                if (!bl2) {
                                                    stringBuilder.append("   XXX   ");
                                                }
                                            } else {
                                                bl6 = false;
                                            }
                                            bl7 = false;
                                        }
                                    }
                                } else {
                                    if (bl) {
                                        if (!bl2) {
                                            stringBuilder.append("   XXX   ");
                                        }
                                    } else {
                                        bl6 = false;
                                    }
                                    bl7 = false;
                                }
                            } else if (!bl2) {
                                stringBuilder.append("   <<<   ");
                            }
                            if (bl6) {
                                if (!bl2) {
                                    stringBuilder.append("      ");
                                } else {
                                    stringBuilder.append(" ");
                                }
                                stringBuilder.append("(");
                                stringBuilder.append(string3);
                                stringBuilder.append(")");
                                if (!bl2 && (object2 = rawTLVTLVElement.getWording()) != null) {
                                    stringBuilder.append(":  \"");
                                    stringBuilder.append((String)object2);
                                    stringBuilder.append("\"");
                                }
                            }
                        }
                    }
                    stringBuilder.append(UtilsYP.lineSeparator);
                    bl6 = true;
                    if (rawTLVPresence != null) {
                        if (bl7) {
                            if (!bl2) {
                                stringBuilder.append("   >>>   ");
                            }
                        } else if (bl) {
                            if (!bl2) {
                                stringBuilder.append("   XXX   ");
                            }
                        } else {
                            bl6 = false;
                        }
                    } else if (!bl2) {
                        stringBuilder.append("   <<<   ");
                    }
                    if (!bl6) continue;
                    if (!bl2) {
                        stringBuilder.append("               ");
                    } else {
                        stringBuilder.append("  ");
                    }
                    stringBuilder.append("{");
                    if (bl) {
                        stringBuilder.append(string6);
                    } else {
                        object2 = rawTLVTLVStructure.getFieldTrace();
                        switch (YP_TCD_PROT_RawTLV.$SWITCH_TABLE$org$yp$xml$jaxb$rawtlv$RawTLVFieldTraceType()[((Enum)object2).ordinal()]) {
                            case 3: 
                            case 4: {
                                StringBuilder stringBuilder4 = new StringBuilder(string6.length());
                                int n6 = 0;
                                while (n6 < string6.length()) {
                                    stringBuilder4.append('#');
                                    ++n6;
                                }
                                stringBuilder.append(stringBuilder4.toString());
                                break;
                            }
                            case 5: 
                            case 6: 
                            case 7: {
                                try {
                                    int n7 = string6.indexOf(68);
                                    if (n7 <= 0 || n7 <= 4) break;
                                    object = new StringBuilder(string6);
                                    int n8 = 0;
                                    while (n8 < n7 - 4) {
                                        ((StringBuilder)object).setCharAt(n8, '#');
                                        ++n8;
                                    }
                                    n8 = n7 + 1;
                                    while (n8 < string6.length()) {
                                        ((StringBuilder)object).setCharAt(n8, '#');
                                        ++n8;
                                    }
                                    stringBuilder.append((CharSequence)object);
                                }
                                catch (Exception exception) {
                                    stringBuilder.append("null");
                                }
                                break;
                            }
                            case 2: {
                                stringBuilder.append(UtilsYP.maskPAN(string6));
                                break;
                            }
                            default: {
                                stringBuilder.append(string6);
                            }
                        }
                    }
                    stringBuilder.append("}:  \"");
                    stringBuilder.append(rawTLVTLVStructure.getName());
                    stringBuilder.append("\"");
                    bl8 = false;
                    bl5 = true;
                }
                ++n5;
            }
        }
        if (bl5) {
            stringBuilder.append(UtilsYP.lineSeparator);
        }
    }

    public String getRawTLVlog(RawTLVMessage rawTLVMessage, RawTLVPresence rawTLVPresence, boolean bl, boolean bl2) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(UtilsYP.lineSeparator);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField1(), 1, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField2(), 2, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField3(), 3, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField4(), 4, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField5(), 5, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField6(), 6, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField7(), 7, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField8(), 8, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField9(), 9, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField10(), 10, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField11(), 11, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField12(), 12, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField13(), 13, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField14(), 14, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField15(), 15, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField16(), 16, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField17(), 17, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField18(), 18, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField19(), 19, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField20(), 20, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField21(), 21, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField22(), 22, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField23(), 23, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField24(), 24, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField25(), 25, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField26(), 26, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField27(), 27, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField28(), 28, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField29(), 29, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField30(), 30, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField31(), 31, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField32(), 32, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField33(), 33, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField34(), 34, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField35(), 35, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField36(), 36, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField37(), 37, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField38(), 38, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField39(), 39, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField40(), 40, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField41(), 41, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField42(), 42, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField43(), 43, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField44(), 44, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField45(), 45, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField46(), 46, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField47(), 47, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField48(), 48, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField49(), 49, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField50(), 50, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField52(), 52, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField53(), 53, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField54(), 54, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField55(), 55, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField56(), 56, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField59(), 59, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField60(), 60, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField61(), 61, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField62(), 62, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField63(), 63, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField64(), 64, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField65(), 65, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField66(), 66, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField67(), 67, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField68(), 68, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField69(), 69, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField70(), 70, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField71(), 71, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField72(), 72, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField73(), 73, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField74(), 74, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField76(), 76, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField80(), 80, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField81(), 81, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField82(), 82, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField83(), 83, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField84(), 84, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField85(), 85, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField86(), 86, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField201(), 201, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField202(), 202, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField203(), 203, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField204(), 204, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField205(), 205, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField206(), 206, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField301(), 303, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField302(), 302, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField303(), 303, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField304(), 304, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField305(), 305, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField306(), 306, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField307(), 307, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField308(), 308, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField309(), 309, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField310(), 310, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField311(), 311, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField312(), 312, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField313(), 313, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField314(), 314, bl, bl2);
            YP_TCD_PROT_RawTLV.logOneField(stringBuilder, rawTLVPresence, rawTLVMessage.getField401(), 401, bl, bl2);
            String string = stringBuilder.toString();
            while (string.indexOf(UtilsYP.doubleLineSeparator) >= 0) {
                string = string.replace(UtilsYP.doubleLineSeparator, UtilsYP.lineSeparator);
            }
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getRawTLVlog() " + exception);
            return null;
        }
    }

    private static void emptyOneField(RawTLVField rawTLVField) {
        if (rawTLVField == null) {
            return;
        }
        rawTLVField.setFieldValue(null);
        List<RawTLVTLVElement> list = rawTLVField.getTlv();
        if (list == null || list.isEmpty()) {
            return;
        }
        for (RawTLVTLVElement rawTLVTLVElement : list) {
            List<String> list2 = rawTLVTLVElement.getTLVValue();
            if (list2 != null && !list2.isEmpty()) {
                list2.clear();
                continue;
            }
            List<RawTLVTLVStructure> list3 = rawTLVTLVElement.getTLVStructureElt();
            if (list3 == null || list3.isEmpty()) continue;
            for (RawTLVTLVStructure rawTLVTLVStructure : list3) {
                List<String> list4 = rawTLVTLVStructure.getTLVStructureValue();
                if (list4 == null || list4.isEmpty()) continue;
                rawTLVTLVStructure.getTLVStructureValue().clear();
            }
        }
    }

    private void emptyRawTLVMessage(RawTLVMessage rawTLVMessage) {
        try {
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField1());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField2());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField3());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField4());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField5());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField6());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField7());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField8());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField9());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField10());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField11());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField12());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField13());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField14());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField15());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField16());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField17());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField18());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField19());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField20());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField21());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField22());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField23());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField24());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField25());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField26());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField27());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField28());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField29());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField30());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField31());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField32());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField33());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField34());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField35());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField36());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField37());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField38());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField39());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField40());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField41());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField42());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField43());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField44());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField45());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField46());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField47());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField48());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField49());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField50());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField52());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField53());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField54());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField55());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField56());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField59());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField60());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField61());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField62());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField63());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField64());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField65());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField66());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField67());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField68());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField69());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField70());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField71());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField72());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField73());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField74());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField76());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField80());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField81());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField82());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField83());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField84());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField85());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField86());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField201());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField202());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField203());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField204());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField205());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField206());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField301());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField302());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField303());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField304());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField305());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField306());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField307());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField308());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField309());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField310());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField311());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField312());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField313());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField314());
            YP_TCD_PROT_RawTLV.emptyOneField(rawTLVMessage.getField401());
        }
        catch (Exception exception) {
            this.logger(2, "emptyRawTLVMessage()  " + exception);
        }
    }

    @Override
    public int shutdown() {
        if (this.myRawTLVSendMessage != null) {
            this.myRawTLVSendMessage.onUse = 0;
        }
        if (this.myRawTLVReceiveMessage != null) {
            this.myRawTLVReceiveMessage.onUse = 0;
        }
        this.myIpduLayer = null;
        this.parserXML = null;
        return super.shutdown();
    }

    public void setApduBuffer(byte[] byArray) {
        this.apduBuffer = byArray;
    }

    public byte[] getApduBuffer() {
        return this.apduBuffer;
    }

    public YP_PROT_Interface_Com getIPDULayer() {
        return this.myIpduLayer;
    }

    public boolean isSet(RawTLVMessage rawTLVMessage, int n) {
        if (rawTLVMessage == null) {
            this.logger(2, "isSet() myRawTLVData null");
            return false;
        }
        if (n <= 0 || n > 128) {
            this.logger(2, "isSet() FieldNumber out of range ");
            return false;
        }
        RawTLVField rawTLVField = YP_TCD_PROT_RawTLV.getMessageField(rawTLVMessage, n);
        if (rawTLVField == null) {
            return false;
        }
        YP_RawTLVUtils.FieldFormat fieldFormat = YP_RawTLVUtils.getMyFieldFormat(rawTLVField.getFieldLengthType());
        if (fieldFormat == null) {
            this.logger(2, "isSet() pb with fieldFormat");
            return false;
        }
        if (!YP_TCD_PROT_RawTLV.isItATlv(fieldFormat)) {
            String string = rawTLVField.getFieldValue();
            return string != null && !string.isEmpty();
        }
        if (rawTLVField.getStructure() != null) {
            this.logger(3, "isSet() TODO");
        } else {
            List<RawTLVTLVElement> list = rawTLVField.getTlv();
            if (list != null && !list.isEmpty()) {
                for (RawTLVTLVElement rawTLVTLVElement : list) {
                    List<String> list2 = rawTLVTLVElement.getTLVValue();
                    if (list2 != null && !list2.isEmpty()) {
                        return true;
                    }
                    List<RawTLVTLVStructure> list3 = rawTLVTLVElement.getTLVStructureElt();
                    if (list3 == null || list3.isEmpty()) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public String getTlvReceivedOrder() {
        return this.tlvReceivedOrder.toString();
    }

    public void resetTlvReceivedOrder() {
        this.tlvReceivedOrder = new StringBuilder();
    }

    public static enum RawTLVStateMachine {
        DISCONNECTED,
        WAIT_CONNECTION,
        CONNECT,
        CONNECTED,
        WAIT_DISCONNETION;

    }
}

