/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.productlist;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_ProductList
extends YP_TCD_DCB_Interface_Extension {
    public YP_TCD_DesignAccesObject getProductListTable();

    public long getProductListTableChecksum();

    public List<YP_Row> getProductListByAID(String var1);

    public List<YP_Row> getProductListByBIN(String var1);

    public boolean isProductListSupported();
}

