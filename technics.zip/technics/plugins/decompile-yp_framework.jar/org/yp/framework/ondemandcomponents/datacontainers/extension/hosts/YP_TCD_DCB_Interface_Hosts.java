/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.hosts;

import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;

public interface YP_TCD_DCB_Interface_Hosts
extends YP_TCD_DCB_Interface_Extension {
    public boolean isTLCNeeded();

    public YP_PROT_Interface_Prot.ConnectionParameters getConnectionParameters(YP_PROT_Interface_Prot.SERVICEDEMANDE var1, int var2, boolean var3);

    public int getNbHost(YP_PROT_Interface_Prot.SERVICEDEMANDE var1);

    public int deleteTLPHosts();

    public int deleteHosts(YP_PROT_Interface_Prot.SERVICEDEMANDE var1);

    public int addHost(YP_PROT_Interface_Prot.SERVICEDEMANDE var1, int var2, String var3, String var4, String var5, String var6);
}

