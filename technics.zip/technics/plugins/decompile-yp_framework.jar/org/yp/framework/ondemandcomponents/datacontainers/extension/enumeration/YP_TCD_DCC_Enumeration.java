/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.YP_TCD_DCC_Interface_Enumeration;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects.DAO_Enumeration;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects.DAO_EnumerationValues;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCC_Enumeration
extends YP_OnDemandComponent
implements YP_TCD_DCC_Interface_Enumeration {
    private YP_TCD_DC_Context dataContainer;
    public YP_TCD_DesignAccesObject enumeration;
    public YP_TCD_DesignAccesObject enumerationValues;
    private final Map<String, Long> i18Finder = new ConcurrentHashMap<String, Long>();

    public YP_TCD_DCC_Enumeration(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DC_Context) {
            this.dataContainer = (YP_TCD_DC_Context)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.enumeration = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_Enumeration.class, 0, 0, null);
            this.enumerationValues = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_EnumerationValues.class, 0, 0, null);
        }
        catch (Exception exception) {
            this.logger(2, "YP_TCD_DCC_Enumeration", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtension_Enumeration";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.50";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.enumeration) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() enumeration");
            }
            this.i18Finder.clear();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.enumerationValues) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() enumerationValues");
            }
            this.i18Finder.clear();
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.enumeration) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() enumeration");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.enumerationValues) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() enumerationValues");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.enumeration) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() enumeration");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.enumerationValues) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() enumerationValues");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public List<Long> getIdLabelList(long l) {
        List<YP_Row> list;
        block5: {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.enumerationValues);
            yP_ComplexGabarit.set("idEnumeration", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = this.enumerationValues.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null) break block5;
            this.logger(2, "getIdLabelList() error with enumeration :" + l);
            return null;
        }
        try {
            ArrayList<Long> arrayList = new ArrayList<Long>();
            if (list.isEmpty()) {
                this.logger(2, "getIdLabelList() enumeration not found:" + l);
                return arrayList;
            }
            int n = 0;
            while (n < list.size()) {
                DAO_EnumerationValues dAO_EnumerationValues = (DAO_EnumerationValues)list.get(n);
                arrayList.add(dAO_EnumerationValues.idLabel);
                ++n;
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getIdLabelList() ", exception);
            return null;
        }
    }

    @Override
    public long getIdLabel(long l, String string) {
        List<YP_Row> list;
        String string2;
        block6: {
            try {
                YP_Object yP_Object;
                YP_Row yP_Row;
                StringBuilder stringBuilder = new StringBuilder(32);
                stringBuilder.append(l);
                stringBuilder.append('_');
                stringBuilder.append(string);
                string2 = stringBuilder.toString();
                Long l2 = this.i18Finder.get(string2);
                if (l2 != null) {
                    return l2;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.enumerationValues);
                yP_ComplexGabarit.set("idEnumeration", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                yP_ComplexGabarit.set("enumerationValues", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.enumerationValues.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block6;
                this.logger(2, "getIdLabel() enumeration not found:" + l + " " + string);
                if (UtilsYP.getInstanceRole() == 1 && (yP_Row = (YP_Row)(yP_Object = this.getPluginByName("Internationalization")).dealRequest(this, "createNewLabel", string)) != null) {
                    long l3 = yP_Row.getPrimaryKey();
                    YP_Row yP_Row2 = this.enumerationValues.getNewRow();
                    yP_Row2.set("idEnumeration", l);
                    yP_Row2.set("enumerationValues", string);
                    yP_Row2.set("idLabel", l3);
                    this.enumerationValues.addRow(yP_Row2, true);
                    this.enumerationValues.persist();
                    return l3;
                }
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "getIdLabel() ", exception);
                return -1L;
            }
        }
        if (list.size() > 1) {
            this.logger(3, "getIdLabel() more than one enumeration found:" + l + " " + string + ". We take the first one");
        }
        DAO_EnumerationValues dAO_EnumerationValues = (DAO_EnumerationValues)list.get(0);
        this.i18Finder.put(string2, dAO_EnumerationValues.idLabel);
        return dAO_EnumerationValues.idLabel;
    }

    @Override
    public long getIdLabel(Enum<?> enum_) {
        List<YP_Row> list;
        String string;
        block5: {
            try {
                String string2 = enum_.getClass().getSimpleName();
                StringBuilder stringBuilder = new StringBuilder(32);
                stringBuilder.append(string2);
                stringBuilder.append('_');
                stringBuilder.append(enum_.toString());
                string = stringBuilder.toString();
                Long l = this.i18Finder.get(string);
                if (l != null) {
                    return l;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.enumeration);
                yP_ComplexGabarit.set("enumerationName", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                list = this.enumeration.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block5;
                this.logger(2, "getIdLabel() enumeration not found:" + enum_);
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "getIdLabel() ", exception);
                return -1L;
            }
        }
        if (list.size() > 1) {
            this.logger(2, "getIdLabel() more than one enumeration found:" + enum_ + ". We take the first one");
        }
        long l = (Long)list.get(0).getFieldValueByName("idEnumeration");
        long l2 = this.getIdLabel(l, enum_.toString());
        this.i18Finder.put(string, l2);
        return l2;
    }
}

