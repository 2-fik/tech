/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.posmate;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class PosmateMessageAdaptor {
    private TLV dukptTLV = null;
    private ExtendedTVR extendedTVR = null;
    private String issuerScriptResults = null;
    private String authorizationNumber = null;
    private String transactionLocalTime;
    private String authorizedAmount;
    private String acquirerIdentifier;
    private String terminalIdentifier;
    private String merchantIdentifier;
    private String tavnList;
    private byte[] tvr;
    private byte[] tacDefault;
    private byte[] tacDenial;
    private byte[] tacOnline;
    private String targetPercentageRandomSelection;
    private String maxTargetPercentageRandomSelection;
    private String thresholdValueRandomSelection;
    private long floorLimit;
    private long floorLimitDefault;
    private long floorLimitPIN;
    private long floorLimitSignature;
    private String tdol;
    private String ddol;
    private String amountAuthorized;
    private int interCharacterTimeout = 20;
    private int doesCardAppear;
    private int recentTransaction;
    private String lastTransactionAmount;
    private int authorizationResult;
    private int issuerResponse;
    private String issuerAuthorizationCode;
    private String issuerAuthenticationData;
    private String issuerScripts = "";
    private String authDisplayCardHolderMessage;
    private int currentPosmateMessage = 0;
    private TransactionStatusEnumeration initialPosmateStatus = TransactionStatusEnumeration.UNKNOWN;
    private String decryptedMerchantCode;

    /*
     * Enabled aggressive exception aggregation
     */
    public int checkPosMateMessage(YP_Application yP_Application) {
        YP_TCD_DC_Transaction yP_TCD_DC_Transaction = yP_Application.getDataContainerTransaction();
        YP_TCD_DCC_Business yP_TCD_DCC_Business = yP_Application.getDataContainerBusiness();
        try {
            Object object;
            Object object2;
            TLV tLV6;
            String string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
            if (string == null || string.isEmpty()) {
                if (yP_TCD_DC_Transaction.getLogLevel() >= 6) {
                    yP_TCD_DC_Transaction.logger(6, "checkPosMateMessage() no app tags");
                }
                return 0;
            }
            TLV tLV2 = null;
            TLV tLV3 = null;
            TLV tLV4 = null;
            TLV tLV5 = null;
            TLVHandler tLVHandler = new TLVHandler(string);
            block64: for (TLV tLV6 : tLVHandler) {
                block1 : switch (tLV6.tag) {
                    case 14672756: {
                        tLV5 = tLV6;
                        if (tLV2 == null) {
                            tLV2 = tLV6;
                        } else if (tLV3 == null) {
                            tLV3 = tLV6;
                        } else {
                            tLV4 = tLV6;
                        }
                        this.logPosmateMessage(yP_TCD_DC_Transaction, tLV6.value);
                        if (tLV6.value == null || tLV6.value.length < 6 || UtilsYP.indexOf(tLV6.value, 0, 4, new byte[]{2, 52, 56, 49}) != 0) continue block64;
                        object2 = "" + (char)tLV6.value[4] + (char)tLV6.value[5];
                        switch (object2) {
                            case "00": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (mPOS) General Failure");
                                break block1;
                            }
                            case "01": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Application Selection Failure");
                                break block1;
                            }
                            case "02": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Initiate Application Processing Failure");
                                break block1;
                            }
                            case "03": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Read Application Data Failure");
                                break block1;
                            }
                            case "04": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Offline Data Authentication Failure");
                                break block1;
                            }
                            case "05": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Process Restrictions Failure");
                                break block1;
                            }
                            case "06": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Terminal Risk Management Failure");
                                break block1;
                            }
                            case "07": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Cardholder Verification Method Failure");
                                break block1;
                            }
                            case "08": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Terminal Action Analysis Failure");
                                break block1;
                            }
                            case "09": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Card Action Analysis Failure");
                                break block1;
                            }
                            case "10": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Completion Failure");
                                break block1;
                            }
                            case "11": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (EPOS) Transaction Terminated");
                                break block1;
                            }
                            case "12": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) No Answer to Reset");
                                break block1;
                            }
                            case "13": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Swipe) Read Failure");
                                break block1;
                            }
                            case "14": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Card Removed");
                                yP_TCD_DC_Transaction.getExtendedTVR().add(ExtendedTVREnumeration.CARD_REMOVED);
                                break block1;
                            }
                            case "15": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (mPOS) User Cancelled");
                                if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.PIN_ABORTED)) break block1;
                                yP_TCD_DC_Transaction.getExtendedTVR().add(ExtendedTVREnumeration.USER_ABORT);
                                break block1;
                            }
                            case "16": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) No Supported Applications");
                                break block1;
                            }
                            case "17": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Card Blocked");
                                break block1;
                            }
                            case "18": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Chip) Read Failure");
                                break block1;
                            }
                            case "19": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (mPOS) User Time Out");
                                yP_TCD_DC_Transaction.getExtendedTVR().add(ExtendedTVREnumeration.USER_ABORT);
                                break block1;
                            }
                            case "20": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (mPOS) DUKPT Key Failure");
                                break block1;
                            }
                            case "21": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (mPOS) MK/SK Key Failure");
                                break block1;
                            }
                            case "22": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Contactless) Not Allowed");
                                break block1;
                            }
                            case "23": {
                                yP_TCD_DC_Transaction.logger(4, "checkPosMateMessage() (Contactless) Aborted");
                                break block1;
                            }
                        }
                        yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage() unknown reason:" + (String)object2);
                        break;
                    }
                }
            }
            TLV tLV7 = tLV6 = tLV3 == null ? tLV2 : tLV3;
            if (tLV6 == null || tLV6.value == null || tLV6.value.length == 0) {
                if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                    yP_TCD_DC_Transaction.logger(5, "checkPosMateMessage(): No POSMATE_MESSAGE to test");
                }
                return 0;
            }
            Object object3 = new byte[20];
            System.arraycopy(tLV6.value, tLV6.value.length - (2 + ((Object)object3).length), object3, 0, ((Object)object3).length);
            object2 = new byte[16];
            System.arraycopy(tLV6.value, tLV6.value.length - (2 + ((Object)object3).length + ((byte[])object2).length), object2, 0, ((byte[])object2).length);
            byte[] byArray = new byte[tLV6.value.length - 39];
            System.arraycopy(tLV6.value, 1, byArray, 0, byArray.length);
            Object object4 = new String((byte[])object3);
            boolean bl = DUKPT.checkRequestDataMaced((String)object4, byArray, new String((byte[])object2));
            if (!bl) {
                yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage(): bad MAC !!!");
                return -2;
            }
            this.currentPosmateMessage = (tLV5.value[1] - 48) * 10 + (tLV5.value[2] - 48);
            object3 = yP_TCD_DC_Transaction.commonHandler.getRequestEMVTags();
            long l = -1L;
            if (object3 != null && !((String)object3).isEmpty()) {
                object4 = new TLVHandler((String)object3);
                object = ((TLVHandler)object4).iterator();
                while (object.hasNext()) {
                    TLV tLV8 = object.next();
                    switch (tLV8.tag) {
                        case 137: {
                            this.authorizationNumber = UtilsYP.devHexa(tLV8.value);
                            break;
                        }
                        case 40706: {
                            l = TLVHandler.getDCBLong(tLV8.value);
                        }
                    }
                }
            } else if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                yP_TCD_DC_Transaction.logger(5, "checkPosMateMessage() no EMV tags");
            }
            object4 = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
            switch (PosmateMessageAdaptor.$SWITCH_TABLE$org$yp$utils$enums$EntryModeEnumeration()[((Enum)object4).ordinal()]) {
                case 8: 
                case 11: 
                case 12: {
                    List<TLV> list = this.parseSupplementary(yP_TCD_DC_Transaction, tLV6.value);
                    if (object3 != null && !((String)object3).isEmpty()) {
                        object = new TLVHandler();
                        for (TLV tLV9 : list) {
                            ((TLVHandler)object).add(tLV9);
                        }
                        if (!(((String)object3).equalsIgnoreCase(((TLVHandler)object).toString()) || ((String)object3).contains(((TLVHandler)object).toString()) && yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.REFERRAL_DONE) || ((String)object3).contains(((TLVHandler)object).toString()) && yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_ACCEPTED) || ((String)object3).contains(((TLVHandler)object).toString()) && object4 != EntryModeEnumeration.ENTRY_MODE_ICC)) {
                            yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage(): EMV tags have been modified");
                            return -1;
                        }
                    }
                    if (tLV4 != null) {
                        this.extractSupplementaryNFC(yP_TCD_DC_Transaction, tLV4.value);
                    }
                    if (tLV2 != null) {
                        if (yP_TCD_DC_Transaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC && tLV2.value.length >= 6 && UtilsYP.indexOf(tLV2.value, 0, 3, new byte[]{2, 52, 55}) == 0) {
                            int n = 0;
                            while (n < tLV2.value.length && tLV2.value[n] != 28) {
                                ++n;
                            }
                            if (++n < tLV2.value.length && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                                yP_TCD_DC_Transaction.logger(5, "checkPosMateMessage(): " + tLV2.value[n]);
                            }
                            if (n < tLV2.value.length && tLV2.value[n] != 48 && tLV2.value[n] != 50) {
                                yP_Application.getDataContainerTransaction().commonHandler.setTransactionStatus(TransactionStatusEnumeration.REFUSED);
                            }
                        } else if (yP_TCD_DC_Transaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion && tLV2.value.length >= 6 && UtilsYP.indexOf(tLV2.value, 0, 3, new byte[]{2, 52, 55}) == 0) {
                            int n = 0;
                            while (n < tLV2.value.length && tLV2.value[n] != 28) {
                                ++n;
                            }
                            if (++n < tLV2.value.length && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                                yP_TCD_DC_Transaction.logger(5, "checkPosMateMessage(): " + tLV2.value[n]);
                            }
                            if (n < tLV2.value.length && tLV2.value[n] != 48 && tLV2.value[n] != 50) {
                                yP_TCD_DC_Transaction.logger(3, "checkPosMateMessage(): Trs refused by terminal");
                                this.initialPosmateStatus = TransactionStatusEnumeration.REFUSED;
                            }
                        }
                    }
                    if (object4 != EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS && object4 != EntryModeEnumeration.ENTRY_MODE_TAPPED || yP_TCD_DC_Transaction.getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC || l < 0L || l == yP_TCD_DC_Transaction.commonHandler.getTransactionAmount()) break;
                    yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage(): Amount have been modified");
                    return -1;
                }
                default: {
                    Object object5;
                    object = PosmateMessageAdaptor.extractEncryptedTrack2(tLV2.value);
                    String string2 = PosmateMessageAdaptor.extractKSN(tLV2.value);
                    String string3 = yP_TCD_DCC_Business.getApplicationPlugin().getApplicationPropertie("MarocTrsFlow");
                    if (string3 != null && (string3.contentEquals("1") || string3.toLowerCase().contentEquals("true")) && (object5 = PosmateMessageAdaptor.extractFallBackIndicator(tLV2.value)) != null && ((Boolean)object5).booleanValue()) {
                        YP_TCD_DCC_Business.setPaymentTechnology(yP_TCD_DC_Transaction, EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE_FALLBACK);
                    }
                    object5 = new TLVHandler();
                    ((TLVHandler)object5).add(14672737, string2);
                    ((TLVHandler)object5).add(14672738, (String)object);
                    this.dukptTLV = new TLV();
                    this.dukptTLV.tag = 16769892;
                    String string4 = ((TLVHandler)object5).toString();
                    this.dukptTLV.value = UtilsYP.redHexa(string4);
                    this.dukptTLV.length = this.dukptTLV.value.length;
                    if (tLV3 == null) break;
                    this.extractSupplementaryMagstripe(yP_TCD_DC_Transaction, tLV3.value);
                }
            }
            if (this.dukptTLV != null && !string.contains(UtilsYP.devHexa(this.dukptTLV.value))) {
                yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage(): DUKPT have been modified");
                return -1;
            }
            if (this.checkMerchantCodeForRefundOrReversalValidation(yP_TCD_DC_Transaction, yP_TCD_DCC_Business) != 1) {
                yP_TCD_DC_Transaction.logger(3, "checkPosMateMessage(): Error during verification of Merchant Code");
                YP_TCD_DCC_Business.setTransactionStatus(yP_TCD_DC_Transaction, TransactionStatusEnumeration.REFUSED);
            }
            return 1;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            yP_TCD_DC_Transaction.logger(2, "checkPosMateMessage():  " + exception);
            return -1;
        }
    }

    private void logPosmateMessage(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        try {
            if (byArray == null || byArray.length < 3) {
                yP_TCD_DC_Transaction.logger(2, "logPosmateMessage() bad message");
                return;
            }
            if (yP_TCD_DC_Transaction.getLogLevel() < 5) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder(byArray.length + 64);
            if (byArray[0] == 2) {
                stringBuilder.append("<STX>");
            } else {
                stringBuilder.append("<???>");
            }
            int n = 1;
            while (n < byArray.length - 2) {
                if (byArray[n] == 28) {
                    stringBuilder.append("<FS>");
                } else if (byArray[n] == 31) {
                    stringBuilder.append("<US>");
                } else {
                    stringBuilder.append((char)byArray[n]);
                }
                ++n;
            }
            if (byArray[byArray.length - 2] == 3) {
                stringBuilder.append("<ETX>");
            } else {
                stringBuilder.append("<???>");
            }
            stringBuilder.append('[');
            stringBuilder.append(UtilsYP.devHexa(byArray, byArray.length - 1, 1));
            stringBuilder.append(']');
            yP_TCD_DC_Transaction.logger(5, "logPosmateMessage() PosMate Message RECEIVED:" + stringBuilder.toString());
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(2, "logPosmateMessage() " + exception);
        }
    }

    @Deprecated
    public String getTransactionAndApplicationDataMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return this.getTransactionAndApplicationDataMsg(yP_TCD_DC_Transaction, false, true);
    }

    public String getTransactionAndApplicationDataMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl, boolean bl2) {
        Object object;
        Object object2;
        Object object3;
        Object object4;
        int n;
        block71: {
            Object object5;
            Object object7;
            block70: {
                n = 3;
                try {
                    object4 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object3 = ((TLVHandler)object4).iterator();
                    block61: while (object3.hasNext()) {
                        object7 = object3.next();
                        switch (((TLV)object7).tag) {
                            case 14672409: {
                                int n2 = TLVHandler.getDCBInt(((TLV)object7).value);
                                if (n2 == 1) {
                                    n = 0;
                                    break;
                                }
                                if (n2 == 2 || n2 != 3) continue block61;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672659: 
                            case 14672660: 
                            case 14672661: {
                                break;
                            }
                            case 14672642: {
                                String object62 = UtilsYP.devHexa(((TLV)object7).value);
                                this.extendedTVR = new ExtendedTVR(object62);
                                break;
                            }
                            case 14672456: {
                                this.interCharacterTimeout = TLVHandler.getDCBInt(((TLV)object7).value);
                                break;
                            }
                            case 14672657: {
                                break;
                            }
                            case 14672485: {
                                this.floorLimitDefault = TLVHandler.getDCBLong(((TLV)object7).value);
                                break;
                            }
                            case 14672486: {
                                this.floorLimitPIN = TLVHandler.getDCBLong(((TLV)object7).value);
                                break;
                            }
                            case 14672488: {
                                this.floorLimitSignature = TLVHandler.getDCBLong(((TLV)object7).value);
                                break;
                            }
                            case 14672487: 
                            case 14672489: {
                                break;
                            }
                            case -538738359: 
                            case -538738358: 
                            case -2064111: 
                            case 14672129: 
                            case 14672716: 
                            case 16769856: {
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg(): APP tag not handled :" + Integer.toHexString(((TLV)object7).tag));
                            }
                        }
                    }
                    object7 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseEMVTags());
                    object3 = null;
                    object5 = null;
                    object2 = ((TLVHandler)object7).iterator();
                    while (object2.hasNext()) {
                        TLV tLV = object2.next();
                        switch (tLV.tag) {
                            case 154: {
                                object3 = UtilsYP.devHexa(tLV.value);
                                break;
                            }
                            case 40737: {
                                object5 = UtilsYP.devHexa(tLV.value);
                                break;
                            }
                            case 156: {
                                break;
                            }
                            case 40706: {
                                this.authorizedAmount = UtilsYP.devHexa(tLV.value);
                                break;
                            }
                            case 40732: {
                                this.terminalIdentifier = new String(tLV.value);
                                break;
                            }
                            case 40726: {
                                this.merchantIdentifier = new String(tLV.value);
                                break;
                            }
                            case 40705: {
                                this.acquirerIdentifier = new String(tLV.value);
                                break;
                            }
                            case 40731: {
                                break;
                            }
                            case 24362: {
                                break;
                            }
                            case 24374: {
                                break;
                            }
                            case 40725: {
                                break;
                            }
                            case 40730: {
                                break;
                            }
                            case 40761: {
                                break;
                            }
                            case 40769: {
                                break;
                            }
                            case 40782: {
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg(): EMV tag not handled :" + Integer.toHexString(tLV.tag));
                            }
                        }
                    }
                    if (object3 != null && object5 != null) {
                        this.transactionLocalTime = String.valueOf(object3) + (String)object5;
                    }
                    for (AccountHandler.ADF aDF : yP_TCD_DC_Transaction.accountHandler.getADFList()) {
                        TLV tLV;
                        Iterator<TLV> iterator;
                        if (aDF.appTagsExtension != null) {
                            object = new TLVHandler(aDF.appTagsExtension);
                            iterator = ((TLVHandler)object).iterator();
                            while (iterator.hasNext()) {
                                tLV = iterator.next();
                                switch (tLV.tag) {
                                    case 14672677: {
                                        this.tacDefault = tLV.value;
                                        break;
                                    }
                                    case 14672675: {
                                        this.tacDenial = tLV.value;
                                        break;
                                    }
                                    case 14672676: {
                                        this.tacOnline = tLV.value;
                                        break;
                                    }
                                    case 14672427: {
                                        this.targetPercentageRandomSelection = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672428: {
                                        this.maxTargetPercentageRandomSelection = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672426: {
                                        this.thresholdValueRandomSelection = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672425: {
                                        break;
                                    }
                                    case 14672685: {
                                        this.tavnList = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672680: {
                                        this.tdol = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672678: {
                                        this.ddol = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    case 14672223: {
                                        break;
                                    }
                                    case -538803909: {
                                        this.amountAuthorized = UtilsYP.devHexa(tLV.value);
                                        break;
                                    }
                                    default: {
                                        yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg(): APP tag extension not handled :" + Integer.toHexString(tLV.tag));
                                    }
                                }
                            }
                        }
                        if (aDF.emvTagsExtension == null || (object = new TLVHandler(aDF.emvTagsExtension)) == null) continue;
                        iterator = ((TLVHandler)object).iterator();
                        while (iterator.hasNext()) {
                            tLV = iterator.next();
                            switch (tLV.tag) {
                                case 40787: {
                                    break;
                                }
                                case 57103: {
                                    yP_TCD_DC_Transaction.logger(3, "getTransactionAndApplicationDataMsg(): Tag DF0F found -> probably a B12-V1 contract");
                                    break;
                                }
                                default: {
                                    yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg(): EMV tag extension not handled :" + Integer.toHexString(tLV.tag));
                                }
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg():" + exception);
                }
                switch (YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction)) {
                    case DEBIT: 
                    case QUASI_CASH: 
                    case INITIAL_RESERVATION: 
                    case ONE_TIME_RESERVATION: 
                    case COMPLEMENTARY_PAYMENT: 
                    case DEBIT_DIFFERED: {
                        object4 = "00";
                        break;
                    }
                    case CREDIT: 
                    case COMPLEMENTARY_REFUND: 
                    case REFUND_QUASI_CASH: {
                        object4 = "20";
                        break;
                    }
                    case REVERSAL_DEBIT: 
                    case REVERSAL_QUASI_CASH: {
                        object4 = "22";
                        break;
                    }
                    default: {
                        object4 = "??";
                    }
                }
                object7 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object7 != null && !((String)object7).isEmpty()) break block70;
                yP_TCD_DC_Transaction.logger(3, "getTransactionAndApplicationDataMsg() no app tags");
                return null;
            }
            try {
                object3 = null;
                object5 = new TLVHandler((String)object7);
                object2 = ((TLVHandler)object5).iterator();
                while (object2.hasNext()) {
                    TLV tLV = (TLV)object2.next();
                    switch (tLV.tag) {
                        case 14672756: {
                            object3 = tLV;
                            break;
                        }
                    }
                }
                if (object3 != null && ((TLV)object3).value != null && ((TLV)object3).value.length != 0) break block71;
                yP_TCD_DC_Transaction.logger(3, "getTransactionAndApplicationDataMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getTransactionAndApplicationDataMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (((TLV)object3).value[1] - 48) * 10 + (((TLV)object3).value[2] - 48);
        int n2 = ((TLV)object3).value[3] - 48;
        object2 = new byte[20];
        System.arraycopy(((TLV)object3).value, ((TLV)object3).value.length - (2 + ((Object)object2).length), object2, 0, ((Object)object2).length);
        object = new String((byte[])object2);
        return this.buildGetTransactionAndApplicationData((String)object, n2, n, (String)object4, bl, bl2);
    }

    public String getTerminalRiskManagementMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        Object object;
        Object object2;
        int n;
        block52: {
            Object object3;
            Object object4;
            Object object5;
            block51: {
                long l = 0L;
                n = 3;
                try {
                    object5 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object4 = ((TLVHandler)object5).iterator();
                    block21: while (object4.hasNext()) {
                        object2 = object4.next();
                        switch (((TLV)object2).tag) {
                            case 14672409: {
                                int n2 = TLVHandler.getDCBInt(((TLV)object2).value);
                                if (n2 == 1) {
                                    n = 0;
                                    break;
                                }
                                if (n2 == 2 || n2 != 3) continue block21;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672642: {
                                object = UtilsYP.devHexa(((TLV)object2).value);
                                this.extendedTVR = new ExtendedTVR((String)object);
                                break;
                            }
                            case 14672406: {
                                l = TLVHandler.getDCBLong(((TLV)object2).value);
                                break;
                            }
                            case 14672160: 
                            case 14672161: 
                            case 14672162: 
                            case 14672205: 
                            case 14672697: 
                            case 14672698: 
                            case 14672713: 
                            case 16769856: 
                            case 16769870: {
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getTerminalRiskManagementMsg(): APP tag not handled :" + Integer.toHexString(((TLV)object2).tag));
                            }
                        }
                    }
                    object2 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseEMVTags());
                    object3 = ((TLVHandler)object2).iterator();
                    while (object3.hasNext()) {
                        object4 = object3.next();
                        try {
                            switch (((TLV)object4).tag) {
                                case 40731: {
                                    this.floorLimit = TLVHandler.getLong(((TLV)object4).value);
                                    break;
                                }
                                case 149: {
                                    this.tvr = ((TLV)object4).value;
                                    break;
                                }
                                default: {
                                    yP_TCD_DC_Transaction.logger(2, "getTerminalRiskManagementMsg(): EMV tag not handled :" + Integer.toHexString(((TLV)object4).tag));
                                    break;
                                }
                            }
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            yP_TCD_DC_Transaction.logger(2, "getTerminalRiskManagementMsg():  " + exception);
                        }
                    }
                }
                catch (Exception exception) {
                    yP_TCD_DC_Transaction.logger(2, "getTerminalRiskManagementMsg(): Exception " + exception);
                    exception.printStackTrace();
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): FOREIGN_CURRENCY 1657");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                    if (l < this.floorLimit) {
                        l = this.floorLimit;
                    }
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.AMOUNT_ABOVE_FLOOR_LIMIT)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): Amount (" + yP_TCD_DC_Transaction.commonHandler.getTransactionAmount() + ") > floor limit (" + this.floorLimit + ") 1510");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.CUMULATED_AMOUNT_ABOVE_FLOOR_LIMIT)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): Cumul (" + l + ") > floor limit (" + this.floorLimit + ") 1651");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.BIN_UNKNOWN)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): BIN_UNKNOWN 1653");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                    if (l < this.floorLimit) {
                        l = this.floorLimit;
                    }
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.BIN_WATCHED)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): BIN_WATCHED 1652");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                    if (l < this.floorLimit) {
                        l = this.floorLimit;
                    }
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): BIN_REFUSED 1663");
                    this.tvr[0] = (byte)(this.tvr[0] | 0x10);
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): BIN_FORBIDDEN 1512");
                    this.tvr[0] = (byte)(this.tvr[0] | 0x10);
                } else {
                    yP_TCD_DC_Transaction.logger(4, "getTerminalRiskManagementMsg(): BIN accepted");
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.PRE_AUTO)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): PRE_AUTO 1655");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                    if (l < this.floorLimit) {
                        l = this.floorLimit;
                    }
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.CARD_WATCHED)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): CARD_WATCHED 1654");
                    this.tvr[3] = (byte)(this.tvr[3] | 0x80);
                    if (l < this.floorLimit) {
                        l = this.floorLimit;
                    }
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): CARD_REFUSED 1659");
                    this.tvr[0] = (byte)(this.tvr[0] | 0x10);
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): CARD_FORBIDDEN 1513");
                    this.tvr[0] = (byte)(this.tvr[0] | 0x10);
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): CARD_EXPIRED");
                    this.tvr[1] = (byte)(this.tvr[1] | 0x40);
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): CARD_NOT_YET_VALID");
                    this.tvr[1] = (byte)(this.tvr[1] | 0x20);
                }
                this.doesCardAppear = 0;
                if ((this.tvr[0] & 0x10) != 0) {
                    this.doesCardAppear = 2;
                }
                this.recentTransaction = 0;
                if (l != yP_TCD_DC_Transaction.commonHandler.getTransactionAmount()) {
                    this.recentTransaction = 1;
                    this.lastTransactionAmount = Long.toString(l - yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
                }
                object5 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object5 != null && !((String)object5).isEmpty()) break block51;
                yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg() no app tags");
                return null;
            }
            try {
                object2 = null;
                object4 = new TLVHandler((String)object5);
                object = ((TLVHandler)object4).iterator();
                while (object.hasNext()) {
                    object3 = (TLV)object.next();
                    switch (((TLV)object3).tag) {
                        case 14672756: {
                            object2 = object3;
                            break;
                        }
                    }
                }
                if (object2 != null && ((TLV)object2).value != null && ((TLV)object2).value.length != 0) break block52;
                yP_TCD_DC_Transaction.logger(3, "getTerminalRiskManagementMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getTerminalRiskManagementMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (((TLV)object2).value[1] - 48) * 10 + (((TLV)object2).value[2] - 48);
        int n3 = ((TLV)object2).value[3] - 48;
        object = new byte[20];
        System.arraycopy(((TLV)object2).value, ((TLV)object2).value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        String string = new String((byte[])object);
        if (this.currentPosmateMessage == 47) {
            return this.buildCompleteTransaction(string, n3, n, 0);
        }
        return this.buildTerminalRiskManagement(string, n3, n, yP_TCD_DC_Transaction);
    }

    public String getGoOnlineMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        String string;
        Object object;
        Object object2;
        int n;
        block47: {
            Object object3;
            Object object4;
            Object object5;
            block46: {
                n = 3;
                try {
                    object5 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object4 = ((TLVHandler)object5).iterator();
                    block25: while (object4.hasNext()) {
                        object2 = object4.next();
                        switch (((TLV)object2).tag) {
                            case 14672409: {
                                int n2 = TLVHandler.getDCBInt(((TLV)object2).value);
                                if (n2 == 1) {
                                    n = 0;
                                    break;
                                }
                                if (n2 == 2 || n2 != 3) continue block25;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672642: {
                                object = UtilsYP.devHexa(((TLV)object2).value);
                                this.extendedTVR = new ExtendedTVR((String)object);
                                break;
                            }
                            case 14672710: {
                                string = UtilsYP.devHexa(((TLV)object2).value);
                                this.issuerScripts = String.valueOf(this.issuerScripts) + string;
                                break;
                            }
                            case 14672711: {
                                String string2 = UtilsYP.devHexa(((TLV)object2).value);
                                this.issuerScripts = String.valueOf(this.issuerScripts) + string2;
                                break;
                            }
                            case -538803908: 
                            case -538803893: 
                            case 14672160: 
                            case 14672162: 
                            case 14672646: 
                            case 14672647: 
                            case 14672657: 
                            case 14672661: 
                            case 14672697: 
                            case 14672698: 
                            case 14672713: 
                            case 16769856: {
                                break;
                            }
                            case -538803909: {
                                this.amountAuthorized = UtilsYP.devHexa(((TLV)object2).value);
                                break;
                            }
                            case 14672648: {
                                this.authDisplayCardHolderMessage = new String(((TLV)object2).value);
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsg(): APP tag not handled :" + Integer.toHexString(((TLV)object2).tag));
                            }
                        }
                    }
                    object2 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseEMVTags());
                    object3 = ((TLVHandler)object2).iterator();
                    while (object3.hasNext()) {
                        object4 = object3.next();
                        switch (((TLV)object4).tag) {
                            case 137: {
                                this.authorizationNumber = UtilsYP.devHexa(((TLV)object4).value);
                                break;
                            }
                            case 138: {
                                this.issuerAuthorizationCode = new String(((TLV)object4).value);
                                break;
                            }
                            case 145: {
                                this.issuerAuthenticationData = UtilsYP.devHexa(((TLV)object4).value);
                                break;
                            }
                            case 149: {
                                this.tvr = ((TLV)object4).value;
                                break;
                            }
                            case 40706: {
                                this.authorizedAmount = UtilsYP.devHexa(((TLV)object4).value);
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsg(): EMV tag not handled :" + Integer.toHexString(((TLV)object4).tag));
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsg(): Exception " + exception);
                    exception.printStackTrace();
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_ACCEPTED)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): PARTIAL_AUTHORIZATION_ACCEPTED");
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): PARTIAL_AUTHORIZATION");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.REFERRAL_DONE)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): REFERRAL_DONE");
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFERRAL)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): AUTHORIZATION_REFERRAL");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): AUTHORIZATION_REFUSED");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): AUTHORIZATION_FORBIDDEN");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): AUTHORIZATION_INCIDENT");
                    this.authorizationResult = 0;
                    this.issuerResponse = -1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsg(): FORCED_BEFORE_CALL");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                    this.issuerAuthorizationCode = "Y1";
                } else {
                    if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                        yP_TCD_DC_Transaction.logger(5, "getGoOnlineMsg(): Authorization OK");
                    }
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                }
                object5 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object5 != null && !((String)object5).isEmpty()) break block46;
                yP_TCD_DC_Transaction.logger(3, "getGoOnlineMsg() no app tags");
                return null;
            }
            try {
                object2 = null;
                object4 = new TLVHandler((String)object5);
                object = ((TLVHandler)object4).iterator();
                while (object.hasNext()) {
                    object3 = (TLV)object.next();
                    switch (((TLV)object3).tag) {
                        case 14672756: {
                            object2 = object3;
                            break;
                        }
                    }
                }
                if (object2 != null && ((TLV)object2).value != null && ((TLV)object2).value.length != 0) break block47;
                yP_TCD_DC_Transaction.logger(3, "getGoOnlineMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (((TLV)object2).value[1] - 48) * 10 + (((TLV)object2).value[2] - 48);
        int n3 = ((TLV)object2).value[3] - 48;
        object = new byte[20];
        System.arraycopy(((TLV)object2).value, ((TLV)object2).value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        string = new String((byte[])object);
        return this.buildGoOnline(string, n3, n);
    }

    public String getGoOnlineMsgNew(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        String string;
        Object object;
        Object object2;
        int n;
        block50: {
            Object object3;
            Object object4;
            Object object5;
            block49: {
                n = 0;
                try {
                    object5 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object4 = ((TLVHandler)object5).iterator();
                    block25: while (object4.hasNext()) {
                        object2 = object4.next();
                        switch (((TLV)object2).tag) {
                            case 14672409: {
                                int n2 = TLVHandler.getDCBInt(((TLV)object2).value);
                                if (n2 == 1) {
                                    n = 0;
                                    break;
                                }
                                if (n2 == 2) {
                                    n = 0;
                                    break;
                                }
                                if (n2 != 3) continue block25;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672642: {
                                object = UtilsYP.devHexa(((TLV)object2).value);
                                this.extendedTVR = new ExtendedTVR((String)object);
                                break;
                            }
                            case 14672710: {
                                string = UtilsYP.devHexa(((TLV)object2).value);
                                this.issuerScripts = String.valueOf(this.issuerScripts) + string;
                                break;
                            }
                            case 14672711: {
                                String string2 = UtilsYP.devHexa(((TLV)object2).value);
                                this.issuerScripts = String.valueOf(this.issuerScripts) + string2;
                                break;
                            }
                            case -538738378: 
                            case 14672131: 
                            case 14672160: 
                            case 14672162: 
                            case 14672646: 
                            case 14672647: 
                            case 14672657: 
                            case 14672661: 
                            case 14672697: 
                            case 14672698: 
                            case 14672713: 
                            case 16769856: {
                                break;
                            }
                            case -538738359: 
                            case -538738358: {
                                break;
                            }
                            case -538803909: {
                                break;
                            }
                            case 14672648: {
                                this.authDisplayCardHolderMessage = new String(((TLV)object2).value);
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsgNew(): APP tag not handled :" + Integer.toHexString(((TLV)object2).tag));
                            }
                        }
                    }
                    object2 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseEMVTags());
                    object3 = ((TLVHandler)object2).iterator();
                    while (object3.hasNext()) {
                        object4 = object3.next();
                        switch (((TLV)object4).tag) {
                            case 137: {
                                this.authorizationNumber = UtilsYP.devHexa(((TLV)object4).value);
                                break;
                            }
                            case 138: {
                                this.issuerAuthorizationCode = new String(((TLV)object4).value);
                                break;
                            }
                            case 145: {
                                this.issuerAuthenticationData = UtilsYP.devHexa(((TLV)object4).value);
                                break;
                            }
                            case 149: {
                                this.tvr = ((TLV)object4).value;
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsgNew(): EMV tag not handled :" + Integer.toHexString(((TLV)object4).tag));
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsgNew(): Exception " + exception);
                    exception.printStackTrace();
                }
                if (this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_ACCEPTED)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): PARTIAL_AUTHORIZATION_ACCEPTED");
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): PARTIAL_AUTHORIZATION");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.REFERRAL_DONE)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): REFERRAL_DONE");
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFERRAL)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): AUTHORIZATION_REFERRAL");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): AUTHORIZATION_REFUSED");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): AUTHORIZATION_FORBIDDEN");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): AUTHORIZATION_INCIDENT");
                    this.authorizationResult = 0;
                    this.issuerResponse = -1;
                } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL)) {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): FORCED_BEFORE_CALL");
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                    this.issuerAuthorizationCode = "Y1";
                } else if (this.issuerAuthorizationCode == null) {
                    object5 = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
                    if (object5 != EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS && object5 != EntryModeEnumeration.ENTRY_MODE_TAPPED || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) != TransactionTypeEnumeration.CREDIT && YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) != TransactionTypeEnumeration.REVERSAL_DEBIT && YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) != TransactionTypeEnumeration.REFUND_QUASI_CASH && YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) != TransactionTypeEnumeration.REVERSAL_QUASI_CASH) {
                        yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): Offline refusal");
                    }
                    this.authorizationResult = 2;
                    this.issuerResponse = 2;
                } else {
                    yP_TCD_DC_Transaction.logger(4, "getGoOnlineMsgNew(): Authorization OK");
                    this.authorizationResult = 2;
                    this.issuerResponse = 1;
                }
                object5 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object5 != null && !((String)object5).isEmpty()) break block49;
                yP_TCD_DC_Transaction.logger(3, "getGoOnlineMsgNew() no app tags");
                return null;
            }
            try {
                object2 = null;
                object4 = new TLVHandler((String)object5);
                object = ((TLVHandler)object4).iterator();
                while (object.hasNext()) {
                    object3 = (TLV)object.next();
                    switch (((TLV)object3).tag) {
                        case 14672756: {
                            object2 = object3;
                            break;
                        }
                    }
                }
                if (object2 != null && ((TLV)object2).value != null && ((TLV)object2).value.length != 0) break block50;
                yP_TCD_DC_Transaction.logger(3, "getGoOnlineMsgNew(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getGoOnlineMsgNew():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (((TLV)object2).value[1] - 48) * 10 + (((TLV)object2).value[2] - 48);
        int n3 = ((TLV)object2).value[3] - 48;
        object = new byte[20];
        System.arraycopy(((TLV)object2).value, ((TLV)object2).value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        string = new String((byte[])object);
        return this.buildGoOnline(string, n3, n);
    }

    public String getCompleteTransactionMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        int n;
        Object object;
        TLV tLV;
        int n2;
        boolean bl;
        block30: {
            Object object2;
            Object object3;
            block29: {
                bl = false;
                n2 = 3;
                try {
                    object3 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object2 = ((TLVHandler)object3).iterator();
                    block18: while (object2.hasNext()) {
                        tLV = object2.next();
                        switch (tLV.tag) {
                            case 14672409: {
                                int n3 = TLVHandler.getDCBInt(tLV.value);
                                if (n3 == 1) {
                                    n2 = 0;
                                    break;
                                }
                                if (n3 == 2 || n3 != 3) continue block18;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672642: {
                                object = UtilsYP.devHexa(tLV.value);
                                this.extendedTVR = new ExtendedTVR((String)object);
                                break;
                            }
                            case -538803943: 
                            case -538803909: 
                            case -538803908: 
                            case -538738408: 
                            case -538738387: 
                            case -538738382: 
                            case -538738378: 
                            case -538738358: 
                            case 14672663: 
                            case 14672664: 
                            case 14672716: 
                            case 14672755: {
                                break;
                            }
                            case 14672131: {
                                bl = TLVHandler.getBool(tLV.value);
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getCompleteTransactionMsg(): APP tag not handled :" + Integer.toHexString(tLV.tag));
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    yP_TCD_DC_Transaction.logger(2, "getCompleteTransactionMsg(): Exception " + exception);
                }
                object3 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object3 != null && !((String)object3).isEmpty()) break block29;
                yP_TCD_DC_Transaction.logger(3, "getCompleteTransactionMsg() no app tags");
                return null;
            }
            try {
                tLV = null;
                object2 = new TLVHandler((String)object3);
                object = ((TLVHandler)object2).iterator();
                block19: while (object.hasNext()) {
                    TLV tLV2 = (TLV)object.next();
                    switch (tLV2.tag) {
                        case 14672756: {
                            if (tLV == null) {
                                tLV = tLV2;
                                break;
                            }
                            int n4 = (tLV.value[1] - 48) * 10 + (tLV.value[2] - 48);
                            n = (tLV2.value[1] - 48) * 10 + (tLV2.value[2] - 48);
                            if (n4 == 47 && n == 46) continue block19;
                            tLV = tLV2;
                            break;
                        }
                    }
                }
                if (tLV != null && tLV.value != null && tLV.value.length != 0) break block30;
                yP_TCD_DC_Transaction.logger(3, "getCompleteTransactionMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "getCompleteTransactionMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (tLV.value[1] - 48) * 10 + (tLV.value[2] - 48);
        int n5 = tLV.value[3] - 48;
        object = new byte[20];
        System.arraycopy(tLV.value, tLV.value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        String string = new String((byte[])object);
        if (this.currentPosmateMessage == 48) {
            return this.buildTerminateTransaction(string, n5);
        }
        n = 0;
        if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL) || yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL)) {
            n = 4;
        } else if (bl) {
            n = 1;
        } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.DOUBLE_AUTHENTIFICATION_AMOUNT_REACHED)) {
            n = 1;
        }
        if (this.currentPosmateMessage == 47 && this.initialPosmateStatus == TransactionStatusEnumeration.REFUSED && n2 == 0 && n == 0) {
            yP_TCD_DC_Transaction.logger(3, "getCompleteTransactionMsg() initial trs was refused but we want to accept it");
            EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
            switch (entryModeEnumeration) {
                case ENTRY_MODE_TAPPED: 
                case ENTRY_MODE_EMV_CONTACTLESS: {
                    n = 8;
                    yP_TCD_DC_Transaction.logger(3, "getCompleteTransactionMsg() forced for NFC");
                    break;
                }
                default: {
                    yP_TCD_DC_Transaction.logger(3, "getCompleteTransactionMsg() Only for NFC for the moment");
                }
            }
        }
        return this.buildCompleteTransaction(string, n5, n2, n);
    }

    public String getSwipedTransactionDataMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        Object object;
        TLV tLV;
        int n;
        Object object2;
        block49: {
            Object object3;
            Object object4;
            block48: {
                int n2 = 3;
                try {
                    object2 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object4 = ((TLVHandler)object2).iterator();
                    block23: while (object4.hasNext()) {
                        TLV tLV2 = object4.next();
                        switch (tLV2.tag) {
                            case 14672409: {
                                int n3 = TLVHandler.getDCBInt(tLV2.value);
                                if (n3 == 1) {
                                    n2 = 0;
                                    break;
                                }
                                if (n3 == 2 || n3 != 3) continue block23;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672659: 
                            case 14672660: 
                            case 14672661: {
                                break;
                            }
                            case 14672642: {
                                object3 = UtilsYP.devHexa(tLV2.value);
                                this.extendedTVR = new ExtendedTVR((String)object3);
                                break;
                            }
                            case 14672456: {
                                this.interCharacterTimeout = TLVHandler.getDCBInt(tLV2.value);
                                break;
                            }
                            case 14672657: {
                                break;
                            }
                            case 14672485: 
                            case 14672486: 
                            case 14672487: 
                            case 14672488: 
                            case 14672489: {
                                break;
                            }
                            case -538869498: 
                            case -538869463: 
                            case -538738359: 
                            case -538738358: 
                            case 14672129: 
                            case 14672160: 
                            case 14672161: 
                            case 14672162: 
                            case 14672205: 
                            case 14672406: 
                            case 14672697: 
                            case 14672698: 
                            case 14672713: 
                            case 14672716: 
                            case 16769856: 
                            case 16769870: {
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getSwipedTransactionDataMsg(): APP tag not handled :" + Integer.toHexString(tLV2.tag));
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    yP_TCD_DC_Transaction.logger(2, "getSwipedTransactionDataMsg():" + exception);
                }
                switch (YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction)) {
                    case DEBIT: 
                    case QUASI_CASH: 
                    case INITIAL_RESERVATION: 
                    case ONE_TIME_RESERVATION: 
                    case COMPLEMENTARY_PAYMENT: 
                    case DEBIT_DIFFERED: {
                        object2 = "00";
                        break;
                    }
                    case CREDIT: 
                    case COMPLEMENTARY_REFUND: 
                    case REFUND_QUASI_CASH: {
                        object2 = "20";
                        break;
                    }
                    case REVERSAL_DEBIT: 
                    case REVERSAL_QUASI_CASH: {
                        object2 = "22";
                        break;
                    }
                    default: {
                        object2 = "??";
                    }
                }
                n = 0;
                if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CHIP_MUST_BE_USED)) {
                    n = 1;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.PAN_LENGTH_INVALID)) {
                    n = 2;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.UNKNOWN_SERVICE_CODE)) {
                    n = 3;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.LUHN_KEY_INVALID)) {
                    n = 4;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    n = 7;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    n = 8;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    n = 7;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    n = 8;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    n = 9;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    n = 10;
                } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.WRONG_ENTRY_MODE)) {
                    n = 11;
                }
                if (n == 0 && n2 != 0) {
                    n = 99;
                }
                object4 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object4 != null && !((String)object4).isEmpty()) break block48;
                yP_TCD_DC_Transaction.logger(3, "getSwipedTransactionDataMsg() no app tags");
                return null;
            }
            try {
                tLV = null;
                object3 = new TLVHandler((String)object4);
                object = ((TLVHandler)object3).iterator();
                while (object.hasNext()) {
                    TLV tLV3 = object.next();
                    switch (tLV3.tag) {
                        case 14672756: {
                            tLV = tLV3;
                            break;
                        }
                    }
                }
                if (tLV != null && tLV.value != null && tLV.value.length != 0) break block49;
                yP_TCD_DC_Transaction.logger(3, "getSwipedTransactionDataMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getSwipedTransactionDataMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (tLV.value[1] - 48) * 10 + (tLV.value[2] - 48);
        int n4 = tLV.value[3] - 48;
        object = new byte[20];
        System.arraycopy(tLV.value, tLV.value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        String string = new String((byte[])object);
        return this.buildGetSwipedTransactionData(string, n4, 0, n, (String)object2, yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
    }

    public String getProcessSwipedCardMsg(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        Object object;
        TLV tLV;
        int n;
        block32: {
            Object object2;
            Object object3;
            block31: {
                n = 3;
                try {
                    object3 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                    object2 = ((TLVHandler)object3).iterator();
                    block22: while (object2.hasNext()) {
                        tLV = object2.next();
                        switch (tLV.tag) {
                            case 14672409: {
                                int n2 = TLVHandler.getDCBInt(tLV.value);
                                if (n2 == 1) {
                                    n = 0;
                                    break;
                                }
                                if (n2 == 2 || n2 != 3) continue block22;
                                yP_TCD_DC_Transaction.logger(2, "debug log: trs status == error");
                                break;
                            }
                            case 14672642: {
                                object = UtilsYP.devHexa(tLV.value);
                                this.extendedTVR = new ExtendedTVR((String)object);
                                break;
                            }
                            case -538803943: 
                            case -538803909: 
                            case -538738408: 
                            case -538738387: 
                            case -538738382: 
                            case 14672131: 
                            case 14672663: 
                            case 14672664: 
                            case 14672716: 
                            case 14672755: {
                                break;
                            }
                            default: {
                                yP_TCD_DC_Transaction.logger(2, "getProcessSwipedCardMsg(): APP tag not handled :" + Integer.toHexString(tLV.tag));
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    yP_TCD_DC_Transaction.logger(2, "getProcessSwipedCardMsg():" + exception);
                }
                try {
                    object3 = new TLVHandler(yP_TCD_DC_Transaction.getAuthResponseBuffer());
                    object2 = ((TLVHandler)object3).iterator();
                    while (object2.hasNext()) {
                        tLV = object2.next();
                        block10 : switch (tLV.tag) {
                            case 188: {
                                if (tLV.value.length <= 1) break;
                                switch (tLV.value[0]) {
                                    case 50: 
                                    case 51: 
                                    case 53: 
                                    case 54: 
                                    case 66: 
                                    case 67: 
                                    case 98: 
                                    case 99: {
                                        this.authDisplayCardHolderMessage = new String(tLV.value, 1, tLV.value.length - 1, "ISO-8859-1");
                                        break block10;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                object3 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                if (object3 != null && !((String)object3).isEmpty()) break block31;
                yP_TCD_DC_Transaction.logger(3, "getProcessSwipedCardMsg() no app tags");
                return null;
            }
            try {
                tLV = null;
                object2 = new TLVHandler((String)object3);
                object = ((TLVHandler)object2).iterator();
                while (object.hasNext()) {
                    TLV tLV2 = (TLV)object.next();
                    switch (tLV2.tag) {
                        case 14672756: {
                            tLV = tLV2;
                            break;
                        }
                    }
                }
                if (tLV != null && tLV.value != null && tLV.value.length != 0) break block32;
                yP_TCD_DC_Transaction.logger(3, "getProcessSwipedCardMsg(): No POSMATE_MESSAGE to test");
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_TCD_DC_Transaction.logger(2, "getProcessSwipedCardMsg():" + exception);
                return null;
            }
        }
        this.currentPosmateMessage = (tLV.value[1] - 48) * 10 + (tLV.value[2] - 48);
        if (this.currentPosmateMessage == 47) {
            return this.getCompleteTransactionMsg(yP_TCD_DC_Transaction);
        }
        int n3 = tLV.value[3] - 48;
        object = new byte[20];
        System.arraycopy(tLV.value, tLV.value.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
        String string = new String((byte[])object);
        int n4 = 5;
        if (n != 0) {
            n4 = 1;
        } else if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL) || yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL)) {
            n4 = 6;
        }
        if (this.currentPosmateMessage == 48) {
            return this.buildTerminateTransaction(string, n3);
        }
        return this.buildProcessSwipedCard(string, n3, 0, n4);
    }

    private List<TLV> parseSupplementary(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        Object object;
        Object object2;
        List<String> list = this.buildSupplementaryTagList(yP_TCD_DC_Transaction);
        int n = -1;
        String string = null;
        String string2 = null;
        String string3 = null;
        if (byArray == null || list == null) {
            return null;
        }
        ArrayList<TLV> arrayList = new ArrayList<TLV>();
        int n2 = 4;
        int n3 = byArray.length - 38;
        for (String object32 : list) {
            if (n2 > n3) {
                if (object32.contentEquals("5F28") || object32.contentEquals("9F0A") || object32.contentEquals("DB00")) break;
                yP_TCD_DC_Transaction.logger(2, "Problem in parseSupplementary: 1");
                continue;
            }
            object2 = new TLV();
            if (object32.length() == 2 || object32.length() == 6) {
                ((TLV)object2).tag = Integer.parseInt(object32, 16);
            } else if (object32.length() == 4) {
                ((TLV)object2).tag = object32.charAt(2) == '0' && object32.charAt(3) == '0' ? Integer.parseInt(object32.substring(0, 2), 16) : Integer.parseInt(object32, 16);
            } else {
                yP_TCD_DC_Transaction.logger(2, "Problem in parseSupplementary: 2");
                break;
            }
            int n4 = 0;
            while (n2 + n4 < n3 && byArray[n2 + n4] != 28) {
                ++n4;
            }
            switch (((TLV)object2).tag) {
                case 40718: {
                    if (n4 == 0) {
                        yP_TCD_DC_Transaction.logger(3, "parseSupplementary() no IAC DENIAL");
                    } else if (n4 != 10) {
                        yP_TCD_DC_Transaction.logger(2, "parseSupplementary() bad length for IAC DENIAL");
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 40746: {
                    if (n4 == 0) {
                        yP_TCD_DC_Transaction.logger(3, "parseSupplementary() no Card kernel ID");
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 220: {
                    if (n4 == 0) {
                        yP_TCD_DC_Transaction.logger(3, "parseSupplementary() no Terminal kernel ID!!!");
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 149: {
                    if (n4 == 0) {
                        yP_TCD_DC_Transaction.logger(3, "parseSupplementary() no TVR");
                    } else if (n4 != 10) {
                        yP_TCD_DC_Transaction.logger(2, "parseSupplementary() bad length for TVR");
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    int cfr_ignored_0 = ((TLV)object2).length;
                    break;
                }
                case 155: {
                    if (n4 == 0) {
                        yP_TCD_DC_Transaction.logger(3, "parseSupplementary() no TSI");
                    } else if (n4 != 4) {
                        yP_TCD_DC_Transaction.logger(2, "parseSupplementary() bad length for TSI");
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 137: {
                    if (n4 == 0) {
                        if (this.authorizationNumber == null || this.authorizationNumber.isEmpty()) break;
                        ((TLV)object2).value = UtilsYP.redHexa(this.authorizationNumber);
                        ((TLV)object2).length = ((TLV)object2).value.length;
                        break;
                    }
                    yP_TCD_DC_Transaction.logger(2, "Problem in parseSupplementary: 89");
                    break;
                }
                case 40769: {
                    if (n4 % 2 == 1) {
                        yP_TCD_DC_Transaction.logger(3, "SPm2 9f41 above 9999 issue : " + ((TLV)object2).tag);
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                default: {
                    if (n4 % 2 == 1) {
                        yP_TCD_DC_Transaction.logger(2, "Problem in parseSupplementary: 3 : " + ((TLV)object2).tag);
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 24360: 
                case 24362: 
                case 24368: 
                case 40730: 
                case 40763: 
                case 40764: 
                case 40770: 
                case 40874: {
                    if (n4 % 2 == 1) {
                        byte[] byArray2 = new byte[n4 + 1];
                        byArray2[0] = 48;
                        System.arraycopy(byArray, n2, byArray2, 1, n4);
                        ((TLV)object2).value = UtilsYP.redHexa(byArray2);
                        ((TLV)object2).length = ((TLV)object2).value.length;
                        break;
                    }
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    break;
                }
                case 215: {
                    ((TLV)object2).length = n4;
                    ((TLV)object2).value = new byte[((TLV)object2).length];
                    System.arraycopy(byArray, n2, ((TLV)object2).value, 0, ((TLV)object2).length);
                    String string4 = new String(((TLV)object2).value);
                    int n5 = string4.indexOf(31);
                    if (n5 > 0) {
                        string2 = string4.substring(0, n5);
                        string = string4.substring(n5 + 1);
                        break;
                    }
                    string2 = string4;
                    break;
                }
                case 216: {
                    ((TLV)object2).length = n4;
                    ((TLV)object2).value = new byte[((TLV)object2).length];
                    System.arraycopy(byArray, n2, ((TLV)object2).value, 0, ((TLV)object2).length);
                    if (((TLV)object2).length <= 0) break;
                    try {
                        n = Integer.parseInt(new String(((TLV)object2).value));
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    break;
                }
                case 217: {
                    ((TLV)object2).length = n4;
                    ((TLV)object2).value = new byte[((TLV)object2).length];
                    System.arraycopy(byArray, n2, ((TLV)object2).value, 0, ((TLV)object2).length);
                    this.issuerScriptResults = new String(((TLV)object2).value);
                    break;
                }
                case 219: {
                    ((TLV)object2).length = n4 / 2;
                    ((TLV)object2).value = UtilsYP.redHexa(byArray, n2, ((TLV)object2).length);
                    string3 = UtilsYP.devHexa(((TLV)object2).value);
                    break;
                }
                case 80: 
                case 138: 
                case 24365: 
                case 40722: 
                case 40782: {
                    ((TLV)object2).length = n4;
                    ((TLV)object2).value = new byte[((TLV)object2).length];
                    System.arraycopy(byArray, n2, ((TLV)object2).value, 0, ((TLV)object2).length);
                }
            }
            if (((TLV)object2).length == 0) {
                ((TLV)object2).value = null;
            }
            int n6 = 0;
            while (n6 < ((TLV)object2).length) {
                int n7 = n6++;
                ((TLV)object2).value[n7] = (byte)(((TLV)object2).value[n7] & 0xFF);
            }
            if (((TLV)object2).tag != 215 && ((TLV)object2).tag != 216 && ((TLV)object2).tag != 217) {
                arrayList.add((TLV)object2);
            }
            n2 += n4;
            ++n2;
        }
        if (string2 != null && n > 0) {
            if (string == null) {
                byte[] byArray3 = new byte[20];
                System.arraycopy(byArray, byArray.length - (2 + byArray3.length), byArray3, 0, byArray3.length);
                string = new String(byArray3);
            }
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(14672737, string);
            tLVHandler.add(14672738, string2);
            tLVHandler.add(14672483, (long)n);
            this.dukptTLV = new TLV();
            this.dukptTLV.tag = 16769892;
            object = tLVHandler.toString();
            this.dukptTLV.value = UtilsYP.redHexa((String)object);
            this.dukptTLV.length = this.dukptTLV.value.length;
        } else {
            this.dukptTLV = null;
        }
        if (string3 != null && !string3.isEmpty()) {
            byte[] byArray4 = new byte[20];
            System.arraycopy(byArray, byArray.length - (2 + byArray4.length), byArray4, 0, byArray4.length);
            object = new String(byArray4);
            object2 = new String(UtilsYP.redHexa(DUKPT.decryptData((String)object, string3)));
            if (!((String)object2).isEmpty()) {
                this.decryptedMerchantCode = object2;
            }
        }
        return arrayList;
    }

    private void logAIPInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length != 2) {
            return;
        }
        if ((byArray[0] & 0x40) == 64 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD SDA Supported");
        }
        if ((byArray[0] & 0x20) == 32 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD DDA Supported");
        }
        if ((byArray[0] & 0x10) == 16 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD Cardholder verification Supported");
        }
        if ((byArray[0] & 8) == 8 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD Terminal risk management is to be performed");
        }
        if ((byArray[0] & 4) == 4 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD Issuer Authentication is supported");
        }
        if ((byArray[0] & 2) == 2 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD On device cardholder verification is supported");
        }
        if ((byArray[0] & 1) == 1 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD CDA supported");
        }
        if ((byArray[1] & 0x80) == 128 && yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "CTCL API MASTERCARD EMV mode is supported");
        }
    }

    private void setTappedEntryPoint(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            if (YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction) != EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) {
                return;
            }
            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("appInterchangeProfile")));
            if (byArray == null || byArray.length < 2) {
                return;
            }
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("02")) {
                this.logAIPInfo(yP_TCD_DC_Transaction, byArray);
                if (byArray != null && byArray.length == 2 && (byArray[1] & 0x80) == 0) {
                    YP_TCD_DCC_Business.setPaymentTechnology(yP_TCD_DC_Transaction, EntryModeEnumeration.ENTRY_MODE_TAPPED);
                    yP_TCD_DC_Transaction.logger(4, "CTCL setTappedEntryPoint() change entry mode from contactless to tapped");
                }
            }
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(4, "CTCL setTappedEntryPoint() : " + exception);
        }
    }

    private void logIssuerApplicationDataInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("issuerAppData")));
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("02")) {
                if ((byArray[6] & 0x80) == 128) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD lower consecutive offline limit exceeded");
                }
                if ((byArray[6] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD upper consecutive offline limit exceeded");
                }
                if ((byArray[6] & 0x20) == 32) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD lower cumulative offline limit exceeded");
                }
                if ((byArray[6] & 0x10) == 16) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD upper cumulative offline limit exceeded");
                }
                if ((byArray[6] & 8) == 8) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD go online on next transaction was set");
                }
                if ((byArray[6] & 4) == 4) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD Issuer Authentication failed");
                }
                if ((byArray[6] & 2) == 2) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD script received");
                }
                if ((byArray[6] & 1) == 1) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD script failed");
                }
                return;
            }
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("03")) {
                if (byArray[3] != 3) {
                    return;
                }
                if ((byArray[4] & 0x80) == 0) {
                    if ((byArray[4] & 0x40) == 64) {
                        yP_TCD_DC_Transaction.logger(5, "CTCL IAD TC returned in 2nd GAC");
                    } else {
                        yP_TCD_DC_Transaction.logger(5, "CTCL IAD AAC returned in 2nd GAC");
                    }
                }
                if ((byArray[4] & 0x20) == 0) {
                    if ((byArray[4] & 0x10) == 16) {
                        yP_TCD_DC_Transaction.logger(5, "CTCL IAD TC returned in GPO");
                    } else {
                        yP_TCD_DC_Transaction.logger(5, "CTCL IAD AAC returned in GPO");
                    }
                } else if ((byArray[4] & 0x10) == 0) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD ARQC returned in GPO");
                }
                if ((byArray[5] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD PIN TRY limit exceeded");
                }
                if ((byArray[5] & 0x20) == 32) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD exceeded velocity checking counters");
                }
                if ((byArray[5] & 8) == 8) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD Issuer authentication failure on last online transaction");
                }
                if ((byArray[6] & 8) == 8) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL IAD Issuer script processing failed on last transaction");
                }
            }
        }
        catch (Exception exception) {}
    }

    private void logTTQDataInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalTransactionQualifiers")));
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("03")) {
                if ((byArray[1] & 0x80) == 128) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL TTQ Online cryptogram required");
                }
                if ((byArray[1] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL TTQ CVM required");
                }
            }
        }
        catch (Exception exception) {}
    }

    private void logAIPDataInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("03")) {
                byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("appInterchangeProfile")));
                if ((byArray[0] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL AIP SDA is supported");
                }
                if ((byArray[0] & 0x20) == 32) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL AIP DDA is supported for EMV Mode");
                }
                if ((byArray[1] & 0x80) == 128) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL AIP Mag-stripe mode is supported");
                }
                if ((byArray[1] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL AIP mobile phone");
                }
            }
        }
        catch (Exception exception) {}
    }

    private void logCIDDataInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("cryptoInformationData")));
            if ((byArray[0] & 0x80) == 0 && (byArray[0] & 0x40) == 64) {
                yP_TCD_DC_Transaction.logger(5, "CTCL CID TC returned");
                return;
            }
            if ((byArray[0] & 0x80) == 128 && (byArray[0] & 0x40) == 0) {
                yP_TCD_DC_Transaction.logger(5, "CTCL CID ARQC returned");
                return;
            }
            if ((byArray[0] & 0x80) == 0 && (byArray[0] & 0x40) == 0) {
                yP_TCD_DC_Transaction.logger(5, "CTCL CID AAC returned");
                return;
            }
        }
        catch (Exception exception) {}
    }

    private void logCTQDataInfo(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("cardTransactionQualifier")));
            if (YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID")).contentEquals("03")) {
                if ((byArray[0] & 0x80) == 128) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Online PIN required");
                }
                if ((byArray[0] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Signature required");
                }
                if ((byArray[0] & 0x20) == 32) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Go Online if Offline Data Authentication Fails");
                }
                if ((byArray[0] & 0x10) == 16) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Switch Interface if Offline Data Authentication fails");
                }
                if ((byArray[0] & 8) == 8) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Go Online if Application Expired");
                }
                if ((byArray[1] & 0x80) == 128) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Consumer Device CVM Performed");
                }
                if ((byArray[1] & 0x40) == 64) {
                    yP_TCD_DC_Transaction.logger(5, "CTCL CTQ Card supports Issuer Update Processing at the POS");
                }
            }
        }
        catch (Exception exception) {}
    }

    private void extractSupplementaryNFC(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): Start");
        }
        arrayList.add("50");
        arrayList.add("82");
        arrayList.add("9F12");
        arrayList.add("5F28");
        arrayList.add("5F2D");
        arrayList.add("84");
        arrayList.add("87");
        arrayList.add("9F11");
        arrayList.add("9F2A");
        arrayList.add("9F5A");
        arrayList.add("9F5D");
        arrayList.add("9F69");
        arrayList.add("9F6E");
        arrayList.add("9F7C");
        arrayList.add("BF0C");
        arrayList.add("9F34");
        arrayList.add("9F6C");
        arrayList.add("9F66");
        arrayList.add("DC");
        arrayList.add("DD");
        arrayList.add("D6");
        arrayList.add("DF4B");
        arrayList.add("9F7E");
        arrayList.add("DF8115");
        arrayList.add("9F10");
        arrayList.add("9F27");
        arrayList.add("9F08");
        arrayList.add("9F07");
        arrayList.add("9F36");
        arrayList.add("9F37");
        arrayList.add("9F26");
        arrayList.add("9F50");
        arrayList.add("5F24");
        arrayList.add("95");
        int n = 4;
        int n2 = byArray.length - 38;
        int n3 = 0;
        int n4 = n;
        while (n4 < n2) {
            if (byArray[n4] == 28) {
                ++n3;
            }
            ++n4;
        }
        if (n3 > 42) {
            yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC() Probably completion tags (Client issue) better not to try to analyse it");
            return;
        }
        for (String string : arrayList) {
            int n5;
            if (n > n2) {
                yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC() missing tags ???");
                break;
            }
            if (string.length() == 2 || string.length() == 6) {
                n5 = Integer.parseInt(string, 16);
            } else if (string.length() == 4) {
                n5 = string.charAt(2) == '0' && string.charAt(3) == '0' ? Integer.parseInt(string.substring(0, 2), 16) : Integer.parseInt(string, 16);
            } else {
                yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC() bad tag length " + string);
                break;
            }
            int n6 = 0;
            while (n + n6 < n2 && byArray[n + n6] != 28) {
                ++n6;
            }
            if (n6 > 0) {
                switch (n5) {
                    case 40746: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f2a: " + string2);
                        }
                        try {
                            if (string2.isEmpty()) break;
                            yP_TCD_DC_Transaction.setExtensionValue("kernelID", String.format("%02d", Integer.parseInt(string2)));
                        }
                        catch (Exception exception) {}
                        break;
                    }
                    case 221: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xDD Visa Transaction Status: " + string2);
                        }
                        try {
                            if (string2.isEmpty()) break;
                            yP_TCD_DC_Transaction.setExtensionValue("nonAchievedReason", string2);
                        }
                        catch (Exception exception) {
                            yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC(): 0xDD: " + exception);
                        }
                        break;
                    }
                    case 220: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xDC Terminal Kernel Identifier: " + string2);
                        }
                        try {
                            if (string2.isEmpty()) break;
                            yP_TCD_DC_Transaction.setExtensionValue("kernelID", String.format("%02d", Integer.parseInt(string2)));
                        }
                        catch (Exception exception) {
                            yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC(): 0xDC Terminal Kernel Identifier: " + exception);
                        }
                        break;
                    }
                    case 40806: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f66 TTQ: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("terminalTransactionQualifiers", string2);
                        break;
                    }
                    case 40784: 
                    case 40797: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F5D/9F50 Available Off Spend Amount/Mastercard Balance: " + string2);
                        }
                        if (string2.length() >= 16) break;
                        yP_TCD_DC_Transaction.setExtensionValue("availableOfflineSpendingAmount", string2);
                        break;
                    }
                    case 40828: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f7C customerExclusiveData: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("customerExclusiveData", string2);
                        break;
                    }
                    case 40812: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f6C CTQ: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("cardTransactionQualifier", string2);
                        break;
                    }
                    case 80: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x50 Application label: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("applicationLabel", string2);
                        break;
                    }
                    case 130: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x82 AIP: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("appInterchangeProfile", string2);
                        break;
                    }
                    case 132: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x84 AID: " + string2);
                        break;
                    }
                    case 135: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x87 API: " + string2);
                        break;
                    }
                    case 24360: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x5F28: " + string2);
                        break;
                    }
                    case 24365: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x5F2D language preference: " + string2);
                        break;
                    }
                    case 40721: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f11 issuer code table index: " + string2);
                        break;
                    }
                    case 40722: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f12 Preferred Name: " + string2);
                        }
                        int n7 = -1;
                        try {
                            List<AccountHandler.ADF> list = yP_TCD_DC_Transaction.accountHandler.getADFList();
                            if (list != null && !list.isEmpty()) {
                                AccountHandler.ADF aDF = list.get(0);
                                if (aDF.issuerCodeTableIndex != null && !aDF.issuerCodeTableIndex.isEmpty()) {
                                    n7 = Integer.parseInt(aDF.issuerCodeTableIndex);
                                }
                            }
                        }
                        catch (Exception exception) {
                            yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC() :" + exception);
                        }
                        if (n7 != 1) break;
                        yP_TCD_DC_Transaction.setExtensionValue("applicationPreferredName", string2);
                        break;
                    }
                    case 40756: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f34 cvmResult: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("cvmResult", string2);
                        break;
                    }
                    case 40758: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f36 appTransactionCounter: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("appTransactionCounter", string2);
                        break;
                    }
                    case 40759: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f37 unpredictableNumber: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("unpredictableNumber", string2);
                        break;
                    }
                    case 40794: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f5A application program ID: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("applicationProgramID", string2);
                        break;
                    }
                    case 40809: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f69 cardAuthenticationRelatedData: " + string2);
                        }
                        if (string2.length() > 16) {
                            string2 = string2.substring(0, 16);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("cardAuthenticationRelatedData", string2);
                        break;
                    }
                    case 40814: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9f6E formFactor: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("formFactor", string2);
                        break;
                    }
                    case 48908: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xBF0C: " + string2);
                        break;
                    }
                    case 57163: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xDF4B: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("posCardholderInteractionInformation", string2);
                        break;
                    }
                    case 57202: {
                        break;
                    }
                    case 40830: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F7E: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("mobileSupportIndicator", string2);
                        break;
                    }
                    case 214: {
                        if (yP_TCD_DC_Transaction.getLogLevel() < 5) break;
                        yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xD6 received: ");
                        break;
                    }
                    case 14647573: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0xDF8115 errorIndicator: " + string2);
                        }
                        if (string2 == null || string2.length() < 6) break;
                        yP_TCD_DC_Transaction.setExtensionValue("errorIndicator", string2.substring(0, 6));
                        break;
                    }
                    case 40720: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F10 issuerAppData: " + string2);
                        }
                        if (string2 == null) break;
                        yP_TCD_DC_Transaction.setExtensionValue("issuerAppData", string2);
                        break;
                    }
                    case 40711: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F08 appUsageControl: " + string2);
                        }
                        if (string2 == null) break;
                        yP_TCD_DC_Transaction.setExtensionValue("appUsageControl", string2);
                        break;
                    }
                    case 40712: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F08 icc applicationVersionNumber: " + string2);
                        }
                        if (string2 == null) break;
                        yP_TCD_DC_Transaction.setExtensionValue("applicationVersionNumberIcc", string2);
                        break;
                    }
                    case 40742: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F26 appCryptogram: " + string2);
                        }
                        if (string2 == null) break;
                        yP_TCD_DC_Transaction.setExtensionValue("appCryptogram", string2);
                        break;
                    }
                    case 40743: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryNFC(): 0x9F27 cryptoInformationData: " + string2);
                        }
                        if (string2 == null) break;
                        yP_TCD_DC_Transaction.setExtensionValue("cryptoInformationData", string2);
                        break;
                    }
                    case 24356: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "CTCL fillEmvDatas() : expirationDate: " + string2);
                        }
                        yP_TCD_DC_Transaction.accountHandler.setAccountExpirationDate(string2);
                        break;
                    }
                    case 149: {
                        String string2 = new String(byArray, n, n6);
                        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                            yP_TCD_DC_Transaction.logger(5, "CTCL fillEmvDatas() : tvr: " + string2);
                        }
                        yP_TCD_DC_Transaction.setExtensionValue("tvr", string2);
                        break;
                    }
                    default: {
                        yP_TCD_DC_Transaction.logger(2, "extractSupplementaryNFC() not really possible...");
                    }
                }
            }
            n += n6;
            ++n;
        }
        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            this.logCIDDataInfo(yP_TCD_DC_Transaction);
            this.logTTQDataInfo(yP_TCD_DC_Transaction);
            this.logCTQDataInfo(yP_TCD_DC_Transaction);
            this.logAIPDataInfo(yP_TCD_DC_Transaction);
        }
        this.setTappedEntryPoint(yP_TCD_DC_Transaction);
        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            this.logIssuerApplicationDataInfo(yP_TCD_DC_Transaction);
        }
    }

    private void extractSupplementaryMagstripe(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
            yP_TCD_DC_Transaction.logger(5, "extractSupplementaryMagstripe(): Start");
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("DB");
        String string = null;
        int n = 4;
        int n2 = byArray.length - 38;
        for (String string2 : arrayList) {
            Object object;
            if (n > n2) {
                yP_TCD_DC_Transaction.logger(2, "Problem in extractSupplementaryMagstripe: 1");
            } else {
                object = new TLV();
                if (string2.length() == 2 || string2.length() == 6) {
                    ((TLV)object).tag = Integer.parseInt(string2, 16);
                } else if (string2.length() == 4) {
                    ((TLV)object).tag = string2.charAt(2) == '0' && string2.charAt(3) == '0' ? Integer.parseInt(string2.substring(0, 2), 16) : Integer.parseInt(string2, 16);
                } else {
                    yP_TCD_DC_Transaction.logger(2, "Problem in extractSupplementaryMagstripe: 2");
                    break;
                }
                int n3 = 0;
                while (n + n3 < n2 && byArray[n + n3] != 28) {
                    ++n3;
                }
                switch (((TLV)object).tag) {
                    case 219: {
                        ((TLV)object).length = n3 / 2;
                        ((TLV)object).value = UtilsYP.redHexa(byArray, n, ((TLV)object).length);
                        string = UtilsYP.devHexa(((TLV)object).value);
                    }
                }
            }
            if (string == null || string.isEmpty()) continue;
            object = new byte[20];
            System.arraycopy(byArray, byArray.length - (2 + ((Object)object).length), object, 0, ((Object)object).length);
            String string3 = new String((byte[])object);
            String string4 = new String(UtilsYP.redHexa(DUKPT.decryptData(string3, string)));
            if (string4.isEmpty()) continue;
            this.decryptedMerchantCode = string4;
        }
    }

    private String buildGetTransactionAndApplicationData(String string, int n, int n2, String string2, boolean bl, boolean bl2) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(42);
        stringBuilder.append(n);
        stringBuilder.append(n2);
        stringBuilder.append(this.transactionLocalTime);
        stringBuilder.append(string2);
        stringBuilder.append(this.authorizedAmount);
        stringBuilder.append('\u001c');
        stringBuilder.append('\u001c');
        if (this.acquirerIdentifier != null) {
            stringBuilder.append(this.acquirerIdentifier);
        } else {
            stringBuilder.append("00000000000");
        }
        stringBuilder.append('\u001c');
        stringBuilder.append(this.terminalIdentifier);
        stringBuilder.append(this.merchantIdentifier);
        stringBuilder.append('\u001c');
        if (this.tavnList != null && this.tavnList.length() > 40) {
            this.tavnList = this.tavnList.substring(0, 40);
        }
        stringBuilder.append(this.tavnList);
        stringBuilder.append('\u001c');
        stringBuilder.append(UtilsYP.devHexa(this.tacDefault));
        stringBuilder.append(UtilsYP.devHexa(this.tacDenial));
        stringBuilder.append(UtilsYP.devHexa(this.tacOnline));
        stringBuilder.append('\u001c');
        if (this.extendedTVR.isSet(ExtendedTVREnumeration.FORCED_ONLINE_MERCHANT)) {
            stringBuilder.append(1);
        } else {
            stringBuilder.append(0);
        }
        stringBuilder.append('\u001c');
        if (this.extendedTVR.isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            stringBuilder.append('0');
        } else {
            stringBuilder.append(this.targetPercentageRandomSelection);
        }
        stringBuilder.append('\u001c');
        if (this.extendedTVR.isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            stringBuilder.append('0');
        } else {
            stringBuilder.append(this.maxTargetPercentageRandomSelection);
        }
        stringBuilder.append('\u001c');
        if (this.extendedTVR.isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            stringBuilder.append('0');
        } else {
            stringBuilder.append(this.thresholdValueRandomSelection);
        }
        stringBuilder.append('\u001c');
        stringBuilder.append(this.floorLimitDefault);
        stringBuilder.append('\u001c');
        stringBuilder.append(this.floorLimitPIN);
        stringBuilder.append('\u001c');
        stringBuilder.append(this.floorLimitSignature);
        stringBuilder.append('\u001c');
        if (this.tdol != null) {
            stringBuilder.append(this.tdol);
        }
        stringBuilder.append('\u001c');
        if (this.ddol != null) {
            stringBuilder.append(this.ddol);
        }
        stringBuilder.append('\u001c');
        if (bl) {
            stringBuilder.append("7");
        } else {
            stringBuilder.append("6");
        }
        stringBuilder.append('\u001c');
        if (bl2) {
            stringBuilder.append("1");
        } else {
            stringBuilder.append("0");
        }
        String string3 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string3);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildTerminalRiskManagement(String string, int n, int n2, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(43);
        stringBuilder.append(n);
        if (n2 == 3 && this.extendedTVR != null && (this.extendedTVR.isSet(ExtendedTVREnumeration.ALREADY_VOIDED) || this.extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND))) {
            stringBuilder.append("0");
            stringBuilder.append("0");
            stringBuilder.append("0");
        } else {
            stringBuilder.append(n2);
            stringBuilder.append(this.doesCardAppear);
            if (YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.REVERSAL_DEBIT || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.REVERSAL_QUASI_CASH) {
                stringBuilder.append(1);
                stringBuilder.append(yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
            } else {
                stringBuilder.append(this.recentTransaction);
                if (this.recentTransaction != 0) {
                    stringBuilder.append(this.lastTransactionAmount);
                }
            }
        }
        String string2 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string2);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildGoOnline(String string, int n, int n2) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(46);
        stringBuilder.append(n);
        stringBuilder.append(n2);
        stringBuilder.append(this.authorizationResult);
        if (this.issuerResponse > 0) {
            stringBuilder.append(this.issuerResponse);
            if (this.issuerAuthorizationCode != null && !this.issuerAuthorizationCode.isEmpty()) {
                stringBuilder.append(this.issuerAuthorizationCode);
                stringBuilder.append('\u001c');
                if (this.issuerAuthenticationData != null && !this.issuerAuthenticationData.isEmpty() || this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_ACCEPTED) || this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED) || this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZED_AMOUNT_INVALID) || this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION)) {
                    if (this.issuerAuthenticationData != null) {
                        stringBuilder.append(this.issuerAuthenticationData);
                    }
                    stringBuilder.append('\u001c');
                    if (this.issuerScripts != null && !this.issuerScripts.isEmpty()) {
                        stringBuilder.append(this.issuerScripts);
                    }
                    if (this.amountAuthorized != null && !this.amountAuthorized.isEmpty() && (this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_ACCEPTED) || this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED) || this.extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZED_AMOUNT_INVALID) || this.extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION))) {
                        if (this.authDisplayCardHolderMessage != null && !this.authDisplayCardHolderMessage.isEmpty()) {
                            stringBuilder.append('\u001c');
                            if (this.authDisplayCardHolderMessage.length() <= 21) {
                                stringBuilder.append(this.authDisplayCardHolderMessage);
                                stringBuilder.append('\u001c');
                            } else {
                                stringBuilder.append(this.authDisplayCardHolderMessage.substring(0, 21));
                                stringBuilder.append('\u001c');
                                if (this.authDisplayCardHolderMessage.length() <= 42) {
                                    stringBuilder.append(this.authDisplayCardHolderMessage.substring(21));
                                } else {
                                    stringBuilder.append(this.authDisplayCardHolderMessage.substring(21, 42));
                                }
                            }
                        } else {
                            stringBuilder.append('\u001c');
                            stringBuilder.append('\u001c');
                        }
                        stringBuilder.append('\u001c');
                        stringBuilder.append(Long.toString(Long.parseLong(this.amountAuthorized)));
                    } else if (this.authDisplayCardHolderMessage != null && !this.authDisplayCardHolderMessage.isEmpty()) {
                        stringBuilder.append('\u001c');
                        if (this.authDisplayCardHolderMessage.length() <= 21) {
                            stringBuilder.append(this.authDisplayCardHolderMessage);
                        } else {
                            stringBuilder.append(this.authDisplayCardHolderMessage.substring(0, 21));
                            stringBuilder.append('\u001c');
                            if (this.authDisplayCardHolderMessage.length() <= 42) {
                                stringBuilder.append(this.authDisplayCardHolderMessage.substring(21));
                            } else {
                                stringBuilder.append(this.authDisplayCardHolderMessage.substring(21, 42));
                            }
                        }
                    }
                } else {
                    stringBuilder.append('\u001c');
                    stringBuilder.append('\u001c');
                    if (this.authDisplayCardHolderMessage != null && !this.authDisplayCardHolderMessage.isEmpty()) {
                        stringBuilder.append('\u001c');
                        if (this.authDisplayCardHolderMessage.length() <= 21) {
                            stringBuilder.append(this.authDisplayCardHolderMessage);
                        } else {
                            stringBuilder.append(this.authDisplayCardHolderMessage.substring(0, 21));
                            stringBuilder.append('\u001c');
                            if (this.authDisplayCardHolderMessage.length() <= 42) {
                                stringBuilder.append(this.authDisplayCardHolderMessage.substring(21));
                            } else {
                                stringBuilder.append(this.authDisplayCardHolderMessage.substring(21, 42));
                            }
                        }
                    }
                }
            }
        }
        String string2 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string2);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildCompleteTransaction(String string, int n, int n2, int n3) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(47);
        stringBuilder.append(n);
        stringBuilder.append(n2);
        stringBuilder.append(n3);
        String string2 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string2);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildTerminateTransaction(String string, int n) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(48);
        stringBuilder.append(n);
        stringBuilder.append("0");
        String string2 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string2);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildGetSwipedTransactionData(String string, int n, int n2, int n3, String string2, long l) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(53);
        stringBuilder.append(n);
        stringBuilder.append(n2);
        stringBuilder.append(String.format("%02d", n3));
        stringBuilder.append(string2);
        stringBuilder.append('\u001c');
        stringBuilder.append(l);
        stringBuilder.append('\u001c');
        if (UtilsYP.isMoroccoServer()) {
            if (this.extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED)) {
                stringBuilder.append('4');
            } else {
                stringBuilder.append('0');
            }
        } else if (this.extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED)) {
            stringBuilder.append('C');
        } else {
            stringBuilder.append('0');
        }
        String string3 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string3);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private String buildProcessSwipedCard(String string, int n, int n2, int n3) throws UnsupportedEncodingException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(52);
        stringBuilder.append(n);
        stringBuilder.append(n2);
        stringBuilder.append(n3);
        if (this.authDisplayCardHolderMessage != null && !this.authDisplayCardHolderMessage.isEmpty()) {
            stringBuilder.append('\u001c');
            if (this.authDisplayCardHolderMessage.length() <= 21) {
                stringBuilder.append(this.authDisplayCardHolderMessage);
            } else {
                stringBuilder.append(this.authDisplayCardHolderMessage.substring(0, 21));
                stringBuilder.append('\u001c');
                if (this.authDisplayCardHolderMessage.length() <= 42) {
                    stringBuilder.append(this.authDisplayCardHolderMessage.substring(21));
                } else {
                    stringBuilder.append(this.authDisplayCardHolderMessage.substring(21, 42));
                }
            }
        }
        String string2 = DUKPT.macResponseData(string, stringBuilder.toString().getBytes("ISO-8859-1"));
        stringBuilder.append(string2);
        stringBuilder.insert(0, '\u0002');
        stringBuilder.append('\u0003');
        stringBuilder.append('\f');
        return stringBuilder.toString();
    }

    private List<String> buildSupplementaryTagList(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ArrayList<String> arrayList = new ArrayList<String>();
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = yP_TCD_DC_Transaction.getSubRequestType();
        switch (sUB_REQUEST_TYPE) {
            case OpenTransaction: {
                break;
            }
            case TerminalRiskManagement: {
                if (this.currentPosmateMessage != 47) break;
                sUB_REQUEST_TYPE = YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion;
                break;
            }
            case Authorization: {
                break;
            }
            case Completion: {
                break;
            }
        }
        switch (sUB_REQUEST_TYPE) {
            case OpenTransaction: {
                arrayList.add("9F06");
                arrayList.add("5000");
                arrayList.add("9F12");
                arrayList.add("8700");
                arrayList.add("5F2D");
                arrayList.add("9F11");
                arrayList.add("9F0A");
                break;
            }
            case TerminalRiskManagement: {
                arrayList.add("8200");
                arrayList.add("8C00");
                arrayList.add("8D00");
                arrayList.add("8E00");
                arrayList.add("9500");
                arrayList.add("9A00");
                arrayList.add("9B00");
                arrayList.add("9C00");
                arrayList.add("5F24");
                arrayList.add("5F25");
                arrayList.add("5F2A");
                arrayList.add("5F30");
                arrayList.add("5F34");
                arrayList.add("9F02");
                arrayList.add("9F06");
                arrayList.add("9F07");
                arrayList.add("9F08");
                arrayList.add("9F0E");
                arrayList.add("9F0F");
                arrayList.add("9F17");
                arrayList.add("9F21");
                arrayList.add("9F33");
                arrayList.add("9F39");
                arrayList.add("9F41");
                arrayList.add("D700");
                arrayList.add("D800");
                arrayList.add("5F28");
                arrayList.add("9F0A");
                arrayList.add("5000");
                arrayList.add("9F12");
                break;
            }
            case Authorization: {
                arrayList.add("8200");
                arrayList.add("8E00");
                arrayList.add("9500");
                arrayList.add("9A00");
                arrayList.add("9B00");
                arrayList.add("9C00");
                arrayList.add("5F24");
                arrayList.add("5F25");
                arrayList.add("5F2A");
                arrayList.add("5F34");
                arrayList.add("9F02");
                arrayList.add("9F06");
                arrayList.add("9F07");
                arrayList.add("9F08");
                arrayList.add("9F09");
                arrayList.add("9F0D");
                arrayList.add("9F0E");
                arrayList.add("9F0F");
                arrayList.add("9F10");
                arrayList.add("9F17");
                arrayList.add("9F21");
                arrayList.add("9F26");
                arrayList.add("9F27");
                arrayList.add("9F33");
                arrayList.add("9F34");
                arrayList.add("9F35");
                arrayList.add("9F36");
                arrayList.add("9F37");
                arrayList.add("9F39");
                arrayList.add("9F41");
                arrayList.add("D700");
                arrayList.add("D800");
                arrayList.add("5F28");
                arrayList.add("9F0A");
                break;
            }
            case Completion: {
                break;
            }
        }
        return arrayList;
    }

    /*
     * Unable to fully structure code
     */
    private static String extractEncryptedTrack2(byte[] var0) {
        var1_1 = Integer.parseInt(PosmateMessageAdaptor.extractMessageIdentifier(var0));
        switch (var1_1) {
            case 53: {
                var2_2 = 3;
                ** GOTO lbl13
            }
            case 52: {
                var2_2 = 4;
                if (true) ** GOTO lbl13
            }
            default: {
                return null;
            }
        }
        do {
            ++var2_2;
lbl13:
            // 3 sources

        } while (var2_2 < var0.length && var0[var2_2] != 31 && var0[var2_2] != 3);
        if (var0[var2_2] != 31) {
            return null;
        }
        ++var2_2;
        var3_3 = new StringBuilder();
        while (var2_2 < var0.length && var0[var2_2] != 31 && var0[var2_2] != 3) {
            var3_3.append(Character.toString((char)var0[var2_2++]));
        }
        return var3_3.toString();
    }

    private static String extractMessageIdentifier(byte[] byArray) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 1;
        while (n < 3) {
            stringBuilder.append(Character.toString((char)byArray[n]));
            ++n;
        }
        return stringBuilder.toString();
    }

    /*
     * Unable to fully structure code
     */
    private static String extractKSN(byte[] var0) {
        var1_1 = Integer.parseInt(PosmateMessageAdaptor.extractMessageIdentifier(var0));
        switch (var1_1) {
            case 53: {
                var2_2 = 3;
                ** GOTO lbl13
            }
            case 52: {
                var2_2 = 4;
                if (true) ** GOTO lbl13
            }
            default: {
                return null;
            }
        }
        do {
            ++var2_2;
lbl13:
            // 3 sources

        } while (var2_2 < var0.length && var0[var2_2] != 31 && var0[var2_2] != 3);
        if (var0[var2_2] != 31) {
            return null;
        }
        ++var2_2;
        while (var2_2 < var0.length && var0[var2_2] != 31 && var0[var2_2] != 3) {
            ++var2_2;
        }
        if (var0[var2_2] != 31) {
            return null;
        }
        ++var2_2;
        var3_3 = new StringBuilder();
        while (var3_3.length() < 20 && var2_2 < var0.length && var0[var2_2] != 28 && var0[var2_2] != 31 && var0[var2_2] != 3) {
            var3_3.append(Character.toString((char)var0[var2_2++]));
        }
        return var3_3.toString();
    }

    private static Boolean extractFallBackIndicator(byte[] byArray) {
        int n = Integer.parseInt(PosmateMessageAdaptor.extractMessageIdentifier(byArray));
        switch (n) {
            case 53: {
                break;
            }
            case 52: {
                if (byArray[4] == 49) {
                    return true;
                }
                return false;
            }
            default: {
                return null;
            }
        }
        int n2 = PosmateMessageAdaptor.nthIndexOf(byArray, (byte)31, 3);
        if (n2 < 0) {
            return null;
        }
        if (byArray[++n2] != 48 && byArray[n2] != 49) {
            return null;
        }
        if (byArray.length <= n2 + 16 + 20 + 1 + 1) {
            return null;
        }
        if (byArray[n2] == 49) {
            return true;
        }
        return false;
    }

    public static int nthIndexOf(byte[] byArray, byte by, int n) {
        if (byArray != null && n >= 1) {
            int n2 = 0;
            while (n2 < byArray.length) {
                if (byArray[n2] == by && --n == 0) {
                    return n2;
                }
                ++n2;
            }
        }
        return -1;
    }

    private int checkMerchantCodeForRefundOrReversalValidation(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(yP_TCD_DC_Transaction);
        return 1;
    }

    final class Constants {
        public static final int level_2_initialization_msg_identifier = 12;
        public static final int stand_by_msg_identifier = 13;
        public static final int status_report_msg_identifier = 49;
        public static final int start_process_msg_identifier = 41;
        public static final int get_transaction_and_application_data_msg_identifier = 42;
        public static final int terminalRiskManagement = 43;
        public static final int check_exception_file_msg_identifier = 43;
        public static final int check_transaction_log_msg_identifier = 44;
        public static final int referral_performed = 45;
        public static final int go_online_msg_identifier = 46;
        public static final int complete_transaction_msg_identifier = 47;
        public static final int signature_verified = 54;
        public static final int terminate_transaction_msg_identifier = 48;
        public static final int process_swiped_card_identifier = 52;
        public static final int get_swiped_transaction_data_identifier = 53;
        public static final int file_download_msg_identifier = 62;
        public static final char fs = '\u001c';
        public static final char us = '\u001f';
        public static final char stx = '\u0002';
        public static final char etx = '\u0003';
        public static final char zero = '\f';

        Constants() {
        }
    }
}

