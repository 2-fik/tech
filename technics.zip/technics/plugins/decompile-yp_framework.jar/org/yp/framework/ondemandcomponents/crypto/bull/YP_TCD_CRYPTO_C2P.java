/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  iaik.pkcs.pkcs11.Mechanism
 *  iaik.pkcs.pkcs11.Module
 *  iaik.pkcs.pkcs11.Session
 *  iaik.pkcs.pkcs11.Slot
 *  iaik.pkcs.pkcs11.Token
 *  iaik.pkcs.pkcs11.TokenException
 *  iaik.pkcs.pkcs11.TokenInfo
 *  iaik.pkcs.pkcs11.objects.Attribute
 *  iaik.pkcs.pkcs11.objects.CharArrayAttribute
 *  iaik.pkcs.pkcs11.objects.DES2SecretKey
 *  iaik.pkcs.pkcs11.objects.GenericTemplate
 *  iaik.pkcs.pkcs11.objects.Key
 *  iaik.pkcs.pkcs11.objects.Object
 *  iaik.pkcs.pkcs11.objects.SecretKey
 *  iaik.pkcs.pkcs11.parameters.KeyDerivationStringDataParameters
 *  iaik.pkcs.pkcs11.parameters.MacGeneralParameters
 *  iaik.pkcs.pkcs11.parameters.Parameters
 */
package org.yp.framework.ondemandcomponents.crypto.bull;

import iaik.pkcs.pkcs11.Mechanism;
import iaik.pkcs.pkcs11.Module;
import iaik.pkcs.pkcs11.Session;
import iaik.pkcs.pkcs11.Slot;
import iaik.pkcs.pkcs11.Token;
import iaik.pkcs.pkcs11.TokenException;
import iaik.pkcs.pkcs11.TokenInfo;
import iaik.pkcs.pkcs11.objects.Attribute;
import iaik.pkcs.pkcs11.objects.CharArrayAttribute;
import iaik.pkcs.pkcs11.objects.DES2SecretKey;
import iaik.pkcs.pkcs11.objects.GenericTemplate;
import iaik.pkcs.pkcs11.objects.Key;
import iaik.pkcs.pkcs11.objects.SecretKey;
import iaik.pkcs.pkcs11.parameters.KeyDerivationStringDataParameters;
import iaik.pkcs.pkcs11.parameters.MacGeneralParameters;
import iaik.pkcs.pkcs11.parameters.Parameters;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_MacAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_CRYPTO_C2P
extends YP_TCD_CRYPTO_Module
implements YP_TCD_CRYPTO_CipherSym_Interface,
YP_TCD_CRYPTO_MacAlgo_Interface {
    private static final String DLL_NAME = "pkcs11c2p.dll";
    private Module pkcs11Module;
    private Session session;
    private final Map<String, SecretKey> secretKeyMap = new HashMap<String, SecretKey>();
    private final int TOKEN_ITERATIONS = 2;
    private final int TOKEN_SALTLENGTH = 10;

    public YP_TCD_CRYPTO_C2P(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        boolean cfr_ignored_0 = yP_Object instanceof YP_TS_GlobalProcessManager;
    }

    @Override
    public int initialize() {
        try {
            this.myCipherSym = this;
            this.myMAC = this;
            super.initialize();
            return this.initializeContext();
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() " + exception);
            }
            return -1;
        }
    }

    private int initializeContext() {
        String string;
        Token token;
        block12: {
            Slot[] slotArray;
            block11: {
                if (this.session != null) {
                    return 1;
                }
                try {
                    if (this.pkcs11Module == null) {
                        this.pkcs11Module = Module.getInstance((String)DLL_NAME);
                        this.pkcs11Module.initialize(null);
                    }
                    if ((slotArray = this.pkcs11Module.getSlotList(true)) != null && slotArray.length != 0) break block11;
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "initializeContext() No slot with present token found!");
                    }
                    return -1;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "initializeContext() " + exception);
                    }
                    return -1;
                }
            }
            if (this.getLogLevel() >= 4) {
                this.logger(4, "initializeContext() There is(are) " + slotArray.length + " slot(s)");
            }
            Slot slot = slotArray[0];
            token = slot.getToken();
            this.session = token.openSession(true, true, null, null);
            string = this.getCryptoPropertie("USER");
            if (string != null) break block12;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initializeContext() properties USER is not setted !!!");
            }
            return -1;
        }
        this.session.login(true, string.toCharArray());
        if (this.getLogLevel() >= 5) {
            TokenInfo tokenInfo = token.getTokenInfo();
            this.logger(5, "initializeContext() Information of Token:" + tokenInfo);
            List<Mechanism> list = Arrays.asList(token.getMechanismList());
            this.logger(5, "initializeContext() Supported mechanisms:" + list);
        }
        return 1;
    }

    private int closeContext() {
        block7: {
            block6: {
                try {
                    if (this.session != null) {
                        this.session.closeSession();
                        this.session = null;
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) break block6;
                    this.logger(2, "shutdown() " + exception);
                }
            }
            try {
                if (this.pkcs11Module != null) {
                    this.pkcs11Module.finalize(null);
                    this.pkcs11Module = null;
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block7;
                this.logger(2, "shutdown() " + exception);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        this.closeContext();
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "CryptoC2P";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :" + exception);
            return null;
        }
    }

    private Key deriveKey(String string, Key key, String string2) throws TokenException {
        Mechanism mechanism;
        DES2SecretKey dES2SecretKey = new DES2SecretKey();
        switch (string) {
            case "DUKPT/DATA": 
            case "DUKPT/": {
                ((SecretKey)dES2SecretKey).getEncrypt().setBooleanValue(Boolean.TRUE);
                ((SecretKey)dES2SecretKey).getDecrypt().setBooleanValue(Boolean.TRUE);
                ((SecretKey)dES2SecretKey).getSign().setBooleanValue(Boolean.FALSE);
                ((SecretKey)dES2SecretKey).getVerify().setBooleanValue(Boolean.FALSE);
                mechanism = Mechanism.get((long)0x80000066L);
                break;
            }
            case "DUKPT/MAC/REQUEST": {
                ((SecretKey)dES2SecretKey).getEncrypt().setBooleanValue(Boolean.FALSE);
                ((SecretKey)dES2SecretKey).getDecrypt().setBooleanValue(Boolean.FALSE);
                ((SecretKey)dES2SecretKey).getSign().setBooleanValue(Boolean.TRUE);
                ((SecretKey)dES2SecretKey).getVerify().setBooleanValue(Boolean.TRUE);
                mechanism = Mechanism.get((long)0x80000066L);
                break;
            }
            case "DUKPT/MAC/RESPONSE": {
                ((SecretKey)dES2SecretKey).getEncrypt().setBooleanValue(Boolean.FALSE);
                ((SecretKey)dES2SecretKey).getDecrypt().setBooleanValue(Boolean.FALSE);
                ((SecretKey)dES2SecretKey).getSign().setBooleanValue(Boolean.TRUE);
                ((SecretKey)dES2SecretKey).getVerify().setBooleanValue(Boolean.FALSE);
                mechanism = Mechanism.get((long)0x80000066L);
                break;
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "deriveKey() bad parameter algoName " + string);
                }
                throw new TokenException("deriveKey() bad parameter algoName " + string);
            }
        }
        KeyDerivationStringDataParameters keyDerivationStringDataParameters = new KeyDerivationStringDataParameters(UtilsYP.redHexa(string2));
        mechanism.setParameters((Parameters)keyDerivationStringDataParameters);
        Key key2 = this.session.deriveKey(mechanism, key, (Key)dES2SecretKey);
        return key2;
    }

    @Override
    public String decrypt(String string, String string2, List<Property> list, String string3, String string4, String string5) throws Exception {
        byte[] byArray;
        this.initializeContext();
        Mechanism mechanism = this.getMechanism(string3, string4);
        try {
            byArray = UtilsYP.base64Decode(string);
        }
        catch (Exception exception) {
            this.logger(2, "decrypt() bad value to decrypt: " + string + " " + exception);
            throw exception;
        }
        try {
            String string6;
            this.lock();
            SecretKey secretKey = this.getKey(string2);
            if (secretKey == null) {
                return null;
            }
            if (string3.startsWith("DUKPT/")) {
                secretKey = this.deriveKey(string3, (Key)secretKey, string4);
            }
            this.session.decryptInit(mechanism, (Key)secretKey);
            byte[] byArray2 = this.session.decrypt(byArray);
            String string7 = string6 = new String(byArray2);
            return string7;
        }
        catch (Exception exception) {
            this.closeContext();
            throw exception;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public byte[] decrypt(byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        this.initializeContext();
        Mechanism mechanism = this.getMechanism(string2, string3);
        try {
            byte[] byArray2;
            this.lock();
            SecretKey secretKey = this.getKey(string);
            if (secretKey == null) {
                return null;
            }
            if (string2.startsWith("DUKPT/")) {
                secretKey = this.deriveKey(string2, (Key)secretKey, string3);
            }
            this.session.decryptInit(mechanism, (Key)secretKey);
            byte[] byArray3 = byArray2 = this.session.decrypt(byArray);
            return byArray3;
        }
        catch (Exception exception) {
            this.closeContext();
            throw exception;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public String decryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        this.initializeContext();
        if (string2.startsWith("DUKPT/")) {
            this.logger(2, "decryptToken() is not implemented ");
            throw new Exception("decryptToken() is not implemented ");
        }
        Mechanism mechanism = this.getMechanism(string2, null);
        try {
            this.lock();
            SecretKey secretKey = this.getKey(string);
            if (secretKey == null) {
                return null;
            }
            String string4 = null;
            String string5 = string3;
            int n = 0;
            while (n < 2) {
                byte[] byArray = UtilsYP.base64Decode(string5);
                this.session.decryptInit(mechanism, (Key)secretKey);
                byte[] byArray2 = this.session.decrypt(byArray);
                string5 = string4 = new String(byArray2).substring(10);
                ++n;
            }
            String string6 = string4;
            return string6;
        }
        catch (Exception exception) {
            this.closeContext();
            throw exception;
        }
        finally {
            this.unlock();
        }
    }

    private Mechanism getMechanism(String string, String string2) throws Exception {
        Mechanism mechanism;
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMechanism() bad parameter algoName");
            }
            throw new Exception("getMechanism() bad parameter algoName");
        }
        switch (string) {
            case "AES/CBC/PKCS5Padding": {
                mechanism = Mechanism.get((long)4229L);
                break;
            }
            case "AES/CBC/NoPadding": {
                mechanism = Mechanism.get((long)4226L);
                break;
            }
            case "DUKPT/DATA": 
            case "DUKPT/": {
                mechanism = Mechanism.get((long)310L);
                break;
            }
            case "DUKPT/MAC/REQUEST": 
            case "DUKPT/MAC/RESPONSE": {
                mechanism = Mechanism.get((long)2147483957L);
                MacGeneralParameters macGeneralParameters = new MacGeneralParameters(8L);
                mechanism.setParameters((Parameters)macGeneralParameters);
                break;
            }
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getMechanism() unknown algo:" + string);
                }
                throw new Exception("getMechanism() unknown algo:" + string);
            }
        }
        return mechanism;
    }

    private byte[] encryptPrivate(byte[] byArray, String string, String string2, String string3) throws Exception {
        this.initializeContext();
        if (string2.startsWith("DUKPT/")) {
            this.logger(2, "encryptPrivate() encrypt is not implemented for DUKPT");
            throw new Exception("encryptPrivate() encrypt is not implemented for DUKPT");
        }
        Mechanism mechanism = this.getMechanism(string2, string3);
        try {
            byte[] byArray2;
            this.lock();
            SecretKey secretKey = this.getKey(string);
            if (secretKey == null) {
                return null;
            }
            this.session.encryptInit(mechanism, (Key)secretKey);
            byte[] byArray3 = byArray2 = this.session.encrypt(byArray);
            return byArray3;
        }
        catch (Exception exception) {
            this.closeContext();
            throw exception;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public String[] encrypt(String string, String string2, List<Property> list, String string3, String string4) throws Exception {
        byte[] byArray = this.encryptPrivate(string.getBytes(), string2, string3, string4);
        String string5 = UtilsYP.base64Encode(byArray);
        String[] stringArray = new String[]{string5.replace(UtilsYP.lineSeparator, ""), string2};
        return stringArray;
    }

    @Override
    public byte[][] encrypt(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        byte[] byArray2 = this.encryptPrivate(byArray, string, string2, string3);
        byte[][] byArrayArray = new byte[][]{byArray2, string.getBytes()};
        return byArrayArray;
    }

    @Override
    public String[] encryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        int n;
        StringBuilder stringBuilder = new StringBuilder(10);
        if (string3.length() >= 10) {
            n = 0;
            while (n < 10) {
                stringBuilder.append(string3.charAt(n));
                ++n;
            }
        } else {
            n = 0;
            while (n < string3.length()) {
                stringBuilder.append(string3.charAt(n));
                ++n;
            }
            while (stringBuilder.length() != 10) {
                stringBuilder.append("X");
            }
        }
        String string4 = string3;
        int n2 = 0;
        while (n2 < 2) {
            String string5 = stringBuilder + string4;
            byte[] byArray = this.encryptPrivate(string5.getBytes(), string, string2, null);
            string4 = UtilsYP.base64Encode(byArray);
            ++n2;
        }
        String[] stringArray = new String[3];
        stringArray[0] = string4.replace(UtilsYP.lineSeparator, "");
        stringArray[1] = string;
        return stringArray;
    }

    @Override
    public int addKey(String string, List<Property> list, byte[] byArray, String string2) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "addKey() is not implemented");
        }
        throw new Exception("addKey() is not implemented");
    }

    @Override
    public int isCryptoSupported(String string) {
        int n = this.isCipherSymSupported(string);
        if (n >= 1) {
            return n;
        }
        n = this.isMACSupported(string);
        if (n >= 1) {
            return n;
        }
        return 0;
    }

    @Override
    public int isCipherSymSupported(String string) {
        switch (string) {
            case "AES/CBC/NoPadding": 
            case "AES/CBC/PKCS5Padding": 
            case "DUKPT/DATA": 
            case "DUKPT/": {
                return 1;
            }
        }
        return 0;
    }

    @Override
    public String computeMAC(String string, List<Property> list, byte[] byArray, Object ... objectArray) throws Exception {
        Object object;
        this.initializeContext();
        if (objectArray == null || objectArray.length < 3 || objectArray[2] == null || !(objectArray[2] instanceof String)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "computeMAC() bad parameters");
            }
            throw new Exception("Bad parameters");
        }
        if (byArray.length < 8) {
            this.logger(2, "computeMAC() Length must be at least of 8 bytes");
            object = this.getPluginByName("CryptoManager");
            String string2 = (String)((YP_Object)object).dealRequest(this, "sha256Hash", new Object[]{byArray});
            if (string2 == null || string2.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "computeMAC() pb during hash");
                }
                throw new Exception("computeMAC() pb during hash");
            }
            byArray = UtilsYP.redHexa(string2);
        }
        switch ((String)objectArray[2]) {
            case "000000000000FF00000000000000FF00": {
                object = "DUKPT/MAC/REQUEST";
                break;
            }
            case "00000000FF00000000000000FF000000": {
                object = "DUKPT/MAC/RESPONSE";
                break;
            }
            default: {
                throw new Exception("computeMAC() Unknown derivation " + (String)objectArray[2]);
            }
        }
        String string3 = string;
        String string4 = DUKPT.getBDKAlias(string3);
        Mechanism mechanism = this.getMechanism((String)object, null);
        try {
            this.lock();
            SecretKey secretKey = this.getKey(string4);
            if (secretKey == null) {
                return null;
            }
            Key key = this.deriveKey((String)object, (Key)secretKey, string3);
            this.session.signInit(mechanism, key);
            byte[] byArray2 = this.session.sign(byArray);
            String string5 = UtilsYP.devHexa(byArray2);
            return string5;
        }
        catch (Exception exception) {
            this.closeContext();
            throw exception;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public boolean verifyMAC(String string, List<Property> list, byte[] byArray, String string2, Object ... objectArray) throws Exception {
        String string3;
        block6: {
            this.initializeContext();
            if (byArray.length < 8) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "verifyMAC() Length must be at least of 8 bytes");
                }
                return true;
            }
            try {
                string3 = this.computeMAC(string, list, byArray, objectArray[0], objectArray[1], objectArray[3]);
                if (string3 != null) break block6;
                return false;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "verifyMAC() " + exception);
                }
                throw exception;
            }
        }
        return string3.contentEquals(string2);
    }

    @Override
    public int isMACSupported(String string) {
        switch (string) {
            case "DUKPT/MAC/REQUEST": 
            case "DUKPT/MAC/RESPONSE": {
                return 1;
            }
        }
        return 0;
    }

    private SecretKey getKey(String string) throws Exception {
        SecretKey secretKey = this.secretKeyMap.get(string);
        if (secretKey == null) {
            GenericTemplate genericTemplate = new GenericTemplate();
            CharArrayAttribute charArrayAttribute = new CharArrayAttribute(Attribute.LABEL);
            genericTemplate.addAttribute((Attribute)charArrayAttribute);
            genericTemplate.getAttribute(Attribute.LABEL.longValue()).setValue((Object)string.toCharArray());
            try {
                this.session.findObjectsInit((iaik.pkcs.pkcs11.objects.Object)genericTemplate);
                iaik.pkcs.pkcs11.objects.Object[] objectArray = this.session.findObjects(1);
                if (objectArray == null || objectArray.length == 0 || objectArray[0] == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getKey() not found:" + string);
                    }
                    throw new Exception("getKey() not found:" + string);
                }
                if (objectArray.length > 1 && this.getLogLevel() >= 2) {
                    this.logger(2, "getKey() too many found for" + string);
                }
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "getKey() " + string + " loaded");
                }
                secretKey = (SecretKey)objectArray[0];
                this.secretKeyMap.put(string, secretKey);
            }
            finally {
                block13: {
                    try {
                        this.session.findObjectsFinal();
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 2) break block13;
                        this.logger(2, "getKey() " + string + " " + exception);
                    }
                }
            }
        }
        return secretKey;
    }

    @Override
    public byte[] decryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        throw new Exception("decryptPIN() Not done");
    }

    @Override
    public byte[] translatePIN(byte[] byArray, String string, String string2, String string3, List<Property> list, String string4, String string5, String string6, String string7, List<Property> list2, String string8, String string9) throws Exception {
        throw new Exception("translatePIN() Not done");
    }

    @Override
    public byte[] exportKey(String string, List<Property> list, String string2, List<Property> list2) {
        this.logger(2, "exportKey() Not done");
        return null;
    }

    @Override
    public byte[] importKey(String string, String string2, List<Property> list) {
        this.logger(2, "importKey() Not done");
        return null;
    }

    @Override
    public byte[][] encryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        throw new Exception("encryptPIN() Not done");
    }
}

