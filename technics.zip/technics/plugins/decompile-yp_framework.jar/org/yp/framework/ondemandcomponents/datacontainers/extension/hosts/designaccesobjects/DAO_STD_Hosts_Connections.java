/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_Hosts_Connections
extends YP_Row {
    @PrimaryKey
    public long idHostsConnections = 0L;
    public byte[] name = new byte[4];
    public byte[] type = new byte[10];
    public byte[] padType = new byte[1];
    public byte[] connectionTelNumber = new byte[20];
    public byte[] x25Address = new byte[40];
    public byte[] ipAddress = new byte[40];
    public int port = 0;
    public int rank = 0;
    public byte[] externalReference = new byte[30];
}

