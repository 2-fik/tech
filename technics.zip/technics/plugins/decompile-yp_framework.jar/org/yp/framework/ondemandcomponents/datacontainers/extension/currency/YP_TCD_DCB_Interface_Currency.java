/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.currency;

import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_Currency
extends YP_TCD_DCB_Interface_Extension {
    public long convertAmount(long var1, String var3, String var4);

    public long convertAmount(long var1, int var3, int var4);

    public String getCurrencyAlphabeticalCode(int var1);

    public int getCurrencyNumericalCode(String var1);

    public int getCurrencyFraction(int var1);

    public int getCurrencyFraction(String var1);

    public long getCurrencyMinAmount(int var1);

    public long getCurrencyMinAmount(String var1);

    public long getCurrencyMaxAmount(int var1);

    public long getCurrencyMaxAmount(String var1);

    public long getCurrencyDoubleAuthentificationAmount(int var1);

    public long getCurrencyDoubleAuthentificationAmount(String var1);

    public int getCounterValuePrintingActivationCode(String var1);

    public List<String> getCurrencyAlphabeticalCodeList();

    public List<String> getCurrencyAlphabeticalCodeList(boolean var1, boolean var2);

    public List<Integer> getCurrencyNumericalCodeList();

    public List<Integer> getCurrencyNumericalCodeList(boolean var1, boolean var2);

    public List<String> getConversionCurrencyAlphaList(String var1);

    public boolean isCurrencyActivated(String var1);

    public String formatAmount(long var1, String var3);

    public String formatAmount(long var1, int var3);

    public long getCurrencyChecksum();
}

