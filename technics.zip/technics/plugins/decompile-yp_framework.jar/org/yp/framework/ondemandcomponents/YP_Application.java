/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_BaseApplication;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.services.YP_TS_GlobalProcessManager;

public abstract class YP_Application
extends YP_BaseApplication {
    protected YP_TCD_DCC_Business dataContainerBusiness = null;
    private YP_TCD_DC_Transaction dataContainerTransaction = null;
    private YP_Transaction transaction = null;
    private int rankInDCC = -1;
    boolean alreadyShut = false;
    private Map<String, String> schemaNameMap = new HashMap<String, String>();

    public YP_Application(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray != null && objectArray.length >= 1 && objectArray[0] != null && objectArray[0] instanceof YP_Transaction) {
                this.setTransaction((YP_Transaction)objectArray[0]);
                this.setDataContainerTransaction(this.getTransaction().getDataContainerTransaction());
                if (objectArray.length >= 2 && objectArray[1] != null && objectArray[1] instanceof YP_TCD_DCC_Business) {
                    List<Object> list;
                    this.setDataContainerBusiness((YP_TCD_DCC_Business)objectArray[1]);
                    if (this.dataContainerBusiness.transaction != null && (list = this.dataContainerBusiness.transaction.getExtensionList()) != null && !list.isEmpty()) {
                        for (Object object : list) {
                            this.dataContainerTransaction.addExtension(object.getClass().newInstance());
                        }
                    }
                } else if (this.getLogLevel() >= 2) {
                    this.logger(2, "YP_Application() ... ");
                }
            } else if (this.getLogLevel() >= 4) {
                this.logger(4, "YP_Application() Hopefully a master application ");
            }
        }
    }

    public abstract int applicationSelection(YP_Object var1, YP_TCD_DCC_Business var2, YP_TCD_DC_Transaction var3);

    @Override
    public int shutdown() {
        if (this.alreadyShut) {
            return 0;
        }
        this.alreadyShut = true;
        super.shutdown();
        try {
            this.dataContainerBusiness.removeApplicationPlugin(this);
        }
        catch (Exception exception) {}
        this.dataContainerBusiness = null;
        this.dataContainerTransaction = null;
        this.transaction = null;
        return 1;
    }

    public void stop() {
        if (this.getTransaction().getDataContainerTransaction() != null) {
            String string = this.getTransaction().getDataContainerTransaction().getEFTResponse(this.transaction);
            if (string != null && this.getTransaction().getClientConnectionHandler() != null) {
                this.getTransaction().getClientConnectionHandler().send(string);
            }
            this.getTransaction().getDataContainerTransaction().shutdown();
            this.getTransaction().setDataContainerTransaction(null);
        }
        if (this.getTransaction().getClientConnectionHandler() != null) {
            this.getTransaction().getClientConnectionHandler().shutdown();
            this.getTransaction().setClientConnectionHandler(null);
        }
        this.shutdown();
    }

    public final void setTransaction(YP_Transaction yP_Transaction) {
        this.transaction = yP_Transaction;
    }

    public final YP_Transaction getTransaction() {
        return this.transaction;
    }

    public final void setDataContainerBusiness(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        this.dataContainerBusiness = yP_TCD_DCC_Business;
    }

    public YP_TCD_DCC_Business getDataContainerBusiness() {
        return this.dataContainerBusiness;
    }

    public final void setDataContainerTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public final YP_TCD_DC_Transaction getDataContainerTransaction() {
        return this.dataContainerTransaction;
    }

    public final void setRankInDCC(int n) {
        this.rankInDCC = n;
    }

    public final int getRankInDCC() {
        return this.rankInDCC;
    }

    public String getSchemaName(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        String string = yP_TCD_DCC_Business.getDataContainerBrand().getBrandName();
        String string2 = this.schemaNameMap.get(string);
        if (string2 != null) {
            return string2;
        }
        string2 = String.valueOf(string) + '_' + this.getApplicationName();
        this.schemaNameMap.put(string, string2);
        return string2;
    }
}

