/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.designaccessobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_CTLSpecificParameter
extends YP_Row {
    @PrimaryKey
    public long idDAO_CTLSpecificParameter = 0L;
    public byte[] kernelID = new byte[10];
    public byte[] applicationIdentifier = new byte[32];
    public byte[] transactionType = new byte[2];
    public byte[] numericalCurrencyCode = new byte[3];
    public byte[] terminalFloorLimit = new byte[12];
    public byte[] readerContactlessFloorLimit = new byte[12];
    public byte[] readerCVMRequiredLimit = new byte[12];
    public byte[] readerContactlessTransactionLimitNoOnDevice = new byte[12];
    public byte[] readerContactlessTransactionLimitOnDevice = new byte[12];
    public Boolean signatureHandled;
    public Boolean pinOnlineHandled;
    public Boolean noCVMHandled;
    public Boolean onDeviceCVMHandled;
    public Boolean statusCheckSupport;
    public Boolean zeroAmountAllowedSupport;
    public byte[] tacDenial = new byte[10];
    public byte[] tacOnline = new byte[10];
    public byte[] tacDefault = new byte[10];
    public byte[] externalReference = new byte[30];
}

