/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_BaseApplication
extends YP_OnDemandComponent {
    private YP_Row applicationRow = null;
    private List<Property> applicationProperties = null;
    private boolean isSuspended = false;

    public YP_BaseApplication(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        boolean cfr_ignored_0 = yP_Object instanceof YP_TS_GlobalProcessManager;
    }

    public abstract YP_TCD_DCC_Business getNewDataContainer(YP_Service var1);

    @Override
    public int shutdown() {
        super.shutdown();
        this.applicationRow = null;
        return 1;
    }

    public final YP_Row getApplicationRow() {
        return this.applicationRow;
    }

    public final void setApplicationRow(YP_Row yP_Row) {
        this.applicationRow = yP_Row;
    }

    public final void setApplicationProperties(List<Property> list) {
        this.applicationProperties = list;
    }

    public final String getApplicationPropertie(String string) {
        List<Property> list = this.getApplicationProperties();
        if (list != null) {
            for (Property property : list) {
                if (!property.getName().contentEquals(string)) continue;
                return property.getValue();
            }
        }
        return null;
    }

    public final List<Property> getApplicationProperties() {
        return this.applicationProperties;
    }

    public final String getApplicationEnvironmentType() {
        return this.getApplicationRow().getFieldStringValueByName("applicationEnvironmentType");
    }

    public final String getProviderAID() {
        return this.getApplicationRow().getFieldStringValueByName("providerAID");
    }

    public final String getManufacturerAID() {
        return this.getApplicationRow().getFieldStringValueByName("manufacturerAID");
    }

    public final String getApplicationName() {
        return this.getApplicationRow().getFieldStringValueByName("applicationName");
    }

    public boolean isSuspended() {
        return this.isSuspended;
    }

    public void setSuspended(boolean bl) {
        this.isSuspended = bl;
    }
}

