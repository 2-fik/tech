/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.Bitmap;

public class DAO_Test24
extends YP_Row {
    @PrimaryKey
    public long idTest24 = 0L;
    public int test24Int = 0;
    public Bitmap test24Bitmap;
}

