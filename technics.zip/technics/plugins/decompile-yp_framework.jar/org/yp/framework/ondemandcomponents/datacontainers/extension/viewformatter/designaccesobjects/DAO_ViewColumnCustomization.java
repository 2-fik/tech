/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;

public class DAO_ViewColumnCustomization
extends YP_Row {
    @PrimaryKey
    public long idViewColumnCustomization = 0L;
    @ForeignKey(name=DAO_ViewColumn.class)
    public long idViewColumn = 0L;
    @ForeignKey(name=DAO_User.class)
    public long idUser = 0L;
    public int rank = 0;
    public int width = 0;
}

