/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.json.JSONException;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_HTTPS_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private static final int WRITE_TIMEOUT_MS = 30000;
    private static final String DEFAULT_USER_AGENT_PROPERTY = "Mozilla/5.0";
    private static final String DEFAULT_ACCEPT_LANGUAGE_PROPERTY = "en-US,en;q=0.5";
    private String USER_AGENT_PROPERTY;
    private String ACCEPT_LANGUAGE_PROPERTY;
    private String ACCEPT_ENCODING_PROPERTY;
    private String ORIGIN_PROPERTY;
    private String COUNTRY_PROPERTY;
    private String REGION_PROPERTY;
    private String MESSAGE_PROPERTY;
    private String MERCHANT_NUMBER_PROPERTY;
    private String RT_IND_PROPERTY;
    private String CONTENT_TYPE_PROPERTY;
    private String PROTOCOL_PROPERTIES;
    private final String PROTOCOL = "TLSv1.2";
    private final String KEYSTOREALGORITHM = "SunX509";
    private final String TRUSTSTOREALGORITHM = "SunX509";
    private final String KEYSTORETYPE_JCEKS = "JCEKS";
    private final String TRUSTSTORETYPE_JCEKS = "JCEKS";
    private final String KEYSTORETYPE_JKS = "jks";
    private final String TRUSTSTORETYPE_JKS = "jks";
    private final int connectionPort = 0;
    private DataOutputStream outputStream = null;
    private BufferedReader inputStream = null;
    private InputStream bInputStream = null;
    private SSLServerSocket serverSocket = null;
    private final SSLServerSocketFactory sslserversocketfactory = null;
    private SSLSocketFactory sslsocketfactory = null;
    private String ipServer = null;
    private int portServer = 0;
    private String ressource = null;
    private int connectionTimeoutMS = 3499;
    private String trustStorePath = null;
    private String trustStorePasswd = null;
    private String keyStorePath = null;
    private String keyStorePasswd = null;
    private String keyAlias = null;
    private String enabledCipherSuites = null;
    private String enabledProtocols = null;
    private String authentificationNeeded = null;
    private String sessionTimeOut = null;
    private URL url = null;
    private HttpsURLConnection conHttps = null;
    private String proxyType = null;
    private String proxyHost = null;
    private int proxyPort = 0;
    private int lastHTTPResponseCode = 0;
    private String lastHTTPErrorResponseContent = null;
    private boolean isTextResponseExpected = true;
    private final byte[] cleanMessage = new byte[1024];

    public YP_TCD_PHYS_HTTPS_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
    }

    private SSLContext getSSLContext(String string, String string2, String string3, String string4, String string5) {
        block23: {
            TrustManagerFactory trustManagerFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            TrustManager[] trustManagerArray = null;
            try {
                KeyStore keyStore;
                SSLContext sSLContext = SSLContext.getInstance("TLSv1.2");
                if (string != null && !string.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string), string2.toCharArray());
                    keyManagerFactory.init(keyStore, string2.toCharArray());
                }
                if (string4 != null && !string4.isEmpty()) {
                    trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string4.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string4), string5.toCharArray());
                    trustManagerFactory.init(keyStore);
                } else {
                    trustManagerArray = new X509TrustManager[]{new X509TrustManager(){

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }
                    }};
                }
                if (keyManagerFactory == null && trustManagerFactory == null) {
                    sSLContext.init(null, trustManagerArray, null);
                } else if (keyManagerFactory == null && trustManagerFactory != null) {
                    sSLContext.init(null, trustManagerFactory.getTrustManagers(), null);
                } else if (keyManagerFactory != null && trustManagerFactory == null) {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerArray, null);
                } else {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                }
                return sSLContext;
            }
            catch (FileNotFoundException fileNotFoundException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() FileNotFoundException:" + fileNotFoundException);
                }
            }
            catch (KeyStoreException keyStoreException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() KeyStoreException:" + keyStoreException);
                }
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() NoSuchAlgorithmException:" + noSuchAlgorithmException);
                }
            }
            catch (CertificateException certificateException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() CertificateException:" + certificateException);
                }
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() IOException:" + iOException);
                }
            }
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() UnrecoverableKeyException:" + unrecoverableKeyException);
                }
            }
            catch (KeyManagementException keyManagementException) {
                if (this.getLogLevel() < 2) break block23;
                this.logger(2, "getSSLContext() KeyManagementException:" + keyManagementException);
            }
        }
        return null;
    }

    private int enabledCipherSuites(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledCipherSuites() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledCipherSuites == null || this.enabledCipherSuites.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedCipherSuites() : ((SSLServerSocket)object).getSupportedCipherSuites();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledCipherSuites, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledCipherSuites() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledCipherSuites() not added " + string);
                }
                if (arrayList.size() <= 0) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledCipherSuites() bad cipher list ? " + this.enabledCipherSuites);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledCipherSuites() " + exception);
            }
        }
        return -1;
    }

    private int enabledProtocols(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledProtocols() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledProtocols == null || this.enabledProtocols.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedProtocols() : ((SSLServerSocket)object).getSupportedProtocols();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledProtocols, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledProtocols() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledProtocols() not added " + string);
                }
                if (arrayList.isEmpty()) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledProtocols() bad protocol list ? " + this.enabledProtocols);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledProtocols() " + exception);
            }
        }
        return -1;
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int close() {
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server HTTPS closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server HTTPS close failed  :" + iOException);
            }
        }
        try {
            if (this.outputStream != null) {
                this.outputStream.flush();
                this.outputStream.close();
                this.outputStream = null;
            }
            if (this.inputStream != null) {
                this.inputStream.close();
                this.inputStream = null;
            }
            this.bInputStream = null;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "close() Stream closed...");
            }
        }
        catch (IOException iOException) {
            this.logger(2, "close() HTTPS close error :" + iOException);
        }
        if (this.conHttps != null) {
            this.conHttps.disconnect();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "close() Client HTTPS closed...");
            }
            this.conHttps = null;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "HTTPSConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.14";
    }

    public boolean isKeystoreEmpty(String string) {
        FileInputStream fileInputStream;
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "isKeystoreEmpty() keystore name missing");
            }
            return true;
        }
        try {
            fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + string);
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileInputStream = null;
        }
        try {
            KeyStore keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
            keyStore.load(fileInputStream, this.keyStorePasswd.toCharArray());
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            return keyStore.size() <= 0;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isKeystoreEmpty() " + exception);
            }
            return true;
        }
    }

    @Override
    public int openServer() {
        block10: {
            if (this.serverSocket != null) {
                return 1;
            }
            try {
                if (!this.isKeystoreEmpty(this.keyStorePath)) break block10;
                this.logger(1, "openServer() keystore empty");
                this.setObjectStatus(2);
                return -2;
            }
            catch (IOException iOException) {
                this.logger(1, "openServer() Can't connect a socket to port 0 " + iOException);
                return -1;
            }
        }
        this.serverSocket = (SSLServerSocket)this.sslserversocketfactory.createServerSocket(0);
        this.enabledCipherSuites(this.serverSocket);
        this.enabledProtocols(this.serverSocket);
        if (this.trustStorePath == null) {
            this.serverSocket.setWantClientAuth(false);
        } else if (this.authentificationNeeded == null || this.authentificationNeeded.compareTo("0") == 0) {
            this.serverSocket.setWantClientAuth(true);
        } else {
            this.serverSocket.setNeedClientAuth(true);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "openServer() Waiting for connections on port" + this.serverSocket.getLocalPort() + "...");
        }
        if (this.getLogLevel() >= 4) {
            this.printServerSocketInfo(this.serverSocket);
        }
        return 1;
    }

    @Override
    public Object waitConnection() {
        try {
            this.serverSocket.setSoTimeout(this.getConnectionTimeout());
        }
        catch (SocketException socketException) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() setSoTimeout " + socketException);
            }
            return null;
        }
        try {
            SSLSocket sSLSocket = (SSLSocket)this.serverSocket.accept();
            if (this.getLogLevel() >= 4) {
                this.printSocketInfo(this.conHttps);
            }
            return sSLSocket;
        }
        catch (IOException iOException) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() Timeout " + iOException);
            }
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public int recv(byte[] var1_1, int var2_2, int var3_3, int var4_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 11[DOLOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public int clean(int n) {
        try {
            if (this.inputStream == null) {
                this.inputStream = new BufferedReader(new InputStreamReader(this.conHttps.getInputStream()));
            }
        }
        catch (IOException iOException) {
            this.logger(2, "clean() streams " + iOException);
            return -1;
        }
        long l = System.currentTimeMillis();
        StringBuilder stringBuilder = new StringBuilder();
        this.conHttps.setReadTimeout(n);
        do {
            try {
                String string;
                while ((string = this.inputStream.readLine()) != null) {
                    stringBuilder.append(string);
                }
                if (stringBuilder.length() > 0) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, UtilsYP.getFormattedLog(2, this.cleanMessage, 0, stringBuilder.length()));
                        continue;
                    }
                    if (this.getLogLevel() < 4) continue;
                    this.logger(4, "clean() bytes cleaned :" + stringBuilder.length());
                    continue;
                }
                if (stringBuilder.length() == 0) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "clean() nothing...");
                    continue;
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "clean() error :" + stringBuilder.length());
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "clean() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "clean() Read error..." + exception);
                return -1;
            }
        } while (!UtilsYP.isTimeout(l, n));
        return 1;
    }

    @Override
    public int available() {
        try {
            if (this.inputStream == null) {
                this.inputStream = new BufferedReader(new InputStreamReader(this.conHttps.getInputStream()));
            }
        }
        catch (IOException iOException) {
            this.logger(2, "available() streams " + iOException);
            return -1;
        }
        try {
            if (this.inputStream.ready()) {
                return 1;
            }
        }
        catch (IOException iOException) {
            this.logger(2, "available() Error..." + iOException);
        }
        return 0;
    }

    @Override
    public int send(byte[] byArray, int n) {
        if (byArray.length > 0 && this.getLogLevel() >= 6) {
            this.logger(6, "SEND(): " + UtilsYP.devHexa(byArray));
        }
        SendWithTimeout sendWithTimeout = new SendWithTimeout(this, byArray, n);
        sendWithTimeout.start();
        try {
            sendWithTimeout.join(30000L);
        }
        catch (InterruptedException interruptedException) {
            this.logger(2, "send() Interrupted" + interruptedException);
        }
        if (sendWithTimeout.exception != null) {
            this.logger(2, "send() Exception during sendWithTimeout " + sendWithTimeout.exception);
            throw new RuntimeException(sendWithTimeout.exception);
        }
        if (!sendWithTimeout.finished) {
            this.logger(2, "send() sending thread is blocked ? " + sendWithTimeout.exception);
            sendWithTimeout.interrupt();
            try {
                this.close();
            }
            catch (Exception exception) {
                this.logger(2, "send() Excpetion during close " + exception);
            }
            return -1;
        }
        return sendWithTimeout.response;
    }

    private int sendInternal(byte[] byArray, int n) {
        int n2;
        block26: {
            this.lastHTTPResponseCode = 0;
            this.lastHTTPErrorResponseContent = null;
            if (!this.conHttps.getRequestMethod().contentEquals("GET")) {
                try {
                    if (this.outputStream == null) {
                        this.outputStream = new DataOutputStream(this.conHttps.getOutputStream());
                    }
                }
                catch (IOException iOException) {
                    this.logger(2, "send() streams " + iOException);
                    return -1;
                }
            }
            try {
                Object object;
                if (!this.conHttps.getRequestMethod().contentEquals("GET")) {
                    if (this.MESSAGE_PROPERTY != null && this.MESSAGE_PROPERTY.contentEquals("ISO GCAG")) {
                        String string = "AuthorizationRequestParam=" + UtilsYP.devHexa(byArray);
                        this.outputStream.write(string.getBytes(), 0, string.getBytes().length);
                    } else {
                        this.outputStream.write(byArray, 0, n);
                    }
                    this.outputStream.flush();
                }
                this.lastHTTPResponseCode = n2 = this.conHttps.getResponseCode();
                if (this.getLogLevel() >= 5) {
                    object = new StringBuilder("Header fields:\r\n");
                    int n3 = 0;
                    while (n3 < this.conHttps.getHeaderFields().size()) {
                        ((StringBuilder)object).append(String.format("%s: %s\r\n", this.conHttps.getHeaderFieldKey(n3), this.conHttps.getHeaderField(n3)));
                        ++n3;
                    }
                    this.logger(5, ((StringBuilder)object).toString());
                }
                if (n2 >= 200 && n2 < 300) break block26;
                if (this.getLogLevel() >= 6) {
                    this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
                }
                try {
                    object = null;
                    try {
                        object = this.conHttps.getInputStream();
                    }
                    catch (Exception exception) {}
                    if (object == null) {
                        object = this.conHttps.getErrorStream();
                    }
                    if (object != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((InputStream)object, "UTF-8"));
                        String string = null;
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((string = bufferedReader.readLine()) != null) {
                            stringBuilder.append(String.valueOf(string) + "\n");
                        }
                        bufferedReader.close();
                        String string2 = stringBuilder.toString();
                        this.logger(4, "send() Content: " + string2);
                        this.lastHTTPErrorResponseContent = string2;
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "send() " + exception);
                }
                this.logger(2, String.format("send() HTTP %s: %s", this.conHttps.getRequestMethod(), n2));
                return -1;
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 6) {
                    this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
                }
                this.logger(3, "send() Write error..." + iOException);
                return -1;
            }
        }
        if (n2 != 200) {
            this.logger(3, String.format("send() HTTP %s: %s", this.conHttps.getRequestMethod(), n2));
        } else {
            this.logger(4, String.format("send() HTTP %s: %s", this.conHttps.getRequestMethod(), n2));
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
        } else if (this.getLogLevel() >= 4) {
            this.logger(4, "send() bytes sent :" + n);
        }
        return n;
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        try {
            return this.conHttps.getURL().getHost();
        }
        catch (Exception exception) {
            this.logger(2, "getIP() " + exception);
            return null;
        }
    }

    @Override
    public int openClient(Object ... objectArray) {
        Object object;
        block76: {
            block75: {
                if (objectArray != null) break block75;
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                if (this.ipServer == null) {
                    this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                }
                this.ressource = ((YP_Row)objectArray[0]).getFieldStringValueByName("ressource");
                if (this.connectionTimeoutMS == 3499) {
                    this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                }
                if (this.sslsocketfactory == null) {
                    if (this.trustStorePath == null) {
                        this.trustStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePath");
                    }
                    if (this.trustStorePasswd == null) {
                        this.trustStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePasswd");
                    }
                    if (this.keyStorePath == null) {
                        this.keyStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePath");
                    }
                    if (this.keyStorePasswd == null) {
                        this.keyStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePasswd");
                    }
                    if (this.keyAlias == null) {
                        this.keyAlias = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyAlias");
                    }
                    if (this.enabledCipherSuites == null) {
                        this.enabledCipherSuites = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledCipherSuites");
                        this.enabledCipherSuites = this.enabledCipherSuites.trim();
                    }
                    if (this.enabledProtocols == null) {
                        this.enabledProtocols = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledProtocols");
                        this.enabledProtocols = this.enabledProtocols.trim();
                    }
                    if (this.authentificationNeeded == null) {
                        this.authentificationNeeded = ((YP_Row)objectArray[0]).getFieldStringValueByName("authentificationNeeded");
                    }
                    if (this.sessionTimeOut == null) {
                        this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
                    }
                    object = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd);
                    this.sslsocketfactory = ((SSLContext)object).getSocketFactory();
                }
                if (this.proxyType == null) {
                    this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
                }
                if (this.proxyHost == null) {
                    this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
                }
                if (this.proxyPort == 0) {
                    this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
                }
                this.USER_AGENT_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("userAgent");
                if (this.USER_AGENT_PROPERTY == null || this.USER_AGENT_PROPERTY.isEmpty()) {
                    this.USER_AGENT_PROPERTY = DEFAULT_USER_AGENT_PROPERTY;
                }
                this.ACCEPT_LANGUAGE_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("acceptLanguage");
                if (this.ACCEPT_LANGUAGE_PROPERTY == null || this.ACCEPT_LANGUAGE_PROPERTY.isEmpty()) {
                    this.ACCEPT_LANGUAGE_PROPERTY = DEFAULT_ACCEPT_LANGUAGE_PROPERTY;
                }
                this.ACCEPT_ENCODING_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("acceptEncoding");
                this.ORIGIN_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("origin");
                this.COUNTRY_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("country");
                this.REGION_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("region");
                this.MESSAGE_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("message");
                this.MERCHANT_NUMBER_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("merchNbr");
                this.RT_IND_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("rtInd");
                this.CONTENT_TYPE_PROPERTY = ((YP_Row)objectArray[0]).getExtensionValueAsString("contentType");
                this.PROTOCOL_PROPERTIES = ((YP_Row)objectArray[0]).getExtensionValueAsString("protocolProperties");
            } else if (objectArray.length >= 3 && objectArray[0] instanceof String && objectArray[1] instanceof String && objectArray[2] instanceof String) {
                if (this.ipServer == null) {
                    this.ipServer = (String)objectArray[0];
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt((String)objectArray[1]);
                }
                if (this.ressource == null) {
                    this.ressource = (String)objectArray[2];
                }
                if (objectArray.length > 3 && objectArray[3] instanceof Integer) {
                    this.connectionTimeoutMS = (Integer)objectArray[3];
                }
            }
            if (this.ipServer != null && this.portServer != 0 && this.sslsocketfactory != null) break block76;
            this.logger(2, "openClient() missing parameters");
            return -1;
        }
        try {
            try {
                block77: {
                    this.url = new URL("https", this.ipServer, this.portServer, this.ressource);
                    if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "openClient() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
                        }
                        object = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.proxyHost, this.proxyPort));
                        this.conHttps = (HttpsURLConnection)this.url.openConnection((Proxy)object);
                    } else {
                        this.conHttps = (HttpsURLConnection)this.url.openConnection();
                    }
                    this.conHttps.setSSLSocketFactory(this.sslsocketfactory);
                    this.conHttps.setHostnameVerifier(new HostnameVerifier(){

                        @Override
                        public boolean verify(String string, SSLSession sSLSession) {
                            return true;
                        }
                    });
                    this.conHttps.setDoOutput(true);
                    this.conHttps.setDoInput(true);
                    this.conHttps.setRequestMethod("POST");
                    this.conHttps.setUseCaches(false);
                    if (this.PROTOCOL_PROPERTIES == null || this.PROTOCOL_PROPERTIES.isEmpty()) break block77;
                    try {
                        String string;
                        block78: {
                            object = new JSONObject(this.PROTOCOL_PROPERTIES);
                            if (!object.has("requestMethod") || (string = object.getString("requestMethod")) == null) break block78;
                            switch (string = string.toUpperCase()) {
                                case "GET": {
                                    this.conHttps.setDoOutput(false);
                                }
                                case "OPTIONS": 
                                case "PUT": 
                                case "HEAD": 
                                case "POST": 
                                case "PATCH": 
                                case "DELETE": {
                                    this.conHttps.setRequestMethod(string);
                                    break;
                                }
                                default: {
                                    this.logger(2, "openClient() protocolProperties: invalid request method: " + string);
                                }
                            }
                        }
                        if (object.has("httpHeaders") && (string = object.getJSONArray("httpHeaders")) != null) {
                            int n = 0;
                            while (n < string.length()) {
                                Object object2 = string.get(n);
                                if (object2 instanceof JSONObject) {
                                    String string2 = (JSONObject)object2;
                                    String string3 = string2.getString("name");
                                    String string4 = string2.getString("value");
                                    if (string3 != null && !string3.isEmpty() && string4 != null && !string4.isEmpty()) {
                                        this.conHttps.setRequestProperty(string3, string4);
                                    }
                                }
                                ++n;
                            }
                        }
                    }
                    catch (JSONException jSONException) {
                        this.logger(2, "openClient()  protocolProperties mal forme : ", (Exception)((Object)jSONException));
                    }
                }
                if (this.USER_AGENT_PROPERTY != null && !this.USER_AGENT_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("User-Agent", this.USER_AGENT_PROPERTY);
                }
                if (this.ACCEPT_LANGUAGE_PROPERTY != null && !this.ACCEPT_LANGUAGE_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("Accept-Language", this.ACCEPT_LANGUAGE_PROPERTY);
                }
                if (this.ACCEPT_ENCODING_PROPERTY != null && !this.ACCEPT_ENCODING_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("Accept-Encoding", this.ACCEPT_ENCODING_PROPERTY);
                }
                if (this.ORIGIN_PROPERTY != null && !this.ORIGIN_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("origin", this.ORIGIN_PROPERTY);
                }
                if (this.COUNTRY_PROPERTY != null && !this.COUNTRY_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("country", this.COUNTRY_PROPERTY);
                }
                if (this.REGION_PROPERTY != null && !this.REGION_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("region", this.REGION_PROPERTY);
                }
                if (this.MESSAGE_PROPERTY != null && !this.MESSAGE_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("message", this.MESSAGE_PROPERTY);
                }
                if (this.MERCHANT_NUMBER_PROPERTY != null && !this.MERCHANT_NUMBER_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("MerchNbr", this.MERCHANT_NUMBER_PROPERTY);
                }
                if (this.RT_IND_PROPERTY != null && !this.RT_IND_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("RtInd", this.RT_IND_PROPERTY);
                }
                if (this.CONTENT_TYPE_PROPERTY != null && !this.CONTENT_TYPE_PROPERTY.isEmpty()) {
                    this.conHttps.setRequestProperty("Content-Type", this.CONTENT_TYPE_PROPERTY);
                } else {
                    object = ((YP_Row)objectArray[0]).getFieldStringValueByName("serviceRequested");
                    if (((String)object).contentEquals("IPN")) {
                        this.conHttps.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    } else {
                        this.conHttps.setRequestProperty("Content-Type", "application/xml");
                    }
                }
                this.conHttps.setConnectTimeout(this.connectionTimeoutMS);
                this.conHttps.connect();
            }
            catch (MalformedURLException malformedURLException) {
                this.logger(2, "openClient() URL Mal formee : " + malformedURLException);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + " " + exception);
            this.ipServer = null;
            this.conHttps = null;
            this.portServer = 0;
            this.ressource = null;
            this.connectionTimeoutMS = 3499;
            this.sslsocketfactory = null;
            this.trustStorePath = null;
            this.trustStorePasswd = null;
            this.keyStorePath = null;
            this.keyStorePasswd = null;
            this.keyAlias = null;
            this.enabledCipherSuites = null;
            this.enabledProtocols = null;
            this.authentificationNeeded = null;
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return -1;
        }
        if (this.getLogLevel() >= 4) {
            this.printSocketInfo(this.conHttps);
        }
        return this.initialize();
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for HTTPS !!!");
        return null;
    }

    private void printServerSocketInfo(SSLServerSocket sSLServerSocket) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printServerSocketInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Server socket class: ");
            stringBuilder.append(sSLServerSocket.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker address = ");
            stringBuilder.append(sSLServerSocket.getInetAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker port = ");
            stringBuilder.append(sSLServerSocket.getLocalPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Need client authentication = ");
            stringBuilder.append(sSLServerSocket.getNeedClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Want client authentication = ");
            stringBuilder.append(sSLServerSocket.getWantClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Use client mode = ");
            stringBuilder.append(sSLServerSocket.getUseClientMode());
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    private void printSocketInfo(HttpsURLConnection httpsURLConnection) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printHttpsConnectionInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Https class: ");
            stringBuilder.append(httpsURLConnection.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(httpsURLConnection.getURL().getHost());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote port = ");
            stringBuilder.append(httpsURLConnection.getURL().getPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Host = ");
            stringBuilder.append(httpsURLConnection.getURL().getHost());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   File = ");
            stringBuilder.append(httpsURLConnection.getURL().getFile());
            stringBuilder.append(UtilsYP.lineSeparator);
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public int setParameter(String string, String string2) {
        if (string != null && string.contentEquals("isTextResponseExpected")) {
            this.isTextResponseExpected = Boolean.parseBoolean(string2);
        }
        return 0;
    }

    public int getLastHTTPResponseCode() {
        return this.lastHTTPResponseCode;
    }

    public String getLastHTTPErrorResponseContent() {
        return this.lastHTTPErrorResponseContent;
    }

    final class SendWithTimeout
    extends Thread {
        private final YP_TCD_PHYS_HTTPS_Network physical;
        private final byte[] bMessage;
        private final int iLength;
        private volatile Exception exception = null;
        private volatile int response = -1;
        private volatile boolean finished = false;

        public SendWithTimeout(YP_TCD_PHYS_HTTPS_Network yP_TCD_PHYS_HTTPS_Network2, byte[] byArray, int n) {
            this.physical = yP_TCD_PHYS_HTTPS_Network2;
            this.bMessage = byArray;
            this.iLength = n;
        }

        @Override
        public void run() {
            try {
                this.response = this.physical.sendInternal(this.bMessage, this.iLength);
            }
            catch (Exception exception) {
                this.exception = exception;
            }
            this.finished = true;
        }
    }
}

