/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_EMV_KEYS
extends YP_Row {
    @PrimaryKey
    public long idEMV_KEYS = 0L;
    public byte[] rid = new byte[10];
    public int index = 0;
    public int exponent = 0;
    public byte[] keyValue = new byte[512];
    public byte[] externalReference = new byte[30];
}

