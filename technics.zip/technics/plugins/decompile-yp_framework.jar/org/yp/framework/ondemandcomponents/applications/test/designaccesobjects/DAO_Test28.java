/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.Bitmap;
import org.yp.utils.enums.EntryModeEnumeration;

public class DAO_Test28
extends YP_Row {
    @PrimaryKey
    public long idTest28 = 0L;
    @Index
    public byte[] test28Array = new byte[12];
    @Index
    public int test28Int = 0;
    @Index
    public long test28Long = 0L;
    @Index
    public float test28Float = 0.0f;
    @Index
    public Timestamp test28Timestamp = new Timestamp(0L);
    @Index
    public Date test28Date = new Date(0L);
    @Index
    public EntryModeEnumeration test28Enumeration;
    @Index
    public Boolean test28Boolean;
    @Index
    public Bitmap test28Bitmap;
}

