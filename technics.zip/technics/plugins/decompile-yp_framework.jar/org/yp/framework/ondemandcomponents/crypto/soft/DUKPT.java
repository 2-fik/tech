/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.soft;

import java.io.FileInputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.spec.AlgorithmParameterSpec;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_MacAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.ypproperties.Property;

public class DUKPT
extends YP_TCD_CRYPTO_Module
implements YP_TCD_CRYPTO_CipherSym_Interface,
YP_TCD_CRYPTO_MacAlgo_Interface {
    private static YP_Object cryptoManager;
    public static final String EMPTY_IV = "0000000000000000";
    public static final byte[] EMPTY_IV_ARRAY;
    public static final String UCUBE_IV = "AABBCCDDEEFF0000";
    public static final int KSN_LENGTH = 20;
    private static final String _1FFFFF = "1FFFFF";
    private static final String _100000 = "100000";
    private static final String _E00000 = "E00000";
    public static final String PINDerivationXOR = "00000000000000FF00000000000000FF";
    public static final String RequestMACDerivationXOR = "000000000000FF00000000000000FF00";
    public static final String ResponseMACDerivationXOR = "00000000FF00000000000000FF000000";
    public static final String RequestDataDerivationXOR = "0000000000FF00000000000000FF0000";
    public static final String ResponseDataDerivationXOR = "000000FF00000000000000FF00000000";

    static {
        EMPTY_IV_ARRAY = new byte[8];
    }

    public DUKPT(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        boolean cfr_ignored_0 = yP_Object instanceof YP_TS_GlobalProcessManager;
    }

    @Override
    public int initialize() {
        cryptoManager = this.getPluginByName("CryptoManager");
        this.myCipherSym = this;
        this.myMAC = this;
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "CryptoSoft_Dukpt";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :" + exception);
            return null;
        }
    }

    @Override
    public String decrypt(String string, String string2, List<Property> list, String string3, String string4, String string5) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "decrypt() is not implemented");
        }
        throw new Exception("decrypt() is not implemented");
    }

    @Override
    public byte[] decryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.decrypt(3, byArray, string, list, string2, string3, null);
    }

    @Override
    public byte[] decrypt(byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        return this.decrypt(1, byArray, string, list, string2, string3, string4);
    }

    public byte[] decrypt(int n, byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        Object object;
        Object object2;
        Object object3;
        Object object4;
        String string5;
        String string6;
        String string7;
        block8: {
            string7 = string3;
            try {
                string6 = this.getBDKFromAlias(string);
                if (string6 != null) break block8;
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "decrypt()" + exception);
                }
                throw exception;
            }
        }
        String string8 = DUKPT.calculateDerivedKey(string7, string6);
        if (n == 3) {
            string5 = DUKPT.xorHexString(string8, PINDerivationXOR);
        } else if (n == 1) {
            object4 = DUKPT.xorHexString(string8, RequestDataDerivationXOR);
            object3 = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(object4) + ((String)object4).substring(0, 16)), "DESede");
            object2 = Cipher.getInstance("DESede/ECB/NoPadding");
            ((Cipher)object2).init(1, (Key)object3);
            object = UtilsYP.redHexa((String)object4);
            byte[] byArray2 = ((Cipher)object2).doFinal((byte[])object, 0, 8);
            byte[] byArray3 = ((Cipher)object2).doFinal((byte[])object, 8, 8);
            string5 = String.valueOf(UtilsYP.devHexa(byArray2)) + UtilsYP.devHexa(byArray3);
        } else {
            throw new Exception("decrypt() unknown mode " + n);
        }
        object4 = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(string5) + string5.substring(0, 16)), "DESede");
        object3 = string4 == null ? EMPTY_IV_ARRAY : UtilsYP.redHexa(string4);
        object2 = new IvParameterSpec((byte[])object3);
        object = Cipher.getInstance("DESede/CBC/NoPadding");
        ((Cipher)object).init(2, (Key)object4, (AlgorithmParameterSpec)object2);
        return ((Cipher)object).doFinal(byArray, 0, byArray.length);
    }

    @Override
    public String decryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "decryptToken() is not possible for DUKPT");
        }
        throw new Exception("decryptToken() is not possible for DUKPT");
    }

    @Override
    public String[] encrypt(String string, String string2, List<Property> list, String string3, String string4) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "encrypt() is not implemented");
        }
        throw new Exception("encrypt() is not implemented");
    }

    @Override
    public byte[][] encrypt(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "encrypt() is not implemented");
        }
        throw new Exception("encrypt() is not implemented");
    }

    @Override
    public String[] encryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "encryptToken() is not possible for DUKPT");
        }
        throw new Exception("encryptToken() is not possible for DUKPT");
    }

    @Override
    public int addKey(String string, List<Property> list, byte[] byArray, String string2) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "addKey() is not implemented");
        }
        throw new Exception("addKey() is not implemented");
    }

    @Override
    public int isCryptoSupported(String string) {
        int n = this.isCipherSymSupported(string);
        if (n >= 1) {
            return n;
        }
        n = this.isMACSupported(string);
        if (n >= 1) {
            return n;
        }
        return 0;
    }

    @Override
    public int isCipherSymSupported(String string) {
        switch (string) {
            case "DUKPT/DATA": 
            case "DUKPT/": {
                return 1;
            }
        }
        return 0;
    }

    @Override
    public String computeMAC(String string, List<Property> list, byte[] byArray, Object ... objectArray) throws Exception {
        String string2;
        String string3;
        String string4;
        block8: {
            if (objectArray == null || objectArray.length < 3 || objectArray[2] == null || !(objectArray[2] instanceof String)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "computeMAC() bad parameters");
                }
                throw new Exception("Bad parameters");
            }
            string4 = (String)objectArray[2];
            if (!string4.contentEquals(RequestMACDerivationXOR) && !string4.contentEquals(ResponseMACDerivationXOR)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "computeMAC() bad XOR parameter");
                }
                throw new Exception("Bad XOR parameter");
            }
            string3 = string;
            try {
                string2 = this.getBDK(string3);
                if (string2 != null) break block8;
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "computeMAC() " + exception);
                }
                throw exception;
            }
        }
        String string5 = DUKPT.calculateDerivedKey(string3, string2);
        String string6 = DUKPT.xorHexString(string5, string4);
        String string7 = DUKPT.retailMac(string6, byArray);
        return string7;
    }

    @Override
    public boolean verifyMAC(String string, List<Property> list, byte[] byArray, String string2, Object ... objectArray) throws Exception {
        String string3;
        block4: {
            try {
                string3 = (String)cryptoManager.dealRequest(null, "computeMAC", string, byArray, objectArray[3]);
                if (string3 != null) break block4;
                return false;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "verifyMAC() " + exception);
                }
                throw exception;
            }
        }
        return string3.contentEquals(string2);
    }

    @Override
    public int isMACSupported(String string) {
        switch (string) {
            case "DUKPT/MAC/REQUEST": 
            case "DUKPT/MAC/RESPONSE": {
                return 1;
            }
        }
        return 0;
    }

    private String getBDK(String string) {
        String string2 = DUKPT.getBDKAlias(string);
        if (string2 == null || string2.isEmpty()) {
            return null;
        }
        return this.getBDKFromAlias(string2);
    }

    private String getBDKFromAlias(String string) {
        KeyStore.SecretKeyEntry secretKeyEntry;
        block13: {
            try {
                KeyStore keyStore = KeyStore.getInstance("JCEKS");
                FileInputStream fileInputStream = new FileInputStream(".\\keystore\\dukpt\\bdkStore");
                keyStore.load(fileInputStream, "slpc1515".toCharArray());
                fileInputStream.close();
                KeyStore.PasswordProtection passwordProtection = new KeyStore.PasswordProtection("slpc1515".toCharArray());
                if (string.contentEquals("THYRON_01_SSM_KK_BDK_TEST")) {
                    string = "THYRON_01_SSM_BDK_TEST";
                }
                if ((secretKeyEntry = (KeyStore.SecretKeyEntry)keyStore.getEntry(string, passwordProtection)) != null) break block13;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getBDKFromAlias() key not found " + string);
                }
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getBDKFromAlias() " + exception);
                }
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder("");
        UtilsYP.devHexa(secretKeyEntry.getSecretKey().getEncoded(), 0, stringBuilder, secretKeyEntry.getSecretKey().getEncoded().length);
        String string2 = stringBuilder.toString();
        if (string2.length() != 32) {
            if (string2.length() == 48) {
                if (string2.startsWith(string2.substring(32))) {
                    string2 = string2.substring(0, 32);
                } else if (this.getLogLevel() >= 2) {
                    this.logger(2, "getBDKFromAlias() BDK part 3 should be equals to part 1");
                }
            } else if (this.getLogLevel() >= 2) {
                this.logger(2, "getBDKFromAlias() Bad BDK length");
            }
        }
        return string2;
    }

    @Deprecated
    public static String decryptData(String string, String string2, int n) {
        try {
            if (n < 0) {
                return DUKPT.decryptData(string, string2);
            }
            return DUKPT.decryptData(string, string2, null, PaddingType.PKCS5Padding).substring(0, n * 2);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    @Deprecated
    public static String decryptData(String string, String string2) {
        return DUKPT.decryptData(string, string2, null, PaddingType.PKCS5Padding);
    }

    public static String decryptData(String string, String string2, String string3, PaddingType paddingType) {
        try {
            byte[] byArray;
            byte[] byArray2 = DUKPT.decryptBuffer(string, string2, string3);
            switch (paddingType) {
                case ISO78164Padding: {
                    byArray = DUKPT.removePadMod78164(byArray2);
                    break;
                }
                case PKCS5Padding: {
                    byArray = DUKPT.removePadModPKCS5(byArray2);
                    break;
                }
                default: {
                    byArray = byArray2;
                }
            }
            return UtilsYP.devHexa(byArray);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String encryptData(String string, byte[] byArray, PaddingType paddingType, String string2) {
        try {
            byte[] byArray2;
            switch (paddingType) {
                case ISO78164Padding: {
                    byArray2 = DUKPT.padMod78164(byArray);
                    break;
                }
                case PKCS5Padding: {
                    byArray2 = DUKPT.padModPKCS5(byArray);
                    break;
                }
                default: {
                    byArray2 = byArray;
                }
            }
            byte[] byArray3 = DUKPT.encryptBuffer(string, byArray2, string2);
            return UtilsYP.devHexa(byArray3);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    @Deprecated
    public static String macResponseData(String string, byte[] byArray) {
        try {
            return DUKPT.macData(string, DUKPT.padModPKCS5(byArray), ResponseMACDerivationXOR);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String macResponseData(String string, byte[] byArray, PaddingType paddingType) {
        try {
            byte[] byArray2;
            switch (paddingType) {
                case ISO78164Padding: {
                    byArray2 = DUKPT.padMod78164(byArray);
                    break;
                }
                case NoPadding: {
                    byArray2 = byArray;
                    break;
                }
                case PKCS5Padding: {
                    byArray2 = DUKPT.padModPKCS5(byArray);
                    break;
                }
                default: {
                    System.out.println("macResponseData() unknown padding !!!");
                    byArray2 = byArray;
                }
            }
            return DUKPT.macData(string, byArray2, ResponseMACDerivationXOR);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    @Deprecated
    public static String macRequestData(String string, byte[] byArray) {
        try {
            return DUKPT.macData(string, DUKPT.padModPKCS5(byArray), RequestMACDerivationXOR);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String macRequestData(String string, byte[] byArray, PaddingType paddingType) {
        try {
            byte[] byArray2;
            switch (paddingType) {
                case ISO78164Padding: {
                    byArray2 = DUKPT.padMod78164(byArray);
                    break;
                }
                case NoPadding: {
                    byArray2 = byArray;
                    break;
                }
                case PKCS5Padding: {
                    byArray2 = DUKPT.padModPKCS5(byArray);
                    break;
                }
                default: {
                    System.out.println("macRequestData() unknown padding !!!");
                    byArray2 = byArray;
                }
            }
            return DUKPT.macData(string, byArray2, RequestMACDerivationXOR);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    @Deprecated
    public static boolean checkRequestDataMaced(String string, byte[] byArray, String string2) {
        String string3;
        block3: {
            try {
                string3 = DUKPT.macRequestData(string, byArray);
                if (string3 != null) break block3;
                return false;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return false;
            }
        }
        return string3.contentEquals(string2);
    }

    public static String getBDKAlias(String string) {
        String string2;
        block19: {
            block17: {
                block16: {
                    try {
                        if (string != null) break block16;
                        return null;
                    }
                    catch (Exception exception) {
                        System.out.println("getBDKAlias() " + exception);
                        return null;
                    }
                }
                if (string.length() == 20) break block17;
                System.out.println("getBDKAlias() incorrect KSN length " + string);
                return null;
            }
            string = string.toUpperCase();
            String string3 = string.substring(0, 4);
            String string4 = string.substring(4, 6);
            String string5 = string.substring(6, 8);
            String string6 = string.substring(8, 10);
            switch (string3) {
                case "2700": {
                    return "BDK_TEST_TYPE_2";
                }
                case "FFFF": {
                    return "THYRON_01_SSM_BDK_TEST";
                }
            }
            StringBuilder stringBuilder = new StringBuilder(20);
            stringBuilder.append(string3);
            stringBuilder.append('_');
            stringBuilder.append(string4);
            stringBuilder.append('_');
            stringBuilder.append(string5);
            stringBuilder.append('_');
            stringBuilder.append(string6);
            stringBuilder.append("_BDK");
            string2 = stringBuilder.toString();
            if (!string2.contentEquals("0001_02_00_01_BDK")) break block19;
            return "BPCE_01_SSM_BDK";
        }
        return string2;
    }

    public static byte[] padModPKCS5(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n = 8 - byArray.length % 8;
        byte[] byArray2 = new byte[byArray.length + n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
        int n2 = 0;
        while (n2 < n) {
            byArray2[byArray.length + n2] = (byte)n;
            ++n2;
        }
        return byArray2;
    }

    public static byte[] padMod78164(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n = 8 - (byArray.length + 1) % 8;
        if (n == 8) {
            n = 0;
        }
        byte[] byArray2 = new byte[byArray.length + 1 + n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
        byArray2[byArray.length] = -128;
        return byArray2;
    }

    private static byte[] padMod1(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n = byArray.length % 8;
        if (n == 0) {
            return byArray;
        }
        n = 8 - n;
        byte[] byArray2 = new byte[byArray.length + n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray.length);
        int n2 = 0;
        while (n2 < n) {
            byArray2[byArray.length + n2] = 0;
            ++n2;
        }
        return byArray2;
    }

    private static byte[] removePadModPKCS5(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n = byArray[byArray.length - 1];
        if (n < 1 || n > 8) {
            System.out.println("removePadModPKCS5() bad padding !!!");
            return byArray;
        }
        int n2 = 1;
        while (n2 <= n) {
            if (byArray[byArray.length - n2] != n) {
                System.out.println("removePadModPKCS5() bad padding !!!");
                return byArray;
            }
            ++n2;
        }
        byte[] byArray2 = new byte[byArray.length - n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray2.length);
        return byArray2;
    }

    private static byte[] removePadMod78164(byte[] byArray) {
        if (byArray == null) {
            return null;
        }
        int n = byArray.length - 1;
        while (n > 0 && byArray[n] == 0) {
            --n;
        }
        if (byArray[n] != -128) {
            System.out.println("removePadMod78164() bad padding !!!");
            return byArray;
        }
        byte[] byArray2 = new byte[n];
        System.arraycopy(byArray, 0, byArray2, 0, byArray2.length);
        return byArray2;
    }

    private static String retailMac(String string, byte[] byArray) {
        byte[] byArray2;
        byte[] byArray3 = new byte[8];
        System.arraycopy(UtilsYP.redHexa(string), 0, byArray3, 0, 8);
        byte[] byArray4 = new byte[8];
        System.arraycopy(UtilsYP.redHexa(string), 8, byArray4, 0, 8);
        byte[] byArray5 = new byte[8];
        System.arraycopy(byArray, 0, byArray5, 0, 8);
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(byArray3, "DES");
            Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
            cipher.init(1, (Key)secretKeySpec, new IvParameterSpec(new byte[8]));
            SecretKeySpec secretKeySpec2 = new SecretKeySpec(byArray4, "DES");
            Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
            cipher2.init(2, (Key)secretKeySpec2, new IvParameterSpec(new byte[8]));
            byArray2 = cipher.doFinal(byArray5);
            byte[] byArray6 = new byte[8];
            int n = 8;
            while (n < byArray.length) {
                System.arraycopy(byArray, n, byArray6, 0, 8);
                int n2 = 0;
                while (n2 < byArray2.length) {
                    byArray2[n2] = (byte)(byArray2[n2] ^ byArray6[n2]);
                    ++n2;
                }
                byArray2 = cipher.doFinal(byArray2);
                n += 8;
            }
            byArray2 = cipher2.doFinal(byArray2);
            byArray2 = cipher.doFinal(byArray2);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
        return UtilsYP.devHexa(byArray2, 0, 8);
    }

    public static String decryptDataUCube(String string, String string2, String string3) {
        try {
            String string4 = DUKPT.calculateDerivedKey(string, string2);
            String string5 = DUKPT.xorHexString(string4, RequestDataDerivationXOR);
            SecretKeySpec secretKeySpec = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(string5) + string5.substring(0, 16)), "DESede");
            Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding");
            cipher.init(1, secretKeySpec);
            byte[] byArray = UtilsYP.redHexa(string5);
            byte[] byArray2 = cipher.doFinal(byArray, 0, 8);
            byte[] byArray3 = cipher.doFinal(byArray, 8, 8);
            String string6 = String.valueOf(UtilsYP.devHexa(byArray2)) + UtilsYP.devHexa(byArray3);
            SecretKeySpec secretKeySpec2 = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(string6) + string6.substring(0, 16)), "DESede");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(UtilsYP.redHexa(UCUBE_IV));
            Cipher cipher2 = Cipher.getInstance("DESede/CBC/NoPadding");
            cipher2.init(2, (Key)secretKeySpec2, ivParameterSpec);
            byte[] byArray4 = UtilsYP.redHexa(string3);
            byte[] byArray5 = cipher2.doFinal(byArray4, 0, byArray4.length);
            return UtilsYP.devHexa(byArray5);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String encryptDataUCube(String string, String string2, byte[] byArray) {
        try {
            String string3 = DUKPT.calculateDerivedKey(string, string2);
            String string4 = DUKPT.xorHexString(string3, RequestDataDerivationXOR);
            SecretKeySpec secretKeySpec = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(string4) + string4.substring(0, 16)), "DESede");
            Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding");
            cipher.init(1, secretKeySpec);
            byte[] byArray2 = UtilsYP.redHexa(string4);
            byte[] byArray3 = cipher.doFinal(byArray2, 0, 8);
            byte[] byArray4 = cipher.doFinal(byArray2, 8, 8);
            String string5 = String.valueOf(UtilsYP.devHexa(byArray3)) + UtilsYP.devHexa(byArray4);
            SecretKeySpec secretKeySpec2 = new SecretKeySpec(UtilsYP.redHexa(String.valueOf(string5) + string5.substring(0, 16)), "DESede");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(UtilsYP.redHexa(UCUBE_IV));
            Cipher cipher2 = Cipher.getInstance("DESede/CBC/NoPadding");
            cipher2.init(1, (Key)secretKeySpec2, ivParameterSpec);
            byte[] byArray5 = cipher2.doFinal(byArray, 0, byArray.length);
            return UtilsYP.devHexa(byArray5);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    private static byte[] decryptBuffer(String string, String string2, String string3) throws Exception {
        return (byte[])cryptoManager.dealRequest(null, "decrypt", string, UtilsYP.redHexa(string2), null, string3);
    }

    private static byte[] encryptBuffer(String string, byte[] byArray, String string2) throws Exception {
        byte[][] byArray2 = (byte[][])cryptoManager.dealRequest(null, "encrypt", string, byArray, string2);
        return byArray2[0];
    }

    private static String macData(String string, byte[] byArray, String string2) throws Exception {
        return (String)cryptoManager.dealRequest(null, "computeMAC", string, byArray, string2);
    }

    private static String calculateDerivedKey(String string, String string2) {
        String string3 = DUKPT.calculateIpek(string.substring(0, 16), string2);
        String string4 = string.substring(4);
        string4 = DUKPT.andHexStringOffset(string4, _E00000, string4.length() - 6);
        String string5 = DUKPT.andHexStringOffset(string.substring(string.length() - 6), _1FFFFF, 0);
        String string6 = _100000;
        while (Integer.parseInt(string6) > 0) {
            String string7 = DUKPT.andHexString(string6, string5);
            if (Integer.parseInt(string7) != 0) {
                string4 = DUKPT.orHexStringOffset(string4, string6, string4.length() - 6);
                String string8 = DUKPT.xorHexString(string4, string3.substring(16, 32));
                string8 = DUKPT.desEncrypt(string3.substring(0, 16), string8);
                string8 = DUKPT.xorHexString(string8, string3.substring(16, 32));
                string3 = DUKPT.xorHexString(string3, "C0C0C0C000000000C0C0C0C000000000");
                String string9 = DUKPT.xorHexString(string3.substring(16, 32), string4);
                string9 = DUKPT.desEncrypt(string3.substring(0, 16), string9);
                string9 = DUKPT.xorHexString(string9, string3.substring(16, 32));
                string3 = String.valueOf(string9) + string8;
            }
            string6 = DUKPT.shiftRightHexString(string6);
        }
        return string3;
    }

    private static String calculateIpek(String string, String string2) {
        String string3 = DUKPT.tripleDesEncrypt(string2, string);
        String string4 = DUKPT.xorHexString(string2, "C0C0C0C000000000C0C0C0C000000000");
        string3 = String.valueOf(string3) + DUKPT.tripleDesEncrypt(string4, string);
        return string3;
    }

    private static String andHexString(String string, String string2) {
        return DUKPT.andHexStringOffset(string, string2, 0);
    }

    private static String andHexStringOffset(String string, String string2, int n) {
        try {
            String string3 = string;
            if (string.length() % 2 == 1) {
                string3 = "0" + string;
            }
            byte[] byArray = UtilsYP.redHexa(string3);
            String string4 = string2;
            if (string2.length() % 2 == 1) {
                string4 = String.valueOf(string2) + "F";
            }
            byte[] byArray2 = UtilsYP.redHexa(string4);
            int n2 = n / 2;
            int n3 = n2 + byArray2.length;
            int n4 = n2;
            while (n4 < byArray.length && n4 < n3) {
                byte by = byArray[n4];
                byte by2 = byArray2[n4 - n2];
                byArray[n4] = (byte)(by & by2);
                ++n4;
            }
            n4 = string.length();
            String string5 = UtilsYP.devHexa(byArray);
            return string5.substring(string5.length() - n4);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private static String desEncrypt(String string, String string2) {
        try {
            byte[] byArray = UtilsYP.redHexa(string);
            byte[] byArray2 = new byte[8];
            IvParameterSpec ivParameterSpec = new IvParameterSpec(byArray2);
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = SecretKeyFactory.getInstance("DES").generateSecret(dESKeySpec);
            Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
            cipher.init(1, (Key)secretKey, ivParameterSpec);
            byte[] byArray3 = cipher.doFinal(UtilsYP.redHexa(string2));
            return UtilsYP.devHexa(byArray3);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private static String orHexStringOffset(String string, String string2, int n) {
        try {
            if (string2.length() % 2 == 1) {
                string2 = "0" + string2;
            }
            byte[] byArray = UtilsYP.redHexa(string);
            byte[] byArray2 = UtilsYP.redHexa(string2);
            int n2 = n / 2;
            int n3 = n2 + byArray2.length;
            int n4 = n2;
            while (n4 < byArray.length && n4 < n3) {
                byte by = byArray[n4];
                byte by2 = byArray2[n4 - n2];
                byArray[n4] = (byte)(by | by2);
                ++n4;
            }
            return UtilsYP.devHexa(byArray);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private static String padLeft(String string, int n, char c) {
        int n2 = n - string.length();
        String string2 = string;
        int n3 = 0;
        while (n3 < n2) {
            string2 = String.valueOf(c) + string2;
            ++n3;
        }
        return string2;
    }

    private static String shiftRightHexString(String string) {
        long l = Long.parseLong(string, 16);
        String string2 = Long.toString(l >>= 1, 16);
        return DUKPT.padLeft(string2, string.length(), '0');
    }

    private static String tripleDesEncrypt(String string, String string2) {
        try {
            byte[] byArray = UtilsYP.redHexa(string);
            byte[] byArray2 = new byte[24];
            System.arraycopy(byArray, 0, byArray2, 0, 16);
            System.arraycopy(byArray, 0, byArray2, 16, 8);
            DESedeKeySpec dESedeKeySpec = new DESedeKeySpec(byArray2);
            SecretKey secretKey = SecretKeyFactory.getInstance("DESede").generateSecret(dESedeKeySpec);
            Cipher cipher = Cipher.getInstance("DESede/ECB/NoPadding");
            cipher.init(1, secretKey);
            byte[] byArray3 = cipher.doFinal(UtilsYP.redHexa(string2));
            return UtilsYP.devHexa(byArray3);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private static String xorHexString(String string, String string2) {
        try {
            byte[] byArray = UtilsYP.redHexa(string);
            byte[] byArray2 = UtilsYP.redHexa(string2);
            int n = 0;
            while (n < byArray.length) {
                byArray[n] = (byte)(byArray[n] ^ byArray2[n]);
                ++n;
            }
            return UtilsYP.devHexa(byArray);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public byte[] translatePIN(byte[] byArray, String string, String string2, String string3, List<Property> list, String string4, String string5, String string6, String string7, List<Property> list2, String string8, String string9) throws Exception {
        throw new Exception("translatePIN() Not done");
    }

    @Override
    public byte[] exportKey(String string, List<Property> list, String string2, List<Property> list2) {
        this.logger(2, "exportKey() Not done");
        return null;
    }

    @Override
    public byte[] importKey(String string, String string2, List<Property> list) {
        this.logger(2, "importKey() Not done");
        return null;
    }

    @Override
    public byte[][] encryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        throw new Exception("encryptPIN() Not done");
    }

    public static enum PaddingType {
        NoPadding,
        PKCS5Padding,
        ISO78164Padding;

    }
}

