/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.productlist;

import java.lang.reflect.Field;
import java.util.List;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.designaccessobjects.DAO_ProductList;
import org.yp.utils.ByteBuilder;

public class YP_TCD_DCB_STD_ProductList
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_ProductList {
    private YP_TCD_DCC_Business dataContainer;
    private YP_TCD_DesignAccesObject productList;
    private long cksproductList = -1L;

    public YP_TCD_DCB_STD_ProductList(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    private long getCKS(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        Object object2;
        ByteBuilder byteBuilder = new ByteBuilder();
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        for (Object object2 : yP_TCD_DesignAccesObject) {
            ((YP_Row)object2).serialize(byteBuilder, fieldArray);
        }
        if (byteBuilder.size() == 0) {
            return 0L;
        }
        object2 = new CRC32();
        object2.update(byteBuilder.data(), 0, byteBuilder.size());
        long l = object2.getValue();
        return l;
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.productList = this.dataContainer.getDesignAccesObject_ByName("ProductList");
            if (this.productList == null) {
                this.productList = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_ProductList.class, 0, 0, null);
            }
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.productList) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() productList");
            }
            this.cksproductList = -1L;
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.productList) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() productList");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.productList != null && clazz == this.productList.getRowClass()) {
            this.cksproductList = -1L;
        }
        return 0;
    }

    @Override
    public YP_TCD_DesignAccesObject getProductListTable() {
        return this.productList;
    }

    @Override
    public long getProductListTableChecksum() {
        if (this.cksproductList == -1L) {
            try {
                this.lock();
                if (this.cksproductList == -1L) {
                    this.cksproductList = this.getCKS(this.productList);
                }
            }
            finally {
                this.unlock();
            }
        }
        return this.cksproductList;
    }

    @Override
    public List<YP_Row> getProductListByAID(String string) {
        if (string == null || string.isEmpty()) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.productList);
        yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.toUpperCase());
        List<YP_Row> list = this.productList.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(2, "getProductListByAID() not found :" + string);
            return null;
        }
        return list;
    }

    @Override
    public List<YP_Row> getProductListByBIN(String string) {
        if (string == null || string.isEmpty()) {
            return null;
        }
        return null;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionProductList";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public boolean isProductListSupported() {
        return this.productList != null && this.productList.size() > 0;
    }
}

