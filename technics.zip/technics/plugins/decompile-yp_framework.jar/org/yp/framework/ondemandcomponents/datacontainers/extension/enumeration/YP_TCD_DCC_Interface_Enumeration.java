/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration;

import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCC_Interface_Enumeration
extends YP_TCD_DCB_Interface_Extension {
    public List<Long> getIdLabelList(long var1);

    public long getIdLabel(long var1, String var3);

    public long getIdLabel(Enum<?> var1);
}

