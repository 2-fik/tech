/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects.DAO_Enumeration;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects.DAO_InternationalizationLabel;

public class DAO_EnumerationValues
extends YP_Row {
    @PrimaryKey
    public long idEnumerationValues = 0L;
    @ForeignKey(name=DAO_Enumeration.class)
    public long idEnumeration = 0L;
    public byte[] enumerationValues = new byte[32];
    @ForeignKey(name=DAO_InternationalizationLabel.class)
    public long idLabel = 0L;
}

