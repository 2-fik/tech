/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.EntryModeEnumeration;

public class DAO_EMV_AID_Parameters
extends YP_Row {
    @PrimaryKey
    public long idEMV_AID_Parameters = 0L;
    public byte[] rid = new byte[10];
    public byte[] pix = new byte[22];
    public EntryModeEnumeration entryMode;
    public byte[] tacDenial = new byte[10];
    public byte[] tacOnline = new byte[10];
    public byte[] tacDefault = new byte[10];
    public byte[] defaultDDOL = new byte[512];
    public byte[] defaultPDOL = new byte[512];
    public byte[] defaultTDOL = new byte[512];
    public int currencyNumericalCode = 0;
    public long thresholdCall = 0L;
    public int randomCallCoefficient = 0;
    public int randomCallMaximumCoefficient = 0;
    public byte[] specificData = new byte[512];
    public byte[] externalReference = new byte[30];
}

