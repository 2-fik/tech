/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.cbcom;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;

public class YP_TCD_PROT_Cbcom
extends YP_OnDemandComponent
implements YP_PROT_Interface_Com {
    private YP_PHYS_Interface physicalInterface;
    private int physicalInterfaceToShutdown = 0;
    private YP_Row connectionRow;
    private boolean noTimerInIPDUCN = false;
    private static final int DEFAULT_TNR = 30;
    private static final int DEFAULT_TSI = 900;
    private static final int DEFAULT_TMA = 900;
    private static final byte PI_01 = 1;
    private static final byte PI_04 = 4;
    private static final byte PI_05 = 5;
    private static final byte PI_06 = 6;
    private static final byte PI_07 = 7;
    private static final byte PI_08 = 8;
    private static final byte PI_15 = 15;
    private static final byte PI_16 = 16;
    private static final byte PI_17 = 17;
    private static final byte PI_18 = 18;
    private static final byte PI_25 = 25;
    private Set<?> allowedPI05ProtocolIdentifier;
    private PI01CBComEnumeration PI01_CodeReponseToSend;
    private PI01CBComEnumeration PI01_CodeReponseReceived;
    private byte[] PI04_PseudoSessionID;
    private byte[] PI05_ProtocolIdentifier = null;
    private byte[] PI06_MaxLength;
    private int PI07_DataLength;
    private boolean PI08_isAscii = true;
    private byte[] PI15_GlobalDataLength;
    private int PI16_TNR;
    private int PI17_TSI;
    private int PI18_TMA;
    private int TGR;
    private int TSM;
    private byte[] PI25;
    private byte[] ipduBuffer = new byte[10000];
    private byte[] ApduBuffer;
    private byte[] tempoBuffer;
    private IMessageType myMessageType;
    private boolean isIpduLengthPrefixed = true;
    private ReceiverTransmitterMode myMode = null;
    private YP_PROT_Interface_Com.ComStateMachine myState;
    private boolean timeoutOccured = false;
    private String timerName = null;
    private long timeoutTime = 0L;

    public YP_TCD_PROT_Cbcom(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PHYS_Interface) {
            this.physicalInterface = (YP_PHYS_Interface)objectArray[0];
        }
    }

    @Override
    public int setParameters(Object ... objectArray) {
        try {
            byte[] byArray = null;
            if (objectArray != null && objectArray.length == 7) {
                int n = (Integer)objectArray[0];
                int n2 = (Integer)objectArray[1];
                this.allowedPI05ProtocolIdentifier = (Set)objectArray[2];
                String string = (String)objectArray[3];
                if (string != null) {
                    byArray = new byte[string.length() / 2];
                    UtilsYP.redHexa(byArray, string, string.length() / 2);
                }
                int n3 = (Integer)objectArray[4];
                int n4 = (Integer)objectArray[5];
                int n5 = (Integer)objectArray[6];
                this.noTimerInIPDUCN = n3 == 0 && n4 == 0 && n5 == 0;
                int n6 = n3 / 1000;
                int n7 = n4 / 1000;
                int n8 = n5 / 1000;
                if (n == 4) {
                    this.isIpduLengthPrefixed = true;
                } else if (n == 0) {
                    this.isIpduLengthPrefixed = false;
                } else {
                    this.logger(2, "setParameters() Bad value for length prefix :" + n);
                }
                if (n2 == 1) {
                    this.PI08_isAscii = true;
                } else if (n2 == 0) {
                    this.PI08_isAscii = false;
                } else {
                    this.logger(2, "setParameters() Bad value for isASCII :" + n2);
                }
                if (this.allowedPI05ProtocolIdentifier != null && this.allowedPI05ProtocolIdentifier.size() == 1) {
                    this.PI05_ProtocolIdentifier = new byte[4];
                    Iterator<?> iterator = this.allowedPI05ProtocolIdentifier.iterator();
                    UtilsYP.redHexa(this.PI05_ProtocolIdentifier, (String)iterator.next(), 4);
                    if (this.PI05_ProtocolIdentifier[0] != 16 && this.PI05_ProtocolIdentifier[0] != 17 && this.PI05_ProtocolIdentifier[0] != 18) {
                        this.PI08_isAscii = true;
                        if (byArray != null) {
                            this.PI25 = new byte[byArray.length];
                            System.arraycopy(byArray, 0, this.PI25, 0, byArray.length);
                        }
                    } else if (byArray != null && byArray.length == 15) {
                        System.arraycopy(this.PI04_PseudoSessionID, 0, byArray, 0, 15);
                    }
                }
                this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
                this.TGR = -1;
                this.TSM = -1;
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_OK;
                this.PI16_TNR = n6 <= 0 ? 30 : (n6 < 5 ? 5 : (n6 > 50 ? 50 : n6));
                this.PI17_TSI = n7 <= 0 ? 900 : (n7 < 30 || n7 > 1800 ? 900 : n7);
                this.PI18_TMA = n8 <= 0 ? 900 : (n8 < 300 || n8 > 1800 ? 900 : n8);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setParameters() " + exception);
            return -1;
        }
    }

    private boolean isTimeoutOccured() {
        if (this.timeoutTime != 0L && System.currentTimeMillis() > this.timeoutTime) {
            if (this.timerName.compareTo("TNR") == 0) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TNR;
            }
            if (this.timerName.compareTo("TSI") == 0) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TSI;
            }
            if (this.timerName.compareTo("TGR") == 0) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TGR;
            }
            System.out.println("Time's up!: " + this.timerName);
            this.timeoutOccured = true;
        }
        return this.timeoutOccured;
    }

    private void resetTimer() {
        this.timeoutOccured = false;
        this.timerName = null;
        this.timeoutTime = 0L;
    }

    private void setTimer(String string) {
        this.timeoutOccured = false;
        this.timerName = string;
        this.timeoutTime = 0L;
        if (string.compareTo("TNR") == 0) {
            if (this.PI16_TNR == -1) {
                return;
            }
            this.timeoutTime = System.currentTimeMillis() + (long)(this.PI16_TNR * 1000);
        }
        if (string.compareTo("TSI") == 0) {
            if (this.PI17_TSI == -1) {
                return;
            }
            this.timeoutTime = System.currentTimeMillis() + (long)(this.PI17_TSI * 1000);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "setTimer TSI " + this.PI17_TSI);
            }
        }
        if (string.compareTo("TGR") == 0) {
            if (this.TGR == -1) {
                return;
            }
            this.timeoutTime = System.currentTimeMillis() + (long)(this.TGR * 1000);
        }
    }

    private byte[] ipduCode(IMessageType iMessageType, byte[] byArray, boolean bl) {
        int n = 0;
        int n2 = 0;
        n = this.isIpduLengthPrefixed ? (n += 6) : (n += 2);
        switch (iMessageType) {
            case IPDU_DE: {
                if (!bl) {
                    n2 += 3;
                }
                int n3 = byArray.length <= 255 ? 1 : (byArray.length <= 65535 ? 2 : (byArray.length <= 0xFFFFFF ? 3 : 4));
                n += (n2 += 2 + n3) + byArray.length;
                break;
            }
            case IPDU_CN: {
                if (this.PI05_ProtocolIdentifier[0] == 17 || this.PI05_ProtocolIdentifier[0] == 18) {
                    if (this.PI04_PseudoSessionID != null && this.PI04_PseudoSessionID.length > 0) {
                        n2 += 2 + this.PI04_PseudoSessionID.length;
                    }
                } else if (this.PI25 != null && this.PI25.length > 0) {
                    n2 += 2 + this.PI25.length;
                }
                n2 += 2 + this.PI05_ProtocolIdentifier.length;
                if (this.PI05_ProtocolIdentifier[0] == 17 || this.PI05_ProtocolIdentifier[0] == 18) {
                    n2 += 3;
                }
                if (!this.noTimerInIPDUCN) {
                    if (this.PI16_TNR > 0) {
                        n2 += 4;
                    }
                    if (this.PI17_TSI > 0) {
                        n2 += 4;
                    }
                }
                n += n2;
                break;
            }
            case IPDU_AC: {
                n2 += 3;
                if (this.PI06_MaxLength != null && this.PI06_MaxLength.length != 0) {
                    n2 += 2 + this.PI06_MaxLength.length;
                }
                n += n2;
                break;
            }
            case IPDU_AB: {
                n += (n2 += 3);
            }
        }
        byte[] byArray2 = new byte[n];
        int n4 = this.isIpduLengthPrefixed ? 4 : 0;
        switch (iMessageType) {
            case IPDU_DE: {
                byArray2[n4++] = IMessageType.IPDU_DE.getCommand();
                byArray2[n4++] = (byte)n2;
                if (!bl) {
                    byArray2[n4++] = 1;
                    byArray2[n4++] = 1;
                    byArray2[n4++] = this.PI01_CodeReponseToSend.getValue();
                }
                byArray2[n4++] = 7;
                byte by = 0;
                int n5 = n4++;
                boolean bl2 = true;
                int n6 = 3;
                while (n6 >= 0) {
                    byte by2 = (byte)(byArray.length >>> 8 * n6 & 0xFF);
                    if (by2 != 0) {
                        bl2 = false;
                        byArray2[n4++] = by2;
                        by = (byte)(by + 1);
                    } else if (!bl2) {
                        byArray2[n4++] = by2;
                        by = (byte)(by + 1);
                    }
                    --n6;
                }
                byArray2[n5] = by;
                n6 = 0;
                while (n6 < byArray.length) {
                    byArray2[n4++] = byArray[n6];
                    ++n6;
                }
                break;
            }
            case IPDU_CN: {
                byArray2[n4++] = IMessageType.IPDU_CN.myValue;
                byArray2[n4++] = (byte)n2;
                if ((this.PI05_ProtocolIdentifier[0] == 17 || this.PI05_ProtocolIdentifier[0] == 18) && this.PI04_PseudoSessionID != null && this.PI04_PseudoSessionID.length > 0) {
                    byArray2[n4++] = 4;
                    byArray2[n4++] = (byte)this.PI04_PseudoSessionID.length;
                    System.arraycopy(byArray2, n4, this.PI04_PseudoSessionID, 0, this.PI04_PseudoSessionID.length);
                    n4 += this.PI04_PseudoSessionID.length;
                }
                byArray2[n4++] = 5;
                byArray2[n4++] = (byte)this.PI05_ProtocolIdentifier.length;
                int n7 = 0;
                while (n7 < this.PI05_ProtocolIdentifier.length) {
                    byArray2[n4++] = this.PI05_ProtocolIdentifier[n7];
                    ++n7;
                }
                if (this.PI05_ProtocolIdentifier[0] == 17 || this.PI05_ProtocolIdentifier[0] == 18) {
                    byArray2[n4++] = 8;
                    byArray2[n4++] = 1;
                    byArray2[n4++] = this.PI08_isAscii ? 1 : 2;
                }
                if (!this.noTimerInIPDUCN) {
                    if (this.PI16_TNR > 0) {
                        byArray2[n4++] = 16;
                        byArray2[n4++] = 2;
                        byArray2[n4++] = (byte)(this.PI16_TNR >> 8);
                        byArray2[n4++] = (byte)this.PI16_TNR;
                    }
                    if (this.PI17_TSI > 0) {
                        byArray2[n4++] = 17;
                        byArray2[n4++] = 2;
                        byArray2[n4++] = (byte)(this.PI17_TSI >> 8);
                        byArray2[n4++] = (byte)this.PI17_TSI;
                    }
                }
                if (this.PI05_ProtocolIdentifier[0] == 17 || this.PI05_ProtocolIdentifier[0] == 18 || this.PI25 == null || this.PI25.length <= 0) break;
                byArray2[n4++] = 25;
                byArray2[n4++] = (byte)this.PI25.length;
                System.arraycopy(this.PI25, 0, byArray2, n4, this.PI25.length);
                n4 += this.PI25.length;
                break;
            }
            case IPDU_AC: {
                byArray2[n4++] = IMessageType.IPDU_AC.myValue;
                byArray2[n4++] = (byte)n2;
                byArray2[n4++] = 1;
                byArray2[n4++] = 1;
                byArray2[n4++] = this.PI01_CodeReponseToSend.getValue();
                if (this.PI06_MaxLength == null || this.PI06_MaxLength.length == 0) break;
                byArray2[n4++] = 6;
                byArray2[n4++] = (byte)this.PI06_MaxLength.length;
                System.arraycopy(byArray2, n4, this.PI06_MaxLength, 0, this.PI06_MaxLength.length);
                n4 += this.PI06_MaxLength.length;
                break;
            }
            case IPDU_AB: {
                byArray2[n4++] = IMessageType.IPDU_AB.myValue;
                byArray2[n4++] = (byte)n2;
                byArray2[n4++] = 1;
                byArray2[n4++] = 1;
                byArray2[n4++] = this.PI01_CodeReponseToSend.getValue() == PI01CBComEnumeration.PI01_OK.getValue() ? PI01CBComEnumeration.PI01_NormalEnding.getValue() : this.PI01_CodeReponseToSend.getValue();
            }
        }
        if (this.isIpduLengthPrefixed) {
            byArray2[0] = (byte)(n - 4 >> 24 & 0xFF);
            byArray2[1] = (byte)(n - 4 >> 16 & 0xFF);
            byArray2[2] = (byte)(n - 4 >> 8 & 0xFF);
            byArray2[3] = (byte)(n - 4 & 0xFF);
        }
        return byArray2;
    }

    private boolean checkPI05Value(byte[] byArray) {
        if (byArray == null) {
            return false;
        }
        Iterator<?> iterator = this.allowedPI05ProtocolIdentifier.iterator();
        while (iterator.hasNext()) {
            if (this.PI05_ProtocolIdentifier == null) {
                this.PI05_ProtocolIdentifier = new byte[4];
            }
            UtilsYP.redHexa(this.PI05_ProtocolIdentifier, (String)iterator.next(), 4);
            if (!Arrays.equals(this.PI05_ProtocolIdentifier, byArray)) continue;
            return true;
        }
        return false;
    }

    private boolean checkIpdu(byte[] byArray, int n, int n2, IMessageType iMessageType, boolean bl) {
        int n3 = n;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_OK;
        block19: while (n3 < n + n2) {
            byte by = byArray[n3++];
            switch (by) {
                case 1: {
                    int n4 = byArray[n3++];
                    if (n4 != 1) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI01 incorrect");
                        return false;
                    }
                    this.PI01_CodeReponseReceived = PI01CBComEnumeration.getPI01Value(byArray[n3++]);
                    if (this.PI01_CodeReponseReceived == null) {
                        this.logger(2, "checkIpdu() PI01 unknown value");
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_23;
                    } else if (this.PI01_CodeReponseReceived != PI01CBComEnumeration.PI01_OK && this.PI01_CodeReponseReceived != PI01CBComEnumeration.PI01_NormalEnding) {
                        this.logger(2, "checkIpdu() PIO1 received : " + (Object)((Object)this.PI01_CodeReponseReceived) + " -> we do nothing on CBCOM level. PI received : " + UtilsYP.devHexa(byArray, n, n2));
                    }
                    bl2 = true;
                    break;
                }
                case 4: {
                    byte[] byArray2;
                    int n4 = byArray[n3++];
                    if (n4 != 15) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI04 incorrect");
                        return false;
                    }
                    if (this.PI04_PseudoSessionID == null) {
                        this.PI04_PseudoSessionID = Arrays.copyOfRange(byArray, n3, n3 + n4);
                    } else {
                        byArray2 = Arrays.copyOfRange(byArray, n3, n3 + n4);
                        if (!Arrays.equals(this.PI04_PseudoSessionID, byArray2)) {
                            this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_IncorrectValue;
                            this.logger(2, "checkIpdu() ID Session changed");
                            return false;
                        }
                    }
                    n3 += n4;
                    break;
                }
                case 5: {
                    int n4 = byArray[n3++];
                    if (n4 != 4) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI05 incorrect");
                        return false;
                    }
                    byte[] byArray2 = Arrays.copyOfRange(byArray, n3, n3 + n4);
                    if (!this.checkPI05Value(byArray2)) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolVersionIncorrect;
                        this.logger(2, "checkIpdu() PGI changed");
                        return false;
                    }
                    n3 += n4;
                    bl3 = true;
                    break;
                }
                case 6: {
                    int n4 = byArray[n3++];
                    if (n4 > 10) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI06 incorrect");
                        return false;
                    }
                    this.PI06_MaxLength = new byte[n4];
                    int n5 = 0;
                    while (n5 < n4) {
                        this.PI06_MaxLength[n5] = byArray[n3++];
                        ++n5;
                    }
                    continue block19;
                }
                case 7: {
                    int n4 = byArray[n3++];
                    if (n4 > 10) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI07 incorrect");
                        return false;
                    }
                    this.PI07_DataLength = 0;
                    int n5 = 0;
                    while (n5 < n4) {
                        this.PI07_DataLength <<= 8;
                        this.PI07_DataLength |= byArray[n3++] & 0xFF;
                        ++n5;
                    }
                    bl4 = true;
                    break;
                }
                case 8: {
                    int n4 = byArray[n3++];
                    if (n4 != 1) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() PI08 incorrect");
                        return false;
                    }
                    if (byArray[n3++] == 1 && !this.PI08_isAscii) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ABUnsupported;
                        this.logger(2, "checkIpdu() CBCOM configure en EBCDIC et ASCII recu");
                        return false;
                    }
                    if (byArray[n3] == 2 && this.PI08_isAscii) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ABUnsupported;
                        this.logger(2, "checkIpdu() CBCOM configure en ASCII et EBCDIC recu");
                        return false;
                    }
                    bl5 = true;
                    break;
                }
                case 15: {
                    int n4 = byArray[n3++];
                    if (n4 > 10) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() La longueur du PI15 est forcement inferieur a 10");
                        return false;
                    }
                    if (iMessageType == IMessageType.IPDU_CN) {
                        this.PI15_GlobalDataLength = Arrays.copyOfRange(byArray, n3, n3 + n4);
                    }
                    n3 += n4;
                    break;
                }
                case 16: {
                    int n6;
                    byte[] byArray2;
                    int n4 = byArray[n3++];
                    if (n4 != 2) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() La longueur du PI016 est forcement de 2");
                        return false;
                    }
                    if ((n6 = (0xFF & (byArray2 = new byte[]{byArray[n3++], byArray[n3++]})[0]) << 8 | 0xFF & byArray2[1]) < 15 || n6 > 50) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TNRTooSmall;
                        this.logger(2, "checkIpdu() Timer hors limite");
                        return false;
                    }
                    this.PI16_TNR = n6;
                    this.TGR = this.PI16_TNR + 20;
                    break;
                }
                case 17: {
                    int n6;
                    byte[] byArray2;
                    int n4 = byArray[n3++];
                    if (n4 != 2) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() La longueur du PI017 est forcement de 2");
                        return false;
                    }
                    if ((n6 = (0xFF & (byArray2 = new byte[]{byArray[n3++], byArray[n3++]})[0]) << 8 | 0xFF & byArray2[1]) < 30 || n6 > 1800) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TSITooSmall;
                        this.logger(2, "checkIpdu() Timer hors limite");
                        return false;
                    }
                    this.PI17_TSI = n6;
                    break;
                }
                case 18: {
                    int n6;
                    byte[] byArray2;
                    int n4 = byArray[n3++];
                    if (n4 != 2) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() La longueur du PI018 est forcement de 2");
                        return false;
                    }
                    if ((n6 = (0xFF & (byArray2 = new byte[]{byArray[n3++], byArray[n3++]})[0]) << 8 | 0xFF & byArray2[1]) < 300 || n6 > 1800) {
                        this.logger(2, "checkIpdu() Timer hors limite");
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_TMATooSmall;
                        return false;
                    }
                    this.PI18_TMA = n6;
                    this.TSM = this.PI18_TMA + 15;
                    break;
                }
                case 25: {
                    byte[] byArray2;
                    int n4 = byArray[n3++];
                    if (n4 > 40) {
                        this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_26;
                        this.logger(2, "checkIpdu() La longueur du PI_25 est forcement inferieur a 40");
                        return false;
                    }
                    if (this.PI25 == null) {
                        this.PI25 = Arrays.copyOfRange(byArray, n3, n3 + n4);
                    } else {
                        byArray2 = Arrays.copyOfRange(byArray, n3, n3 + n4);
                        if (!Arrays.equals(this.PI25, byArray2)) {
                            this.logger(2, "checkIpdu() PI_25 ne devrait pas changer");
                            return false;
                        }
                    }
                    n3 += n4;
                }
            }
        }
        switch (iMessageType) {
            case IPDU_CN: {
                if (!bl3) {
                    this.logger(2, "checkIpdu() Mandatory data missing PI_05");
                    return false;
                }
                if (this.PI05_ProtocolIdentifier[0] != 17 && this.PI05_ProtocolIdentifier[0] != 18 || bl5) break;
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PIMissing;
                this.logger(2, "checkIpdu() Mandatory data missing PI_01");
                return false;
            }
            case IPDU_DE: {
                if (!bl2 && !bl) {
                    this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PIMissing;
                    this.logger(3, "checkIpdu() Mandatory data missing PI_01, may be a notification request");
                }
                if (bl4) break;
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PIMissing;
                this.logger(2, "checkIpdu() Mandatory data missing PI_07");
                return false;
            }
            case IPDU_AC: {
                if (bl2) break;
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PIMissing;
                this.logger(2, "checkIpdu() Mandatory data missing PI_01");
                return false;
            }
            case IPDU_AB: {
                if (bl2) break;
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PIMissing;
                this.logger(2, "checkIpdu() Mandatory data missing PI_01");
                return false;
            }
        }
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private int ipduDecode(byte[] var1_1, int var2_2, boolean var3_3) {
        block26: {
            var4_4 = 0;
            if (var2_2 < 2) {
                this.logger(3, "ipduDecode() trame incomplete IpduLength < 2 " + var2_2);
                return 0;
            }
            if (!this.isIpduLengthPrefixed) break block26;
            var5_5 = 0;
            if (var1_1[var4_4] == 0) ** GOTO lbl14
            this.logger(2, "ipduDecode() size too big !!!");
            return -1;
lbl-1000:
            // 1 sources

            {
                var5_5 |= (var1_1[var4_4] & 255) << (3 - var4_4) * 8;
                ++var4_4;
lbl14:
                // 2 sources

                ** while (var4_4 < 4)
            }
lbl15:
            // 1 sources

            if (var5_5 < 0 && (var1_1[0] & 255) == 194) {
                this.isIpduLengthPrefixed = false;
                var4_4 = 0;
            } else if (var5_5 > var2_2 - 4) {
                this.logger(3, "ipduDecode() trame incomplete :" + var5_5 + " vs " + (var2_2 - 4));
                return 0;
            }
        }
        if (IMessageType.access$4(IMessageType.IPDU_AC, var5_5 = var1_1[var4_4++])) {
            this.myMessageType = IMessageType.IPDU_AC;
        } else if (IMessageType.access$4(IMessageType.IPDU_AB, var5_5)) {
            this.myMessageType = IMessageType.IPDU_AB;
            if (this.myState != YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolError;
            } else if (this.myMode == ReceiverTransmitterMode.TransmitMode) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolError;
            } else {
                this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
            }
        } else if (IMessageType.access$4(IMessageType.IPDU_DE, var5_5)) {
            if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED || this.myState == YP_PROT_Interface_Com.ComStateMachine.WAIT_CONNECTION || this.myState == YP_PROT_Interface_Com.ComStateMachine.CONNECT) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolError;
            }
            this.myMessageType = IMessageType.IPDU_DE;
        } else if (IMessageType.access$4(IMessageType.IPDU_CN, var5_5)) {
            if (this.myState != YP_PROT_Interface_Com.ComStateMachine.WAIT_CONNECTION) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolError;
            }
            if (this.myMode != ReceiverTransmitterMode.ReceiveMode) {
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_ProtocolError;
            }
            this.myMessageType = IMessageType.IPDU_CN;
        } else {
            this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_PGIKO;
            this.logger(2, "ipduDecode() code inconnu");
            this.ApduBuffer = null;
            return -1;
        }
        var6_6 = var1_1[var4_4++];
        if (!this.checkIpdu(var1_1, var4_4, var6_6, this.myMessageType, var3_3)) {
            this.logger(2, "ipduDecode() YP_CheckIpdu");
            this.ApduBuffer = null;
            return -1;
        }
        if (!IMessageType.access$4(IMessageType.IPDU_DE, var5_5)) {
            this.ApduBuffer = null;
            return 1;
        }
        var4_4 += var6_6;
        var7_7 = this.isIpduLengthPrefixed != false ? var2_2 - (4 + var6_6 + 1 + 1) : var2_2 - (var6_6 + 1 + 1);
        if (var7_7 == this.PI07_DataLength) {
            this.ApduBuffer = new byte[this.PI07_DataLength];
            System.arraycopy(var1_1, var4_4, this.ApduBuffer, 0, this.PI07_DataLength);
            return 1;
        }
        if (var7_7 > this.PI07_DataLength) {
            this.ApduBuffer = new byte[this.PI07_DataLength];
            System.arraycopy(var1_1, var4_4, this.ApduBuffer, 0, this.PI07_DataLength);
            if (this.isIpduLengthPrefixed && (255 & var1_1[var4_4 + this.PI07_DataLength]) == 193) {
                this.tempoBuffer = new byte[4 + var7_7 - this.PI07_DataLength];
                var8_8 = var7_7 - this.PI07_DataLength;
                this.tempoBuffer[0] = (byte)(255 & (byte)(var8_8 / 0x1000000));
                this.tempoBuffer[1] = (byte)(255 & (byte)(var8_8 / 65536));
                this.tempoBuffer[2] = (byte)(255 & (byte)(var8_8 / 256));
                this.tempoBuffer[3] = (byte)(255 & (byte)(var8_8 % 256));
                System.arraycopy(var1_1, var4_4 + this.PI07_DataLength, this.tempoBuffer, 4, var7_7 - this.PI07_DataLength);
                this.logger(3, "ipduDecode() length expected but missing");
            } else {
                this.tempoBuffer = new byte[var7_7 - this.PI07_DataLength];
                System.arraycopy(var1_1, var4_4 + this.PI07_DataLength, this.tempoBuffer, 0, var7_7 - this.PI07_DataLength);
            }
            return 2;
        }
        this.logger(3, "ipduDecode() trame incomplete :" + var7_7 + " vs " + this.PI07_DataLength);
        return 0;
    }

    @Override
    public int waitConnection() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
            return 1;
        }
        this.myMode = ReceiverTransmitterMode.ReceiveMode;
        this.myState = YP_PROT_Interface_Com.ComStateMachine.WAIT_CONNECTION;
        int n = 0;
        int n2 = 0;
        while (n == 0) {
            int n3 = 0;
            while (n3 == 0) {
                n3 = this.physicalInterface.recv(this.ipduBuffer, n2, this.ipduBuffer.length - n2, 3000);
            }
            if (n3 < 0) {
                this.logger(2, "waitConnection() broken connection");
                return -1;
            }
            n = this.ipduDecode(this.ipduBuffer, n2 += n3, true);
        }
        if (n != 1) {
            return 0;
        }
        byte[] byArray = this.ipduCode(IMessageType.IPDU_AC, null, false);
        this.physicalInterface.send(byArray, byArray.length);
        this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
        this.setTimer("TSI");
        return 1;
    }

    @Override
    public int connect(YP_Row yP_Row) {
        Object object;
        this.connectionRow = yP_Row;
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.WAIT_CONNECTION) {
            return 0;
        }
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 1;
        }
        this.myMode = ReceiverTransmitterMode.TransmitMode;
        try {
            object = (YP_Service)this.getPluginByName("ConnectionManager");
            this.physicalInterface = (YP_PHYS_Interface)((YP_Object)object).dealRequest(this, "openConnection", yP_Row);
            if (this.physicalInterface == null) {
                this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
            return -1;
        }
        this.physicalInterfaceToShutdown = 1;
        object = this.ipduCode(IMessageType.IPDU_CN, null, true);
        this.physicalInterface.send((byte[])object, ((Object)object).length);
        this.setTimer("TNR");
        int n = 0;
        int n2 = 0;
        while (n == 0) {
            int n3 = 0;
            while (!this.isTimeoutOccured() && n3 == 0) {
                n3 = this.physicalInterface.recv(this.ipduBuffer, n2, this.ipduBuffer.length - n2, 3000);
            }
            if (this.timeoutOccured) {
                this.logger(2, "connect() TimeOut " + this.timerName);
                this.resetTimer();
                this.adjustConnectionStatusIssues(yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.CONNECT_TIMEOUT);
                return -1;
            }
            if (n3 < 0) {
                this.logger(2, "connect() broken connection");
                this.adjustConnectionStatusIssues(yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.CONNECT_BROKEN);
                return -2;
            }
            if (n3 == 0) {
                this.logger(2, "connect() TimeOut");
                this.adjustConnectionStatusIssues(yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.CONNECT_TIMEOUT);
                return -3;
            }
            this.logger(5, "connect() Received Data: " + n3);
            n = this.ipduDecode(this.ipduBuffer, n2 += n3, false);
        }
        this.resetTimer();
        if (n < 0) {
            this.logger(2, "connect() failed 1");
            this.disconnect();
            this.adjustConnectionStatusIssues(yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.CONNECT_PROTOCOL);
            return -1;
        }
        if (this.myMessageType == IMessageType.IPDU_AC && this.PI01_CodeReponseToSend == PI01CBComEnumeration.PI01_OK) {
            this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
        } else {
            this.logger(2, "connect() failed 2");
            this.disconnect();
            this.adjustConnectionStatusIssues(yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.CONNECT_PROTOCOL);
        }
        return 1;
    }

    private void adjustConnectionStatusIssues(YP_Row yP_Row, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration connectionStatusIssueEnumeration) {
        try {
            YP_TCD_DCC_Status yP_TCD_DCC_Status = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
            yP_TCD_DCC_Status.adjustConnectionStatusIssues(yP_Row, connectionStatusIssueEnumeration);
        }
        catch (Exception exception) {
            this.logger(2, "adjustConnectionStatusIssues() ", exception);
        }
    }

    @Override
    public void send(byte[] byArray, boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException {
        byte[] byArray2 = this.ipduCode(IMessageType.IPDU_DE, byArray, bl);
        if (this.isTimeoutOccured()) {
            this.logger(2, "send() Timer " + this.timerName + " expired");
            YP_PROT_Interface_Com.TimeOutException timeOutException = new YP_PROT_Interface_Com.TimeOutException();
            timeOutException.timerName = this.timerName;
            this.resetTimer();
            throw timeOutException;
        }
        int n = this.physicalInterface.send(byArray2, byArray2.length);
        if (n < 0) {
            this.logger(2, "send() broken connection");
            throw new YP_PROT_Interface_Com.DisconnectionException();
        }
        this.resetTimer();
        if (bl) {
            this.setTimer("TNR");
        } else {
            this.setTimer("TSI");
        }
    }

    @Override
    public byte[] receive(boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException, YP_PROT_Interface_Com.BadFormatException {
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
            this.logger(2, "receive() not connected !!!");
            return null;
        }
        int n = 0;
        int n2 = 0;
        if (this.timeoutTime == 0L) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "receive() no TimeOut specified, let's use one !!!");
            }
            if (bl) {
                this.setTimer("TSI");
            } else {
                this.setTimer("TNR");
            }
        }
        if (this.tempoBuffer != null) {
            if (this.ipduBuffer.length < this.tempoBuffer.length + 10000) {
                this.ipduBuffer = new byte[this.tempoBuffer.length + 10000];
            }
            System.arraycopy(this.tempoBuffer, 0, this.ipduBuffer, 0, this.tempoBuffer.length);
            n2 = this.tempoBuffer.length;
            this.tempoBuffer = null;
            n = this.ipduDecode(this.ipduBuffer, n2, bl);
        }
        while (n == 0) {
            Object object;
            int n3 = 0;
            while (!this.isTimeoutOccured() && n3 == 0) {
                if (this.ipduBuffer.length < n2 + 10000) {
                    object = this.ipduBuffer;
                    this.ipduBuffer = Arrays.copyOf(object, n2 + 10000);
                }
                n3 = this.physicalInterface.recv(this.ipduBuffer, n2, this.ipduBuffer.length - n2, 3000);
            }
            if (this.timeoutOccured && n3 == 0) {
                this.logger(2, "receive() TimeOut " + this.timerName);
                if (this.connectionRow != null) {
                    this.adjustConnectionStatusIssues(this.connectionRow, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.RECEIVE_TIMEOUT);
                }
                object = new YP_PROT_Interface_Com.TimeOutException();
                object.timerName = this.timerName;
                this.resetTimer();
                throw object;
            }
            if (n3 < 0) {
                this.logger(2, "receive() broken connection");
                if (this.connectionRow != null) {
                    this.adjustConnectionStatusIssues(this.connectionRow, YP_TCD_DCC_Status.ConnectionStatusIssueEnumeration.RECEIVE_BROKEN);
                }
                throw new YP_PROT_Interface_Com.DisconnectionException();
            }
            if (n3 == 0) {
                this.logger(2, "receive() TimeOut");
                return new byte[0];
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "receive() Received Data: " + n3);
            }
            n = this.ipduDecode(this.ipduBuffer, n2 += n3, bl);
        }
        this.resetTimer();
        if (n < 0) {
            this.logger(2, "receive() reception pb");
            throw new YP_PROT_Interface_Com.BadFormatException();
        }
        if (this.myMessageType != IMessageType.IPDU_DE) {
            throw new YP_PROT_Interface_Com.BadFormatException();
        }
        if (bl) {
            this.setTimer("TGR");
        }
        return this.ApduBuffer;
    }

    @Override
    public int disconnect() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 0;
        }
        this.resetTimer();
        byte[] byArray = this.ipduCode(IMessageType.IPDU_AB, null, true);
        this.physicalInterface.send(byArray, byArray.length);
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        this.connectionRow = null;
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        this.resetTimer();
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        this.connectionRow = null;
        return 1;
    }

    @Override
    public String toString() {
        return "CBCOM";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String getParameter(String string) {
        switch (string) {
            case "PI01": {
                if (this.PI01_CodeReponseReceived == null) {
                    return null;
                }
                byte[] byArray = new byte[]{this.PI01_CodeReponseReceived.getValue()};
                return UtilsYP.devHexa(byArray);
            }
            case "PI05": {
                if (this.PI05_ProtocolIdentifier == null) {
                    return null;
                }
                return UtilsYP.devHexa(this.PI05_ProtocolIdentifier, 0, 4);
            }
            case "STATUT": {
                return this.myState.toString();
            }
        }
        return null;
    }

    @Override
    public int waitDisconnection() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 1;
        }
        this.myMode = ReceiverTransmitterMode.ReceiveMode;
        this.myState = YP_PROT_Interface_Com.ComStateMachine.WAIT_DISCONNECTION;
        int n = 0;
        int n2 = 0;
        this.setTimer("TNR");
        while (!this.isTimeoutOccured()) {
            n = 0;
            while (!this.isTimeoutOccured() && n == 0) {
                n = this.physicalInterface.recv(this.ipduBuffer, n2, this.ipduBuffer.length - n2, 3000);
            }
            if (n < 0) {
                this.logger(2, "waitDisconnection() broken connection");
                return -1;
            }
            if (this.isTimeoutOccured()) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "waitDisconnection() time out " + this.timerName + "on IPDU_AB reception");
                }
                this.PI01_CodeReponseToSend = PI01CBComEnumeration.PI01_22;
                byte[] byArray = this.ipduCode(IMessageType.IPDU_AB, null, true);
                n = this.physicalInterface.send(byArray, byArray.length);
                if (n < 0) {
                    this.logger(2, "send() broken connection");
                }
                this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
                return 1;
            }
            int n3 = this.ipduDecode(this.ipduBuffer, n2 += n, true);
            if (n3 == 0) continue;
            if (this.myMessageType == IMessageType.IPDU_AB) {
                if (this.getLogLevel() < 5) break;
                this.logger(5, "waitDisconnection() disconect IPDU received");
                break;
            }
            n2 = 0;
            this.logger(3, "waitDisconnection() message trashed");
        }
        this.resetTimer();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "waitDisconnection() disconnected");
        }
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        return 1;
    }

    @Override
    public int setComParameter(String string, String string2) {
        return 0;
    }

    private static enum IMessageType {
        IPDU_DE(-63),
        IPDU_CN(-62),
        IPDU_AC(-61),
        IPDU_AB(-60);

        private byte myValue;

        private IMessageType(byte by) {
            this.myValue = by;
        }

        private byte getCommand() {
            return this.myValue;
        }

        private boolean isEquals(byte by) {
            return this.myValue == by;
        }

        static /* synthetic */ boolean access$4(IMessageType iMessageType, byte by) {
            return iMessageType.isEquals(by);
        }
    }

    public static enum PI01CBComEnumeration {
        PI01_OK(0),
        PI01_01(1),
        PI01_PGIKO(2),
        PI01_03(3),
        PI01_PIMissing(4),
        PI01_LGIInvalid(5),
        PI01_06(6),
        PI01_AccessPointJammed(7),
        PI01_8(8),
        PI01_09(9),
        PI01_0A(10),
        PI01_ServiceStopped(14),
        PI01_AccessPointStopped(15),
        PI01_10(16),
        PI01_11(17),
        PI01_UnknownAPDU(18),
        PI01_APDULengthIncorrect(19),
        PI01_TNRTooSmall(21),
        PI01_TSITooSmall(22),
        PI01_TMATooSmall(23),
        PI01_ProtocolError(24),
        PI01_TSI(25),
        PI01_TGR(26),
        PI01_TNR(27),
        PI01_TSM(28),
        PI01_UncorrectPISequence(29),
        PI01_IncorrectCBCOMVers(30),
        PI01_ProtocolTypeIncorrect(31),
        PI01_ProtocolVersionIncorrect(32),
        PI01_21(33),
        PI01_22(34),
        PI01_23(35),
        PI01_24(36),
        PI01_25(37),
        PI01_26(38),
        PI01_IncorrectValue(39),
        PI01_ABUnsupported(40),
        PI01_NormalEnding(-128);

        private byte pi01;

        private PI01CBComEnumeration(byte by) {
            this.pi01 = by;
        }

        public byte getValue() {
            return this.pi01;
        }

        public static PI01CBComEnumeration getPI01Value(byte by) {
            PI01CBComEnumeration[] pI01CBComEnumerationArray = PI01CBComEnumeration.values();
            int n = pI01CBComEnumerationArray.length;
            int n2 = 0;
            while (n2 < n) {
                PI01CBComEnumeration pI01CBComEnumeration = pI01CBComEnumerationArray[n2];
                if (pI01CBComEnumeration.getValue() == by) {
                    return pI01CBComEnumeration;
                }
                ++n2;
            }
            return null;
        }
    }

    private static enum ReceiverTransmitterMode {
        ReceiveMode,
        TransmitMode;

    }
}

