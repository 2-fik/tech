/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package org.yp.framework.ondemandcomponents.applications.persisters.smarttpe;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_KRN_InitialisationParameters;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects.DAO_SmartTPE_BrandAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects.DAO_SmartTPE_ContractAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects.DAO_SmartTPE_InitialisationExtension;
import org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects.DAO_SmartTPE_MerchantAccess;
import org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects.DAO_SmartTPE_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister.YP_TCD_DCB_Interface_TRSPersister;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class YP_BCD_A_DCC_TRSPersister_SmartTPE
extends YP_TCD_DCC_Business
implements YP_TCD_DCB_Interface_TRSPersister {
    public YP_TCD_DesignAccesObject smartTPETransaction;
    private YP_TCD_DesignAccesObject brandAccess;
    private YP_TCD_DesignAccesObject merchantAccess;
    private YP_TCD_DesignAccesObject contractAccess;
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    private final String PROTOCOL = "SSL";
    private final String KEYSTOREALGORITHM = "SunX509";
    private final String TRUSTSTOREALGORITHM = "SunX509";
    private final String KEYSTORETYPE = "jks";
    private final String TRUSTSTORETYPE = "jks";

    public YP_BCD_A_DCC_TRSPersister_SmartTPE(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        this.setContainerBusinessType(this.getContainerBusinessType() | 1);
        super.initialize();
        try {
            this.smartTPETransaction = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_SmartTPE_Transaction.class, 0, 0, null);
            this.brandAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_SmartTPE_BrandAccess.class, 0, 0, null);
            this.merchantAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_SmartTPE_MerchantAccess.class, 0, 0, null);
            this.contractAccess = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_SmartTPE_ContractAccess.class, 0, 0, null);
            if (this.initialisationParameters == null) {
                this.initialisationParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_InitialisationParameters.class, 0, 0, null);
            }
            this.initialisationParameters.addExtension(new DAO_SmartTPE_InitialisationExtension());
            this.getInitialisationRow();
            this.loadBrands();
            this.loadMerchants();
            this.loadContracts();
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    private int loadBrands() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.brandAccess) {
                Object object;
                long l = (Long)yP_Row.getFieldValueByName("idBrand");
                if (l < 0L) {
                    this.logger(2, "loadBrands() bad value for idBrand:" + l);
                    continue;
                }
                if (l == 0L) {
                    this.logger(4, "loadBrands() We have to add all brands");
                    object = (List)yP_Object.dealRequest(this, "getDataContainerBrandList", new Object[0]);
                    if (object == null) {
                        this.logger(2, "loadBrands() unable to get all datacontainer ");
                        continue;
                    }
                    Iterator iterator = object.iterator();
                    while (iterator.hasNext()) {
                        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)iterator.next();
                        yP_TCD_DCC_Brand.addPersister(this);
                    }
                    continue;
                }
                object = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBrand", l);
                if (object == null) {
                    this.logger(2, "loadBrands() unable to get datacontainer for idBrand:" + l);
                    continue;
                }
                boolean bl = ((YP_TCD_DC_Context)object).addPersister(this);
                if (bl) continue;
                this.logger(3, "loadBrands() datacontainer already added for idBrand:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadBrands()" + exception);
            return -1;
        }
    }

    private int loadMerchants() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.merchantAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idMerchant");
                if (l <= 0L) {
                    this.logger(2, "loadMerchants() bad value for idMerchant:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerMerchant", l);
                if (yP_TCD_DC_Context == null) {
                    this.logger(2, "loadMerchants() unable to get datacontainer for idMerchant:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl) continue;
                this.logger(3, "loadMerchants() datacontainer already added for idMerchant:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadMerchants()" + exception);
            return -1;
        }
    }

    private int loadContracts() {
        try {
            YP_Object yP_Object = this.getPluginByName("DataContainerManager");
            for (YP_Row yP_Row : this.contractAccess) {
                long l = (Long)yP_Row.getFieldValueByName("idContract");
                if (l <= 0L) {
                    this.logger(2, "loadContracts() bad value for idContract:" + l);
                    continue;
                }
                YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_Object.dealRequest(this, "getDataContainerBusiness", l);
                if (yP_TCD_DC_Context == null) {
                    this.logger(2, "loadContracts() unable to get datacontainer for idContract:" + l);
                    continue;
                }
                boolean bl = yP_TCD_DC_Context.addPersister(this);
                if (bl) continue;
                this.logger(3, "loadContracts() datacontainer already added for idContract:" + l);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "loadContracts()" + exception);
            return -1;
        }
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.smartTPETransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() smartTPETransaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() brandAccess");
            }
            this.loadBrands();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() merchantAccess");
            }
            this.loadMerchants();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractAccess) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contractAccess");
            }
            this.loadContracts();
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.smartTPETransaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() smartTPETransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.smartTPETransaction != null && (yP_TCD_DesignAccesObject == this.smartTPETransaction || clazz == this.smartTPETransaction.getRowClass())) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() smartTPETransaction");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int persistTransaction(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "persistTransaction() only for ETF busines");
            }
            return -1;
        }
        YP_Row yP_Row = this.getTransactionRow((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "persistTransaction() unable to get transactionRow");
            }
            return -1;
        }
        return this.dealOneTransaction(yP_Row);
    }

    private YP_Row getTransactionRow(YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            Object object;
            Object object2;
            String string;
            YP_Row yP_Row = this.smartTPETransaction.getNewRow();
            yP_Row.set("merchantTransactionIdentifier", yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionIdentifier());
            TransactionTypeEnumeration transactionTypeEnumeration = yP_TCD_DC_Transaction.commonHandler.getTransactionType();
            yP_Row.set("type", transactionTypeEnumeration);
            yP_Row.set("amount", yP_TCD_DC_Transaction.commonHandler.getTransactionAmount());
            yP_Row.set("currency", yP_TCD_DC_Transaction.commonHandler.getTransactionCurrencyAlpha());
            yP_Row.set("datetime", yP_TCD_DC_Transaction.commonHandler.getTransactionAppliGMTTime());
            yP_Row.set("status", yP_TCD_DC_Transaction.commonHandler.getRealisationMode());
            yP_Row.set("maskedPAN", UtilsYP.maskPAN_Last4(yP_TCD_DC_Transaction.accountHandler.getAccountIdentifier()));
            yP_Row.set("userName", yP_TCD_DC_Transaction.userHandler.getUserUID());
            yP_Row.set("merchantContractIdentifier", yP_TCD_DCC_EFT_Business.getMerchantContract());
            yP_Row.set("verificationMethod", yP_TCD_DC_Transaction.commonHandler.getCardHolderAuthentication());
            String string2 = yP_TCD_DC_Transaction.getAuthorisationApprovalCode();
            if (string2 != null && !string2.isEmpty()) {
                yP_Row.set("authorizationNumber", string2);
            }
            if ((string = yP_TCD_DC_Transaction.getAuthorisationResponseCode()) != null && !string.isEmpty()) {
                yP_Row.set("authorizationRespCode", string);
            }
            yP_Row.set("nepSAServerResponse", yP_TCD_DC_Transaction.commonHandler.getExtendedResult().toString());
            try {
                int n = yP_TCD_DC_Transaction.getRealNLPA();
                object2 = yP_TCD_DC_Transaction.getTerminalRow();
                if (object2 == null) {
                    this.logger(2, "getTransactionRow() unable to find terminal row for " + yP_TCD_DCC_EFT_Business.getDataContainerMerchant().getIDMerchant() + " " + n);
                } else {
                    yP_Row.set("dongle_serial", ((YP_Row)object2).getFieldStringValueByName("terminalSerialNumber"));
                    yP_Row.set("dongle_model", "PosMate");
                    long l = (Long)((YP_Row)object2).getFieldValueByName("idTerminalReference");
                    if (l <= 0L) {
                        this.logger(2, "getTransactionRow() no terminal reference  for " + yP_TCD_DCC_EFT_Business.getDataContainerMerchant().getIDMerchant() + " " + n);
                    } else {
                        object = this.dataContainerTechnique.getTerminalReferenceRow(l);
                        if (object == null) {
                            this.logger(2, "getTransactionRow() unable to find terminal reference row for " + yP_TCD_DCC_EFT_Business.getDataContainerMerchant().getIDMerchant() + " " + n);
                        } else {
                            yP_Row.set("dongle_model", ((YP_Row)object).getFieldStringValueByName("model"));
                        }
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "getTransactionRow() dongle_ " + exception);
            }
            String string3 = yP_TCD_DC_Transaction.accountHandler.getScheme();
            if (string3 != null && string3.contentEquals("UNION PAY")) {
                string3 = "UPI";
            }
            yP_Row.set("scheme", string3);
            yP_Row.set("entryCondition", yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology());
            yP_Row.set("applicationType", yP_TCD_DCC_EFT_Business.getApplicationPlugin().getApplicationRow().getFieldStringValueByName("applicationName"));
            object2 = yP_TCD_DCC_EFT_Business.getTransactionTicket(yP_TCD_DC_Transaction, false, 1);
            object2 = ((String)object2).trim();
            yP_Row.set("customerTillReceipt", (String)object2);
            String string4 = yP_TCD_DCC_EFT_Business.getTransactionTicket(yP_TCD_DC_Transaction, false, 5);
            string4 = string4.trim();
            yP_Row.set("merchantTillReceipt", string4);
            String string5 = yP_TCD_DCC_EFT_Business.getTransactionTicket(yP_TCD_DC_Transaction, false, 4);
            string5 = string5.trim();
            yP_Row.set("customerTillReceiptSms", string5);
            try {
                object = yP_TCD_DC_Transaction.getTokenHash();
                if (object != null && !((String)object).isEmpty()) {
                    yP_Row.set("cardToken", (String)object);
                }
            }
            catch (Exception exception) {
                this.logger(2, "getTransactionRow() cardToken " + exception);
            }
            if ((object = yP_TCD_DC_Transaction.commonHandler.getMerchantPrivateData()) != null && !((String)object).isEmpty()) {
                yP_Row.set("privateData", (String)object);
            }
            return yP_Row;
        }
        catch (Exception exception) {
            this.logger(2, "getTransactionRow() " + exception);
            return null;
        }
    }

    private byte[] getTRSRequest(YP_Row yP_Row) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("merchantTransactionIdentifier", (Object)yP_Row.getFieldStringValueByName("merchantTransactionIdentifier"));
            jSONObject.put("type", (Object)yP_Row.getFieldStringValueByName("type"));
            jSONObject.put("amount", ((Long)yP_Row.getFieldValueByName("amount")).longValue());
            jSONObject.put("currency", (Object)yP_Row.getFieldStringValueByName("currency"));
            jSONObject.put("datetime", ((Timestamp)yP_Row.getFieldValueByName("datetime")).getTime() / 1000L);
            jSONObject.put("status", (Object)yP_Row.getFieldStringValueByName("status"));
            jSONObject.put("maskedPAN", (Object)yP_Row.getFieldStringValueByName("maskedPAN"));
            jSONObject.put("userName", (Object)yP_Row.getFieldStringValueByName("userName"));
            jSONObject.put("merchantContractIdentifier", (Object)yP_Row.getFieldStringValueByName("merchantContractIdentifier"));
            jSONObject.put("verificationMethod", (Object)yP_Row.getFieldStringValueByName("verificationMethod"));
            jSONObject.put("authorizationNumber", (Object)yP_Row.getFieldStringValueByName("authorizationNumber"));
            jSONObject.put("authorizationRespCode", (Object)yP_Row.getFieldStringValueByName("authorizationRespCode"));
            jSONObject.put("nepSAServerResponse", (Object)yP_Row.getFieldStringValueByName("nepSAServerResponse"));
            jSONObject.put("dongle_serial", (Object)yP_Row.getFieldStringValueByName("dongle_serial"));
            jSONObject.put("dongle_model", (Object)yP_Row.getFieldStringValueByName("dongle_model"));
            jSONObject.put("scheme", (Object)yP_Row.getFieldStringValueByName("scheme"));
            jSONObject.put("entryCondition", (Object)yP_Row.getFieldStringValueByName("entryCondition"));
            jSONObject.put("applicationType", (Object)yP_Row.getFieldStringValueByName("applicationType"));
            jSONObject.put("customerTillReceipt", (Object)yP_Row.getFieldStringValueByName("customerTillReceipt"));
            jSONObject.put("merchantTillReceipt", (Object)yP_Row.getFieldStringValueByName("merchantTillReceipt"));
            jSONObject.put("customerTillReceiptSms", (Object)yP_Row.getFieldStringValueByName("customerTillReceiptSms"));
            jSONObject.put("cardToken", (Object)yP_Row.getFieldStringValueByName("cardToken"));
            jSONObject.put("privateData", (Object)yP_Row.getFieldStringValueByName("privateData"));
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getTRSRequest() " + jSONObject.toString());
            }
            return jSONObject.toString().getBytes("UTF-8");
        }
        catch (Exception exception) {
            this.logger(2, "getTRSRequest() " + exception);
            return null;
        }
    }

    private int dealOneTransaction(YP_Row yP_Row) {
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealOneTransaction() no transactionRow");
            }
            return -1;
        }
        YP_Row yP_Row2 = this.getInitialisationRow();
        if (yP_Row2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealOneTransaction() no initialisationRow");
            }
            return -1;
        }
        String string = yP_Row2.getFieldStringValueByName("webServiceURL");
        String string2 = yP_Row2.getFieldStringValueByName("method");
        String string3 = yP_Row2.getFieldStringValueByName("proxyHost");
        int n = (Integer)yP_Row2.getFieldValueByName("proxyPort");
        String string4 = yP_Row2.getFieldStringValueByName("keyStorePath");
        String string5 = yP_Row2.getFieldStringValueByName("keyStorePasswd");
        String string6 = yP_Row2.getFieldStringValueByName("keyAlias");
        String string7 = yP_Row2.getFieldStringValueByName("trustStorePath");
        String string8 = yP_Row2.getFieldStringValueByName("trustStorePasswd");
        HttpURLConnection httpURLConnection = null;
        try {
            Object object;
            URL uRL = new URL(String.valueOf(string) + yP_Row.getFieldStringValueByName("merchantTransactionIdentifier") + "/close");
            if (string3 != null && string3.length() > 0 && n > 0) {
                object = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(string3, n));
                httpURLConnection = (HttpURLConnection)uRL.openConnection((Proxy)object);
            } else {
                httpURLConnection = (HttpURLConnection)uRL.openConnection();
            }
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(20000);
            if (httpURLConnection instanceof HttpsURLConnection) {
                object = this.getSSLContext(string4, string5, string6, string7, string8);
                SSLSocketFactory sSLSocketFactory = ((SSLContext)object).getSocketFactory();
                ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(sSLSocketFactory);
            }
            httpURLConnection.setRequestMethod(string2);
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            object = new DataOutputStream(httpURLConnection.getOutputStream());
            ((FilterOutputStream)object).write(this.getTRSRequest(yP_Row));
            ((DataOutputStream)object).flush();
            ((FilterOutputStream)object).close();
            int n2 = httpURLConnection.getResponseCode();
            if (n2 == 200) {
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "dealOneTransaction() OK  ");
                }
                try {
                    InputStream inputStream = httpURLConnection.getInputStream();
                    if (inputStream == null) {
                        inputStream = httpURLConnection.getErrorStream();
                    }
                    if (inputStream != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                        String string9 = null;
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((string9 = bufferedReader.readLine()) != null) {
                            stringBuilder.append(String.valueOf(string9) + "\n");
                        }
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "dealOneTransaction() Content: " + stringBuilder.toString());
                        }
                        bufferedReader.close();
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "dealOneTransaction() 1" + exception);
                }
                if (!yP_Row.isItAClonedRow()) {
                    yP_Row.delete();
                    yP_Row.persist();
                }
                return 1;
            }
            String string10 = httpURLConnection.getResponseMessage();
            if (string10 == null) {
                string10 = "";
            }
            yP_Row.set("responseContent", "");
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealOneTransaction() Response code: " + n2 + "  " + string10);
                try {
                    InputStream inputStream = httpURLConnection.getErrorStream();
                    if (inputStream == null) {
                        inputStream = httpURLConnection.getInputStream();
                    }
                    if (inputStream != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                        String string11 = null;
                        StringBuilder stringBuilder = new StringBuilder();
                        while ((string11 = bufferedReader.readLine()) != null) {
                            stringBuilder.append(String.valueOf(string11) + "\n");
                        }
                        String string12 = stringBuilder.toString();
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "dealOneTransaction() Content: " + string12);
                        }
                        yP_Row.set("responseContent", string12);
                        bufferedReader.close();
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.logger(2, "dealOneTransaction() 2 " + exception);
                }
            }
            if (yP_Row.isItAClonedRow()) {
                yP_Row.setIsItAClonedRow(false);
            }
            yP_Row.set("responseMessage", string10);
            yP_Row.set("responseCode", n2);
            yP_Row.set("currentTry", (Integer)yP_Row.getFieldValueByName("currentTry") + 1);
            yP_Row.persist();
            return -1;
        }
        catch (Exception exception) {
            this.logger(2, "dealOneTransaction() 3 " + exception);
            if (yP_Row.isItAClonedRow()) {
                yP_Row.setIsItAClonedRow(false);
            }
            yP_Row.set("responseMessage", exception.getMessage());
            yP_Row.set("responseCode", -1);
            try {
                yP_Row.persist();
            }
            catch (Exception exception2) {
                this.logger(2, "dealOneTransaction() 4 " + exception2);
            }
            return -1;
        }
        finally {
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
        }
    }

    private int dealTransactionsUpload() {
        if (UtilsYP.getInstanceRole() != 1) {
            return 0;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.smartTPETransaction);
        yP_ComplexGabarit.set(this.smartTPETransaction.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1234);
        yP_ComplexGabarit.set("responseCode", YP_ComplexGabarit.OPERATOR.DIFFERENT, 4567);
        yP_ComplexGabarit.set("currentTry", YP_ComplexGabarit.OPERATOR.LESS, 10);
        List<YP_Row> list = this.smartTPETransaction.getRowListSuchAs(0, 1000, yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealTransactionsUpload() unable to get transation list");
            }
            return -1;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "dealTransactionsUpload() nothing to do");
            }
        } else {
            for (YP_Row yP_Row : list) {
                int n = this.dealOneTransaction(yP_Row);
                if (n == 1) continue;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealTransactionsUpload() unable to upload transaction");
                }
                return -1;
            }
            if (this.getLogLevel() >= 4) {
                this.logger(4, "dealTransactionsUpload() all transactions have been uploaded");
            }
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            block9: {
                if (string == null || string.isEmpty()) break block9;
                switch (string) {
                    case "dealTransactionsUpload": {
                        return this.dealTransactionsUpload();
                    }
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerTRSPersister_SmartTPE";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    private SSLContext getSSLContext(String string, String string2, String string3, String string4, String string5) {
        block23: {
            TrustManagerFactory trustManagerFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            TrustManager[] trustManagerArray = null;
            try {
                KeyStore keyStore;
                SSLContext sSLContext = SSLContext.getInstance("SSL");
                if (string != null && !string.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance("jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string), string2.toCharArray());
                    keyManagerFactory.init(keyStore, string2.toCharArray());
                }
                if (string4 != null && !string4.isEmpty()) {
                    trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance("jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string4), string5.toCharArray());
                    trustManagerFactory.init(keyStore);
                } else {
                    trustManagerArray = new X509TrustManager[]{new X509TrustManager(){

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }
                    }};
                }
                if (keyManagerFactory == null && trustManagerFactory == null) {
                    sSLContext.init(null, trustManagerArray, null);
                } else if (keyManagerFactory == null && trustManagerFactory != null) {
                    sSLContext.init(null, trustManagerFactory.getTrustManagers(), null);
                } else if (keyManagerFactory != null && trustManagerFactory == null) {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerArray, null);
                } else {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                }
                return sSLContext;
            }
            catch (FileNotFoundException fileNotFoundException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() FileNotFoundException:" + fileNotFoundException);
                }
            }
            catch (KeyStoreException keyStoreException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() KeyStoreException:" + keyStoreException);
                }
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() NoSuchAlgorithmException:" + noSuchAlgorithmException);
                }
            }
            catch (CertificateException certificateException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() CertificateException:" + certificateException);
                }
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() IOException:" + iOException);
                }
            }
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() UnrecoverableKeyException:" + unrecoverableKeyException);
                }
            }
            catch (KeyManagementException keyManagementException) {
                if (this.getLogLevel() < 2) break block23;
                this.logger(2, "getSSLContext() KeyManagementException:" + keyManagementException);
            }
        }
        return null;
    }
}

