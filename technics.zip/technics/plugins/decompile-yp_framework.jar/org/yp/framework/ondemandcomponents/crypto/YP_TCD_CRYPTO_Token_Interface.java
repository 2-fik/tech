/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Interface;

public interface YP_TCD_CRYPTO_Token_Interface
extends YP_TCD_CRYPTO_Interface {
    public String[] encryptToken(String var1, String var2, String var3) throws Exception;

    public String decryptToken(String var1, String var2, String var3) throws Exception;
}

