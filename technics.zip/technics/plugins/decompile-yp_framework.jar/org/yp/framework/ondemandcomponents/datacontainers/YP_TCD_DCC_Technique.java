/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Acquirer;
import org.yp.designaccesobjects.technic.DAO_Application;
import org.yp.designaccesobjects.technic.DAO_ApplicationInsideBrand;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_BrandInsideGroup;
import org.yp.designaccesobjects.technic.DAO_Connection;
import org.yp.designaccesobjects.technic.DAO_Connector;
import org.yp.designaccesobjects.technic.DAO_Contract;
import org.yp.designaccesobjects.technic.DAO_Group;
import org.yp.designaccesobjects.technic.DAO_Image;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.designaccesobjects.technic.DAO_MgtParameters;
import org.yp.designaccesobjects.technic.DAO_Schedule;
import org.yp.designaccesobjects.technic.DAO_TerminalConfig;
import org.yp.designaccesobjects.technic.DAO_TerminalConfigStatus;
import org.yp.designaccesobjects.technic.DAO_TerminalReference;
import org.yp.designaccesobjects.technic.DAO_TerminalUpdate;
import org.yp.designaccesobjects.technic.info.DAO_ApplicationTableInfo;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.YP_TCG_XMLParser;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_BaseApplication;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.InitializationStatusEnumeration;
import org.yp.utils.enums.TableStatusEnumeration;
import org.yp.utils.enums.TerminalConfigStatusEnumeration;
import org.yp.xml.jaxb.ypplugin.Plugin;
import org.yp.xml.jaxb.ypproperties.Properties;
import org.yp.xml.jaxb.ypproperties.Property;

public final class YP_TCD_DCC_Technique
extends YP_TCD_DC_Context {
    public YP_TCD_DesignAccesObject application;
    private YP_TCD_DesignAccesObject connector;
    public YP_TCD_DesignAccesObject contract;
    public YP_TCD_DesignAccesObject merchant;
    public YP_TCD_DesignAccesObject brand;
    private YP_TCD_DesignAccesObject group;
    private YP_TCD_DesignAccesObject brandInsideGroup;
    public YP_TCD_DesignAccesObject schedule;
    public YP_TCD_DesignAccesObject connection;
    private YP_TCD_DesignAccesObject terminalReference;
    private YP_TCD_DesignAccesObject terminalConfig;
    private YP_TCD_DesignAccesObject terminalConfigStatus;
    private YP_TCD_DesignAccesObject terminalUpdate;
    private YP_TCD_DesignAccesObject applicationTableInfo;
    private YP_TCD_DesignAccesObject mgtParameters;
    private YP_TCD_DesignAccesObject applicationInsideBrand;
    private YP_Service dataContainerManager;
    private YP_TCD_DesignAccesObject image;
    private YP_TCD_DesignAccesObject acquirer;
    private final Map<Long, YP_BaseApplication> hashedApplicationList = new HashMap<Long, YP_BaseApplication>();
    private final Set<Long> hashedObsoleteApplicationList = new HashSet<Long>();
    private List<YP_TCD_DataBaseConnector> dataBaseConnectorListForEvent = null;
    private final Map<String, List<YP_Row>> tableStatusMap = new HashMap<String, List<YP_Row>>();
    private static final int NB_STATUS_AT_ONE_TIME = 10000;

    public YP_TCD_DCC_Technique(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.applicationTableInfo = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ApplicationTableInfo.class, 0, 0, null);
            this.loadTableStatus();
            this.application = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Application.class, 0, 0, null);
            this.connector = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Connector.class, 0, 0, null);
            this.contract = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Contract.class, 0, 0, null);
            this.merchant = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Merchant.class, 0, 0, null);
            this.brand = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Brand.class, 0, 0, null);
            this.group = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Group.class, 0, 0, null);
            this.brandInsideGroup = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_BrandInsideGroup.class, 0, 0, null);
            this.schedule = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Schedule.class, 0, 512, null);
            this.connection = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Connection.class, 0, 0, null);
            this.terminalReference = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_TerminalReference.class, 0, 0, null);
            this.terminalConfig = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_TerminalConfig.class, 0, 0, null);
            this.terminalConfigStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_TerminalConfigStatus.class, 0, 0, null);
            this.terminalUpdate = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_TerminalUpdate.class, 0, 0, null);
            this.mgtParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_MgtParameters.class, 0, 0, null);
            this.applicationInsideBrand = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_ApplicationInsideBrand.class, 0, 0, null);
            this.dataContainerManager = (YP_Service)this.getPluginByName("DataContainerManager");
            this.image = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Image.class, 0, 0, null);
            this.acquirer = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Acquirer.class, 0, 0, null);
            this.acquirer.size();
        }
        catch (Exception exception) {
            this.logger(2, "initialize() " + exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerTechnique";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.application) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() application");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connector) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() connector");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contract) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contract");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchant) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() merchant");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() brand");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.group) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() group");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandInsideGroup) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() brandInsideGroup");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.schedule) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() schedule");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connection) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() connection");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalReference) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() terminalReference");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfig) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() terminalConfig");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfigStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() terminalConfigStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalUpdate) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() terminalUpdate");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationTableInfo) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() applicationTableInfo");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.mgtParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() mgtParameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.image) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() image");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.acquirer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() acquirer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationInsideBrand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() applicationInsideBrand");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.application) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() application");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connector) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() connector");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contract) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() contract");
            }
            if (yP_Row != null) {
                this.dealContractUpdate(null, yP_Row.getPrimaryKey());
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchant) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() merchant");
            }
            if (yP_Row != null) {
                this.dealMerchantUpdate(null, yP_Row.getPrimaryKey());
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() brand");
            }
            if (yP_Row != null) {
                this.dealBrandUpdate(null, yP_Row.getPrimaryKey());
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.group) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() group");
            }
            if (yP_Row != null) {
                this.dealGroupUpdate(null, yP_Row.getPrimaryKey());
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandInsideGroup) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() brandInsideGroup");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.schedule) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() schedule");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connection) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() connection");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalReference) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminalReference");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfig) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminalConfig");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfigStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminalConfigStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalUpdate) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminalUpdate");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationTableInfo) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() applicationTableInfo");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.mgtParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() mgtParameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.image) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() image");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.acquirer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() acquirer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationInsideBrand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() applicationInsideBrand");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.application) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() application");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connector) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() connector");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contract) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() contract");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchant) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() merchant");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() brand");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.group) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() group");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.brandInsideGroup) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() brandInsideGroup");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.schedule) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() schedule");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.connection) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() connection");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalReference) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminalReference");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfig) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminalConfig");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalConfigStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminalConfigStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalUpdate) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminalUpdate");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationTableInfo) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() applicationTableInfo");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.mgtParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() mgtParameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.image) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() image");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.acquirer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() acquirer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.applicationInsideBrand) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() applicationInsideBrand");
            }
            return 1;
        }
        return super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    public int loadMasterApplications() {
        for (YP_Row yP_Row : this.application) {
            Boolean bl = (Boolean)yP_Row.getFieldValueByName("isObsolete");
            if (bl == null || !bl.booleanValue()) {
                Object object;
                Object object2;
                Object object3;
                String string = yP_Row.getFieldStringValueByName("application_Plugin");
                if (string == null) {
                    this.logger(2, "loadMasterApplications() unable to get applicationPlugin");
                    continue;
                }
                YP_BaseApplication yP_BaseApplication = (YP_BaseApplication)this.newPluginByName(string, new Object[0]);
                if (yP_BaseApplication == null) {
                    this.logger(2, "loadMasterApplications() problem with " + string);
                    continue;
                }
                yP_BaseApplication.setApplicationRow(yP_Row);
                String string2 = yP_Row.getFieldStringValueByName("pluginsRestriction");
                if (string2 != null && !string2.isEmpty()) {
                    try {
                        object3 = (YP_TCG_XMLParser)this.getPluginByName("YPPluginParser");
                        object2 = (Plugin)((YP_TCG_XMLParser)object3).xmlToObject(string2);
                        object = new ArrayList<Object>();
                        object.add(object2);
                        yP_BaseApplication.setPluginsRestriction((List<Plugin>)object);
                    }
                    catch (Exception exception) {
                        this.logger(2, "loadMasterApplications() ", exception);
                    }
                }
                if ((object3 = yP_Row.getFieldStringValueByName("applicationProperties")) != null && !((String)object3).isEmpty()) {
                    try {
                        object2 = (YP_TCG_XMLParser)this.getPluginByName("YPPropertiesParser");
                        object = (Properties)((YP_TCG_XMLParser)object2).xmlToObject((String)object3);
                        yP_BaseApplication.setApplicationProperties(((Properties)object).getProperty());
                    }
                    catch (Exception exception) {
                        this.logger(2, "loadMasterApplications() ", exception);
                    }
                }
                this.hashedApplicationList.put(yP_Row.getPrimaryKey(), yP_BaseApplication);
                continue;
            }
            this.hashedObsoleteApplicationList.add(yP_Row.getPrimaryKey());
        }
        return 1;
    }

    private int reloadMasterApplications() {
        for (YP_Row yP_Row : this.application) {
            Object object;
            Object object2;
            Object object3;
            Boolean bl = (Boolean)yP_Row.getFieldValueByName("isObsolete");
            if (bl != null && bl.booleanValue()) {
                object3 = this.hashedApplicationList.remove(yP_Row.getPrimaryKey());
                if (object3 == null) continue;
                ((YP_BaseApplication)object3).shutdown();
                continue;
            }
            object3 = null;
            Properties properties = null;
            String string = yP_Row.getFieldStringValueByName("pluginsRestriction");
            if (string != null && !string.isEmpty()) {
                try {
                    object2 = (YP_TCG_XMLParser)this.getPluginByName("YPPluginParser");
                    object = (Plugin)((YP_TCG_XMLParser)object2).xmlToObject(string);
                    object3 = new ArrayList();
                    object3.add(object);
                }
                catch (Exception exception) {
                    this.logger(2, "reloadMasterApplications() ", exception);
                }
            }
            if ((object2 = yP_Row.getFieldStringValueByName("applicationProperties")) != null && !((String)object2).isEmpty()) {
                try {
                    object = (YP_TCG_XMLParser)this.getPluginByName("YPPropertiesParser");
                    properties = (Properties)((YP_TCG_XMLParser)object).xmlToObject((String)object2);
                }
                catch (Exception exception) {
                    this.logger(2, "reloadMasterApplications() ", exception);
                }
            }
            if ((object = this.hashedApplicationList.get(yP_Row.getPrimaryKey())) == null) {
                String string2 = yP_Row.getFieldStringValueByName("application_Plugin");
                if (string2 == null) {
                    this.logger(2, "reloadMasterApplications() unable to get applicationPlugin");
                    continue;
                }
                YP_Application yP_Application = (YP_Application)this.newPluginByName(string2, new Object[0]);
                if (yP_Application == null) {
                    this.logger(2, "reloadMasterApplications() problem with " + string2);
                    continue;
                }
                yP_Application.setApplicationRow(yP_Row);
                yP_Application.setPluginsRestriction((List<Plugin>)object3);
                if (properties != null) {
                    yP_Application.setApplicationProperties(properties.getProperty());
                }
                this.hashedApplicationList.put(yP_Row.getPrimaryKey(), yP_Application);
                continue;
            }
            ((YP_BaseApplication)object).setApplicationRow(yP_Row);
            ((YP_Object)object).setPluginsRestriction((List<Plugin>)object3);
            if (properties == null) continue;
            ((YP_BaseApplication)object).setApplicationProperties(properties.getProperty());
        }
        return 1;
    }

    public int loadGroups() {
        for (YP_Row yP_Row : this.group) {
            YP_TCD_DCC_Group yP_TCD_DCC_Group = this.loadGroup(yP_Row);
            if (yP_TCD_DCC_Group == null) continue;
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneGroup", yP_TCD_DCC_Group) >= 0) continue;
                this.logger(2, "loadGroups() No more space available...");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "loadGroups() " + exception);
                return -1;
            }
        }
        return 1;
    }

    public int loadBrands() {
        for (YP_Row yP_Row : this.brand) {
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.loadBrand(yP_Row);
            if (yP_TCD_DCC_Brand == null) continue;
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneBrand", yP_TCD_DCC_Brand) >= 0) continue;
                this.logger(2, "loadBrands() No more space available...");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "loadBrands() " + exception);
                return -1;
            }
        }
        return 1;
    }

    public int loadMerchants() {
        for (YP_Row yP_Row : this.merchant) {
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = this.loadMerchant(yP_Row);
            if (yP_TCD_DCC_Merchant == null) continue;
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneMerchant", yP_TCD_DCC_Merchant) >= 0) continue;
                this.logger(2, "loadMerchants() No more space available...");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "loadMerchants() " + exception);
                return -1;
            }
        }
        return 1;
    }

    public int loadContracts() {
        ArrayList<YP_TCD_DCC_Business> arrayList = new ArrayList<YP_TCD_DCC_Business>();
        for (YP_Row object : this.contract) {
            YP_TCD_DCC_Business yP_TCD_DCC_Business;
            block7: {
                InitializationStatusEnumeration initializationStatusEnumeration = (InitializationStatusEnumeration)((Object)object.getFieldValueByName("initializationStatus"));
                if (initializationStatusEnumeration == InitializationStatusEnumeration.DELETED || (yP_TCD_DCC_Business = this.loadContract(object)) == null) continue;
                try {
                    if ((Integer)this.dataContainerManager.dealRequest(this, "addOneContract", yP_TCD_DCC_Business) >= 0) break block7;
                    this.logger(2, "loadContracts() No more space available...");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "loadContracts() " + exception);
                    return -1;
                }
            }
            if ((yP_TCD_DCC_Business.getContainerBusinessType() & 1) != 0 || yP_TCD_DCC_Business.initialisationParameters != null) continue;
            arrayList.add(yP_TCD_DCC_Business);
        }
        try {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : arrayList) {
                yP_TCD_DCC_Business.initialize();
            }
        }
        catch (Exception exception) {
            this.logger(2, "loadContracts() ignored for compatibility ", exception);
        }
        return 1;
    }

    public int shutdownBrandAt(YP_Service yP_Service, int n) {
        return yP_Service.getChildByRank(n).shutdown();
    }

    private String getApplicationIdentifier(YP_Row yP_Row) {
        if (yP_Row instanceof DAO_Brand) {
            YP_Row yP_Row2 = yP_Row;
            String string = yP_Row2.getFieldStringValueByName("brandName");
            return string;
        }
        if (yP_Row instanceof DAO_Merchant) {
            YP_Row yP_Row3 = yP_Row;
            YP_Row yP_Row4 = this.brand.getRowFromNaturalJoin(yP_Row3);
            if (yP_Row4 == null) {
                this.logger(2, "getApplicationIdentifier() brandRow not retrieved");
                return null;
            }
            String string = yP_Row4.getFieldStringValueByName("brandName");
            String string2 = yP_Row3.getFieldStringValueByName("merchantName");
            return String.valueOf(string) + '_' + string2;
        }
        if (yP_Row instanceof DAO_Contract) {
            YP_Row yP_Row5 = yP_Row;
            YP_Row yP_Row6 = this.application.getRowFromNaturalJoin(yP_Row5);
            if (yP_Row6 == null) {
                this.logger(2, "getApplicationIdentifier() applicationRow not retrieved ");
                return null;
            }
            YP_Row yP_Row7 = this.merchant.getRowFromNaturalJoin(yP_Row5);
            if (yP_Row7 == null) {
                this.logger(2, "getApplicationIdentifier() merchantRow not retrieved");
                return null;
            }
            YP_Row yP_Row8 = this.brand.getRowFromNaturalJoin(yP_Row7);
            if (yP_Row8 == null) {
                this.logger(2, "getApplicationIdentifier() brandRow not retrieved");
                return null;
            }
            String string = yP_Row8.getFieldStringValueByName("brandName");
            if (string == null) {
                this.logger(2, "getApplicationIdentifier() brandName not retrieved");
                return null;
            }
            String string3 = yP_Row7.getFieldStringValueByName("merchantName");
            if (string3 == null) {
                this.logger(2, "getApplicationIdentifier() merchantName not retrieved");
                return null;
            }
            String string4 = yP_Row6.getFieldStringValueByName("applicationName");
            if (string4 == null) {
                this.logger(2, "getApplicationIdentifier() applicationName not retrieved");
                return null;
            }
            String string5 = yP_Row5.getFieldStringValueByName("applicationIndex");
            if (string5 == null) {
                this.logger(2, "getApplicationIdentifier() indexApplication not retrieved");
                return null;
            }
            return String.valueOf(string) + "_" + string3 + "_" + string4 + "_" + string5;
        }
        this.logger(2, "getApplicationIdentifier() unknown row type");
        return null;
    }

    private int shutdownBrandByPrimaryKey(long l) {
        YP_Row yP_Row = this.brand.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return -1;
        }
        String string = yP_Row.getFieldStringValueByName("brandName");
        return this.shutdownDataContainerByApplicationIdentifier(string);
    }

    private int shutdownGroupByPrimaryKey(long l) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        block5: {
            YP_Row yP_Row;
            block4: {
                try {
                    yP_Row = this.group.getRowByPrimaryKey(l);
                    if (yP_Row != null) break block4;
                    this.logger(2, "shutdownGroupByPrimaryKey() unable to find group for: " + l);
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "shutdownGroupByPrimaryKey() " + l + " " + exception);
                    return -1;
                }
            }
            String string = yP_Row.getFieldStringValueByName("groupName");
            yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainerGroup", string);
            if (yP_TCD_DataContainer != null) break block5;
            this.logger(2, "shutdownGroupByPrimaryKey() unable to get data container for: " + string);
            return -1;
        }
        return yP_TCD_DataContainer.shutdown();
    }

    private int shutdownMerchantByPrimaryKey(long l) {
        YP_Row yP_Row = this.merchant.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return -1;
        }
        String string = this.getApplicationIdentifier(yP_Row);
        if (string == null) {
            return -1;
        }
        return this.shutdownDataContainerByApplicationIdentifier(string);
    }

    private int shutdownContractByPrimaryKey(long l) {
        YP_Row yP_Row = this.contract.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return -1;
        }
        String string = this.getApplicationIdentifier(yP_Row);
        if (string == null) {
            return -1;
        }
        return this.shutdownDataContainerByApplicationIdentifier(string);
    }

    private int shutdownDataContainerByApplicationIdentifier(String string) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        block3: {
            try {
                yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
                if (yP_TCD_DataContainer != null) break block3;
                this.logger(2, "shutdownDataContainerByApplicationIdentifier() unable to get data container for: " + string);
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "shutdownDataContainerByApplicationIdentifier() " + exception);
                return -1;
            }
        }
        return yP_TCD_DataContainer.shutdown();
    }

    public YP_TCD_DCC_Brand loadBrandByPrimaryKey(long l) {
        YP_Row yP_Row = this.brand.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return null;
        }
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.loadBrand(yP_Row);
        if (yP_TCD_DCC_Brand != null) {
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneBrand", yP_TCD_DCC_Brand) < 0) {
                    this.logger(2, "loadBrandByPrimaryKey() No more space available...");
                    return null;
                }
            }
            catch (Exception exception) {
                this.logger(2, "loadBrandByPrimaryKey() " + exception);
                return null;
            }
            return yP_TCD_DCC_Brand;
        }
        return null;
    }

    public YP_TCD_DCC_Group loadGroupByPrimaryKey(long l) {
        YP_Row yP_Row = this.group.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return null;
        }
        YP_TCD_DCC_Group yP_TCD_DCC_Group = this.loadGroup(yP_Row);
        if (yP_TCD_DCC_Group != null) {
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneGroup", yP_TCD_DCC_Group) < 0) {
                    this.logger(2, "loadGroupByPrimaryKey() No more space available...");
                    return null;
                }
            }
            catch (Exception exception) {
                this.logger(2, "loadGroupByPrimaryKey() " + exception);
                return null;
            }
            return yP_TCD_DCC_Group;
        }
        return null;
    }

    public YP_TCD_DCC_Merchant loadMerchantByPrimaryKey(long l) {
        YP_Row yP_Row = this.merchant.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return null;
        }
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = this.loadMerchant(yP_Row);
        if (yP_TCD_DCC_Merchant != null) {
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneMerchant", yP_TCD_DCC_Merchant) < 0) {
                    this.logger(2, "loadMerchantByPrimaryKey() No more space available...");
                    return null;
                }
            }
            catch (Exception exception) {
                this.logger(2, "loadMerchantByPrimaryKey() " + exception);
                return null;
            }
            return yP_TCD_DCC_Merchant;
        }
        return null;
    }

    public YP_TCD_DCC_Business loadContractByPrimaryKey(long l) {
        YP_Row yP_Row = this.contract.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            return null;
        }
        InitializationStatusEnumeration initializationStatusEnumeration = (InitializationStatusEnumeration)((Object)yP_Row.getFieldValueByName("initializationStatus"));
        if (initializationStatusEnumeration == InitializationStatusEnumeration.DELETED) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadContractByPrimaryKey() trying to load a deleted contract");
            }
            return null;
        }
        YP_TCD_DCC_Business yP_TCD_DCC_Business = this.loadContract(yP_Row);
        if (yP_TCD_DCC_Business != null) {
            try {
                if ((Integer)this.dataContainerManager.dealRequest(this, "addOneContract", yP_TCD_DCC_Business) < 0) {
                    this.logger(2, "loadContractByPrimaryKey() No more space available...");
                    return null;
                }
            }
            catch (Exception exception) {
                this.logger(2, "loadContractByPrimaryKey() " + exception);
                return null;
            }
            return yP_TCD_DCC_Business;
        }
        return null;
    }

    private YP_TCD_DCC_Group loadGroup(YP_Row yP_Row) {
        YP_TCD_DCC_Group yP_TCD_DCC_Group = null;
        try {
            yP_TCD_DCC_Group = (YP_TCD_DCC_Group)this.dataContainerManager.newPluginByName("DataContainerGroup", yP_Row);
            yP_TCD_DCC_Group.initialize();
        }
        catch (Exception exception) {
            this.logger(2, "loadGroup() " + exception);
        }
        return yP_TCD_DCC_Group;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private YP_TCD_DCC_Brand loadBrand(YP_Row yP_Row) {
        String string = yP_Row.getFieldStringValueByName("brandName");
        if (string == null) {
            this.logger(2, "loadBrand() brandName not retrieved");
            return null;
        }
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = null;
        try {
            yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.dataContainerManager.newPluginByName("DataContainerBrand", yP_Row);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.connector);
            yP_ComplexGabarit.set("connectorType", YP_ComplexGabarit.OPERATOR.EQUAL, (Integer)yP_Row.getFieldValueByName("connectorType"));
            List<YP_Row> list = this.connector.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(2, "loadBrand() no connector found...");
            }
            ArrayList<YP_TCD_DataBaseConnector> arrayList = new ArrayList<YP_TCD_DataBaseConnector>();
            int n = 0;
            while (true) {
                if (n >= list.size()) {
                    yP_TCD_DCC_Brand.setDataBaseConnectorList(arrayList);
                    yP_TCD_DCC_Brand.setContractIdentifier(string);
                    yP_TCD_DCC_Brand.initialize();
                    break;
                }
                try {
                    YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = (YP_TCD_DataBaseConnector)yP_TCD_DCC_Brand.newPluginByName(list.get(n).getFieldStringValueByName("connector_Plugin"), list.get(n));
                    yP_TCD_DataBaseConnector.setDataBaseName(string);
                    yP_TCD_DataBaseConnector.initialize();
                    arrayList.add(yP_TCD_DataBaseConnector);
                    if (UtilsYP.getInstanceNumber() == yP_TCD_DataBaseConnector.getSiteIdentifier()) {
                        yP_TCD_DCC_Brand.setDataBaseConnector(yP_TCD_DataBaseConnector);
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "loadBrand() No dataBaseConnector for server " + exception);
                    return null;
                }
                if (arrayList == null || arrayList.isEmpty()) {
                    this.logger(2, "loadBrand() No dataBaseConnector for server");
                    return null;
                }
                ++n;
            }
        }
        catch (Exception exception) {
            this.logger(2, "loadBrand() No DataContainer for server " + exception);
        }
        if (yP_TCD_DCC_Brand == null) {
            this.logger(2, "loadBrand() No DataContainer for server");
        }
        return yP_TCD_DCC_Brand;
    }

    private YP_TCD_DCC_Merchant loadMerchant(YP_Row yP_Row) {
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand;
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
        block7: {
            YP_Row yP_Row2 = this.brand.getRowFromNaturalJoin(yP_Row);
            if (yP_Row2 == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "loadMerchant() unable to find corresponding brand");
                }
                return null;
            }
            yP_TCD_DCC_Merchant = null;
            String string = yP_Row2.getFieldStringValueByName("brandName");
            yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", string);
            if (yP_TCD_DCC_Brand != null) break block7;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadMerchant() unable to find corresponding brand");
            }
            return null;
        }
        try {
            yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.newPluginByName("DataContainerMerchant", yP_Row, yP_TCD_DCC_Brand);
            yP_TCD_DCC_Merchant.initialize();
            yP_TCD_DCC_Brand.dataContainerMerchantList.add(yP_TCD_DCC_Merchant);
        }
        catch (Exception exception) {
            this.logger(2, "loadMerchant() No DataContainer for server " + exception);
        }
        if (yP_TCD_DCC_Merchant == null) {
            this.logger(2, "loadMerchant() No DataContainer for server");
        }
        return yP_TCD_DCC_Merchant;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private YP_TCD_DCC_Business loadContract(YP_Row yP_Row) {
        YP_TCD_DCC_Business yP_TCD_DCC_Business = null;
        try {
            YP_Row yP_Row2;
            block18: {
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
                String string = this.getApplicationIdentifier(yP_Row);
                if (string == null) {
                    this.logger(2, "loadContract() applicationIdentifier not retrieved");
                    return null;
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", string);
                if (yP_TCD_DCC_Brand == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "loadContract() unable to find corresponding brand");
                    }
                    return null;
                }
                yP_Row2 = this.application.getRowFromNaturalJoin(yP_Row);
                if (yP_Row2 == null) {
                    this.logger(2, "loadContract() applicationRow not retrieved");
                    return null;
                }
                long l = yP_Row2.getPrimaryKey();
                YP_BaseApplication yP_BaseApplication = this.hashedApplicationList.get(l);
                if (yP_BaseApplication == null) {
                    if (!this.hashedObsoleteApplicationList.contains(l)) {
                        this.logger(2, "loadContract() master application not found: " + l);
                        return null;
                    }
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "loadContract() contract not loaded as application is obsolete :" + string);
                    }
                    return null;
                }
                yP_TCD_DCC_Business = yP_BaseApplication.getNewDataContainer(this.dataContainerManager);
                yP_TCD_DCC_Business.setContractRow(yP_Row);
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.connector);
                yP_ComplexGabarit.set("connectorType", YP_ComplexGabarit.OPERATOR.EQUAL, (Integer)yP_Row.getFieldValueByName("connectorType"));
                List<YP_Row> list = this.connector.getRowListSuchAs(yP_ComplexGabarit);
                if (list == null || list.isEmpty()) {
                    this.logger(2, "loadContract() no connector found... TODO take the one of the brand");
                    return null;
                }
                ArrayList<YP_TCD_DataBaseConnector> arrayList = new ArrayList<YP_TCD_DataBaseConnector>();
                int n = 0;
                while (true) {
                    if (n >= list.size()) {
                        yP_TCD_DCC_Business.setDataBaseConnectorList(arrayList);
                        yP_TCD_DCC_Business.setContractIdentifier(string);
                        yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", string);
                        if (yP_TCD_DCC_Merchant != null) break;
                        this.logger(2, "loadContract() No DC merchant. probably not possible");
                        break block18;
                    }
                    try {
                        YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = (YP_TCD_DataBaseConnector)yP_TCD_DCC_Business.newPluginByName(list.get(n).getFieldStringValueByName("connector_Plugin"), list.get(n));
                        yP_TCD_DataBaseConnector.setDataBaseName(string);
                        yP_TCD_DataBaseConnector.initialize();
                        arrayList.add(yP_TCD_DataBaseConnector);
                        if (UtilsYP.getInstanceNumber() == yP_TCD_DataBaseConnector.getSiteIdentifier()) {
                            yP_TCD_DCC_Business.setDataBaseConnector(yP_TCD_DataBaseConnector);
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "loadContract() No dataBaseConnector for server " + exception);
                        return null;
                    }
                    if (arrayList == null || arrayList.isEmpty()) {
                        this.logger(2, "loadContract() No dataBaseConnector for server");
                        return null;
                    }
                    ++n;
                }
                yP_TCD_DCC_Business.setDataContainerMerchant(yP_TCD_DCC_Merchant);
                yP_TCD_DCC_Merchant.dataContainerBusinessList.add(yP_TCD_DCC_Business);
            }
            yP_TCD_DCC_Business.initialize();
            int n = (Integer)yP_Row.getFieldValueByName("satisfactionIndex");
            if (n == 0) {
                n = (Integer)yP_Row2.getFieldValueByName("satisfactionIndex");
            }
            yP_TCD_DCC_Business.setSatisfactionIndex(n);
        }
        catch (Exception exception) {
            this.logger(2, "loadContract() No DataContainer for server " + exception);
        }
        if (yP_TCD_DCC_Business == null) {
            this.logger(2, "loadContract() No DataContainer for server");
        }
        return yP_TCD_DCC_Business;
    }

    private int dealGroupUpdate(YP_Row yP_Row, long l) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        YP_Row yP_Row2;
        String string = null;
        String string2 = null;
        YP_Row yP_Row3 = this.group.getRowByPrimaryKey(l);
        if (yP_Row3 != null) {
            string = yP_Row3.getFieldStringValueByName("groupName");
        }
        if (yP_Row != null) {
            super.dealParameterUpdate(yP_Row);
        }
        if ((yP_Row2 = this.group.getRowByPrimaryKey(l)) != null) {
            string2 = yP_Row2.getFieldStringValueByName("groupName");
        }
        try {
            yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainerGroup", string);
            if (yP_TCD_DataContainer == null) {
                this.logger(2, "dealGroupUpdate() unable to get data container for: " + string);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealGroupUpdate() unable to get data container for: " + string + " " + exception);
            return -1;
        }
        if (string != null && string2 != null && string2.contentEquals(string)) {
            if (yP_TCD_DataContainer instanceof YP_TCD_DCC_Group) {
                ((YP_TCD_DCC_Group)yP_TCD_DataContainer).setGroupRow(yP_Row2);
            }
            return 1;
        }
        this.logger(2, "dealGroupUpdate() Not really possible on group: " + string + " " + string2);
        yP_TCD_DataContainer.shutdown();
        return this.loadGroupByPrimaryKey(l) == null ? -1 : 1;
    }

    private int dealBrandUpdate(YP_Row yP_Row, long l) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        YP_Row yP_Row2;
        String string = null;
        String string2 = null;
        YP_Row yP_Row3 = this.brand.getRowByPrimaryKey(l);
        if (yP_Row3 != null) {
            string = this.getApplicationIdentifier(yP_Row3);
        }
        if (yP_Row != null) {
            super.dealParameterUpdate(yP_Row);
        }
        if ((yP_Row2 = this.brand.getRowByPrimaryKey(l)) != null) {
            string2 = this.getApplicationIdentifier(yP_Row2);
        }
        try {
            yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
            if (yP_TCD_DataContainer == null) {
                this.logger(2, "dealBrandUpdate() unable to get data container for: " + string);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealBrandUpdate() unable to get data container for: " + string + " " + exception);
            return -1;
        }
        if (string != null && string2 != null && string2.contentEquals(string)) {
            if (yP_TCD_DataContainer instanceof YP_TCD_DCC_Brand) {
                ((YP_TCD_DCC_Brand)yP_TCD_DataContainer).setBrandRow(yP_Row2);
            }
            return 1;
        }
        this.logger(2, "dealBrandUpdate() Not really possible on brand: " + string + " " + string2);
        yP_TCD_DataContainer.shutdown();
        return this.loadBrandByPrimaryKey(l) == null ? -1 : 1;
    }

    private int dealMerchantUpdate(YP_Row yP_Row, long l) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        YP_Row yP_Row2;
        String string = null;
        String string2 = null;
        YP_Row yP_Row3 = this.merchant.getRowByPrimaryKey(l);
        if (yP_Row3 != null) {
            string = this.getApplicationIdentifier(yP_Row3);
        }
        if (yP_Row != null) {
            super.dealParameterUpdate(yP_Row);
        }
        if ((yP_Row2 = this.merchant.getRowByPrimaryKey(l)) != null) {
            string2 = this.getApplicationIdentifier(yP_Row2);
        }
        try {
            yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
            if (yP_TCD_DataContainer == null) {
                this.logger(2, "dealMerchantUpdate() unable to get data container for: " + string);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealMerchantUpdate() unable to get data container for: " + string + " " + exception);
            return -1;
        }
        if (string != null && string2 != null && string2.contentEquals(string)) {
            if (yP_TCD_DataContainer instanceof YP_TCD_DCC_Merchant) {
                ((YP_TCD_DCC_Merchant)yP_TCD_DataContainer).setMerchantRow(yP_Row2);
            }
            return 1;
        }
        this.logger(2, "dealMerchantUpdate() Not really possible on merchant: " + string + " " + string2);
        yP_TCD_DataContainer.shutdown();
        return this.loadMerchantByPrimaryKey(l) == null ? -1 : 1;
    }

    private int dealContractUpdate(YP_Row yP_Row, long l) {
        YP_TCD_DataContainer yP_TCD_DataContainer;
        YP_Row yP_Row2;
        String string = null;
        String string2 = null;
        YP_Row yP_Row3 = this.contract.getRowByPrimaryKey(l);
        if (yP_Row3 != null) {
            string = this.getApplicationIdentifier(yP_Row3);
        }
        if (yP_Row != null) {
            super.dealParameterUpdate(yP_Row);
        }
        if ((yP_Row2 = this.contract.getRowByPrimaryKey(l)) != null) {
            string2 = this.getApplicationIdentifier(yP_Row2);
        }
        try {
            yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
            if (yP_TCD_DataContainer == null) {
                this.logger(2, "dealContractUpdate() unable to get data container for: " + string);
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealContractUpdate() unable to get data container for: " + string + " " + exception);
            return -1;
        }
        if (string != null && string2 != null && string2.contentEquals(string)) {
            InitializationStatusEnumeration initializationStatusEnumeration;
            if (yP_TCD_DataContainer instanceof YP_TCD_DCC_Business) {
                ((YP_TCD_DCC_Business)yP_TCD_DataContainer).setContractRow(yP_Row2);
                try {
                    int n = (Integer)yP_Row2.getFieldValueByName("satisfactionIndex");
                    if (n > 0) {
                        ((YP_TCD_DCC_Business)yP_TCD_DataContainer).setSatisfactionIndex(n);
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "dealContractUpdate() Issue with satisfactionIndex");
                }
            }
            if ((initializationStatusEnumeration = (InitializationStatusEnumeration)((Object)yP_Row2.getFieldValueByName("initializationStatus"))) == InitializationStatusEnumeration.DELETED) {
                yP_TCD_DataContainer.shutdown();
            }
            return 1;
        }
        yP_TCD_DataContainer.shutdown();
        return this.loadContractByPrimaryKey(l) == null ? -1 : 1;
    }

    @Override
    public int dealParameterUpdate(YP_Row yP_Row) {
        block31: {
            String string = yP_Row.getFieldStringValueByName("DB_Table");
            if (string == null) {
                this.logger(2, "dealParameterUpdate() DB_Table not found...");
                return -1;
            }
            if (string.compareTo(this.connector.getTableName()) == 0) {
                this.logger(2, "dealParameterUpdate() TODO: chercher si une application a ete initialisee avec ce connecteur...");
                return super.dealParameterUpdate(yP_Row);
            }
            if (string.compareTo(this.application.getTableName()) == 0) {
                super.dealParameterUpdate(yP_Row);
                return this.reloadMasterApplications();
            }
            long l = (Long)yP_Row.getFieldValueByName("primaryKeyValue");
            if (l <= 0L) {
                this.logger(2, "dealParameterUpdate() bad value of primaryKeyValue");
                return -1;
            }
            String string2 = yP_Row.getFieldStringValueByName("changeType");
            if (string2 == null) {
                this.logger(2, "dealParameterUpdate() changeType not found...");
                return -1;
            }
            if (string.compareTo(this.brand.getTableName()) == 0 || string.compareTo(this.merchant.getTableName()) == 0 || string.compareTo(this.contract.getTableName()) == 0) {
                if (string2.compareTo("DELETE") == 0) {
                    if (string.contentEquals(this.brand.getTableName())) {
                        this.shutdownBrandByPrimaryKey(l);
                    } else if (string.contentEquals(this.merchant.getTableName())) {
                        this.shutdownMerchantByPrimaryKey(l);
                    } else {
                        this.shutdownContractByPrimaryKey(l);
                    }
                    return super.dealParameterUpdate(yP_Row);
                }
                if (string2.compareTo("INSERT") == 0) {
                    super.dealParameterUpdate(yP_Row);
                    if (string.contentEquals(this.brand.getTableName())) {
                        return this.loadBrandByPrimaryKey(l) == null ? -1 : 1;
                    }
                    if (string.contentEquals(this.merchant.getTableName())) {
                        return this.loadMerchantByPrimaryKey(l) == null ? -1 : 1;
                    }
                    return this.loadContractByPrimaryKey(l) == null ? -1 : 1;
                }
                if (string2.compareTo("UPDATE") == 0) {
                    if (string.contentEquals(this.brand.getTableName())) {
                        return this.dealBrandUpdate(yP_Row, l);
                    }
                    if (string.contentEquals(this.merchant.getTableName())) {
                        return this.dealMerchantUpdate(yP_Row, l);
                    }
                    if (string.contentEquals(this.contract.getTableName())) {
                        return this.dealContractUpdate(yP_Row, l);
                    }
                    this.logger(2, "dealParameterUpdate() not posible...");
                    return -1;
                }
                this.logger(2, "dealParameterUpdate() changeType unknown...");
                return -1;
            }
            if (!string.contentEquals(this.group.getTableName())) break block31;
            switch (string2) {
                case "DELETE": {
                    this.shutdownGroupByPrimaryKey(l);
                    return super.dealParameterUpdate(yP_Row);
                }
                case "INSERT": {
                    super.dealParameterUpdate(yP_Row);
                    return this.loadGroupByPrimaryKey(l) == null ? -1 : 1;
                }
                case "UPDATE": {
                    return this.dealGroupUpdate(yP_Row, l);
                }
            }
            this.logger(2, "dealParameterUpdate() changeType unknown...");
            return -1;
        }
        return super.dealParameterUpdate(yP_Row);
    }

    public List<YP_TCD_DataBaseConnector> getDataBaseConnectorListForEvent() {
        if (this.dataBaseConnectorListForEvent != null) {
            return this.dataBaseConnectorListForEvent;
        }
        this.dataBaseConnectorListForEvent = new ArrayList<YP_TCD_DataBaseConnector>();
        for (YP_Row yP_Row : this.connector) {
            try {
                Boolean bl = (Boolean)yP_Row.getFieldValueByName("checkForEvent");
                if (bl == null || !bl.booleanValue()) continue;
                YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = (YP_TCD_DataBaseConnector)this.newPluginByName(yP_Row.getFieldStringValueByName("connector_Plugin"), yP_Row);
                yP_TCD_DataBaseConnector.setDataBaseName("events");
                yP_TCD_DataBaseConnector.initialize();
                this.dataBaseConnectorListForEvent.add(yP_TCD_DataBaseConnector);
            }
            catch (Exception exception) {
                this.logger(2, "loadContract() No dataBaseConnector for server " + exception);
                return null;
            }
        }
        return this.dataBaseConnectorListForEvent;
    }

    public YP_Row getTerminalReferenceRow(String string, String string2) {
        List<YP_Row> list;
        block5: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalReference);
                yP_ComplexGabarit.set("model", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("appCBTerminalVersion", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string2);
                yP_ComplexGabarit.set("appCBTerminalVersion", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                list = this.terminalReference.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block5;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getTerminalReferenceRow() not found:" + string);
                }
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getTerminalReferenceRow() " + exception);
                }
                return null;
            }
        }
        return list.get(0);
    }

    public long getTerminalReferenceRowId(String string, String string2) {
        YP_Row yP_Row;
        block4: {
            try {
                yP_Row = this.getTerminalReferenceRow(string, string2);
                if (yP_Row != null) break block4;
                return -1L;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getTerminalReferenceRowId() " + exception);
                }
                return -1L;
            }
        }
        return yP_Row.getPrimaryKey();
    }

    public YP_Row getTerminalReferenceRow(long l) {
        try {
            return this.terminalReference.getRowByPrimaryKey(l);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTerminalReferenceRow() " + exception);
            }
            return null;
        }
    }

    private int loadTableStatus() {
        List<YP_Row> list;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationTableInfo);
        yP_ComplexGabarit.set(this.applicationTableInfo.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_ASC);
        int n = 0;
        do {
            if ((list = this.applicationTableInfo.getRowListSuchAs(n, 10000, yP_ComplexGabarit)) == null) {
                return -1;
            }
            n += 10000;
            for (YP_Row yP_Row : list) {
                String string = yP_Row.getFieldStringValueByName("schemaName");
                List<YP_Row> list2 = this.tableStatusMap.get(string);
                if (list2 == null) {
                    list2 = new ArrayList<YP_Row>();
                    this.tableStatusMap.put(string, list2);
                }
                list2.add(yP_Row);
            }
        } while (list.size() == 10000);
        return 1;
    }

    @Override
    public int retrieveTableStatus(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        List<YP_Row> list;
        yP_TCD_DesignAccesObject.setTableStatusRetrieved(true);
        if (yP_TCD_DesignAccesObject.getTableName().contentEquals("TableList")) {
            return 0;
        }
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "retrieveTableStatus() meaningless for a transaction table");
            }
            return 0;
        }
        String string = yP_TCD_DesignAccesObject.getDataContainerContext().getContractIdentifier();
        if (string != null && string.contentEquals("KERNEL")) {
            string = "management";
        }
        if ((list = this.tableStatusMap.get(string)) == null) {
            list = new ArrayList<YP_Row>();
            this.tableStatusMap.put(string, list);
        }
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationTableInfo);
            yP_ComplexGabarit.set("schemaName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("tableName", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DesignAccesObject.getTableName());
            List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
            if (list2 != null && list2.size() > 0) {
                yP_TCD_DesignAccesObject.setTableSystemGMTTime((Timestamp)list2.get(0).getFieldValueByName("tableSystemGMTTime"));
                yP_TCD_DesignAccesObject.setTableVersion(list2.get(0).getFieldStringValueByName("tableVersion"));
                yP_TCD_DesignAccesObject.setTableCksum(list2.get(0).getFieldStringValueByName("tableCksum"));
                yP_TCD_DesignAccesObject.setTableStatus((TableStatusEnumeration)((Object)list2.get(0).getFieldValueByName("tableStatus")));
                yP_TCD_DesignAccesObject.setTableAckMessage((Integer)list2.get(0).getFieldValueByName("tableAckMessage"));
                if (yP_TCD_DesignAccesObject.getTableNumber() != ((Integer)list2.get(0).getFieldValueByName("tableNumber")).intValue()) {
                    yP_TCD_DesignAccesObject.setDefaultStatus();
                    this.updateTableStatus(yP_TCD_DesignAccesObject);
                }
            } else {
                yP_TCD_DesignAccesObject.setDefaultStatus();
                this.updateTableStatus(yP_TCD_DesignAccesObject);
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "retrieveTableStatus() " + exception);
            }
            return -1;
        }
    }

    @Override
    public int updateTableStatus(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (this.applicationTableInfo == null || yP_TCD_DesignAccesObject == null) {
            return 0;
        }
        if (yP_TCD_DesignAccesObject.getTableName().contentEquals("TableList")) {
            return 0;
        }
        if (yP_TCD_DesignAccesObject == this.applicationTableInfo) {
            return 0;
        }
        if (yP_TCD_DesignAccesObject.getTableName().contentEquals(this.applicationTableInfo.getTableName())) {
            return 0;
        }
        if ((4 & yP_TCD_DesignAccesObject.getTableType()) != 0) {
            return 0;
        }
        if ((2 & yP_TCD_DesignAccesObject.getTableType()) != 0) {
            return 0;
        }
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            return 0;
        }
        yP_TCD_DesignAccesObject.setDefaultStatus();
        String string = yP_TCD_DesignAccesObject.getDataContainerContext().getContractIdentifier();
        if (string != null && string.contentEquals("KERNEL")) {
            string = "management";
        }
        try {
            List<YP_Row> list = this.tableStatusMap.get(string);
            if (list == null) {
                list = new ArrayList<YP_Row>();
                this.tableStatusMap.put(string, list);
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationTableInfo);
            yP_ComplexGabarit.set("schemaName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("tableName", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DesignAccesObject.getTableName());
            List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
            if (list2 != null && list2.size() > 0) {
                YP_Row yP_Row = list2.get(0);
                yP_Row.set("tableSystemGMTTime", yP_TCD_DesignAccesObject.getTableSystemGMTTime());
                yP_Row.set("tableVersion", yP_TCD_DesignAccesObject.getTableVersion());
                yP_Row.set("tableCksum", yP_TCD_DesignAccesObject.getTableCksum());
                yP_Row.set("tableStatus", yP_TCD_DesignAccesObject.getTableStatus());
                yP_Row.set("tableAckMessage", yP_TCD_DesignAccesObject.getTableAckMessage());
                yP_Row.set("tableNumber", yP_TCD_DesignAccesObject.getTableNumber());
                yP_Row.persist();
            } else {
                yP_TCD_DesignAccesObject.setTableStatusRetrieved(true);
                YP_Row yP_Row = this.applicationTableInfo.getNewRow();
                list.add(yP_Row);
                yP_Row.set("schemaName", string);
                yP_Row.set("tableName", yP_TCD_DesignAccesObject.getTableName());
                yP_Row.set("tableSystemGMTTime", yP_TCD_DesignAccesObject.getTableSystemGMTTime());
                yP_Row.set("tableVersion", yP_TCD_DesignAccesObject.getTableVersion());
                yP_Row.set("tableCksum", yP_TCD_DesignAccesObject.getTableCksum());
                yP_Row.set("tableStatus", yP_TCD_DesignAccesObject.getTableStatus());
                yP_Row.set("tableAckMessage", yP_TCD_DesignAccesObject.getTableAckMessage());
                yP_Row.set("tableNumber", yP_TCD_DesignAccesObject.getTableNumber());
                yP_Row.setIsItAClonedRow(false);
                yP_Row.persist();
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateTableStatus()" + exception);
            }
            return -1;
        }
    }

    public Timestamp getLastApplicationEventTimeFromTableInfos() {
        Timestamp timestamp = null;
        if (this.applicationTableInfo == null) {
            this.logger(2, "getLastApplicationEventTimeFromTableInfos() applicationTableInfo is null !!!");
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationTableInfo);
        yP_ComplexGabarit.set("schemaName", YP_ComplexGabarit.OPERATOR.DIFFERENT, "management");
        yP_ComplexGabarit.set("tableSystemGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.applicationTableInfo.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null && !list.isEmpty()) {
            timestamp = (Timestamp)list.get(0).getFieldValueByName("tableSystemGMTTime");
        }
        if (timestamp == null) {
            timestamp = new Timestamp(0L);
        }
        return timestamp;
    }

    public List<YP_Row> getNewerApplicationEventsFromTableInfos(Timestamp timestamp, List<YP_Row> list) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationTableInfo);
        yP_ComplexGabarit.set("schemaName", YP_ComplexGabarit.OPERATOR.DIFFERENT, "management");
        yP_ComplexGabarit.set("tableSystemGMTTime", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, timestamp);
        yP_ComplexGabarit.set("tableSystemGMTTime", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list2 = this.applicationTableInfo.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null) {
            for (YP_Row yP_Row : list) {
                int n = 0;
                while (n < list2.size()) {
                    if (list2.get(n).getPrimaryKey() == yP_Row.getPrimaryKey() && ((Timestamp)list2.get(n).getFieldValueByName("tableSystemGMTTime")).getTime() == timestamp.getTime()) {
                        list2.remove(n);
                    }
                    ++n;
                }
            }
        }
        return list2;
    }

    public Set<String> getParameters(YP_TCD_DC_Context yP_TCD_DC_Context, Object ... objectArray) {
        HashSet<String> hashSet = new HashSet<String>();
        List<YP_Row> list = this.getParametersList(yP_TCD_DC_Context, objectArray);
        if (list != null && !list.isEmpty()) {
            List<Long> list2 = null;
            for (YP_Row yP_Row : list) {
                long l;
                String string;
                long l2 = (Long)yP_Row.getFieldValueByName("idStore");
                if (l2 > 0L && yP_TCD_DC_Context instanceof YP_TCD_DCC_Business) {
                    if (list2 == null) {
                        list2 = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getDataContainerMerchant().getDataContainerBrand().getIdStoreListByContract(((YP_TCD_DCC_Business)yP_TCD_DC_Context).getIDContract());
                    }
                    if (list2 != null && !list2.contains(l2)) continue;
                }
                if ((string = yP_Row.getFieldStringValueByName("value")).isEmpty() && (l = ((Long)yP_Row.getFieldValueByName("idUser")).longValue()) != 0L) {
                    string = Long.toString(l);
                }
                hashSet.add(string);
            }
        }
        return hashSet;
    }

    public boolean setParameter(YP_TCD_DC_Context yP_TCD_DC_Context, String string, String string2) {
        long l;
        long l2;
        long l3;
        long l4;
        block11: {
            l4 = 0L;
            l3 = 0L;
            l2 = 0L;
            l = 0L;
            if (yP_TCD_DC_Context == null) break block11;
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Business) {
                l4 = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getIDContract();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Merchant) {
                l3 = ((YP_TCD_DCC_Merchant)yP_TCD_DC_Context).getIDMerchant();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Brand) {
                l2 = ((YP_TCD_DCC_Brand)yP_TCD_DC_Context).getIDBrand();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Group) {
                l = ((YP_TCD_DCC_Group)yP_TCD_DC_Context).getIDGroup();
                break block11;
            }
            this.logger(2, "setParameter() unknown datacontainer");
            return false;
        }
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l4);
            yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
            List<YP_Row> list = this.mgtParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) {
                if (list.size() > 1) {
                    this.logger(2, "setParameter() too many found for " + string);
                }
                for (YP_Row yP_Row : list) {
                    yP_Row.set("value", string2);
                    yP_Row.persist();
                }
            } else {
                YP_Row yP_Row = this.mgtParameters.getNewRow();
                yP_Row.set("idContract", l4);
                yP_Row.set("idMerchant", l3);
                yP_Row.set("idBrand", l2);
                yP_Row.set("idGroup", l);
                yP_Row.set("key", string);
                yP_Row.set("value", string2);
                this.mgtParameters.addRow(yP_Row);
                this.mgtParameters.persist();
            }
        }
        catch (Exception exception) {
            this.logger(2, "setParameter() " + exception);
            return false;
        }
        return true;
    }

    public boolean deleteParameter(YP_TCD_DC_Context yP_TCD_DC_Context, String string) {
        long l;
        long l2;
        long l3;
        long l4;
        block11: {
            l4 = 0L;
            l3 = 0L;
            l2 = 0L;
            l = 0L;
            if (yP_TCD_DC_Context == null) break block11;
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Business) {
                l4 = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getIDContract();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Merchant) {
                l3 = ((YP_TCD_DCC_Merchant)yP_TCD_DC_Context).getIDMerchant();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Brand) {
                l2 = ((YP_TCD_DCC_Brand)yP_TCD_DC_Context).getIDBrand();
                break block11;
            }
            if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Group) {
                l = ((YP_TCD_DCC_Group)yP_TCD_DC_Context).getIDGroup();
                break block11;
            }
            this.logger(2, "deleteParameter() unknown datacontainer");
            return false;
        }
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l4);
            yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
            List<YP_Row> list = this.mgtParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) {
                if (list.size() > 1) {
                    this.logger(2, "deleteParameter() too many found for " + string);
                }
                for (YP_Row yP_Row : list) {
                    yP_Row.delete();
                    yP_Row.persist();
                }
            } else {
                this.logger(2, "deleteParameter() no parameter found " + string);
            }
        }
        catch (Exception exception) {
            this.logger(2, "deleteParameter() " + exception);
            return false;
        }
        return true;
    }

    public Map<String, Set<String>> getParametersMap(YP_TCD_DC_Context yP_TCD_DC_Context, Object ... objectArray) {
        HashMap<String, Set<String>> hashMap = new HashMap<String, Set<String>>();
        List<YP_Row> list = this.getParametersList(yP_TCD_DC_Context, objectArray);
        if (list != null && !list.isEmpty()) {
            for (YP_Row yP_Row : list) {
                String string;
                HashSet<String> hashSet;
                long l;
                String string2 = yP_Row.getFieldStringValueByName("value");
                if (string2.isEmpty() && (l = ((Long)yP_Row.getFieldValueByName("idUser")).longValue()) != 0L) {
                    string2 = Long.toString(l);
                }
                if ((hashSet = (HashSet<String>)hashMap.get(string = yP_Row.getFieldStringValueByName("key"))) == null) {
                    hashSet = new HashSet<String>();
                    hashMap.put(string, hashSet);
                }
                hashSet.add(string2);
            }
        }
        return hashMap;
    }

    private List<YP_Row> getParametersList(YP_TCD_DC_Context yP_TCD_DC_Context, Object ... objectArray) {
        List<YP_Row> list;
        long l;
        long l2 = 0L;
        long l3 = 0L;
        if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Business) {
            l2 = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getIDContract();
            l3 = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getDataContainerMerchant().getIDMerchant();
            l = ((YP_TCD_DCC_Business)yP_TCD_DC_Context).getDataContainerMerchant().getDataContainerBrand().getIDBrand();
        } else if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Merchant) {
            l3 = ((YP_TCD_DCC_Merchant)yP_TCD_DC_Context).getIDMerchant();
            l = ((YP_TCD_DCC_Merchant)yP_TCD_DC_Context).getDataContainerBrand().getIDBrand();
        } else if (yP_TCD_DC_Context instanceof YP_TCD_DCC_Brand) {
            l = ((YP_TCD_DCC_Brand)yP_TCD_DC_Context).getIDBrand();
        } else {
            this.logger(2, "getParametersList() bad container");
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = null;
        List<Long> list2 = this.getGroupIDs(l);
        if (list2 != null && !list2.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)list2);
            yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit2.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit2.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
        YP_ComplexGabarit yP_ComplexGabarit3 = null;
        YP_ComplexGabarit yP_ComplexGabarit4 = null;
        if (l3 != 0L) {
            yP_ComplexGabarit3 = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit3.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
            yP_ComplexGabarit3.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
            if (l2 != 0L) {
                yP_ComplexGabarit4 = new YP_ComplexGabarit(this.mgtParameters);
                yP_ComplexGabarit4.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
                yP_ComplexGabarit4.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
            }
        }
        YP_ComplexGabarit yP_ComplexGabarit5 = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit5.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
        yP_ComplexGabarit5.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit5.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit5.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit5.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit5.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        ArrayList<YP_ComplexGabarit> arrayList = new ArrayList<YP_ComplexGabarit>();
        arrayList.add(yP_ComplexGabarit5);
        arrayList.add(yP_ComplexGabarit2);
        if (yP_ComplexGabarit4 != null) {
            arrayList.add(yP_ComplexGabarit4);
        }
        if (yP_ComplexGabarit3 != null) {
            arrayList.add(yP_ComplexGabarit3);
        }
        if (yP_ComplexGabarit != null) {
            arrayList.add(yP_ComplexGabarit);
        }
        if ((list = this.mgtParameters.getRowListSuchAs(arrayList.toArray(new YP_ComplexGabarit[arrayList.size()]))) == null) {
            this.logger(2, "getParametersList() null list");
            return null;
        }
        if (list.isEmpty()) {
            return list;
        }
        return this.orderParametersList(list);
    }

    private List<YP_Row> orderParametersList(List<YP_Row> list) {
        class IndiceList {
            final List<YP_Row> list = new ArrayList<YP_Row>();
            int indice;

            public IndiceList(int n, YP_Row yP_Row) {
                this.indice = n;
                this.list.add(yP_Row);
            }
        }
        HashMap<String, IndiceList> hashMap = new HashMap<String, IndiceList>();
        for (YP_Row object : list) {
            String string;
            IndiceList indiceList;
            int n = 0;
            if (((DAO_MgtParameters)object).idGroup != 0L) {
                ++n;
            }
            if (((DAO_MgtParameters)object).idBrand != 0L) {
                n += 10;
            }
            if (((DAO_MgtParameters)object).idMerchant != 0L) {
                n += 100;
            }
            if (((DAO_MgtParameters)object).idStore != 0L) {
                n += 1000;
            }
            if (((DAO_MgtParameters)object).idContract != 0L) {
                n += 10000;
            }
            if (((DAO_MgtParameters)object).idUser != 0L) {
                n += 100000;
            }
            if ((indiceList = (IndiceList)hashMap.get(string = YP_Row.getStringValue(((DAO_MgtParameters)object).key))) == null) {
                hashMap.put(string, new IndiceList(n, object));
                continue;
            }
            if (n < indiceList.indice) {
                n = 1;
                continue;
            }
            if (n == indiceList.indice) {
                indiceList.list.add(object);
                continue;
            }
            indiceList.list.clear();
            indiceList.indice = n;
            indiceList.list.add(object);
        }
        list.clear();
        for (Map.Entry entry : hashMap.entrySet()) {
            list.addAll(((IndiceList)entry.getValue()).list);
        }
        return list;
    }

    public List<YP_Row> getUserParameters(long l, Object ... objectArray) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.IN, objectArray);
        return this.mgtParameters.getRowListSuchAs(yP_ComplexGabarit);
    }

    public boolean setUserParameter(long l, String string, String string2) {
        try {
            List<YP_Row> list = this.getUserParameters(l, string);
            if (list != null && !list.isEmpty()) {
                if (list.size() > 1) {
                    this.logger(2, "setUserParameter() too many found for " + string);
                }
                for (YP_Row yP_Row : list) {
                    yP_Row.set("value", string2);
                    yP_Row.persist();
                }
            } else {
                YP_Row yP_Row = this.mgtParameters.getNewRow();
                yP_Row.set("idUser", l);
                yP_Row.set("key", string);
                yP_Row.set("value", string2);
                this.mgtParameters.addRow(yP_Row);
                this.mgtParameters.persist();
            }
        }
        catch (Exception exception) {
            this.logger(2, "setUserParameter() " + exception);
            return false;
        }
        return true;
    }

    public boolean deleteUserParameter(long l, String string) {
        block3: {
            List<YP_Row> list;
            block4: {
                try {
                    list = this.getUserParameters(l, string);
                    if (list == null || list.isEmpty()) break block3;
                    if (list.size() <= 1) break block4;
                    this.logger(2, "deleteUserParameter() too many found for " + string);
                    return false;
                }
                catch (Exception exception) {
                    this.logger(2, "deleteUserParameter() " + exception);
                    return false;
                }
            }
            YP_Row yP_Row = list.get(0);
            this.mgtParameters.deleteRow(yP_Row);
            this.mgtParameters.persist();
        }
        return true;
    }

    /*
     * WARNING - void declaration
     */
    private List<YP_Row> getMerchantPropertiesList(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, String string, long l) {
        List<YP_Row> list;
        void var7_9;
        ArrayList<Long> arrayList = new ArrayList<Long>();
        for (YP_TCD_DCC_Business object2 : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
            arrayList.add(object2.getIDContract());
        }
        Object var7_7 = null;
        List<Long> list2 = this.getGroupIDs(yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
        if (list2 != null && !list2.isEmpty()) {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)list2);
            yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit2.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DCC_Merchant.getIDMerchant());
        yP_ComplexGabarit2.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0L);
        yP_ComplexGabarit2.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        YP_ComplexGabarit yP_ComplexGabarit3 = null;
        if (!arrayList.isEmpty()) {
            yP_ComplexGabarit3 = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit3.set("idContract", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
            yP_ComplexGabarit3.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        }
        YP_ComplexGabarit yP_ComplexGabarit4 = new YP_ComplexGabarit(this.mgtParameters);
        yP_ComplexGabarit4.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        yP_ComplexGabarit4.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit4.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit4.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit4.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit4.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        YP_ComplexGabarit yP_ComplexGabarit5 = null;
        if (l > 0L) {
            yP_ComplexGabarit5 = new YP_ComplexGabarit(this.mgtParameters);
            yP_ComplexGabarit5.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit5.set("key", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        }
        ArrayList<Object> arrayList2 = new ArrayList<Object>();
        arrayList2.add(yP_ComplexGabarit4);
        arrayList2.add(yP_ComplexGabarit);
        arrayList2.add(yP_ComplexGabarit2);
        if (yP_ComplexGabarit3 != null) {
            arrayList2.add(yP_ComplexGabarit3);
        }
        if (var7_9 != null) {
            arrayList2.add(var7_9);
        }
        if (yP_ComplexGabarit5 != null) {
            arrayList2.add(yP_ComplexGabarit5);
        }
        if ((list = this.mgtParameters.getRowListSuchAs(arrayList2.toArray(new YP_ComplexGabarit[arrayList2.size()]))) == null) {
            this.logger(2, "getMerchantPropertiesList() null list");
            return null;
        }
        if (list.isEmpty()) {
            return list;
        }
        return this.orderParametersList(list);
    }

    @Deprecated
    public List<Property> getMerchantProperties(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, String string) {
        ArrayList<Property> arrayList = new ArrayList<Property>();
        List<YP_Row> list = this.getMerchantPropertiesList(yP_TCD_DCC_Merchant, string, 0L);
        if (list != null && !list.isEmpty()) {
            for (YP_Row yP_Row : list) {
                String string2 = yP_Row.getFieldStringValueByName("value");
                String string3 = yP_Row.getFieldStringValueByName("key");
                arrayList.add(new Property(string3, string2));
            }
        }
        return arrayList;
    }

    public List<Property> getMerchantProperties(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, String string, String string2) {
        long l = 0L;
        if (string2 != null && !string2.isEmpty()) {
            l = yP_TCD_DCC_Merchant.getDataContainerBrand().getIdStore(yP_TCD_DCC_Merchant.getIDMerchant(), string2);
        }
        ArrayList<Property> arrayList = new ArrayList<Property>();
        List<YP_Row> list = this.getMerchantPropertiesList(yP_TCD_DCC_Merchant, string, l);
        if (list != null && !list.isEmpty()) {
            for (YP_Row yP_Row : list) {
                String string3 = yP_Row.getFieldStringValueByName("value");
                String string4 = yP_Row.getFieldStringValueByName("key");
                arrayList.add(new Property(string4, string3));
            }
        }
        return arrayList;
    }

    public YP_Row getTerminalConfigRow(long l) {
        try {
            return this.terminalConfig.getRowByPrimaryKey(l);
        }
        catch (Exception exception) {
            this.logger(2, "getTerminalConfigRow() " + exception);
            return null;
        }
    }

    public long getIDTerminalConfig(YP_Transaction yP_Transaction, boolean bl, long l) {
        YP_Row yP_Row = this.getTerminalConfig(yP_Transaction, bl, l);
        if (yP_Row == null) {
            return -1L;
        }
        long l2 = (Long)yP_Row.getFieldValueByName("idTerminalConfig");
        return l2;
    }

    public YP_Row getTerminalConfig(YP_Transaction yP_Transaction, boolean bl, long l) {
        List<Long> list2;
        YP_Row object = null;
        ArrayList<Long> arrayList = new ArrayList<Long>();
        arrayList.add(0L);
        ArrayList<Long> arrayList2 = new ArrayList<Long>();
        arrayList2.add(0L);
        List<YP_TCD_DCC_Brand> list3 = yP_Transaction.getBrandList(false);
        if (list3.size() == 1) {
            long l2 = list3.get(0).getIDBrand();
            arrayList2.add(l2);
            list2 = this.getGroupIDs(l2);
            if (list2 != null && !list2.isEmpty()) {
                arrayList.addAll(list2);
            }
        }
        ArrayList<Long> arrayList3 = new ArrayList<Long>();
        arrayList3.add(0L);
        List<YP_TCD_DCC_Merchant> list4 = yP_Transaction.getMerchantList();
        if (list4.size() == 1) {
            arrayList3.add(list4.get(0).getIDMerchant());
        }
        list2 = new ArrayList<Long>();
        list2.add(0L);
        list2.add(yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalConfig);
        yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList2);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList3);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.IN, (Object)list2);
        yP_ComplexGabarit.set("idTerminalReference", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("testVersion", YP_ComplexGabarit.OPERATOR.EQUAL, bl);
        List<YP_Row> list5 = this.terminalConfig.getRowListSuchAs(yP_ComplexGabarit);
        if (list5 == null) {
            this.logger(2, "getTerminalConfig() null list");
            return null;
        }
        if (list5.isEmpty()) {
            return null;
        }
        class IndiceList {
            final List<YP_Row> list = new ArrayList<YP_Row>();
            int indice;

            public IndiceList(int n, YP_Row yP_Row) {
                this.indice = n;
                this.list.add(yP_Row);
            }
        }
        IndiceList indiceList = null;
        for (YP_Row yP_Row : list5) {
            int n = 0;
            if (((DAO_TerminalConfig)yP_Row).idGroup > 0L) {
                ++n;
            }
            if (((DAO_TerminalConfig)yP_Row).idBrand > 0L) {
                n += 10;
            }
            if (((DAO_TerminalConfig)yP_Row).idMerchant > 0L) {
                n += 100;
            }
            if (((DAO_TerminalConfig)yP_Row).idUser > 0L) {
                n += 1000;
            }
            try {
                TerminalConfigStatusEnumeration terminalConfigStatusEnumeration = this.getTerminalConfigStatus(yP_Transaction, yP_Row.getPrimaryKey());
                if (terminalConfigStatusEnumeration == TerminalConfigStatusEnumeration.INACTIVE) {
                    n = 0;
                }
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalConfig() while checking inactive configs" + exception);
            }
            if (indiceList == null) {
                indiceList = new IndiceList(n, yP_Row);
                continue;
            }
            if (n < indiceList.indice) {
                n = 1;
                continue;
            }
            if (n == indiceList.indice) {
                indiceList.list.add(yP_Row);
                continue;
            }
            indiceList.list.clear();
            indiceList.indice = n;
            indiceList.list.add(yP_Row);
        }
        list5.clear();
        list5.addAll(indiceList.list);
        ArrayList<Long> arrayList4 = new ArrayList<Long>();
        for (YP_Row yP_Row : list5) {
            arrayList4.add(yP_Row.getPrimaryKey());
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalConfigStatus);
        yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList2);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList3);
        yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TerminalConfigStatusEnumeration.DEFAULT, TerminalConfigStatusEnumeration.ACTIVE});
        yP_ComplexGabarit.set("idTerminalConfig", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList4);
        List<YP_Row> list = this.terminalConfigStatus.getRowListSuchAs(yP_ComplexGabarit);
        indiceList = null;
        for (YP_Row yP_Row : list) {
            int n = 0;
            if (((DAO_TerminalConfigStatus)yP_Row).status == TerminalConfigStatusEnumeration.DEFAULT) {
                ++n;
            }
            if (((DAO_TerminalConfigStatus)yP_Row).idGroup != 0L) {
                n += 10;
            }
            if (((DAO_TerminalConfigStatus)yP_Row).idBrand != 0L) {
                n += 100;
            }
            if (((DAO_TerminalConfigStatus)yP_Row).idMerchant != 0L) {
                n += 1000;
            }
            if (indiceList == null) {
                indiceList = new IndiceList(n, yP_Row);
                continue;
            }
            if (n < indiceList.indice) {
                n = 1;
                continue;
            }
            if (n == indiceList.indice) {
                indiceList.list.add(yP_Row);
                continue;
            }
            indiceList.list.clear();
            indiceList.indice = n;
            indiceList.list.add(yP_Row);
        }
        list.clear();
        if (indiceList != null) {
            list.addAll(indiceList.list);
        }
        if (list.size() > 1) {
            this.logger(2, "getTerminalConfig() too many status found for " + l);
        }
        if (list.isEmpty()) {
            if (list5.size() > 1) {
                this.logger(2, "getTerminalConfig() too many config found for  " + l);
            }
            object = list5.get(0);
        } else {
            YP_Row yP_Row = list.get(0);
            for (YP_Row yP_Row2 : list5) {
                if (((Long)yP_Row2.getFieldValueByName("idTerminalConfig")).longValue() != ((Long)yP_Row.getFieldValueByName("idTerminalConfig")).longValue()) continue;
                object = yP_Row2;
                break;
            }
        }
        return object;
    }

    public List<YP_Row> getTerminalConfigList(boolean bl, long l, long l2) {
        class IndiceList {
            final List<YP_Row> list = new ArrayList<YP_Row>();
            int indice;

            public IndiceList(int n, YP_Row yP_Row) {
                this.indice = n;
                this.list.add(yP_Row);
            }
        }
        Cloneable cloneable2;
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
        try {
            yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", l2);
            if (yP_TCD_DCC_Merchant == null) {
                this.logger(2, "getTerminalConfigList() unable to get datacontainer for idMerchant:" + l2);
                return null;
            }
        }
        catch (Exception exception) {
            this.logger(2, "getTerminalConfigList()" + exception);
            return null;
        }
        ArrayList<Long> arrayList = new ArrayList<Long>();
        arrayList.add(0L);
        ArrayList<Long> arrayList2 = new ArrayList<Long>();
        arrayList2.add(0L);
        arrayList2.add(yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
        ArrayList<Long> arrayList3 = new ArrayList<Long>();
        arrayList3.add(0L);
        arrayList3.add(yP_TCD_DCC_Merchant.getIDMerchant());
        List<Long> list = this.getGroupIDs(yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
        if (list != null && !list.isEmpty()) {
            arrayList.addAll(list);
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalConfig);
        yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit.set("idTerminalReference", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("testVersion", YP_ComplexGabarit.OPERATOR.EQUAL, bl);
        List<YP_Row> list2 = this.terminalConfig.getRowListSuchAs(yP_ComplexGabarit);
        if (list2 == null) {
            this.logger(2, "getTerminalConfig() null list");
            return null;
        }
        if (list2.isEmpty()) {
            this.logger(3, "getTerminalConfig() empty config list");
            return new ArrayList<YP_Row>();
        }
        ArrayList<Long> arrayList4 = new ArrayList<Long>();
        for (YP_Row object2 : list2) {
            arrayList4.add(object2.getPrimaryKey());
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalConfigStatus);
        yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList2);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList3);
        yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TerminalConfigStatusEnumeration.DEFAULT, TerminalConfigStatusEnumeration.ACTIVE});
        yP_ComplexGabarit.set("idTerminalConfig", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList4);
        List<YP_Row> list3 = this.terminalConfigStatus.getRowListSuchAs(yP_ComplexGabarit);
        Object object3 = null;
        for (Cloneable cloneable2 : list3) {
            int iterator = 0;
            if (((DAO_TerminalConfigStatus)cloneable2).idGroup != 0L) {
                ++iterator;
            }
            if (((DAO_TerminalConfigStatus)cloneable2).idBrand != 0L) {
                iterator += 10;
            }
            if (((DAO_TerminalConfigStatus)cloneable2).idMerchant != 0L) {
                iterator += 100;
            }
            if (object3 == null) {
                object3 = new IndiceList(iterator, (YP_Row)cloneable2);
                continue;
            }
            if (iterator < ((IndiceList)object3).indice) continue;
            if (iterator == ((IndiceList)object3).indice) {
                ((IndiceList)object3).list.add((YP_Row)cloneable2);
                continue;
            }
            ((IndiceList)object3).list.clear();
            ((IndiceList)object3).indice = iterator;
            ((IndiceList)object3).list.add((YP_Row)cloneable2);
        }
        list3.clear();
        if (object3 != null) {
            list3.addAll(((IndiceList)object3).list);
        }
        if (list3.isEmpty()) {
            this.logger(3, "getTerminalConfig() empty status list");
            return new ArrayList<YP_Row>();
        }
        cloneable2 = new ArrayList();
        block4: for (Object object : list3) {
            for (YP_Row yP_Row : list2) {
                if (((Long)yP_Row.getFieldValueByName("idTerminalConfig")).longValue() != ((Long)((YP_Row)object).getFieldValueByName("idTerminalConfig")).longValue()) continue;
                cloneable2.add(yP_Row);
                continue block4;
            }
        }
        return cloneable2;
    }

    public TerminalConfigStatusEnumeration getTerminalConfigStatus(YP_Transaction yP_Transaction, long l) {
        YP_Row yP_Row2;
        Object object;
        ArrayList<Long> arrayList = new ArrayList<Long>();
        arrayList.add(0L);
        ArrayList<Long> arrayList2 = new ArrayList<Long>();
        arrayList2.add(0L);
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList(false);
        if (list.size() == 1) {
            long l2 = list.get(0).getIDBrand();
            arrayList2.add(l2);
            object = this.getGroupIDs(l2);
            if (object != null && !object.isEmpty()) {
                arrayList.addAll((Collection<Long>)object);
            }
        }
        ArrayList<Long> arrayList3 = new ArrayList<Long>();
        arrayList3.add(0L);
        List<YP_TCD_DCC_Merchant> list2 = yP_Transaction.getMerchantList();
        if (list2.size() == 1) {
            arrayList3.add(list2.get(0).getIDMerchant());
        }
        object = new YP_ComplexGabarit(this.terminalConfigStatus);
        ((YP_ComplexGabarit)object).set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        ((YP_ComplexGabarit)object).set("idBrand", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList2);
        ((YP_ComplexGabarit)object).set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList3);
        ((YP_ComplexGabarit)object).set("idTerminalConfig", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list3 = this.terminalConfigStatus.getRowListSuchAs(new YP_ComplexGabarit[]{object});
        class IndiceList {
            final List<YP_Row> list = new ArrayList<YP_Row>();
            int indice;

            public IndiceList(int n, YP_Row yP_Row) {
                this.indice = n;
                this.list.add(yP_Row);
            }
        }
        IndiceList indiceList = null;
        for (YP_Row yP_Row2 : list3) {
            int n = 0;
            if (((DAO_TerminalConfigStatus)yP_Row2).status == TerminalConfigStatusEnumeration.DEFAULT) {
                ++n;
            }
            if (((DAO_TerminalConfigStatus)yP_Row2).idGroup != 0L) {
                n += 10;
            }
            if (((DAO_TerminalConfigStatus)yP_Row2).idBrand != 0L) {
                n += 100;
            }
            if (((DAO_TerminalConfigStatus)yP_Row2).idMerchant != 0L) {
                n += 1000;
            }
            if (indiceList == null) {
                indiceList = new IndiceList(n, yP_Row2);
                continue;
            }
            if (n < indiceList.indice) {
                n = 1;
                continue;
            }
            if (n == indiceList.indice) {
                indiceList.list.add(yP_Row2);
                continue;
            }
            indiceList.list.clear();
            indiceList.indice = n;
            indiceList.list.add(yP_Row2);
        }
        list3.clear();
        if (indiceList != null) {
            list3.addAll(indiceList.list);
        }
        if (list3.size() > 1) {
            this.logger(2, "getTerminalConfigStatus() too many status found for " + l);
            return null;
        }
        if (list3.isEmpty()) {
            return null;
        }
        yP_Row2 = list3.get(0);
        return (TerminalConfigStatusEnumeration)((Object)yP_Row2.getFieldValueByName("status"));
    }

    /*
     * WARNING - void declaration
     */
    public YP_Row getImage(YP_Transaction yP_Transaction, String string) {
        Object object;
        ArrayList<Long> arrayList = new ArrayList<Long>();
        arrayList.add(0L);
        ArrayList<Long> arrayList2 = new ArrayList<Long>();
        arrayList2.add(0L);
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList(false);
        if (list.size() == 1) {
            long l = list.get(0).getIDBrand();
            arrayList2.add(l);
            object = this.getGroupIDs(l);
            if (object != null && !object.isEmpty()) {
                arrayList.addAll((Collection<Long>)object);
            }
        }
        ArrayList<Long> arrayList3 = new ArrayList<Long>();
        arrayList3.add(0L);
        List<YP_TCD_DCC_Merchant> list2 = yP_Transaction.getMerchantList();
        if (list2.size() == 1) {
            arrayList3.add(list2.get(0).getIDMerchant());
        }
        object = new YP_ComplexGabarit(this.image);
        ((YP_ComplexGabarit)object).set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        ((YP_ComplexGabarit)object).set("idBrand", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList2);
        ((YP_ComplexGabarit)object).set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList3);
        ((YP_ComplexGabarit)object).set("model", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        ((YP_ComplexGabarit)object).set("idImage", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list3 = this.image.getRowListSuchAs(new YP_ComplexGabarit[]{object});
        if (list3 == null) {
            this.logger(2, "getImage() null list");
            return null;
        }
        if (list3.isEmpty()) {
            return null;
        }
        class IndiceList {
            final List<YP_Row> list = new ArrayList<YP_Row>();
            int indice;

            public IndiceList(int n, YP_Row yP_Row) {
                this.indice = n;
                this.list.add(yP_Row);
            }
        }
        IndiceList indiceList = null;
        for (YP_Row object2 : list3) {
            int n = 0;
            if (((DAO_Image)object2).idGroup != 0L) {
                ++n;
            }
            if (((DAO_Image)object2).idBrand != 0L) {
                n += 10;
            }
            if (((DAO_Image)object2).idMerchant != 0L) {
                n += 100;
            }
            if (indiceList == null) {
                indiceList = new IndiceList(n, object2);
                continue;
            }
            if (n < indiceList.indice) {
                n = 1;
                continue;
            }
            if (n == indiceList.indice) {
                indiceList.list.add(object2);
                continue;
            }
            indiceList.list.clear();
            indiceList.indice = n;
            indiceList.list.add(object2);
        }
        list3.clear();
        if (indiceList != null) {
            list3.addAll(indiceList.list);
        }
        if (list3.size() > 1) {
            void var11_19;
            if (list2.size() == 1) {
                try {
                    for (YP_TCD_DCC_Business n : list2.get((int)0).dataContainerBusinessList) {
                        String string2;
                        YP_Row yP_Row;
                        if (!n.getActivationCode().contentEquals("1") || !n.toString().contains("CarteBancaire") && !n.toString().contains("CB5") && !n.toString().contains("CB6") || n.initialisationParameters == null || (yP_Row = n.initialisationParameters.getUniqueRow()) == null || (string2 = yP_Row.getExtensionValueAsString("acquiringInstitutionIdentificationCode")) == null) continue;
                        String string3 = String.valueOf(string) + "_" + string2;
                        for (YP_Row yP_Row2 : list3) {
                            if (!yP_Row2.getFieldStringValueByName("model").contentEquals(string3)) continue;
                            return yP_Row2;
                        }
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "getImage() ", exception);
                }
            }
            int n = list3.size() - 1;
            while (var11_19 >= 0) {
                if (!list3.get((int)var11_19).getFieldStringValueByName("model").contentEquals(string)) {
                    list3.remove((int)var11_19);
                }
                --var11_19;
            }
            if (list3.isEmpty()) {
                this.logger(2, "getImage() no image matching exactly " + string);
                return null;
            }
        }
        if (list3.size() > 1) {
            this.logger(2, "getImage() too many found for " + string);
        }
        return list3.get(0);
    }

    public List<Long> getGroupIDs(long l) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.brandInsideGroup);
            yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.IN, l, 0L);
            return this.brandInsideGroup.getDistinctValueListSuchAs("idGroup", yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "getGroupIDs() " + exception);
            return null;
        }
    }

    public List<Long> getIdBrandListByGroup(long l) {
        ArrayList<Long> arrayList = new ArrayList<Long>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.brandInsideGroup);
        yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = this.brandInsideGroup.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "getIdBrandListByGroup() not found:" + l);
            }
        } else {
            for (YP_Row yP_Row : list) {
                long l2 = (Long)yP_Row.getFieldValueByName("idBrand");
                if (l2 == 0L) {
                    return this.brand.getDistinctValueList("idBrand");
                }
                arrayList.add(l2);
            }
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public YP_Row getSoftUpdateRow(YP_Transaction yP_Transaction, String string, String string2) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalUpdate);
            yP_ComplexGabarit.set("updateName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("fromVersion", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
            List<YP_Row> list = this.terminalUpdate.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) {
                if (list.size() <= 1) return list.get(0);
                this.logger(2, "getSoftUpdateRow() too many update found for " + string + " " + string2);
                return null;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalUpdate);
            yP_ComplexGabarit.set("updateName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            yP_ComplexGabarit.set("fromVersion", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string2);
            yP_ComplexGabarit.set("fromVersion", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
            list = this.terminalUpdate.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) {
                list.size();
                return list.get(0);
            }
            this.logger(2, "getSoftUpdateRow() no update found for " + string + " " + string2);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getSoftUpdateRow() " + exception);
            return null;
        }
    }

    public List<YP_Row> getApplicationListInsideBrand(YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationInsideBrand);
        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DCC_Brand.getIDBrand());
        List<YP_Row> list = this.applicationInsideBrand.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            this.logger(2, "getApplicationListInsideBrand() null list");
            return null;
        }
        return list;
    }

    public void updateApplicationInsideBrand(Long l, List<Long> list, List<Long> list2, boolean bl) throws Exception {
        if (!list2.isEmpty()) {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationInsideBrand);
            yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)l);
            yP_ComplexGabarit.set("idApplication", YP_ComplexGabarit.OPERATOR.IN, (Object)list2);
            this.applicationInsideBrand.deleteRowsSuchAs(yP_ComplexGabarit);
        }
        for (long l2 : list) {
            YP_Row yP_Row = this.applicationInsideBrand.getNewRow();
            yP_Row.set("idBrand", l);
            yP_Row.set("idApplication", l2);
            yP_Row.setPrimaryKey(this.applicationInsideBrand.getNextPrimaryKey());
            this.applicationInsideBrand.addRow(yP_Row, true);
        }
        if (!(!bl || list2.isEmpty() && list.isEmpty())) {
            this.applicationInsideBrand.persist();
        }
    }

    public YP_Row getAcquirer(String string) {
        if (string == null) {
            this.logger(2, "getAcquirer() acquirerID is null");
            return null;
        }
        if (string.length() < 5) {
            this.logger(2, "getAcquirer() acquirerID too small " + string);
            return null;
        }
        String string2 = string.length() > 5 ? string.substring(string.length() - 5) : string;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.acquirer);
        yP_ComplexGabarit.set("acquirerID", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        List<YP_Row> list = this.acquirer.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            this.logger(2, "getAcquirer() null list");
            return null;
        }
        if (list.isEmpty()) {
            this.logger(2, "getAcquirer() acquirer not found " + string);
            return null;
        }
        if (list.size() > 1) {
            this.logger(2, "getAcquirer() too many found for " + string);
        }
        return list.get(0);
    }

    public String getAcquirerShortName(String string) {
        return this.getAcquirerShortName(this.getAcquirer(string));
    }

    public String getAcquirerShortName(YP_Row yP_Row) {
        if (yP_Row == null) {
            return null;
        }
        return yP_Row.getFieldStringValueByName("acquirerShortName");
    }

    public String getAcquirerBIN3DMastercard(YP_Row yP_Row) {
        if (yP_Row == null) {
            return null;
        }
        return yP_Row.getFieldStringValueByName("bin3DMastercard");
    }

    public String getAcquirerBIN3DVisa(YP_Row yP_Row) {
        if (yP_Row == null) {
            return null;
        }
        return yP_Row.getFieldStringValueByName("bin3DVisa");
    }
}

