/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications;

public class YP_ApplicationEvent {
    protected APPLICATIONEVENT myEvent;
    protected boolean suspendNeeded = false;

    public APPLICATIONEVENT getEvent() {
        return this.myEvent;
    }

    public void setEvent(APPLICATIONEVENT aPPLICATIONEVENT) {
        this.myEvent = aPPLICATIONEVENT;
    }

    public boolean isSuspendNeeded() {
        return this.suspendNeeded;
    }

    public void setSuspendNeeded(boolean bl) {
        this.suspendNeeded = bl;
    }

    public void resetSuspendNeeded() {
        this.suspendNeeded = false;
    }

    public static enum APPLICATIONEVENT {
        nextStepEvent,
        stopEvent,
        errorEvent;

    }
}

