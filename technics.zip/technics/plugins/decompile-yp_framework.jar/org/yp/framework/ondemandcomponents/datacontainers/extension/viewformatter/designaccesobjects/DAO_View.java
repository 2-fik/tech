/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.Bitmap;

public class DAO_View
extends YP_Row {
    @PrimaryKey
    public long idView = 0L;
    public byte[] viewName = new byte[32];
    public Bitmap readAccessList;
    public Bitmap writeAccessList;
    public Bitmap createAccessList;
}

