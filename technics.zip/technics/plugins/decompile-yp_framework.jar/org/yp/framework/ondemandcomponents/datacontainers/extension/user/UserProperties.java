/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.user;

public class UserProperties {
    public static final String CONTRACT_ACCESS = "contractAccess";
    public static final String MERCHANT_ACCESS = "merchantAccess";
    public static final String STORE_ACCESS = "storeAccess";
    public static final String BRAND_ACCESS = "brandAccess";
    public static final String GROUP_ACCESS = "groupAccess";
    public static final String MESSAGE_TO_DISPLAY = "info";
    public static final String PASSWORD = "password";
}

