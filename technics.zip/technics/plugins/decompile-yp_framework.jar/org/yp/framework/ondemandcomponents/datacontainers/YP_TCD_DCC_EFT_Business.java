/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_KRN_ApplicationParameters;
import org.yp.designaccesobjects.business.DAO_Transaction;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.bin.YP_TCD_DCB_Interface_BIN;
import org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters.YP_TCD_DCB_Interface_CallParameters;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.YP_TCD_DCB_Interface_Currency;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.SessionData;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.PANLengthTypeEnumeration;
import org.yp.utils.enums.RealisationModeEnumeration;
import org.yp.utils.enums.SessionStatusEnumeration;
import org.yp.utils.enums.TicketTypeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_TCD_DCC_EFT_Business
extends YP_TCD_DCC_Business {
    public YP_TCD_DCB_Interface_Currency currencyInterface;
    public YP_TCD_DCB_Interface_CallParameters callParametersInterface;
    public YP_TCD_DesignAccesObject applicationParameters;
    private static final String AMOUNT = "Montant";
    private static final String DEBIT_VAD = "Debit VAD";
    private static final String LABEL = "Libelle";
    private static final String CARD = "Carte";
    private static final String CVV = "CVV";

    public YP_TCD_DCC_EFT_Business(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.applicationParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_ApplicationParameters.class, 0, 0, null);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()", exception);
            return -1;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        if (this.currencyInterface != null) {
            this.currencyInterface.shutdown();
            this.currencyInterface = null;
        }
        if (this.applicationParameters != null) {
            this.applicationParameters.shutdown();
            this.applicationParameters = null;
        }
        return super.shutdown();
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.applicationParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() applicationParameters");
            }
            return 1;
        }
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (clazz == DAO_KRN_ApplicationParameters.class) {
            this.logger(2, "onChange() test to see if this case is possible");
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.applicationParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() applicationParameters");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.applicationParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() applicationParameters");
            }
            return 1;
        }
        return super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    private int checkTransactionUploadTime() {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
            yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.NOT_YET_UPLOADABLE);
            yP_ComplexGabarit.set("transactionUploadAppliLocalTime", YP_ComplexGabarit.OPERATOR.LESS, new Timestamp(this.timeInterface.getAppliLocalTime().getTimeInMillis()));
            YP_Row yP_Row = this.transaction.getNewRow();
            yP_Row.set("transactionUploadStatus", UploadStatusEnumeration.UPLOADABLE);
            return this.transaction.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "checkTransactionUploadTime() ", exception);
            return -1;
        }
    }

    private List<String> getCurrencyAlphaListInSession(boolean bl) {
        List<String> list;
        if (bl) {
            list = this.currencyInterface.getCurrencyAlphabeticalCodeList(true, false);
            if (list == null) {
                this.logger(2, "getCurrencyAlphaListInSession() currencyList 1 null");
                return null;
            }
        } else {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
            yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.UPLOADABLE);
            list = this.transaction.getDistinctStringValueListSuchAs("transactionCurrencyAlpha", yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getCurrencyAlphaListInSession() currencyList 2 null");
                return null;
            }
        }
        return list;
    }

    public int closeSessions(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl) throws Exception {
        this.logger(4, "closeSessions() start");
        if (this.synchronizeTransactions() < 0) {
            this.logger(2, "closeSessions() aborted because not synchronized");
            return -1;
        }
        this.checkTransactionUploadTime();
        List<String> list = this.getCurrencyAlphaListInSession(bl);
        if (list == null) {
            this.logger(2, "closeSessions() no list...");
            return -1;
        }
        if (list.isEmpty()) {
            this.logger(3, "closeSessions() nothing to do");
            return 0;
        }
        Collections.sort(list);
        for (String string : list) {
            int n;
            do {
                YP_Row yP_Row;
                try {
                    yP_Row = yP_TCD_DC_Transaction.getDataContainerBrand().getNewSession(this);
                }
                catch (Exception exception) {
                    this.logger(2, "closeSessions() unable to get a new session ", exception);
                    return -1;
                }
                if (yP_Row == null) {
                    this.logger(2, "closeSessions() unable to get a new session");
                    return -1;
                }
                int n2 = (Integer)yP_Row.getFieldValueByName("sessionNumber");
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
                yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.UPLOADABLE);
                yP_ComplexGabarit.set("transactionCurrencyAlpha", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                YP_Row yP_Row2 = this.transaction.getNewRow();
                yP_Row2.set("transactionUploadStatus", UploadStatusEnumeration.TO_UPLOAD);
                yP_Row2.set("sessionNumber", n2);
                n = this.transaction.updateRowSuchAs(yP_Row2, 99000, yP_ComplexGabarit);
                if (n < 0) continue;
                this.fillSession(yP_Row, n2, null, string);
                yP_Row.persist();
            } while (n == 99000);
        }
        return 1;
    }

    public int fillSession(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, SessionData sessionData) throws Exception {
        if (sessionData == null) {
            this.logger(2, "fillSession() aborted because sessionData is null");
            return -1;
        }
        YP_Row yP_Row = yP_TCD_DC_Transaction.getDataContainerBrand().getNewSession(this);
        yP_Row.set("status", SessionStatusEnumeration.TO_UPLOAD);
        yP_Row.set("sessionSystemGMTTimeMS", UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_Row.set("sessionAppliLocalTime", new Timestamp(this.timeInterface.getAppliLocalTime().getTimeInMillis()));
        yP_Row.set("applicationName", sessionData.getApplicationName());
        if (sessionData.getProcessorIdentifier() != null && !sessionData.getProcessorIdentifier().isEmpty()) {
            yP_Row.set("processorIdentifier", sessionData.getProcessorIdentifier());
        }
        if (sessionData.getMerchantContract() != null && !sessionData.getMerchantContract().isEmpty()) {
            yP_Row.set("merchantContract", sessionData.getMerchantContract());
        }
        if (sessionData.getAcquiringInstitutionIdentificationCode() != null && !sessionData.getAcquiringInstitutionIdentificationCode().isEmpty()) {
            yP_Row.set("acquiringInstitutionIdentificationCode", sessionData.getAcquiringInstitutionIdentificationCode());
        }
        if (sessionData.getCommercialRegisterNumber() != null && !sessionData.getCommercialRegisterNumber().isEmpty()) {
            yP_Row.set("commercialRegisterNumber", sessionData.getCommercialRegisterNumber());
        }
        if (sessionData.getMerchantCategoryCode() != null && !sessionData.getMerchantCategoryCode().isEmpty()) {
            yP_Row.set("merchantCategoryCode", sessionData.getMerchantCategoryCode());
        }
        if (sessionData.getApplicationEnvironmentType() != null && !sessionData.getApplicationEnvironmentType().isEmpty()) {
            yP_Row.set("applicationEnvironmentType", sessionData.getApplicationEnvironmentType());
        }
        if (sessionData.getSiteType() != null && !sessionData.getSiteType().isEmpty()) {
            yP_Row.set("siteType", sessionData.getSiteType());
        }
        if (sessionData.getTerminalIdentification() != null && !sessionData.getTerminalIdentification().isEmpty()) {
            yP_Row.set("terminalIdentification", sessionData.getTerminalIdentification());
        }
        if (sessionData.getProviderAID() != null && !sessionData.getProviderAID().isEmpty()) {
            yP_Row.set("providerAID", sessionData.getProviderAID());
        }
        if (sessionData.getNlsa() != null && !sessionData.getNlsa().isEmpty()) {
            yP_Row.set("nlsa", sessionData.getNlsa());
        }
        if (sessionData.getIdsa() != null && !sessionData.getIdsa().isEmpty()) {
            yP_Row.set("idsa", sessionData.getIdsa());
        }
        if (sessionData.getManufacturerAID() != null && !sessionData.getManufacturerAID().isEmpty()) {
            yP_Row.set("manufacturerAID", sessionData.getManufacturerAID());
        }
        if (sessionData.getCardAcceptorIdentificationCode() != null && !sessionData.getCardAcceptorIdentificationCode().isEmpty()) {
            yP_Row.set("cardAcceptorIdentificationCode", sessionData.getCardAcceptorIdentificationCode());
        }
        if (sessionData.getCountryCode() != null && !sessionData.getCountryCode().isEmpty()) {
            yP_Row.set("countryCode", sessionData.getCountryCode());
        }
        yP_Row.set("sequenceNumber", sessionData.getSequenceNumber());
        String string = sessionData.getCurrencyAlphabeticalCode();
        int n = sessionData.getCurrencyNumericalCode();
        if (sessionData.getCurrencyAlphabeticalCode() == null || sessionData.getCurrencyAlphabeticalCode().isEmpty()) {
            if (n > 0) {
                string = this.currencyInterface.getCurrencyAlphabeticalCode(n);
            } else {
                this.logger(2, "fillSession() aborted because currencyAlphabeticalCode and currencyNumericalCode are null");
            }
        } else if (n == 0) {
            n = this.currencyInterface.getCurrencyNumericalCode(string);
        }
        if (string != null) {
            yP_Row.set("currencyAlphabeticalCode", string);
        }
        yP_Row.set("currencyNumericalCode", n);
        yP_Row.set("nbDebit", sessionData.getNbDebit());
        yP_Row.set("totalAmountDebit", sessionData.getTotalAmountDebit());
        yP_Row.set("nbDebitOnline", sessionData.getNbDebitOnline());
        yP_Row.set("totalAmountDebitOnline", sessionData.getTotalAmountDebitDifferedOnline());
        yP_Row.set("nbDebitOffline", sessionData.getNbDebitOffline());
        yP_Row.set("totalAmountDebitOffline", sessionData.getTotalAmountDebitOffline());
        yP_Row.set("nbDebitDiffered", sessionData.getNbDebitDiffered());
        yP_Row.set("totalAmountDebitDiffered", sessionData.getTotalAmountDebitDiffered());
        yP_Row.set("nbDebitDifferedOnline", sessionData.getNbDebitDifferedOnline());
        yP_Row.set("totalAmountDebitDifferedOnline", sessionData.getTotalAmountDebitDifferedOffline());
        yP_Row.set("nbDebitDifferedOffline", sessionData.getNbDebitDifferedOffline());
        yP_Row.set("totalAmountDebitDifferedOffline", sessionData.getTotalAmountDebitDifferedOffline());
        yP_Row.set("nbRefund", sessionData.getNbRefund());
        yP_Row.set("totalAmountRefund", sessionData.getTotalAmountRefund());
        yP_Row.set("nbReversalDebit", sessionData.getNbReversalDebit());
        yP_Row.set("totalAmountReversalDebit", sessionData.getTotalAmountReversalDebit());
        yP_Row.set("nbReversalDebitOnline", sessionData.getNbReversalDebitOnline());
        yP_Row.set("totalAmountReversalDebitOnline", sessionData.getTotalAmountReversalDebitOnline());
        yP_Row.set("nbReversalDebitOffline", sessionData.getNbReversalDebitOffline());
        yP_Row.set("totalAmountReversalDebitOffline", sessionData.getTotalAmountReversalDebitOffline());
        yP_Row.set("nbReversalRefund", sessionData.getNbReversalRefund());
        yP_Row.set("totalAmountReversalRefund", sessionData.getTotalAmountReversalRefund());
        yP_Row.set("nbDebitAbandonned", sessionData.getNbDebitAbandonned());
        yP_Row.set("nbCASH_ADVANCE", sessionData.getNbCASH_ADVANCE());
        yP_Row.set("totalAmountCASH_ADVANCE", sessionData.getTotalAmountCASH_ADVANCE());
        yP_Row.set("nbQUASI_CASH", sessionData.getNbQUASI_CASH());
        yP_Row.set("totalAmountQUASI_CASH", sessionData.getTotalAmountQUASI_CASH());
        yP_Row.set("nbINITIAL_RESERVATION", sessionData.getNbINITIAL_RESERVATION());
        yP_Row.set("totalAmountINITIAL_RESERVATION", sessionData.getTotalAmountINITIAL_RESERVATION());
        yP_Row.set("nbADDITIONAL_RESERVATION", sessionData.getNbADDITIONAL_RESERVATION());
        yP_Row.set("totalAmountADDITIONAL_RESERVATION", sessionData.getTotalAmountADDITIONAL_RESERVATION());
        yP_Row.set("nbONE_TIME_RESERVATION", sessionData.getNbONE_TIME_RESERVATION());
        yP_Row.set("totalAmountONE_TIME_RESERVATION", sessionData.getTotalAmountONE_TIME_RESERVATION());
        yP_Row.set("nbCLOSING_PAYMENT", sessionData.getNbCLOSING_PAYMENT());
        yP_Row.set("totalAmountCLOSING_PAYMENT", sessionData.getTotalAmountCLOSING_PAYMENT());
        yP_Row.set("nbVOID_CLOSING_PAYMENT", sessionData.getNbVOID_CLOSING_PAYMENT());
        yP_Row.set("nbCOMPLEMENTARY_PAYMENT", sessionData.getNbCOMPLEMENTARY_PAYMENT());
        yP_Row.set("totalAmountCOMPLEMENTARY_PAYMENT", sessionData.getTotalAmountCOMPLEMENTARY_PAYMENT());
        yP_Row.set("nbCOMPLEMENTARY_REFUND", sessionData.getNbCOMPLEMENTARY_REFUND());
        yP_Row.set("totalAmountCOMPLEMENTARY_REFUND", sessionData.getTotalAmountCOMPLEMENTARY_REFUND());
        yP_Row.set("nbTRS", sessionData.getNbTRS());
        yP_Row.set("sessionNumber", sessionData.getSessionNumber());
        yP_Row.persist();
        return 1;
    }

    private boolean isThereTransactionToUpload() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
        yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.UPLOADABLE);
        int n = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        return n > 0;
    }

    public int closeOrUpdateSessions(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl) throws Exception {
        this.logger(4, "closeOrUpdateSessions() start");
        if (this.synchronizeTransactions() < 0) {
            this.logger(2, "closeOrUpdateSessions() aborted because not synchronized");
            return -1;
        }
        this.checkTransactionUploadTime();
        List<String> list = this.getCurrencyAlphaListInSession(bl);
        if (list == null) {
            this.logger(2, "closeOrUpdateSessions() no list...");
            return -1;
        }
        if (list.isEmpty()) {
            this.logger(3, "closeOrUpdateSessions() nothing to do");
            return 0;
        }
        Collections.sort(list);
        List<YP_Row> list2 = yP_TCD_DC_Transaction.getSessionListToUpload(this.getContractIdentifier());
        if (list2 == null) {
            this.logger(2, "closeOrUpdateSessions() no session list...");
            return -1;
        }
        for (String string : list) {
            YP_Row yP_Row = null;
            for (YP_Row yP_Row2 : list2) {
                if (!string.contentEquals(yP_Row2.getFieldStringValueByName("currencyAlphabeticalCode"))) continue;
                yP_Row = yP_Row2;
                break;
            }
            if (yP_Row == null) {
                try {
                    yP_Row = yP_TCD_DC_Transaction.getDataContainerBrand().getNewSession(this);
                }
                catch (Exception exception) {
                    this.logger(2, "closeOrUpdateSessions() unable to get a new session ", exception);
                    return -1;
                }
            }
            if (yP_Row == null) {
                this.logger(2, "closeOrUpdateSessions() unable to get a new session");
                return -1;
            }
            int n = (Integer)yP_Row.getFieldValueByName("sessionNumber");
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
            yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.UPLOADABLE);
            yP_ComplexGabarit.set("transactionCurrencyAlpha", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            YP_Row yP_Row3 = this.transaction.getNewRow();
            yP_Row3.set("transactionUploadStatus", UploadStatusEnumeration.TO_UPLOAD);
            yP_Row3.set("sessionNumber", n);
            this.transaction.updateRowSuchAs(yP_Row3, yP_ComplexGabarit);
            if (this.fillSession(yP_Row, n, null, string) < 0) continue;
            yP_Row.persist();
        }
        return 1;
    }

    private YP_ComplexGabarit getGabarit(int n, String string, int n2, String string2, long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
        yP_ComplexGabarit.set("sessionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, n);
        if (string != null) {
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        yP_ComplexGabarit.set("transactionCurrencyNumerical", YP_ComplexGabarit.OPERATOR.EQUAL, n2);
        if (string2 != null && !string2.isEmpty()) {
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        }
        if (l >= 0L) {
            yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.GREATER, l);
        }
        return yP_ComplexGabarit;
    }

    public int fillSession(YP_Row yP_Row, int n, String string, String string2) {
        return this.fillSession(yP_Row, n, string, string2, null);
    }

    public int fillSession(YP_Row yP_Row, int n, String string, String string2, String string3) {
        return this.fillSession(yP_Row, n, string, string2, null, -1L);
    }

    public int fillSession(YP_Row yP_Row, int n, String string, String string2, String string3, long l) {
        YP_Row yP_Row2;
        Object object;
        yP_Row.set("status", SessionStatusEnumeration.TO_UPLOAD);
        yP_Row.set("sessionSystemGMTTimeMS", UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_Row.set("sessionAppliLocalTime", new Timestamp(this.timeInterface.getAppliLocalTime().getTimeInMillis()));
        yP_Row.set("applicationName", this.getApplicationPlugin().toString());
        if (string != null) {
            yP_Row.set("processorIdentifier", string);
            object = new YP_ComplexGabarit(this.applicationParameters);
            ((YP_ComplexGabarit)object).set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(new YP_ComplexGabarit[]{object});
            if (list != null && !list.isEmpty()) {
                yP_Row.set("applicationName", list.get(0).getFieldStringValueByName("applicationName"));
            }
        }
        if ((object = this.getTicketReportHeader(null)) != null) {
            yP_Row.set("ticketHeader", (String)object);
        }
        if ((object = this.getTicketReportFooter(null)) != null) {
            yP_Row.set("ticketFooter", (String)object);
        }
        if ((object = this.getMerchantContract()) != null) {
            yP_Row.set("merchantContract", (String)object);
        }
        if ((object = this.getAcquiringInstitutionIdentificationCode()) != null) {
            yP_Row.set("acquiringInstitutionIdentificationCode", (String)object);
        }
        if ((object = this.getCommercialRegisterNumber()) != null) {
            yP_Row.set("commercialRegisterNumber", (String)object);
        }
        if ((object = this.getMerchantCategoryCode()) != null) {
            yP_Row.set("merchantCategoryCode", (String)object);
        }
        if ((object = this.getApplicationPlugin().getApplicationEnvironmentType()) != null) {
            yP_Row.set("applicationEnvironmentType", (String)object);
        }
        if ((object = this.getMerchantType()) != null) {
            yP_Row.set("siteType", (String)object);
        }
        if ((object = this.getTerminalIdentification()) != null) {
            yP_Row.set("terminalIdentification", (String)object);
        }
        if ((object = this.getApplicationPlugin().getProviderAID()) != null) {
            yP_Row.set("providerAID", (String)object);
        }
        yP_Row.set("currencyAlphabeticalCode", string2);
        int n2 = this.currencyInterface.getCurrencyNumericalCode(string2);
        if (n2 == 0) {
            this.logger(2, "updateSession() unable to find numerical value of " + string2);
            return -1;
        }
        yP_Row.set("currencyNumericalCode", n2);
        int n3 = this.currencyInterface.getCurrencyFraction(string2);
        if (n3 < 0) {
            this.logger(2, "updateSession() unable to find fraction of " + string2);
            n3 = 2;
        }
        if (n3 == 0 && n2 == 978) {
            this.logger(3, "updateSession() fraction set to 2 for euro");
            n3 = 2;
        }
        yP_Row.set("currencyFraction", n3);
        YP_ComplexGabarit yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MIN);
        List<YP_Row> list = this.transaction.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null && !list.isEmpty()) {
            yP_Row2 = list.get(0);
            yP_Row.set("firstTransactionAppliLocalTime", (Timestamp)yP_Row2.getFieldValueByName("transactionAppliLocalTime"));
        }
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MAX);
        list = this.transaction.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null && !list.isEmpty()) {
            yP_Row2 = list.get(0);
            yP_Row.set("lastTransactionAppliLocalTime", (Timestamp)yP_Row2.getFieldValueByName("transactionAppliLocalTime"));
        }
        int n4 = 0;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.QUASI_CASH, TransactionTypeEnumeration.ADVICE_DEBIT});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("differedFlag", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0);
        int n5 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbDebit", n5);
        long l2 = this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit);
        yP_Row.set("totalAmountDebit", l2);
        n4 += n5;
        yP_ComplexGabarit.set("realisationMode", YP_ComplexGabarit.OPERATOR.IN, new Object[]{RealisationModeEnumeration.OkOnline, RealisationModeEnumeration.OkReferral});
        int n6 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbDebitOnline", n6);
        long l3 = this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit);
        yP_Row.set("totalAmountDebitOnline", l3);
        int n7 = n5 - n6;
        yP_Row.set("nbDebitOffline", n7);
        yP_Row.set("totalAmountDebitOffline", l2 - l3);
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.DEBIT_DIFFERED});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("differedFlag", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
        int n8 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbDebitDiffered", n8);
        long l4 = this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit);
        yP_Row.set("totalAmountDebitDiffered", l4);
        n4 += n8;
        yP_ComplexGabarit.set("realisationMode", YP_ComplexGabarit.OPERATOR.IN, new Object[]{RealisationModeEnumeration.OkOnline, RealisationModeEnumeration.OkReferral});
        int n9 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbDebitDifferedOnline", n9);
        long l5 = this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit);
        yP_Row.set("totalAmountDebitDifferedOnline", l5);
        int n10 = n8 - n9;
        yP_Row.set("nbDebitDifferedOffline", n10);
        yP_Row.set("totalAmountDebitDifferedOffline", l4 - l5);
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.CREDIT, TransactionTypeEnumeration.REFUND_QUASI_CASH});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n11 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbRefund", n11);
        yP_Row.set("totalAmountRefund", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n11;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.REVERSAL_DEBIT, TransactionTypeEnumeration.REVERSAL_QUASI_CASH});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n12 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbReversalDebit", n12);
        yP_Row.set("totalAmountReversalDebit", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n12;
        yP_ComplexGabarit.set("realisationMode", YP_ComplexGabarit.OPERATOR.EQUAL, RealisationModeEnumeration.OkOnline);
        n12 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbReversalDebitOnline", n12);
        yP_Row.set("totalAmountReversalDebitOnline", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.REVERSAL_DEBIT, TransactionTypeEnumeration.REVERSAL_QUASI_CASH});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("realisationMode", YP_ComplexGabarit.OPERATOR.EQUAL, RealisationModeEnumeration.OkOffline);
        n12 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbReversalDebitOffline", n12);
        yP_Row.set("totalAmountReversalDebitOffline", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.REVERSAL_CREDIT);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n13 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbReversalRefund", n13);
        yP_Row.set("totalAmountReversalRefund", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n13;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        boolean bl = false;
        String string4 = this.getApplicationPlugin().getProviderAID();
        if (string4 == null || !string4.contentEquals("A000000025")) {
            Object object2;
            Object object3;
            YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)this.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class);
            if (yP_TCD_DCB_Interface_CTCL != null) {
                object3 = this.selectorList.iterator();
                while (object3.hasNext()) {
                    object2 = (YP_App_Interface_Selection)object3.next();
                    if (!object2.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                    bl = true;
                    break;
                }
            }
            if (!bl) {
                try {
                    object2 = this.getApplicationPlugin().getManufacturerAID();
                    if (object2 != null && ((String)object2).length() >= 5 && "55".contentEquals((CharSequence)(object3 = ((String)object2).substring(3, 5)))) {
                        bl = true;
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "fillSession() ", exception);
                }
            }
        }
        if (bl) {
            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.DEBIT_DIFFERED, TransactionTypeEnumeration.INITIAL_RESERVATION, TransactionTypeEnumeration.ONE_TIME_RESERVATION, TransactionTypeEnumeration.CREDIT, TransactionTypeEnumeration.REVERSAL_DEBIT, TransactionTypeEnumeration.QUASI_CASH, TransactionTypeEnumeration.REFUND_QUASI_CASH, TransactionTypeEnumeration.REVERSAL_QUASI_CASH});
        } else {
            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.DEBIT_DIFFERED, TransactionTypeEnumeration.INITIAL_RESERVATION, TransactionTypeEnumeration.ONE_TIME_RESERVATION, TransactionTypeEnumeration.QUASI_CASH});
        }
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.REFUSED);
        int n14 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.ADVICE_DEBIT);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        n4 += (n14 += this.transaction.getCountSuchAs(yP_ComplexGabarit));
        yP_Row.set("nbDebitAbandonned", n14);
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.CASH_ADVANCE);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n15 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbCASH_ADVANCE", n15);
        yP_Row.set("totalAmountCASH_ADVANCE", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n15;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.QUASI_CASH);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n16 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbQUASI_CASH", n16);
        yP_Row.set("totalAmountQUASI_CASH", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.INITIAL_RESERVATION);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n17 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbINITIAL_RESERVATION", n17);
        yP_Row.set("totalAmountINITIAL_RESERVATION", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n17;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.ADDITIONAL_RESERVATION);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n18 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbADDITIONAL_RESERVATION", n18);
        yP_Row.set("totalAmountADDITIONAL_RESERVATION", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n18;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.ONE_TIME_RESERVATION);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n19 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbONE_TIME_RESERVATION", n19);
        yP_Row.set("totalAmountONE_TIME_RESERVATION", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n19;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.CLOSING_PAYMENT);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0);
        int n20 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbCLOSING_PAYMENT", n20);
        yP_Row.set("totalAmountCLOSING_PAYMENT", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n20;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.CLOSING_PAYMENT);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
        int n21 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbVOID_CLOSING_PAYMENT", n21);
        n4 += n21;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n22 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbCOMPLEMENTARY_PAYMENT", n22);
        yP_Row.set("totalAmountCOMPLEMENTARY_PAYMENT", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        n4 += n22;
        yP_ComplexGabarit = this.getGabarit(n, string, n2, string3, l);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionTypeEnumeration.COMPLEMENTARY_REFUND);
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        int n23 = this.transaction.getCountSuchAs(yP_ComplexGabarit);
        yP_Row.set("nbCOMPLEMENTARY_REFUND", n23);
        yP_Row.set("totalAmountCOMPLEMENTARY_REFUND", this.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit));
        yP_Row.set("nbTRS", n4 += n23);
        return n4;
    }

    @Override
    public String get(String string) {
        return super.get(string);
    }

    public static void setSessionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setSessionNumber(n);
    }

    public static int getSessionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getSessionNumber();
    }

    private String foundProcessorIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row;
        YP_TCD_DCB_Interface_BIN yP_TCD_DCB_Interface_BIN;
        String string = yP_TCD_DC_Transaction.commonHandler.getProcessorIdentifier();
        if ((string == null || string.isEmpty()) && (yP_TCD_DCB_Interface_BIN = (YP_TCD_DCB_Interface_BIN)this.getExtensionByType(YP_TCD_DCB_Interface_BIN.class)) != null && (yP_Row = yP_TCD_DCB_Interface_BIN.getBINRecord(yP_TCD_DC_Transaction)) != null) {
            string = yP_Row.getFieldStringValueByName("processorIdentifier");
            yP_TCD_DC_Transaction.commonHandler.setProcessorIdentifier(string);
        }
        return string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isLengthAcceptable(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        try {
            int n = string.length();
            YP_Row yP_Row = this.applicationParameters.getUniqueRow();
            if (yP_Row == null) {
                this.logger(2, "isLengthAcceptable() no row found");
                return false;
            }
            PANLengthTypeEnumeration pANLengthTypeEnumeration = (PANLengthTypeEnumeration)((Object)yP_Row.getFieldValueByName("lengthType"));
            int n2 = (Integer)yP_Row.getFieldValueByName("lengthMin");
            int n3 = (Integer)yP_Row.getFieldValueByName("lengthMax");
            if (pANLengthTypeEnumeration == PANLengthTypeEnumeration.RANGE) {
                if (n < n2) {
                    this.logger(2, "isLengthAcceptable() length is less than authorized: " + n2 + " : " + n);
                    return false;
                }
                if (n > n3) {
                    this.logger(2, "isLengthAcceptable() length is greater than authorized: " + n3 + " : " + n);
                    return false;
                }
                this.logger(5, "isLengthAcceptable() length OK");
                return true;
            }
            if (pANLengthTypeEnumeration == PANLengthTypeEnumeration.VALUES) {
                if (n == n2) return true;
                if (n == n3) return true;
                this.logger(2, "isLengthAcceptable() length must be either : " + n2 + " or " + n3 + " : " + n);
                return false;
            }
            this.logger(2, "isLengthAcceptable() bad value for lengthtype");
            return false;
        }
        catch (Exception exception) {
            this.logger(2, "isLengthAcceptable() :", exception);
            return false;
        }
    }

    public int getMinimumLength(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row = this.applicationParameters.getUniqueRow();
        if (yP_Row == null) {
            this.logger(3, "getMinimumLength() no row found");
            return -1;
        }
        return (Integer)yP_Row.getFieldValueByName("lengthMin");
    }

    public int getMaximumLength(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row = this.applicationParameters.getUniqueRow();
        if (yP_Row == null) {
            this.logger(3, "getMaximumLength() no row found");
            return -1;
        }
        return (Integer)yP_Row.getFieldValueByName("lengthMax");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getTicketPaymentInformationHeader(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string == null || string.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationHeader() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationHeader");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getTicketPaymentInformationHeader() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationHeader() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationHeader");
            }
            if (list.size() > 1) {
                this.logger(3, "getTicketPaymentInformationHeader() too many row found");
            }
            return list.get(0).getFieldStringValueByName("ticketPaymentInformationHeader");
        }
        catch (Exception exception) {
            this.logger(2, "getTicketPaymentInformationHeader() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getTicketPaymentInformationFooter(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string == null || string.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationFooter() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationFooter");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getTicketPaymentInformationFooter() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationFooter() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationFooter");
            }
            if (list.size() > 1) {
                this.logger(3, "getTicketPaymentInformationFooter() too many row found");
            }
            return list.get(0).getFieldStringValueByName("ticketPaymentInformationFooter");
        }
        catch (Exception exception) {
            this.logger(2, "getTicketPaymentInformationFooter() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getTicketPaymentInformationFooterSup(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string == null || string.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationFooterSup() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationFooterSup");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getTicketPaymentInformationFooterSup() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTicketPaymentInformationFooterSup() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("ticketPaymentInformationFooterSup");
            }
            if (list.size() > 1) {
                this.logger(3, "getTicketPaymentInformationFooterSup() too many row found");
            }
            return list.get(0).getFieldStringValueByName("ticketPaymentInformationFooterSup");
        }
        catch (Exception exception) {
            this.logger(2, "getTicketPaymentInformationFooterSup() :", exception);
            return null;
        }
    }

    public String getTicketReportHeader(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row = this.applicationParameters.getUniqueRow();
        if (yP_Row == null) {
            this.logger(3, "getTicketReportHeader() no row found");
            return null;
        }
        return yP_Row.getFieldStringValueByName("ticketReportHeader");
    }

    public String getTicketReportFooter(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row = this.applicationParameters.getRowAt(0);
        if (yP_Row == null) {
            this.logger(3, "getTicketReportFooter() no row found");
            return null;
        }
        return yP_Row.getFieldStringValueByName("ticketReportFooter");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getApplicationContract(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string == null || string.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getApplicationContract() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("applicationContract");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getApplicationContract() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                this.logger(3, "getApplicationContract() no row found");
                return "";
            }
            if (list.size() > 1) {
                this.logger(3, "getApplicationContract() too many row found");
            }
            return list.get(0).getFieldStringValueByName("applicationContract");
        }
        catch (Exception exception) {
            this.logger(2, "getApplicationContract() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getEndUserLangageList(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string == null || string.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getEndUserLangageList() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("endUserLangageList");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getEndUserLangageList() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getEndUserLangageList() no row found");
                    return null;
                }
                return yP_Row.getFieldStringValueByName("endUserLangageList");
            }
            if (list.size() > 1) {
                this.logger(3, "getEndUserLangageList() too many row found");
            }
            return list.get(0).getFieldStringValueByName("endUserLangageList");
        }
        catch (Exception exception) {
            this.logger(2, "getEndUserLangageList() :", exception);
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Bitmap getTransactionTypeAllowed(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row;
        block3: {
            try {
                String string = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
                if (string != null && !string.isEmpty()) return this.getTransactionTypeAllowed(string);
                yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row != null) break block3;
                this.logger(3, "getTransactionTypeAllowed() no row found");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTransactionTypeAllowed() :", exception);
                return null;
            }
        }
        return (Bitmap)yP_Row.getFieldValueByName("trsTypeAllowed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Bitmap getTransactionTypeAllowed(String string) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getTransactionTypeAllowed() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getTransactionTypeAllowed() no row found");
                    return null;
                }
                return (Bitmap)yP_Row.getFieldValueByName("trsTypeAllowed");
            }
            if (list.size() > 1) {
                this.logger(3, "getTransactionTypeAllowed() too many row found");
            }
            return (Bitmap)list.get(0).getFieldValueByName("trsTypeAllowed");
        }
        catch (Exception exception) {
            this.logger(2, "getTransactionTypeAllowed() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public Boolean isForcedAllowed(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        try {
            List<YP_Row> list;
            Object object;
            Object object2;
            Boolean bl = false;
            String string2 = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
            if (string2 == null || string2.isEmpty()) {
                object2 = this.applicationParameters.getUniqueRow();
                if (object2 == null) {
                    this.logger(3, "isForcedAllowed() no row found");
                    return null;
                }
                bl = (Boolean)((YP_Row)object2).getFieldValueByName("isForcedAllowed");
            } else {
                object2 = new YP_ComplexGabarit(this.applicationParameters);
                ((YP_ComplexGabarit)object2).set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                object = this.applicationParameters.getRowListSuchAs(new YP_ComplexGabarit[]{object2});
                if (object == null) {
                    this.logger(2, "isForcedAllowed() error with application list");
                    return null;
                }
                if (object.isEmpty()) {
                    list = this.applicationParameters.getUniqueRow();
                    if (list == null) {
                        this.logger(3, "isForcedAllowed() no row found");
                        return null;
                    }
                    bl = (Boolean)((YP_Row)((Object)list)).getFieldValueByName("isForcedAllowed");
                } else {
                    if (object.size() > 1) {
                        this.logger(3, "isForcedAllowed() too many row found");
                    }
                    bl = (Boolean)((YP_Row)object.get(0)).getFieldValueByName("isForcedAllowed");
                }
            }
            if (entryModeEnumeration != null && (entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) && bl != null && bl.booleanValue() && (object2 = (YP_TCD_DCB_Interface_EMV)this.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) != null && (object = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("aid"))) != null && !((String)object).isEmpty()) {
                list = object2.getAIDList((String)object);
                if (list == null || list.isEmpty()) {
                    this.logger(2, "isForcedAllowed() EMV but no AID for " + (String)object);
                    return false;
                }
                String string3 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("applicationVersionNumberIcc"));
                int n = 0;
                if (string3 != null && !string3.isEmpty()) {
                    n = Integer.parseInt(string3, 16);
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(((YP_Row)list.get(0)).getFather());
                yP_ComplexGabarit.set("terminalApplicationVersionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, n);
                List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
                if (list2 != null && !list2.isEmpty()) {
                    for (YP_Row yP_Row : list2) {
                        if (((Boolean)yP_Row.getFieldValueByName("forcingAllowed")).booleanValue()) continue;
                        return false;
                    }
                } else {
                    yP_ComplexGabarit = new YP_ComplexGabarit(((YP_Row)list.get(0)).getFather());
                    yP_ComplexGabarit.set("terminalApplicationVersionNumber", YP_ComplexGabarit.OPERATOR.MAX);
                    list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
                    if (list2 != null && !list2.isEmpty()) {
                        for (YP_Row yP_Row : list2) {
                            if (((Boolean)yP_Row.getFieldValueByName("forcingAllowed")).booleanValue()) continue;
                            return false;
                        }
                    }
                }
            }
            return bl;
        }
        catch (Exception exception) {
            this.logger(2, "isForcedAllowed() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Boolean isAutoCall(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        try {
            String string2 = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string2 == null || string2.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "isAutoCall() no row found");
                    return null;
                }
                return (Boolean)yP_Row.getFieldValueByName("isAutoCall");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "isAutoCall() error with application list");
                return null;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "isAutoCall() no row found");
                    return null;
                }
                return (Boolean)yP_Row.getFieldValueByName("isAutoCall");
            }
            if (list.size() > 1) {
                this.logger(3, "isAutoCall() too many row found");
            }
            return (Boolean)list.get(0).getFieldValueByName("isAutoCall");
        }
        catch (Exception exception) {
            this.logger(2, "isAutoCall() :", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int getInterCharacterTimeout(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        try {
            String string2 = this.foundProcessorIdentifier(yP_TCD_DC_Transaction);
            if (string2 == null || string2.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getInterCharacterTimeout() no row found");
                    return -1;
                }
                return (Integer)yP_Row.getFieldValueByName("interCharacterTimeout");
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.applicationParameters);
            yP_ComplexGabarit.set("processorIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
            List<YP_Row> list = this.applicationParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null) {
                this.logger(2, "getInterCharacterTimeout() error with application list");
                return -1;
            }
            if (list.isEmpty()) {
                YP_Row yP_Row = this.applicationParameters.getUniqueRow();
                if (yP_Row == null) {
                    this.logger(3, "getInterCharacterTimeout() no row found");
                    return -1;
                }
                return (Integer)yP_Row.getFieldValueByName("interCharacterTimeout");
            }
            if (list.size() > 1) {
                this.logger(3, "getInterCharacterTimeout() too many row found");
            }
            return (Integer)list.get(0).getFieldValueByName("interCharacterTimeout");
        }
        catch (Exception exception) {
            this.logger(2, "getInterCharacterTimeout() :", exception);
            return -1;
        }
    }

    public abstract String getTransactionTicket(YP_TCD_DC_Transaction var1, boolean var2, int var3);

    protected void logTransactionStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string;
            EntryModeEnumeration entryModeEnumeration;
            long l;
            ExtendedTVR extendedTVR;
            TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(yP_TCD_DC_Transaction);
            if (transactionStatusEnumeration == TransactionStatusEnumeration.ACCEPTED && this.getLogLevel() < 5) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder("\r\n");
            if (transactionStatusEnumeration != null) {
                stringBuilder.append("Status :");
                stringBuilder.append((Object)transactionStatusEnumeration);
                stringBuilder.append("\r\n");
            }
            RealisationModeEnumeration realisationModeEnumeration = YP_TCD_DCC_Business.getRealisationMode(yP_TCD_DC_Transaction);
            if (transactionStatusEnumeration != null) {
                stringBuilder.append("RealisationMode :");
                stringBuilder.append((Object)realisationModeEnumeration);
                stringBuilder.append("\r\n");
            }
            if ((extendedTVR = yP_TCD_DC_Transaction.getExtendedTVR()) != null) {
                stringBuilder.append("Extended TVR :");
                for (ExtendedTVREnumeration extendedTVREnumeration : extendedTVR) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append((Object)extendedTVREnumeration);
                }
                stringBuilder.append("\r\n\r\n");
            }
            if ((l = yP_TCD_DC_Transaction.getAuthorisationReasonList()) != 0L) {
                stringBuilder.append("Authorization reason list :");
                if ((l & 1L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ALEA_CALL");
                }
                if ((l & 2L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ONLINE_ACCEPTOR");
                }
                if ((l & 4L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ONLINE_FOR_UPDATE");
                }
                if ((l & 8L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ONLINE_TERMINAL");
                }
                if ((l & 0x10L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ONLINE_CARD_ISSUER_SERVICE_CODE");
                }
                if ((l & 0x20L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("AMOUNT_ABOVE_FLOOR_LIMIT");
                }
                if ((l & 0x40L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("MERCHANT_SUSPICION");
                }
                if ((l & 0x80L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("BIN_FORBIDDEN");
                }
                if ((l & 0x100L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("CARD_FORBIDDEN");
                }
                if ((l & 0x200L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("CUMULATIVE_THRESHOLD");
                }
                if ((l & 0x400L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("BIN_WATCHED");
                }
                if ((l & 0x800L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("BIN_UNKNOWN");
                }
                if ((l & 0x1000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("CARD_WATCHED");
                }
                if ((l & 0x2000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("PRE_AUTHORIZATION");
                }
                if ((l & 0x4000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ONLINE_CARD_ISSUER_FLOW");
                }
                if ((l & 0x8000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("FOREIGN_CURRENCY");
                }
                if ((l & 0x10000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("UNKNOWN_CURRENCY");
                }
                if ((l & 0x20000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("CARD_REFUSED");
                }
                if ((l & 0x40000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("ARQC_CARD");
                }
                if ((l & 0x80000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("PRE_AUTHORIZATION_115");
                }
                if ((l & 0x100000L) != 0L) {
                    stringBuilder.append("\r\n - ");
                    stringBuilder.append("BIN_REFUSED");
                }
                stringBuilder.append("\r\n\r\n");
            }
            if (((entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction)) == EntryModeEnumeration.ENTRY_MODE_ICC || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) && (string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("tvr"))) != null && string.length() == 10) {
                byte[] byArray;
                Object object;
                Object object2;
                Object object3;
                stringBuilder.append("TVR : ");
                stringBuilder.append(string);
                byte[] byArray2 = UtilsYP.redHexa(string);
                if ((byArray2[0] & 0x80) != 0) {
                    stringBuilder.append("\r\n - Offline data authentication was not performed");
                }
                if ((byArray2[0] & 0x40) != 0) {
                    stringBuilder.append("\r\n - SDA Failed");
                }
                if ((byArray2[0] & 0x20) != 0) {
                    stringBuilder.append("\r\n - ICC data missing");
                }
                if ((byArray2[0] & 0x10) != 0) {
                    stringBuilder.append("\r\n - Card appears on terminal exception file");
                }
                if ((byArray2[0] & 8) != 0) {
                    stringBuilder.append("\r\n - DDA Failed");
                }
                if ((byArray2[0] & 4) != 0) {
                    stringBuilder.append("\r\n - CDA Failed");
                }
                if ((byArray2[0] & 2) != 0) {
                    stringBuilder.append("\r\n - SDA Selected");
                }
                if ((byArray2[0] & 1) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[1] & 0x80) != 0) {
                    stringBuilder.append("\r\n - ICC and terminal have different application versions");
                }
                if ((byArray2[1] & 0x40) != 0) {
                    stringBuilder.append("\r\n - Expired application");
                }
                if ((byArray2[1] & 0x20) != 0) {
                    stringBuilder.append("\r\n - Application not yet effective");
                }
                if ((byArray2[1] & 0x10) != 0) {
                    stringBuilder.append("\r\n - Requested service not allowed for card product");
                }
                if ((byArray2[1] & 8) != 0) {
                    stringBuilder.append("\r\n - New Card");
                }
                if ((byArray2[1] & 4) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[1] & 2) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[1] & 1) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[2] & 0x80) != 0) {
                    stringBuilder.append("\r\n - Cardholder verification was not successful");
                }
                if ((byArray2[2] & 0x40) != 0) {
                    stringBuilder.append("\r\n - Unrecognised CVM");
                }
                if ((byArray2[2] & 0x20) != 0) {
                    stringBuilder.append("\r\n - PIN Try Limit exceeded");
                }
                if ((byArray2[2] & 0x10) != 0) {
                    stringBuilder.append("\r\n - PIN entry required and PIN pad not present or not working");
                }
                if ((byArray2[2] & 8) != 0) {
                    stringBuilder.append("\r\n - PIN entry required, PIN pad present, but PIN was not entered");
                }
                if ((byArray2[2] & 4) != 0) {
                    stringBuilder.append("\r\n - Online PIN entered");
                }
                if ((byArray2[2] & 2) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[2] & 1) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[3] & 0x80) != 0) {
                    stringBuilder.append("\r\n - Transaction exceeds floor limit");
                }
                if ((byArray2[3] & 0x40) != 0) {
                    stringBuilder.append("\r\n - Lower consecutive offline limit exceeded");
                }
                if ((byArray2[3] & 0x20) != 0) {
                    stringBuilder.append("\r\n - Upper consecutive offline limit exceeded");
                }
                if ((byArray2[3] & 0x10) != 0) {
                    stringBuilder.append("\r\n - Transaction selected randomly for online");
                }
                if ((byArray2[3] & 8) != 0) {
                    stringBuilder.append("\r\n - Merchant forced transaction online");
                }
                if ((byArray2[3] & 4) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[3] & 2) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[3] & 1) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[4] & 0x80) != 0) {
                    stringBuilder.append("\r\n - Default TDOL used");
                }
                if ((byArray2[4] & 0x40) != 0) {
                    stringBuilder.append("\r\n - Issuer authentication failed");
                }
                if ((byArray2[4] & 0x20) != 0) {
                    stringBuilder.append("\r\n - Script processing failed before final GENERATE AC");
                }
                if ((byArray2[4] & 0x10) != 0) {
                    stringBuilder.append("\r\n - Script processing failed after final GENERATE AC");
                }
                if ((byArray2[4] & 8) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[4] & 4) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[4] & 2) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                if ((byArray2[4] & 1) != 0) {
                    stringBuilder.append("\r\n - RFU");
                }
                stringBuilder.append("\r\n\r\n");
                String string2 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("issuerActionCodeOnline"));
                String string3 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalActionCodeOnline"));
                if (string2 != null && string2.length() == 10 && string3 != null && string3.length() == 10) {
                    object3 = UtilsYP.redHexa(string2);
                    object2 = UtilsYP.redHexa(string3);
                    object = new byte[5];
                    int n = 0;
                    while (n < 5) {
                        object[n] = (byte)((object3[n] | object2[n]) & byArray2[n]);
                        ++n;
                    }
                    stringBuilder.append(" ,IAC Online  : ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" ,TAC Online  : ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" ,Online Reasons  : ");
                    stringBuilder.append(UtilsYP.devHexa((byte[])object));
                    stringBuilder.append("\r\n");
                }
                object = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("issuerActionCodeDenial"));
                object3 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalActionCodeDenial"));
                if (object != null && ((String)object).length() == 10 && object3 != null && ((String)object3).length() == 10) {
                    byte[] byArray3 = UtilsYP.redHexa((String)object);
                    byArray = UtilsYP.redHexa((String)object3);
                    object2 = new byte[5];
                    int n = 0;
                    while (n < 5) {
                        object2[n] = (byte)((byArray3[n] | byArray[n]) & byArray2[n]);
                        ++n;
                    }
                    stringBuilder.append(" ,IAC Denial  : ");
                    stringBuilder.append((String)object);
                    stringBuilder.append(" ,TAC Denial  : ");
                    stringBuilder.append((String)object3);
                    stringBuilder.append(" ,Denial Reasons  : ");
                    stringBuilder.append(UtilsYP.devHexa(object2));
                    stringBuilder.append("\r\n");
                }
                object2 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("issuerActionCodeDefault"));
                String string4 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalActionCodeDefault"));
                if (object2 != null && object2.length() == 10 && string4 != null && string4.length() == 10) {
                    byte[] byArray4 = UtilsYP.redHexa((String)object2);
                    byte[] byArray5 = UtilsYP.redHexa(string4);
                    byArray = new byte[5];
                    int n = 0;
                    while (n < 5) {
                        byArray[n] = (byte)((byArray4[n] | byArray5[n]) & byArray2[n]);
                        ++n;
                    }
                    stringBuilder.append(" ,IAC Default : ");
                    stringBuilder.append((String)object2);
                    stringBuilder.append(" ,TAC Default : ");
                    stringBuilder.append(string4);
                    stringBuilder.append(" ,Default Reasons : ");
                    stringBuilder.append(UtilsYP.devHexa(byArray));
                    stringBuilder.append("\r\n");
                }
            }
            this.logger(4, "logTransactionStatus() " + stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "logTransactionStatus() ", exception);
        }
    }

    protected void addReprintCustomerAction(DAO_Transaction dAO_Transaction, List<YP_TCD_DC_Context.Action> list) {
        Object object;
        Object object2;
        Object object3;
        String string = dAO_Transaction.getFieldStringValueByName("authorisationResponseBuffer");
        if (string != null && !string.isEmpty()) {
            object3 = new YP_TCD_DC_Context.Action();
            ((YP_TCD_DC_Context.Action)object3).applicationIdentifier = this.getContractIdentifier();
            ((YP_TCD_DC_Context.Action)object3).formName = "StandardNoConfirmationForm";
            ((YP_TCD_DC_Context.Action)object3).id = "ReprintCustomer";
            ((YP_TCD_DC_Context.Action)object3).label = this.getLabel("REPRINT_CUSTOMER");
            object2 = new ArrayList();
            object = new Property();
            ((Property)object).setName("TicketFormat");
            ((Property)object).setValue("HTML");
            object2.add(object);
            ((YP_TCD_DC_Context.Action)object3).propertiesList = object2;
            list.add((YP_TCD_DC_Context.Action)object3);
        }
        if ((object3 = this.getProcessPluginByThreadID(Thread.currentThread().getId())) instanceof YP_Transaction) {
            object2 = (YP_Transaction)object3;
            object = ((YP_Transaction)object2).getDataContainerTransaction().userHandler.getUserUID();
            if (object != null && (((String)object).contains("frenault") || ((String)object).contains("nlaporte"))) {
                YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                action.applicationIdentifier = this.getContractIdentifier();
                action.formName = "StandardNoConfirmationForm";
                action.id = "ReprintMerchant";
                action.label = this.getLabel("REPRINT_MERCHANT");
                ArrayList<Property> arrayList = new ArrayList<Property>();
                Property property = new Property();
                property.setName("TicketFormat");
                property.setValue("HTML");
                arrayList.add(property);
                action.propertiesList = arrayList;
                list.add(action);
            }
        }
    }

    private YP_TCD_DCC_Business getVADContainer(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        String string2;
        Object object2;
        YP_TCD_DCC_Business object3;
        block19: {
            object3 = null;
            if (this.getActivationCode() == null || !this.getActivationCode().contentEquals("1")) break block19;
            switch (this.getApplicationPlugin().getApplicationEnvironmentType()) {
                case "20": 
                case "24": {
                    if (!this.currencyInterface.isCurrencyActivated(string)) break;
                    object3 = this;
                }
            }
        }
        if (object3 == null) {
            object2 = this.getDataContainerMerchant().dataContainerBusinessList.iterator();
            while (object2.hasNext()) {
                YP_TCD_DCC_Business object4 = object2.next();
                if (!(object4 instanceof YP_TCD_DCC_EFT_Business) || !object4.getApplicationPlugin().getApplicationEnvironmentType().contentEquals("24") || object4.getActivationCode() == null || !object4.getActivationCode().contentEquals("1") || !((YP_TCD_DCC_EFT_Business)object4).currencyInterface.isCurrencyActivated(string)) continue;
                object3 = object4;
                break;
            }
        }
        if (object3 == null) {
            object2 = this.getDataContainerMerchant().dataContainerBusinessList.iterator();
            while (object2.hasNext()) {
                YP_TCD_DCC_Business yP_TCD_DCC_Business = object2.next();
                if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) || !yP_TCD_DCC_Business.getApplicationPlugin().getApplicationEnvironmentType().contentEquals("20") || yP_TCD_DCC_Business.getActivationCode() == null || !yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || !((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.isCurrencyActivated(string)) continue;
                object3 = yP_TCD_DCC_Business;
                break;
            }
        }
        if (object3 == null && (string2 = this.getParameter("manualRefundMerchant", true)) != null && !string2.isEmpty() && (object2 = (YP_TCD_DCC_Merchant)((YP_TS_DataContainerManager)this.transaction.getPluginByName("DataContainerManager")).dealRequest(this.transaction, "getDataContainerMerchant", Long.parseLong(string2))) != null) {
            block9: for (YP_TCD_DCC_Business yP_TCD_DCC_Business : ((YP_TCD_DCC_Merchant)object2).dataContainerBusinessList) {
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1")) continue;
                if (yP_TCD_DC_Transaction.userHandler.getUserIdentifier() > 0L) {
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business2 : yP_TCD_DC_Transaction.contextHandler.businessContainers) {
                        if (yP_TCD_DCC_Business2 != yP_TCD_DCC_Business) continue;
                        object3 = yP_TCD_DCC_Business;
                        break block9;
                    }
                    break;
                }
                object3 = yP_TCD_DCC_Business;
                break;
            }
        }
        if (object3 == null) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : this.getDataContainerMerchant().dataContainerBusinessList) {
                if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) || !yP_TCD_DCC_Business.getApplicationPlugin().getApplicationEnvironmentType().contentEquals("80") || yP_TCD_DCC_Business.getActivationCode() == null || !yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || !((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.isCurrencyActivated(string)) continue;
                object3 = yP_TCD_DCC_Business;
                break;
            }
        }
        return object3;
    }

    protected int addVADActions(YP_Transaction yP_Transaction, DAO_Transaction dAO_Transaction, List<YP_TCD_DC_Context.Action> list) {
        if (!yP_Transaction.getDataContainerTransaction().userHandler.isVadAllowed().booleanValue()) {
            return 0;
        }
        return 1;
    }

    private int addDebitAction(YP_Transaction yP_Transaction, DAO_Transaction dAO_Transaction, List<YP_TCD_DC_Context.Action> list, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        if (!UtilsYP.isTrue(this.getParameter("debitVADAllowed", true))) {
            return 0;
        }
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.applicationIdentifier = yP_TCD_DCC_Business.getContractIdentifier();
        action.formName = "StandardGenericForm";
        action.id = "Debit_VAD";
        action.label = DEBIT_VAD;
        action.propertiesList = new ArrayList<Property>();
        Property property = new Property();
        property.setName("LIBELLE_LABEL_FIELD");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("text", (Object)("Libelle : " + this.getDataContainerMerchant().getMerchantLabel()));
        String string = jSONObject.toString();
        property.setValue(string);
        action.propertiesList.add(property);
        property = new Property();
        property.setName("maskedAccountIdentifierLABEL_FIELD");
        jSONObject = new JSONObject();
        jSONObject.put("text", (Object)("Carte : " + dAO_Transaction.getFieldStringValueByName("maskedAccountIdentifier")));
        string = jSONObject.toString();
        property.setValue(string);
        action.propertiesList.add(property);
        property = new Property();
        property.setName("debitAmount_TEXT_FIELD_AMOUNT");
        jSONObject = new JSONObject();
        jSONObject.put("label", (Object)AMOUNT);
        jSONObject.put("text", (Object)"");
        jSONObject.put("currencyFraction", (Object)dAO_Transaction.getFieldStringValueByName("transactionAmountFraction"));
        jSONObject.put("currency", (Object)dAO_Transaction.getFieldStringValueByName("transactionCurrencyAlpha"));
        string = jSONObject.toString();
        property.setValue(string);
        action.propertiesList.add(property);
        property = new Property();
        property.setName("cvv_TEXT_FIELD");
        jSONObject = new JSONObject();
        jSONObject.put("label", (Object)CVV);
        jSONObject.put("text", (Object)"");
        string = jSONObject.toString();
        property.setValue(string);
        action.propertiesList.add(property);
        list.add(action);
        return 1;
    }

    private int addRefundAction(YP_Transaction yP_Transaction, DAO_Transaction dAO_Transaction, List<YP_TCD_DC_Context.Action> list, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        String string;
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.applicationIdentifier = yP_TCD_DCC_Business.getContractIdentifier();
        StringBuilder stringBuilder = new StringBuilder();
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "transactionAmount");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "transactionAmountFraction");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "transactionCurrencyNumerical");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "transactionCurrencyAlpha");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "idToken");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "maskedAccountIdentifier");
        this.addOneParamToForm(stringBuilder, dAO_Transaction, "merchantTransactionIdentifier");
        Timestamp timestamp = (Timestamp)dAO_Transaction.getFieldValueByName("accountExpirationDate");
        if (timestamp != null && timestamp.getTime() != 0L) {
            string = UtilsYP.getAAMMJJTime(UtilsYP.getCalendar(timestamp)).substring(0, 4);
            String string2 = String.valueOf(string.substring(2, 4)) + string.substring(0, 2);
            stringBuilder.append("&expirationDateMMAA=");
            stringBuilder.append(string2);
        }
        stringBuilder.append("&merchantLabel=");
        stringBuilder.append(this.getDataContainerMerchant().getMerchantLabel());
        string = dAO_Transaction.getFieldStringValueByName("transactionAmount");
        int n = (Integer)dAO_Transaction.getFieldValueByName("transactionAmountFraction");
        String string3 = dAO_Transaction.getFieldStringValueByName("transactionCurrencyAlpha");
        String string4 = String.valueOf(UtilsYP.formatAmount(string, n, Locale.FRANCE)) + " " + string3;
        stringBuilder.append("&maxAmountFormatted=");
        stringBuilder.append(string4);
        stringBuilder.append("&transactionAmountFraction=");
        stringBuilder.append(n);
        stringBuilder.append("&transactionCurrencyAlpha=");
        stringBuilder.append(string3);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("RefundForm?");
        stringBuilder2.append(stringBuilder.toString());
        action.formName = stringBuilder2.toString();
        action.id = "Refund";
        action.label = this.getLabel("ACTION_REFUND_VAD");
        list.add(action);
        return 1;
    }

    private int addOneParamToForm(StringBuilder stringBuilder, YP_Row yP_Row, String string) {
        if (stringBuilder.length() > 0) {
            stringBuilder.append('&');
        }
        stringBuilder.append(string);
        stringBuilder.append('=');
        stringBuilder.append(yP_Row.getFieldStringValueByName(string));
        return 1;
    }

    protected int executeDebitAction(YP_Transaction yP_Transaction, DAO_Transaction dAO_Transaction, YP_TCD_DC_Context.Action action) {
        return 1;
    }

    public int executeRequest(YP_Transaction yP_Transaction, YP_TCD_PosProtocol.REQUEST_TYPE rEQUEST_TYPE) {
        try {
            YP_TCD_DC_Transaction yP_TCD_DC_Transaction = yP_Transaction.getDataContainerTransaction();
            yP_TCD_DC_Transaction.setRequestType(rEQUEST_TYPE);
            yP_TCD_DC_Transaction.setSubRequestType(null);
            YP_Application yP_Application = this.newApplicationPlugin(yP_Transaction);
            yP_TCD_DC_Transaction.setContractIdentifier(this.getContractIdentifier());
            yP_Application.setContractIdentifier(this.getContractIdentifier());
            yP_Application.initialize();
            yP_Application.dealRequest(this.transaction, "dealTransaction", null);
            yP_Application.shutdown();
            return 1;
        }
        catch (Exception exception) {
            yP_Transaction.getDataContainerTransaction().logger(2, "executeRequest() ", exception);
            return -1;
        }
    }

    protected boolean isItAMPA(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        switch (this.getApplicationPlugin().getApplicationEnvironmentType()) {
            case "41": 
            case "42": 
            case "43": 
            case "44": 
            case "45": 
            case "46": 
            case "47": 
            case "48": 
            case "49": 
            case "50": 
            case "51": {
                return true;
            }
        }
        try {
            String string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalType"));
            return string != null && string.contentEquals("25");
        }
        catch (Exception exception) {
            return false;
        }
    }

    public void createTransactionTicket(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        block12: {
            String string;
            int n = this.putTicketsInsideAppTags(yP_TCD_DC_Transaction);
            if (n > 0) break block12;
            try {
                switch (this.getApplicationPlugin().getApplicationEnvironmentType()) {
                    case "24": {
                        string = this.getTransactionTicket(yP_TCD_DC_Transaction, false, 1);
                        break;
                    }
                    default: {
                        if (this.isItAMPA(yP_TCD_DC_Transaction)) {
                            string = this.getTransactionTicket(yP_TCD_DC_Transaction, false, 1);
                            break;
                        }
                        if (YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction) == EntryModeEnumeration.ENTRY_MODE_MANUAL) {
                            string = this.getTransactionTicket(yP_TCD_DC_Transaction, false, 1);
                            break;
                        }
                        string = this.getTransactionTicket(yP_TCD_DC_Transaction, false, 2);
                        break;
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "finalizeTransaction(): ", exception);
                string = this.getTransactionTicket(yP_TCD_DC_Transaction, false, 1);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "finalizeTransaction(): " + string);
            }
            yP_TCD_DC_Transaction.addTicket(string);
        }
    }

    private int putTicketsInsideAppTags(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            TLVHandler tLVHandler;
            TLV tLV;
            TLVHandler tLVHandler2;
            TLV tLV2;
            String string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
            if (string != null && !string.isEmpty() && (tLV2 = (tLVHandler2 = new TLVHandler(string)).getTLV(16769901)) != null && (tLV = (tLVHandler = new TLVHandler(tLV2.value)).getTLV(14672497)) != null) {
                Bitmap bitmap = new Bitmap(TLVHandler.getDCBLong(tLV.value));
                TLVHandler tLVHandler3 = new TLVHandler(yP_TCD_DC_Transaction.commonHandler.getResponseAppTags());
                if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER.getValue())) {
                    this.addOneTicket(yP_TCD_DC_Transaction, tLVHandler3, 14672663, false, 1);
                }
                if (!this.isItAMPA(yP_TCD_DC_Transaction) && bitmap.isSet(TicketTypeEnumeration.MERCHANT.getValue())) {
                    this.addOneTicket(yP_TCD_DC_Transaction, tLVHandler3, 14672664, false, 2);
                }
                if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER_HANDWRITTEN.getValue())) {
                    this.addOneTicket(yP_TCD_DC_Transaction, tLVHandler3, 14672755, false, 3);
                }
                if (bitmap.isSet(TicketTypeEnumeration.SMS_TICKET.getValue())) {
                    this.addOneTicket(yP_TCD_DC_Transaction, tLVHandler3, -538738382, false, 4);
                }
                yP_TCD_DC_Transaction.commonHandler.setResponseAppTags(tLVHandler3.toString());
                return 1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "putTicketsInsideAppTags() ", exception);
            return -1;
        }
        return 0;
    }

    private void addOneTicket(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TLVHandler tLVHandler, int n, boolean bl, int n2) {
        try {
            tLVHandler.addASCII(n, UtilsYP.base64Encode(this.getTransactionTicket(yP_TCD_DC_Transaction, bl, n2).getBytes("UTF-8")));
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            tLVHandler.addASCII(n, UtilsYP.base64Encode(this.getTransactionTicket(yP_TCD_DC_Transaction, bl, n2).getBytes()));
        }
    }

    public long getCurrencyChecksum() {
        if (this.currencyInterface == null) {
            return 0L;
        }
        long l = this.currencyInterface.getCurrencyChecksum();
        String string = this.getParameter("CurrencyList", true);
        if (string != null && !string.isEmpty()) {
            l += (long)string.hashCode();
        }
        return l;
    }

    public List<String> getListOfAuthorizedCurrency() {
        try {
            if (this.currencyInterface == null) {
                this.logger(3, "getListOfAuthorizedCurrency() currencyInterface null");
                return Collections.emptyList();
            }
            List<String> list = this.currencyInterface.getCurrencyAlphabeticalCodeList(true, false);
            if (list == null || list.size() == 0) {
                this.logger(3, "getListOfAuthorizedCurrency() currencyAlphabeticalCodeList empty");
                return Collections.emptyList();
            }
            String string = this.getParameter("CurrencyList", true);
            if (string != null && !string.isEmpty()) {
                ArrayList<String> arrayList = null;
                String[] stringArray = string.split(":");
                if (stringArray == null || stringArray.length <= 0) {
                    return list;
                }
                String[] stringArray2 = stringArray;
                int n = stringArray.length;
                int n2 = 0;
                while (n2 < n) {
                    String string2 = stringArray2[n2];
                    for (String string3 : list) {
                        if (!string3.toUpperCase().contentEquals(string2)) continue;
                        if (arrayList == null) {
                            arrayList = new ArrayList<String>();
                        }
                        arrayList.add(string3);
                    }
                    ++n2;
                }
                if (arrayList != null) {
                    return arrayList;
                }
            }
            return list;
        }
        catch (Exception exception) {
            this.logger(2, "getListOfAuthorizedCurrency() : ", exception);
            return Collections.emptyList();
        }
    }
}

