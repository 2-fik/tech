/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test29
extends YP_Row {
    @Index
    public byte[] test29Array1 = new byte[12];
    @Index
    public byte[] test29Array2 = new byte[12];
}

