/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects.DAO_InternationalizationLabel;

public class DAO_Internationalization
extends YP_Row {
    @PrimaryKey
    public long idInternationalization = 0L;
    @ForeignKey(name=DAO_InternationalizationLabel.class)
    public long idLabel = 0L;
    public byte[] translatedText = new byte[128];
    public byte[] languageCode = new byte[2];
}

