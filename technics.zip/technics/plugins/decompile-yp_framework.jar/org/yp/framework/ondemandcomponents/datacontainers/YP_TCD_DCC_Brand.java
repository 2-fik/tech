/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.lang.reflect.Field;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Agence;
import org.yp.designaccesobjects.brand.DAO_ContractInsideStore;
import org.yp.designaccesobjects.brand.DAO_Customer;
import org.yp.designaccesobjects.brand.DAO_MeanOfPayment;
import org.yp.designaccesobjects.brand.DAO_PDV;
import org.yp.designaccesobjects.brand.DAO_PointOfSaleAlias;
import org.yp.designaccesobjects.brand.DAO_ReservationDetails;
import org.yp.designaccesobjects.brand.DAO_Session;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.brand.DAO_Terminal;
import org.yp.designaccesobjects.brand.DAO_TerminalCountByMerchant;
import org.yp.designaccesobjects.brand.DAO_UserAuthentication;
import org.yp.designaccesobjects.brand.DAO_Ville;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.authentifiers.YP_Authentifiers;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.ReservationStatusEnumeration;
import org.yp.utils.enums.SessionStatusEnumeration;
import org.yp.utils.enums.StoreStatusEnumeration;
import org.yp.utils.enums.sorec.PDVStatusEnumeration;
import org.yp.utils.enums.sorec.PDVTypeEnumeration;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public final class YP_TCD_DCC_Brand
extends YP_TCD_DC_Context {
    private YP_TCD_DesignAccesObject customer;
    private YP_TCD_DesignAccesObject meanOfPayment;
    public YP_TCD_DesignAccesObject reservationDetails;
    public YP_TCD_DesignAccesObject session;
    private YP_TCD_DAO_SQL_Transaction terminal;
    private YP_TCD_DesignAccesObject terminalArchive;
    private YP_TCD_DAO_SQL_Transaction pdv;
    private YP_TCD_DAO_SQL_Transaction agence;
    private YP_TCD_DAO_SQL_Transaction ville;
    private YP_TCD_DesignAccesObject pointOfSaleAlias;
    private YP_TCD_DesignAccesObject userAuthentication;
    private YP_TCD_DesignAccesObject store;
    private YP_TCD_DesignAccesObject contractInsideStore;
    private YP_TCD_DAO_SQL_Transaction webTPE;
    private long idBrand = 0L;
    private YP_Row brandRow;
    private String brandName;
    private String brandLabel;
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    public List<YP_TCD_DCC_Merchant> dataContainerMerchantList = new ArrayList<YP_TCD_DCC_Merchant>();
    private YP_TS_DataContainerManager dataContainerManager;
    private static final int VALIDITY_PASSWORD_DAYS = 90;
    private static final int VALIDITY_TEMPORARY_PASSWORD_DAYS = 5;
    private static final Timestamp EMPTY_TIMESTAMP = new Timestamp(0L);
    private final Map<String, YP_Row> terminalMap = new ConcurrentHashMap<String, YP_Row>();
    private final Map<Long, YP_Row> terminalByPrimaryKeyMap = new ConcurrentHashMap<Long, YP_Row>();
    private final Map<Long, YP_Row> pdvMap = new ConcurrentHashMap<Long, YP_Row>();
    private final Map<String, YP_Row> pdvByReferenceMap = new ConcurrentHashMap<String, YP_Row>();
    private final Map<Integer, YP_Row> pdvByNumeroMap = new ConcurrentHashMap<Integer, YP_Row>();
    private final Map<String, Long> terminalInPdvMap = new ConcurrentHashMap<String, Long>();
    private final Map<Long, List<AbstractMap.SimpleEntry<Integer, String>>> pointOfSaleAliasMap = new ConcurrentHashMap<Long, List<AbstractMap.SimpleEntry<Integer, String>>>();
    private Boolean reservationDetailsEmpty = null;

    public YP_TCD_DCC_Brand(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray != null && objectArray.length > 0 && objectArray[0] != null && objectArray[0] instanceof YP_Row) {
                this.setBrandRow((YP_Row)objectArray[0]);
            }
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
            this.meanOfPayment = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_MeanOfPayment.class, 0, 0, null);
            this.customer = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Customer.class, 0, 0, null);
            this.reservationDetails = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_ReservationDetails.class, 0, 0, null);
            this.session = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Session.class, 0, 0, null);
            this.userAuthentication = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_UserAuthentication.class, 0, 0, null);
            this.terminal = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Terminal.class, 0, 0, null);
            this.terminalArchive = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Terminal.class, 0, 8, null);
            this.pdv = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_PDV.class, 0, 0, null);
            this.agence = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Agence.class, 0, 0, null);
            this.ville = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Ville.class, 0, 0, null);
            this.ville.getRowAt(0);
            this.agence.getRowAt(0);
            YP_Service yP_Service = (YP_Service)this.getPluginByName("Dispatcher");
            yP_Service.dealRequest(this, "addOneTerminalList", this.terminal);
            this.pointOfSaleAlias = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_PointOfSaleAlias.class, 0, 0, null);
            this.store = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Store.class, 0, 0, null);
            this.contractInsideStore = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_ContractInsideStore.class, 0, 0, null);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize()" + exception);
            }
            return -1;
        }
        return 1;
    }

    public final void setBrandRow(YP_Row yP_Row) {
        this.brandRow = yP_Row;
        this.idBrand = this.brandRow.getPrimaryKey();
        this.brandName = this.brandRow.getFieldStringValueByName("brandName");
        this.brandLabel = this.brandRow.getFieldStringValueByName("brandLabel");
        try {
            for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : this.dataContainerMerchantList) {
                yP_TCD_DCC_Merchant.setMerchantRow(yP_TCD_DCC_Merchant.getMerchantRow());
            }
        }
        catch (Exception exception) {}
        this.storedParameters = null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.customer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() customer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.meanOfPayment) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() meanOfPayment");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.reservationDetails) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() reservationDetails");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.session) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() session");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userAuthentication) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() userAuthentication");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminal) {
            block23: {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "onChange() terminal");
                }
                try {
                    this.getPluginByName("Dispatcher").dealRequest(this, "addTerminalListToReload", this.terminal);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) break block23;
                    this.logger(2, "onChange() terminal " + exception);
                }
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pointOfSaleAlias) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() pointOfSaleAlias");
            }
            if (UtilsYP.getInstanceRole() != 1) {
                this.pointOfSaleAliasMap.clear();
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.store) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() store");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractInsideStore) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contractInsideStore");
            }
            return 1;
        }
        if (this.webTPE != null && yP_TCD_DesignAccesObject == this.webTPE) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() webTPE");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.customer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() customer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.meanOfPayment) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() meanOfPayment");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.reservationDetails) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() reservationDetails");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.session) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() session");
            }
            if (yP_Row != null && yP_Row instanceof DAO_Session) {
                YP_TCD_DC_Transaction yP_TCD_DC_Transaction;
                DAO_Session dAO_Session = (DAO_Session)yP_Row;
                YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
                if (yP_Process != null && yP_Process instanceof YP_Transaction && (yP_TCD_DC_Transaction = ((YP_Transaction)yP_Process).getDataContainerTransaction()) != null) {
                    dAO_Session.idUser = yP_TCD_DC_Transaction.userHandler.getUserIdentifier();
                    dAO_Session.isAutomatic = yP_TCD_DC_Transaction.isItACronRequest();
                }
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userAuthentication) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() userAuthentication");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminal) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminal");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pointOfSaleAlias) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() pointOfSaleAlias");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.store) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() store");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractInsideStore) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() contractInsideStore");
            }
            return 1;
        }
        if (this.webTPE != null && yP_TCD_DesignAccesObject == this.webTPE) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() webTPE");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.customer) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() customer");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.meanOfPayment) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() meanOfPayment");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.reservationDetails) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() reservationDetails");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.session) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() session");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userAuthentication) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() userAuthentication");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminal) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminal");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pointOfSaleAlias) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() pointOfSaleAlias");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.store) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() store");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractInsideStore) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() contractInsideStore");
            }
            return 1;
        }
        if (this.webTPE != null && yP_TCD_DesignAccesObject == this.webTPE) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() webTPE");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    public String getBrandLabel() {
        return this.brandLabel;
    }

    public YP_Row getBrandRow() {
        return this.brandRow;
    }

    public long getIDBrand() {
        return this.idBrand;
    }

    @Override
    public int shutdown() {
        this.brandRow = null;
        this.dataContainerTechnique = null;
        this.dataContainerMerchantList.clear();
        this.dataContainerManager = null;
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerBrand";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "getCustomerByIdentifier": {
                    if (objectArray.length == 1 && objectArray[0] instanceof Long) {
                        return this.getCustomerByIdentifier((Long)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getCustomerByIdentifier  ");
                    }
                    return null;
                }
                case "getCustomerByMerchantIdentifier": {
                    if (objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.getCustomerByMerchantIdentifier((String)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getCustomerByMerchantIdentifier  ");
                    }
                    return null;
                }
                case "createNewCustomer": {
                    if (objectArray.length == 0) {
                        return this.createNewCustomer();
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for createNewCustomer  ");
                    }
                    return null;
                }
                case "updateCustomer": {
                    if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                        return this.updateCustomer((YP_Row)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for updateCustomer  ");
                    }
                    return null;
                }
                case "createNewMeanOfPayment": {
                    if (objectArray.length == 0) {
                        return this.createNewMeanOfPayment();
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for createNewMeanOfPayment  ");
                    }
                    return null;
                }
                case "updateMeanOfPayment": {
                    if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                        return this.updateMeanOfPayment((YP_Row)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for updateMeanOfPayment  ");
                    }
                    return null;
                }
                case "getMeanOfPaymentByIdentifiers": {
                    if (objectArray.length == 2 && objectArray[0] instanceof Long && objectArray[1] instanceof Long) {
                        return this.getMeanOfPaymentByIdentifiers((Long)objectArray[0], (Long)objectArray[1]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getMeanOfPaymentByIdentifiers  ");
                    }
                    return null;
                }
                case "getMeanOfPaymentListByCustomerIdentifier": {
                    if (objectArray.length == 1 && objectArray[0] instanceof Long) {
                        return this.getMeanOfPaymentListByCustomerIdentifier((Long)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getMeanOfPaymentListByCustomerIdentifier  ");
                    }
                    return null;
                }
                case "getIDBrand": {
                    if (objectArray.length == 0) {
                        return this.getIDBrand();
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getIDBrand  ");
                    }
                    return null;
                }
                case "createNewReservationDetails": {
                    if (objectArray.length == 0) {
                        return this.createNewReservationDetails();
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for createNewReservationDetails  ");
                    }
                    return null;
                }
                case "loadReferenceDetails": {
                    if (objectArray.length == 2 && objectArray[0] instanceof String && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                        return this.loadReferenceDetails((String)objectArray[0], (YP_TCD_DC_Transaction)objectArray[1]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for loadReferenceDetails  ");
                    }
                    return null;
                }
                case "getSession": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof Integer) {
                        int n = (Integer)objectArray[0];
                        return this.getSession(yP_Object, n);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getSession");
                    }
                    return null;
                }
                case "getNewSession": {
                    return this.getNewSession(yP_Object);
                }
                case "getSessionListToUpload": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        String string2 = (String)objectArray[0];
                        return this.getSessionListToUpload(string2);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getSessionListToUpload");
                    }
                    return null;
                }
                case "getSessionList": {
                    if (objectArray == null || objectArray.length != 3 || !(objectArray[0] instanceof String) || objectArray[1] != null && !(objectArray[1] instanceof Timestamp) || objectArray[2] != null && !(objectArray[2] instanceof Timestamp)) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameters for getSessionList");
                        }
                        return null;
                    }
                    String string3 = (String)objectArray[0];
                    Timestamp timestamp = (Timestamp)objectArray[1];
                    Timestamp timestamp2 = (Timestamp)objectArray[2];
                    return this.getSessionList(string3, timestamp, timestamp2);
                }
                case "getOpenReservationList": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        String string4 = (String)objectArray[0];
                        return this.getOpenReservationList(string4);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getOpenReservationList");
                    }
                    return null;
                }
                case "getTerminalRowList": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Business) {
                        YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)objectArray[0];
                        return this.getTerminalRowList(yP_TCD_DCC_Business);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getTerminalRowList");
                    }
                    return null;
                }
                case "getPointOfSaleAlias": {
                    if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof Long && objectArray[1] instanceof Integer) {
                        long l = (Long)objectArray[0];
                        int n = (Integer)objectArray[1];
                        return this.getPointOfSaleAlias(l, n);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getPointOfSaleAlias");
                    }
                    return null;
                }
                case "setPointOfSaleAlias": {
                    if (objectArray == null || objectArray.length != 3 || !(objectArray[0] instanceof Long) || !(objectArray[1] instanceof Integer) && objectArray[2] instanceof String) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameters for setPointOfSaleAlias");
                        }
                        return null;
                    }
                    long l = (Long)objectArray[0];
                    int n = (Integer)objectArray[1];
                    String string5 = (String)objectArray[2];
                    return this.setPointOfSaleAlias(l, n, string5);
                }
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest() request unknown " + string);
            }
            return null;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest() bad request ???  :" + exception);
            }
            return null;
        }
    }

    public YP_Row getReferenceTransaction(String string, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        List<YP_Row> list;
        YP_TCD_DCC_Business yP_TCD_DCC_Business;
        block11: {
            List list2;
            long l;
            block10: {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.reservationDetails);
                yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.MIN);
                List<YP_Row> list3 = this.reservationDetails.getRowListSuchAs(yP_ComplexGabarit);
                if (list3 == null || list3.isEmpty()) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "getReferenceTransaction() reservationReference not found :" + string);
                    }
                    return null;
                }
                l = (Long)list3.get(0).getFieldValueByName("idTransaction");
                String string2 = list3.get(0).getFieldStringValueByName("contractIdentifier");
                try {
                    list2 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", yP_TCD_DC_Transaction.getTransactionProcessFather(), string2, "");
                    if (list2 != null && list2.size() == 1) break block10;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction() blahblahblah :" + string);
                    }
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction()" + exception);
                    }
                    return null;
                }
            }
            yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list2.get(0);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transaction.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getReferenceTransaction() transaction not found we have to search in archive:");
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transactionArchive);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transactionArchive.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getReferenceTransaction() transaction not found :" + string);
            }
            return null;
        }
        yP_TCD_DC_Transaction.setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
        yP_TCD_DC_Transaction.getAncestor().setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
        return list.get(0);
    }

    public YP_Row getReferenceClosedTransaction(String string, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        List<YP_Row> list;
        block11: {
            List list2;
            long l;
            block10: {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.reservationDetails);
                yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.EQUAL, ReservationStatusEnumeration.CLOSED);
                List<YP_Row> list3 = this.reservationDetails.getRowListSuchAs(yP_ComplexGabarit);
                if (list3 == null || list3.isEmpty()) {
                    if (this.getLogLevel() >= 3) {
                        this.logger(3, "getReferenceClosedTransaction() reservationReference not found :" + string);
                    }
                    return null;
                }
                l = (Long)list3.get(0).getFieldValueByName("idTransaction");
                String string2 = list3.get(0).getFieldStringValueByName("contractIdentifier");
                try {
                    list2 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", yP_TCD_DC_Transaction.getTransactionProcessFather(), string2, "");
                    if (list2 != null && list2.size() == 1) break block10;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction() blahblahblah :" + string);
                    }
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction()" + exception);
                    }
                    return null;
                }
            }
            YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list2.get(0);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transaction.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getReferenceTransaction() transaction not found we have to search in archive:");
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transactionArchive);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transactionArchive.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getReferenceTransaction() transaction not found :" + string);
            }
            return null;
        }
        return list.get(0);
    }

    public YP_Row getReferenceCanceledTransaction(String string, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        List<YP_Row> list;
        block11: {
            List list2;
            long l;
            block10: {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.reservationDetails);
                yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.EQUAL, ReservationStatusEnumeration.CANCELED);
                List<YP_Row> list3 = this.reservationDetails.getRowListSuchAs(yP_ComplexGabarit);
                if (list3 == null || list3.isEmpty()) {
                    if (this.getLogLevel() >= 3) {
                        this.logger(3, "getReferenceClosedTransaction() reservationReference not found :" + string);
                    }
                    return null;
                }
                l = (Long)list3.get(0).getFieldValueByName("idTransaction");
                String string2 = list3.get(0).getFieldStringValueByName("contractIdentifier");
                try {
                    list2 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", yP_TCD_DC_Transaction.getTransactionProcessFather(), string2, "");
                    if (list2 != null && list2.size() == 1) break block10;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction() blahblahblah :" + string);
                    }
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getReferenceTransaction()" + exception);
                    }
                    return null;
                }
            }
            YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list2.get(0);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transaction.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getReferenceTransaction() transaction not found we have to search in archive:");
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transactionArchive);
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            list = yP_TCD_DCC_Business.transactionArchive.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block11;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getReferenceTransaction() transaction not found :" + string);
            }
            return null;
        }
        return list.get(0);
    }

    public YP_Row getCustomerByIdentifier(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.customer);
        yP_ComplexGabarit.set("idCustomer", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = this.customer.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerByIdentifier() customer not found :" + l);
            }
            return null;
        }
        if (list.size() > 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerByIdentifier() too many customers found :" + l);
            }
            return null;
        }
        if (list.size() != 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerByIdentifier() customer not found :" + l);
            }
            return null;
        }
        YP_Row yP_Row = list.get(0);
        return yP_Row;
    }

    public YP_Row getCustomerByMerchantIdentifier(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.customer);
        yP_ComplexGabarit.set("merchantIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        List<YP_Row> list = this.customer.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerByMerchantIdentifier() customer not found :" + string);
            }
            return null;
        }
        if (list.size() > 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerByMerchantIdentifier() too many customers found :" + string);
            }
            return null;
        }
        if (list.size() != 1) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getCustomerByMerchantIdentifier() customer not found :" + string);
            }
            return null;
        }
        YP_Row yP_Row = list.get(0);
        return yP_Row;
    }

    public YP_Row createNewCustomer() {
        try {
            YP_Row yP_Row = this.customer.getNewRow();
            yP_Row.setPrimaryKey(this.customer.getNextPrimaryKey());
            return yP_Row;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createNewCustomer() " + exception);
            }
            return null;
        }
    }

    public YP_Row createNewMeanOfPayment() {
        try {
            YP_Row yP_Row = this.meanOfPayment.getNewRow();
            yP_Row.setPrimaryKey(this.meanOfPayment.getNextPrimaryKey());
            try {
                Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
                yP_Row.set("creationSystemGMTTime", timestamp);
            }
            catch (Exception exception) {
                this.logger(2, "createNewMeanOfPayment() Ignored to avoid regresion", exception);
            }
            return yP_Row;
        }
        catch (Exception exception) {
            this.logger(2, "createNewMeanOfPayment() ", exception);
            return null;
        }
    }

    public int updateCustomer(YP_Row yP_Row) {
        try {
            yP_Row.setIsItAClonedRow(false);
            yP_Row.persist();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateCustomer() " + exception);
            }
            return -1;
        }
    }

    public int updateMeanOfPayment(YP_Row yP_Row) {
        try {
            yP_Row.setIsItAClonedRow(false);
            yP_Row.persist();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateMeanOfPayment() " + exception);
            }
            return -1;
        }
    }

    public YP_Row getMeanOfPaymentByIdentifiers(long l, long l2) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.meanOfPayment);
        yP_ComplexGabarit.set("idCustomer", YP_ComplexGabarit.OPERATOR.IN, 0L, l);
        yP_ComplexGabarit.set("idMeanOfPayment", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
        List<YP_Row> list = this.meanOfPayment.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMeanOfPaymentByIdentifiers() MeanOfPayment not found :" + l + " " + l2);
            }
            return null;
        }
        if (list.size() > 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMeanOfPaymentByIdentifiers() too many MeanOfPayments found :" + l + " " + l2);
            }
            return null;
        }
        if (list.size() != 1) {
            this.logger(3, "getMeanOfPaymentByIdentifiers() MeanOfPayment not found :" + l + " " + l2);
            return null;
        }
        YP_Row yP_Row = list.get(0);
        return yP_Row;
    }

    public List<YP_Row> getMeanOfPaymentListByCustomerIdentifier(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.meanOfPayment);
        yP_ComplexGabarit.set("idCustomer", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = this.meanOfPayment.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getMeanOfPaymentListByCustomerIdentifier() MeanOfPayment not found for customer :" + l);
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(3, "getMeanOfPaymentListByCustomerIdentifier() MeanOfPayment not found for customer :" + l);
            }
            return list;
        }
        return list;
    }

    public YP_Row createNewReservationDetails() {
        try {
            YP_Row yP_Row = this.reservationDetails.getNewRow();
            yP_Row.setPrimaryKey(this.reservationDetails.getNextPrimaryKey());
            yP_Row.setIsItAClonedRow(false);
            try {
                if (this.reservationDetailsEmpty == null || this.reservationDetailsEmpty.booleanValue()) {
                    this.reservationDetailsEmpty = false;
                }
            }
            catch (Exception exception) {
                this.logger(2, "createNewReservationDetails() reservationDetailsEmpty ", exception);
            }
            return yP_Row;
        }
        catch (Exception exception) {
            this.logger(2, "createNewReservationDetails() ", exception);
            return null;
        }
    }

    public int loadReferenceDetails(String string, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row = this.getReferenceTransaction(string, yP_TCD_DC_Transaction);
        if (yP_Row == null) {
            return 0;
        }
        yP_TCD_DC_Transaction.accountHandler.load(yP_Row);
        return 1;
    }

    public boolean isValidRequest(YP_Transaction yP_Transaction) {
        return this.checkValidRequest(yP_Transaction) >= 0;
    }

    public int checkValidRequest(YP_Transaction yP_Transaction) {
        return this.checkStandardValidRequest(yP_Transaction);
    }

    private int checkStandardValidRequest(YP_Transaction yP_Transaction) {
        YP_TCD_PosProtocol.REQUEST_TYPE rEQUEST_TYPE = yP_Transaction.getDataContainerTransaction().getRequestType();
        if (rEQUEST_TYPE == null) {
            return -1;
        }
        return 1;
    }

    public String getBrandName() {
        return this.brandName;
    }

    public YP_Row getSession(YP_Object yP_Object, int n) {
        if (n == -1) {
            return this.session.getNewRow();
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Object.getContractIdentifier());
        yP_ComplexGabarit.set("sessionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, n);
        List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getSession() session not found:" + yP_Object.getContractIdentifier() + " " + n);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getSession() more than one row !!! only the first one will be handled");
        }
        return list.get(0);
    }

    public YP_Row getLastSession(YP_Object yP_Object) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Object.getContractIdentifier());
        yP_ComplexGabarit.set("sessionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(3, "getLastSession() session not found:" + yP_Object.getContractIdentifier());
            return null;
        }
        if (list.size() > 1) {
            this.logger(3, "getLastSession() more than one row !!! only the first one will be handled");
        }
        return list.get(0);
    }

    public YP_Row getNewSession(YP_Object yP_Object) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Object.getContractIdentifier());
            YP_Row yP_Row = this.session.getNewRow();
            yP_Row.setPrimaryKey(this.session.getNextPrimaryKey());
            yP_Row.set("applicationIdentifier", yP_Object.getContractIdentifier());
            if (yP_Object instanceof YP_TCD_DCC_Business) {
                yP_Row.set("idContract", ((YP_TCD_DCC_Business)yP_Object).getIDContract());
            }
            try {
                int n;
                yP_ComplexGabarit.set("sessionNumber", YP_ComplexGabarit.OPERATOR.MAX);
                this.session.lock();
                try {
                    List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null || list.isEmpty()) {
                        n = 1;
                    } else {
                        n = (Integer)list.get(0).getFieldValueByName("sessionNumber");
                        ++n;
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getNewSession() " + exception);
                    }
                    n = 1;
                }
                yP_Row.set("sessionNumber", n);
                yP_Row.set("status", SessionStatusEnumeration.UNKNOWN);
                this.session.addRow(yP_Row, true);
                this.session.persist();
            }
            finally {
                this.session.unlock();
            }
            return yP_Row;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getNewSession() " + exception);
            }
            return null;
        }
    }

    private void addTerminalRowToTerminalMap(YP_Row yP_Row) {
        if (yP_Row != null) {
            String string = yP_Row.getFieldStringValueByName("terminalIP");
            this.terminalMap.put(string, yP_Row);
            this.terminalByPrimaryKeyMap.put(yP_Row.getPrimaryKey(), yP_Row);
        } else {
            this.logger(2, "addTerminalRowToTerminalMap() terminal row is null");
        }
    }

    private void addPdvRowToPdvMap(String string, YP_Row yP_Row) {
        if (yP_Row != null) {
            this.pdvMap.put(yP_Row.getPrimaryKey(), yP_Row);
            this.pdvByReferenceMap.put(yP_Row.getFieldStringValueByName("referencePDV"), yP_Row);
            this.pdvByNumeroMap.put((int)((Integer)yP_Row.getFieldValueByName("numeroPDV")), yP_Row);
            if (string != null) {
                this.terminalInPdvMap.put(string, yP_Row.getPrimaryKey());
            }
        } else {
            this.logger(2, "addTerminalRowToTerminalMap() pdv row is null");
        }
    }

    public List<YP_Row> getTerminalRowList(YP_ComplexGabarit yP_ComplexGabarit) {
        return this.getLastRowListFromTerminalRowList(this.terminal.getRowListSuchAs(yP_ComplexGabarit), true);
    }

    public List<YP_Row> getTerminalRowList(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        try {
            long l = yP_TCD_DCC_Business.getContractRow().getPrimaryKey();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.contractInsideStore);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            List<Object> list = this.contractInsideStore.getDistinctValueListSuchAs("idStore", yP_ComplexGabarit);
            long l2 = yP_TCD_DCC_Business.getDataContainerMerchant().getMerchantRow().getPrimaryKey();
            yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
            yP_ComplexGabarit.set("firstGMTTime", YP_ComplexGabarit.OPERATOR.DIFFERENT, EMPTY_TIMESTAMP);
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.GREATER, 0);
            if (list == null || list.isEmpty()) {
                yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
            } else {
                yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.IN, (Object)list);
            }
            yP_ComplexGabarit.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
            List<YP_Row> list2 = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
            if (list2 == null || list2.isEmpty()) {
                return list2;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
            list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list2, yP_ComplexGabarit);
            yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
            yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TerminalStatusEnumeration.A_JOUR, TerminalStatusEnumeration.EN_COURS_MAJ, TerminalStatusEnumeration.NON_MAJ});
            list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list2, yP_ComplexGabarit);
            return this.getLastRowListFromTerminalRowList(list2, true);
        }
        catch (Exception exception) {
            this.logger(2, "getTerminalRowList() ", exception);
            return null;
        }
    }

    public List<YP_Row> getTerminalRowList() {
        this.terminalMap.clear();
        return this.getTerminalRowList(null, null);
    }

    public List<YP_Row> getTerminalRowList(Timestamp timestamp) {
        return this.getTerminalRowList(timestamp, null);
    }

    public List<YP_Row> getTerminalRowList(Timestamp timestamp, Timestamp timestamp2) {
        try {
            List<YP_Row> list;
            int n = 0;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            do {
                if ((list = this.getTerminalRowList(timestamp, timestamp2, n, 1000)) == null) continue;
                arrayList.addAll(list);
                n += 1000;
            } while (list != null && list.size() == 1000);
            return this.getLastRowListFromTerminalRowList(arrayList, timestamp2 == null);
        }
        catch (Exception exception) {
            this.logger(2, "getTerminalRowList() " + exception);
            return null;
        }
    }

    private List<YP_Row> getLastRowListFromTerminalRowList(List<YP_Row> list, boolean bl) {
        if (list == null) {
            return null;
        }
        if (list.isEmpty()) {
            return list;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
        yP_ComplexGabarit.set("idTerminalCan", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set(this.terminal.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.MAX);
        yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
        List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
        if (bl && list2 != null && !list2.isEmpty()) {
            for (YP_Row yP_Row : list2) {
                YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(this.pdv);
                yP_ComplexGabarit2.set(this.pdv.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row.getFieldValueByName("idPdv"));
                List<YP_Row> list3 = this.pdv.getRowListSuchAs(0, 1, yP_ComplexGabarit2);
                if (list3 == null || list3.isEmpty()) {
                    this.logger(2, "getLastRowListFromTerminalRowList() pdv row not found");
                    return null;
                }
                this.addTerminalRowToTerminalMap(yP_Row);
                String string = yP_Row.getFieldStringValueByName("terminalIP");
                this.addPdvRowToPdvMap(string, list3.get(0));
            }
        }
        return list2;
    }

    private YP_Row getLastRowFromTerminalRowList(List<YP_Row> list, boolean bl) {
        Object object;
        if (list == null || list.isEmpty()) {
            return null;
        }
        if (list.size() > 0) {
            object = new YP_ComplexGabarit(this.terminal);
            ((YP_ComplexGabarit)object).set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
            list = YP_TCD_DesignAccesObject.getRowListSuchAs(list, new YP_ComplexGabarit[]{object});
            if (list == null || list.isEmpty()) {
                return null;
            }
        }
        if (list.size() > 0) {
            object = new YP_ComplexGabarit(this.terminal);
            ((YP_ComplexGabarit)object).set(this.terminal.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.MAX);
            list = YP_TCD_DesignAccesObject.getRowListSuchAs(list, new YP_ComplexGabarit[]{object});
            if (list == null || list.isEmpty()) {
                return null;
            }
        }
        list.size();
        object = list.get(0);
        if (bl) {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pdv);
            yP_ComplexGabarit.set(this.pdv.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, (Long)((YP_Row)object).getFieldValueByName("idPdv"));
            List<YP_Row> list2 = this.pdv.getRowListSuchAs(0, 1, yP_ComplexGabarit);
            if (list2 == null || list2.isEmpty()) {
                this.logger(2, "getLastRowListFromTerminalRowList() pdv row not found");
                return null;
            }
            this.addTerminalRowToTerminalMap((YP_Row)object);
            String string = ((YP_Row)object).getFieldStringValueByName("terminalIP");
            this.addPdvRowToPdvMap(string, list2.get(0));
        }
        return object;
    }

    private YP_ComplexGabarit getTerminalListGabarit() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
        yP_ComplexGabarit.set("idTerminalCan", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
        return yP_ComplexGabarit;
    }

    private List<YP_Row> getTerminalRowList(Timestamp timestamp, Timestamp timestamp2, int n, int n2) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = this.getTerminalListGabarit();
            if (timestamp == null && timestamp2 == null) {
                return this.terminal.getRowListSuchAs(n, n2, yP_ComplexGabarit);
            }
            if (timestamp != null) {
                yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, timestamp);
            }
            if (timestamp2 != null) {
                yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, timestamp2);
            }
            return this.terminal.getRowListSuchAs(n, n2, yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "getTerminalRowList() ", exception);
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public YP_Row getTerminalRow(String string, boolean bl) {
        List<YP_Row> list;
        YP_Row yP_Row;
        block5: {
            block4: {
                try {
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
                    yP_ComplexGabarit.set("idTerminalCan", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)Long.valueOf(string));
                    yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
                    yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                    List<YP_Row> list2 = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
                    if (list2 != null && !list2.isEmpty()) return this.getLastRowFromTerminalRowList(list2, true);
                    this.logger(3, "getTerminalRow() not found:" + string);
                    if (bl) break block4;
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "getTerminalRow() ", exception);
                    return null;
                }
            }
            yP_Row = this.terminal.getNewRow();
            yP_Row.set("idTerminalCan", Long.valueOf(string));
            Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
            yP_Row.set("firstGMTTime", timestamp);
            yP_Row.set("lastGMTTime", timestamp);
            yP_Row.set("terminalStatus", TerminalStatusEnumeration.A_JOUR);
            yP_Row.set("statusModificationGMTTime", timestamp);
            yP_Row.setIsItAClonedRow(false);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pdv);
            yP_ComplexGabarit.set(this.pdv.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row.getFieldValueByName("idPdv"));
            list = this.pdv.getRowListSuchAs(0, 1, yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block5;
            this.logger(2, "getLastRowListFromTerminalRowList() pdv row not found");
            return null;
        }
        this.addTerminalRowToTerminalMap(yP_Row);
        String string2 = yP_Row.getFieldStringValueByName("terminalIP");
        this.addPdvRowToPdvMap(string2, list.get(0));
        return yP_Row;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public YP_Row getPdvRow(String string, boolean bl) {
        block3: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pdv);
                yP_ComplexGabarit.set("referencePDV", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("pdvStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, PDVStatusEnumeration.FERME);
                yP_ComplexGabarit.set("pdvStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, PDVStatusEnumeration.FERME);
                List<YP_Row> list = this.pdv.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) return list.get(0);
                this.logger(3, "getPdvRow() not found:" + string);
                if (bl) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        YP_Row yP_Row = this.pdv.getNewRow();
        yP_Row.set("referencePDV", string);
        Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_Row.set("terminalStatus", PDVStatusEnumeration.ACTIF);
        yP_Row.set("statusModificationGMTTime", timestamp);
        yP_Row.setIsItAClonedRow(false);
        return yP_Row;
    }

    public YP_Row getTerminalRowWithIdMerchant(String string, long l) {
        List<YP_Row> list;
        block5: {
            String[] stringArray;
            block4: {
                try {
                    stringArray = string.split("_");
                    if (stringArray != null && stringArray.length == 2) break block4;
                    this.logger(2, "getTerminalRowWithIdMerchant() bad terminalIdentifier !!:" + string);
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "getTerminalRowWithIdMerchant() ", exception);
                    return null;
                }
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
            yP_ComplexGabarit.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.EQUAL, stringArray[0]);
            yP_ComplexGabarit.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.EQUAL, stringArray[1]);
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
            yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
            list = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block5;
            this.logger(3, "getTerminalRowWithIdMerchant() not found:" + string);
            return null;
        }
        return this.getLastRowFromTerminalRowList(list, false);
    }

    @Deprecated
    public YP_Row getTerminalRow(String string) {
        return this.getTerminalRow(string, true);
    }

    public YP_Row getTerminalRow(long l, String string) {
        List<YP_Row> list;
        block4: {
            try {
                YP_Row yP_Row = this.terminalMap.get(string);
                if (yP_Row != null) {
                    return yP_Row;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
                yP_ComplexGabarit.set("ip", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
                list = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getTerminalRow() not found:" + l + " : " + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        return this.getLastRowFromTerminalRowList(list, true);
    }

    public YP_Row getTerminalRowByIp(String string) {
        List<YP_Row> list;
        block4: {
            try {
                YP_Row yP_Row = this.terminalMap.get(string);
                if (yP_Row != null) {
                    return yP_Row;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
                yP_ComplexGabarit.set("terminalIP", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
                list = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getTerminalRow() not found:" + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        return this.getLastRowFromTerminalRowList(list, true);
    }

    public YP_Row getTerminalRowByPrimaryKey(long l) {
        List<YP_Row> list;
        block4: {
            try {
                YP_Row yP_Row = this.terminalByPrimaryKeyMap.get(l);
                if (yP_Row != null) {
                    return yP_Row;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
                yP_ComplexGabarit.set(this.terminal.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, l);
                yP_ComplexGabarit.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit.set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
                list = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getTerminalRow() not found:" + l);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        return this.getLastRowFromTerminalRowList(list, true);
    }

    public YP_Row getPdvRowByTerminalIp(String string) {
        block5: {
            List<YP_Row> list;
            YP_Row yP_Row;
            block7: {
                List<YP_Row> list2;
                block6: {
                    try {
                        Object object;
                        yP_Row = null;
                        if (string != null && this.terminalInPdvMap.containsKey(string) && this.pdvMap.containsKey(object = this.terminalInPdvMap.get(string)) && (yP_Row = this.pdvMap.get(object)) != null) {
                            return yP_Row;
                        }
                        if (string == null) break block5;
                        object = new YP_ComplexGabarit(this.terminal);
                        ((YP_ComplexGabarit)object).set("terminalIP", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                        ((YP_ComplexGabarit)object).set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                        ((YP_ComplexGabarit)object).set("terminalStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, TerminalStatusEnumeration.DELETED);
                        list2 = this.terminal.getRowListSuchAs(new YP_ComplexGabarit[]{object});
                        if (list2 != null && !list2.isEmpty()) break block6;
                        this.logger(3, "getPdvRowByTerminalIp() terminal not found:" + string);
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "getTerminalRow() ", exception);
                        return null;
                    }
                }
                YP_Row yP_Row2 = this.getLastRowFromTerminalRowList(list2, true);
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pdv);
                yP_ComplexGabarit.set("idPdv", YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row2.getFieldValueByName("idPdv"));
                list = this.pdv.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block7;
                this.logger(3, "getPdvRow() not found:" + string);
                return null;
            }
            yP_Row = list.get(0);
            this.addPdvRowToPdvMap(string, list.get(0));
            return yP_Row;
        }
        return null;
    }

    public YP_Row getPdvRowByReference(String string) {
        List<YP_Row> list;
        block4: {
            try {
                Object object;
                if (this.pdvByReferenceMap.containsKey(string) && (object = this.pdvByReferenceMap.get(string)) != null) {
                    return object;
                }
                object = new YP_ComplexGabarit(this.pdv);
                ((YP_ComplexGabarit)object).set("referencePDV", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.pdv.getRowListSuchAs(new YP_ComplexGabarit[]{object});
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getPdvRow() not found:" + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        this.addPdvRowToPdvMap(null, list.get(0));
        return list.get(0);
    }

    public YP_Row getPdvRowByNumero(int n) {
        List<YP_Row> list;
        block4: {
            try {
                Object object;
                if (this.pdvByNumeroMap.containsKey(n) && (object = this.pdvByNumeroMap.get(n)) != null) {
                    return object;
                }
                object = new YP_ComplexGabarit(this.pdv);
                ((YP_ComplexGabarit)object).set("numeroPDV", YP_ComplexGabarit.OPERATOR.EQUAL, n);
                list = this.pdv.getRowListSuchAs(new YP_ComplexGabarit[]{object});
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getPdvRow() not found:" + n);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        this.addPdvRowToPdvMap(null, list.get(0));
        return list.get(0);
    }

    public YP_Row getPdvRowByPrimaryKey(long l) {
        List<YP_Row> list;
        block4: {
            try {
                Object object;
                if (this.pdvMap.containsKey(l) && (object = this.pdvMap.get(l)) != null) {
                    return object;
                }
                object = new YP_ComplexGabarit(this.pdv);
                ((YP_ComplexGabarit)object).set(this.pdv.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, l);
                list = this.pdv.getRowListSuchAs(new YP_ComplexGabarit[]{object});
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getPdvRow() not found:" + l);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTerminalRow() ", exception);
                return null;
            }
        }
        this.addPdvRowToPdvMap(null, list.get(0));
        return list.get(0);
    }

    public int getNextNLPA(long l) {
        List<YP_Row> list;
        block4: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminal);
                yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.MAX);
                list = this.terminal.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                return 1;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getNextNLPA() " + exception);
                }
                return 1;
            }
        }
        int n = (Integer)list.get(0).getFieldValueByName("nlpa");
        return n + 1;
    }

    public boolean isMPOS(YP_Row yP_Row) {
        YP_Row yP_Row2;
        block7: {
            long l;
            block6: {
                block5: {
                    try {
                        if (yP_Row != null) break block5;
                        return false;
                    }
                    catch (Exception exception) {
                        this.logger(2, "isMPOS() exception:" + exception);
                        return false;
                    }
                }
                l = (Long)yP_Row.getFieldValueByName("idTerminalReference");
                if (l > 0L) break block6;
                return false;
            }
            yP_Row2 = this.dataContainerTechnique.getTerminalReferenceRow(l);
            if (yP_Row2 != null) break block7;
            this.logger(2, "isMPOS() unable to get terminal reference row!!!");
            return false;
        }
        Boolean bl = (Boolean)yP_Row2.getFieldValueByName("mposDevice");
        return bl != null && bl != false;
    }

    public int archiveTerminal() {
        if (UtilsYP.getInstanceRole() != 1) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "archiveTerminal() only on master !!!");
            }
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" INNER JOIN\r\n");
        stringBuilder.append("( SELECT idTerminalCan AS idTerminalCanTMP, MAX(statusModificationGMTTime) AS maxGMTTime\r\n");
        stringBuilder.append("FROM ");
        stringBuilder.append(this.terminal.getFullTableName());
        stringBuilder.append(" GROUP BY idTerminalCan \r\n");
        stringBuilder.append(") tmp\r\n");
        stringBuilder.append("ON idTerminalCan = idTerminalCanTMP \r\n");
        stringBuilder.append("AND statusModificationGMTTime <> maxGMTTime ");
        int n = this.terminal.archiveRowsSuchAs(this.terminalArchive, true, stringBuilder.toString());
        return n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private YP_Row binarySearch(Field field, long l, List<YP_Row> list) {
        try {
            int n = 0;
            int n2 = list.size() - 1;
            if (n2 < 0) {
                return null;
            }
            while (true) {
                if (n > n2) {
                    return null;
                }
                int n3 = (n + n2) / 2;
                YP_Row yP_Row = list.get(n3);
                long l2 = (Long)yP_Row.getFieldValue(field);
                if (l2 < l) {
                    n = n3 + 1;
                    continue;
                }
                if (l2 <= l) {
                    return yP_Row;
                }
                n2 = n3 - 1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "binarySearch() " + exception);
            return null;
        }
    }

    public int countTerminals() {
        if (UtilsYP.getInstanceRole() != 1) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "countTerminals() only on master !!!");
            }
            return 0;
        }
        this.archiveTerminal();
        YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table = null;
        try {
            yP_TCD_DAO_LOC_Table = (YP_TCD_DAO_LOC_Table)this.dataContainerTechnique.newPluginByName("DAO_Table", DAO_TerminalCountByMerchant.class, 0, 1, null);
            Field field = yP_TCD_DAO_LOC_Table.getFieldByName("idMerchant");
            Field field2 = yP_TCD_DAO_LOC_Table.getFieldByName("nbTerminals");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT idMerchant, COUNT(*) AS nbTerminals\r\n");
            stringBuilder.append("FROM " + this.terminal.getFullTableName() + "\r\n");
            stringBuilder.append("WHERE terminalStatus IN ('ACTIVE', 'DECLARED')\r\n");
            stringBuilder.append("GROUP BY idMerchant\r\n");
            stringBuilder.append("ORDER BY idMerchant ASC\r\n");
            List<YP_Row> list = this.terminal.getDataBaseConnector().dealSelect((YP_TCD_DesignAccesObject)this.terminal, yP_TCD_DAO_LOC_Table, stringBuilder.toString());
            if (list != null && !list.isEmpty()) {
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : this.dataContainerMerchantList) {
                    YP_Row yP_Row;
                    int n;
                    long l = yP_TCD_DCC_Merchant.getIDMerchant();
                    YP_Row yP_Row2 = yP_TCD_DCC_Merchant.getMerchantRow();
                    int n2 = (Integer)yP_Row2.getFieldValueByName("terminalCountCalculated");
                    if (n2 == (n = (yP_Row = this.binarySearch(field, l, list)) == null ? 0 : (Integer)yP_Row.getFieldValue(field2))) continue;
                    try {
                        yP_Row2.set("terminalCountCalculated", n);
                        yP_Row2.persist();
                    }
                    catch (Exception exception) {
                        this.logger(2, "countTerminals() ", exception);
                    }
                }
            }
        }
        finally {
            yP_TCD_DAO_LOC_Table.shutdown();
        }
        return 1;
    }

    public String getPointOfSaleAlias(long l, int n) {
        try {
            AbstractMap.SimpleEntry<Integer, String> simpleEntry2;
            List<AbstractMap.SimpleEntry<Integer, String>> list = this.pointOfSaleAliasMap.get(l);
            if (list == null) {
                list = new ArrayList<AbstractMap.SimpleEntry<Integer, String>>();
                this.pointOfSaleAliasMap.put(l, list);
            }
            for (AbstractMap.SimpleEntry<Integer, String> simpleEntry2 : list) {
                if (simpleEntry2.getKey() != n) continue;
                return simpleEntry2.getValue();
            }
            simpleEntry2 = null;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pointOfSaleAlias);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, n);
            List<YP_Row> list2 = this.pointOfSaleAlias.getRowListSuchAs(yP_ComplexGabarit);
            if (list2 != null && !list2.isEmpty() && (simpleEntry2 = list2.get(0).getFieldStringValueByName("alias")) != null) {
                simpleEntry2 = ((String)((Object)simpleEntry2)).trim();
            }
            AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Integer, String>> simpleEntry3 = new AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Integer, String>>(n, simpleEntry2);
            list.add(simpleEntry3);
            return simpleEntry2;
        }
        catch (Exception exception) {
            this.logger(2, "getPointOfSaleAlias() " + exception);
            return null;
        }
    }

    public int resetPointOfSaleAlias(long l) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pointOfSaleAlias);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            this.pointOfSaleAlias.deleteRowsSuchAs(yP_ComplexGabarit);
            this.pointOfSaleAlias.persist();
            List<AbstractMap.SimpleEntry<Integer, String>> list = this.pointOfSaleAliasMap.get(l);
            if (list != null) {
                list.clear();
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "resetPointOfSaleAlias() " + exception);
            return -1;
        }
    }

    public int setPointOfSaleAlias(long l, int n, String string) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pointOfSaleAlias);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, n);
            YP_Row yP_Row = this.pointOfSaleAlias.getNewRow();
            yP_Row.set("idContract", l);
            yP_Row.set("nlpa", n);
            yP_Row.set("alias", string);
            if (this.pointOfSaleAlias.updateRowSuchAs(yP_Row, yP_ComplexGabarit) <= 0) {
                this.pointOfSaleAlias.addRow(yP_Row);
            }
            this.pointOfSaleAlias.persist();
            List<AbstractMap.SimpleEntry<Integer, String>> list = this.pointOfSaleAliasMap.get(l);
            if (list != null) {
                for (AbstractMap.SimpleEntry<Integer, String> simpleEntry : list) {
                    if (simpleEntry.getKey() != n) continue;
                    simpleEntry.setValue(string);
                }
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setPointOfSaleAlias() " + exception);
            return -1;
        }
    }

    public long getLasdtFileSequenceNumber(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("fileSequenceNumber", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(4, "getSessionListToUpload() session not found :" + string);
            return 0L;
        }
        long l = 0L;
        try {
            l = (Long)list.get(0).getFieldValueByName("fileSequenceNumber");
        }
        catch (Exception exception) {
            this.logger(2, "getSessionListToUpload() fileSequenceNumber :", exception);
        }
        return l;
    }

    public List<YP_Row> getSessionListToUpload(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.DIFFERENT, SessionStatusEnumeration.UPLOADED);
        List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getSessionListToUpload() session not found :" + string);
            }
            return list;
        }
        return list;
    }

    public List<YP_Row> getSessionListToUpload(String string, String string2) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("currencyAlphabeticalCode", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.DIFFERENT, SessionStatusEnumeration.UPLOADED);
        List<YP_Row> list = this.session.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getSessionListToUpload() session not found :" + string);
            }
            return list;
        }
        return list;
    }

    public List<YP_Row> getOpenReservationList(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.reservationDetails);
        yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.MAX);
        yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        yP_ComplexGabarit.set("status", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, new Object[]{ReservationStatusEnumeration.INITIAL, ReservationStatusEnumeration.ADDITIONAL});
        List<YP_Row> list = this.reservationDetails.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getOpenReservationList() no reservation opened :" + string);
            }
            return list;
        }
        return list;
    }

    public List<YP_Row> getSessionList(String string, Timestamp timestamp, Timestamp timestamp2) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.session);
        String[] stringArray = string.split("_");
        if (stringArray.length < 4) {
            string = string.concat("_");
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        } else {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        if (timestamp != null) {
            yP_ComplexGabarit.set("sessionAppliLocalTime", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, timestamp);
        }
        if (timestamp2 != null) {
            yP_ComplexGabarit.set("sessionAppliLocalTime", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, timestamp2);
        }
        yP_ComplexGabarit.set("sessionAppliLocalTime", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list = this.session.getRowListSuchAs(0, 1000, yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getSessionList() session not found :" + string);
            }
            return list;
        }
        return list;
    }

    public static YP_TCD_DCC_Brand getBrandForUserAction(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null || list.isEmpty()) {
            yP_Transaction.logger(2, "getBrandForUserAction() No brand");
            return null;
        }
        if (n == 1) {
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
                if (!yP_TCD_DCC_Brand.getContractIdentifier().contentEquals("YouPay") && list.size() != 1) continue;
                return yP_TCD_DCC_Brand;
            }
            yP_Transaction.logger(2, "getBrandForUserAction() Should never happens");
            return null;
        }
        if (list.size() > 1) {
            yP_Transaction.logger(2, "getBrandForUserAction() Brand on which the user is related must be setted:" + yP_Row.getFieldStringValueByName("login"));
            if (UtilsYP.isSATIMServer()) {
                yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Veuillez vous positionner sur une banque");
            } else {
                yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Veuillez vous positionner sur une enseigne");
            }
            return null;
        }
        return list.get(0);
    }

    private boolean checkPasswordValidity(String string, StringBuilder stringBuilder) {
        if (string == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "checkPasswordValidity() password null!!!");
            }
            return false;
        }
        if (string.length() < 7) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "checkPasswordValidity() password must contain at least 7 characters: " + string.length());
            }
            if (stringBuilder != null) {
                stringBuilder.append(this.getLabel("NEW_PASSWORD_BAD_LENGTH_7"));
            }
            return false;
        }
        boolean bl = false;
        boolean bl2 = false;
        int n = 0;
        while (n < string.length()) {
            if (bl && bl2) break;
            char c = string.charAt(n);
            if (!bl && Character.isDigit(c)) {
                bl = true;
            }
            if (!bl2 && Character.isLetter(c)) {
                bl2 = true;
            }
            ++n;
        }
        if (bl && bl2) {
            return true;
        }
        if (this.getLogLevel() >= 3 && !bl) {
            this.logger(3, "checkPasswordValidity() password must contain at least 1 numerical caracter");
        }
        if (this.getLogLevel() >= 3 && !bl2) {
            this.logger(3, "checkPasswordValidity() password must contain at least 1 alphabetical caracter");
        }
        if (stringBuilder != null) {
            stringBuilder.append(this.getLabel("NEW_PASSWORD_ONE_LETTER_AND_ONE_DIGIT"));
        }
        return false;
    }

    public String getHashedPassword(String string, String string2) {
        String string3;
        block12: {
            if (string == null || string.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getHashedPassword() no login");
                }
                return null;
            }
            if (string2 == null || string2.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getHashedPassword() no password");
                }
                return null;
            }
            try {
                int n = string.length() + string2.length();
                byte[] byArray = new byte[n < 32 ? 32 : n];
                int n2 = 0;
                while (n2 < string.length()) {
                    byArray[n2] = (byte)string.charAt(n2);
                    ++n2;
                }
                n2 = 0;
                while (n2 < string2.length()) {
                    byArray[string.length() + n2] = (byte)string2.charAt(n2);
                    ++n2;
                }
                n2 = n;
                while (n2 < 32) {
                    byArray[n2] = (byte)string2.charAt(n2 % string2.length());
                    ++n2;
                }
                YP_Object yP_Object = this.getPluginByName("CryptoManager");
                string3 = (String)yP_Object.dealRequest(this, "sha256Hash", new Object[]{byArray});
                if (string3 != null && !string3.isEmpty()) break block12;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getHashedPassword() pb during hash");
                }
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getHashedPassword() pb during hash: " + exception.toString());
                }
                return null;
            }
        }
        return string3;
    }

    public Boolean changePassword(YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "changePassword() no login");
            }
            return null;
        }
        if (string2 == null || string2.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "changePassword() no password");
            }
            return null;
        }
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userAuthentication);
            yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.userAuthentication.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "changePassword() to change a password user must exist!!!");
                }
                if (stringBuilder != null) {
                    stringBuilder.append(this.getLabel("UNKNOWN_USER"));
                }
                return false;
            }
            if (!this.checkPasswordValidity(string2, stringBuilder)) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "changePassword() invalid new password!!!");
                }
                return false;
            }
            String string3 = this.getHashedPassword(string, string2);
            if (string3 == null || string3.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "changePassword() pb during hash new password");
                }
                return false;
            }
            YP_Row yP_Row2 = list.get(0);
            String string4 = yP_Row2.getFieldStringValueByName("hashedPassword");
            String string5 = yP_Row2.getFieldStringValueByName("hashedPassword1");
            String string6 = yP_Row2.getFieldStringValueByName("hashedPassword2");
            String string7 = yP_Row2.getFieldStringValueByName("hashedPassword3");
            if (string4.contentEquals(string3)) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "changePassword() new password identical to last one");
                }
                if (stringBuilder != null) {
                    stringBuilder.append(this.getLabel("NEW_PASSWORD_RECENTLY_USED"));
                }
                return false;
            }
            if (string5.contentEquals(string3)) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "changePassword() new password identical to password 1");
                }
                if (stringBuilder != null) {
                    stringBuilder.append(this.getLabel("NEW_PASSWORD_RECENTLY_USED"));
                }
                return false;
            }
            if (string6.contentEquals(string3)) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "changePassword() new password identical to password 2");
                }
                if (stringBuilder != null) {
                    stringBuilder.append(this.getLabel("NEW_PASSWORD_RECENTLY_USED"));
                }
                return false;
            }
            if (string7.contentEquals(string3)) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "changePassword() new password identical to password 3");
                }
                if (stringBuilder != null) {
                    stringBuilder.append(this.getLabel("NEW_PASSWORD_RECENTLY_USED"));
                }
                return false;
            }
            yP_Row2.set("hashedPassword", string3);
            yP_Row2.set("hashedPassword1", string4);
            yP_Row2.set("hashedPassword2", string5);
            yP_Row2.set("hashedPassword3", string6);
            this.setValidityTimes(yP_Row, yP_Row2, stringBuilder, 90);
            yP_Row2.setIsItAClonedRow(false);
            yP_Row2.persist();
            return true;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "changePassword()" + exception);
            }
            return false;
        }
    }

    public boolean setPassword(String string, String string2) {
        if (string == null || string.isEmpty()) {
            this.logger(2, "setPassword() no login");
            return false;
        }
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "setPassword() no password");
            return false;
        }
        String string3 = this.getHashedPassword(string, string2);
        if (string3 == null || string3.isEmpty()) {
            this.logger(2, "setPassword() pb during hash new password");
            return false;
        }
        return this.setHashedPassword(string, string3);
    }

    public boolean setHashedPassword(String string, String string2) {
        List<YP_Row> list;
        block5: {
            if (string == null || string.isEmpty()) {
                this.logger(2, "setHashedPassword() no login");
                return false;
            }
            if (string2 == null || string2.isEmpty()) {
                this.logger(2, "setHashedPassword() no hashedPassword");
                return false;
            }
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userAuthentication);
                yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.userAuthentication.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block5;
                this.logger(2, "setHashedPassword() to change a password user must exist!!!");
                return false;
            }
            catch (Exception exception) {
                this.logger(2, "setHashedPassword()" + exception);
                return false;
            }
        }
        YP_Row yP_Row = list.get(0);
        yP_Row.set("hashedPassword3", yP_Row.getFieldValueByName("hashedPassword2"));
        yP_Row.set("hashedPassword2", yP_Row.getFieldValueByName("hashedPassword1"));
        yP_Row.set("hashedPassword1", yP_Row.getFieldValueByName("hashedPassword"));
        yP_Row.set("hashedPassword", string2.toUpperCase());
        yP_Row.setIsItAClonedRow(false);
        yP_Row.persist();
        return true;
    }

    public String createUser(YP_Row yP_Row, String string, String string2) {
        String string3;
        if (string2 == null || string2.isEmpty()) {
            string2 = this.getTemporaryPassword();
        }
        String string4 = this.getHashedPassword(string, string2);
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userAuthentication);
        yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        try {
            YP_Row yP_Row2;
            this.userAuthentication.lock();
            List<YP_Row> list = this.userAuthentication.getRowListSuchAs(yP_ComplexGabarit);
            if (!list.isEmpty()) {
                this.logger(2, "createUSer() previous row found for login " + string);
                yP_Row2 = list.get(0);
                yP_Row2.set("login", String.valueOf(string) + "_Deleted");
            }
            yP_Row2 = this.userAuthentication.getNewRow();
            yP_Row2.set("login", string);
            yP_Row2.set("hashedPassword", string4);
            yP_Row2.set("hashedPassword1", "");
            yP_Row2.set("hashedPassword2", "");
            yP_Row2.set("hashedPassword3", "");
            this.setValidityTimes(yP_Row, yP_Row2, null, 5);
            this.userAuthentication.addRow(yP_Row2, true);
            this.userAuthentication.persist();
            string3 = string2;
        }
        catch (Throwable throwable) {
            try {
                this.userAuthentication.unlock();
                throw throwable;
            }
            catch (Exception exception) {
                this.logger(2, "createUSer()" + exception);
                return null;
            }
        }
        this.userAuthentication.unlock();
        return string3;
    }

    private String getTemporaryPassword() {
        SecureRandom secureRandom = new SecureRandom();
        if (UtilsYP.isMoroccoServer()) {
            return "t" + String.format("%06d", secureRandom.nextInt(999999));
        }
        byte[] byArray = new byte[6];
        secureRandom.nextBytes(byArray);
        return "t" + UtilsYP.devHexa(byArray);
    }

    public String resetUser(YP_Row yP_Row, String string) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userAuthentication);
            yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.userAuthentication.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(2, "resetUser() User doesn't exist:" + string);
                return this.createUser(yP_Row, string, null);
            }
            YP_Row yP_Row2 = list.get(0);
            String string2 = this.getTemporaryPassword();
            String string3 = this.getHashedPassword(string, string2);
            String string4 = yP_Row2.getFieldStringValueByName("hashedPassword");
            String string5 = yP_Row2.getFieldStringValueByName("hashedPassword1");
            String string6 = yP_Row2.getFieldStringValueByName("hashedPassword2");
            yP_Row2.set("hashedPassword", string3);
            yP_Row2.set("hashedPassword1", string4);
            yP_Row2.set("hashedPassword2", string5);
            yP_Row2.set("hashedPassword3", string6);
            this.setValidityTimes(yP_Row, yP_Row2, null, 5);
            this.userAuthentication.persist();
            return string2;
        }
        catch (Exception exception) {
            this.logger(2, "resetUser()" + exception);
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public YP_Authentifiers.AuthenticationResultEnumeration authenticate(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        if (string == null || string.isEmpty()) {
            this.logger(2, "authenticate() no login");
            return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
        }
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "authenticate() no password");
            return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
        }
        try {
            String string3 = this.getHashedPassword(string, string2);
            if (string3 == null || string3.isEmpty()) {
                this.logger(2, "authenticate() pb during hash");
                return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userAuthentication);
            yP_ComplexGabarit.set("login", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            List<YP_Row> list = this.userAuthentication.getRowListSuchAs(yP_ComplexGabarit);
            if (list.isEmpty()) {
                if (!this.checkPasswordValidity(string2, stringBuilder)) {
                    this.logger(2, "authenticate() invalid password!!!");
                    return YP_Authentifiers.AuthenticationResultEnumeration.INVALID_PASSWORD;
                }
                this.logger(4, "authenticate() Saving new user/password for " + string);
                YP_Row yP_Row2 = this.userAuthentication.getNewRow();
                yP_Row2.set("login", string);
                yP_Row2.set("hashedPassword", string3);
                this.setValidityTimes(yP_Row, yP_Row2, stringBuilder, 90);
                this.userAuthentication.addRow(yP_Row2, true);
                this.userAuthentication.persist();
                return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
            }
            YP_Row yP_Row3 = list.get(0);
            String string4 = yP_Row3.getFieldStringValueByName("hashedPassword");
            Timestamp timestamp = (Timestamp)yP_Row3.getFieldValueByName("endValidityGMTTime");
            this.logger(4, "passwordEndOfValidity() Password end of validity : " + timestamp);
            if (string4.isEmpty()) {
                this.logger(4, "authenticate() Saving new password for" + string);
                yP_Row3.set("hashedPassword", string3);
                this.setValidityTimes(yP_Row, yP_Row3, stringBuilder, 90);
                yP_Row3.setIsItAClonedRow(false);
                yP_Row3.persist();
                return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
            }
            if (string4.contentEquals(string3)) {
                this.logger(4, "authenticate() Password OK");
                Calendar calendar = UtilsYP.getSystemGMTTime();
                if (timestamp.getTime() == 0L) {
                    int n;
                    Object object;
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "authenticate() No end of validity");
                    }
                    boolean bl = false;
                    String string5 = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
                    if (string5 != null && !string5.isEmpty()) {
                        try {
                            TLVHandler tLVHandler = new TLVHandler(string5);
                            object = tLVHandler.getTLV(-538869478);
                            if (object != null) {
                                bl = TLVHandler.getBool(((TLV)object).value);
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, "authenticate() GUI TLV received:" + bl);
                                }
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "authenticate()  " + exception);
                        }
                    }
                    if (!bl) {
                        this.logger(4, "authenticate() Password end of validity not checked");
                        return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    }
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "authenticate() Check GUI interface");
                    }
                    if ((n = yP_TCD_DC_Transaction.userHandler.getUserAccessLevel()) == 1 || n == 2) {
                        this.logger(3, "authenticate() Password OK but no end of validity for admin user");
                        return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    }
                    object = yP_Row.getFieldStringValueByName("authPluginName");
                    if (object != null && !((String)object).isEmpty()) {
                        this.logger(3, "authenticate() Password OK but no end of validity for user with authentifier plugin " + (String)object);
                        return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    }
                    this.logger(4, "authenticate() Password OK and no end of validity");
                    if (!UtilsYP.isMoroccoServer() || n == 4) return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    return YP_Authentifiers.AuthenticationResultEnumeration.EXPIRED_PASSWORD;
                }
                if (timestamp.getTime() < calendar.getTimeInMillis()) {
                    int n = yP_TCD_DC_Transaction.userHandler.getUserAccessLevel();
                    if (UtilsYP.isMoroccoServer() && n == 4) {
                        if (this.getLogLevel() < 5) return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                        this.logger(5, "authenticate() Password OK, end of validity ignored for cashier created before cashier non expiration password");
                        return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    }
                    this.logger(3, "authenticate() Password OK but end of validity reached: " + timestamp.toString());
                    return YP_Authentifiers.AuthenticationResultEnumeration.EXPIRED_PASSWORD;
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "authenticate() Password is still valid");
                }
                if (stringBuilder == null) return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                try {
                    String string6 = this.getLabel("PASSWORD_VALID_FOR_X_DAYS");
                    if (string6 != null && string6.indexOf("%d") >= 0) {
                        long l = timestamp.getTime() - calendar.getTimeInMillis();
                        if (l > 10L) return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                        stringBuilder.append(String.format(string6, TimeUnit.DAYS.convert(l, TimeUnit.MILLISECONDS)));
                        return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                    } else {
                        this.logger(3, "authenticate() Bad value for I18N.PASSWORD_VALID_FOR_X_DAYS");
                    }
                    return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
                }
                catch (Exception exception) {
                    this.logger(2, "authenticate() " + exception);
                }
                return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
            }
            this.logger(3, "authenticate() Wrong password");
            if (stringBuilder == null) return YP_Authentifiers.AuthenticationResultEnumeration.WRONG_PASSWORD;
            stringBuilder.append(this.getLabel("WRONG_PASSWORD"));
            return YP_Authentifiers.AuthenticationResultEnumeration.WRONG_PASSWORD;
        }
        catch (Exception exception) {
            this.logger(2, "authenticate()" + exception);
            return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
        }
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        try {
            if (string.contentEquals("View_Session") && yP_Row instanceof DAO_Session) {
                DAO_Session dAO_Session = (DAO_Session)yP_Row;
                ArrayList<Property> arrayList = new ArrayList<Property>();
                Property property = new Property();
                property.setName("SessionNumber");
                property.setValue(Integer.toString(dAO_Session.sessionNumber));
                arrayList.add(property);
                ArrayList<YP_TCD_DC_Context.Action> arrayList2 = new ArrayList<YP_TCD_DC_Context.Action>();
                YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                action.applicationIdentifier = YP_Row.getStringValue(dAO_Session.applicationIdentifier);
                action.formName = "StandardNoConfirmationForm";
                action.id = "ReconciliationReport";
                action.label = this.getLabel("RECONCILIATION_REPORT");
                action.propertiesList = arrayList;
                arrayList2.add(action);
                YP_Transaction yP_Transaction = null;
                YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
                if (yP_Process instanceof YP_Transaction) {
                    yP_Transaction = (YP_Transaction)yP_Process;
                    int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                    if (!(n != 1 && n != 2 || dAO_Session.status != SessionStatusEnumeration.TO_UPLOAD && dAO_Session.status != SessionStatusEnumeration.ERROR)) {
                        action = new YP_TCD_DC_Context.Action();
                        action.applicationIdentifier = YP_Row.getStringValue(dAO_Session.applicationIdentifier);
                        action.formName = "StandardConfirmationForm";
                        action.id = "Reconciliation";
                        action.label = this.getLabel("RECONCILIATION");
                        action.propertiesList = arrayList;
                        arrayList2.add(action);
                    }
                }
                return arrayList2;
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getActionList()" + exception);
            return null;
        }
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public int executeAction(YP_Transaction var1_1, String var2_2, YP_Row var3_3, YP_TCD_DC_Context.Action var4_4) {
        var5_5 = var1_1.getDataContainerTransaction().getRequestType();
        var6_6 = var1_1.getDataContainerTransaction().getSubRequestType();
        var7_7 = var1_1.getDataContainerTransaction().commonHandler.getSessionNumber();
        var8_8 = var1_1.getDataContainerTransaction().getContractIdentifier();
        try {
            block37: {
                if (!var2_2.contentEquals("View_Session") || !(var3_3 instanceof DAO_Session)) break block37;
                var9_9 = var4_4.id;
                tmp = -1;
                switch (var9_9.hashCode()) {
                    case -1358605801: {
                        if (var9_9.equals("ReconciliationReport")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case -288055549: {
                        if (var9_9.equals("Reconciliation")) {
                            tmp = 2;
                        }
                        break;
                    }
                }
                switch (tmp) {
                    case 1: {
                        var1_1.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.Report);
                        var1_1.getDataContainerTransaction().setSubRequestType(YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ReconciliationReport);
                        break;
                    }
                    case 2: {
                        var1_1.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation);
                        var1_1.getDataContainerTransaction().setSubRequestType(null);
                    }
                }
                var10_11 = var4_4.id;
                tmp = -1;
                switch (var10_11.hashCode()) {
                    case -1358605801: {
                        if (var10_11.equals("ReconciliationReport")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case -288055549: {
                        if (var10_11.equals("Reconciliation")) {
                            tmp = 1;
                        }
                        break;
                    }
                }
                block15 : switch (tmp) {
                    case 1: {
                        if (var4_4.propertiesList != null) {
                            for (Object var11_13 : var4_4.propertiesList) {
                                if (!var11_13.getName().contentEquals("SessionNumber")) continue;
                                var1_1.getDataContainerTransaction().commonHandler.setSessionNumber(Integer.parseInt(var11_13.getValue()));
                            }
                        }
                        if ((var11_13 = (List)this.dataContainerManager.dealRequest(this, "getDataContainerList", new Object[]{var1_1, var4_4.applicationIdentifier, var1_1.getDataContainerTransaction().contextHandler.getStoreIdentifier()})) == null || var11_13.isEmpty()) {
                            return -1;
                        }
                        var13_14 = var11_13.iterator();
                        while (var13_14.hasNext()) {
                            var12_12 = (YP_TCD_DCC_Business)var13_14.next();
                            var14_15 = var12_12.newApplicationPlugin(var1_1);
                            var1_1.getDataContainerTransaction().setContractIdentifier(var4_4.applicationIdentifier);
                            var14_15.setContractIdentifier(var4_4.applicationIdentifier);
                            var14_15.initialize();
                            var14_15.dealRequest(var1_1, "dealTransaction", null);
                            var14_15.shutdown();
                        }
                        var12_12 = var4_4.id;
                        tmp = -1;
                        switch (var12_12.hashCode()) {
                            case -288055549: {
                                if (var12_12.equals("Reconciliation")) {
                                    tmp = 1;
                                }
                                break;
                            }
                        }
                        switch (tmp) {
                            case 1: {
                                YP_TCD_DCC_Business.getExtendedResult(var1_1.getDataContainerTransaction()).add(8);
                            }
                            ** default:
lbl83:
                            // 1 sources

                            break block15;
                        }
                    }
                }
            }
            return 0;
        }
        catch (Exception var9_10) {
            this.logger(2, "executeAction() ", var9_10);
        }
        finally {
            var1_1.getDataContainerTransaction().setRequestType(var5_5);
            var1_1.getDataContainerTransaction().setSubRequestType(var6_6);
            var1_1.getDataContainerTransaction().commonHandler.setSessionNumber(var7_7);
            var1_1.getDataContainerTransaction().setContractIdentifier(var8_8);
        }
        return -1;
    }

    public List<Long> getIdContractList(long l, String string) {
        long l2 = this.getIdStore(l, string);
        if (l2 < 0L) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getIdContractList() not found:" + l + " " + string);
            }
            return null;
        }
        return this.getIdContractList(l2);
    }

    public long getIdStore(long l, String string) {
        YP_Row yP_Row = this.getStore(l, string);
        if (yP_Row == null) {
            return -1L;
        }
        return yP_Row.getPrimaryKey();
    }

    public YP_Row getStore(long l, String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.store);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("storeIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        List<YP_Row> list = this.store.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(2, "getStore() not found:" + l + " " + string);
            return null;
        }
        if (list.size() > 1) {
            this.logger(2, "getStore() too many found:" + l + " " + string);
            this.logger(3, "getStore() only the first one is handled");
        }
        return list.get(0);
    }

    public List<Long> getIdContractList(long l) {
        if (l < 0L) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getIdContractList() store not found:" + l);
            }
            return null;
        }
        ArrayList<Long> arrayList = new ArrayList<Long>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.contractInsideStore);
        yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = this.contractInsideStore.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null) {
            Field field = this.contractInsideStore.getFieldByName("idContract");
            for (YP_Row yP_Row : list) {
                arrayList.add((Long)yP_Row.getFieldValue(field));
            }
        }
        return arrayList;
    }

    public List<Long> getIdStoreList(long l) {
        ArrayList<Long> arrayList = new ArrayList<Long>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.store);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = this.store.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getIdStoreList() not found:" + l);
            }
        } else {
            for (YP_Row yP_Row : list) {
                arrayList.add(yP_Row.getPrimaryKey());
            }
        }
        return arrayList;
    }

    public List<Long> getIdMerchantWithStore() {
        try {
            List<Object> list = this.store.getDistinctValueList("idMerchant");
            if ((list == null || list.isEmpty()) && this.getLogLevel() >= 5) {
                this.logger(5, "getIdMerchantWithStore() not found");
            }
            return list;
        }
        catch (Exception exception) {
            this.logger(2, "getIdMerchantWithStore() " + exception);
            return null;
        }
    }

    public List<Long> getIdStoreListByContract(long l) {
        ArrayList<Long> arrayList = new ArrayList<Long>();
        if (this.contractInsideStore.size() > 0) {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.contractInsideStore);
            yP_ComplexGabarit.set("idContract", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            List<YP_Row> list = this.contractInsideStore.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                if (this.getLogLevel() >= 6) {
                    this.logger(6, "getIdStoreListByContract() not found:" + l);
                }
            } else {
                for (YP_Row yP_Row : list) {
                    arrayList.add((Long)yP_Row.getFieldValueByName("idStore"));
                }
            }
        }
        return arrayList;
    }

    public List<YP_Row> getStoreList(long l) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.store);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("storeLabel", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
        yP_ComplexGabarit.set("storeStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT, StoreStatusEnumeration.DELETED);
        List<YP_Row> list = this.store.getRowListSuchAs(yP_ComplexGabarit);
        if ((list == null || list.isEmpty()) && this.getLogLevel() >= 6) {
            this.logger(6, "getStoreList() not found:" + l);
        }
        return list;
    }

    public YP_Row getStore(long l) {
        YP_Row yP_Row = this.store.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getStore() not found:" + l);
            }
            return null;
        }
        return yP_Row;
    }

    public String getStoreIdentifier(YP_Row yP_Row) {
        return yP_Row.getFieldStringValueByName("storeIdentifier");
    }

    public String getStoreLabel(YP_Row yP_Row) {
        return yP_Row.getFieldStringValueByName("storeLabel");
    }

    public String getStoreLabel(long l, String string) {
        YP_Row yP_Row = this.getStore(l, string);
        if (yP_Row == null) {
            return null;
        }
        return yP_Row.getFieldStringValueByName("storeLabel");
    }

    public int addContractInsideSore(long l, String string, long l2) {
        long l3;
        block4: {
            try {
                l3 = this.getIdStore(l, string);
                if (l3 > 0L) break block4;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "addContractInsideSore() not found:" + l + " " + string + " " + l2);
                }
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "addContractInsideSore() " + exception);
                return -1;
            }
        }
        DAO_ContractInsideStore dAO_ContractInsideStore = (DAO_ContractInsideStore)this.contractInsideStore.getNewRow();
        dAO_ContractInsideStore.idStore = l3;
        dAO_ContractInsideStore.idContract = l2;
        dAO_ContractInsideStore.setPrimaryKey(this.contractInsideStore.getNextPrimaryKey());
        this.contractInsideStore.addRow(dAO_ContractInsideStore, true);
        this.contractInsideStore.persist();
        return 1;
    }

    public int removeAllContractsFromStore(long l) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.contractInsideStore);
            yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, l);
            this.contractInsideStore.deleteRowsSuchAs(yP_ComplexGabarit);
            this.contractInsideStore.persist();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "removeAllContractsFromStore() ", exception);
            return -1;
        }
    }

    private void setValidityTimes(YP_Row yP_Row, YP_Row yP_Row2, StringBuilder stringBuilder, int n) {
        if (UtilsYP.isMoroccoServer()) {
            this.setMoroccoValidityTimes(yP_Row, yP_Row2, stringBuilder, n);
        } else {
            this.setStandardValidityTimes(yP_Row, yP_Row2, stringBuilder, n);
        }
    }

    private void setMoroccoValidityTimes(YP_Row yP_Row, YP_Row yP_Row2, StringBuilder stringBuilder, int n) {
        Timestamp timestamp;
        Calendar calendar = UtilsYP.getSystemGMTTime();
        yP_Row2.set("startValidityGMTTime", new Timestamp(calendar.getTimeInMillis()));
        int n2 = (Integer)yP_Row.getFieldValueByName("accessLevel");
        if (n == 5 && (n2 == 3 || n2 == 4)) {
            timestamp = EMPTY_TIMESTAMP;
        } else {
            Calendar calendar2 = calendar;
            calendar2.add(5, n);
            timestamp = new Timestamp(calendar2.getTimeInMillis());
            if (stringBuilder != null) {
                stringBuilder.append(this.getLabel("PASSWORD_VALID_UNTIL"));
                stringBuilder.append(' ');
                stringBuilder.append(UtilsYP.formatJJMMAATime(calendar2));
            }
        }
        yP_Row2.set("endValidityGMTTime", timestamp);
    }

    private void setStandardValidityTimes(YP_Row yP_Row, YP_Row yP_Row2, StringBuilder stringBuilder, int n) {
        Timestamp timestamp;
        Calendar calendar = UtilsYP.getSystemGMTTime();
        yP_Row2.set("startValidityGMTTime", new Timestamp(calendar.getTimeInMillis()));
        int n2 = (Integer)yP_Row.getFieldValueByName("accessLevel");
        if (n2 == 3 || n2 == 4) {
            timestamp = EMPTY_TIMESTAMP;
        } else {
            Calendar calendar2 = calendar;
            calendar2.add(5, n);
            timestamp = new Timestamp(calendar2.getTimeInMillis());
            if (stringBuilder != null) {
                stringBuilder.append(this.getLabel("PASSWORD_VALID_UNTIL"));
                stringBuilder.append(' ');
                stringBuilder.append(UtilsYP.formatJJMMAATime(calendar2));
            }
        }
        yP_Row2.set("endValidityGMTTime", timestamp);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean isReservationDetailsEmpty() {
        block3: {
            try {
                if (this.reservationDetailsEmpty != null) return this.reservationDetailsEmpty;
                if (this.reservationDetails != null) break block3;
                return true;
            }
            catch (Exception exception) {
                return true;
            }
        }
        this.reservationDetailsEmpty = this.reservationDetails.size() == 0;
        return this.reservationDetailsEmpty;
    }

    public int doTerminalAuthentication(YP_Transaction yP_Transaction) {
        this.logger(4, "doTerminalAuthentication(");
        return 1;
    }

    public int saveTerminalRow(YP_Row yP_Row) {
        try {
            yP_Row.setIsItAClonedRow(false);
            yP_Row.persist();
            this.addTerminalRowToTerminalMap(yP_Row);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "saveTerminalRow() ", exception);
            return -1;
        }
    }

    public int savePdvRow(String string, YP_Row yP_Row) {
        try {
            yP_Row.persist();
            this.addPdvRowToPdvMap(string, yP_Row);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "savePdvRow() ", exception);
            return -1;
        }
    }

    public int resetPdvForTfj() {
        try {
            YP_Row yP_Row = this.pdv.getNewRow();
            yP_Row.set("cumulPDV", -9223372036854775807L);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pdv);
            yP_ComplexGabarit.set("modePaymentPdv", YP_ComplexGabarit.OPERATOR.EQUAL, PDVTypeEnumeration.POST_PAYE);
            this.pdv.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
            this.pdv.persist();
            for (long l : this.pdvMap.keySet()) {
                YP_Row yP_Row2 = this.pdvMap.get(l);
                if (!((PDVTypeEnumeration)((Object)yP_Row2.getFieldValueByName("modePaymentPdv"))).equals((Object)PDVTypeEnumeration.POST_PAYE)) continue;
                yP_Row2.set("cumulPDV", "0");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "resetPdv() ", exception);
            return -1;
        }
    }

    class OldTerminalClass {
        final long idMerchant;
        final int nlpa;

        public OldTerminalClass(long l, int n) {
            this.idMerchant = l;
            this.nlpa = n;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || this.getClass() != object.getClass()) {
                return false;
            }
            OldTerminalClass oldTerminalClass = (OldTerminalClass)object;
            return this.idMerchant == oldTerminalClass.idMerchant && this.nlpa == oldTerminalClass.nlpa;
        }

        public int hashCode() {
            int n = (int)(this.idMerchant ^ this.idMerchant >>> 32);
            return 31 * n + (this.nlpa ^ this.nlpa >>> 32);
        }
    }

    class TerminalClass {
        final long idMerchant;
        final String ip;

        public TerminalClass(long l, String string) {
            this.idMerchant = l;
            this.ip = string;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || this.getClass() != object.getClass()) {
                return false;
            }
            TerminalClass terminalClass = (TerminalClass)object;
            if (this.idMerchant != terminalClass.idMerchant || !this.ip.contentEquals(terminalClass.ip)) {
                return false;
            }
            return this.ip.contentEquals(terminalClass.ip);
        }

        public int hashCode() {
            return this.ip.hashCode();
        }
    }
}

