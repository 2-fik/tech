/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.extendedapplication;

import org.yp.framework.ondemandcomponents.applications.YP_ApplicationEvent;
import org.yp.framework.ondemandcomponents.applications.extendedapplication.YP_Interface_StateMachine;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class YP_BCD_A_StateMachine {
    private final TransactionTypeEnumeration transactionType;
    private final YP_TCD_PosProtocol.SUB_REQUEST_TYPE subRequestType;
    public final YP_ApplicationEvent applicationEvent = new YP_ApplicationEvent();
    private final YP_Interface_StateMachine interfaceSM;

    public YP_BCD_A_StateMachine(YP_Interface_StateMachine yP_Interface_StateMachine, TransactionTypeEnumeration transactionTypeEnumeration) {
        this.interfaceSM = yP_Interface_StateMachine;
        this.transactionType = transactionTypeEnumeration;
        this.subRequestType = null;
    }

    public YP_BCD_A_StateMachine(YP_Interface_StateMachine yP_Interface_StateMachine, TransactionTypeEnumeration transactionTypeEnumeration, YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE) {
        this.interfaceSM = yP_Interface_StateMachine;
        this.transactionType = transactionTypeEnumeration;
        this.subRequestType = sUB_REQUEST_TYPE;
    }

    public int yp_PaymentStep() {
        switch (this.transactionType) {
            case DEBIT: 
            case QUASI_CASH: 
            case INITIAL_RESERVATION: 
            case DEBIT_DIFFERED: {
                if (this.subRequestType != null) {
                    switch (this.subRequestType) {
                        case OpenTransaction: {
                            return this.interfaceSM.openTransactionStep();
                        }
                        case TerminalRiskManagement: {
                            return this.interfaceSM.terminalRiskManagementStepForDebit();
                        }
                        case OpenTransactionAndTRM: {
                            return this.interfaceSM.openTransactionAndTRMStepForDebit();
                        }
                        case Authorization: {
                            return this.interfaceSM.authorizationStep();
                        }
                        case Completion: {
                            return this.interfaceSM.completionStep();
                        }
                        case ProcessNFC: {
                            return this.interfaceSM.processNFCStep();
                        }
                    }
                    this.interfaceSM.logger(2, "yp_PaymentStep()");
                }
                return this.interfaceSM.yp_DebitStep();
            }
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                if (this.subRequestType != null) {
                    switch (this.subRequestType) {
                        case OpenTransaction: {
                            return this.interfaceSM.openTransactionStep();
                        }
                        case TerminalRiskManagement: {
                            return this.interfaceSM.terminalRiskManagementStepForCredit();
                        }
                        case OpenTransactionAndTRM: {
                            return this.interfaceSM.openTransactionAndTRMStepForCredit();
                        }
                        case Authorization: {
                            return this.interfaceSM.authorizationStepForRefund();
                        }
                        case Completion: {
                            return this.interfaceSM.completionRefundReversalStep();
                        }
                        case ProcessNFC: {
                            return this.interfaceSM.processNFCStepForCredit();
                        }
                    }
                    this.interfaceSM.logger(2, "yp_RefundStep()");
                }
                return this.interfaceSM.yp_RefundStep();
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                if (this.subRequestType != null) {
                    switch (this.subRequestType) {
                        case OpenTransaction: {
                            return this.interfaceSM.openTransactionStep();
                        }
                        case TerminalRiskManagement: {
                            return this.interfaceSM.terminalRiskManagementStepForReversal();
                        }
                        case OpenTransactionAndTRM: {
                            return this.interfaceSM.openTransactionAndTRMStepForReversal();
                        }
                        case Authorization: {
                            return this.interfaceSM.authorizationStepForReversal();
                        }
                        case Completion: {
                            return this.interfaceSM.completionRefundReversalStep();
                        }
                        case ProcessNFC: {
                            return this.interfaceSM.processNFCStepForReversal();
                        }
                    }
                    this.interfaceSM.logger(2, "yp_ReversalStep()");
                }
                return this.interfaceSM.yp_ReversalStep();
            }
            case ADDITIONAL_RESERVATION: 
            case ONE_TIME_RESERVATION: {
                return this.interfaceSM.yp_DebitStep();
            }
            case COMPLEMENTARY_PAYMENT: {
                return this.interfaceSM.yp_ComplementaryPaymentStep();
            }
            case COMPLEMENTARY_REFUND: {
                return this.interfaceSM.yp_ComplementaryRefundStep();
            }
            case CLOSING_PAYMENT: 
            case ADVICE_DEBIT: {
                return this.interfaceSM.yp_ClosingPaymentStep();
            }
        }
        return -1;
    }
}

