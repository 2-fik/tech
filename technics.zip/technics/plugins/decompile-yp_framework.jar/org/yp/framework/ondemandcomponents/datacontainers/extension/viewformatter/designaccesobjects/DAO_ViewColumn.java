/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_View;
import org.yp.utils.Bitmap;

public class DAO_ViewColumn
extends YP_Row {
    @PrimaryKey
    public long idViewColumn = 0L;
    public byte[] columnName = new byte[40];
    @ForeignKey(name=DAO_View.class)
    public long idView = 0L;
    public long idLabel = 0L;
    public Bitmap readAccessList;
    public Bitmap writeAccessList;
    public Bitmap searchAccessList;
    public int defaultRank = 0;
}

