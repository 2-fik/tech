/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachine;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure_Host_Auto;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_ThreeDSecureEvent;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine
extends YP_OnDemandComponent
implements YP_PROT_Interface_StateMachine {
    private YP_TCD_PROT_ThreeDSecure_Host_Auto myAutoClass;
    public YP_TCD_PROT_ThreeDSecure protocolThreeDS = null;
    public final YP_ThreeDSecureEvent eventThreeDS = new YP_ThreeDSecureEvent();
    private YP_PROT_Interface_Prot.SERVICEDEMANDE serviceRequested = null;
    public YP_TCD_DCC_Business dataContainerBusiness = null;
    public YP_TCD_DC_Transaction dataContainerTransaction = null;
    private YP_PROT_Interface_Prot protocolInterface;
    private YP_PHYS_Interface physicalInterface;
    private HOSTAUTOSTATEMACHINE myCurrentState = HOSTAUTOSTATEMACHINE.autoReceive;
    private int errorStatus;

    public YP_TCD_PROT_ThreeDSecure_Host_AutoStateMachine(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int setParameters(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, List<Property> list, YP_PROT_Interface_Prot yP_PROT_Interface_Prot, YP_Object yP_Object, Object ... objectArray) {
        try {
            this.dataContainerBusiness = yP_TCD_DCC_Business;
            this.dataContainerTransaction = yP_TCD_DC_Transaction;
            this.serviceRequested = sERVICEDEMANDE;
            if (yP_PROT_Interface_Prot != null) {
                this.protocolInterface = yP_PROT_Interface_Prot;
            }
            if (yP_Object != null && yP_Object instanceof YP_PHYS_Interface) {
                this.physicalInterface = (YP_PHYS_Interface)((Object)yP_Object);
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)this.newPluginByName("THREEDSECURE_PROTOCOL", yP_Object);
            } else if (yP_Object != null && yP_Object instanceof YP_TCD_PROT_ThreeDSecure) {
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)yP_Object;
            } else {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setParameters() ");
                }
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setParameters() " + exception);
            }
            return -1;
        }
    }

    private HOSTAUTOSTATEMACHINE getState() {
        return this.myCurrentState;
    }

    private void setState(HOSTAUTOSTATEMACHINE hOSTAUTOSTATEMACHINE) {
        this.myCurrentState = hOSTAUTOSTATEMACHINE;
    }

    @Override
    public void setServiceRequested(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        this.serviceRequested = sERVICEDEMANDE;
    }

    public YP_PROT_Interface_Prot.SERVICEDEMANDE getServiceRequested() {
        return this.serviceRequested;
    }

    public int getErrorStatus() {
        return this.errorStatus;
    }

    public void setErrorStatus(int n) {
        this.errorStatus = n;
    }

    @Override
    public int step() {
        if (this.getLogLevel() >= 5) {
            this.logger(5, "step() state: " + (Object)((Object)this.getState()) + " event: " + (Object)((Object)this.eventThreeDS.getEventThreeDS()));
        }
        switch (this.myCurrentState) {
            case autoReceive: {
                this.getMyAutoClass().YP_ThreeDSAutoReceive();
                if (this.eventThreeDS.getEventThreeDS() == YP_ThreeDSecureEvent.THREEDSEVENT.autoAnswer) {
                    this.setState(HOSTAUTOSTATEMACHINE.autoAnswer);
                    return 1;
                }
                this.setState(HOSTAUTOSTATEMACHINE.autoEnd);
                return 1;
            }
            case autoAnswer: {
                this.getMyAutoClass().YP_ThreeDSAnswerAuto();
                this.setState(HOSTAUTOSTATEMACHINE.autoEnd);
                this.getMyAutoClass().YP_ThreeDSAutoEnd();
                return 0;
            }
            case autoEnd: {
                this.getMyAutoClass().YP_ThreeDSAutoEnd();
                return 0;
            }
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "step() unknown step");
        }
        this.setState(HOSTAUTOSTATEMACHINE.autoEnd);
        return 1;
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "SM_THREEDSECURE_HOST_AUTO";
    }

    @Override
    public int shutdown() {
        if (this.myAutoClass != null) {
            this.myAutoClass.shutdown();
            this.myAutoClass = null;
        }
        if (this.protocolThreeDS != null) {
            this.protocolThreeDS.shutdown();
            this.protocolThreeDS = null;
        }
        return super.shutdown();
    }

    public void setMyAutoClass(YP_TCD_PROT_ThreeDSecure_Host_Auto yP_TCD_PROT_ThreeDSecure_Host_Auto) {
        this.myAutoClass = yP_TCD_PROT_ThreeDSecure_Host_Auto;
    }

    public YP_TCD_PROT_ThreeDSecure_Host_Auto getMyAutoClass() {
        if (this.myAutoClass == null) {
            Object[] objectArray = new Object[]{this.dataContainerBusiness, null, this.protocolThreeDS, this.eventThreeDS};
            this.myAutoClass = (YP_TCD_PROT_ThreeDSecure_Host_Auto)this.newPluginByName("THREEDSECURE_HOST_AUTO", objectArray);
        }
        return this.myAutoClass;
    }

    public YP_PROT_Interface_Prot getProtocolInterface() {
        return this.protocolInterface;
    }

    public static enum HOSTAUTOSTATEMACHINE {
        autoReceive,
        autoAnswer,
        autoEnd;

    }
}

