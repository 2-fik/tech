/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.net.Socket;

public interface YP_PHYS_Interface {
    public int openClient(Object ... var1);

    public int openServer();

    public Object waitConnection();

    public int peek(byte[] var1, int var2, int var3, int var4);

    public int recv(byte[] var1, int var2, int var3, int var4);

    public int send(byte[] var1, int var2);

    public int available();

    public int clean(int var1);

    public int close();

    public Socket createSocket(Object ... var1);

    public int closeHandle(Object var1);

    public String getIP();

    public int shutdown();

    public int setParameter(String var1, String var2);
}

