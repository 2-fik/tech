/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test2
extends YP_Row {
    @PrimaryKey
    public long idTest2 = 0L;
    public long test2Long = 0L;
    public int test2Int = 0;
    public float test2Float = 0.0f;
    public byte[] test2CharArray = new byte[50];
    public Timestamp test2Timestamp = new Timestamp(0L);
    public Date test2Date = new Date(0L);
}

