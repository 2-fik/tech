/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.databaseevents;

import java.sql.Timestamp;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.event.DAO_ApplicationEvent;
import org.yp.designaccesobjects.technic.event.DAO_TransactionSlaveEvent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEvents;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCC_DataBaseEventsAPP
extends YP_TCD_DCC_DataBaseEvents {
    private YP_TCD_DesignAccesObject applicationEvent;
    private Timestamp previousApplicationTableInfoTime;
    private List<YP_Row> previousApplicationTableInfoList;
    private YP_TCD_DCC_Technique dataContainerTechnique;
    private YP_Service dataContainerManager;

    public YP_TCD_DCC_DataBaseEventsAPP(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.applicationEvent = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ApplicationEvent.class, 0, 4, null);
            if (UtilsYP.getInstanceRole() == 2) {
                this.applicationEvent.deleteRows(true);
            }
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_TransactionSlaveEvent.class, 0, 4, null);
            yP_TCD_DesignAccesObject.shutdown();
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
            this.previousApplicationTableInfoTime = this.dataContainerTechnique.getLastApplicationEventTimeFromTableInfos();
            this.previousApplicationTableInfoList = this.dataContainerTechnique.getNewerApplicationEventsFromTableInfos(this.previousApplicationTableInfoTime, null);
            this.dataContainerManager = (YP_Service)this.getPluginByName("DataContainerManager");
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataBaseEventsAPP";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.applicationEvent) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() applicationEvent");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
        return 0;
    }

    private boolean isThereApplicationChangesSlaveSharedDB() {
        List<YP_Row> list = this.dataContainerTechnique.getNewerApplicationEventsFromTableInfos(this.previousApplicationTableInfoTime, this.previousApplicationTableInfoList);
        return list != null && !list.isEmpty();
    }

    public boolean isThereApplicationChanges() {
        if (UtilsYP.getInstanceRole() == 3) {
            return this.isThereApplicationChangesSlaveSharedDB();
        }
        return this.applicationEvent.size() > 0;
    }

    private void reLoadContractsSlaveSharedDB() {
        List<YP_Row> list = this.dataContainerTechnique.getNewerApplicationEventsFromTableInfos(this.previousApplicationTableInfoTime, this.previousApplicationTableInfoList);
        if (list != null && list.size() > 0) {
            this.previousApplicationTableInfoTime = (Timestamp)list.get(0).getFieldValueByName("tableSystemGMTTime");
            this.previousApplicationTableInfoList = list;
            int n = this.previousApplicationTableInfoList.size() - 1;
            while (n >= 0) {
                YP_Row yP_Row = this.previousApplicationTableInfoList.get(n);
                String string = yP_Row.getFieldStringValueByName("schemaName");
                String string2 = yP_Row.getFieldStringValueByName("tableName");
                if (string == null || string2 == null) {
                    this.logger(2, "reLoadContractsSlaveSharedDB() Names not found ...");
                } else {
                    try {
                        YP_TCD_DataContainer yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
                        if (yP_TCD_DataContainer == null) {
                            this.logger(2, "reLoadContractsSlaveSharedDB() not found :" + string);
                        }
                        yP_TCD_DataContainer.dealParameterUpdate(string2);
                    }
                    catch (Exception exception) {
                        this.logger(2, "reLoadContractsSlaveSharedDB() error with :" + string + " " + string2 + " " + exception);
                    }
                }
                if (((Timestamp)yP_Row.getFieldValueByName("tableSystemGMTTime")).getTime() != this.previousApplicationTableInfoTime.getTime()) {
                    this.previousApplicationTableInfoList.remove(n);
                }
                --n;
            }
        }
    }

    public void reLoadContracts() {
        block13: {
            if (UtilsYP.getInstanceRole() == 3) {
                this.reLoadContractsSlaveSharedDB();
                return;
            }
            try {
                try {
                    this.applicationEvent.lock();
                    List<YP_Row> list = this.applicationEvent.getRowList();
                    if (list == null || list.size() <= 0) break block13;
                    int n = 0;
                    while (n < list.size()) {
                        String string = list.get(n).getFieldStringValueByName("DB_Name");
                        if (string == null) {
                            this.logger(2, "reLoadContracts() DB_Name not found ...");
                        } else {
                            try {
                                YP_TCD_DataContainer yP_TCD_DataContainer = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", string);
                                if (yP_TCD_DataContainer == null) {
                                    this.logger(2, "reLoadContracts() not found :" + string);
                                } else {
                                    yP_TCD_DataContainer.dealParameterUpdate(list.get(n));
                                }
                            }
                            catch (Exception exception) {
                                this.logger(2, "reLoadContracts() error with :" + string + " " + exception);
                            }
                        }
                        list.get(n).delete();
                        list.get(n).persist();
                        ++n;
                    }
                }
                catch (Exception exception) {
                    this.logger(2, "reLoadContracts() " + exception);
                    this.applicationEvent.unlock();
                }
            }
            finally {
                this.applicationEvent.unlock();
            }
        }
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

