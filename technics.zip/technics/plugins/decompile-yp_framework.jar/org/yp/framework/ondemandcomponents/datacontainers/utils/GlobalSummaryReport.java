/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Summary;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.applications.YP_Print;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.SessionData;
import org.yp.utils.UtilsYP;

public class GlobalSummaryReport
extends YP_Print {
    private final YP_TCD_DCC_Merchant dataContainerMerchant;
    private List<SessionData> listSessionData = new ArrayList<SessionData>();

    public GlobalSummaryReport(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        super(yP_TCD_DCC_Merchant.dataContainerBusinessList.isEmpty() ? null : yP_TCD_DCC_Merchant.dataContainerBusinessList.get(0), yP_TCD_DC_Transaction);
        this.dataContainerMerchant = yP_TCD_DCC_Merchant;
    }

    public void doReport(YP_Transaction yP_Transaction, String string, String string2) {
        try {
            this.listSessionData.clear();
            if (string == null || string.length() == 0) {
                return;
            }
            if (string2 == null || string2.length() == 0) {
                string2 = "0000;1";
            }
            if (this.dataContainerMerchant.dataContainerBusinessList.isEmpty()) {
                this.dataContainerMerchant.logger(2, "doReport() no DCB for " + this.dataContainerMerchant.getMerchantLabel() + "|" + this.dataContainerMerchant.getContractIdentifier());
                return;
            }
            String[] stringArray = string2.split(";");
            String string3 = null;
            if (stringArray.length >= 1 && (string3 = stringArray[0]).isEmpty()) {
                string3 = "0000";
            }
            if (stringArray.length >= 2) {
                Integer.parseInt(stringArray[1]);
            }
            long l = 0L;
            long l2 = 0L;
            if (stringArray.length >= 3) {
                l = this.setTransactionTimeMS(0, stringArray[2], string3);
                l2 = this.setTransactionTimeMS(1, stringArray[2], string3);
            } else {
                l = this.setTransactionTimeMS(-1, string3);
                l2 = this.setTransactionTimeMS(0, string3);
                if (UtilsYP.getSystemGMTTime().getTimeInMillis() < l2) {
                    l = this.setTransactionTimeMS(-2, string3);
                    l2 = this.setTransactionTimeMS(-1, string3);
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            this.printHeaderTicket(yP_Transaction, stringBuilder, this.dataContainerMerchant.dataContainerBusinessList, l, l2);
            String string4 = "";
            string4 = String.valueOf(string4) + "                    AND transactionSystemGMTTimeMS >= '" + l + "'\r\n";
            string4 = String.valueOf(string4) + "                    AND transactionSystemGMTTimeMS < '" + l2 + "'\r\n";
            YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table = null;
            try {
                yP_TCD_DAO_LOC_Table = (YP_TCD_DAO_LOC_Table)((YP_TS_DataContainerManager)yP_Transaction.getPluginByName("DataContainerManager")).getDataContainerTechnique().newPluginByName("DAO_Table", DAO_Summary.class, 0, 1, null);
                this.getSummaryList(stringBuilder, yP_Transaction, string4, yP_TCD_DAO_LOC_Table);
                this.printTotalTicket(stringBuilder);
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(this.getLabelTranslated("RECAP_APPLICATION", "R\u00e9capitulatif commer\u00e7ant du"));
                stringBuilder2.append(" ");
                this.addFormatedDateJJxMMxAAAA(stringBuilder2, l, "/");
                this.dataContainerMerchant.dataContainerBusinessList.get(0).mailGSRReprint(yP_Transaction.getDataContainerTransaction(), string, stringBuilder2.toString(), stringBuilder.toString());
            }
            finally {
                if (yP_TCD_DAO_LOC_Table != null) {
                    yP_TCD_DAO_LOC_Table.shutdown();
                }
            }
        }
        catch (Exception exception) {
            this.dataContainerMerchant.logger(2, "doReport() ", exception);
        }
    }

    private void getSummaryList(StringBuilder stringBuilder, YP_Transaction yP_Transaction, String string, YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : this.dataContainerMerchant.dataContainerBusinessList) {
            String string2 = yP_TCD_DCC_Business.getActivationCode();
            if (string2 == null || !string2.contentEquals("1") || yP_TCD_DCC_Business.transactionArchive == null) continue;
            StringBuilder stringBuilder2 = new StringBuilder();
            this.createMainSQLRequest(stringBuilder2, yP_TCD_DCC_Business.getDataBaseConnector());
            yP_TCD_DCC_Business.transactionArchive.size();
            this.appendContractSQLRequest(stringBuilder2, yP_TCD_DCC_Business, string);
            this.endMainSQLRequest(stringBuilder2);
            List<YP_Row> list = yP_TCD_DCC_Business.getDataBaseConnector().dealSelect(yP_TCD_DCC_Business.transactionArchive, yP_TCD_DAO_LOC_Table, stringBuilder2.toString());
            if (list == null) {
                yP_TCD_DCC_Business.transactionArchive.getRowAt(0);
                list = yP_TCD_DCC_Business.getDataBaseConnector().dealSelect(yP_TCD_DCC_Business.transactionArchive, yP_TCD_DAO_LOC_Table, stringBuilder2.toString());
            }
            if (yP_Transaction.getLogLevel() >= 5) {
                this.dataContainerMerchant.logger(5, "getSummaryList() \n" + stringBuilder2.toString());
            }
            stringBuilder.append(yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel"));
            this.appendLineFeed(stringBuilder);
            this.appendOneApplication(stringBuilder, list);
        }
    }

    private void printHeaderTicket(YP_Transaction yP_Transaction, StringBuilder stringBuilder, List<YP_TCD_DCC_Business> list, long l, long l2) {
        stringBuilder.append(this.getLabelTranslated("brandLabel", "Enseigne"));
        stringBuilder.append(" : ");
        stringBuilder.append(this.dataContainerMerchant.getDataContainerBrand().getBrandLabel());
        this.appendLineFeed(stringBuilder);
        stringBuilder.append(this.getLabelTranslated("merchantLabel", "Commer\u00e7ant"));
        stringBuilder.append(" : ");
        stringBuilder.append(this.dataContainerMerchant.getMerchantLabel());
        this.appendLineFeed(stringBuilder);
        this.appendLineFeed(stringBuilder);
        stringBuilder.append(this.getLabelTranslated("FROM_DATE_LABEL", "Du"));
        stringBuilder.append(" ");
        this.addFormatedDateJJxMMxAAAA(stringBuilder, l, "/");
        stringBuilder.append(" ");
        stringBuilder.append(this.getLabelTranslated("TIME_PREFIX_LABEL", "\u00e0"));
        stringBuilder.append(" ");
        this.addFormatedDateHHxMM(stringBuilder, l, ":");
        this.appendLineFeed(stringBuilder);
        stringBuilder.append(this.getLabelTranslated("TO_DATE_LABEL", "Au"));
        stringBuilder.append(" ");
        this.addFormatedDateJJxMMxAAAA(stringBuilder, l2, "/");
        stringBuilder.append(" ");
        stringBuilder.append(this.getLabelTranslated("TIME_PREFIX_LABEL", "\u00e0"));
        stringBuilder.append(" ");
        this.addFormatedDateHHxMM(stringBuilder, l2, ":");
        this.appendLineFeed(stringBuilder);
        this.appendLineFeed(stringBuilder);
    }

    private void printOneTransactionInfo(String string, StringBuilder stringBuilder, int n, long l, int n2, String string2) {
        switch (string) {
            case "DEBIT": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("nbDebit", "Nombre de d\u00e9bits :"));
                stringBuilder.append(" ");
                break;
            }
            case "REFUND": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("nbRefund", "Nombre de cr\u00e9dits :"));
                stringBuilder.append(" ");
                break;
            }
            case "REVERSAL": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("nbReversalDebit", "Nombre d'annulations :"));
                stringBuilder.append(" ");
                break;
            }
            default: {
                return;
            }
        }
        stringBuilder.append(n);
        this.appendLineFeed(stringBuilder);
        switch (string) {
            case "DEBIT": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("totalAmountDebit", "Montant d\u00e9bit :"));
                stringBuilder.append(" ");
                break;
            }
            case "REFUND": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("totalAmountRefund", "Montant cr\u00e9dit :"));
                stringBuilder.append(" ");
                break;
            }
            case "REVERSAL": {
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("totalAmountReversalDebit", "Montant annulation :"));
                stringBuilder.append(" ");
                break;
            }
            default: {
                return;
            }
        }
        this.appendInfoTransaction(stringBuilder, l, n2, string2);
        this.appendLineFeed(stringBuilder);
    }

    private void appendOneApplication(StringBuilder stringBuilder, List<YP_Row> list) {
        if (list.isEmpty()) {
            stringBuilder.append(" ");
            stringBuilder.append(this.getLabelTranslated("NO_TRANSACTION_LABEL", "Aucune transaction"));
            this.appendLineFeed(stringBuilder);
            this.appendLineFeed(stringBuilder);
        } else {
            for (YP_Row yP_Row : list) {
                SessionData sessionData = new SessionData();
                String string = yP_Row.getFieldStringValueByName("transactionCurrencyAlpha");
                sessionData.setCurrencyAlphabeticalCode(string);
                int n = this.getAmountFraction(string);
                sessionData.setCurrencyFraction(n);
                int n2 = 0;
                long l = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountDebit"));
                if (l > 0L) {
                    n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("nbDebit"));
                    this.printOneTransactionInfo("DEBIT", stringBuilder, n2, l, n, string);
                    sessionData.setTotalAmountDebit(l);
                    sessionData.setNbDebit(n2);
                }
                if ((l = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountRefund"))) > 0L) {
                    n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("nbRefund"));
                    this.printOneTransactionInfo("REFUND", stringBuilder, n2, l, n, string);
                    sessionData.setTotalAmountRefund(l);
                    sessionData.setNbRefund(n2);
                }
                if ((l = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountReversalDebit"))) > 0L) {
                    n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("nbReversalDebit"));
                    this.printOneTransactionInfo("REVERSAL", stringBuilder, n2, l, n, string);
                    sessionData.setTotalAmountReversalDebit(l);
                    sessionData.setNbReversalDebit(n2);
                }
                this.addSessionDataToList(sessionData);
            }
        }
    }

    private void printTotalTicket(StringBuilder stringBuilder) {
        try {
            if (this.listSessionData != null && !this.listSessionData.isEmpty()) {
                for (SessionData sessionData : this.listSessionData) {
                    stringBuilder.append(this.getLabelTranslated("TOTAL_CURRENCY_LABEL", "Total"));
                    stringBuilder.append(" ");
                    stringBuilder.append(sessionData.getCurrencyAlphabeticalCode());
                    this.appendLineFeed(stringBuilder);
                    int n = 0;
                    long l = sessionData.getTotalAmountDebit();
                    if (l > 0L) {
                        n = sessionData.getNbDebit();
                        this.printOneTransactionInfo("DEBIT", stringBuilder, n, l, sessionData.getCurrencyFraction(), sessionData.getCurrencyAlphabeticalCode());
                    }
                    if ((l = sessionData.getTotalAmountRefund()) > 0L) {
                        n = sessionData.getNbRefund();
                        this.printOneTransactionInfo("REFUND", stringBuilder, n, l, sessionData.getCurrencyFraction(), sessionData.getCurrencyAlphabeticalCode());
                    }
                    if ((l = sessionData.getTotalAmountReversalDebit()) <= 0L) continue;
                    n = sessionData.getNbReversalDebit();
                    this.printOneTransactionInfo("REVERSAL", stringBuilder, n, l, sessionData.getCurrencyFraction(), sessionData.getCurrencyAlphabeticalCode());
                }
            } else {
                stringBuilder.append(this.getLabelTranslated("TOTAL_CURRENCY_LABEL", "Total"));
                this.appendLineFeed(stringBuilder);
                stringBuilder.append(" ");
                stringBuilder.append(this.getLabelTranslated("NO_TRANSACTION_LABEL", "Aucune transaction"));
                this.appendLineFeed(stringBuilder);
            }
        }
        catch (Exception exception) {
            this.dataContainerMerchant.logger(2, "printTotalTicket() " + exception);
        }
    }

    private void appendInfoTransaction(StringBuilder stringBuilder, long l, int n, String string) {
        stringBuilder.append(UtilsYP.formatAmount(l, n, Locale.FRANCE));
        stringBuilder.append(' ');
        stringBuilder.append(string);
        this.appendLineFeed(stringBuilder);
    }

    private void addFormatedDateJJxMMxAAAA(StringBuilder stringBuilder, long l, String string) {
        try {
            Calendar calendar = UtilsYP.getCalendar(l);
            int n = calendar.get(1);
            int n2 = calendar.get(2) + 1;
            int n3 = calendar.get(5);
            if (n3 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n3);
            stringBuilder.append(string);
            if (n2 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n2);
            stringBuilder.append(string);
            stringBuilder.append(n);
        }
        catch (Exception exception) {
            this.dataContainerMerchant.logger(2, "addFormatedDateJJxMMxAAAA() " + exception);
        }
    }

    private void addFormatedDateHHxMM(StringBuilder stringBuilder, long l, String string) {
        try {
            Calendar calendar = UtilsYP.getCalendar(l);
            int n = calendar.get(11);
            int n2 = calendar.get(12);
            if (n < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n);
            stringBuilder.append(string);
            if (n2 < 10) {
                stringBuilder.append('0');
            }
            stringBuilder.append(n2);
        }
        catch (Exception exception) {
            this.dataContainerMerchant.logger(2, "addFormatedDateHHxMM() " + exception);
        }
    }

    private void addSessionDataToList(SessionData sessionData) {
        try {
            boolean bl = false;
            if (this.listSessionData.isEmpty()) {
                this.listSessionData.add(sessionData);
            } else {
                for (SessionData sessionData2 : this.listSessionData) {
                    if (!UtilsYP.isEquals(sessionData2.getCurrencyAlphabeticalCode(), sessionData.getCurrencyAlphabeticalCode(), false, false)) continue;
                    int n = 0;
                    n = sessionData2.getNbDebit() + sessionData.getNbDebit();
                    sessionData2.setNbDebit(n);
                    n = sessionData2.getNbRefund() + sessionData.getNbRefund();
                    sessionData2.setNbRefund(n);
                    n = sessionData2.getNbReversalDebit() + sessionData.getNbReversalDebit();
                    sessionData2.setNbReversalDebit(n);
                    long l = 0L;
                    l = sessionData2.getTotalAmountDebit() + sessionData.getTotalAmountDebit();
                    sessionData2.setTotalAmountDebit(l);
                    l = sessionData2.getTotalAmountRefund() + sessionData.getTotalAmountRefund();
                    sessionData2.setTotalAmountRefund(l);
                    l = sessionData2.getTotalAmountReversalDebit() + sessionData.getTotalAmountReversalDebit();
                    sessionData2.setTotalAmountReversalDebit(l);
                    bl = true;
                }
                if (!bl) {
                    this.listSessionData.add(sessionData);
                }
            }
        }
        catch (Exception exception) {
            this.dataContainerMerchant.logger(2, "addSessionDataToList() " + exception);
        }
    }

    private void createMainSQLRequest(StringBuilder stringBuilder, YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) {
        stringBuilder.append("SELECT \r\n");
        stringBuilder.append("        '***' AS date\r\n");
        stringBuilder.append("        ,'***' AS contractIdentifier\r\n");
        stringBuilder.append("        ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("        ,'***' AS cashierID\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ('DEBIT' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT' , 'DEBIT_DIFFERED', 'QUASI_CASH') , 1, 0)) AS nbDebit\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ('DEBIT' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'DEBIT_DIFFERED', 'QUASI_CASH') , transactionAmount, 0)) AS totalAmountDebit\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , transactionAmount, 0)) AS totalAmountRefund\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ('REVERSAL_DEBIT', 'REVERSAL_QUASI_CASH'), 1, 0)) AS nbReversalDebit\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType IN ('REVERSAL_DEBIT', 'REVERSAL_QUASI_CASH'), transactionAmount, 0)) AS totalAmountReversalDebit\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
        stringBuilder.append("        ,SUM(");
        stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
        stringBuilder.append("(transactionType = 'INITIAL_RESERVATION', transactionAmount, 0)) AS totalAmountINITIAL_RESERVATION\r\n");
        stringBuilder.append("FROM\r\n");
        stringBuilder.append("(\r\n");
    }

    private void appendContractSQLRequest(StringBuilder stringBuilder, YP_TCD_DCC_Business yP_TCD_DCC_Business, String string) {
        String string2 = yP_TCD_DCC_Business.transaction.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DCC_Business.transaction);
        stringBuilder.append("          SELECT\r\n");
        stringBuilder.append("              ");
        stringBuilder.append(yP_TCD_DCC_Business.getDataBaseConnector().sql_Formater.sqlDate("transactionAppliLocalTime"));
        stringBuilder.append(" AS dateTmp\r\n");
        stringBuilder.append("              ,transactionType\r\n");
        stringBuilder.append("              ,transactionAmount\r\n");
        stringBuilder.append("              ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("              FROM " + yP_TCD_DCC_Business.transactionArchive.getFullTableName() + "\r\n");
        stringBuilder.append("              WHERE transactionStatus ='ACCEPTED'\r\n");
        stringBuilder.append(string);
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append("              AND" + string2 + "\r\n");
        }
    }

    private void endMainSQLRequest(StringBuilder stringBuilder) {
        stringBuilder.append(") tmp\r\n");
        stringBuilder.append("GROUP BY transactionCurrencyAlpha");
    }

    private int getAmountFraction(String string) {
        if (string != null && string.contentEquals("XPF")) {
            return 0;
        }
        return 2;
    }

    private long setTransactionTimeMS(int n, String string) {
        Calendar calendar = UtilsYP.getSystemGMTTime();
        calendar.add(5, n);
        calendar.set(11, Integer.parseInt(string.substring(0, 2)));
        calendar.set(12, Integer.parseInt(string.substring(2, 4)));
        calendar.set(13, 0);
        calendar.set(14, 0);
        return calendar.getTimeInMillis();
    }

    private long setTransactionTimeMS(int n, String string, String string2) {
        Calendar calendar = UtilsYP.getSystemGMTTime();
        calendar.set(1, Integer.parseInt(string.substring(6, 10)));
        calendar.set(2, Integer.parseInt(string.substring(3, 5)) - 1);
        calendar.set(5, Integer.parseInt(string.substring(0, 2)) + n);
        calendar.set(11, Integer.parseInt(string2.substring(0, 2)));
        calendar.set(12, Integer.parseInt(string2.substring(2, 4)));
        calendar.set(13, 0);
        calendar.set(14, 0);
        return calendar.getTimeInMillis();
    }

    @Override
    public String ticket(boolean bl, int n) {
        return null;
    }

    @Override
    protected String summaryReport(YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE, List<YP_Row> list) {
        return null;
    }
}

