/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_KRN_InitialisationParameters;
import org.yp.designaccesobjects.business.DAO_KRN_MerchantParameters;
import org.yp.designaccesobjects.business.DAO_Transaction;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.YP_TCG_Mailer;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.events.YP_TCD_DCB_Interface_Events;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.YP_TCD_DCB_Interface_Hosts;
import org.yp.framework.ondemandcomponents.datacontainers.extension.sessionpersister.YP_TCD_DCB_Interface_SessionPersister;
import org.yp.framework.ondemandcomponents.datacontainers.extension.sms.YP_TCD_DCB_Interface_SMS;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.YP_TCD_DCB_Interface_Time;
import org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister.YP_TCD_DCB_Interface_TRSPersister;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.CardHolderAuthenticationEnumeration;
import org.yp.utils.enums.CardHolderAuthenticationSystemEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.InitializationStatusEnumeration;
import org.yp.utils.enums.RealisationModeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_TCD_DCC_Business
extends YP_TCD_DC_Context {
    public static final int YP_DATA_CONTAINER = 1;
    public static final String DUPLICATES_CHECK_MODE_NONE = "0";
    public static final String DUPLICATES_CHECK_MODE_EIGHT_MINUTES = "1";
    private int containerBusinessType = 0;
    private YP_Application applicationPlugin;
    private YP_TCD_DCC_Status dataContainerStatus = null;
    private YP_TCD_DCC_Merchant dataContainerMerchant = null;
    public YP_TCD_DCB_Interface_Events eventsInterface;
    public YP_TCD_DCB_Interface_Time timeInterface;
    public YP_TCD_DCB_Interface_Hosts hostsInterface;
    public YP_TCD_DAO_SQL_Transaction transaction;
    public YP_TCD_DesignAccesObject transactionArchive;
    public YP_TCD_DesignAccesObject initialisationParameters;
    public YP_TCD_DesignAccesObject merchantParameters;
    private int transactionNumber = 0;
    private boolean transactionNumberInitialised = false;
    private final ReentrantLock transactionNumberMutex = new ReentrantLock();
    private YP_Row contractRow = null;
    private long idContract;
    protected YP_Row initialisationRow = null;
    private YP_TCD_DAO_LOC_Table temporaryTable;
    private final List<Integer> applicationList = new ArrayList<Integer>();
    private final ReentrantLock applicationListMutex = new ReentrantLock();
    public List<YP_App_Interface_Selection> selectorList = new ArrayList<YP_App_Interface_Selection>();
    private Bitmap trsTypeAllowed = null;
    private int satisfactionIndex = 0;
    private static final int PERSIST_DUPLICATE_TIMEOUT = 30000;
    public static final Set<Long> persistTokenSet = ConcurrentHashMap.newKeySet();
    private boolean merchantParametersInitialised = false;
    private String merchantContract;
    private String merchantName;
    private String merchantAddress;
    private String merchantCity;
    private String merchantZipCode;
    private String merchantCategoryCode;
    private String countryCode;
    private String acquiringInstitutionIdentificationCode;
    private String commercialRegisterNumber;
    private String terminalIdentification;
    private String merchantType;
    public static final String MAIL_TLX_REPORT = "mailTLXReport";
    public static final String MAIL_TLX_REPORT_KO = "mailTLXReportKO";
    public static final String MAIL_TLC_REPORT = "mailTLCReport";
    public static final String MAIL_TLC_REPORT_OFF = "mailTLCReportOff";
    public static final String MAIL_TLC_REPORT_KO = "mailTLCReportKO";
    public static final String MAIL_TLP_REPORT = "mailTLPReport";
    public static final String MAIL_TLP_REPORT_KO = "mailTLPReportKO";
    public static final String MAIL_GLOBAL_REPORT = "mailGlobalReport";
    public static final String MAIL_GLOBAL_REPORT_OFF = "mailGlobalReportOff";
    public static final String MAIL_GSR_PATTERN = "mailGSRPattern";
    public static final String MAIL_TLC_REPORT_PATTERN_BY_BANK_ = "mailTLCReportPatternByBank_";
    public static final String MAIL_TLP_REPORT_PATTERN_BY_BANK_ = "mailTLPReportPatternByBank_";
    public static final String MAIL_REPRINT_PATTERN_ACCEPTED = "mailReprintPatternAccepted";
    public static final String MAIL_REPRINT_PATTERN_REFUSED = "mailReprintPatternRefused";

    public YP_TCD_DCC_Business(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length >= 1 && objectArray[0] != null && objectArray[0] instanceof YP_Application) {
            this.setApplicationPlugin((YP_Application)objectArray[0]);
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            if ((this.getContainerBusinessType() & 1) == 0) {
                this.transaction = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Transaction.class, 0, 32, null);
                this.transactionArchive = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Transaction.class, 0, 8, null);
                this.initialisationParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_InitialisationParameters.class, 0, 0, null);
                this.merchantParameters = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_KRN_MerchantParameters.class, 0, 0, null);
            }
        }
        catch (Exception exception) {
            this.logger(2, "initialize()", exception);
            return -1;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        if (this.transaction != null) {
            this.transaction.shutdown();
            this.transaction = null;
        }
        if (this.transactionArchive != null) {
            this.transactionArchive.shutdown();
            this.transactionArchive = null;
        }
        if (this.temporaryTable != null) {
            this.temporaryTable.shutdown();
            this.temporaryTable = null;
        }
        for (YP_App_Interface_Selection yP_App_Interface_Selection : this.selectorList) {
            yP_App_Interface_Selection.shutdown();
        }
        this.selectorList.clear();
        try {
            this.applicationListMutex.lock();
            int n = this.applicationList.size();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object;
                Integer n3 = this.applicationList.get(n2);
                if (n3 > 0 && (yP_Object = this.getPluginByProcessID(n3)) != null) {
                    yP_Object.shutdown();
                }
                ++n2;
            }
        }
        finally {
            this.applicationListMutex.unlock();
        }
        this.applicationList.clear();
        if (this.dataContainerMerchant != null) {
            this.dataContainerMerchant.dataContainerBusinessList.remove(this);
            this.dataContainerMerchant = null;
        }
        if (this.eventsInterface != null) {
            this.eventsInterface.shutdown();
            this.eventsInterface = null;
        }
        if (this.timeInterface != null) {
            this.timeInterface.shutdown();
            this.timeInterface = null;
        }
        if (this.hostsInterface != null) {
            this.hostsInterface.shutdown();
            this.hostsInterface = null;
        }
        if (this.initialisationParameters != null) {
            this.initialisationParameters.shutdown();
            this.initialisationParameters = null;
        }
        if (this.merchantParameters != null) {
            this.merchantParameters.shutdown();
            this.merchantParameters = null;
        }
        try {
            this.getPluginByName("DataContainerManager").dealRequest(this, "removeOneContract", this);
        }
        catch (Exception exception) {
            this.logger(2, "shutdown()", exception);
        }
        return super.shutdown();
    }

    public void extendTransactionDAO(Object object) {
        this.transaction.addExtension(object);
        this.transactionArchive.addExtension(object);
    }

    protected int initialiseSelectors(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2) {
        YP_Object yP_Object;
        String string = this.getApplicationPlugin().getApplicationPropertie("SelectorByBIN");
        String string2 = this.getApplicationPlugin().getApplicationPropertie("SelectorByAID");
        String string3 = this.getApplicationPlugin().getApplicationPropertie("SelectorCMC7");
        if (string3 != null && !string3.isEmpty()) {
            yP_Object = this.newPluginByName(string3, new Object[0]);
            yP_Object.initialize();
        } else {
            if (yP_TCD_DesignAccesObject != null && string != null && !string.isEmpty()) {
                yP_Object = this.newPluginByName(string, yP_TCD_DesignAccesObject);
                yP_Object.initialize();
            }
            if (yP_TCD_DesignAccesObject2 != null && string2 != null && !string2.isEmpty()) {
                yP_Object = this.newPluginByName(string2, yP_TCD_DesignAccesObject2);
                yP_Object.initialize();
            }
        }
        long l = -1L;
        try {
            l = Long.parseLong(this.getApplicationPlugin().getApplicationPropertie("TrsTypeAllowed"));
        }
        catch (Exception exception) {}
        if (l < 0L) {
            this.logger(3, "initialiseSelectors() this log is just to indicate that one must add the property SELECTOR_TRS_TYPE_ALLOWED to the application");
            this.trsTypeAllowed = null;
        } else {
            this.trsTypeAllowed = new Bitmap(l);
        }
        return 1;
    }

    protected int initialiseSelectors(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3) {
        YP_Object yP_Object;
        String string = this.getApplicationPlugin().getApplicationPropertie("SelectorByBIN");
        String string2 = this.getApplicationPlugin().getApplicationPropertie("SelectorByAIDAndProduct");
        String string3 = this.getApplicationPlugin().getApplicationPropertie("SelectorCMC7");
        if (string3 != null && !string3.isEmpty()) {
            yP_Object = this.newPluginByName(string3, new Object[0]);
            yP_Object.initialize();
        } else if (string == null && string2 == null) {
            this.logger(2, "initialiseSelectors() this log is just to indicate that one should add the properties SelectorByBIN and/or SelectorByAID and/or selectorByAIDAndProduct to the application");
            if (yP_TCD_DesignAccesObject != null) {
                yP_Object = this.newPluginByName("ApplicationSelectorByBIN", yP_TCD_DesignAccesObject);
                yP_Object.initialize();
            }
            if (yP_TCD_DesignAccesObject2 != null) {
                yP_Object = this.newPluginByName("ApplicationSelectorByAIDAndProduct", yP_TCD_DesignAccesObject2, yP_TCD_DesignAccesObject3);
                yP_Object.initialize();
            }
        } else {
            if (yP_TCD_DesignAccesObject != null && string != null && !string.isEmpty()) {
                yP_Object = this.newPluginByName(string, yP_TCD_DesignAccesObject);
                yP_Object.initialize();
            }
            if (yP_TCD_DesignAccesObject2 != null && string2 != null && !string2.isEmpty()) {
                yP_Object = this.newPluginByName(string2, yP_TCD_DesignAccesObject2, yP_TCD_DesignAccesObject3);
                yP_Object.initialize();
            }
        }
        long l = -1L;
        try {
            l = Long.parseLong(this.getApplicationPlugin().getApplicationPropertie("TrsTypeAllowed"));
        }
        catch (Exception exception) {}
        if (l < 0L) {
            this.logger(2, "initialiseSelectors() this log is just to indicate that one must add the property SELECTOR_TRS_TYPE_ALLOWED to the application");
            this.trsTypeAllowed = null;
        } else {
            this.trsTypeAllowed = new Bitmap(l);
        }
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        Class<? extends YP_Row> clazz;
        if (yP_TCD_DesignAccesObject == this.transaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() transaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.transactionArchive) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() transactionArchive");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() merchantParameters");
            }
            this.merchantParametersInitialised = false;
            this.resetMerchantParameters();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.initialisationParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() initialisationParameters");
            }
            this.initialisationRow = this.initialisationParameters.getUniqueRow();
        }
        if ((clazz = yP_TCD_DesignAccesObject.getRowClass()) == DAO_KRN_MerchantParameters.class && this.getLogLevel() >= 2) {
            this.logger(2, "onChange() test to see it this case is possible");
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.transaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() transaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.transactionArchive) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() transactionArchive");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() merchantParameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.initialisationParameters && this.getLogLevel() >= 5) {
            this.logger(5, "onSaveBefore() initialisationParameters");
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.transaction) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() transaction");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.transactionArchive) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() transactionArchive");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.merchantParameters) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() merchantParameters");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.initialisationParameters && this.getLogLevel() >= 5) {
            this.logger(5, "onSaveAfter() initialisationParameters");
        }
        return super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    private void setApplicationPlugin(YP_Application yP_Application) {
        this.applicationPlugin = yP_Application;
    }

    public final YP_Application getApplicationPlugin() {
        return this.applicationPlugin;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final YP_Application newApplicationPlugin(YP_Transaction yP_Transaction) {
        try {
            YP_Application yP_Application = (YP_Application)yP_Transaction.newPluginByName(this.getApplicationPlugin().toString(), yP_Transaction, this);
            yP_Application.setApplicationRow(this.getApplicationPlugin().getApplicationRow());
            yP_Application.setApplicationProperties(this.getApplicationPlugin().getApplicationProperties());
            yP_Application.setContractIdentifier(this.getContractIdentifier());
            try {
                this.applicationListMutex.lock();
                int n = this.applicationList.size();
                int n2 = 0;
                while (true) {
                    if (n2 >= n) {
                        this.applicationList.add(yP_Application.getProcessID());
                        yP_Application.setRankInDCC(n);
                        YP_Application yP_Application2 = yP_Application;
                        return yP_Application2;
                    }
                    Integer n3 = this.applicationList.get(n2);
                    if (n3 < 0) {
                        this.applicationList.set(n2, yP_Application.getProcessID());
                        yP_Application.setRankInDCC(n2);
                        YP_Application yP_Application3 = yP_Application;
                        return yP_Application3;
                    }
                    ++n2;
                }
            }
            finally {
                this.applicationListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "newApplicationPlugin() ", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int removeApplicationPlugin(YP_Application yP_Application) {
        try {
            try {
                this.applicationListMutex.lock();
                if (yP_Application.getProcessID() == this.applicationList.get(yP_Application.getRankInDCC()).intValue()) {
                    this.applicationList.set(yP_Application.getRankInDCC(), -1);
                    return 1;
                }
                if (this.getLogLevel() < 2) return -1;
                this.logger(2, "removeApplicationPlugin() application not found...");
                return -1;
            }
            finally {
                this.applicationListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "removeApplicationPlugin() ", exception);
            return -1;
        }
    }

    private void initTransactionNumber() {
        Object object;
        this.transactionNumber = (UtilsYP.getInstanceNumber() - 1) * 100000;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
        yP_ComplexGabarit.set("transactionNumber", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, (UtilsYP.getInstanceNumber() - 1) * 100000);
        yP_ComplexGabarit.set("transactionNumber", YP_ComplexGabarit.OPERATOR.LESS, UtilsYP.getInstanceNumber() * 100000);
        yP_ComplexGabarit.set("transactionNumber", YP_ComplexGabarit.OPERATOR.MAX);
        List<YP_Row> list = this.transaction.getRowListSuchAs(yP_ComplexGabarit);
        if (list != null && !list.isEmpty() && (object = list.get(0).getFieldValueByName("transactionNumber")) != null) {
            if (object instanceof Integer) {
                this.transactionNumber = (Integer)object;
            } else {
                this.logger(2, "initTransactionNumber() : bad type for transactionNumber");
            }
        }
        this.transactionNumberInitialised = true;
    }

    public final int getNextTransactionNumber() {
        try {
            this.transactionNumberMutex.lock();
            if (!this.transactionNumberInitialised) {
                this.initTransactionNumber();
            }
            ++this.transactionNumber;
            if (this.transactionNumber >= UtilsYP.getInstanceNumber() * 100000) {
                this.transactionNumber = UtilsYP.getInstanceNumber() == 1 ? 1 : (UtilsYP.getInstanceNumber() - 1) * 100000;
            }
            int n = this.transactionNumber;
            return n;
        }
        finally {
            this.transactionNumberMutex.unlock();
        }
    }

    public int archiveTransactions() {
        if (this.getLogLevel() >= 4) {
            this.logger(4, "archiveTransactions() start");
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.transaction);
        yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.IN, new Object[]{UploadStatusEnumeration.UPLOADED, UploadStatusEnumeration.NOT_UPLOADABLE});
        int n = this.transaction.archiveRowsSuchAs(this.transactionArchive, true, yP_ComplexGabarit);
        if (n == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "archiveTransactions() no trs uploaded to archive...");
            }
            return 0;
        }
        if (n < 0) {
            this.logger(2, "archiveTransactions() uploaded trs not archived...");
            return 0;
        }
        if (this.getLogLevel() >= 4) {
            this.logger(4, "archiveTransactions() end");
        }
        return 1;
    }

    public final void setSatisfactionIndex(int n) {
        this.satisfactionIndex = n;
    }

    public final int getSatisfactionIndex() {
        return this.satisfactionIndex;
    }

    private void resetMerchantParameters() {
        this.merchantContract = "";
        this.merchantName = "";
        this.merchantAddress = "";
        this.merchantCity = "";
        this.merchantZipCode = "";
        this.merchantCategoryCode = "";
        this.commercialRegisterNumber = "";
        this.countryCode = "";
        this.acquiringInstitutionIdentificationCode = "";
        this.terminalIdentification = "";
        this.merchantType = "";
    }

    private int initialiseMerchantParameters() {
        if ((this.getContainerBusinessType() & 1) != 0) {
            this.resetMerchantParameters();
            this.merchantParametersInitialised = true;
            return 0;
        }
        if (this.merchantParameters == null) {
            this.logger(2, "initialiseMerchantParameters() no merchantParameters empty values will be used");
            this.resetMerchantParameters();
            return -1;
        }
        try {
            this.merchantParameters.lock();
            if (this.merchantParametersInitialised) {
                return 0;
            }
            YP_Row yP_Row = this.merchantParameters.getUniqueRow();
            if (yP_Row == null) {
                this.logger(3, "initialiseMerchantParameters() unable to retrieve merchantParametersRow");
                this.resetMerchantParameters();
                this.merchantParametersInitialised = true;
                return 0;
            }
            this.merchantContract = yP_Row.getFieldStringValueByName("merchantContract").trim();
            this.merchantName = yP_Row.getFieldStringValueByName("merchantName").trim();
            this.merchantAddress = yP_Row.getFieldStringValueByName("merchantAddress").trim();
            this.merchantCity = yP_Row.getFieldStringValueByName("merchantCity").trim();
            this.merchantZipCode = yP_Row.getFieldStringValueByName("merchantZipCode").trim();
            this.merchantCategoryCode = yP_Row.getFieldStringValueByName("merchantCategoryCode").trim();
            this.commercialRegisterNumber = yP_Row.getFieldStringValueByName("commercialRegisterNumber").trim();
            this.countryCode = yP_Row.getFieldStringValueByName("countryCode").trim();
            this.acquiringInstitutionIdentificationCode = yP_Row.getFieldStringValueByName("acquiringInstitutionIdentificationCode").trim();
            this.terminalIdentification = yP_Row.getFieldStringValueByName("terminalIdentification").trim();
            this.merchantType = yP_Row.getFieldStringValueByName("merchantType").trim();
            this.merchantParametersInitialised = true;
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "initialiseMerchantParameters() ", exception);
            return -1;
        }
        finally {
            this.merchantParameters.unlock();
        }
    }

    public String getMerchantContract() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantContract;
    }

    public String getMerchantName() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantName;
    }

    public String getMerchantAddress() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantAddress;
    }

    public String getMerchantCity() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantCity;
    }

    public String getMerchantZipCode() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantZipCode;
    }

    public String getMerchantCategoryCode() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantCategoryCode;
    }

    @Deprecated
    public String getCountryCode() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.countryCode;
    }

    public boolean isFacilitatorApplication() {
        try {
            String string = this.getContractRow().getFieldStringValueByName("contractLabel");
            if (string != null) {
                return string.toUpperCase().contains("FICHIER");
            }
        }
        catch (Exception exception) {
            this.logger(2, "isFacilitatorApplication() ", exception);
        }
        return false;
    }

    public String getCountryCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_Row yP_Row;
        String string;
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        if (yP_TCD_DC_Transaction != null && (string = yP_TCD_DC_Transaction.contextHandler.getStoreIdentifier()) != null && !string.isEmpty() && (yP_Row = yP_TCD_DC_Transaction.getDataContainerBrand().getStore(this.getDataContainerMerchant().getIDMerchant(), string)) != null) {
            try {
                String string2;
                String string3 = yP_Row.getFieldStringValueByName("facilitatorID");
                if (this.isFacilitatorApplication() && string3 != null && !string3.isEmpty() && (string2 = yP_Row.getFieldStringValueByName("storeCountryCodeNum")) != null && !string2.isEmpty()) {
                    return string2;
                }
            }
            catch (Exception exception) {}
        }
        return this.countryCode;
    }

    public String getAcquiringInstitutionIdentificationCode() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.acquiringInstitutionIdentificationCode;
    }

    public String getCommercialRegisterNumber() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.commercialRegisterNumber;
    }

    public YP_Row getInitialisationRow() {
        if (this.initialisationRow == null && this.initialisationParameters != null) {
            this.initialisationRow = this.initialisationParameters.getUniqueRow();
            if (this.initialisationRow == null) {
                try {
                    this.initialisationParameters.addRow(this.initialisationParameters.getNewRow());
                }
                catch (Exception exception) {
                    this.logger(2, "getInitialisationRow()", exception);
                    return null;
                }
                this.initialisationParameters.persist();
                this.initialisationRow = this.initialisationParameters.getUniqueRow();
            }
        }
        return this.initialisationRow;
    }

    public void setInitialisationRow(YP_Row yP_Row) {
        this.initialisationRow = yP_Row;
    }

    public String getTerminalIdentification() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.terminalIdentification;
    }

    public String getMerchantType() {
        if (!this.merchantParametersInitialised) {
            this.initialiseMerchantParameters();
        }
        return this.merchantType;
    }

    public YP_Row getMerchantRow() {
        return this.getDataContainerMerchant().getMerchantRow();
    }

    public YP_Row getContractRow() {
        return this.contractRow;
    }

    public void setContractRow(YP_Row yP_Row) {
        this.contractRow = yP_Row;
        if (yP_Row != null) {
            this.idContract = yP_Row.getPrimaryKey();
        }
        this.storedParameters = null;
    }

    public String getActivationCode() {
        return this.contractRow.getFieldStringValueByName("activationCode");
    }

    public void setActivationCode(String string) {
        this.contractRow.set("activationCode", string);
    }

    public InitializationStatusEnumeration getInitializationStatus() {
        return (InitializationStatusEnumeration)((Object)this.contractRow.getFieldValueByName("initializationStatus"));
    }

    public void setInitializationStatus(InitializationStatusEnumeration initializationStatusEnumeration) {
        this.contractRow.set("initializationStatus", initializationStatusEnumeration);
    }

    @Override
    public String get(String string) {
        return super.get(string);
    }

    public void setContainerBusinessType(int n) {
        this.containerBusinessType = n;
    }

    public int getContainerBusinessType() {
        return this.containerBusinessType;
    }

    public YP_TCD_DAO_LOC_Table getTemporaryTable() {
        return this.temporaryTable;
    }

    public void setTemporaryTable(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        if (this.temporaryTable != null) {
            this.temporaryTable.shutdown();
        }
        this.temporaryTable = yP_TCD_DAO_LOC_Table;
    }

    @Deprecated
    public int mailTLCReport(String string, String string2, boolean bl) {
        return this.mailTLCReport(string, string2, bl, false, false);
    }

    public int mailTLCReport(String string, String string2, boolean bl, boolean bl2, boolean bl3) {
        if (bl2) {
            return 0;
        }
        if (!bl && !bl3) {
            return 0;
        }
        Set<String> set = bl ? this.getParameters(MAIL_TLC_REPORT, MAIL_TLX_REPORT) : this.getParameters(MAIL_TLC_REPORT_KO, MAIL_TLX_REPORT_KO);
        if (set == null || set.isEmpty()) {
            return 0;
        }
        return this.mailTLCReport(string, string2, set);
    }

    public int mailTLCReport(String string, String string2, String string3) {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add(string);
        return this.mailTLCReport(string2, string3, hashSet);
    }

    private int mailTLCReport(String string, String string2, Set<String> set) {
        Set<String> set2 = null;
        String string3 = this.getAcquiringInstitutionIdentificationCode();
        if (string3 != null && !string3.isEmpty()) {
            if (string3.length() >= 5) {
                string3 = string3.substring(string3.length() - 5);
            }
            if ((set2 = this.getParameters(MAIL_TLC_REPORT_PATTERN_BY_BANK_ + string3)) == null || set2.isEmpty()) {
                set2 = this.getParameters(MAIL_TLC_REPORT_PATTERN_BY_BANK_);
            }
            if (set2 != null && set2.size() > 1) {
                this.logger(2, "mailTLCReport() Too many templates by bank for " + string3);
            }
        }
        return YP_TCG_Mailer.mailTLXReport(this, string, string2, set, set2);
    }

    public int mailTLPReport(String string, String string2, boolean bl) {
        Set<String> set = bl ? this.getParameters(MAIL_TLP_REPORT, MAIL_TLX_REPORT) : this.getParameters(MAIL_TLP_REPORT_KO, MAIL_TLX_REPORT_KO);
        if (set == null || set.isEmpty()) {
            return 0;
        }
        Set<String> set2 = null;
        String string3 = this.getAcquiringInstitutionIdentificationCode();
        if (string3 != null && !string3.isEmpty()) {
            if (string3.length() >= 5) {
                string3 = string3.substring(string3.length() - 5);
            }
            if ((set2 = this.getParameters(MAIL_TLP_REPORT_PATTERN_BY_BANK_ + string3)) == null || set2.isEmpty()) {
                set2 = this.getParameters(MAIL_TLP_REPORT_PATTERN_BY_BANK_);
            }
            if (set2 != null && set2.size() > 1) {
                this.logger(2, "mailTLPReport() Too many templates by bank for " + string3);
            }
        }
        return YP_TCG_Mailer.mailTLXReport(this, string, string2, set, set2);
    }

    public int mailGSRReprint(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string, String string2, String string3) {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add(string);
        Set<String> set = this.getParameters(MAIL_GSR_PATTERN);
        return YP_TCG_Mailer.mailTLXReport(this, string2, string3, hashSet, set, yP_TCD_DC_Transaction);
    }

    public int mailTRSReprint(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string, String string2, String string3, boolean bl) {
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add(string);
        Set<String> set = bl ? this.getParameters(MAIL_REPRINT_PATTERN_ACCEPTED) : this.getParameters(MAIL_REPRINT_PATTERN_REFUSED);
        return YP_TCG_Mailer.mailTLXReport(this, string2, string3, hashSet, set, yP_TCD_DC_Transaction);
    }

    @Deprecated
    public int mailTRSReprint(String string, String string2, String string3, boolean bl) {
        return this.mailTRSReprint(null, string, string2, string3, bl);
    }

    private void logDuplicateTransaction(YP_Row yP_Row) {
        try {
            this.logger(-3, yP_Row.serialize());
        }
        catch (Exception exception) {
            this.logger(2, "logDuplicateTransaction() ???:", exception);
        }
    }

    protected int duplicateGabaritChecks(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_ComplexGabarit yP_ComplexGabarit) {
        return 0;
    }

    public int persistTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) throws Exception {
        long l = YP_TCD_DCC_Business.getIDToken(yP_TCD_DC_Transaction);
        try {
            int n;
            if (l > 0L && (n = (int)(persistTokenSet.add(l) ? 1 : 0)) == 0) {
                long l2 = System.currentTimeMillis();
                do {
                    this.logger(2, "persistTransaction() there are two transactions with the same token at the same time, let's wait");
                    Thread.sleep(1000L);
                } while ((n = (int)(persistTokenSet.add(l) ? 1 : 0)) == 0 && !UtilsYP.isTimeout(l2, 30000));
                if (n == 0) {
                    this.logger(2, "persistTransaction() can't wait anymore let's save it anyway...");
                }
            }
            int n2 = n = this.persistTransactionInternal(yP_TCD_DC_Transaction);
            return n2;
        }
        catch (Exception exception) {
            this.logger(2, "persistTransaction() ", exception);
            throw exception;
        }
        finally {
            if (l > 0L) {
                try {
                    persistTokenSet.remove(l);
                }
                catch (Exception exception) {
                    this.logger(2, "persistTransaction() ignored", exception);
                }
            }
        }
    }

    private int persistTransactionInternal(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) throws Exception {
        boolean bl = false;
        YP_Row yP_Row = bl ? this.transactionArchive.getNewRow() : this.transaction.getNewRow();
        int n = yP_TCD_DC_Transaction.transactionDatasToTransactionRow(yP_Row);
        if (n <= 0) {
            this.logger(1, "persistTransaction() unable to map row");
            return -1;
        }
        n = bl ? this.transactionArchive.addRow(yP_Row, true) : this.transaction.addRow(yP_Row, true);
        if (n <= 0) {
            this.logger(1, "persistTransaction() unable to add row");
        } else {
            if (this.persisterSet != null) {
                for (YP_TCD_DCB_Interface_TRSPersister yP_TCD_DCB_Interface_TRSPersister : this.persisterSet) {
                    yP_TCD_DCB_Interface_TRSPersister.persistTransaction(this, yP_TCD_DC_Transaction);
                }
            }
            if (this.dataContainerMerchant.persisterSet != null) {
                for (YP_TCD_DCB_Interface_TRSPersister yP_TCD_DCB_Interface_TRSPersister : this.dataContainerMerchant.persisterSet) {
                    yP_TCD_DCB_Interface_TRSPersister.persistTransaction(this, yP_TCD_DC_Transaction);
                }
            }
            if (this.getDataContainerBrand().persisterSet != null) {
                for (YP_TCD_DCB_Interface_TRSPersister yP_TCD_DCB_Interface_TRSPersister : this.getDataContainerBrand().persisterSet) {
                    yP_TCD_DCB_Interface_TRSPersister.persistTransaction(this, yP_TCD_DC_Transaction);
                }
            }
        }
        if (yP_TCD_DC_Transaction.accountHandler.getMeanOfPaymentDatasReceived() == 2) {
            yP_TCD_DC_Transaction.accountHandler.updateMopStats();
        }
        return n;
    }

    public int loadTransactions(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, List<YP_Row> list) {
        Iterator<YP_Row> iterator = list.iterator();
        if (iterator.hasNext()) {
            YP_Row yP_Row = iterator.next();
            int n = yP_TCD_DC_Transaction.transactionRowToTransactionDatas(yP_Row);
            return n;
        }
        return 0;
    }

    public int loadTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row) {
        int n = yP_TCD_DC_Transaction.transactionRowToTransactionDatas(yP_Row);
        return n;
    }

    public YP_Row saveTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        int n;
        Object object;
        try {
            object = this.transaction.getExtensionList();
            if (object != null && !object.isEmpty()) {
                Iterator<Object> iterator = object.iterator();
                while (iterator.hasNext()) {
                    Object object2 = iterator.next();
                    yP_TCD_DC_Transaction.addExtension(object2.getClass().newInstance());
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "saveTransaction() ", exception);
        }
        if ((n = yP_TCD_DC_Transaction.transactionDatasToTransactionRow((YP_Row)(object = this.transaction.getNewRow()))) <= 0) {
            return null;
        }
        return object;
    }

    public List<YP_Row> snapshotTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        arrayList.add(this.saveTransaction(yP_TCD_DC_Transaction));
        return arrayList;
    }

    public static void setServiceSequenceNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.contextHandler.setServiceSequenceNumber(string);
    }

    public static String getServiceSequenceNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.contextHandler.getServiceSequenceNumber();
    }

    public static void setExtendedIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.contextHandler.setExtendedIdentifier(string);
    }

    public static String getExtendedIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.contextHandler.getExtendedIdentifier();
    }

    public static void setProcessorIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setProcessorIdentifier(string);
    }

    public static String getProcessorIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getProcessorIdentifier();
    }

    public static void setInstanceNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.contextHandler.setInstanceNumber(n);
    }

    public static int getInstanceNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.contextHandler.getInstanceNumber();
    }

    public static void setGlobalResult(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_TCD_PosProtocol.RESULT_TYPE rESULT_TYPE) {
        yP_TCD_DC_Transaction.commonHandler.setGlobalResult(rESULT_TYPE);
    }

    public static YP_TCD_PosProtocol.RESULT_TYPE getGlobalResult(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getGlobalResult();
    }

    public static void setExtendedResult(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedResult extendedResult) {
        yP_TCD_DC_Transaction.commonHandler.setExtendedResult(extendedResult);
    }

    public static ExtendedResult getExtendedResult(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getExtendedResult();
    }

    public static void setTransactionPrimaryKey(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionPrimaryKey(l);
    }

    public static long getTransactionPrimaryKey(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionPrimaryKey();
    }

    public static void setReferenceTransactionPrimaryKey(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceTransactionPrimaryKey(l);
    }

    public static long getReferenceTransactionPrimaryKey(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceTransactionPrimaryKey();
    }

    public static void setIDToken(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.accountHandler.setIDToken(l);
    }

    public static long getIDToken(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.accountHandler.getIDToken();
    }

    public static void setIsItANewToken(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl) {
        yP_TCD_DC_Transaction.accountHandler.setIsItANewToken(bl);
    }

    public static boolean isItANewToken(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.accountHandler.isItANewToken();
    }

    public static void setTransactionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionNumber(n);
    }

    public static int getTransactionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionNumber();
    }

    public static void setReferenceTransactionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceTransactionNumber(n);
    }

    public static int getReferenceTransactionNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceTransactionNumber();
    }

    public static void setMerchantTransactionIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setMerchantTransactionIdentifier(string);
    }

    public static String getMerchantTransactionIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionIdentifier();
    }

    public static void setReferenceMerchantTransactionIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceMerchantTransactionIdentifier(string);
    }

    public static String getReferenceMerchantTransactionIdentifier(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceMerchantTransactionIdentifier();
    }

    public static void setShiftNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setShiftNumber(n);
    }

    public static int getShiftNumber(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getShiftNumber();
    }

    public static void setTransactionType(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionType(transactionTypeEnumeration);
    }

    public static TransactionTypeEnumeration getTransactionType(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionType();
    }

    public static void setTransactionStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionStatusEnumeration transactionStatusEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionStatus(transactionStatusEnumeration);
    }

    public static TransactionStatusEnumeration getTransactionStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionStatus();
    }

    public static void setRealisationMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, RealisationModeEnumeration realisationModeEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setRealisationMode(realisationModeEnumeration);
    }

    public static RealisationModeEnumeration getRealisationMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getRealisationMode();
    }

    public static void setReferenceRealisationMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, RealisationModeEnumeration realisationModeEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceRealisationMode(realisationModeEnumeration);
    }

    public static RealisationModeEnumeration getReferenceRealisationMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceRealisationMode();
    }

    public static void setPaymentTechnology(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, EntryModeEnumeration entryModeEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setPaymentTechnology(entryModeEnumeration);
    }

    public static EntryModeEnumeration getPaymentTechnology(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology();
    }

    public static void setCardHolderAuthentication(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, CardHolderAuthenticationEnumeration cardHolderAuthenticationEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setCardHolderAuthentication(cardHolderAuthenticationEnumeration);
    }

    public static CardHolderAuthenticationEnumeration getCardHolderAuthentication(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCardHolderAuthentication();
    }

    public static void setCardHolderAuthenticationSystem(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, CardHolderAuthenticationSystemEnumeration cardHolderAuthenticationSystemEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setCardHolderAuthenticationSystem(cardHolderAuthenticationSystemEnumeration);
    }

    public static CardHolderAuthenticationSystemEnumeration getCardHolderAuthenticationSystem(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCardHolderAuthenticationSystem();
    }

    public static void setEntryModeCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Bitmap bitmap) {
        yP_TCD_DC_Transaction.commonHandler.setEntryModeCapability(bitmap);
    }

    public static Bitmap getEntryModeCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getEntryModeCapability();
    }

    public static void setCardCaptureCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setCardCaptureCapability(n);
    }

    public static int getCardCaptureCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCardCaptureCapability();
    }

    public static void setCardholderVerificationCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Bitmap bitmap) {
        yP_TCD_DC_Transaction.commonHandler.setCardholderVerificationCapability(bitmap);
    }

    public static Bitmap getCardholderVerificationCapability(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCardholderVerificationCapability();
    }

    public static void setTestTransactionIndicator(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTestTransactionIndicator(n);
    }

    public static int getTestTransactionIndicator(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTestTransactionIndicator();
    }

    public static void setDifferedFlag(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setDifferedFlag(n);
    }

    public static int getDifferedFlag(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getDifferedFlag();
    }

    public static void setTransactionUploadStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, UploadStatusEnumeration uploadStatusEnumeration) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionUploadStatus(uploadStatusEnumeration);
    }

    public static UploadStatusEnumeration getTransactionUploadStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionUploadStatus();
    }

    public static void setTransactionUploadAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionUploadAppliLocalTime(timestamp);
    }

    public static Timestamp getTransactionUploadAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionUploadAppliLocalTime();
    }

    public static void setTransactionSystemGMTTimeMS(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionSystemGMTTimeMS(l);
    }

    public static long getTransactionSystemGMTTimeMS(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionSystemGMTTimeMS();
    }

    public static void setTransactionAppliGMTTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionAppliGMTTime(timestamp);
    }

    public static Timestamp getTransactionAppliGMTTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionAppliGMTTime();
    }

    public static void setTransactionAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionAppliLocalTime(timestamp);
    }

    public static Timestamp getTransactionAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionAppliLocalTime();
    }

    public static void setReferenceTransactionAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceTransactionAppliLocalTime(timestamp);
    }

    public static Timestamp getReferenceTransactionAppliLocalTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceTransactionAppliLocalTime();
    }

    public static void setMerchantTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setMerchantTransactionTime(timestamp);
    }

    public static Timestamp getMerchantTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionTime();
    }

    public static void setReferenceMerchantTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceMerchantTransactionTime(timestamp);
    }

    public static Timestamp getReferenceMerchantTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceMerchantTransactionTime();
    }

    public static void setTerminalTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setTerminalTransactionTime(timestamp);
    }

    public static Timestamp getTerminalTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTerminalTransactionTime();
    }

    public static void setReferenceTerminalTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Timestamp timestamp) {
        yP_TCD_DC_Transaction.commonHandler.setReferenceTerminalTransactionTime(timestamp);
    }

    public static Timestamp getReferenceTerminalTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReferenceTerminalTransactionTime();
    }

    public static void setTransactionAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionAmount(l);
    }

    public static long getTransactionAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionAmount();
    }

    public static void setTransactionAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionAmountFraction(n);
    }

    public static int getTransactionAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionAmountFraction();
    }

    public static void setTransactionCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionCurrencyNumerical(n);
    }

    public static int getTransactionCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionCurrencyNumerical();
    }

    public static void setTransactionCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionCurrencyAlpha(string);
    }

    public static String getTransactionCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionCurrencyAlpha();
    }

    public static void setOtherAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setOtherAmount(l);
    }

    public static long getOtherAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getOtherAmount();
    }

    public static void setOtherAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setOtherAmountFraction(n);
    }

    public static int getOtherAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getOtherAmountFraction();
    }

    public static void setOtherCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setOtherCurrencyNumerical(n);
    }

    public static int getOtherCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getOtherCurrencyNumerical();
    }

    public static void setOtherCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setOtherCurrencyAlpha(string);
    }

    public static String getOtherCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getOtherCurrencyAlpha();
    }

    public static void setEstimatedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setEstimatedAmount(l);
    }

    public static long getEstimatedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getEstimatedAmount();
    }

    public static void setEstimatedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setEstimatedAmountFraction(n);
    }

    public static int getEstimatedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getEstimatedAmountFraction();
    }

    public static void setEstimatedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setEstimatedCurrencyNumerical(n);
    }

    public static int getEstimatedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getEstimatedCurrencyNumerical();
    }

    public static void setEstimatedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setEstimatedCurrencyAlpha(string);
    }

    public static String getEstimatedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getEstimatedCurrencyAlpha();
    }

    public static void setConvertedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setConvertedAmount(l);
    }

    public static long getConvertedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getConvertedAmount();
    }

    public static void setConvertedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setConvertedAmountFraction(n);
    }

    public static int getConvertedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getConvertedAmountFraction();
    }

    public static void setAuthorizedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setAuthorizedAmount(l);
    }

    public static long getAuthorizedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getAuthorizedAmount();
    }

    public static void setAuthorizedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setAuthorizedAmountFraction(n);
    }

    public static int getAuthorizedAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getAuthorizedAmountFraction();
    }

    public static void setAuthorizedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setAuthorizedCurrencyAlpha(string);
    }

    public static String getAuthorizedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getAuthorizedCurrencyAlpha();
    }

    public static void setAuthorizedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setAuthorizedCurrencyNumerical(n);
    }

    public static int getAuthorizedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getAuthorizedCurrencyNumerical();
    }

    public static void setConvertedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setConvertedCurrencyAlpha(string);
    }

    public static String getConvertedCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getConvertedCurrencyAlpha();
    }

    public static void setConvertedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setConvertedCurrencyNumerical(n);
    }

    public static int getConvertedCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getConvertedCurrencyNumerical();
    }

    public static void setReconciliationAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setReconciliationAmount(l);
    }

    public static long getReconciliationAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReconciliationAmount();
    }

    public static void setReconciliationAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setReconciliationAmountFraction(n);
    }

    public static int getReconciliationAmountFraction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReconciliationAmountFraction();
    }

    public static void setReconciliationCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setReconciliationCurrencyNumerical(n);
    }

    public static int getReconciliationCurrencyNumerical(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReconciliationCurrencyNumerical();
    }

    public static void setReconciliationCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setReconciliationCurrencyAlpha(string);
    }

    public static String getReconciliationCurrencyAlpha(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getReconciliationCurrencyAlpha();
    }

    public static void setCumulatedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, long l) {
        yP_TCD_DC_Transaction.commonHandler.setCumulatedAmount(l);
    }

    public static long getCumulatedAmount(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCumulatedAmount();
    }

    public void setDataContainerMerchant(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant) {
        this.dataContainerMerchant = yP_TCD_DCC_Merchant;
    }

    public YP_TCD_DCC_Merchant getDataContainerMerchant() {
        return this.dataContainerMerchant;
    }

    public YP_TCD_DCC_Brand getDataContainerBrand() {
        return this.dataContainerMerchant.getDataContainerBrand();
    }

    public static String getMerchantPrivatdeData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getMerchantPrivateData();
    }

    public static void setMerchantPrivatdeData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setMerchantPrivateData(string);
    }

    public static String getMerchantPOSAlias(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getMerchantPOSAlias();
    }

    public static void setMerchantPOSAlias(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setMerchantPOSAlias(string);
    }

    public int updateStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_TCD_DCC_Status yP_TCD_DCC_Status;
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = yP_TCD_DC_Transaction.getSubRequestType();
        if (sUB_REQUEST_TYPE != null) {
            switch (sUB_REQUEST_TYPE) {
                case OpenTransaction: 
                case TerminalRiskManagement: 
                case OpenTransactionAndTRM: 
                case Authorization: 
                case ProcessNFC: {
                    return 0;
                }
            }
        }
        if ((yP_TCD_DCC_Status = this.getDataContainerStatus()) == null) {
            return -1;
        }
        return yP_TCD_DCC_Status.updateContractStatus(this, yP_TCD_DC_Transaction);
    }

    public static void setCountryName(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        yP_TCD_DC_Transaction.commonHandler.setCountryName(string);
    }

    public static String getCountryName(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getCountryName();
    }

    public static void setTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionTime(n);
    }

    public static int getTransactionTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionTime();
    }

    public static void setTransactionTimeFull(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setTransactionTimeFull(n);
    }

    public static int getTransactionTimeFull(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getTransactionTimeFull();
    }

    public static void setAuthorisationTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, int n) {
        yP_TCD_DC_Transaction.commonHandler.setAuthorisationTime(n);
    }

    public static int getAuthorisationTime(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.getAuthorisationTime();
    }

    public long getIDContract() {
        return this.idContract;
    }

    public YP_TCD_DCC_Status getDataContainerStatus() {
        if (this.dataContainerStatus == null) {
            this.dataContainerStatus = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
        }
        return this.dataContainerStatus;
    }

    public static void setTestMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, Boolean bl) {
        yP_TCD_DC_Transaction.commonHandler.setTestMode(bl);
    }

    public static Boolean getTestMode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return yP_TCD_DC_Transaction.commonHandler.isTestMode();
    }

    public void persistSessionsIfNeeded(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            Set<YP_TCD_DCB_Interface_SessionPersister> set = this.getSessionPersisters();
            if (set == null || set.isEmpty()) {
                set = this.getDataContainerMerchant().getSessionPersisters();
            }
            if (set == null || set.isEmpty()) {
                set = this.getDataContainerMerchant().getDataContainerBrand().getSessionPersisters();
            }
            if (set != null) {
                for (YP_TCD_DCB_Interface_SessionPersister yP_TCD_DCB_Interface_SessionPersister : set) {
                    yP_TCD_DCB_Interface_SessionPersister.persistSession(this, yP_TCD_DC_Transaction);
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "persistSessionsIfNeeded() Exception ignored (for the moment) to keep the compatibility: ", exception);
        }
    }

    public YP_TCD_DCB_Interface_SMS getSMSPlugin() {
        Iterator<YP_TCD_DCB_Interface_SMS> iterator;
        Set<YP_TCD_DCB_Interface_SMS> set = this.getSMSPlugins();
        if (set == null || set.isEmpty()) {
            set = this.getDataContainerMerchant().getSMSPlugins();
        }
        if (set == null || set.isEmpty()) {
            set = this.getDataContainerMerchant().getDataContainerBrand().getSMSPlugins();
        }
        if (set == null || set.isEmpty()) {
            return null;
        }
        if (set.size() > 1) {
            this.logger(2, "getSMSPlugin() too many found");
        }
        if ((iterator = set.iterator()).hasNext()) {
            YP_TCD_DCB_Interface_SMS yP_TCD_DCB_Interface_SMS = iterator.next();
            return yP_TCD_DCB_Interface_SMS;
        }
        return null;
    }

    public int sendSMS(String string, String string2) {
        YP_TCD_DCB_Interface_SMS yP_TCD_DCB_Interface_SMS;
        block3: {
            try {
                yP_TCD_DCB_Interface_SMS = this.getSMSPlugin();
                if (yP_TCD_DCB_Interface_SMS != null) break block3;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "sendSMS() ", exception);
                return -1;
            }
        }
        int n = yP_TCD_DCB_Interface_SMS.sendSMS(this, string, string2);
        return n;
    }

    @Override
    public List<Property> getPropertiesParameters() {
        List<Property> list = super.getPropertiesParameters();
        YP_TCD_DCB_Interface_SMS yP_TCD_DCB_Interface_SMS = this.getSMSPlugin();
        if (yP_TCD_DCB_Interface_SMS != null) {
            if (list == null) {
                list = new ArrayList<Property>();
            }
            Property property = new Property();
            property.setName("SMSCapable");
            property.setValue(DUPLICATES_CHECK_MODE_EIGHT_MINUTES);
            list.add(property);
        }
        return list;
    }

    public boolean isTrsTypeAllowed(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (this.trsTypeAllowed == null) {
            return true;
        }
        if (yP_TCD_DC_Transaction == null) {
            return true;
        }
        switch (yP_TCD_DC_Transaction.getRequestType()) {
            case ReprintLastTrs: 
            case System: 
            case Login: 
            case Logout: 
            case GetData: 
            case SetData: 
            case CreateData: 
            case Shutdown: {
                this.logger(2, "isTrsTypeAllowed() should not be here ??? : " + (Object)((Object)yP_TCD_DC_Transaction.getRequestType()));
                break;
            }
            case Reprint: 
            case ReprintCustomer: 
            case ReprintMerchant: 
            case Reconciliation: 
            case RemoteParameterization: 
            case Report: 
            case Transparent: {
                return true;
            }
            default: {
                this.logger(2, "isTrsTypeAllowed() unknown request : " + (Object)((Object)yP_TCD_DC_Transaction.getRequestType()));
            }
        }
        return true;
    }

    public int performExtraActionsDuringLogin(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return 0;
    }

    public static void checkDuplicateTransaction(YP_Application yP_Application, List<YP_Row> list, YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        String string = yP_Application.getDataContainerBusiness().getDataContainerMerchant().getDuplicatesCheckMode();
        if (string != null && string.contentEquals(DUPLICATES_CHECK_MODE_EIGHT_MINUTES)) {
            long l = YP_TCD_DCC_Business.getTransactionSystemGMTTimeMS(yP_Application.getDataContainerTransaction());
            long l2 = 480000L;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
            yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.EQUAL, YP_TCD_DCC_Business.getTransactionAmount(yP_Application.getDataContainerTransaction()));
            yP_ComplexGabarit.set("transactionCurrencyNumerical", YP_ComplexGabarit.OPERATOR.EQUAL, YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_Application.getDataContainerTransaction()));
            yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.GREATER, l - l2);
            List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
            if (!list2.isEmpty()) {
                yP_Application.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.DUPLICATE_TRS);
            }
        }
    }

    public boolean isMposApplication() {
        try {
            if (this.getApplicationPlugin().getApplicationRow().getFieldStringValueByName("applicationName").toUpperCase().contains("MPOS")) {
                return true;
            }
        }
        catch (Exception exception) {
            this.logger(2, "isMposApplication() ", exception);
        }
        return false;
    }
}

