/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Account;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Context;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.CardHolderAuthenticationEnumeration;
import org.yp.utils.enums.CardHolderAuthenticationSystemEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.RealisationModeEnumeration;
import org.yp.utils.enums.TerminalOutputCapabilityEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;

public class CommonHandler
implements HandlerInterface {
    YP_TCD_DC_Transaction dataContainerTransaction;
    private YP_TCD_PosProtocol.RESULT_TYPE t_GlobalResult = YP_TCD_PosProtocol.RESULT_TYPE.Error;
    private ExtendedResult t_ExtendedResult = new ExtendedResult(0);
    private String t_ProcessorIdentifier = "";
    private long t_TransactionPrimaryKey = 0L;
    private long v_referenceTransactionPrimaryKey = 0L;
    private int t_TransactionNumber = 0;
    private int t_ReferenceTransactionNumber = 0;
    private String t_MerchantTransactionIdentifier = "";
    private String t_ReferenceMerchantTransactionIdentifier = "";
    private String t_MerchantPrivateData = "";
    private String t_merchantPOSAlias = "";
    private int t_ShiftNumber = 0;
    private int t_SessionNumber = -1;
    private TransactionTypeEnumeration t_TransactionType = TransactionTypeEnumeration.UNKNOWN;
    private TransactionStatusEnumeration t_TransactionStatus = TransactionStatusEnumeration.UNKNOWN;
    private RealisationModeEnumeration t_RealisationMode = RealisationModeEnumeration.Unknown;
    private RealisationModeEnumeration t_ReferenceRealisationMode = RealisationModeEnumeration.Unknown;
    private EntryModeEnumeration t_PaymentTechnology = EntryModeEnumeration.UNKNOWN;
    private CardHolderAuthenticationEnumeration t_CardHolderAuthentication = CardHolderAuthenticationEnumeration.UNKNOWN;
    private CardHolderAuthenticationSystemEnumeration t_CardHolderAuthenticationSystem = CardHolderAuthenticationSystemEnumeration.UNKNOWN;
    private Bitmap t_entryModeCapability = new Bitmap();
    private Bitmap t_cardholderVerificationCapability = new Bitmap();
    private int t_cardCaptureCapability = 0;
    private TerminalOutputCapabilityEnumeration t_terminalOutputCapability;
    private int t_pinInputLengthCapability = 0;
    private int t_TestTransactionIndicator = 0;
    private int t_DifferedFlag = 0;
    private long t_TransactionSystemGMTTimeMS = 0L;
    private Timestamp t_TransactionAppliGMTTime = new Timestamp(0L);
    private Timestamp t_TransactionAppliLocalTime = new Timestamp(0L);
    private Timestamp t_ReferenceTransactionAppliLocalTime = new Timestamp(0L);
    private Timestamp t_MerchantTransactionTime = new Timestamp(0L);
    private Timestamp t_ReferenceMerchantTransactionTime = new Timestamp(0L);
    private Timestamp t_TerminalTransactionTime = new Timestamp(0L);
    private Timestamp t_ReferenceTerminalTransactionTime = new Timestamp(0L);
    private UploadStatusEnumeration t_TransactionUploadStatus = UploadStatusEnumeration.UNKNOWN;
    private Timestamp t_TransactionUploadAppliLocalTime = new Timestamp(0L);
    private long t_TransactionAmount = 0L;
    private int t_TransactionCurrencyNumerical = 0;
    private String t_TransactionCurrencyAlpha = "";
    private int t_TransactionAmountFraction = 0;
    private long t_OtherAmount = 0L;
    private int t_OtherCurrencyNumerical = 0;
    private String t_OtherCurrencyAlpha = "";
    private int t_OtherAmountFraction = 0;
    private long t_EstimatedAmount = 0L;
    private int t_EstimatedCurrencyNumerical = 0;
    private String t_EstimatedCurrencyAlpha = "";
    private int t_EstimatedAmountFraction = 0;
    private long t_ConvertedAmount = 0L;
    private int t_ConvertedCurrencyNumerical = 0;
    private String t_ConvertedCurrencyAlpha = "";
    private int t_ConvertedAmountFraction = 0;
    private long t_AuthorizedAmount = 0L;
    private int t_AuthorizedCurrencyNumerical = 0;
    private String t_AuthorizedCurrencyAlpha = "";
    private int t_AuthorizedAmountFraction = 0;
    private long t_ReconciliationAmount = 0L;
    private int t_ReconciliationCurrencyNumerical = 0;
    private String t_ReconciliationCurrencyAlpha = "";
    private int t_ReconciliationAmountFraction = 0;
    private long t_CumulatedAmount = 0L;
    private String v_RequestAppTags = "";
    private String v_ResponseAppTags = "";
    private String v_RequestEMVTags = "";
    private String v_ResponseEMVTags = "";
    private String t_CountryName = "";
    private int t_TransactionTime = 0;
    private int t_TransactionTimeFull = 0;
    private int t_AuthorisationTime = 0;
    private Boolean t_TestMode;
    private String v_printFormat = "";
    private long v_ReferenceTransactionSystemGMTTimeMS = 0L;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        return 1;
    }

    @Override
    public int clear() {
        return 1;
    }

    public CommonHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public void setGlobalResult(YP_TCD_PosProtocol.RESULT_TYPE rESULT_TYPE) {
        this.t_GlobalResult = rESULT_TYPE;
    }

    public YP_TCD_PosProtocol.RESULT_TYPE getGlobalResult() {
        return this.t_GlobalResult;
    }

    public void setExtendedResult(ExtendedResult extendedResult) {
        this.t_ExtendedResult = extendedResult;
    }

    public ExtendedResult getExtendedResult() {
        return this.t_ExtendedResult;
    }

    public void setProcessorIdentifier(String string) {
        this.t_ProcessorIdentifier = string;
    }

    public String getProcessorIdentifier() {
        return this.t_ProcessorIdentifier;
    }

    public void setTransactionPrimaryKey(long l) {
        this.t_TransactionPrimaryKey = l;
    }

    public long getTransactionPrimaryKey() {
        return this.t_TransactionPrimaryKey;
    }

    public void setReferenceTransactionPrimaryKey(long l) {
        this.v_referenceTransactionPrimaryKey = l;
    }

    public long getReferenceTransactionPrimaryKey() {
        return this.v_referenceTransactionPrimaryKey;
    }

    public void setTransactionNumber(int n) {
        this.t_TransactionNumber = n;
    }

    public int getTransactionNumber() {
        return this.t_TransactionNumber;
    }

    public void setReferenceTransactionNumber(int n) {
        this.t_ReferenceTransactionNumber = n;
    }

    public int getReferenceTransactionNumber() {
        return this.t_ReferenceTransactionNumber;
    }

    public void setMerchantTransactionIdentifier(String string) {
        this.t_MerchantTransactionIdentifier = string;
    }

    public String getMerchantTransactionIdentifier() {
        return this.t_MerchantTransactionIdentifier;
    }

    public void setReferenceMerchantTransactionIdentifier(String string) {
        this.t_ReferenceMerchantTransactionIdentifier = string;
    }

    public String getReferenceMerchantTransactionIdentifier() {
        return this.t_ReferenceMerchantTransactionIdentifier;
    }

    public void setMerchantPrivateData(String string) {
        this.t_MerchantPrivateData = string;
    }

    public String getMerchantPrivateData() {
        return this.t_MerchantPrivateData;
    }

    public void setMerchantPOSAlias(String string) {
        this.t_merchantPOSAlias = string;
    }

    public String getMerchantPOSAlias() {
        return this.t_merchantPOSAlias;
    }

    public void setShiftNumber(int n) {
        this.t_ShiftNumber = n;
    }

    public int getShiftNumber() {
        return this.t_ShiftNumber;
    }

    public void setSessionNumber(int n) {
        this.t_SessionNumber = n;
    }

    public int getSessionNumber() {
        return this.t_SessionNumber;
    }

    public void setTransactionType(TransactionTypeEnumeration transactionTypeEnumeration) {
        this.t_TransactionType = transactionTypeEnumeration;
    }

    public TransactionTypeEnumeration getTransactionType() {
        return this.t_TransactionType;
    }

    public void setTransactionStatus(TransactionStatusEnumeration transactionStatusEnumeration) {
        this.t_TransactionStatus = transactionStatusEnumeration;
    }

    public TransactionStatusEnumeration getTransactionStatus() {
        return this.t_TransactionStatus;
    }

    public void setRealisationMode(RealisationModeEnumeration realisationModeEnumeration) {
        this.t_RealisationMode = realisationModeEnumeration;
    }

    public RealisationModeEnumeration getRealisationMode() {
        return this.t_RealisationMode;
    }

    public void setReferenceRealisationMode(RealisationModeEnumeration realisationModeEnumeration) {
        this.t_ReferenceRealisationMode = realisationModeEnumeration;
    }

    public RealisationModeEnumeration getReferenceRealisationMode() {
        return this.t_ReferenceRealisationMode;
    }

    public void setPaymentTechnology(EntryModeEnumeration entryModeEnumeration) {
        this.t_PaymentTechnology = entryModeEnumeration;
    }

    public EntryModeEnumeration getPaymentTechnology() {
        return this.t_PaymentTechnology;
    }

    public void setCardHolderAuthentication(CardHolderAuthenticationEnumeration cardHolderAuthenticationEnumeration) {
        this.t_CardHolderAuthentication = cardHolderAuthenticationEnumeration;
    }

    public CardHolderAuthenticationEnumeration getCardHolderAuthentication() {
        return this.t_CardHolderAuthentication;
    }

    public void setCardHolderAuthenticationSystem(CardHolderAuthenticationSystemEnumeration cardHolderAuthenticationSystemEnumeration) {
        this.t_CardHolderAuthenticationSystem = cardHolderAuthenticationSystemEnumeration;
    }

    public CardHolderAuthenticationSystemEnumeration getCardHolderAuthenticationSystem() {
        return this.t_CardHolderAuthenticationSystem;
    }

    public void setTestTransactionIndicator(int n) {
        this.t_TestTransactionIndicator = n;
    }

    public int getTestTransactionIndicator() {
        return this.t_TestTransactionIndicator;
    }

    public void setDifferedFlag(int n) {
        this.t_DifferedFlag = n;
    }

    public int getDifferedFlag() {
        return this.t_DifferedFlag;
    }

    public void setTransactionUploadStatus(UploadStatusEnumeration uploadStatusEnumeration) {
        this.t_TransactionUploadStatus = uploadStatusEnumeration;
    }

    public UploadStatusEnumeration getTransactionUploadStatus() {
        return this.t_TransactionUploadStatus;
    }

    public void setTransactionUploadAppliLocalTime(Timestamp timestamp) {
        this.t_TransactionUploadAppliLocalTime = timestamp;
    }

    public Timestamp getTransactionUploadAppliLocalTime() {
        return this.t_TransactionUploadAppliLocalTime;
    }

    public void setTransactionSystemGMTTimeMS(long l) {
        this.t_TransactionSystemGMTTimeMS = l;
    }

    public long getTransactionSystemGMTTimeMS() {
        return this.t_TransactionSystemGMTTimeMS;
    }

    public void setTransactionAppliGMTTime(Timestamp timestamp) {
        this.t_TransactionAppliGMTTime = timestamp;
    }

    public Timestamp getTransactionAppliGMTTime() {
        return this.t_TransactionAppliGMTTime;
    }

    public void setTransactionAppliLocalTime(Timestamp timestamp) {
        this.t_TransactionAppliLocalTime = timestamp;
    }

    public Timestamp getTransactionAppliLocalTime() {
        return this.t_TransactionAppliLocalTime;
    }

    public void setReferenceTransactionAppliLocalTime(Timestamp timestamp) {
        this.t_ReferenceTransactionAppliLocalTime = timestamp;
    }

    public Timestamp getReferenceTransactionAppliLocalTime() {
        return this.t_ReferenceTransactionAppliLocalTime;
    }

    public void setMerchantTransactionTime(Timestamp timestamp) {
        this.t_MerchantTransactionTime = timestamp;
    }

    public Timestamp getMerchantTransactionTime() {
        return this.t_MerchantTransactionTime;
    }

    public void setReferenceMerchantTransactionTime(Timestamp timestamp) {
        this.t_ReferenceMerchantTransactionTime = timestamp;
    }

    public Timestamp getReferenceMerchantTransactionTime() {
        return this.t_ReferenceMerchantTransactionTime;
    }

    public void setTerminalTransactionTime(Timestamp timestamp) {
        this.t_TerminalTransactionTime = timestamp;
    }

    public Timestamp getTerminalTransactionTime() {
        return this.t_TerminalTransactionTime;
    }

    public void setReferenceTerminalTransactionTime(Timestamp timestamp) {
        this.t_ReferenceTerminalTransactionTime = timestamp;
    }

    public Timestamp getReferenceTerminalTransactionTime() {
        return this.t_ReferenceTerminalTransactionTime;
    }

    public void setTransactionAmount(long l) {
        this.t_TransactionAmount = l;
    }

    public long getTransactionAmount() {
        return this.t_TransactionAmount;
    }

    public void setTransactionAmountFraction(int n) {
        this.t_TransactionAmountFraction = n;
    }

    public int getTransactionAmountFraction() {
        return this.t_TransactionAmountFraction;
    }

    public void setTransactionCurrencyNumerical(int n) {
        this.t_TransactionCurrencyNumerical = n;
    }

    public int getTransactionCurrencyNumerical() {
        return this.t_TransactionCurrencyNumerical;
    }

    public void setTransactionCurrencyAlpha(String string) {
        this.t_TransactionCurrencyAlpha = string;
    }

    public String getTransactionCurrencyAlpha() {
        return this.t_TransactionCurrencyAlpha;
    }

    public void setOtherAmount(long l) {
        this.t_OtherAmount = l;
    }

    public long getOtherAmount() {
        return this.t_OtherAmount;
    }

    public void setOtherAmountFraction(int n) {
        this.t_OtherAmountFraction = n;
    }

    public int getOtherAmountFraction() {
        return this.t_OtherAmountFraction;
    }

    public void setOtherCurrencyNumerical(int n) {
        this.t_OtherCurrencyNumerical = n;
    }

    public int getOtherCurrencyNumerical() {
        return this.t_OtherCurrencyNumerical;
    }

    public void setOtherCurrencyAlpha(String string) {
        this.t_OtherCurrencyAlpha = string;
    }

    public String getOtherCurrencyAlpha() {
        return this.t_OtherCurrencyAlpha;
    }

    public void setEstimatedAmount(long l) {
        this.t_EstimatedAmount = l;
    }

    public long getEstimatedAmount() {
        return this.t_EstimatedAmount;
    }

    public void setEstimatedAmountFraction(int n) {
        this.t_EstimatedAmountFraction = n;
    }

    public int getEstimatedAmountFraction() {
        return this.t_EstimatedAmountFraction;
    }

    public void setEstimatedCurrencyNumerical(int n) {
        this.t_EstimatedCurrencyNumerical = n;
    }

    public int getEstimatedCurrencyNumerical() {
        return this.t_EstimatedCurrencyNumerical;
    }

    public void setEstimatedCurrencyAlpha(String string) {
        this.t_EstimatedCurrencyAlpha = string;
    }

    public String getEstimatedCurrencyAlpha() {
        return this.t_EstimatedCurrencyAlpha;
    }

    public void setConvertedAmount(long l) {
        this.t_ConvertedAmount = l;
    }

    public long getConvertedAmount() {
        return this.t_ConvertedAmount;
    }

    public void setConvertedAmountFraction(int n) {
        this.t_ConvertedAmountFraction = n;
    }

    public int getConvertedAmountFraction() {
        return this.t_ConvertedAmountFraction;
    }

    public void setAuthorizedAmount(long l) {
        this.t_AuthorizedAmount = l;
    }

    public long getAuthorizedAmount() {
        return this.t_AuthorizedAmount;
    }

    public void setAuthorizedAmountFraction(int n) {
        this.t_AuthorizedAmountFraction = n;
    }

    public int getAuthorizedAmountFraction() {
        return this.t_AuthorizedAmountFraction;
    }

    public void setAuthorizedCurrencyAlpha(String string) {
        this.t_AuthorizedCurrencyAlpha = string;
    }

    public String getAuthorizedCurrencyAlpha() {
        return this.t_AuthorizedCurrencyAlpha;
    }

    public void setAuthorizedCurrencyNumerical(int n) {
        this.t_AuthorizedCurrencyNumerical = n;
    }

    public int getAuthorizedCurrencyNumerical() {
        return this.t_AuthorizedCurrencyNumerical;
    }

    public void setConvertedCurrencyAlpha(String string) {
        this.t_ConvertedCurrencyAlpha = string;
    }

    public String getConvertedCurrencyAlpha() {
        return this.t_ConvertedCurrencyAlpha;
    }

    public void setConvertedCurrencyNumerical(int n) {
        this.t_ConvertedCurrencyNumerical = n;
    }

    public int getConvertedCurrencyNumerical() {
        return this.t_ConvertedCurrencyNumerical;
    }

    public void setCumulatedAmount(long l) {
        this.t_CumulatedAmount = l;
    }

    public void setReconciliationAmount(long l) {
        this.t_ReconciliationAmount = l;
    }

    public long getReconciliationAmount() {
        return this.t_ReconciliationAmount;
    }

    public void setReconciliationAmountFraction(int n) {
        this.t_ReconciliationAmountFraction = n;
    }

    public int getReconciliationAmountFraction() {
        return this.t_ReconciliationAmountFraction;
    }

    public void setReconciliationCurrencyNumerical(int n) {
        this.t_ReconciliationCurrencyNumerical = n;
    }

    public int getReconciliationCurrencyNumerical() {
        return this.t_ReconciliationCurrencyNumerical;
    }

    public void setReconciliationCurrencyAlpha(String string) {
        this.t_ReconciliationCurrencyAlpha = string;
    }

    public String getReconciliationCurrencyAlpha() {
        return this.t_ReconciliationCurrencyAlpha;
    }

    public long getCumulatedAmount() {
        return this.t_CumulatedAmount;
    }

    public void setTransactionTime(int n) {
        this.t_TransactionTime = n;
    }

    public int getTransactionTime() {
        return this.t_TransactionTime;
    }

    public void setTransactionTimeFull(int n) {
        this.t_TransactionTimeFull = n;
    }

    public int getTransactionTimeFull() {
        return this.t_TransactionTimeFull;
    }

    public int getAuthorisationTime() {
        return this.t_AuthorisationTime;
    }

    public void setAuthorisationTime(int n) {
        this.t_AuthorisationTime = n;
    }

    public void setCountryName(String string) {
        this.t_CountryName = string;
    }

    public String getCountryName() {
        return this.t_CountryName;
    }

    public String getRequestAppTags() {
        return this.v_RequestAppTags;
    }

    public void setRequestAppTags(String string) {
        this.v_RequestAppTags = string;
    }

    public String getResponseAppTags() {
        return this.v_ResponseAppTags;
    }

    public void setResponseAppTags(String string) {
        this.v_ResponseAppTags = string;
    }

    public String getRequestEMVTags() {
        return this.v_RequestEMVTags;
    }

    public void setRequestEMVTags(String string) {
        this.v_RequestEMVTags = string;
    }

    public String getResponseEMVTags() {
        return this.v_ResponseEMVTags;
    }

    public void setResponseEMVTags(String string) {
        this.v_ResponseEMVTags = string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int readRequest() {
        try {
            String string;
            Calendar calendar;
            String string2;
            Calendar calendar2;
            String string3;
            Calendar calendar3;
            String string4;
            Calendar calendar4;
            String string5;
            String string6;
            int n;
            int n2;
            String string7;
            long l;
            int n3;
            int n4;
            Calendar calendar5;
            YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
            if (!(yP_TCD_PosProtocol instanceof YP_PROT_Context)) {
                if (this.dataContainerTransaction.getLogLevel() >= 5) {
                    this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with context");
                }
                return 0;
            }
            int n5 = yP_TCD_PosProtocol.getDifferedFlag();
            if (n5 >= 0) {
                this.setDifferedFlag(n5);
            }
            if ((calendar5 = yP_TCD_PosProtocol.getUploadTimeStamp()) != null) {
                this.setTransactionUploadAppliLocalTime(new Timestamp(calendar5.getTimeInMillis()));
            }
            if ((n4 = yP_TCD_PosProtocol.getShiftNumber()) > 0) {
                this.setShiftNumber(n4);
            }
            if ((n3 = yP_TCD_PosProtocol.getSessionNumber()) > 0) {
                this.setSessionNumber(n3);
            }
            if ((l = yP_TCD_PosProtocol.getTransactionAmount()) >= 0L) {
                this.setTransactionAmount(l);
            }
            if ((string7 = yP_TCD_PosProtocol.getTransactionCurrencyAlpha()) != null && !string7.isEmpty()) {
                this.setTransactionCurrencyAlpha(string7);
            }
            if ((n2 = yP_TCD_PosProtocol.getTransactionCurrencyNumerical()) >= 0) {
                this.setTransactionCurrencyNumerical(n2);
            }
            if ((n = yP_TCD_PosProtocol.getTransactionCurrencyFraction()) >= 0) {
                this.setTransactionAmountFraction(n);
            }
            if ((string6 = yP_TCD_PosProtocol.getTransactionAmountAlpha()) != null && !string6.isEmpty()) {
                string6 = string6.replace(',', '.').replace(" ", "").trim();
                boolean bl = false;
                int n6 = 0;
                int n7 = 0;
                while (true) {
                    if (n7 >= string6.length()) {
                        string6 = string6.replace(".", "");
                        n = this.getTransactionAmountFraction();
                        if (n > 0 && n != n6 && this.dataContainerTransaction.getLogLevel() >= 3) {
                            this.dataContainerTransaction.logger(3, "readRequest() not same amount fraction :" + n + " vs " + n6);
                        }
                        this.setTransactionAmountFraction(n6);
                        long l2 = Long.parseLong(string6);
                        if (l > 0L && l != l2 && this.dataContainerTransaction.getLogLevel() >= 3) {
                            this.dataContainerTransaction.logger(3, "readRequest() not same amount  :" + l + " vs " + l2);
                        }
                        this.setTransactionAmount(l2);
                        break;
                    }
                    switch (string6.charAt(n7)) {
                        case '0': 
                        case '1': 
                        case '2': 
                        case '3': 
                        case '4': 
                        case '5': 
                        case '6': 
                        case '7': 
                        case '8': 
                        case '9': {
                            if (!bl) break;
                            ++n6;
                            break;
                        }
                        case '.': {
                            if (bl) {
                                if (this.dataContainerTransaction.getLogLevel() >= 2) {
                                    this.dataContainerTransaction.logger(2, "readRequest() bad amount format :" + string6);
                                }
                                return -1;
                            }
                            bl = true;
                            break;
                        }
                        default: {
                            if (this.dataContainerTransaction.getLogLevel() >= 2) {
                                this.dataContainerTransaction.logger(2, "readRequest() bad amount format :" + string6);
                            }
                            return -1;
                        }
                    }
                    ++n7;
                }
            }
            if ((string5 = yP_TCD_PosProtocol.getMerchantTransactionIdentifier()) != null && !string5.isEmpty()) {
                this.setMerchantTransactionIdentifier(string5);
            }
            if ((calendar4 = yP_TCD_PosProtocol.getMerchantTransactionTime()) != null) {
                this.setMerchantTransactionTime(new Timestamp(calendar4.getTimeInMillis()));
            }
            if ((string4 = yP_TCD_PosProtocol.getTransactionNumber()) != null && !string4.isEmpty()) {
                this.setTransactionNumber(Integer.parseInt(string4));
            }
            if ((calendar3 = yP_TCD_PosProtocol.getTransactionAppliLocalTime()) != null) {
                this.setTransactionAppliLocalTime(new Timestamp(calendar3.getTimeInMillis()));
            }
            if ((string3 = yP_TCD_PosProtocol.getReferenceMerchantTransactionIdentifier()) != null && !string3.isEmpty()) {
                this.setReferenceMerchantTransactionIdentifier(string3);
            }
            if ((calendar2 = yP_TCD_PosProtocol.getReferenceMerchantTransactionTime()) != null) {
                this.setReferenceMerchantTransactionTime(new Timestamp(calendar2.getTimeInMillis()));
            }
            if ((string2 = yP_TCD_PosProtocol.getReferenceTransactionNumber()) != null && !string2.isEmpty()) {
                this.setReferenceTransactionNumber(Integer.parseInt(string2));
            }
            if ((calendar = yP_TCD_PosProtocol.getReferenceTransactionAppliLocalTime()) != null) {
                this.setReferenceTransactionAppliLocalTime(new Timestamp(calendar.getTimeInMillis()));
            }
            this.v_printFormat = yP_TCD_PosProtocol.getPrintFormat();
            String string8 = yP_TCD_PosProtocol.getAppTags();
            if (string8 != null) {
                this.setRequestAppTags(string8);
            }
            if ((string = yP_TCD_PosProtocol.getEMVTags()) != null) {
                this.setRequestEMVTags(string);
            }
            Boolean bl = yP_TCD_PosProtocol.getTestMode();
            this.setTestMode(bl);
            return 0;
        }
        catch (Exception exception) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(2, "readRequest()  " + exception);
            }
            return -1;
        }
    }

    @Override
    public int prepareResponse() {
        String string;
        String string2;
        String string3;
        Timestamp timestamp;
        String string4;
        Timestamp timestamp2;
        String string5;
        Timestamp timestamp3;
        String string6;
        Timestamp timestamp4;
        String string7;
        String string8;
        int n;
        int n2;
        Timestamp timestamp5;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with account");
            }
            return 0;
        }
        int n3 = this.getDifferedFlag();
        if (n3 >= 0) {
            yP_TCD_PosProtocol.setDifferedFlag(n3);
        }
        if ((timestamp5 = this.getTransactionUploadAppliLocalTime()) != null) {
            yP_TCD_PosProtocol.setUploadTimeStamp(UtilsYP.getCalendar(timestamp5));
        }
        if ((n2 = this.getShiftNumber()) > 0) {
            yP_TCD_PosProtocol.setShiftNumber(n2);
        }
        if ((n = this.getSessionNumber()) > 0) {
            yP_TCD_PosProtocol.setSessionNumber(n);
        }
        if ((string8 = this.getTransactionCurrencyAlpha()) != null && !string8.isEmpty()) {
            long l;
            yP_TCD_PosProtocol.setTransactionCurrencyAlpha(string8);
            int n4 = this.getTransactionAmountFraction();
            if (string8 != null && n4 >= 0) {
                yP_TCD_PosProtocol.setTransactionCurrencyFraction(n4);
            }
            if ((l = this.getTransactionAmount()) != 0L) {
                yP_TCD_PosProtocol.setTransactionAmount(l);
                yP_TCD_PosProtocol.setTransactionAmountAlpha(UtilsYP.formatAmount(l, this.getTransactionAmountFraction(), Locale.FRANCE));
            }
        }
        if ((string7 = this.getMerchantTransactionIdentifier()) != null && !string7.isEmpty()) {
            yP_TCD_PosProtocol.setMerchantTransactionIdentifier(string7);
        }
        if ((timestamp4 = this.getMerchantTransactionTime()).getTime() != 0L) {
            yP_TCD_PosProtocol.setMerchantTransactionTime(UtilsYP.getCalendar(timestamp4));
        }
        if ((string6 = Integer.toString(this.getTransactionNumber())) != null && !string6.isEmpty() && !string6.contentEquals("0")) {
            yP_TCD_PosProtocol.setTransactionNumber(string6);
        }
        if ((timestamp3 = this.getTransactionAppliLocalTime()).getTime() != 0L) {
            yP_TCD_PosProtocol.setTransactionAppliLocalTime(UtilsYP.getCalendar(timestamp3));
        }
        if ((string5 = this.getReferenceMerchantTransactionIdentifier()) != null && !string5.isEmpty()) {
            yP_TCD_PosProtocol.setReferenceMerchantTransactionIdentifier(string5);
        }
        if ((timestamp2 = this.getReferenceMerchantTransactionTime()).getTime() != 0L) {
            yP_TCD_PosProtocol.setReferenceMerchantTransactionTime(UtilsYP.getCalendar(timestamp2));
        }
        if ((string4 = Integer.toString(this.getReferenceTransactionNumber())) != null && !string4.isEmpty() && !string4.contentEquals("0")) {
            yP_TCD_PosProtocol.setReferenceTransactionNumber(string4);
        }
        if ((timestamp = this.getReferenceTransactionAppliLocalTime()).getTime() != 0L) {
            yP_TCD_PosProtocol.setReferenceTransactionAppliLocalTime(UtilsYP.getCalendar(timestamp));
        }
        if ((string3 = this.dataContainerTransaction.getTicket()) != null && !string3.isEmpty()) {
            yP_TCD_PosProtocol.setTicket(string3);
        }
        if (this.dataContainerTransaction.xmlResponse.length() > 0) {
            yP_TCD_PosProtocol.setXMLResponse(this.dataContainerTransaction.xmlResponse.toString());
        }
        if ((string2 = this.getResponseAppTags()) != null && !string2.isEmpty()) {
            yP_TCD_PosProtocol.setAppTags(string2);
        }
        if ((string = this.getResponseEMVTags()) != null && !string.isEmpty()) {
            yP_TCD_PosProtocol.setEMVTags(string);
        }
        return 1;
    }

    @Override
    public int load(YP_Row yP_Row) {
        return 0;
    }

    @Override
    public int persist() {
        return 0;
    }

    public Bitmap getEntryModeCapability() {
        return this.t_entryModeCapability;
    }

    public void setEntryModeCapability(Bitmap bitmap) {
        this.t_entryModeCapability = bitmap;
    }

    public Bitmap getCardholderVerificationCapability() {
        return this.t_cardholderVerificationCapability;
    }

    public void setCardholderVerificationCapability(Bitmap bitmap) {
        this.t_cardholderVerificationCapability = bitmap;
    }

    public int getCardCaptureCapability() {
        return this.t_cardCaptureCapability;
    }

    public void setCardCaptureCapability(int n) {
        this.t_cardCaptureCapability = n;
    }

    public TerminalOutputCapabilityEnumeration getTerminalOutputCapability() {
        return this.t_terminalOutputCapability;
    }

    public void setTerminalOutputCapability(TerminalOutputCapabilityEnumeration terminalOutputCapabilityEnumeration) {
        this.t_terminalOutputCapability = terminalOutputCapabilityEnumeration;
    }

    public int getPinInputLengthCapability() {
        return this.t_pinInputLengthCapability;
    }

    public void setPinInputLengthCapability(int n) {
        this.t_pinInputLengthCapability = n;
    }

    public Boolean isTestMode() {
        return this.t_TestMode;
    }

    public void setTestMode(Boolean bl) {
        this.t_TestMode = bl;
    }

    public String getPrintFormat() {
        return this.v_printFormat;
    }

    public void setPrintFormat(String string) {
        this.v_printFormat = string;
    }

    public long getReferenceTransactionSystemGMTTimeMS() {
        return this.v_ReferenceTransactionSystemGMTTimeMS;
    }

    public void setReferenceTransactionSystemGMTTimeMS(long l) {
        this.v_ReferenceTransactionSystemGMTTimeMS = l;
    }
}

