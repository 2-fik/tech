/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_Row;

@TableExtensionName(masterExtension="_foo", slaveExtension="_bar")
public class DAO_Test33
extends YP_Row {
    @PrimaryKey
    public long idTest33 = 0L;
}

