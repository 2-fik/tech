/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.YP_EFT_Application;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public final class YP_TCD_DC_EFT_Transaction
extends YP_TCD_DC_Transaction {
    public YP_TCD_DC_EFT_Transaction(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "DataContainerEFTTransaction";
    }

    @Override
    public final int initTransaction(YP_Application yP_Application, boolean bl) {
        super.initTransaction(yP_Application, bl);
        if (yP_Application instanceof YP_EFT_Application) {
            YP_EFT_Application yP_EFT_Application = (YP_EFT_Application)yP_Application;
            if (bl) {
                int n;
                int n2 = this.commonHandler.getTransactionCurrencyNumerical();
                String string = this.commonHandler.getTransactionCurrencyAlpha();
                if (n2 <= 0 && string != null && !string.isEmpty()) {
                    n2 = yP_EFT_Application.getDataContainerBusiness().currencyInterface.getCurrencyNumericalCode(string);
                    if (n2 <= 0) {
                        this.logger(2, "initTransaction() : unknown currency numerical code: " + n2 + " alphabetical code " + string);
                        return -1;
                    }
                    this.commonHandler.setTransactionCurrencyNumerical(n2);
                } else if (n2 > 0 && (string == null || string.isEmpty())) {
                    string = yP_EFT_Application.getDataContainerBusiness().currencyInterface.getCurrencyAlphabeticalCode(n2);
                    this.commonHandler.setTransactionCurrencyAlpha(string);
                } else if (n2 > 0 && string != null && !string.isEmpty() && (n = yP_EFT_Application.getDataContainerBusiness().currencyInterface.getCurrencyNumericalCode(string)) != n2) {
                    if (n == -1) {
                        this.logger(2, "initTransaction() : currency not managed by server!!!");
                        return -1;
                    }
                    this.logger(2, "initTransaction() : differents currency values" + n + " vs " + string);
                    this.commonHandler.setTransactionCurrencyNumerical(n);
                }
                if (n2 > 0 && this.commonHandler.getTransactionAmountFraction() <= 0) {
                    n = yP_EFT_Application.getDataContainerBusiness().currencyInterface.getCurrencyFraction(n2);
                    if (n >= 0) {
                        this.commonHandler.setTransactionAmountFraction(n);
                    }
                } else if (n2 > 0 && this.commonHandler.getTransactionAmountFraction() > 0 && (n = yP_EFT_Application.getDataContainerBusiness().currencyInterface.getCurrencyFraction(n2)) != this.commonHandler.getTransactionAmountFraction()) {
                    this.logger(2, "initTransaction() : differents currency fraction values");
                    while (n > this.commonHandler.getTransactionAmountFraction()) {
                        this.commonHandler.setTransactionAmountFraction(this.commonHandler.getTransactionAmountFraction() + 1);
                        this.commonHandler.setTransactionAmount(this.commonHandler.getTransactionAmount() * 10L);
                    }
                    while (n < this.commonHandler.getTransactionAmountFraction()) {
                        this.commonHandler.setTransactionAmountFraction(this.commonHandler.getTransactionAmountFraction() - 1);
                        this.commonHandler.setTransactionAmount(this.commonHandler.getTransactionAmount() / 10L);
                    }
                }
            }
        }
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "onChange() test to see it this case is possible");
        }
        return -1;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "onSaveBefore() test to see it this case is possible");
        }
        return -1;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "onSaveAfter() test to see it this case is possible");
        }
        return -1;
    }
}

