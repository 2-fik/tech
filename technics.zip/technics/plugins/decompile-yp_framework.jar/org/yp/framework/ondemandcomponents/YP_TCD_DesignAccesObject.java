/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import javax.naming.NamingException;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Disk;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TableStatusEnumeration;

public abstract class YP_TCD_DesignAccesObject
extends YP_OnDemandComponent
implements Cloneable,
Iterable<YP_Row> {
    public static final int TEMPORARY_TABLE = 1;
    public static final int STATUS_TABLE = 2;
    public static final int EVENT_TABLE = 4;
    public static final int ARCHIVE_TABLE = 8;
    public static final int VERSION_TABLE = 16;
    public static final int TRANSACTION_TABLE_WITH_CACHE = 32;
    public static final int GAME_TEST_TABLE = 64;
    public static final int SLAVE_TABLE = 128;
    public static final int EMPTY_PROTOCOL_TABLE = 256;
    public static final int NO_TRIGGER_TABLE = 512;
    public static final int ALL_TABLE = 65535;
    private YP_TCD_DC_Context dataContainerContext;
    private List<Object> extensionList;
    private static final AtomicLong primaryKeyValue = new AtomicLong(UtilsYP.getPrimaryKeyCursor());
    private boolean tableStatusRetrieved = false;
    private int tableType;
    private String tableVersion;
    private int tableNumber;
    private String tableCksum;
    private Timestamp tableSystemGMTTime;
    private TableStatusEnumeration tableStatus;
    private int tableAckMessage;
    private YP_Row rowTemplate;
    private Class<? extends YP_Row> rowClass;
    private boolean isItAClonedDAO = false;
    private boolean isItAModifiedDAO = false;
    private String fieldFinderIdentifier;
    private static final Map<String, Field[]> globalFieldList = new ConcurrentHashMap<String, Field[]>();
    private static final Map<String, Map<String, Field>> globalHashedFieldList = new ConcurrentHashMap<String, Map<String, Field>>();
    private String tableName;
    private String fullTableName;
    private String primaryKeyName;
    private Field primaryKeyField;
    private int lastCountValue = -1;
    public static final String TABLE_MASTER_EXTENSION = "_master";
    public static final String TABLE_SLAVE_EXTENSION = "_slave";
    protected String masterExtension = "_master";
    protected String slaveExtension = "_slave";

    public YP_TCD_DesignAccesObject(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        try {
            TableExtensionName tableExtensionName;
            if (yP_Object instanceof YP_TS_GlobalProcessManager) {
                return;
            }
            if (!(yP_Object instanceof YP_TCD_DC_Context)) {
                if ((1 & (Integer)objectArray[2]) == 0) {
                    this.logger(2, "YP_TCD_DesignAccesObject() the father of a DAO must be a Data Container Context");
                    throw new Exception();
                }
                if (!(yP_Object instanceof YP_TCD_DesignAccesObject)) {
                    this.logger(2, "YP_TCD_DesignAccesObject() the father of a DAO temporary must be a DAO");
                    throw new Exception();
                }
                this.dataContainerContext = ((YP_TCD_DesignAccesObject)yP_Object).getDataContainerContext();
            } else {
                this.dataContainerContext = (YP_TCD_DC_Context)yP_Object;
            }
            if (objectArray == null || objectArray.length != 4) {
                this.logger(2, "YP_TCD_DesignAccesObject() bad number of parameters");
                throw new Exception();
            }
            if (objectArray[0] == null || !(objectArray[0] instanceof Class)) {
                this.logger(2, "YP_TCD_DesignAccesObject() parameter 1 (Row Class) must be set");
                throw new Exception();
            }
            this.rowClass = (Class)objectArray[0];
            this.rowTemplate = (YP_Row)((Class)objectArray[0]).newInstance();
            this.rowTemplate.setFather(this);
            this.fieldFinderIdentifier = this.rowTemplate.getClass().getName();
            if (this.rowTemplate.contractKey != 0L) {
                this.fieldFinderIdentifier = String.valueOf(this.fieldFinderIdentifier) + 'X';
            }
            if ((tableExtensionName = this.rowClass.getAnnotation(TableExtensionName.class)) != null) {
                this.masterExtension = tableExtensionName.masterExtension();
                this.slaveExtension = tableExtensionName.slaveExtension();
                if (this.masterExtension.contentEquals(this.slaveExtension)) {
                    this.logger(2, "YP_TCD_DesignAccesObject() parameter 1. Master & slave name can't be the same");
                    throw new NamingException();
                }
            }
            if (objectArray[1] == null || !(objectArray[1] instanceof Integer)) {
                this.logger(2, "YP_TCD_DesignAccesObject() parameter 2 (tableNumber) must be an Integer");
                throw new Exception();
            }
            this.tableNumber = (Integer)objectArray[1];
            if (objectArray[2] == null || !(objectArray[2] instanceof Integer)) {
                this.logger(2, "YP_TCD_DesignAccesObject() parameter 3 (tableType) must be an Integer");
                throw new Exception();
            }
            this.tableType = (Integer)objectArray[2];
            if (objectArray[3] == null && (0x10 & this.getTableType()) != 0) {
                this.logger(2, "YP_TCD_DesignAccesObject() Version Table must have a non null parameter 4 (version)");
                throw new Exception();
            }
            this.setTableVersion((String)objectArray[3]);
            if ((1 & this.getTableType()) == 0) {
                this.dataContainerContext.getDAOList().add(this);
                if ((yP_Object instanceof YP_TCD_DCC_Technique || yP_Object instanceof YP_TCD_DCC_Brand || UtilsYP.getTableCreationMode() == 2 || this instanceof YP_TCD_DAO_SQL_Transaction && !this.getTableName().startsWith("Transaction_") || (4 & this.getTableType()) != 0 || (8 & this.getTableType()) != 0 && !this.getTableName().startsWith("Transaction_") || (0x10 & this.getTableType()) != 0 || (2 & this.getTableType()) != 0) && (0x80 & this.getTableType()) == 0 && this.getDataBaseConnector() != null) {
                    try {
                        this.getDataBaseConnector().sql_Formater.sqlCreateTable(this, false);
                    }
                    catch (Exception exception) {
                        this.logger(2, "YP_TCD_DesignAccesObject() :" + exception);
                    }
                }
            }
            if ((1 & this.getTableType()) == 0 && (UtilsYP.getTableCreationMode() == 3 || UtilsYP.getTableCreationMode() == 4 && "KERNEL".contentEquals(this.getContractIdentifier()))) {
                try {
                    this.getDataBaseConnector().sql_Formater.sqlCreateTable(this, true);
                }
                catch (Exception exception) {
                    this.logger(2, "YP_TCD_DesignAccesObject() sqlCreateTable forced :" + exception);
                }
            }
            if ((0x20 & this.getTableType()) != 0 && !(this instanceof YP_TCD_DAO_SQL_Transaction)) {
                this.logger(2, "YP_TCD_DesignAccesObject() : only Transaction table can have a cache");
                throw new Exception();
            }
            if ((8 & this.getTableType()) != 0 && !(this instanceof YP_TCD_DAO_SQL_Disk)) {
                this.logger(2, "YP_TCD_DesignAccesObject() : an archive table can only be of Disk type");
                throw new Exception();
            }
            if ((1 & this.getTableType()) != 0 && !(this instanceof YP_TCD_DAO_LOC_Table)) {
                this.logger(2, "YP_TCD_DesignAccesObject() : a temporary table can only be of table type");
                throw new Exception();
            }
            if (!(this instanceof YP_TCD_DAO_SQL_Transaction)) {
                if ((1 & this.getTableType()) != 0) {
                    if ((0x10 & this.getTableType()) == 0) {
                        this.setTableVersion("0000");
                    }
                    this.setTableStatus(TableStatusEnumeration.UNKNOWN);
                    this.setTableCksum("0000");
                    this.tableStatusRetrieved = true;
                } else if ((4 & this.getTableType()) != 0) {
                    this.setTableStatus(TableStatusEnumeration.UNKNOWN);
                    this.setTableCksum("0000");
                    this.tableStatusRetrieved = true;
                } else if ((2 & this.getTableType()) != 0) {
                    this.setTableStatus(TableStatusEnumeration.UNKNOWN);
                    this.setTableCksum("0000");
                    this.tableStatusRetrieved = true;
                } else if (this.getTableName().contentEquals("TableList")) {
                    this.setTableStatus(TableStatusEnumeration.UNKNOWN);
                    this.setTableCksum("0000");
                    this.tableStatusRetrieved = true;
                } else if (objectArray[3] != null) {
                    this.dataContainerContext.retrieveTableStatus(this);
                    this.setTableVersion((String)objectArray[3]);
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "YP_TCD_DesignAccesObject() :" + exception);
            throw exception;
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    protected boolean checkIfModificationsAllowed() {
        if (UtilsYP.getInstanceRole() == 1) {
            return true;
        }
        if ((4 & this.getTableType()) != 0) {
            return true;
        }
        if ((2 & this.getTableType()) != 0) {
            return true;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "checkIfModificationsAllowed() forbidden on slave !!!");
        }
        return false;
    }

    protected final boolean checkIfCreationsAllowed() {
        if (UtilsYP.getInstanceRole() == 1) {
            return true;
        }
        if (this instanceof YP_TCD_DAO_SQL_Transaction) {
            return true;
        }
        if ((4 & this.getTableType()) != 0) {
            return true;
        }
        if ((2 & this.getTableType()) != 0) {
            return true;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "checkIfCreationsAllowed() forbidden on slave !!!");
        }
        return false;
    }

    public final void createRow(YP_Row yP_Row) throws Exception {
        if (!this.checkIfCreationsAllowed()) {
            throw new Exception("createRow() is not allowed !!!");
        }
        this.getDataBaseConnector().sql_Formater.createRow(this, yP_Row);
    }

    public final void updateRow(YP_Row yP_Row) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRow() is not allowed !!!");
        }
        this.getDataBaseConnector().sql_Formater.updateRow(this, yP_Row);
    }

    public final void deleteRow(YP_Row yP_Row) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRow() is not allowed !!!");
        }
        this.getDataBaseConnector().sql_Formater.deleteRow(this, yP_Row);
    }

    @Override
    public final Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        try {
            this.rowTemplate = null;
            this.rowClass = null;
            this.dataContainerContext = null;
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "shutdown() " + exception);
            return -1;
        }
    }

    @Override
    public Iterator<YP_Row> iterator() {
        return new DAOIterator<YP_Row>();
    }

    public final YP_TCD_DC_Context getDataContainerContext() {
        return this.dataContainerContext;
    }

    public final long getNextPrimaryKey() {
        return primaryKeyValue.incrementAndGet();
    }

    public final int getTableType() {
        return this.tableType;
    }

    public final int getTableNumber() {
        return this.tableNumber;
    }

    public final void setTableStatusRetrieved(boolean bl) {
        this.tableStatusRetrieved = bl;
    }

    public final void setDefaultStatus() {
        if (this.tableSystemGMTTime == null || this.tableSystemGMTTime.getTime() == 0L) {
            this.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        }
        if (this.tableVersion == null) {
            this.setTableVersion("0000");
        }
        if (this.tableCksum == null) {
            this.setTableCksum("0000");
        }
        if (this.tableStatus == null) {
            this.setTableStatus(TableStatusEnumeration.UNKNOWN);
        }
    }

    public final void setTableVersion(String string) {
        if (string != null && this.tableVersion != null && !string.contentEquals(this.tableVersion)) {
            this.isItAModifiedDAO = true;
        }
        this.tableVersion = string;
    }

    public final String getTableVersion() {
        if (this.tableVersion == null && !this.tableStatusRetrieved) {
            this.dataContainerContext.retrieveTableStatus(this);
            if (this.tableVersion == null) {
                this.tableVersion = "";
            }
        }
        return this.tableVersion;
    }

    public final void setTableCksum(String string) {
        if (string != null && this.tableCksum != null && !string.contentEquals(this.tableCksum)) {
            this.isItAModifiedDAO = true;
        }
        this.tableCksum = string;
    }

    public final String getTableCksum() {
        if (this.tableCksum == null && !this.tableStatusRetrieved) {
            this.dataContainerContext.retrieveTableStatus(this);
            if (this.tableCksum == null) {
                this.tableCksum = "0000";
            }
        }
        return this.tableCksum;
    }

    public final void setTableSystemGMTTime(Timestamp timestamp) {
        this.tableSystemGMTTime = timestamp;
    }

    public final Timestamp getTableSystemGMTTime() {
        if (this.tableSystemGMTTime == null && !this.tableStatusRetrieved) {
            this.dataContainerContext.retrieveTableStatus(this);
            if (this.tableSystemGMTTime == null) {
                this.tableSystemGMTTime = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
            }
        }
        return this.tableSystemGMTTime;
    }

    public final void setTableStatus(TableStatusEnumeration tableStatusEnumeration) {
        this.tableStatus = tableStatusEnumeration;
    }

    public final TableStatusEnumeration getTableStatus() {
        if (this.tableStatus == null && !this.tableStatusRetrieved) {
            this.dataContainerContext.retrieveTableStatus(this);
            if (this.tableStatus == null) {
                this.tableStatus = TableStatusEnumeration.UNKNOWN;
            }
        }
        return this.tableStatus;
    }

    public final void setTableAckMessage(int n) {
        this.tableAckMessage = n;
    }

    public final int getTableAckMessage() {
        return this.tableAckMessage;
    }

    public final String getTableName() {
        if (this.tableName != null) {
            return this.tableName;
        }
        this.tableName = this.rowTemplate.getTableName();
        return this.tableName;
    }

    public final String getFullTableName() {
        if (this.fullTableName != null) {
            return this.fullTableName;
        }
        this.fullTableName = this.getDataBaseConnector().sql_Formater.sqlFullTableName(this);
        return this.fullTableName;
    }

    public final String getSchemaName() {
        String string = this.rowTemplate.contractKey != 0L ? ((YP_TCD_DCC_Business)this.dataContainerContext).getApplicationPlugin().getSchemaName((YP_TCD_DCC_Business)this.dataContainerContext) : this.getDataBaseConnector().getDataBaseName();
        return string;
    }

    public final String getPrimaryKeyName() {
        if (this.primaryKeyName == null) {
            this.primaryKeyName = this.rowTemplate.__getPrimaryKeyName();
        }
        return this.primaryKeyName;
    }

    public final Field[] getFieldList() {
        Field[] fieldArray = globalFieldList.get(this.fieldFinderIdentifier);
        if (fieldArray == null) {
            try {
                this.lock();
                if (fieldArray == null && (fieldArray = this.rowTemplate.__getFieldList()) != null) {
                    globalFieldList.put(this.fieldFinderIdentifier, fieldArray);
                    HashMap<String, Field> hashMap = new HashMap<String, Field>();
                    Field[] fieldArray2 = fieldArray;
                    int n = fieldArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        Field field = fieldArray2[n2];
                        hashMap.put(field.getName(), field);
                        ++n2;
                    }
                    globalHashedFieldList.put(this.fieldFinderIdentifier, hashMap);
                }
            }
            finally {
                this.unlock();
            }
        }
        return fieldArray;
    }

    public final Field getPrimaryKeyField() {
        if (this.primaryKeyField != null) {
            return this.primaryKeyField;
        }
        this.primaryKeyField = this.getFieldByName(this.getPrimaryKeyName());
        return this.primaryKeyField;
    }

    public final YP_Row getNewRow() {
        try {
            YP_Row yP_Row = this.rowClass.newInstance();
            yP_Row.setFather(this);
            yP_Row.setIsItAClonedRow(true);
            if (this.extensionList != null) {
                for (Object object : this.extensionList) {
                    yP_Row.addRowExtension(object.getClass().newInstance());
                }
            }
            return yP_Row;
        }
        catch (Exception exception) {
            this.logger(2, "getNewRow() " + exception);
            return null;
        }
    }

    public final Class<? extends YP_Row> getRowClass() {
        return this.rowClass;
    }

    public final int addExtension(Object object) {
        try {
            if (UtilsYP.getTableCreationMode() == 2 || this instanceof YP_TCD_DAO_SQL_Transaction && !this.getTableName().startsWith("Transaction_") || (4 & this.getTableType()) != 0 || (8 & this.getTableType()) != 0 && !this.getTableName().startsWith("Transaction_") || (2 & this.getTableType()) != 0) {
                return this.addExtension(object, true);
            }
            return this.addExtension(object, false);
        }
        catch (Exception exception) {
            this.logger(2, "addExtension()  :" + exception);
            return 1;
        }
    }

    public final int addExtension(Object object, boolean bl) {
        try {
            this.fieldFinderIdentifier = String.valueOf(this.fieldFinderIdentifier) + Integer.toString(object.getClass().hashCode());
            int n = this.rowTemplate.addRowExtension(object);
            if (n != 1) {
                return n;
            }
            if (this.extensionList == null) {
                this.extensionList = new ArrayList<Object>();
            }
            this.extensionList.add(object);
            if (bl && UtilsYP.getTableCreationMode() != 0 && this.getDataBaseConnector() != null) {
                try {
                    this.getDataBaseConnector().sql_Formater.sqlCreateTable(this, false);
                }
                catch (Exception exception) {
                    this.logger(2, "addExtension()  :" + exception);
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "addExtension()  :" + exception);
        }
        return 1;
    }

    public final List<Object> getExtensionList() {
        return this.extensionList;
    }

    public final int getLastCountValue() {
        return this.lastCountValue;
    }

    public final void setLastCountValue(int n) {
        this.lastCountValue = n;
    }

    public final List<String> getIndexesKeysNames() {
        return this.rowTemplate.getIndexesKeysNames();
    }

    public final int getFieldLength(String string) {
        return this.rowTemplate.getFieldLength(string);
    }

    public final int getFieldLength(Field field) {
        return this.rowTemplate.getFieldLength(field);
    }

    public final Field getFieldByName(String string) {
        Field field;
        Map<String, Field> map = globalHashedFieldList.get(this.fieldFinderIdentifier);
        if (map != null) {
            return map.get(string);
        }
        Field[] fieldArray = this.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            field = fieldArray[n2];
            if (field.getName().contentEquals(string)) {
                return field;
            }
            ++n2;
        }
        fieldArray = this.getFieldList();
        n = fieldArray.length;
        n2 = 0;
        while (n2 < n) {
            field = fieldArray[n2];
            if (field.getName().equalsIgnoreCase(string)) {
                this.logger(2, "getFieldByName() " + string + " not found maybe you want to use " + field.getName());
            }
            ++n2;
        }
        return null;
    }

    public final Field getFieldByName(String string, boolean bl) {
        Field field = this.getFieldByName(string);
        if (field != null) {
            return field;
        }
        if (!bl) {
            return null;
        }
        Field[] fieldArray = this.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            Field field2 = fieldArray[n2];
            if (field2.getName().compareToIgnoreCase(string) == 0) {
                return field2;
            }
            ++n2;
        }
        return null;
    }

    public final YP_TCD_DataBaseConnector getDataBaseConnector() {
        return this.dataContainerContext.getDataBaseConnector();
    }

    public final void setIsItAClonedDAO(boolean bl) {
        this.isItAClonedDAO = bl;
    }

    public final boolean isItAClonedDAO() {
        return this.isItAClonedDAO;
    }

    public final void setIsItAModifiedDAO(boolean bl) {
        this.isItAModifiedDAO = bl;
    }

    public final boolean isItAModifiedDAO() {
        return this.isItAModifiedDAO;
    }

    public final YP_Row getUniqueRow() {
        List<YP_Row> list;
        block9: {
            block8: {
                list = this.getRowList();
                if (list != null) break block8;
                this.logger(2, "getUniqueRow() unable to get rowlist :" + this.getTableName());
                return null;
            }
            if (!list.isEmpty()) break block9;
            this.logger(3, "getUniqueRow() table is empty :" + this.getTableName());
            return null;
        }
        try {
            if (list.size() > 1) {
                this.logger(3, "getUniqueRow() too many rows in Unique table :" + this.getTableName());
            }
            for (YP_Row yP_Row : list) {
                if (yP_Row.getModifierFlag() == 1) {
                    if (this.getLogLevel() < 3) continue;
                    this.logger(3, "getUniqueRow() deleted row ignored :" + this.getTableName());
                    continue;
                }
                return yP_Row;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getUniqueRow() no not deleted row :" + this.getTableName());
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getUniqueRow() :" + this.getTableName() + " " + exception);
            return null;
        }
    }

    public abstract YP_Row getRowByPrimaryKey(long var1);

    public abstract YP_Row getRowAt(int var1);

    protected abstract YP_Row getRowAt(int var1, boolean var2);

    public final List<YP_Row> getRowListSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getRowListSuchAs(0, 0, yP_ComplexGabaritArray);
    }

    public final List<YP_Row> getRowList() {
        return this.getRowListSuchAs(0, 0, new YP_ComplexGabarit[]{null});
    }

    public abstract List<YP_Row> getRowListSuchAs(int var1, int var2, YP_ComplexGabarit ... var3);

    public abstract List<String> getDistinctStringValueListSuchAs(String var1, YP_ComplexGabarit ... var2);

    public abstract List<String> getDistinctStringValueList(String var1);

    public abstract List<Object> getDistinctValueListSuchAs(String var1, YP_ComplexGabarit ... var2);

    public abstract List<Object> getDistinctValueList(String var1);

    public abstract long getSumSuchAs(String var1, YP_ComplexGabarit ... var2);

    public abstract int getCountSuchAs(YP_ComplexGabarit ... var1);

    public abstract int size();

    public abstract int deleteRows(boolean var1) throws Exception;

    public abstract int deleteRowsSuchAs(YP_ComplexGabarit ... var1) throws Exception;

    public abstract int persist();

    public abstract int persist(YP_TCD_DAO_LOC_Table var1);

    public abstract int addRow(YP_Row var1) throws Exception;

    public abstract int addRow(YP_Row var1, boolean var2) throws Exception;

    public final int updateRowSuchAs(YP_Row yP_Row, YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRowSuchAs() is not allowed !!!");
        }
        return this.updateRowSuchAs(yP_Row, 0, yP_ComplexGabaritArray);
    }

    public abstract int updateRowSuchAs(YP_Row var1, int var2, YP_ComplexGabarit ... var3) throws Exception;

    public abstract int reload();

    public final YP_Row getRowFromNaturalJoin(YP_Row yP_Row) {
        Field field;
        block5: {
            try {
                field = yP_Row.getFieldByName(this.getPrimaryKeyName());
                if (field != null) break block5;
                this.logger(2, "getRowFromNaturalJoin() " + this.getPrimaryKeyName() + " not found. Maybe you have to use getRowListFromNaturalJoin()");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getRowFromNaturalJoin() : unable to join" + exception);
                return null;
            }
        }
        Object object = yP_Row.getFieldValue(field);
        if (object instanceof Long) {
            return this.getRowByPrimaryKey((Long)object);
        }
        if (object instanceof Integer) {
            return this.getRowByPrimaryKey(((Integer)object).intValue());
        }
        this.logger(2, "getRowFromNaturalJoin() the primary key is neither a long or a int. TODO ? ");
        return null;
    }

    public final List<YP_Row> getRowListFromNaturalJoin(YP_Row yP_Row) {
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this);
            yP_ComplexGabarit.set(yP_Row.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getPrimaryKey());
            return this.getRowListSuchAs(yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "getRowListFromNaturalJoin() : " + exception);
            return null;
        }
    }

    public final YP_TCD_DAO_LOC_Table createTemporaryTable(boolean bl) {
        if (this instanceof YP_TCD_DAO_SQL_Transaction) {
            this.logger(2, "createTemporaryTable() : Transaction table can't have temporary table !!!");
            return null;
        }
        try {
            YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table = (YP_TCD_DAO_LOC_Table)this.newPluginByName("DAO_Table", this.getRowClass(), this.getTableNumber(), 1, null);
            if (bl) {
                yP_TCD_DAO_LOC_Table.isLoadedInMemory = 2;
            } else {
                yP_TCD_DAO_LOC_Table.reload();
            }
            return yP_TCD_DAO_LOC_Table;
        }
        catch (Exception exception) {
            this.logger(2, "createTemporaryTable() : " + exception);
            return null;
        }
    }

    @Override
    public Object clone() {
        if (!(this instanceof YP_TCD_DAO_LOC_Table)) {
            this.logger(2, "clone() : only table are cloneable ");
            return null;
        }
        return super.clone();
    }

    public final List<YP_Row> getSortedRowListSuchAs(YP_ComplexGabarit yP_ComplexGabarit) {
        List<YP_Row> list = this.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() <= 1) {
            return list;
        }
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
        block0: for (YP_Row yP_Row : list) {
            int n = 0;
            int n2 = 0;
            while (n2 < yP_ComplexGabarit.size()) {
                if (UtilsYP.isEquals(yP_ComplexGabarit.getObjectAt(n2), yP_Row.getFieldValueByName(yP_ComplexGabarit.getFieldNameAt(n2)), false, false)) {
                    ++n;
                }
                ++n2;
            }
            n2 = 0;
            while (n2 <= arrayList2.size()) {
                if (n2 == arrayList2.size() || (Integer)arrayList2.get(n2) <= n) {
                    arrayList2.add(n2, n);
                    arrayList.add(n2, yP_Row);
                    continue block0;
                }
                ++n2;
            }
        }
        return arrayList;
    }

    public int createTable(boolean bl) {
        return this.getDataBaseConnector().sql_Formater.sqlCreateTable(this, bl);
    }

    protected static List<YP_Row> orderRowList(List<YP_Row> list, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            return list;
        }
        YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
        int n = yP_ComplexGabaritArray.length;
        int n2 = 0;
        while (n2 < n) {
            YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n2];
            if (yP_ComplexGabarit.isOrdered) {
                return yP_ComplexGabarit.order(list);
            }
            ++n2;
        }
        return list;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public static List<YP_Row> getRowListSuchAs(List<YP_Row> list, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null || yP_ComplexGabaritArray[0].size() == 0) {
                return list;
            }
            YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
            int n = yP_ComplexGabaritArray.length;
            int n2 = 0;
            while (n2 < n) {
                object = yP_ComplexGabaritArray2[n2];
                if (((YP_ComplexGabarit)object).groupFieldNameList != null) {
                    if (yP_ComplexGabaritArray.length > 1) {
                        Object object2;
                        HashSet<YP_Row> hashSet = new HashSet<YP_Row>();
                        YP_ComplexGabarit[] yP_ComplexGabaritArray3 = yP_ComplexGabaritArray;
                        int n3 = yP_ComplexGabaritArray.length;
                        int n4 = 0;
                        while (n4 < n3) {
                            object2 = yP_ComplexGabaritArray3[n4];
                            List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, new YP_ComplexGabarit[]{object2});
                            if (list2 != null) {
                                hashSet.addAll(list2);
                            }
                            ++n4;
                        }
                        object2 = new ArrayList();
                        object2.addAll(hashSet);
                        return YP_TCD_DesignAccesObject.orderRowList((List<YP_Row>)object2, yP_ComplexGabaritArray);
                    }
                    if (!((YP_ComplexGabarit)object).gabaritHasOneMinOrMax) {
                        return null;
                    }
                }
                ++n2;
            }
            yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
            n = yP_ComplexGabaritArray.length;
            n2 = 0;
            while (n2 < n) {
                object = yP_ComplexGabaritArray2[n2];
                if (((YP_ComplexGabarit)object).gabaritHasOneMinOrMax) {
                    return YP_TCD_DesignAccesObject.orderRowList(YP_TCD_DesignAccesObject.getRowListSuchAsForMinMax(list, yP_ComplexGabaritArray), yP_ComplexGabaritArray);
                }
                ++n2;
            }
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            n = list.size();
            if (n < 0) {
                return null;
            }
            int n5 = 0;
            while (n5 < n) {
                object = list.get(n5);
                YP_ComplexGabarit[] yP_ComplexGabaritArray4 = yP_ComplexGabaritArray;
                int n6 = yP_ComplexGabaritArray.length;
                int n7 = 0;
                while (n7 < n6) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray4[n7];
                    if (yP_ComplexGabarit.match((YP_Row)object)) {
                        arrayList.add((YP_Row)object);
                        break;
                    }
                    ++n7;
                }
                ++n5;
            }
            return YP_TCD_DesignAccesObject.orderRowList(arrayList, yP_ComplexGabaritArray);
        }
        catch (Exception exception) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static List<YP_Row> getRowListSuchAsForMinMax(List<YP_Row> list, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            Object object2;
            YP_Row yP_Row;
            YP_ComplexGabarit yP_ComplexGabarit;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null || yP_ComplexGabaritArray[0].size() == 0) {
                return null;
            }
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            int n2 = list.size();
            if (n2 < 0) {
                return null;
            }
            ArrayList[] arrayListArray = new ArrayList[yP_ComplexGabaritArray.length];
            int n3 = 0;
            while (n3 < yP_ComplexGabaritArray.length) {
                yP_ComplexGabarit = yP_ComplexGabaritArray[n3];
                if (yP_ComplexGabarit.gabaritHasOneMinOrMax) {
                    arrayListArray[n3] = new ArrayList();
                }
                ++n3;
            }
            n3 = 0;
            while (n3 < n2) {
                yP_Row = list.get(n3);
                int n4 = 0;
                while (n4 < yP_ComplexGabaritArray.length) {
                    object2 = yP_ComplexGabaritArray[n4];
                    if (((YP_ComplexGabarit)object2).match(yP_Row, 0)) {
                        arrayList.add(yP_Row);
                        if (((YP_ComplexGabarit)object2).gabaritHasOneMinOrMax) {
                            arrayListArray[n4].add(yP_Row);
                        }
                    }
                    ++n4;
                }
                ++n3;
            }
            n3 = 0;
            while (n3 < yP_ComplexGabaritArray.length) {
                yP_ComplexGabarit = yP_ComplexGabaritArray[n3];
                if (yP_ComplexGabarit.gabaritHasOneMinOrMax) {
                    int n5;
                    if (yP_ComplexGabarit.minFieldName != null) {
                        object2 = yP_ComplexGabarit.minFieldName;
                        n = 0;
                    } else {
                        if (yP_ComplexGabarit.maxFieldName == null) {
                            return null;
                        }
                        object2 = yP_ComplexGabarit.maxFieldName;
                        n = 1;
                    }
                    object = yP_ComplexGabarit.groupFieldList != null ? YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsGrouped(yP_ComplexGabarit.designAccesObject, (String)object2, n, arrayListArray[n3], yP_ComplexGabarit.groupFieldList) : YP_TCD_DesignAccesObject.getMinMaxRowListSuchAs(yP_ComplexGabarit.designAccesObject, (String)object2, n, arrayListArray[n3]);
                    Iterator<YP_Row> iterator = object.iterator();
                    while (iterator.hasNext()) {
                        YP_Row yP_Row2 = iterator.next();
                        n5 = 0;
                        while (n5 < arrayListArray[n3].size()) {
                            if (arrayListArray[n3].get(n5) == yP_Row2) {
                                arrayListArray[n3].remove(n5);
                            }
                            ++n5;
                        }
                    }
                    for (YP_Row yP_Row2 : arrayListArray[n3]) {
                        n5 = 0;
                        while (n5 < arrayList.size()) {
                            if (arrayList.get(n5) == yP_Row2) {
                                arrayList.remove(n5);
                            }
                            ++n5;
                        }
                    }
                }
                ++n3;
            }
            n3 = 0;
            int n6 = 0;
            while (n6 < yP_ComplexGabaritArray.length) {
                object2 = yP_ComplexGabaritArray[n6];
                n = 0;
                while (n < ((YP_ComplexGabarit)object2).size()) {
                    if (((YP_ComplexGabarit)object2).getOperatorAt(n) == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP || ((YP_ComplexGabarit)object2).getOperatorAt(n) == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP || ((YP_ComplexGabarit)object2).getOperatorAt(n) == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP || ((YP_ComplexGabarit)object2).getOperatorAt(n) == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                        n3 = 1;
                        break;
                    }
                    ++n;
                }
                ++n6;
            }
            if (n3 != 0) {
                n6 = arrayList.size() - 1;
                while (n6 >= 0) {
                    yP_Row = (YP_Row)arrayList.get(n6);
                    boolean bl = false;
                    n = 0;
                    while (n < yP_ComplexGabaritArray.length) {
                        object = yP_ComplexGabaritArray[n];
                        if (((YP_ComplexGabarit)object).match(yP_Row, 2)) {
                            bl = true;
                        }
                        if (!bl) {
                            arrayList.remove(n6);
                        }
                        ++n;
                    }
                    --n6;
                }
            }
            n6 = 0;
            while (n6 < arrayList.size() - 1) {
                if (arrayList.get(n6) == arrayList.get(n6 + 1)) {
                    arrayList.remove(n6);
                }
                ++n6;
            }
            return arrayList;
        }
        catch (Exception exception) {
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForInt(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            int n2 = Integer.MIN_VALUE;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (n2 == Integer.MIN_VALUE) {
                    n2 = (Integer)yP_Row.getFieldValue(field);
                    arrayList.add(yP_Row);
                    continue;
                }
                int n3 = (Integer)yP_Row.getFieldValue(field);
                int n4 = n2 < n3 ? -1 : (n2 == n3 ? 0 : 1);
                if (n == 0 && n4 < 0 || n == 1 && n4 > 0) continue;
                if (n == 0 && n4 > 0 || n == 1 && n4 < 0) {
                    arrayList.clear();
                }
                n2 = n3;
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForInt() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForLong(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            long l = Long.MIN_VALUE;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (l == Long.MIN_VALUE) {
                    l = (Long)yP_Row.getFieldValue(field);
                    arrayList.add(yP_Row);
                    continue;
                }
                long l2 = (Long)yP_Row.getFieldValue(field);
                int n2 = l < l2 ? -1 : (l == l2 ? 0 : 1);
                if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                    arrayList.clear();
                }
                l = l2;
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForLong() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForFloat(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            float f = Float.MIN_VALUE;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (f == Float.MIN_VALUE) {
                    f = ((Float)yP_Row.getFieldValue(field)).floatValue();
                    arrayList.add(yP_Row);
                    continue;
                }
                float f2 = ((Float)yP_Row.getFieldValue(field)).floatValue();
                int n2 = f < f2 ? -1 : (f == f2 ? 0 : 1);
                if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                    arrayList.clear();
                }
                f = f2;
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForFloat() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForTimestamp(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            Timestamp timestamp = null;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (timestamp == null) {
                    timestamp = (Timestamp)yP_Row.getFieldValue(field);
                    arrayList.add(yP_Row);
                    continue;
                }
                int n2 = timestamp.compareTo((Timestamp)yP_Row.getFieldValue(field));
                if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                    arrayList.clear();
                }
                timestamp = (Timestamp)yP_Row.getFieldValue(field);
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForTimestamp() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForDate(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            Date date = null;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (date == null) {
                    date = (Date)yP_Row.getFieldValue(field);
                    arrayList.add(yP_Row);
                    continue;
                }
                int n2 = date.compareTo((Date)yP_Row.getFieldValue(field));
                if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                    arrayList.clear();
                }
                date = (Date)yP_Row.getFieldValue(field);
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForDate() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsForString(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, Field field, List<YP_Row> list) {
        try {
            String string = null;
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : list) {
                if (string == null) {
                    string = yP_Row.getFieldStringValue(field);
                    arrayList.add(yP_Row);
                    continue;
                }
                int n2 = string.compareTo(yP_Row.getFieldStringValue(field));
                if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                    arrayList.clear();
                }
                string = yP_Row.getFieldStringValue(field);
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsForString() " + exception);
            return null;
        }
    }

    protected static List<YP_Row> getMinMaxRowListSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, List<YP_Row> list) {
        block9: {
            try {
                Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
                Class<?> clazz = field.getType();
                if (clazz == Long.TYPE) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForLong(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (clazz == Integer.TYPE) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForInt(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (clazz == Float.TYPE) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForFloat(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (clazz == Timestamp.class) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForTimestamp(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (clazz == Date.class) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForDate(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (clazz == byte[].class) {
                    return YP_TCD_DesignAccesObject.getMinMaxRowListSuchAsForString(yP_TCD_DesignAccesObject, n, field, list);
                }
                if (!clazz.isEnum()) break block9;
                yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAs() meaningless on Enum :" + string);
                return null;
            }
            catch (Exception exception) {
                yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAs() " + exception);
                return null;
            }
        }
        yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAs() unknown type of" + string);
        return null;
    }

    protected static List<YP_Row> getMinMaxRowListSuchAsGrouped(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, List<YP_Row> list, List<Field> list2) {
        try {
            List<String> list3;
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            HashMap hashMap = new HashMap();
            for (YP_Row arrayList2 : list) {
                list3 = new ArrayList();
                for (Field field2 : list2) {
                    list3.add(arrayList2.getFieldStringValue(field2));
                }
                if (hashMap.containsKey(list3)) {
                    List list4 = (List)hashMap.get(list3);
                    int n2 = YP_ComplexGabarit.compare(((YP_Row)list4.get(0)).getFieldValue(field), arrayList2.getFieldValue(field));
                    if (n == 0 && n2 < 0 || n == 1 && n2 > 0) continue;
                    if (n == 0 && n2 > 0 || n == 1 && n2 < 0) {
                        list4.clear();
                    }
                    list4.add(arrayList2);
                    continue;
                }
                ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
                arrayList.add(arrayList2);
                hashMap.put(list3, arrayList);
            }
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            Collection collection = hashMap.values();
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                list3 = (List)iterator.next();
                arrayList.addAll(list3);
            }
            return arrayList;
        }
        catch (Exception exception) {
            yP_TCD_DesignAccesObject.logger(2, "getMinMaxRowListSuchAsGrouped() " + exception);
            return null;
        }
    }

    public static List<String> getDistinctStringValueList(List<YP_Row> list, String string) {
        block7: {
            if (list != null) break block7;
            return null;
        }
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            if (list.isEmpty()) {
                return arrayList;
            }
            Field field = list.get(0).getFieldByName(string);
            int n = list.size();
            int n2 = 0;
            while (n2 < n) {
                String string2 = list.get(n2).getFieldStringValue(field);
                boolean bl = false;
                for (String string3 : arrayList) {
                    if (!string3.contentEquals(string2)) continue;
                    bl = true;
                    break;
                }
                if (!bl) {
                    arrayList.add(string2);
                }
                ++n2;
            }
            return arrayList;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static long getSum(List<YP_Row> list, String string) {
        try {
            long l = 0L;
            int n = 0;
            while (n < list.size()) {
                Object object = list.get(n).getFieldValueByName(string);
                l = object instanceof Long ? (l += ((Long)object).longValue()) : (object instanceof Integer ? (l += (long)((Integer)object).intValue()) : (object instanceof Float ? (long)((float)l + ((Float)object).floatValue()) : (object instanceof byte[] ? (l += Long.parseLong(new String((byte[])object))) : (l += Long.parseLong(new String(object.toString()))))));
                ++n;
            }
            return l;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return -1L;
        }
    }

    public final String getMasterExtension() {
        return this.masterExtension;
    }

    public final String getSlaveExtension() {
        return this.slaveExtension;
    }

    public YP_Row getRowTemplate() {
        return this.rowTemplate;
    }

    public String getDistinctValueListSuchAsRequest(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getDataBaseConnector().sql_Formater.getDistinctValueListSuchAsRequestSQL(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    public int persistOptimized(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        return 0;
    }

    public int updateBatch(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, Field[] fieldArray, Field[] fieldArray2) {
        return 0;
    }

    public int deleteBatch(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, Field[] fieldArray) {
        return 0;
    }

    class DAOIterator<T>
    implements Iterator<T> {
        int count = 0;
        int daoSize;

        DAOIterator() {
            this.daoSize = YP_TCD_DesignAccesObject.this.size();
        }

        @Override
        public boolean hasNext() {
            return this.count < this.daoSize;
        }

        @Override
        public T next() {
            if (this.count == this.daoSize) {
                throw new NoSuchElementException();
            }
            return (T)YP_TCD_DesignAccesObject.this.getRowAt(this.count++);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}

