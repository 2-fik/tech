/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.crypto.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_CryptoModule
extends YP_Row {
    @PrimaryKey
    public long idCryptoModule = 0L;
    public byte[] cryptoModule_Plugin = new byte[120];
    public byte[] idSM = new byte[120];
    public byte[] providerName = new byte[200];
    public byte[] serialNumber = new byte[100];
    public byte[] interfaceType = new byte[20];
    public byte[] jarFile = new byte[120];
    public int securityLevel = 0;
    public int instanceNumber = 0;
    public int priority = 0;
    public byte[] prng = new byte[200];
    public byte[] rng = new byte[200];
    public byte[] cipherSym = new byte[200];
    public byte[] cipherAsym = new byte[200];
    public byte[] macAlgo = new byte[200];
    public byte[] signatureAlgo = new byte[200];
    public byte[] digestAlgo = new byte[200];
    public byte[] properties = new byte[1024];
    public byte[] ownerProcessCrypto = new byte[200];
    public byte[] ownerPreferredNameCrypto = new byte[200];
    public byte[] ownerBrandNameCrypto = new byte[120];
    public long ownerMerchantIdCrypto = 0L;
    public long ownerApplicationIdCrypto = 0L;
    public byte[] ownerApplicationNameCrypto = new byte[120];
}

