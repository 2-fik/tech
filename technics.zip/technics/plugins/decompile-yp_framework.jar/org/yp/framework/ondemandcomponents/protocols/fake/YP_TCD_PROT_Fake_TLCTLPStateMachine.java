/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.fake;

import java.sql.Timestamp;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.hosts.YP_TCD_DCB_STD_Hosts;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachine;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.InitializationStatusEnumeration;
import org.yp.utils.enums.SessionStatusEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_PROT_Fake_TLCTLPStateMachine
extends YP_OnDemandComponent
implements YP_PROT_Interface_StateMachine {
    private YP_PROT_Interface_Prot.SERVICEDEMANDE serviceRequested = null;
    public YP_TCD_DCC_Business dataContainerBusiness = null;
    public YP_TCD_DC_Transaction dataContainerTransaction = null;

    public YP_TCD_PROT_Fake_TLCTLPStateMachine(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int step() {
        try {
            switch (this.serviceRequested) {
                case ServiceTlc: {
                    this.logger(4, "step() ServiceTlc fake");
                    List<YP_Row> list = this.getSessionList();
                    if (list == null || list.isEmpty()) {
                        this.logger(4, "step() no session");
                    } else {
                        for (YP_Row yP_Row : list) {
                            this.updateSessionStatus(yP_Row);
                        }
                        this.logger(4, "step() no more session");
                        this.dataContainerBusiness.archiveTransactions();
                    }
                    this.dataContainerBusiness.eventsInterface.setEventStatus("TLC", 1);
                    break;
                }
                case ServiceTlp: {
                    this.logger(4, "step() ServiceTlp fake");
                    ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).deleteHosts(YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceTlc);
                    YP_Row yP_Row = ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.getNewRow();
                    yP_Row.set("name", "TLC");
                    yP_Row.set("maxTries", 1);
                    yP_Row.set("delayInterCallInSec", 300);
                    yP_Row.set("frequencyInYYMMWWDDHHMMSS", "00000001000000");
                    yP_Row.set("frequencyExtendedInYYMMWWDDHHMMSS", "00000001000000");
                    yP_Row.set("dateToCallCenterAAAAMMJJ", "00000000");
                    long l = System.currentTimeMillis();
                    String string = String.format("%02d%02d%02d", l % 3L, l % 60L, l / 1000L % 60L);
                    yP_Row.set("timeToCallCenterHHMMSS", string);
                    ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.addRow(yP_Row);
                    yP_Row = ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.getNewRow();
                    yP_Row.set("name", "TLP");
                    yP_Row.set("maxTries", 0);
                    yP_Row.set("delayInterCallInSec", 0);
                    yP_Row.set("frequencyInYYMMWWDDHHMMSS", "00000000000000");
                    yP_Row.set("frequencyExtendedInYYMMWWDDHHMMSS", "00000000000000");
                    yP_Row.set("dateToCallCenterAAAAMMJJ", "00000000");
                    yP_Row.set("timeToCallCenterHHMMSS", "000000");
                    ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.addRow(yP_Row);
                    ((YP_TCD_DCB_STD_Hosts)this.dataContainerBusiness.hostsInterface).hostsParameters.persist();
                    YP_Row yP_Row2 = this.dataContainerBusiness.getContractRow();
                    yP_Row2.set("activationCode", "1");
                    yP_Row2.set("initializationStatus", InitializationStatusEnumeration.INITIALISED);
                    yP_Row2.persist();
                    this.dataContainerBusiness.eventsInterface.setEventStatus("TLP", 1);
                    break;
                }
                default: {
                    this.logger(2, "step() service not handled " + (Object)((Object)this.serviceRequested));
                    break;
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "step()  " + exception);
        }
        return 0;
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "SM_FAKE_TLCTLP";
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public int setParameters(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, List<Property> list, YP_PROT_Interface_Prot yP_PROT_Interface_Prot, YP_Object yP_Object, Object ... objectArray) {
        this.dataContainerBusiness = yP_TCD_DCC_Business;
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
        this.serviceRequested = sERVICEDEMANDE;
        return 1;
    }

    @Override
    public void setServiceRequested(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        this.serviceRequested = sERVICEDEMANDE;
    }

    public List<YP_Row> getSessionList() {
        return this.dataContainerTransaction.getSessionListToUpload(this.getContractIdentifier());
    }

    private int topTransactionsToUploadAsUploaded(YP_Row yP_Row) {
        YP_Row yP_Row2 = this.dataContainerBusiness.transaction.getNewRow();
        yP_Row2.set("transactionUploadStatus", UploadStatusEnumeration.UPLOADED);
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerBusiness.transaction);
        yP_ComplexGabarit.set("transactionUploadStatus", YP_ComplexGabarit.OPERATOR.EQUAL, UploadStatusEnumeration.TO_UPLOAD);
        yP_ComplexGabarit.set("sessionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldValueByName("sessionNumber"));
        try {
            this.dataContainerBusiness.transaction.updateRowSuchAs(yP_Row2, yP_ComplexGabarit);
        }
        catch (Exception exception) {
            this.logger(2, "topTransactionsToUploadAsUploaded() " + exception);
            return -1;
        }
        return 1;
    }

    private int updateSessionStatus(YP_Row yP_Row) {
        yP_Row.set("sessionSystemGMTTimeMS", UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_Row.set("sessionAppliLocalTime", new Timestamp(this.dataContainerBusiness.timeInterface.getAppliLocalTime().getTimeInMillis()));
        this.topTransactionsToUploadAsUploaded(yP_Row);
        yP_Row.set("status", SessionStatusEnumeration.UPLOADED);
        long l = this.dataContainerTransaction.userHandler.getUserIdentifier();
        if (l > 0L) {
            yP_Row.set("idUser", l);
        }
        try {
            yP_Row.persist();
        }
        catch (Exception exception) {
            this.logger(2, "updateSessionStatus()" + exception);
            return -1;
        }
        return 1;
    }
}

