/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_IPV4_Channel_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private int connectionPort = 0;
    private final ByteBuffer byteBufferRead = ByteBuffer.allocate(8192);
    private ServerSocketChannel serverSocket = null;
    private Selector serverSelector = null;
    private SocketChannel clientSocket = null;
    String ipServer = null;
    int portServer = 0;
    int connectionTimeoutMS = 3499;
    String proxyType = null;
    String proxyHost = null;
    int proxyPort = 0;

    public YP_TCD_PHYS_IPV4_Channel_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof SocketChannel) {
            this.clientSocket = (SocketChannel)objectArray[0];
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.clientSocket == null) {
            String string = this.getProperty(this.getPropertyFileName(), "connectionPort");
            if (string != null) {
                this.connectionPort = Integer.parseInt(string);
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "proxyType")) != null && !string.isEmpty()) {
                this.proxyType = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "proxyHost")) != null && !string.isEmpty()) {
                this.proxyHost = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "proxyPort")) != null && !string.isEmpty()) {
                try {
                    this.proxyPort = Integer.parseInt(string);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "initialize() proxyPort :" + this.proxyPort + " " + exception);
                    }
                }
            }
        } else {
            try {
                this.clientSocket.configureBlocking(false);
            }
            catch (Exception exception) {
                this.logger(2, "initialize():" + exception);
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int close() {
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server Socket closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server socket close failed  :" + iOException);
                return -1;
            }
        }
        if (this.clientSocket != null) {
            try {
                this.clientSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Client Socket closed...");
                }
                this.clientSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Socket close error :" + iOException);
                this.clientSocket = null;
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "NetChannelConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int openServer() {
        if (this.serverSocket != null) {
            return 1;
        }
        try {
            this.serverSocket = ServerSocketChannel.open();
            this.serverSocket.configureBlocking(false);
            InetSocketAddress inetSocketAddress = new InetSocketAddress(this.connectionPort);
            this.serverSocket.socket().bind(inetSocketAddress);
            this.serverSelector = Selector.open();
            this.serverSocket.register(this.serverSelector, 16);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "openServer() Waiting for connections...");
            }
            return 1;
        }
        catch (IOException iOException) {
            this.logger(1, "openServer() Can't connect a socket to port " + this.connectionPort + " " + iOException);
            return -1;
        }
    }

    @Override
    public Object waitConnection() {
        try {
            long l = System.currentTimeMillis();
            do {
                this.serverSelector.select();
                Set<SelectionKey> set = this.serverSelector.selectedKeys();
                Iterator<SelectionKey> iterator = set.iterator();
                while (iterator.hasNext()) {
                    SelectionKey selectionKey = iterator.next();
                    iterator.remove();
                    if (!selectionKey.isAcceptable()) continue;
                    SocketChannel socketChannel = this.serverSocket.accept();
                    socketChannel.configureBlocking(false);
                    return socketChannel;
                }
            } while (!UtilsYP.isTimeout(l, this.getConnectionTimeout()));
            return null;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() " + exception);
            }
            return null;
        }
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        int n4 = 0;
        long l = System.currentTimeMillis();
        this.byteBufferRead.clear();
        do {
            try {
                n4 = this.clientSocket.read(this.byteBufferRead);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "recv() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "recv() Read error..." + exception);
                try {
                    this.clientSocket.close();
                }
                catch (IOException iOException) {}
                return -1;
            }
        } while (n4 == 0 && !UtilsYP.isTimeout(l, n3));
        if (n4 > 0) {
            System.arraycopy(this.byteBufferRead.array(), 0, byArray, n, n4);
            if (this.getLogLevel() >= 6) {
                this.logger(6, UtilsYP.getFormattedLog(0, byArray, n, n4));
            } else if (this.getLogLevel() >= 5) {
                this.logger(5, "recv() bytes received :" + n4);
            }
        } else if (n4 == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "recv() nothing...");
            }
        } else if (this.getLogLevel() >= 5) {
            this.logger(5, "recv() error :" + n4);
        }
        return n4;
    }

    @Override
    public int clean(int n) {
        long l = System.currentTimeMillis();
        this.byteBufferRead.clear();
        do {
            try {
                int n2 = this.clientSocket.read(this.byteBufferRead);
                if (n2 > 0) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, UtilsYP.getFormattedLog(2, this.byteBufferRead.array(), 0, n2));
                    } else if (this.getLogLevel() >= 4) {
                        this.logger(4, "clean() bytes cleaned :" + n2);
                    }
                    this.byteBufferRead.clear();
                    continue;
                }
                if (n2 == 0) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "clean() nothing...");
                    continue;
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "clean() error :" + n2);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "clean() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "clean() Read error..." + exception);
                return -1;
            }
        } while (!UtilsYP.isTimeout(l, n));
        return 1;
    }

    @Override
    public int available() {
        this.logger(2, "available() TODO");
        return -1;
    }

    @Override
    public int send(byte[] byArray, int n) {
        ByteBuffer byteBuffer = ByteBuffer.allocate(n);
        try {
            byteBuffer.clear();
            byteBuffer.put(byArray, 0, n);
            byteBuffer.flip();
            while (byteBuffer.hasRemaining()) {
                this.clientSocket.write(byteBuffer);
            }
        }
        catch (IOException iOException) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "send() Write error..." + iOException);
            }
            return -1;
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n));
        } else if (this.getLogLevel() >= 4) {
            this.logger(4, "send() bytes sent :" + n);
        }
        return n;
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        try {
            SocketAddress socketAddress = this.clientSocket.socket().getRemoteSocketAddress();
            String string = socketAddress.toString();
            int n = string.indexOf(":");
            string = string.substring(1, n);
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getIP() " + exception);
            return null;
        }
    }

    @Override
    public int openClient(Object ... objectArray) {
        block22: {
            block21: {
                block20: {
                    try {
                        if (this.clientSocket == null || !this.clientSocket.isConnected()) break block20;
                        return 1;
                    }
                    catch (Exception exception) {
                        this.logger(2, "openClient() " + exception);
                        this.ipServer = null;
                        this.clientSocket = null;
                        this.portServer = 0;
                        this.connectionTimeoutMS = 3499;
                        this.proxyHost = null;
                        this.proxyPort = 0;
                        return -1;
                    }
                }
                if (objectArray != null) break block21;
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                if (this.ipServer == null) {
                    this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                }
                if (this.connectionTimeoutMS == 3499) {
                    this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                }
                if (this.proxyType == null) {
                    this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
                }
                if (this.proxyHost == null) {
                    this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
                }
                if (this.proxyPort == 0) {
                    this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
                }
            } else if (objectArray.length >= 2 && objectArray[0] instanceof String && objectArray[1] instanceof String) {
                if (this.ipServer == null) {
                    this.ipServer = (String)objectArray[0];
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt((String)objectArray[1]);
                }
                if (objectArray.length > 2 && objectArray[2] instanceof Integer) {
                    this.connectionTimeoutMS = (Integer)objectArray[2];
                }
            }
            if (this.ipServer != null && this.portServer != 0) break block22;
            this.logger(2, "openClient() missing parameters");
            return -1;
        }
        if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "openClient() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
            }
            this.clientSocket = this.tunnelThroughProxy(this.proxyType, this.proxyHost, this.proxyPort, this.ipServer, this.portServer);
        } else {
            InetSocketAddress inetSocketAddress = new InetSocketAddress(InetAddress.getByName(this.ipServer), this.portServer);
            this.clientSocket = SocketChannel.open();
            this.clientSocket.socket().connect(inetSocketAddress, this.connectionTimeoutMS);
        }
        return this.initialize();
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for channel !!!");
        return null;
    }

    private SocketChannel tunnelThroughProxy(String string, String string2, int n, String string3, int n2) throws UnknownHostException, IOException {
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "tunnelThroughProxy() tunnelType missing. Assuming HTTP");
            }
            string = "HTTP";
        }
        if (string.equalsIgnoreCase("SOCKS")) {
            this.logger(2, "tunnelThroughProxy() NIO and proxy SOCKS not yet available !!!");
            throw new IOException("NIO and proxy SOCKS not yet available");
        }
        if (string.equalsIgnoreCase("HTTP")) {
            SocketChannel socketChannel = SocketChannel.open();
            socketChannel.socket().connect(new InetSocketAddress(string2, n), this.connectionTimeoutMS);
            this.doTunnelHandshake(socketChannel.socket(), string3, n2);
            return socketChannel;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "tunnelThroughProxy() unknown tunnelType " + string);
        }
        throw new UnknownHostException("unknown tunnelType");
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }
}

