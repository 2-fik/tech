/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.events;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.events.YP_TCD_DCB_Interface_Events;
import org.yp.framework.ondemandcomponents.datacontainers.extension.events.designaccesobjects.DAO_STD_Events;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCB_STD_Events
extends YP_OnDemandComponent
implements YP_TCD_DCB_Interface_Events {
    private YP_TCD_DCC_Business dataContainer;
    public YP_TCD_DesignAccesObject events;
    private static final Map<String, YP_Row> lastTLCEventFinder = new ConcurrentHashMap<String, YP_Row>();
    private static final Map<String, YP_Row> lastTLPEventFinder = new ConcurrentHashMap<String, YP_Row>();

    public YP_TCD_DCB_STD_Events(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.events = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Disk", DAO_STD_Events.class, 0, 0, null);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        this.resetFastEventFinder();
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionSTD_Events";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.events) {
            this.resetFastEventFinder();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() events");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.events) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() events");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.events) {
            this.resetFastEventFinder();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() events");
            }
            return 1;
        }
        return 0;
    }

    private void resetFastEventFinder() {
        String string = this.getContractIdentifier();
        if (string != null) {
            lastTLCEventFinder.remove(string);
            lastTLPEventFinder.remove(string);
        }
    }

    private void storeLastEvent(String string, YP_Row yP_Row) {
        Map<String, YP_Row> map;
        switch (string) {
            case "TLC": {
                map = lastTLCEventFinder;
                break;
            }
            case "TLP": {
                map = lastTLPEventFinder;
                break;
            }
            default: {
                return;
            }
        }
        if (yP_Row == null) {
            map.remove(this.getContractIdentifier());
        } else {
            map.put(this.getContractIdentifier(), yP_Row);
        }
    }

    private YP_Row getLastEventFast(String string) {
        if (UtilsYP.getInstanceRole() != 1) {
            return null;
        }
        switch (string) {
            case "TLC": {
                return lastTLCEventFinder.get(this.getContractIdentifier());
            }
            case "TLP": {
                return lastTLPEventFinder.get(this.getContractIdentifier());
            }
        }
        return null;
    }

    private YP_Row getLastEvent(String string) {
        List<YP_Row> list;
        YP_Row yP_Row;
        block5: {
            try {
                yP_Row = this.getLastEventFast(string);
                if (yP_Row != null) {
                    return yP_Row;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.events);
                yP_ComplexGabarit.set("eventName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("isDeleted", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                yP_ComplexGabarit.set("eventAppliLocalTime", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                list = this.events.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block5;
                this.logger(3, "getLastEvent() " + string + " not found");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getLastEvent()  " + string, exception);
                return null;
            }
        }
        if (list.size() > 1) {
            this.logger(2, "getLastEvent() too many events " + string);
        }
        yP_Row = list.get(0);
        this.storeLastEvent(string, yP_Row);
        return yP_Row;
    }

    private YP_Row getFirstEvent(String string) {
        List<YP_Row> list;
        block4: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.events);
                yP_ComplexGabarit.set("eventName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                yP_ComplexGabarit.set("isDeleted", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                yP_ComplexGabarit.set("eventAppliLocalTime", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                list = this.events.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block4;
                this.logger(3, "getFirstEvent() " + string + " not found");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getFirstEvent()  " + string, exception);
                return null;
            }
        }
        if (list.size() > 1) {
            this.logger(2, "getFirstEvent() too many events " + string);
        }
        return list.get(0);
    }

    @Override
    public int getLastEventStatus(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getLastEvent(string);
                if (yP_Row != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getLastEventStatus() " + string, exception);
                return -1;
            }
        }
        return (Integer)yP_Row.getFieldValueByName("status");
    }

    @Override
    public Timestamp getFirstEventAppliLocalTime(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getFirstEvent(string);
                if (yP_Row != null) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getFirstEventAppliLocalTime() " + string, exception);
                return null;
            }
        }
        return (Timestamp)yP_Row.getFieldValueByName("eventAppliLocalTime");
    }

    @Override
    public Timestamp getLastEventAppliLocalTime(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getLastEvent(string);
                if (yP_Row != null) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getLastEventAppliLocalTime() " + string, exception);
                return null;
            }
        }
        return (Timestamp)yP_Row.getFieldValueByName("eventAppliLocalTime");
    }

    @Override
    public Timestamp getLastEventSystemGMTTime(String string) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_Row = this.getLastEvent(string);
                if (yP_Row != null) break block3;
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getLastEventSystemGMTTime() " + string, exception);
                return null;
            }
        }
        return (Timestamp)yP_Row.getFieldValueByName("eventSystemGMTTime");
    }

    @Override
    public int setEventStatus(String string, int n) {
        this.resetFastEventFinder();
        try {
            this.events.lock();
            YP_Row yP_Row = this.events.getNewRow();
            yP_Row.set("eventName", string);
            yP_Row.set("status", n);
            yP_Row.set("eventSystemGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            yP_Row.set("eventAppliLocalTime", new Timestamp(this.dataContainer.timeInterface.getAppliLocalTime().getTimeInMillis()));
            this.events.addRow(yP_Row);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setEventStatus() " + string, exception);
        }
        finally {
            this.events.unlock();
        }
        return -1;
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int resetAllEvents() {
        this.resetFastEventFinder();
        YP_Row yP_Row = this.events.getNewRow();
        yP_Row.set("isDeleted", 1);
        try {
            this.events.updateRow(yP_Row);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "resetAllEvents() ", exception);
            return -1;
        }
    }

    @Override
    public int resetEvents(String string) {
        this.resetFastEventFinder();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.events);
        yP_ComplexGabarit.set("eventName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("isDeleted", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1);
        YP_Row yP_Row = this.events.getNewRow();
        yP_Row.set("isDeleted", 1);
        try {
            this.events.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "resetEvents()", exception);
            return -1;
        }
    }
}

