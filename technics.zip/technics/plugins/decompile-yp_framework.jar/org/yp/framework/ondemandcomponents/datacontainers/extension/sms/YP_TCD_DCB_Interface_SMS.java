/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.sms;

import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_SMS
extends YP_TCD_DCB_Interface_Extension {
    public int sendSMS(YP_TCD_DataContainer var1, String var2, String var3);
}

