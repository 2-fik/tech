/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_InternationalizationLanguage
extends YP_Row {
    @PrimaryKey
    public long idLanguage = 0L;
    @Index
    public byte[] languageCode = new byte[2];
    public byte[] languageName = new byte[32];
}

