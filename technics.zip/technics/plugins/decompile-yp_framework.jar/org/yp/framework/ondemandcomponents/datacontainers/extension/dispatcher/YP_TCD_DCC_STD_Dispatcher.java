/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher;

import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher.YP_TCD_DCC_Interface_Dispatcher;
import org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher.designaccesobjects.DAO_STD_Dispatcher;

public class YP_TCD_DCC_STD_Dispatcher
extends YP_OnDemandComponent
implements YP_TCD_DCC_Interface_Dispatcher {
    private YP_TCD_DC_Context dataContainer;
    public YP_TCD_DesignAccesObject dispatcher;

    public YP_TCD_DCC_STD_Dispatcher(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DC_Context) {
            this.dataContainer = (YP_TCD_DC_Context)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        block2: {
            super.initialize();
            try {
                this.dispatcher = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_STD_Dispatcher.class, 0, 0, null);
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block2;
                this.logger(2, "initialize" + exception);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionSTD_Dispatcher";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.dispatcher) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() time");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.dispatcher) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() time");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.dispatcher) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() time");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public YP_Row getDispatchRow(YP_Transaction yP_Transaction, String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dispatcher);
        String[] stringArray = string.split("_");
        if (stringArray == null || stringArray.length != 2) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDispatchRow() bad terminalIdentifier !!:" + string);
            }
            return null;
        }
        yP_ComplexGabarit.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.EQUAL, stringArray[0]);
        yP_ComplexGabarit.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.EQUAL, stringArray[1]);
        List<YP_Row> list = this.dispatcher.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDispatchRow() terminalIdentifier not found:" + string);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getDispatchRow() more than one dispatch !!! only the first one will be handled");
        }
        return list.get(0);
    }
}

