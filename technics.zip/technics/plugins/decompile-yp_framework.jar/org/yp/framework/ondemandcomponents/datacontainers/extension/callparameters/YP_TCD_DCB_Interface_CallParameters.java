/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters;

import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_CallParameters
extends YP_TCD_DCB_Interface_Extension {
    public List<Threshold> getThresholdList();

    public long getThresholdCall(YP_TCD_DC_Transaction var1);

    public long getMaxThresholdCall(YP_TCD_DC_Transaction var1);

    public boolean isRandomCallNeeded(YP_TCD_DC_Transaction var1);

    public Thresholds getThresholds(YP_TCD_DC_Transaction var1);

    public static class Threshold {
        public long threshold = 0L;
        public int numericalCurrencyCode = 0;
        public byte[] validationMode = new byte[1];
        public byte[] startTimeHHMM = new byte[4];
        public byte[] endTimeHHMM = new byte[4];
    }

    public static class Thresholds {
        public long defaultThreshold = 0L;
        public long manualThreshold = 0L;
        public long pinThreshold = 0L;
        public long signatureThreshold = 0L;
        public long pinAndSignatureThreshold = 0L;
    }
}

