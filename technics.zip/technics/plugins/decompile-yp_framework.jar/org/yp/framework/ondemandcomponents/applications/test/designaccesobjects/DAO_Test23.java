/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test23
extends YP_Row {
    @PrimaryKey
    public long idTest23 = 0L;
    public int test23Int = 0;
    public Boolean test23Boolean;
}

