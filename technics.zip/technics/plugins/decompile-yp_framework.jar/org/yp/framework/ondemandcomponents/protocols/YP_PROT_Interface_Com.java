/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols;

import org.yp.designaccesobjects.YP_Row;

public interface YP_PROT_Interface_Com {
    public int waitConnection();

    public int waitDisconnection();

    public int connect(YP_Row var1);

    public void send(byte[] var1, boolean var2) throws TimeOutException, DisconnectionException;

    public int disconnect();

    public byte[] receive(boolean var1) throws TimeOutException, DisconnectionException, BadFormatException;

    public int shutdown();

    public int setParameters(Object ... var1);

    public String getParameter(String var1);

    public int setComParameter(String var1, String var2);

    public static class BadFormatException
    extends Exception {
        private static final long serialVersionUID = -8683844530757695786L;
    }

    public static enum ComStateMachine {
        DISCONNECTED,
        WAIT_CONNECTION,
        CONNECT,
        CONNECTED,
        WAIT_DISCONNECTION;

    }

    public static class ConnectionException
    extends Exception {
        private static final long serialVersionUID = -846330806419781141L;
    }

    public static class DisconnectionException
    extends Exception {
        private static final long serialVersionUID = 6391124303637080000L;
    }

    public static class TimeOutException
    extends Exception {
        private static final long serialVersionUID = 2829767267775643602L;
        public String timerName;
    }
}

