/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_GlobalProcessManager;

public final class YP_TCD_DCC_Group
extends YP_TCD_DC_Context {
    private YP_Row groupRow;
    private String groupName;
    private String groupLabel;
    private long idGroup = 0L;
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    private List<YP_TCD_DCC_Brand> dataContainerBrandList = new ArrayList<YP_TCD_DCC_Brand>();

    public YP_TCD_DCC_Group(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray != null && objectArray.length > 0 && objectArray[0] != null && objectArray[0] instanceof YP_Row) {
                this.setGroupRow((YP_Row)objectArray[0]);
            }
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    public final void setGroupRow(YP_Row yP_Row) {
        this.groupRow = yP_Row;
        this.idGroup = this.groupRow.getPrimaryKey();
        this.groupName = this.groupRow.getFieldStringValueByName("groupName");
        this.groupLabel = this.groupRow.getFieldStringValueByName("groupLabel");
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int shutdown() {
        this.groupRow = null;
        this.dataContainerBrandList.clear();
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerGroup";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        this.logger(2, "dealRequest() unhnwown request: " + string);
        return null;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public String getGroupLabel() {
        return this.groupLabel;
    }

    public YP_Row getGroupRow() {
        return this.groupRow;
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    public long getIDGroup() {
        return this.idGroup;
    }
}

