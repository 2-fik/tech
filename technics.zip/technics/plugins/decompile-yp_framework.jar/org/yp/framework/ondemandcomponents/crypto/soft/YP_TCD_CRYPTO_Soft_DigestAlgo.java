/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.soft;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_DigestAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.utils.UtilsYP;

public class YP_TCD_CRYPTO_Soft_DigestAlgo
implements YP_TCD_CRYPTO_DigestAlgo_Interface {
    private final YP_TCD_CRYPTO_Module father;
    private final List<MyMessageDigest> messageDigestList = new ArrayList<MyMessageDigest>();
    private final ReentrantLock messageDigestListMutex = new ReentrantLock();

    public YP_TCD_CRYPTO_Soft_DigestAlgo(YP_Object yP_Object) {
        this.father = (YP_TCD_CRYPTO_Module)yP_Object;
    }

    private MyMessageDigest createDigestElement(String string) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(string);
            return new MyMessageDigest(messageDigest, 1, string);
        }
        catch (Exception exception) {
            this.father.logger(2, "createEncryptCipher()" + exception);
            return null;
        }
    }

    private int recreateEncryptCipher(MyMessageDigest myMessageDigest) {
        try {
            MessageDigest messageDigest;
            myMessageDigest.messageDigest = messageDigest = MessageDigest.getInstance(myMessageDigest.algo);
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "recreateEncryptCipher()" + exception);
            return 0;
        }
    }

    private MyMessageDigest getDigestElement(String string) {
        this.messageDigestListMutex.lock();
        try {
            MyMessageDigest myMessageDigest2;
            for (MyMessageDigest myMessageDigest2 : this.messageDigestList) {
                if (myMessageDigest2.status != 0 || !myMessageDigest2.algo.contentEquals(string)) continue;
                myMessageDigest2.status = 1;
                MyMessageDigest myMessageDigest3 = myMessageDigest2;
                return myMessageDigest3;
            }
            myMessageDigest2 = this.createDigestElement(string);
            this.messageDigestList.add(myMessageDigest2);
            MyMessageDigest myMessageDigest4 = myMessageDigest2;
            return myMessageDigest4;
        }
        catch (Exception exception) {
            this.father.logger(2, "getDigestElement()" + exception);
            return null;
        }
        finally {
            this.messageDigestListMutex.unlock();
        }
    }

    private int releaseDigestElement(MyMessageDigest myMessageDigest) {
        for (MyMessageDigest myMessageDigest2 : this.messageDigestList) {
            if (myMessageDigest2.messageDigest != myMessageDigest.messageDigest) continue;
            myMessageDigest2.status = 0;
            return 1;
        }
        if (this.father.getLogLevel() >= 2) {
            this.father.logger(2, "releaseMessageDigest() not found !!!");
        }
        return 0;
    }

    @Override
    public String digest(String string, byte[] byArray) throws Exception {
        MyMessageDigest myMessageDigest;
        if (this.father.getLogLevel() >= 5) {
            this.father.logger(5, "digest() " + string);
        }
        if ((myMessageDigest = this.getDigestElement(string)) != null) {
            try {
                myMessageDigest.messageDigest.update(byArray);
                String string2 = UtilsYP.devHexa(myMessageDigest.messageDigest.digest());
                return string2;
            }
            catch (Exception exception) {
                this.recreateEncryptCipher(myMessageDigest);
                throw exception;
            }
            finally {
                this.releaseDigestElement(myMessageDigest);
            }
        }
        this.father.logger(2, "digest() unable to create digest message");
        return null;
    }

    @Override
    public String digest(String string, String string2) throws Exception {
        return this.digest(string, string2.getBytes());
    }

    @Override
    public int isCryptoSupported(String string) {
        try {
            MessageDigest.getInstance(string, this.father.getProviderName());
            return 1;
        }
        catch (NoSuchAlgorithmException | NoSuchProviderException generalSecurityException) {
            if (this.father.getLogLevel() >= 5) {
                this.father.logger(5, "isCryptoSupported() algo not supported:" + string + " " + generalSecurityException);
            }
            return 0;
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "isCryptoSupported() " + exception);
            }
            return -1;
        }
    }

    @Override
    public int isDigestSupported(String string) {
        return this.isCryptoSupported(string);
    }

    private class MyMessageDigest {
        public MessageDigest messageDigest;
        public int status;
        private final String algo;

        public MyMessageDigest(MessageDigest messageDigest, int n, String string) {
            this.messageDigest = messageDigest;
            this.status = n;
            this.algo = string;
        }
    }
}

