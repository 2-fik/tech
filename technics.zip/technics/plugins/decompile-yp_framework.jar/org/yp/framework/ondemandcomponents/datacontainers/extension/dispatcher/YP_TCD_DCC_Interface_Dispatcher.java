/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCC_Interface_Dispatcher
extends YP_TCD_DCB_Interface_Extension {
    public YP_Row getDispatchRow(YP_Transaction var1, String var2);
}

