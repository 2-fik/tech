/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test9
extends YP_Row {
    @PrimaryKey
    public long idTest9 = 0L;
    public byte[] test9CharArray01 = new byte[10];
    public byte[] test9CharArray02 = new byte[10];
    public byte[] test9CharArray03 = new byte[10];
    public byte[] test9CharArray04 = new byte[10];
    public byte[] test9CharArray05 = new byte[10];
    public byte[] test9CharArray06 = new byte[10];
    public byte[] test9CharArray07 = new byte[10];
    public byte[] test9CharArray08 = new byte[10];
    public byte[] test9CharArray09 = new byte[10];
    public byte[] test9CharArray10 = new byte[10];
    public byte[] test9CharArray11 = new byte[10];
    public byte[] test9CharArray12 = new byte[10];
    public byte[] test9CharArray13 = new byte[10];
    public byte[] test9CharArray14 = new byte[10];
    public byte[] test9CharArray15 = new byte[10];
    public byte[] test9CharArray16 = new byte[10];
    public byte[] test9CharArray17 = new byte[10];
    public byte[] test9CharArray18 = new byte[10];
    public byte[] test9CharArray19 = new byte[10];
    public byte[] test9CharArray20 = new byte[10];
    public byte[] test9CharArray21 = new byte[10];
    public byte[] test9CharArray22 = new byte[10];
    public byte[] test9CharArray23 = new byte[10];
    public byte[] test9CharArray24 = new byte[10];
    public byte[] test9CharArray25 = new byte[10];
    public byte[] test9CharArray26 = new byte[10];
    public byte[] test9CharArray27 = new byte[10];
    public byte[] test9CharArray28 = new byte[10];
    public byte[] test9CharArray29 = new byte[10];
    public byte[] test9CharArray30 = new byte[10];
    public byte[] test9CharArray31 = new byte[10];
    public byte[] test9CharArray32 = new byte[10];
    public byte[] test9CharArray33 = new byte[10];
    public byte[] test9CharArray34 = new byte[10];
    public byte[] test9CharArray35 = new byte[10];
    public byte[] test9CharArray36 = new byte[10];
    public byte[] test9CharArray37 = new byte[10];
    public byte[] test9CharArray38 = new byte[10];
    public byte[] test9CharArray39 = new byte[10];
    public byte[] test9CharArray40 = new byte[10];
    public byte[] test9CharArray41 = new byte[10];
    public byte[] test9CharArray42 = new byte[10];
    public byte[] test9CharArray43 = new byte[10];
    public byte[] test9CharArray44 = new byte[10];
    public byte[] test9CharArray45 = new byte[10];
    public byte[] test9CharArray46 = new byte[10];
    public byte[] test9CharArray47 = new byte[10];
    public byte[] test9CharArray48 = new byte[10];
    public byte[] test9CharArray49 = new byte[10];
    public byte[] test9CharArray50 = new byte[10];
}

