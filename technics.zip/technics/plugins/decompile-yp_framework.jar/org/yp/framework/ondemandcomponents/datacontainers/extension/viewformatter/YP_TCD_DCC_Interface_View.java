/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter;

import java.util.List;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;

public interface YP_TCD_DCC_Interface_View
extends YP_TCD_DCB_Interface_Extension {
    public long getIdView(String var1);

    public List<DAO_ViewColumn> getColumns(String var1, int var2);

    public List<DAO_ViewColumn> getColumns(long var1, int var3);

    public long getIdEnum(long var1);

    @Deprecated
    public List<DAO_ViewColumnCustomization> getColumnCustomization(long var1);

    public List<DAO_ViewColumnCustomization> getColumnCustomization(long var1, List<DAO_ViewColumn> var3);

    public DAO_ViewColumnCustomization createColumnCustomization(long var1, long var3);

    public DAO_View getViewRow(String var1);

    public YP_TCD_DesignAccesObject getDAOColumn();

    public boolean isWriteAllowed(long var1, int var3);

    public List<String> getViewList(int var1);
}

