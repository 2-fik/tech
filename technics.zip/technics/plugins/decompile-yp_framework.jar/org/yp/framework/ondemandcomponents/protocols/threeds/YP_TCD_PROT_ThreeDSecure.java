/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyException;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.threeds.PARes;
import org.yp.xml.jaxb.threeds.ThreeDSecure;
import org.yp.xml.jaxb.threeds.VERes;

public class YP_TCD_PROT_ThreeDSecure
extends YP_OnDemandComponent
implements YP_PROT_Interface_Com {
    private ThreeDSecure objectToSend = null;
    private ThreeDSecure objectReceived = null;
    private byte[] responseByte;
    private YP_GlobalComponent parserXML = null;
    private YP_PHYS_Interface physicalInterface;
    private int physicalInterfaceToShutdown = 0;
    private YP_PROT_Interface_Com.ComStateMachine myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
    private byte[] recvBuffer = new byte[10000];
    private boolean timeoutOccured = false;
    private long timeoutTime = 0L;

    public YP_TCD_PROT_ThreeDSecure(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager)) {
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PHYS_Interface) {
                this.physicalInterface = (YP_PHYS_Interface)objectArray[0];
                this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
            }
            this.parserXML = (YP_GlobalComponent)this.getPluginByName("ThreeDSecureParser");
        }
    }

    public int YP_Disconnect() {
        this.resetTimer();
        this.disconnect();
        return 1;
    }

    public String YP_FormatXMLPAReq(ThreeDSecure threeDSecure) {
        if (threeDSecure == null) {
            return null;
        }
        try {
            String string = (String)this.parserXML.dealRequest(this, "objectToXML", threeDSecure);
            if (this.getLogLevel() >= 4) {
                this.logger(4, "YP_FormatXMLPAReq() : " + string);
            }
            return string;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "YP_FormatXMLPAReq() " + exception);
            }
            return null;
        }
    }

    public boolean checkSignatureDocument() {
        return this.checkSignatureDocument(this.responseByte);
    }

    /*
     * Recovered potentially malformed switches.  Disable with '--allowmalformedswitch false'
     * Enabled aggressive block sorting
     */
    private boolean isPaResValid() {
        PARes pARes = this.objectReceived.getMessage().get(0).getPARes();
        if (pARes == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isMessageValid() messageToCheck is not a paRes");
            }
            return false;
        }
        String string = pARes.getTX().getStatus();
        if (string == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isMessageValid() messageToCheck TX.status missing");
            }
            return false;
        }
        switch (string.toUpperCase()) {
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck TX.status uncorrect value: " + string);
                }
                return false;
            }
            case "A": 
            case "N": 
            case "U": 
            case "Y": 
        }
        if (string.toUpperCase().contentEquals("A") || string.toUpperCase().contentEquals("Y")) {
            if (pARes.getTX().getCavv() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck TX.cavv missing");
                }
                return false;
            }
            if (pARes.getTX().getCavvAlgorithm() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck TX.cavvAlgorithm missing");
                }
                return false;
            }
            switch (pARes.getTX().getCavvAlgorithm()) {
                default: {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "isMessageValid() messageToCheck TX.cavvAlgorithm incorrect value: " + pARes.getTX().getCavvAlgorithm());
                    }
                    return false;
                }
                case "0": 
                case "1": 
                case "2": 
                case "3": 
            }
            if (pARes.getTX().getEci() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck TX.eci missing");
                }
                return false;
            }
        }
        return true;
    }

    /*
     * Recovered potentially malformed switches.  Disable with '--allowmalformedswitch false'
     * Enabled aggressive block sorting
     */
    private boolean isVeResValid() {
        VERes vERes = this.objectReceived.getMessage().get(0).getVERes();
        if (vERes == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isMessageValid() messageToCheck is not a veRes");
            }
            return false;
        }
        String string = vERes.getCH().getEnrolled();
        if (string == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isMessageValid() messageToCheck CH.enrolled missing");
            }
            return false;
        }
        switch (string.toUpperCase()) {
            default: {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck CH.enrolled uncorrect value: " + string);
                }
                return false;
            }
            case "N": 
            case "U": 
            case "Y": 
        }
        if (string.toUpperCase().contentEquals("Y")) {
            if (vERes.getProtocol() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck protocol should be present");
                }
                return false;
            }
            if (vERes.getCH().getAcctID() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck CH.acctID should be present");
                }
                return false;
            }
            if (vERes.getUrl() == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "isMessageValid() messageToCheck ACS url should be present");
                }
                return false;
            }
        }
        return true;
    }

    public boolean isMessageValid(String string) {
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isMessageValid() messageToCheck null");
            }
            return false;
        }
        switch (string) {
            case "paRes": {
                return this.isPaResValid();
            }
            case "veRes": {
                return this.isVeResValid();
            }
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "isMessageValid() messageToCheck unknown: " + string);
        }
        return false;
    }

    public boolean checkSignatureDocument(byte[] byArray) {
        XMLSignature xMLSignature;
        DOMValidateContext dOMValidateContext;
        block10: {
            block9: {
                NodeList nodeList;
                block8: {
                    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                    documentBuilderFactory.setNamespaceAware(true);
                    Document document = documentBuilderFactory.newDocumentBuilder().parse(new ByteArrayInputStream(byArray));
                    Element element = document.getDocumentElement();
                    Element element2 = (Element)element.getElementsByTagName("PARes").item(0);
                    element2.setIdAttributeNode(element2.getAttributeNodeNS(null, "id"), true);
                    nodeList = document.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature");
                    if (nodeList != null && nodeList.getLength() != 0) break block8;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "checkSignatureDocument() Cannot find Signature element");
                    }
                    return false;
                }
                dOMValidateContext = new DOMValidateContext(new KeyValueKeySelector(), nodeList.item(0));
                XMLSignatureFactory xMLSignatureFactory = XMLSignatureFactory.getInstance("DOM");
                xMLSignature = xMLSignatureFactory.unmarshalXMLSignature(dOMValidateContext);
                boolean bl = xMLSignature.validate(dOMValidateContext);
                if (!bl) break block9;
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "checkSignatureDocument() Signature passed core validation");
                }
                return true;
            }
            this.logger(2, "checkSignatureDocument() Signature failed core validation");
            boolean bl = xMLSignature.getSignatureValue().validate(dOMValidateContext);
            if (!bl) break block10;
            this.logger(4, "checkSignatureDocument() signature validation status: OK");
            return false;
        }
        try {
            Iterator<Reference> iterator = xMLSignature.getSignedInfo().getReferences().iterator();
            int n = 0;
            while (iterator.hasNext()) {
                Reference reference = iterator.next();
                boolean bl = reference.validate(dOMValidateContext);
                this.logger(4, "checkSignatureDocument() ref[" + n + "] validity status: " + bl);
                this.logger(4, "checkSignatureDocument() digest : " + new String(reference.getCalculatedDigestValue()));
                ++n;
            }
        }
        catch (Exception exception) {
            this.logger(2, "checkSignatureDocument() " + exception);
        }
        return false;
    }

    public byte[] signDocument(String string) {
        XMLSignatureFactory xMLSignatureFactory = XMLSignatureFactory.getInstance("DOM");
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] cArray = "slpc1515".toCharArray();
            FileInputStream fileInputStream = new FileInputStream("C:\\YP\\keystore\\intermediate\\intermediate.keystore");
            keyStore.load(fileInputStream, cArray);
            fileInputStream.close();
            Key key = keyStore.getKey("userYPHost", cArray);
            KeyInfoFactory keyInfoFactory = xMLSignatureFactory.getKeyInfoFactory();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "signDocument() " + keyStore.getCertificate("userYPHost").toString());
            }
            PublicKey publicKey = keyStore.getCertificate("userYPHost").getPublicKey();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "signDocument() " + publicKey.toString());
            }
            Certificate[] certificateArray = keyStore.getCertificateChain("userYPHost");
            ArrayList<X509Certificate> arrayList = new ArrayList<X509Certificate>();
            int n = 0;
            while (n < certificateArray.length) {
                arrayList.add((X509Certificate)certificateArray[n]);
                ++n;
            }
            X509Data x509Data = keyInfoFactory.newX509Data(arrayList);
            KeyInfo keyInfo = keyInfoFactory.newKeyInfo(Collections.singletonList(x509Data));
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            documentBuilderFactory.setNamespaceAware(true);
            Document document = documentBuilderFactory.newDocumentBuilder().parse(new ByteArrayInputStream(string.getBytes()));
            Element element = document.getDocumentElement();
            Element element2 = (Element)element.getElementsByTagName("PARes").item(0);
            String string2 = "#" + element2.getAttribute("id");
            Reference reference = xMLSignatureFactory.newReference(string2, xMLSignatureFactory.newDigestMethod("http://www.w3.org/2000/09/xmldsig#sha1", null), null, null, null);
            SignedInfo signedInfo = xMLSignatureFactory.newSignedInfo(xMLSignatureFactory.newCanonicalizationMethod("http://www.w3.org/TR/2001/REC-xml-c14n-20010315", (C14NMethodParameterSpec)null), xMLSignatureFactory.newSignatureMethod("http://www.w3.org/2000/09/xmldsig#rsa-sha1", null), Collections.singletonList(reference));
            XMLSignature xMLSignature = xMLSignatureFactory.newXMLSignature(signedInfo, keyInfo);
            Element element3 = (Element)element.getElementsByTagName("Message").item(0);
            DOMSignContext dOMSignContext = new DOMSignContext(key, (Node)element3);
            xMLSignature.sign(dOMSignContext);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            transformer.transform(new DOMSource(document), new StreamResult(byteArrayOutputStream));
            byteArrayOutputStream.flush();
            byte[] byArray = byteArrayOutputStream.toByteArray();
            byteArrayOutputStream.close();
            return byArray;
        }
        catch (Exception exception) {
            this.logger(2, "signDocument() " + exception);
            return null;
        }
    }

    public int YP_FormatAndSendPARes(ThreeDSecure threeDSecure) {
        String string;
        if (threeDSecure == null) {
            return -1;
        }
        try {
            string = (String)this.parserXML.dealRequest(this, "objectToXML", threeDSecure);
        }
        catch (Exception exception) {
            this.logger(2, "YP_FormatAndSendPARes() " + exception);
            return -2;
        }
        byte[] byArray = this.signDocument(string);
        if (byArray == null) {
            return -3;
        }
        this.logger(5, "YP_FormatAndSendPARes() message sent:" + new String(byArray).replace(">", ">\r\n"));
        try {
            this.send(byArray, true);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_FormatAndSendPARes() message sent");
            }
            return 1;
        }
        catch (YP_PROT_Interface_Com.TimeOutException timeOutException) {
            this.logger(2, "YP_FormatAndSendPARes() Nothing has been sent ( a timeout has expired) ");
            return -4;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException disconnectionException) {
            this.logger(2, "YP_FormatAndSendPARes() The connection is dead ");
            return -5;
        }
        catch (Exception exception) {
            this.logger(2, "YP_FormatAndSendPARes() " + exception);
            return -6;
        }
    }

    public int YP_Send() {
        String string;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "YP_Send()");
        }
        try {
            string = (String)this.parserXML.dealRequest(this, "objectToXML", this.objectToSend);
        }
        catch (Exception exception) {
            this.logger(2, "YP_Send() format XML message failed" + exception);
            return -1;
        }
        try {
            this.send(string.getBytes(), true);
            if (this.getLogLevel() >= 5) {
                this.logger(5, "YP_Send() message sent");
            }
            return 1;
        }
        catch (YP_PROT_Interface_Com.TimeOutException timeOutException) {
            this.logger(2, "YP_Send() Nothing has been sent ( a timeout has expired) ");
            return 0;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException disconnectionException) {
            this.logger(2, "YP_Send() The connection is dead ");
            return -3;
        }
        catch (Exception exception) {
            this.logger(2, "YP_Send() " + exception);
            return -2;
        }
    }

    public ThreeDSecure YP_GetNewSendFactoryObject(String string) {
        try {
            this.objectToSend = (ThreeDSecure)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
        }
        catch (Exception exception) {
            this.logger(2, "YP_GetNewSendFactoryObject() " + exception);
            return null;
        }
        return this.objectToSend;
    }

    public void YP_SetObjectToSend(ThreeDSecure threeDSecure) {
        this.objectToSend = threeDSecure;
    }

    public ThreeDSecure YP_GetSendFactoryObject() {
        return this.objectToSend;
    }

    public ThreeDSecure YP_GetReceiveFactoryObject() {
        return this.objectReceived;
    }

    public int YP_Receive() {
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
            this.logger(2, "YP_Receive() not connected !!!");
            return -2;
        }
        try {
            this.responseByte = this.receive(true);
        }
        catch (YP_PROT_Interface_Com.TimeOutException timeOutException) {
            this.logger(2, "YP_Receive()" + timeOutException);
            return -3;
        }
        catch (YP_PROT_Interface_Com.DisconnectionException disconnectionException) {
            this.logger(2, "YP_Receive()" + disconnectionException);
            return -3;
        }
        catch (YP_PROT_Interface_Com.BadFormatException badFormatException) {
            this.logger(2, "YP_Receive()" + badFormatException);
            return -3;
        }
        if (this.responseByte == null) {
            this.logger(2, "YP_Receive() connection lost ?");
            return -3;
        }
        if (this.responseByte.length == 0) {
            this.logger(2, "YP_Receive() nothing received");
            return 0;
        }
        try {
            this.objectReceived = (ThreeDSecure)this.parserXML.dealRequest(this, "xmlToObject", new Object[]{this.responseByte});
        }
        catch (Exception exception) {
            this.logger(2, "YP_Receive() parse XML message failed  " + exception);
            return -1;
        }
        return 1;
    }

    @Override
    public String toString() {
        return "THREEDSECURE_PROTOCOL";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public MessageType getMessageType(ThreeDSecure threeDSecure) {
        if (threeDSecure.getMessage().get(0).getVEReq() != null) {
            return MessageType.VEReq;
        }
        if (threeDSecure.getMessage().get(0).getVERes() != null) {
            return MessageType.VERes;
        }
        if (threeDSecure.getMessage().get(0).getCRReq() != null) {
            return MessageType.CRReq;
        }
        if (threeDSecure.getMessage().get(0).getCRRes() != null) {
            return MessageType.CRRes;
        }
        if (threeDSecure.getMessage().get(0).getPAReq() != null) {
            return MessageType.PAReq;
        }
        if (threeDSecure.getMessage().get(0).getPARes() != null) {
            return MessageType.PARes;
        }
        if (threeDSecure.getMessage().get(0).getSignature() != null) {
            return MessageType.Signature;
        }
        return MessageType.VEReq;
    }

    public ThreeDSecure getObjectFromXMLFile(String string) {
        try {
            if (string == null) {
                this.logger(2, "getObjectFromXMLFile() No file given...");
            }
            return (ThreeDSecure)this.parserXML.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + string);
        }
        catch (Exception exception) {
            this.logger(2, "getObjectFromXMLFile() " + exception + string);
            return null;
        }
    }

    public boolean isSignatureCorrect() {
        this.getObjectFromXMLFile("/technics/xml/threeds/exemple-pares.xml");
        return false;
    }

    public Object getMessage(ThreeDSecure threeDSecure) {
        switch (this.getMessageType(threeDSecure)) {
            default: {
                return threeDSecure.getMessage().get(0).getVEReq();
            }
            case VERes: {
                return threeDSecure.getMessage().get(0).getVERes();
            }
            case CRReq: {
                return threeDSecure.getMessage().get(0).getCRReq();
            }
            case CRRes: {
                return threeDSecure.getMessage().get(0).getCRRes();
            }
            case PAReq: {
                return threeDSecure.getMessage().get(0).getPAReq();
            }
            case PARes: 
        }
        return threeDSecure.getMessage().get(0).getPARes();
    }

    @Override
    public int connect(YP_Row yP_Row) {
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 1;
        }
        try {
            YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
            this.physicalInterface = (YP_PHYS_Interface)yP_Service.dealRequest(this, "openConnection", yP_Row);
            if (this.physicalInterface == null) {
                this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
            return -1;
        }
        this.physicalInterfaceToShutdown = 1;
        this.myState = YP_PROT_Interface_Com.ComStateMachine.CONNECTED;
        return 1;
    }

    @Override
    public int disconnect() {
        if (this.myState == YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED) {
            return 0;
        }
        this.myState = YP_PROT_Interface_Com.ComStateMachine.DISCONNECTED;
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "disconnect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    private boolean isTimeoutOccured() {
        if (this.timeoutTime != 0L && System.currentTimeMillis() > this.timeoutTime) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "isTimeoutOccured() Time's up!");
            }
            this.timeoutOccured = true;
        }
        return this.timeoutOccured;
    }

    private void resetTimer() {
        this.timeoutOccured = false;
        this.timeoutTime = 0L;
    }

    private void setTimer(int n) {
        this.timeoutOccured = false;
        this.timeoutTime = 0L;
        this.timeoutTime = System.currentTimeMillis() + (long)n;
    }

    @Override
    public byte[] receive(boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException, YP_PROT_Interface_Com.BadFormatException {
        Object object;
        if (this.myState != YP_PROT_Interface_Com.ComStateMachine.CONNECTED) {
            this.logger(2, "receive() not connected !!!");
            return null;
        }
        int n = 0;
        int n2 = 0;
        this.setTimer(9000);
        while (n == 0) {
            int n3 = 0;
            while (!this.isTimeoutOccured() && n3 == 0) {
                if (this.recvBuffer.length < n2 + 10000) {
                    object = this.recvBuffer;
                    this.recvBuffer = Arrays.copyOf(object, n2 + 10000);
                }
                n3 = this.physicalInterface.recv(this.recvBuffer, n2, this.recvBuffer.length - n2, 3000);
            }
            if (this.timeoutOccured && n3 == 0) {
                this.logger(2, "receive() TimeOut ");
                object = new YP_PROT_Interface_Com.TimeOutException();
                this.resetTimer();
                throw object;
            }
            if (n3 < 0) {
                this.logger(2, "receive() broken connection");
                throw new YP_PROT_Interface_Com.DisconnectionException();
            }
            if (n3 == 0) {
                this.logger(2, "receive() TimeOut");
                return new byte[0];
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "receive() Received Data: " + n3);
            }
            if (UtilsYP.indexOf(this.recvBuffer, 0, n2 += n3, "/ThreeDSecure>") == -1) {
                this.logger(3, "receive() not everything ???: " + new String(this.recvBuffer));
                n = 0;
                continue;
            }
            n = 1;
        }
        this.resetTimer();
        if (n < 0) {
            this.logger(2, "receive() reception pb");
            throw new YP_PROT_Interface_Com.BadFormatException();
        }
        object = new byte[n2];
        System.arraycopy(this.recvBuffer, 0, object, 0, ((byte[])object).length);
        return object;
    }

    @Override
    public void send(byte[] byArray, boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException {
        int n = this.physicalInterface.send(byArray, byArray.length);
        if (n < 0) {
            this.logger(2, "send() broken connection");
            throw new YP_PROT_Interface_Com.DisconnectionException();
        }
    }

    @Override
    public int setParameters(Object ... objectArray) {
        this.logger(2, "setParameters() TODO");
        return 0;
    }

    @Override
    public int waitConnection() {
        this.logger(2, "waitConnection() no need");
        return -1;
    }

    @Override
    public String getParameter(String string) {
        return null;
    }

    @Override
    public int waitDisconnection() {
        return 0;
    }

    @Override
    public int setComParameter(String string, String string2) {
        return 0;
    }

    private class KeyValueKeySelector
    extends KeySelector {
        private KeyValueKeySelector() {
        }

        @Override
        public KeySelectorResult select(KeyInfo keyInfo, KeySelector.Purpose purpose, AlgorithmMethod algorithmMethod, XMLCryptoContext xMLCryptoContext) throws KeySelectorException {
            Object object;
            Object object2;
            Object object3;
            KeyStore keyStore;
            Iterator<XMLStructure> iterator = keyInfo.getContent().iterator();
            try {
                keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                object3 = "slpc1515".toCharArray();
                object2 = YP_TCD_PROT_ThreeDSecure.this.getProperty("business/properties/KERNEL/directory_parameter.properties", "TRUSTSTORE");
                if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() >= 4 && object2 != null) {
                    YP_TCD_PROT_ThreeDSecure.this.logger(4, "KeyValueKeySelector() trustedkeystore: " + (String)object2);
                }
                object = new FileInputStream((String)object2);
                keyStore.load((InputStream)object, (char[])object3);
                ((FileInputStream)object).close();
            }
            catch (Exception exception) {
                if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() >= 2) {
                    YP_TCD_PROT_ThreeDSecure.this.logger(2, "select() " + exception);
                }
                return null;
            }
            object3 = new ArrayList();
            while (iterator.hasNext()) {
                object = iterator.next();
                if (object instanceof X509Data) {
                    Object object42;
                    object2 = (X509Data)object;
                    for (Object object42 : object2.getContent()) {
                        if (!(object42 instanceof X509Certificate)) continue;
                        X509Certificate x509Certificate = (X509Certificate)object42;
                        x509Certificate.getIssuerX500Principal();
                        object3.add(x509Certificate);
                        if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() >= 5) {
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() key : " + x509Certificate.getPublicKey());
                        }
                        try {
                            x509Certificate.checkValidity();
                            int n = x509Certificate.getBasicConstraints();
                            if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() < 5) continue;
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() key : " + x509Certificate.getPublicKey());
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() CA : " + n);
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() certificat : " + x509Certificate);
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() certificat name : " + x509Certificate.getIssuerX500Principal().getName());
                            YP_TCD_PROT_ThreeDSecure.this.logger(5, "select() certificat : " + x509Certificate.getIssuerX500Principal());
                        }
                        catch (Exception exception) {
                            YP_TCD_PROT_ThreeDSecure.this.logger(2, "select() " + exception);
                            return null;
                        }
                    }
                    if (!this.checkCertificateValidity(keyStore, (List<X509Certificate>)object3)) continue;
                    object42 = this.getCertificatePubliKey((List<X509Certificate>)object3);
                    if (!this.algEquals(algorithmMethod.getAlgorithm(), object42.getAlgorithm())) continue;
                    return new KeySelectorResult((PublicKey)object42){
                        private final /* synthetic */ PublicKey val$key;
                        {
                            this.val$key = publicKey;
                        }

                        @Override
                        public Key getKey() {
                            return this.val$key;
                        }
                    };
                }
                if (!(object instanceof KeyValue)) continue;
                object2 = null;
                try {
                    object2 = ((KeyValue)object).getPublicKey();
                }
                catch (KeyException keyException) {
                    throw new KeySelectorException(keyException);
                }
                if (!this.algEquals(algorithmMethod.getAlgorithm(), object2.getAlgorithm())) continue;
                return new SimpleKeySelectorResult((PublicKey)object2);
            }
            throw new KeySelectorException("No key found!");
        }

        public boolean isReference(List<X509Certificate> list, X509Certificate x509Certificate) {
            String string = x509Certificate.getSubjectX500Principal().getName();
            int n = 0;
            while (n < list.size()) {
                if (list.get(n).getIssuerX500Principal().getName().compareTo(string) == 0) {
                    return true;
                }
                ++n;
            }
            return false;
        }

        public boolean isItReferenced(List<X509Certificate> list, X509Certificate x509Certificate) {
            String string = x509Certificate.getIssuerX500Principal().getName();
            int n = 0;
            while (n < list.size()) {
                if (!list.get(n).equals(x509Certificate) && list.get(n).getSubjectX500Principal().getName().compareTo(string) == 0) {
                    return true;
                }
                ++n;
            }
            return false;
        }

        public PublicKey getCertificatePubliKey(List<X509Certificate> list) {
            int n = 0;
            while (n < list.size()) {
                X509Certificate x509Certificate = list.get(n);
                if (!this.isReference(list, x509Certificate) && this.isItReferenced(list, x509Certificate)) {
                    return x509Certificate.getPublicKey();
                }
                ++n;
            }
            return null;
        }

        public PublicKey getPublicKey(List<X509Certificate> list, X509Certificate x509Certificate) {
            if (list == null || list.size() <= 0) {
                return null;
            }
            if (x509Certificate == null) {
                return null;
            }
            String string = x509Certificate.getIssuerX500Principal().getName();
            if (string == null) {
                return null;
            }
            int n = 0;
            while (n < list.size()) {
                if (list.get(n).getSubjectX500Principal().getName().compareTo(string) == 0) {
                    return list.get(n).getPublicKey();
                }
                ++n;
            }
            return null;
        }

        public boolean isCertificatTrustable(KeyStore keyStore, X509Certificate x509Certificate) {
            x509Certificate.getIssuerDN();
            x509Certificate.getIssuerX500Principal();
            try {
                if (keyStore.getCertificateAlias(x509Certificate) != null) {
                    if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() >= 5) {
                        YP_TCD_PROT_ThreeDSecure.this.logger(5, "isCertificatTrustable() certificate " + x509Certificate.getSubjectDN() + " trustable");
                    }
                    return true;
                }
            }
            catch (Exception exception) {
                YP_TCD_PROT_ThreeDSecure.this.logger(2, "isCertificatTrustable() " + exception);
            }
            if (YP_TCD_PROT_ThreeDSecure.this.getLogLevel() >= 5) {
                YP_TCD_PROT_ThreeDSecure.this.logger(5, "isCertificatTrustable() certificate " + x509Certificate.getSubjectDN() + " not trustable");
            }
            return false;
        }

        private boolean checkCertificateValidity(KeyStore keyStore, List<X509Certificate> list) {
            boolean bl = false;
            if (list == null || list.size() <= 0) {
                return false;
            }
            int n = 0;
            while (n < list.size()) {
                PublicKey publicKey;
                if (!bl) {
                    bl = this.isCertificatTrustable(keyStore, list.get(n));
                }
                if ((publicKey = this.getPublicKey(list, list.get(n))) == null) {
                    return false;
                }
                try {
                    list.get(n).verify(publicKey);
                }
                catch (Exception exception) {
                    YP_TCD_PROT_ThreeDSecure.this.logger(2, "checkCertificateValidity() " + exception);
                    return false;
                }
                ++n;
            }
            return bl;
        }

        boolean algEquals(String string, String string2) {
            if (string2.equalsIgnoreCase("DSA") && string.equalsIgnoreCase("http://www.w3.org/2000/09/xmldsig#dsa-sha1")) {
                return true;
            }
            return string2.equalsIgnoreCase("RSA") && string.equalsIgnoreCase("http://www.w3.org/2000/09/xmldsig#rsa-sha1");
        }
    }

    public static enum MessageType {
        VEReq,
        VERes,
        CRReq,
        CRRes,
        PAReq,
        PARes,
        Signature;

    }

    private static class SimpleKeySelectorResult
    implements KeySelectorResult {
        private final PublicKey pk;

        SimpleKeySelectorResult(PublicKey publicKey) {
            this.pk = publicKey;
        }

        @Override
        public Key getKey() {
            return this.pk;
        }
    }
}

