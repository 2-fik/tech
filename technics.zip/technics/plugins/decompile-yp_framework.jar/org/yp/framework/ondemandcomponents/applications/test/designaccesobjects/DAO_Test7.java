/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test7
extends YP_Row {
    @PrimaryKey
    public long idTest7 = 0L;
    public long test7Long = 0L;
    public int test7Int = 0;
    public float test7Float = 0.0f;
    public byte[] test7CharArray = new byte[60];
    public Timestamp test7Timestamp = new Timestamp(0L);
    public Date test7Date = new Date(0L);
}

