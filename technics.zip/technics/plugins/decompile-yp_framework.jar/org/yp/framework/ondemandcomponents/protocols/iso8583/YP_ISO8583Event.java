/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.iso8583;

public class YP_ISO8583Event {
    protected ISO8583EVENT myEvent;

    public ISO8583EVENT getEventISO8583() {
        return this.myEvent;
    }

    public void setEventISO8583(ISO8583EVENT iSO8583EVENT) {
        this.myEvent = iSO8583EVENT;
    }

    public static enum ISO8583EVENT {
        OuvertureDialogue,
        ServiceRefuse,
        RefusAccepteur,
        RefusAcquereur,
        RepOk,
        RepKo,
        AttenteOd,
        synchroRequest,
        tlpInitTransfer,
        tlpDataTransfer,
        tlpActivateTable,
        tlpDealFunctionState,
        echoTest,
        giveTalk,
        dealGiveTalk,
        closeDialog,
        closeDialogReq,
        tlpInitTransferKo,
        openService,
        tlpAckFunctionalState,
        synchroLastRequest,
        synchroCloseDialog,
        askTableState,
        askSAState,
        askPAState,
        autoAnswer,
        autoEnd,
        autoprocess,
        fichierVide,
        askConsolidation,
        askEndOfDay,
        askRetry,
        askNewSession,
        dealInitTransactionUpload,
        error,
        hostEnd,
        dealSynchro;

    }
}

