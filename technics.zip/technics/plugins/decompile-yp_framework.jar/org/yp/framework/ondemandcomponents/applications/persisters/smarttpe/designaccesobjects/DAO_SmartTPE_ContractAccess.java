/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_SmartTPE_ContractAccess
extends YP_Row {
    @PrimaryKey
    public long idContractAccess = 0L;
    public long idContract = 0L;
}

