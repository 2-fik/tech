/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.transaction.DAO_TRS_EXT_Ctcl;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_STD_EMV;
import org.yp.utils.UtilsYP;

public class YP_TCD_DCB_STD_CTCL
extends YP_TCD_DCB_STD_EMV
implements YP_TCD_DCB_Interface_CTCL {
    private YP_TCD_DCC_Business dataContainer;
    private YP_TCD_DesignAccesObject ctcl_Param;
    private YP_TCD_DesignAccesObject ctcl_Drl;
    private YP_TCD_DesignAccesObject product_List;
    private long cksCtcl = -1L;
    private boolean nfcActivated = true;

    public YP_TCD_DCB_STD_CTCL(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DCC_Business) {
            this.dataContainer = (YP_TCD_DCC_Business)yP_Object;
            this.dataContainer.addExtension(this);
            if (this.dataContainer.transaction != null) {
                this.dataContainer.extendTransactionDAO(new DAO_TRS_EXT_Ctcl());
            }
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.ctcl_Param = this.dataContainer.getDesignAccesObject_ByNumber(34);
            this.ctcl_Drl = this.dataContainer.getDesignAccesObject_ByNumber(35);
            this.product_List = this.dataContainer.getDesignAccesObject_ByNumber(38);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()" + exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.ctcl_Param) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() ctl_Param");
            }
            this.cksCtcl = -1L;
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.ctcl_Drl) {
            this.cksCtcl = -1L;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() ctcl_Drl");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.product_List) {
            this.cksCtcl = -1L;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() product_List");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.ctcl_Param) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() ctl_Param");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.ctcl_Drl) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() ctl_Drl");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.product_List) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() product_List");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        Class<? extends YP_Row> clazz = yP_TCD_DesignAccesObject.getRowClass();
        if (this.ctcl_Param != null && clazz == this.ctcl_Param.getRowClass()) {
            this.cksCtcl = -1L;
        } else if (this.ctcl_Drl != null && clazz == this.ctcl_Drl.getRowClass()) {
            this.cksCtcl = -1L;
        } else if (this.product_List != null && clazz == this.product_List.getRowClass()) {
            this.cksCtcl = -1L;
        }
        return super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public String toString() {
        return "DataContainerExtensionCTCL";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public YP_TCD_DesignAccesObject getCTCLTable() {
        return this.ctcl_Param;
    }

    @Override
    public long getCTCLChecksum() {
        if (this.cksCtcl == -1L) {
            try {
                this.lock();
                if (this.cksCtcl == -1L) {
                    this.cksCtcl = this.getCKS(this.ctcl_Param);
                    this.cksCtcl += this.getCKS(this.ctcl_Drl);
                    this.cksCtcl += this.getCKS(this.product_List);
                }
            }
            finally {
                this.unlock();
            }
        }
        long l = this.cksCtcl;
        l += this.getAIDTableChecksum();
        l += this.getKeysTableChecksum();
        return l += this.getAIDParametersTableChecksum();
    }

    @Override
    public YP_TCD_DesignAccesObject getDRLTable() {
        return this.ctcl_Drl;
    }

    @Override
    public YP_TCD_DesignAccesObject getProductListTable() {
        return this.product_List;
    }

    @Override
    @Deprecated
    public List<YP_Row> getAIDKIDList() {
        if (UtilsYP.isMoroccoServer()) {
            return this.getAIDKIDList("504");
        }
        return this.getAIDKIDList("978");
    }

    @Override
    public List<YP_Row> getAIDKIDList(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.ctcl_Param);
        yP_ComplexGabarit.set("numericalCurrencyCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        return this.ctcl_Param.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public List<String> getKIDList() {
        List<String> list = this.ctcl_Param.getDistinctStringValueList("kernelID");
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string : list) {
            arrayList.add(String.format("%02d", Integer.parseInt(string)));
        }
        return arrayList;
    }

    @Override
    public List<YP_Row> getAIDKIDAmountList(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.ctcl_Param);
        if (string != null) {
            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        return this.ctcl_Param.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public List<YP_Row> getDynamicReaderLimitsList() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.ctcl_Drl);
        yP_ComplexGabarit.set("defaultApplicationID", YP_ComplexGabarit.OPERATOR.EQUAL, "0");
        return this.ctcl_Drl.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public YP_Row getAIDKIDAmountRow(String string, String string2, String string3) {
        List<YP_Row> list;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.ctcl_Param);
        if (string != null) {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string);
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        }
        if (string2 != null) {
            yP_ComplexGabarit.set("kernelID", YP_ComplexGabarit.OPERATOR.IN, string2, Integer.toString(Integer.parseInt(string2)));
        }
        if (string3 != null) {
            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        if ((list = this.ctcl_Param.getRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public YP_Row getProgramIDKIDDrlRow(String string, String string2, String string3) {
        List<YP_Row> list;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.ctcl_Drl);
        if (string != null) {
            yP_ComplexGabarit.set("applicationPgmId", YP_ComplexGabarit.OPERATOR.START_WITH, string);
        }
        if (string2 != null) {
            yP_ComplexGabarit.set("kernelID", YP_ComplexGabarit.OPERATOR.IN, string2, Integer.toString(Integer.parseInt(string2)));
        }
        if (string3 != null) {
            yP_ComplexGabarit.set("numericalCurrencyCode", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        if ((list = this.ctcl_Drl.getRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public String getForbiddenProduct(String string) {
        if (this.product_List == null) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.product_List);
        if (string == null) {
            return null;
        }
        yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        List<YP_Row> list = this.product_List.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (YP_Row yP_Row : list) {
            StringBuilder stringBuilder2 = new StringBuilder(yP_Row.getFieldStringValueByName("codeProduit"));
            int n = 10 - stringBuilder2.length();
            while (n > 0) {
                stringBuilder2.append("0");
                --n;
            }
            stringBuilder.append((CharSequence)stringBuilder2);
        }
        return "0001" + String.format("%02x", stringBuilder.length() / 2) + stringBuilder.toString();
    }

    @Override
    public boolean isActive() {
        return this.nfcActivated;
    }

    @Override
    public void setActive(boolean bl) {
        this.nfcActivated = bl;
    }
}

