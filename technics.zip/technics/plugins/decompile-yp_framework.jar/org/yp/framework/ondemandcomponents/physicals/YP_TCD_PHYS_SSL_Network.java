/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.StringTokenizer;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSessionContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_SSL_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private final String PROTOCOL = "SSL";
    private final String KEYSTOREALGORITHM = "SunX509";
    private final String TRUSTSTOREALGORITHM = "SunX509";
    private final String KEYSTORETYPE_JCEKS = "JCEKS";
    private final String TRUSTSTORETYPE_JCEKS = "JCEKS";
    private final String KEYSTORETYPE_JKS = "jks";
    private final String TRUSTSTORETYPE_JKS = "jks";
    private int connectionPort = 0;
    private OutputStream outputStream = null;
    private InputStream inputStream = null;
    private PushbackInputStream pushbackInputStream = null;
    private SSLServerSocket serverSocket = null;
    private SSLServerSocketFactory sslserversocketfactory = null;
    private SSLSocket clientSocket = null;
    private SSLSocketFactory sslsocketfactory = null;
    private boolean logAsBinary = false;
    String ipServer = null;
    int portServer = 0;
    int connectionTimeoutMS = 3499;
    String trustStorePath = null;
    String trustStorePasswd = null;
    String keyStorePath = null;
    String keyStorePasswd = null;
    String keyAlias = null;
    String enabledCipherSuites = null;
    String enabledProtocols = null;
    String authentificationNeeded = null;
    String sessionTimeOut = null;
    String proxyType = null;
    String proxyHost = null;
    int proxyPort = 0;
    private final byte[] cleanMessage = new byte[1024];

    public YP_TCD_PHYS_SSL_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof SSLSocket) {
            this.clientSocket = (SSLSocket)objectArray[0];
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private SSLContext getSSLContext(String string, String string2, String string3, String string4, String string5) {
        block28: {
            TrustManagerFactory trustManagerFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            TrustManager[] trustManagerArray = null;
            try {
                KeyStore keyStore;
                SSLContext sSLContext = SSLContext.getInstance("SSL");
                if (string != null && !string.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string), string2.toCharArray());
                    keyManagerFactory.init(keyStore, string2.toCharArray());
                }
                if (string4 != null && !string4.isEmpty()) {
                    trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string4.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string4), string5.toCharArray());
                    trustManagerFactory.init(keyStore);
                    try {
                        Enumeration<String> enumeration = keyStore.aliases();
                        while (enumeration.hasMoreElements()) {
                            X509Certificate x509Certificate;
                            String string6 = enumeration.nextElement();
                            if (!keyStore.isCertificateEntry(string6) || !(x509Certificate = (X509Certificate)keyStore.getCertificate(string6)).getIssuerDN().getName().contentEquals(x509Certificate.getSubjectDN().getName())) continue;
                            try {
                                x509Certificate.verify(x509Certificate.getPublicKey());
                            }
                            catch (SignatureException signatureException) {
                                this.logger(2, "getSSLContext() Exception while verifying self signed certificate : " + signatureException);
                                return null;
                            }
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "getSSLContext() certificat invalid : " + exception);
                        return null;
                    }
                } else {
                    trustManagerArray = new X509TrustManager[]{new X509TrustManager(){

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }
                    }};
                }
                if (keyManagerFactory == null && trustManagerFactory == null) {
                    sSLContext.init(null, trustManagerArray, null);
                } else if (keyManagerFactory == null && trustManagerFactory != null) {
                    sSLContext.init(null, trustManagerFactory.getTrustManagers(), null);
                } else if (keyManagerFactory != null && trustManagerFactory == null) {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerArray, null);
                } else {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                }
                return sSLContext;
            }
            catch (FileNotFoundException fileNotFoundException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() FileNotFoundException:" + fileNotFoundException);
                }
            }
            catch (KeyStoreException keyStoreException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() KeyStoreException:" + keyStoreException);
                }
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() NoSuchAlgorithmException:" + noSuchAlgorithmException);
                }
            }
            catch (CertificateException certificateException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() CertificateException:" + certificateException);
                }
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() IOException:" + iOException);
                }
            }
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() UnrecoverableKeyException:" + unrecoverableKeyException);
                }
            }
            catch (KeyManagementException keyManagementException) {
                if (this.getLogLevel() < 2) break block28;
                this.logger(2, "getSSLContext() KeyManagementException:" + keyManagementException);
            }
        }
        return null;
    }

    private int enabledCipherSuites(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledCipherSuites() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledCipherSuites == null || this.enabledCipherSuites.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedCipherSuites() : ((SSLServerSocket)object).getSupportedCipherSuites();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledCipherSuites, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledCipherSuites() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledCipherSuites() not added " + string);
                }
                if (arrayList.size() <= 0) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledCipherSuites(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledCipherSuites() bad cipher list ? " + this.enabledCipherSuites);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledCipherSuites() " + exception);
            }
        }
        return -1;
    }

    private int enabledProtocols(Object object) {
        block13: {
            block12: {
                if (!(object instanceof SSLSocket) && !(object instanceof SSLServerSocket)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "enabledProtocols() bad socket type...");
                    }
                    return -1;
                }
                if (this.enabledProtocols == null || this.enabledProtocols.isEmpty()) {
                    return 0;
                }
                String[] stringArray = object instanceof SSLSocket ? ((SSLSocket)object).getSupportedProtocols() : ((SSLServerSocket)object).getSupportedProtocols();
                StringTokenizer stringTokenizer = new StringTokenizer(this.enabledProtocols, ",", false);
                ArrayList<String> arrayList = new ArrayList<String>();
                while (stringTokenizer.countTokens() > 0) {
                    String string = stringTokenizer.nextToken();
                    boolean bl = false;
                    String[] stringArray2 = stringArray;
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        if (string2.compareTo(string) == 0) {
                            arrayList.add(string);
                            bl = true;
                            if (this.getLogLevel() < 5) break;
                            this.logger(5, "enabledProtocols() added " + string);
                            break;
                        }
                        ++n2;
                    }
                    if (bl || this.getLogLevel() < 2) continue;
                    this.logger(2, "enabledProtocols() not added " + string);
                }
                if (arrayList.isEmpty()) break block12;
                if (object instanceof SSLSocket) {
                    ((SSLSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                } else {
                    ((SSLServerSocket)object).setEnabledProtocols(arrayList.toArray(new String[arrayList.size()]));
                }
                return 1;
            }
            try {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "enabledProtocols() bad protocol list ? " + this.enabledProtocols);
                }
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block13;
                this.logger(2, "enabledProtocols() " + exception);
            }
        }
        return -1;
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.clientSocket == null) {
            SSLContext sSLContext;
            block24: {
                block23: {
                    String string = this.getProperty(this.getPropertyFileName(), "connectionPort");
                    if (string != null) {
                        this.connectionPort = Integer.parseInt(string);
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "trustStorePath")) != null && !string.isEmpty()) {
                        this.trustStorePath = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "trustStorePasswd")) != null && !string.isEmpty()) {
                        this.trustStorePasswd = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "keyStorePath")) != null && !string.isEmpty()) {
                        this.keyStorePath = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "keyStorePasswd")) != null && !string.isEmpty()) {
                        this.keyStorePasswd = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "keyAlias")) != null && !string.isEmpty()) {
                        this.keyAlias = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "enabledCipherSuites")) != null && !string.isEmpty()) {
                        this.enabledCipherSuites = string;
                        this.enabledCipherSuites = this.enabledCipherSuites.trim();
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "enabledProtocols")) != null && !string.isEmpty()) {
                        this.enabledProtocols = string;
                        this.enabledProtocols = this.enabledProtocols.trim();
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "authentificationNeeded")) != null && !string.isEmpty()) {
                        this.authentificationNeeded = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "proxyType")) != null && !string.isEmpty()) {
                        this.proxyType = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "proxyHost")) != null && !string.isEmpty()) {
                        this.proxyHost = string;
                    }
                    if ((string = this.getProperty(this.getPropertyFileName(), "proxyPort")) != null && !string.isEmpty()) {
                        try {
                            this.proxyPort = Integer.parseInt(string);
                        }
                        catch (Exception exception) {
                            if (this.getLogLevel() < 2) break block23;
                            this.logger(2, "initialize() proxyPort :" + this.proxyPort + " " + exception);
                        }
                    }
                }
                sSLContext = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd);
                if (sSLContext != null) break block24;
                return -1;
            }
            try {
                this.sslserversocketfactory = sSLContext.getServerSocketFactory();
            }
            catch (Exception exception) {
                this.logger(2, "initialize():" + exception);
            }
        } else {
            try {
                this.outputStream = this.clientSocket.getOutputStream();
                this.inputStream = this.clientSocket.getInputStream();
            }
            catch (IOException iOException) {
                this.logger(2, "initialize():" + iOException);
                return -1;
            }
            try {
                this.clientSocket.setSoTimeout(100);
            }
            catch (SocketException socketException) {
                this.logger(2, "initialize():" + socketException);
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int close() {
        this.outputStream = null;
        this.inputStream = null;
        this.pushbackInputStream = null;
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server Socket closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server socket close failed  :" + iOException);
                return -1;
            }
        }
        if (this.clientSocket != null) {
            try {
                this.clientSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Client Socket closed...");
                }
                this.clientSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Socket close error :" + iOException);
                this.clientSocket = null;
                return -1;
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "SSLConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.14";
    }

    public boolean isKeystoreEmpty(String string) {
        FileInputStream fileInputStream;
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "isKeystoreEmpty() keystore name missing");
            }
            return true;
        }
        try {
            fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + string);
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileInputStream = null;
        }
        try {
            KeyStore keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
            keyStore.load(fileInputStream, this.keyStorePasswd.toCharArray());
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            return keyStore.size() <= 0;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "isKeystoreEmpty() " + exception);
            }
            return true;
        }
    }

    @Override
    public int openServer() {
        block10: {
            if (this.serverSocket != null) {
                return 1;
            }
            try {
                if (!this.isKeystoreEmpty(this.keyStorePath)) break block10;
                this.logger(1, "openServer() keystore empty");
                this.setObjectStatus(2);
                return -2;
            }
            catch (IOException iOException) {
                this.logger(1, "openServer() Can't connect a socket to port " + this.connectionPort + " " + iOException);
                return -1;
            }
        }
        this.serverSocket = (SSLServerSocket)this.sslserversocketfactory.createServerSocket(this.connectionPort);
        this.enabledCipherSuites(this.serverSocket);
        this.enabledProtocols(this.serverSocket);
        if (this.trustStorePath == null) {
            this.serverSocket.setWantClientAuth(false);
        } else if (this.authentificationNeeded == null || this.authentificationNeeded.compareTo("0") == 0) {
            this.serverSocket.setWantClientAuth(true);
        } else {
            this.serverSocket.setNeedClientAuth(true);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "openServer() Waiting for connections on port" + this.serverSocket.getLocalPort() + "...");
        }
        if (this.getLogLevel() >= 4) {
            this.printServerSocketInfo(this.serverSocket);
        }
        return 1;
    }

    @Override
    public Object waitConnection() {
        try {
            this.serverSocket.setSoTimeout(this.getConnectionTimeout());
        }
        catch (SocketException socketException) {
            this.logger(2, "waitConnection() setSoTimeout " + socketException);
        }
        try {
            SSLSocket sSLSocket = (SSLSocket)this.serverSocket.accept();
            return sSLSocket;
        }
        catch (SocketTimeoutException socketTimeoutException) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "waitConnection() Timeout " + socketTimeoutException);
            }
            return null;
        }
        catch (IOException iOException) {
            this.logger(2, "waitConnection() " + iOException);
            return null;
        }
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        int n4 = 0;
        long l = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(n3);
        }
        catch (SocketException socketException) {
            this.logger(2, "recv() Timeout Initialisation error :" + socketException);
            return -1;
        }
        do {
            try {
                if (this.pushbackInputStream == null) {
                    n4 = this.inputStream.read(byArray, n, n2);
                    continue;
                }
                n4 = this.pushbackInputStream.read(byArray, n, n2);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "recv() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "recv() Read error..." + exception);
                return -1;
            }
        } while (n4 == 0 && !UtilsYP.isTimeout(l, n3));
        if (n4 > 0) {
            if (this.getLogLevel() >= 6) {
                this.logger(6, UtilsYP.getFormattedLog(0, byArray, n, n4, this.logAsBinary));
            } else if (this.getLogLevel() >= 4) {
                this.logger(4, "recv() bytes received :" + n4);
            }
        } else if (n4 == 0) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "recv() nothing...");
            }
        } else if (this.getLogLevel() >= 5) {
            this.logger(5, "recv() error :" + n4);
        }
        if (n == 0 && n4 == 1 && n2 > 1) {
            int n5 = this.recv(byArray, 1, n2 - 1, 100);
            if (n5 <= 0) {
                return 1;
            }
            return n5 + 1;
        }
        return n4;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public int peek(byte[] var1_1, int var2_2, int var3_3, int var4_4) {
        if (!this.inputStream.markSupported()) {
            try {
                this.pushbackInputStream = new PushbackInputStream(this.inputStream, 100);
            }
            catch (Exception var5_5) {
                this.logger(3, "peek() mark is not supported !!!" + var5_5);
                return -1;
            }
        }
        var5_6 = 0;
        var6_7 = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(var4_4);
        }
        catch (SocketException var8_8) {
            this.logger(2, "peek() Timeout Initialisation error :" + var8_8);
            return -1;
        }
        do {
            try {
                if (this.pushbackInputStream == null) {
                    this.inputStream.mark(var3_3 + 1);
                    var5_6 = this.inputStream.read(var1_1, var2_2, var3_3);
                    this.inputStream.reset();
                    continue;
                }
                var5_6 = this.pushbackInputStream.read(var1_1, var2_2, var3_3);
                if (var5_6 <= 0) continue;
                this.pushbackInputStream.unread(var1_1, var2_2, var5_6);
                continue;
            }
            catch (SocketTimeoutException var8_9) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "peek() Read timeout" + var8_9);
                }
                return 0;
            }
            catch (SocketException var8_10) {
                var9_12 = new Throwable().getStackTrace();
                var10_13 = 0;
                ** while (var10_13 < var9_12.length)
            }
lbl-1000:
            // 1 sources

            {
                if (var9_12[var10_13].getMethodName().contentEquals("waitRequest")) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "peek() socket closed :" + var8_10);
                    }
                    return -1;
                }
                ++var10_13;
                continue;
            }
lbl45:
            // 1 sources

            if (this.getLogLevel() >= 5) {
                this.logger(2, "peek() Read error..." + var8_10);
            }
            return -1;
            catch (Exception var8_11) {
                this.logger(2, "peek() Read error..." + var8_11);
                return -1;
            }
        } while (var5_6 == 0 && !UtilsYP.isTimeout(var6_7, var4_4));
        if (var5_6 <= 0) {
            if (var5_6 == 0) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "peek() nothing...");
                }
            } else if (this.getLogLevel() >= 5) {
                this.logger(5, "peek() error :" + var5_6);
            }
        }
        return var5_6;
    }

    @Override
    public int clean(int n) {
        long l = System.currentTimeMillis();
        try {
            this.clientSocket.setSoTimeout(n);
        }
        catch (SocketException socketException) {
            this.logger(2, "clean() Timeout Initialisation error :" + socketException);
            return -1;
        }
        do {
            try {
                int n2 = this.inputStream.read(this.cleanMessage);
                if (n2 > 0) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, UtilsYP.getFormattedLog(2, this.cleanMessage, 0, n2));
                        continue;
                    }
                    if (this.getLogLevel() < 4) continue;
                    this.logger(4, "clean() bytes cleaned :" + n2);
                    continue;
                }
                if (n2 == 0) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "clean() nothing...");
                    continue;
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "clean() error :" + n2);
            }
            catch (SocketTimeoutException socketTimeoutException) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "clean() Read timeout" + socketTimeoutException);
                }
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "clean() Read error..." + exception);
                return -1;
            }
        } while (!UtilsYP.isTimeout(l, n));
        return 1;
    }

    @Override
    public int available() {
        try {
            return this.inputStream.available();
        }
        catch (Exception exception) {
            this.logger(2, "available() available error..." + exception);
            return -1;
        }
    }

    @Override
    public int send(byte[] byArray, int n) {
        try {
            this.outputStream.write(byArray, 0, n);
            this.outputStream.flush();
        }
        catch (IOException iOException) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "send() Write error..." + iOException);
            }
            return -1;
        }
        if (this.getLogLevel() >= 6) {
            this.logger(6, UtilsYP.getFormattedLog(1, byArray, 0, n, this.logAsBinary));
        } else if (this.getLogLevel() >= 4) {
            this.logger(4, "send() bytes sent :" + n);
        }
        return n;
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        try {
            SocketAddress socketAddress = this.clientSocket.getRemoteSocketAddress();
            String string = socketAddress.toString();
            int n = string.indexOf(":");
            string = string.substring(1, n);
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getIP() " + exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int openClient(Object ... objectArray) {
        try {
            int n;
            if (this.clientSocket != null && this.clientSocket.isConnected()) {
                return 1;
            }
            if (objectArray == null) {
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                if (this.ipServer == null) {
                    this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                }
                if (this.connectionTimeoutMS == 3499) {
                    this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                }
                if (this.sslsocketfactory == null) {
                    SSLContext sSLContext;
                    if (this.trustStorePath == null) {
                        this.trustStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePath");
                    }
                    if (this.trustStorePasswd == null) {
                        this.trustStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePasswd");
                    }
                    if (this.keyStorePath == null) {
                        this.keyStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePath");
                    }
                    if (this.keyStorePasswd == null) {
                        this.keyStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePasswd");
                    }
                    if (this.keyAlias == null) {
                        this.keyAlias = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyAlias");
                    }
                    if (this.enabledCipherSuites == null) {
                        this.enabledCipherSuites = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledCipherSuites");
                        this.enabledCipherSuites = this.enabledCipherSuites.trim();
                    }
                    if (this.enabledProtocols == null) {
                        this.enabledProtocols = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledProtocols");
                        this.enabledProtocols = this.enabledProtocols.trim();
                    }
                    if (this.authentificationNeeded == null) {
                        this.authentificationNeeded = ((YP_Row)objectArray[0]).getFieldStringValueByName("authentificationNeeded");
                    }
                    if (this.sessionTimeOut == null) {
                        this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
                    }
                    if ((sSLContext = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd)) == null) {
                        return -1;
                    }
                    this.sslsocketfactory = sSLContext.getSocketFactory();
                }
                if (this.proxyType == null) {
                    this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
                }
                if (this.proxyHost == null) {
                    this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
                }
                if (this.proxyPort == 0) {
                    this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
                }
            } else if (objectArray.length >= 2 && objectArray[0] instanceof String && objectArray[1] instanceof String) {
                if (this.ipServer == null) {
                    this.ipServer = (String)objectArray[0];
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt((String)objectArray[1]);
                }
                if (objectArray.length > 2 && objectArray[2] instanceof Integer) {
                    this.connectionTimeoutMS = (Integer)objectArray[2];
                }
            }
            if (this.ipServer == null || this.portServer == 0 || this.sslsocketfactory == null) {
                this.logger(2, "openClient() missing parameters");
                return -1;
            }
            try {
                n = Integer.parseInt(this.sessionTimeOut);
            }
            catch (Exception exception) {
                n = 0;
            }
            if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
                this.logger(4, "openClient() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
                this.clientSocket = this.tunnelThroughProxy(this.sslsocketfactory, this.proxyType, this.proxyHost, this.proxyPort, this.ipServer, this.portServer);
            } else {
                try {
                    this.clientSocket = (SSLSocket)this.sslsocketfactory.createSocket(InetAddress.getByName(this.ipServer), this.portServer);
                }
                catch (Exception exception) {
                    this.logger(3, "openClient() create socket failed for " + this.ipServer + ":" + this.portServer + " " + exception);
                    throw exception;
                }
            }
            this.enabledCipherSuites(this.clientSocket);
            this.enabledProtocols(this.clientSocket);
            try {
                int n2 = this.clientSocket.getSoTimeout();
                this.clientSocket.setSoTimeout(this.connectionTimeoutMS);
                this.clientSocket.startHandshake();
                this.clientSocket.setSoTimeout(n2);
            }
            catch (Exception exception) {
                this.logger(3, "openClient().startHandshake failed: " + exception);
                this.close();
                throw exception;
            }
            SSLSessionContext sSLSessionContext = this.clientSocket.getSession().getSessionContext();
            if (sSLSessionContext != null) {
                sSLSessionContext.setSessionTimeout(n);
            }
            this.printSocketInfo(this.clientSocket);
            if (this.trustStorePath == null) return this.initialize();
            if (this.trustStorePath.isEmpty()) return this.initialize();
            try {
                X509Certificate[] x509CertificateArray;
                X509Certificate[] x509CertificateArray2 = x509CertificateArray = (X509Certificate[])this.clientSocket.getSession().getPeerCertificates();
                int n3 = x509CertificateArray.length;
                int n4 = 0;
                while (true) {
                    if (n4 >= n3) {
                        return this.initialize();
                    }
                    X509Certificate x509Certificate = x509CertificateArray2[n4];
                    x509Certificate.checkValidity();
                    ++n4;
                }
            }
            catch (Exception exception) {
                this.logger(3, "openClient() Certificate check: " + exception);
                this.close();
                throw exception;
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + " ", exception);
            this.ipServer = null;
            this.clientSocket = null;
            this.portServer = 0;
            this.connectionTimeoutMS = 3499;
            this.sslsocketfactory = null;
            this.trustStorePath = null;
            this.trustStorePasswd = null;
            this.keyStorePath = null;
            this.keyStorePasswd = null;
            this.keyAlias = null;
            this.enabledCipherSuites = null;
            this.enabledProtocols = null;
            this.authentificationNeeded = null;
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Socket createSocket(Object ... objectArray) {
        try {
            SSLSocket sSLSocket;
            int n;
            if (objectArray == null) {
                this.logger(2, "createSocket() missing parameters");
                return null;
            }
            if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                if (this.ipServer == null) {
                    this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                }
                if (this.connectionTimeoutMS == 3499) {
                    this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                }
                if (this.sslsocketfactory == null) {
                    SSLContext sSLContext;
                    if (this.trustStorePath == null) {
                        this.trustStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePath");
                    }
                    if (this.trustStorePasswd == null) {
                        this.trustStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePasswd");
                    }
                    if (this.keyStorePath == null) {
                        this.keyStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePath");
                    }
                    if (this.keyStorePasswd == null) {
                        this.keyStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePasswd");
                    }
                    if (this.keyAlias == null) {
                        this.keyAlias = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyAlias");
                    }
                    if (this.enabledCipherSuites == null) {
                        this.enabledCipherSuites = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledCipherSuites");
                        this.enabledCipherSuites = this.enabledCipherSuites.trim();
                    }
                    if (this.enabledProtocols == null) {
                        this.enabledProtocols = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledProtocols");
                        this.enabledProtocols = this.enabledProtocols.trim();
                    }
                    if (this.authentificationNeeded == null) {
                        this.authentificationNeeded = ((YP_Row)objectArray[0]).getFieldStringValueByName("authentificationNeeded");
                    }
                    if (this.sessionTimeOut == null) {
                        this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
                    }
                    if ((sSLContext = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd)) == null) {
                        return null;
                    }
                    this.sslsocketfactory = sSLContext.getSocketFactory();
                }
                if (this.proxyType == null) {
                    this.proxyType = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyType");
                }
                if (this.proxyHost == null) {
                    this.proxyHost = ((YP_Row)objectArray[0]).getFieldStringValueByName("proxyHost");
                }
                if (this.proxyPort == 0) {
                    this.proxyPort = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("proxyPort");
                }
            } else if (objectArray.length >= 2 && objectArray[0] instanceof String && objectArray[1] instanceof String) {
                if (this.ipServer == null) {
                    this.ipServer = (String)objectArray[0];
                }
                if (this.portServer == 0) {
                    this.portServer = Integer.parseInt((String)objectArray[1]);
                }
                if (objectArray.length > 2 && objectArray[2] instanceof Integer) {
                    this.connectionTimeoutMS = (Integer)objectArray[2];
                }
            }
            if (this.ipServer == null || this.portServer == 0 || this.sslsocketfactory == null) {
                this.logger(2, "createSocket() missing parameters");
                return null;
            }
            try {
                n = Integer.parseInt(this.sessionTimeOut);
            }
            catch (Exception exception) {
                n = 0;
            }
            if (this.proxyHost != null && this.proxyHost.length() > 0 && this.proxyPort > 0) {
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "createSocket() Connection using proxy " + this.proxyHost + ":" + this.proxyPort + " " + this.ipServer + ":" + this.portServer);
                }
                sSLSocket = this.tunnelThroughProxy(this.sslsocketfactory, this.proxyType, this.proxyHost, this.proxyPort, this.ipServer, this.portServer);
            } else {
                try {
                    sSLSocket = (SSLSocket)this.sslsocketfactory.createSocket(InetAddress.getByName(this.ipServer), this.portServer);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) throw exception;
                    this.logger(2, "createSocket() create socket failed for " + this.ipServer + ":" + this.portServer + " " + exception);
                    throw exception;
                }
            }
            this.enabledCipherSuites(sSLSocket);
            this.enabledProtocols(sSLSocket);
            int n2 = sSLSocket.getSoTimeout();
            sSLSocket.setSoTimeout(this.connectionTimeoutMS);
            sSLSocket.startHandshake();
            sSLSocket.setSoTimeout(n2);
            SSLSessionContext sSLSessionContext = sSLSocket.getSession().getSessionContext();
            if (sSLSessionContext != null) {
                sSLSessionContext.setSessionTimeout(n);
            }
            if (this.getLogLevel() >= 4) {
                this.printSocketInfo(sSLSocket);
            }
            try {
                X509Certificate[] x509CertificateArray;
                X509Certificate[] x509CertificateArray2 = x509CertificateArray = (X509Certificate[])sSLSocket.getSession().getPeerCertificates();
                int n3 = x509CertificateArray.length;
                int n4 = 0;
                while (true) {
                    if (n4 >= n3) {
                        return sSLSocket;
                    }
                    X509Certificate x509Certificate = x509CertificateArray2[n4];
                    x509Certificate.checkValidity();
                    ++n4;
                }
            }
            catch (Exception exception) {
                this.logger(2, "createSocket() " + exception);
                sSLSocket.close();
                return null;
            }
        }
        catch (Exception exception) {
            this.logger(2, "createSocket() " + exception);
            this.ipServer = null;
            this.clientSocket = null;
            this.portServer = 0;
            this.connectionTimeoutMS = 3499;
            this.sslsocketfactory = null;
            this.trustStorePath = null;
            this.trustStorePasswd = null;
            this.keyStorePath = null;
            this.keyStorePasswd = null;
            this.keyAlias = null;
            this.enabledCipherSuites = null;
            this.enabledProtocols = null;
            this.authentificationNeeded = null;
            this.proxyType = null;
            this.proxyHost = null;
            this.proxyPort = 0;
            return null;
        }
    }

    private void printServerSocketInfo(SSLServerSocket sSLServerSocket) {
        try {
            String string;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printServerSocketInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Server socket class: ");
            stringBuilder.append(sSLServerSocket.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker address = ");
            stringBuilder.append(sSLServerSocket.getInetAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Socker port = ");
            stringBuilder.append(sSLServerSocket.getLocalPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Need client authentication = ");
            stringBuilder.append(sSLServerSocket.getNeedClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Want client authentication = ");
            stringBuilder.append(sSLServerSocket.getWantClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Use client mode = ");
            stringBuilder.append(sSLServerSocket.getUseClientMode());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Enabled Cipher Suites = ");
            stringBuilder.append(UtilsYP.lineSeparator);
            String[] stringArray = sSLServerSocket.getEnabledCipherSuites();
            int n = stringArray.length;
            int n2 = 0;
            while (n2 < n) {
                string = stringArray[n2];
                stringBuilder.append(string);
                stringBuilder.append(UtilsYP.lineSeparator);
                ++n2;
            }
            stringBuilder.append("   Enabled Protocols = ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringArray = sSLServerSocket.getEnabledProtocols();
            n = stringArray.length;
            n2 = 0;
            while (n2 < n) {
                string = stringArray[n2];
                stringBuilder.append(string);
                stringBuilder.append(UtilsYP.lineSeparator);
                ++n2;
            }
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    private void printSocketInfo(SSLSocket sSLSocket) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printSocketInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Socket class: ");
            stringBuilder.append(sSLSocket.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(sSLSocket.getInetAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote port = ");
            stringBuilder.append(sSLSocket.getPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local socket address = ");
            stringBuilder.append(sSLSocket.getLocalSocketAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local address = ");
            stringBuilder.append(sSLSocket.getLocalAddress().toString());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Local port = ");
            stringBuilder.append(sSLSocket.getLocalPort());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Need client authentication = ");
            stringBuilder.append(sSLSocket.getNeedClientAuth());
            stringBuilder.append(UtilsYP.lineSeparator);
            SSLSession sSLSession = sSLSocket.getSession();
            stringBuilder.append("   Cipher suite = ");
            stringBuilder.append(sSLSession.getCipherSuite());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Protocol = ");
            stringBuilder.append(sSLSession.getProtocol());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Creation date = ");
            stringBuilder.append(new java.util.Date(sSLSession.getCreationTime()));
            try {
                Certificate[] certificateArray;
                Date date = new Date(System.currentTimeMillis() + 864000000L);
                Certificate[] certificateArray2 = certificateArray = sSLSession.getPeerCertificates();
                int n = certificateArray.length;
                int n2 = 0;
                while (n2 < n) {
                    Certificate certificate = certificateArray2[n2];
                    X509Certificate x509Certificate = (X509Certificate)certificate;
                    stringBuilder.append(UtilsYP.lineSeparator);
                    stringBuilder.append("   End of validity = ");
                    stringBuilder.append(x509Certificate.getNotAfter());
                    if (x509Certificate.getNotAfter().before(date)) {
                        this.logger(2, "printSocketInfo() Certicate for " + sSLSocket.getInetAddress().toString() + ":" + sSLSocket.getPort() + " will soon expire");
                    }
                    ++n2;
                }
            }
            catch (Exception exception) {}
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    private SSLSocket tunnelThroughProxy(SSLSocketFactory sSLSocketFactory, String string, String string2, int n, String string3, int n2) throws UnknownHostException, IOException {
        Socket socket;
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "tunnelThroughProxy() tunnelType missing. Assuming HTTP");
            }
            string = "HTTP";
        }
        if (string.equalsIgnoreCase("SOCKS")) {
            socket = new Socket(new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(string2, n)));
            socket.connect(new InetSocketAddress(string3, n2));
        } else if (string.equalsIgnoreCase("HTTP")) {
            socket = new Socket(string2, n);
            this.doTunnelHandshake(socket, string3, n2);
        } else {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "tunnelThroughProxy() unknown tunnelType " + string);
            }
            throw new UnknownHostException("unknown tunnelType");
        }
        SSLSocket sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(socket, string3, n2, true);
        return sSLSocket;
    }

    @Override
    public int setParameter(String string, String string2) {
        switch (string) {
            case "logAsBinary": {
                this.logAsBinary = Boolean.parseBoolean(string2);
                return 1;
            }
        }
        return 0;
    }
}

