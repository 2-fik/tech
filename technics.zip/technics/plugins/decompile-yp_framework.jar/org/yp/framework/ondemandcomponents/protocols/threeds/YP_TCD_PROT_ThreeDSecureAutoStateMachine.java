/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.threeds;

import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_3DSecure;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachine;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecureAuto;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_ThreeDSecureEvent;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_PROT_ThreeDSecureAutoStateMachine
extends YP_OnDemandComponent
implements YP_PROT_Interface_StateMachine {
    private YP_TCD_PROT_ThreeDSecureAuto myAutoClass;
    public YP_TCD_PROT_ThreeDSecure protocolThreeDS = null;
    public final YP_ThreeDSecureEvent eventThreeDS = new YP_ThreeDSecureEvent();
    private YP_PROT_Interface_Prot.SERVICEDEMANDE serviceRequested = null;
    public YP_TCD_DCC_Business dataContainerBusiness = null;
    public YP_TCD_DC_Transaction dataContainerTransaction = null;
    private YP_PROT_Interface_Prot protocolInterface;
    private YP_PHYS_Interface physicalInterface;
    private YP_PROT_Interface_3DSecure protocolEFT;
    private AUTOSTATEMACHINE myCurrentState = AUTOSTATEMACHINE.autoPrepareRequest;
    private int errorStatus = -1;

    public YP_TCD_PROT_ThreeDSecureAutoStateMachine(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int setParameters(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE, List<Property> list, YP_PROT_Interface_Prot yP_PROT_Interface_Prot, YP_Object yP_Object, Object ... objectArray) {
        try {
            this.dataContainerBusiness = yP_TCD_DCC_Business;
            this.dataContainerTransaction = yP_TCD_DC_Transaction;
            this.serviceRequested = sERVICEDEMANDE;
            if (objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PROT_Interface_3DSecure) {
                this.protocolEFT = (YP_PROT_Interface_3DSecure)objectArray[0];
            }
            if (yP_PROT_Interface_Prot != null) {
                this.protocolInterface = yP_PROT_Interface_Prot;
            }
            if (yP_Object != null && yP_Object instanceof YP_PHYS_Interface) {
                this.physicalInterface = (YP_PHYS_Interface)((Object)yP_Object);
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)this.newPluginByName("THREEDSECURE_PROTOCOL", yP_Object);
            } else if (yP_Object != null && yP_Object instanceof YP_TCD_PROT_ThreeDSecure) {
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)yP_Object;
            } else {
                this.protocolThreeDS = (YP_TCD_PROT_ThreeDSecure)this.newPluginByName("THREEDSECURE_PROTOCOL", new Object[0]);
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "setParameters() " + exception);
            }
            return -1;
        }
    }

    private AUTOSTATEMACHINE getState() {
        return this.myCurrentState;
    }

    private void setState(AUTOSTATEMACHINE aUTOSTATEMACHINE) {
        this.myCurrentState = aUTOSTATEMACHINE;
    }

    @Override
    public void setServiceRequested(YP_PROT_Interface_Prot.SERVICEDEMANDE sERVICEDEMANDE) {
        this.serviceRequested = sERVICEDEMANDE;
    }

    public YP_PROT_Interface_Prot.SERVICEDEMANDE getServiceRequested() {
        return this.serviceRequested;
    }

    public int getErrorStatus() {
        return this.errorStatus;
    }

    public void setErrorStatus(int n) {
        this.errorStatus = n;
    }

    @Override
    public int step() {
        if (this.getLogLevel() >= 5) {
            this.logger(5, "step() state: " + (Object)((Object)this.getState()) + " event: " + (Object)((Object)this.eventThreeDS.getEventThreeDS()));
        }
        switch (this.myCurrentState) {
            case autoPrepareRequest: {
                this.getMyAutoClass().YP_ThreeDSAutoPrepareRequest();
                if (this.eventThreeDS.getEventThreeDS() == YP_ThreeDSecureEvent.THREEDSEVENT.RepOk) {
                    this.setState(AUTOSTATEMACHINE.autoConnect);
                    return 1;
                }
                this.setState(AUTOSTATEMACHINE.autoEnd);
                return 1;
            }
            case autoConnect: {
                this.getMyAutoClass().YP_ThreeDSAutoConnect();
                if (this.eventThreeDS.getEventThreeDS() == YP_ThreeDSecureEvent.THREEDSEVENT.RepOk) {
                    this.setState(AUTOSTATEMACHINE.autoProcess);
                    return 1;
                }
                this.setState(AUTOSTATEMACHINE.autoEnd);
                return 1;
            }
            case autoProcess: {
                this.getMyAutoClass().YP_ThreeDSAutoProcess();
                if (this.eventThreeDS.getEventThreeDS() == YP_ThreeDSecureEvent.THREEDSEVENT.RepOk) {
                    this.setState(AUTOSTATEMACHINE.autoAnalyseResponse);
                    return 1;
                }
                this.setState(AUTOSTATEMACHINE.autoEnd);
                return 1;
            }
            case autoAnalyseResponse: {
                this.getMyAutoClass().YP_ThreeDSAutoAnalyseResponse();
                if (this.eventThreeDS.getEventThreeDS() == YP_ThreeDSecureEvent.THREEDSEVENT.RepOk) {
                    this.setState(AUTOSTATEMACHINE.autoEnd);
                    return 1;
                }
                this.setState(AUTOSTATEMACHINE.autoEnd);
                return 1;
            }
            case autoEnd: {
                this.getMyAutoClass().YP_ThreeDSAutoEnd();
                return 0;
            }
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "step() unknown step");
        }
        this.setState(AUTOSTATEMACHINE.autoEnd);
        return 1;
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String toString() {
        return "SM_THREEDSECURE_AUTO";
    }

    @Override
    public int shutdown() {
        if (this.myAutoClass != null) {
            this.myAutoClass.shutdown();
            this.myAutoClass = null;
        }
        return super.shutdown();
    }

    public void setMyAutoClass(YP_TCD_PROT_ThreeDSecureAuto yP_TCD_PROT_ThreeDSecureAuto) {
        this.myAutoClass = yP_TCD_PROT_ThreeDSecureAuto;
    }

    public YP_TCD_PROT_ThreeDSecureAuto getMyAutoClass() {
        if (this.myAutoClass == null) {
            Object[] objectArray = new Object[9];
            objectArray[0] = this.dataContainerBusiness;
            objectArray[1] = this.dataContainerTransaction;
            objectArray[2] = this.protocolThreeDS;
            objectArray[3] = this.eventThreeDS;
            objectArray[4] = this.protocolEFT;
            this.myAutoClass = (YP_TCD_PROT_ThreeDSecureAuto)this.newPluginByName("THREEDSECURE_AUTO", objectArray);
        }
        return this.myAutoClass;
    }

    public YP_PROT_Interface_Prot getProtocolInterface() {
        return this.protocolInterface;
    }

    public static enum AUTOSTATEMACHINE {
        autoPrepareRequest,
        autoConnect,
        autoProcess,
        autoAnalyseResponse,
        autoEnd;

    }
}

