/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_RetrievalReference;
import org.yp.utils.enums.ReservationStatusEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class ReservationHandler
implements HandlerInterface {
    YP_TCD_DC_Transaction dataContainerTransaction;
    private String v_reservationReference;
    private ReservationStatusEnumeration v_reservationStatus;
    private boolean loadReferenceDetailsPostponed = false;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        return 1;
    }

    @Override
    public int clear() {
        this.v_reservationReference = null;
        this.v_reservationStatus = null;
        return 1;
    }

    public ReservationHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public String getReservationReference() {
        return this.v_reservationReference;
    }

    public int setReservationReference(String string) {
        this.v_reservationReference = string;
        return 1;
    }

    public ReservationStatusEnumeration getReservationStatus() {
        return this.v_reservationStatus;
    }

    public int setReservationStatus(ReservationStatusEnumeration reservationStatusEnumeration) {
        this.v_reservationStatus = reservationStatusEnumeration;
        return 1;
    }

    public List<YP_Row> getReservationOpen(String string) {
        try {
            return (List)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "getOpenReservationList", string);
        }
        catch (Exception exception) {
            this.dataContainerTransaction.logger(2, "getReservationOpen() unable to create open reservation list " + exception);
            return null;
        }
    }

    private int prepareRetrievalReferenceData(YP_PROT_RetrievalReference yP_PROT_RetrievalReference) {
        ReservationStatusEnumeration reservationStatusEnumeration;
        String string = this.getReservationReference();
        if (string != null) {
            yP_PROT_RetrievalReference.setReservationReference(string);
        }
        if ((reservationStatusEnumeration = this.getReservationStatus()) != null) {
            yP_PROT_RetrievalReference.setReservationStatus(reservationStatusEnumeration);
        }
        return 1;
    }

    private int readRetrievalReferenceData(YP_PROT_RetrievalReference yP_PROT_RetrievalReference) {
        ReservationStatusEnumeration reservationStatusEnumeration;
        String string = yP_PROT_RetrievalReference.getReservationReference();
        if (string != null && !string.isEmpty()) {
            this.setReservationReference(string);
        }
        if ((reservationStatusEnumeration = yP_PROT_RetrievalReference.getReservationStatus()) != null) {
            this.setReservationStatus(reservationStatusEnumeration);
        }
        return 1;
    }

    @Override
    public int readRequest() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol;
        block7: {
            try {
                yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
                if (yP_TCD_PosProtocol instanceof YP_PROT_RetrievalReference) break block7;
                if (this.dataContainerTransaction.getLogLevel() >= 5) {
                    this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with RetrievalReference");
                }
                return 0;
            }
            catch (Exception exception) {
                this.dataContainerTransaction.logger(2, "readRequest() " + exception);
                return -1;
            }
        }
        YP_PROT_RetrievalReference yP_PROT_RetrievalReference = (YP_PROT_RetrievalReference)((Object)yP_TCD_PosProtocol);
        this.readRetrievalReferenceData(yP_PROT_RetrievalReference);
        if (this.v_reservationReference != null && !this.v_reservationReference.isEmpty()) {
            if (this.dataContainerTransaction.getContractIdentifier().contentEquals("KERNEL")) {
                this.loadReferenceDetailsPostponed = true;
            } else {
                Integer cfr_ignored_0 = (Integer)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "loadReferenceDetails", this.v_reservationReference, this.dataContainerTransaction);
            }
        }
        return 1;
    }

    @Override
    public int prepareResponse() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_RetrievalReference)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with RetrievalReference");
            }
            return 0;
        }
        YP_PROT_RetrievalReference yP_PROT_RetrievalReference = (YP_PROT_RetrievalReference)((Object)yP_TCD_PosProtocol);
        this.prepareRetrievalReferenceData(yP_PROT_RetrievalReference);
        return 0;
    }

    @Override
    public int load(YP_Row yP_Row) {
        this.dataContainerTransaction.logger(2, "load() TODO !!!");
        return -1;
    }

    @Override
    public int persist() {
        String[] stringArray;
        String string;
        YP_Row yP_Row;
        block11: {
            block10: {
                block9: {
                    try {
                        if (this.dataContainerTransaction.getRequestType() != YP_TCD_PosProtocol.REQUEST_TYPE.Transparent || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.CLOSING_PAYMENT || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.INITIAL_RESERVATION || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.ADDITIONAL_RESERVATION || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.ONE_TIME_RESERVATION || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT || this.dataContainerTransaction.commonHandler.getTransactionType() == TransactionTypeEnumeration.COMPLEMENTARY_REFUND) break block9;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.dataContainerTransaction.logger(2, "persist()" + exception);
                        return -1;
                    }
                }
                try {
                    yP_Row = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "createNewReservationDetails", new Object[0]);
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "persist() unable to create reservationDetails " + exception);
                    return -1;
                }
                if (yP_Row != null) break block10;
                this.dataContainerTransaction.logger(2, "persist() unable to create reservation Details ");
                return -1;
            }
            yP_Row.set("reservationReference", this.getReservationReference());
            yP_Row.set("status", this.getReservationStatus());
            yP_Row.set("appliLocalTime", this.dataContainerTransaction.commonHandler.getTransactionAppliLocalTime());
            string = this.dataContainerTransaction.getContractIdentifier();
            stringArray = string.split("_");
            if (stringArray.length == 4) break block11;
            this.dataContainerTransaction.logger(2, "persist() bad format of contract identifier:" + string);
            return -1;
        }
        if (YP_TCD_DCC_Business.getTransactionStatus(this.dataContainerTransaction) == TransactionStatusEnumeration.ACCEPTED) {
            yP_Row.set("contractIdentifier", string);
            yP_Row.set("merchantName", stringArray[1]);
            yP_Row.set("applicationName", stringArray[2]);
            yP_Row.set("applicationInstance", Integer.parseInt(stringArray[3]));
            yP_Row.set("idTransaction", this.dataContainerTransaction.commonHandler.getTransactionPrimaryKey());
            yP_Row.set("merchantTransactionIdentifier", this.dataContainerTransaction.commonHandler.getMerchantTransactionIdentifier());
            yP_Row.persist();
        }
        return 1;
    }

    public boolean isLoadReferenceDetailsPostponed() {
        return this.loadReferenceDetailsPostponed;
    }
}

