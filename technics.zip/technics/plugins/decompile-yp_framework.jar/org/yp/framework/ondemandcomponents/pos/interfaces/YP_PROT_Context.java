/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import java.util.List;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.ExtendedResult;

public interface YP_PROT_Context {
    public String getExtendedIdentifier();

    public int setExtendedIdentifier(String var1);

    public String getMerchantIdentifier();

    public int setMerchantIdentifier(String var1);

    public String getTerminalIdentifier();

    public int setTerminalIdentifier(String var1);

    public String getApplicationIdentifier();

    public int setApplicationIdentifier(String var1);

    public String getStoreIdentifier();

    public int setStoreIdentifier(String var1);

    public int getPosNumber();

    public int setPosNumber(int var1);

    public List<String> getPositiveApplicationIdentifierList();

    public int setPositiveApplicationIdentifierList(List<String> var1);

    public List<String> getPositiveMerchantIdentifierList();

    public int setPositiveMerchantIdentifierList(List<String> var1);

    public String getPaymentSystemIdentifier();

    public String getProtocolMode();

    public String getProtocolVersion();

    public String getServiceSequenceNumber();

    public List<String> getNegativeApplicationIdentifierList();

    public List<String> getNegativeMerchantIdentifierList();

    public int setStatus(YP_TCD_PosProtocol.RESULT_TYPE var1);

    public int setExtendedResult(ExtendedResult var1);

    public long getTimeoutMS();
}

