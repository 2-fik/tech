/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher.designaccesobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.technic.DAO_Merchant;

public class DAO_STD_Dispatcher
extends YP_Row {
    @PrimaryKey
    public long idDispatcher = 0L;
    public byte[] terminalManufacturerID = new byte[16];
    @Index
    public byte[] terminalSerialNumber = new byte[32];
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Store.class)
    public long idStore = 0L;
}

