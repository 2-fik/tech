/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister;

import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_TRSPersister
extends YP_TCD_DCB_Interface_Extension {
    public static final int NB_IPN_AT_ONE_TIME = 1000;

    public int persistTransaction(YP_TCD_DCC_Business var1, YP_TCD_DC_Transaction var2);
}

