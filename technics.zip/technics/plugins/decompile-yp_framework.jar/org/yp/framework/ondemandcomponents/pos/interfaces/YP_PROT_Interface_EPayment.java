/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

public interface YP_PROT_Interface_EPayment {
    public String getMerchantURLStatus();
}

