/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.simpleframework.xml.Serializer
 *  org.simpleframework.xml.core.Persister
 */
package org.yp.framework.ondemandcomponents.parsers;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.parsers.YP_TCD_XMLParser_Interface;
import org.yp.xml.simplexml.xpde.XPDERequest;

public final class YP_TCD_XMLParser_SimpleXML
extends YP_OnDemandComponent
implements YP_TCD_XMLParser_Interface {
    private Serializer serializer;

    public YP_TCD_XMLParser_SimpleXML(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        try {
            this.serializer = new Persister();
        }
        catch (Exception exception) {
            this.logger(2, "initialize()  " + exception);
        }
        return 1;
    }

    @Override
    public final String toString() {
        return "XMLParserSimpleXML";
    }

    @Override
    public final String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    @Override
    public String objectToXML(Object object) {
        StringWriter stringWriter = new StringWriter();
        try {
            this.serializer.write(object, (Writer)stringWriter);
            return stringWriter.toString();
        }
        catch (Exception exception) {
            this.logger(2, "objectToXML() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(String string) {
        try {
            StringReader stringReader = new StringReader(string);
            return this.serializer.read(XPDERequest.class, (Reader)stringReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(byte[] byArray) {
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(byArray));
            return this.serializer.read(XPDERequest.class, (Reader)inputStreamReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }
}

