/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Disk;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test1;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test10;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test11;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test12;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test13;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test14;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test15;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test16;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test17;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test18;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test19;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test2;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test20;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test21;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test22;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test23;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test24;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test25;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test26;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test27;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test28;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test29;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test3;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test30;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test31;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test32;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test33;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test35;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test36;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test37;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test38;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test4;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test5;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test6;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test7;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test8;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.DAO_Test9;
import org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.test34.pk3.DAO_Test34;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;

public class YP_BCD_A_DCC_Test
extends YP_TCD_DCC_EFT_Business {
    public YP_BCD_A_DCC_Test(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        this.setContainerBusinessType(this.getContainerBusinessType() | 1);
        super.initialize();
        try {
            boolean bl = false;
            boolean bl2 = false;
            if (bl) {
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject4;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject5;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject6;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject7;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject8;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject9;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject10;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject11;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject12;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject13 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test1.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject14 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test1.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject15 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test1.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject16 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test1.class, 0, 64, null);
                this.test1_blahblah(yP_TCD_DesignAccesObject13);
                this.test1_blahblah(yP_TCD_DesignAccesObject14);
                this.test1_blahblah(yP_TCD_DesignAccesObject15);
                this.test1_blahblah(yP_TCD_DesignAccesObject16);
                this.test1_blahblah2(yP_TCD_DesignAccesObject13);
                this.test1_blahblah2(yP_TCD_DesignAccesObject14);
                this.test1_blahblah2(yP_TCD_DesignAccesObject15);
                this.test1_blahblah2(yP_TCD_DesignAccesObject16);
                this.test1_blahblah3(yP_TCD_DesignAccesObject13);
                this.test1_blahblah3(yP_TCD_DesignAccesObject14);
                this.test1_blahblah3(yP_TCD_DesignAccesObject15);
                this.test1_blahblah3(yP_TCD_DesignAccesObject16);
                this.test1_blahblah4(yP_TCD_DesignAccesObject13);
                this.test1_blahblah4(yP_TCD_DesignAccesObject14);
                this.test1_blahblah4(yP_TCD_DesignAccesObject15);
                this.test1_blahblah4(yP_TCD_DesignAccesObject16);
                this.test1_blahblah5(yP_TCD_DesignAccesObject13);
                this.test1_blahblah5(yP_TCD_DesignAccesObject14);
                this.test1_blahblah5(yP_TCD_DesignAccesObject15);
                this.test1_blahblah5(yP_TCD_DesignAccesObject16);
                this.test1_blahblah6(yP_TCD_DesignAccesObject13);
                this.test1_blahblah6(yP_TCD_DesignAccesObject14);
                this.test1_blahblah6(yP_TCD_DesignAccesObject15);
                this.test1_blahblah6(yP_TCD_DesignAccesObject16);
                this.test1_blahblah7(yP_TCD_DesignAccesObject13);
                this.test1_blahblah7(yP_TCD_DesignAccesObject14);
                this.test1_blahblah7(yP_TCD_DesignAccesObject15);
                this.test1_blahblah7(yP_TCD_DesignAccesObject16);
                this.test1_blahblah8(yP_TCD_DesignAccesObject13);
                this.test1_blahblah8(yP_TCD_DesignAccesObject14);
                this.test1_blahblah8(yP_TCD_DesignAccesObject15);
                this.test1_blahblah8(yP_TCD_DesignAccesObject16);
                this.test1_blahblah9(yP_TCD_DesignAccesObject13);
                this.test1_blahblah9(yP_TCD_DesignAccesObject14);
                this.test1_blahblah9(yP_TCD_DesignAccesObject15);
                this.test1_blahblah9(yP_TCD_DesignAccesObject16);
                this.test1_blahblah10(yP_TCD_DesignAccesObject13);
                this.test1_blahblah10(yP_TCD_DesignAccesObject14);
                this.test1_blahblah10(yP_TCD_DesignAccesObject15);
                this.test1_blahblah10(yP_TCD_DesignAccesObject16);
                this.test1_blahblah11(yP_TCD_DesignAccesObject13);
                this.test1_blahblah11(yP_TCD_DesignAccesObject14);
                this.test1_blahblah11(yP_TCD_DesignAccesObject15);
                this.test1_blahblah11(yP_TCD_DesignAccesObject16);
                this.test1_blahblah12(yP_TCD_DesignAccesObject13);
                this.test1_blahblah12(yP_TCD_DesignAccesObject14);
                this.test1_blahblah12(yP_TCD_DesignAccesObject15);
                this.test1_blahblah12(yP_TCD_DesignAccesObject16);
                this.test1_blahblah13(yP_TCD_DesignAccesObject13);
                this.test1_blahblah13(yP_TCD_DesignAccesObject14);
                this.test1_blahblah13(yP_TCD_DesignAccesObject15);
                this.test1_blahblah13(yP_TCD_DesignAccesObject16);
                if (!bl2) {
                    yP_TCD_DesignAccesObject12 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test2.class, 0, 64, null);
                    yP_TCD_DesignAccesObject11 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test2.class, 0, 64, null);
                    yP_TCD_DesignAccesObject10 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test2.class, 0, 64, null);
                    yP_TCD_DesignAccesObject9 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test2.class, 0, 64, null);
                    this.test2_Init(yP_TCD_DesignAccesObject12);
                    this.test2_Init(yP_TCD_DesignAccesObject11);
                    this.test2_Init(yP_TCD_DesignAccesObject10);
                    this.test2_Init(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah1(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah1(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah1(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah1(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah2(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah2(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah2(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah2(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah3(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah3(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah3(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah3(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah4(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah4(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah4(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah4(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah5(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah5(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah5(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah5(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah6(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah6(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah6(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah6(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah7(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah7(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah7(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah7(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah8(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah8(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah8(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah8(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah9(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah9(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah9(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah9(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah10(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah10(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah10(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah10(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah11(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah11(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah11(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah11(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah12(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah12(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah12(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah12(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah13(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah13(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah13(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah13(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah14(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah14(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah14(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah14(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah15(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah15(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah15(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah15(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah16(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah16(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah16(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah16(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah17(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah17(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah17(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah17(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah18(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah18(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah18(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah18(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah19(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah19(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah19(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah19(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah20(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah20(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah20(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah20(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah21(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah21(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah21(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah21(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah22(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah22(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah22(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah22(yP_TCD_DesignAccesObject9);
                    this.test2_blahblah23(yP_TCD_DesignAccesObject12);
                    this.test2_blahblah23(yP_TCD_DesignAccesObject11);
                    this.test2_blahblah23(yP_TCD_DesignAccesObject10);
                    this.test2_blahblah23(yP_TCD_DesignAccesObject9);
                    yP_TCD_DesignAccesObject8 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test3.class, 0, 64, null);
                    yP_TCD_DesignAccesObject7 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test3.class, 0, 64, null);
                    yP_TCD_DesignAccesObject6 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test3.class, 0, 64, null);
                    yP_TCD_DesignAccesObject5 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test3.class, 0, 64, null);
                    this.test3_Init(yP_TCD_DesignAccesObject8);
                    this.test3_Init(yP_TCD_DesignAccesObject7);
                    this.test3_Init(yP_TCD_DesignAccesObject6);
                    this.test3_Init(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah1(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah1(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah1(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah1(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah2(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah2(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah2(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah2(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah3(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah3(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah3(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah3(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah4(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah4(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah4(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah4(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah5(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah5(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah5(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah5(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah6(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah6(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah6(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah6(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah7(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah7(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah7(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah7(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah8(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah8(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah8(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah8(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah9(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah9(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah9(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah9(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah10(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah10(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah10(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah10(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah11(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah11(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah11(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah11(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah12(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah12(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah12(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah12(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah13(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah13(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah13(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah13(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah14(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah14(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah14(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah14(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah15(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah15(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah15(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah15(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah16(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah16(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah16(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah16(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah17(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah17(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah17(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah17(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah18(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah18(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah18(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah18(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah19(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah19(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah19(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah19(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah20(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah20(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah20(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah20(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah21(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah21(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah21(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah21(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah22(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah22(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah22(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah22(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah23(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah23(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah23(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah23(yP_TCD_DesignAccesObject5);
                    this.test3_blahblah24(yP_TCD_DesignAccesObject8);
                    this.test3_blahblah24(yP_TCD_DesignAccesObject7);
                    this.test3_blahblah24(yP_TCD_DesignAccesObject6);
                    this.test3_blahblah24(yP_TCD_DesignAccesObject5);
                    if (UtilsYP.getInstanceRole() == 2) {
                        yP_TCD_DesignAccesObject4 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test4.class, 0, 64, null);
                        this.test4_blahblah1(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah2(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah3(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah4(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah5(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah6(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah7(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah8(yP_TCD_DesignAccesObject4);
                        this.test4_blahblah9(yP_TCD_DesignAccesObject4);
                        yP_TCD_DesignAccesObject3 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test5.class, 0, 64, null);
                        this.test5_blahblah1(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah2(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah3(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah4(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah5(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah6(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah7(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah8(yP_TCD_DesignAccesObject3);
                        this.test5_blahblah9(yP_TCD_DesignAccesObject3);
                    }
                    yP_TCD_DesignAccesObject4 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test6.class, 0, 64, null);
                    yP_TCD_DesignAccesObject3 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test6.class, 0, 64, null);
                    yP_TCD_DesignAccesObject2 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test6.class, 0, 64, null);
                    this.test6_Init(yP_TCD_DesignAccesObject4);
                    this.test6_Init(yP_TCD_DesignAccesObject3);
                    this.test6_Init(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah1(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah1(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah1(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah2(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah2(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah2(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah3(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah3(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah3(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah4(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah4(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah4(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah5(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah5(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah5(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah6(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah6(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah6(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah7(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah7(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah7(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah8(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah8(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah8(yP_TCD_DesignAccesObject2);
                    this.test6_blahblah9(yP_TCD_DesignAccesObject4);
                    this.test6_blahblah9(yP_TCD_DesignAccesObject3);
                    this.test6_blahblah9(yP_TCD_DesignAccesObject2);
                }
                yP_TCD_DesignAccesObject12 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test7.class, 0, 64, null);
                yP_TCD_DesignAccesObject11 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test7.class, 0, 64, null);
                yP_TCD_DesignAccesObject10 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test7.class, 0, 64, null);
                yP_TCD_DesignAccesObject9 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test7.class, 0, 64, null);
                this.test7_blahblah1(yP_TCD_DesignAccesObject12);
                this.test7_blahblah1(yP_TCD_DesignAccesObject11);
                this.test7_blahblah1(yP_TCD_DesignAccesObject10);
                this.test7_blahblah1(yP_TCD_DesignAccesObject9);
                this.test7_blahblah2(yP_TCD_DesignAccesObject12);
                this.test7_blahblah2(yP_TCD_DesignAccesObject11);
                this.test7_blahblah2(yP_TCD_DesignAccesObject10);
                this.test7_blahblah2(yP_TCD_DesignAccesObject9);
                if (!bl2) {
                    yP_TCD_DesignAccesObject8 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test8.class, 0, 64, null);
                    yP_TCD_DesignAccesObject7 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test8.class, 0, 64, null);
                    yP_TCD_DesignAccesObject6 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test8.class, 0, 64, null);
                    yP_TCD_DesignAccesObject5 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test8.class, 0, 64, null);
                    this.test8_Init(yP_TCD_DesignAccesObject8);
                    this.test8_Init(yP_TCD_DesignAccesObject7);
                    this.test8_Init(yP_TCD_DesignAccesObject6);
                    this.test8_Init(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah1(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah1(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah1(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah1(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah2(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah2(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah2(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah2(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah3(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah3(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah3(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah3(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah4(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah4(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah4(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah4(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah5(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah5(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah5(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah5(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah6(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah6(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah6(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah6(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah7(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah7(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah7(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah7(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah8(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah8(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah8(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah8(yP_TCD_DesignAccesObject5);
                    this.test8_blahblah9(yP_TCD_DesignAccesObject8);
                    this.test8_blahblah9(yP_TCD_DesignAccesObject7);
                    this.test8_blahblah9(yP_TCD_DesignAccesObject6);
                    this.test8_blahblah9(yP_TCD_DesignAccesObject5);
                }
                yP_TCD_DesignAccesObject8 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test9.class, 0, 64, null);
                this.test9_blahblah1(yP_TCD_DesignAccesObject8);
                yP_TCD_DesignAccesObject7 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test10.class, 0, 64, null);
                yP_TCD_DesignAccesObject6 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test10.class, 0, 64, null);
                yP_TCD_DesignAccesObject5 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test10.class, 0, 64, null);
                yP_TCD_DesignAccesObject4 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test10.class, 0, 64, null);
                this.test10_blahblah1(yP_TCD_DesignAccesObject7);
                this.test10_blahblah1(yP_TCD_DesignAccesObject6);
                this.test10_blahblah1(yP_TCD_DesignAccesObject5);
                this.test10_blahblah1(yP_TCD_DesignAccesObject4);
                yP_TCD_DesignAccesObject3 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test11.class, 0, 64, null);
                yP_TCD_DesignAccesObject2 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test11.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject17 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test11.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject18 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test11.class, 0, 64, null);
                this.test11_blahblah1(yP_TCD_DesignAccesObject3);
                this.test11_blahblah1(yP_TCD_DesignAccesObject2);
                this.test11_blahblah1(yP_TCD_DesignAccesObject17);
                this.test11_blahblah1(yP_TCD_DesignAccesObject18);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject19 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test12.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject20 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test12.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject21 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test12.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject22 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test12.class, 0, 64, null);
                this.test12_blahblah1(yP_TCD_DesignAccesObject19);
                this.test12_blahblah1(yP_TCD_DesignAccesObject20);
                this.test12_blahblah1(yP_TCD_DesignAccesObject21);
                this.test12_blahblah1(yP_TCD_DesignAccesObject22);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject23 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test13.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject24 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test13.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject25 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test13.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject26 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test13.class, 0, 64, null);
                this.test13_blahblah1(yP_TCD_DesignAccesObject23);
                this.test13_blahblah1(yP_TCD_DesignAccesObject24);
                this.test13_blahblah1(yP_TCD_DesignAccesObject25);
                this.test13_blahblah1(yP_TCD_DesignAccesObject26);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject27 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test14.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject28 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test14.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject29 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test14.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject30 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test14.class, 0, 64, null);
                this.test14_blahblah1(yP_TCD_DesignAccesObject27);
                this.test14_blahblah1(yP_TCD_DesignAccesObject28);
                this.test14_blahblah1(yP_TCD_DesignAccesObject29);
                this.test14_blahblah1(yP_TCD_DesignAccesObject30);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject31 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test15.class, 0, 64, null);
                this.test15_blahblah1(yP_TCD_DesignAccesObject31);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject32 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test16.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject33 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test16.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject34 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test16.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject35 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test16.class, 0, 64, null);
                this.test16_blahblah1(yP_TCD_DesignAccesObject32);
                this.test16_blahblah1(yP_TCD_DesignAccesObject33);
                this.test16_blahblah1(yP_TCD_DesignAccesObject34);
                this.test16_blahblah1(yP_TCD_DesignAccesObject35);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject36 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test17.class, 0, 64, null);
                this.test17_blahblah1(yP_TCD_DesignAccesObject36);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject37 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test18.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject38 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test18.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject39 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test18.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject40 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test18.class, 0, 64, null);
                this.test18_blahblah1(yP_TCD_DesignAccesObject37);
                this.test18_blahblah1(yP_TCD_DesignAccesObject38);
                this.test18_blahblah1(yP_TCD_DesignAccesObject39);
                this.test18_blahblah1(yP_TCD_DesignAccesObject40);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject41 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test19.class, 0, 64, null);
                this.test19_blahblah1(yP_TCD_DesignAccesObject41);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject42 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test20.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject43 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test20.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject44 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test20.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject45 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test20.class, 0, 64, null);
                this.test20_blahblah1(yP_TCD_DesignAccesObject42);
                this.test20_blahblah1(yP_TCD_DesignAccesObject43);
                this.test20_blahblah1(yP_TCD_DesignAccesObject44);
                this.test20_blahblah1(yP_TCD_DesignAccesObject45);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject46 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test21.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject47 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test21.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject48 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test21.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject49 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test21.class, 0, 64, null);
                this.test21_blahblah1(yP_TCD_DesignAccesObject46);
                this.test21_blahblah1(yP_TCD_DesignAccesObject47);
                this.test21_blahblah1(yP_TCD_DesignAccesObject48);
                this.test21_blahblah1(yP_TCD_DesignAccesObject49);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject50 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test22.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject51 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test22.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject52 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test22.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject53 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test22.class, 0, 64, null);
                this.test22_blahblah1(yP_TCD_DesignAccesObject50);
                this.test22_blahblah1(yP_TCD_DesignAccesObject51);
                this.test22_blahblah1(yP_TCD_DesignAccesObject52);
                this.test22_blahblah1(yP_TCD_DesignAccesObject53);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject54 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test23.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject55 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test23.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject56 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test23.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject57 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test23.class, 0, 64, null);
                this.test23_blahblah1(yP_TCD_DesignAccesObject54);
                this.test23_blahblah1(yP_TCD_DesignAccesObject55);
                this.test23_blahblah1(yP_TCD_DesignAccesObject56);
                this.test23_blahblah1(yP_TCD_DesignAccesObject57);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject58 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test24.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject59 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test24.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject60 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test24.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject61 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test24.class, 0, 64, null);
                this.test24_blahblah1(yP_TCD_DesignAccesObject58);
                this.test24_blahblah1(yP_TCD_DesignAccesObject59);
                this.test24_blahblah1(yP_TCD_DesignAccesObject60);
                this.test24_blahblah1(yP_TCD_DesignAccesObject61);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject62 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test25.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject63 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test25.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject64 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test25.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject65 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test25.class, 0, 64, null);
                this.test25_blahblah1(yP_TCD_DesignAccesObject62);
                this.test25_blahblah1(yP_TCD_DesignAccesObject63);
                this.test25_blahblah1(yP_TCD_DesignAccesObject64);
                this.test25_blahblah1(yP_TCD_DesignAccesObject65);
                this.test25_blahblah2(yP_TCD_DesignAccesObject64);
                this.test25_blahblah2(yP_TCD_DesignAccesObject65);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject66 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test26.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject67 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test26.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject68 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test26.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject69 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", DAO_Test26.class, 0, 64, null);
                this.test26_blahblah1(yP_TCD_DesignAccesObject66);
                this.test26_blahblah1(yP_TCD_DesignAccesObject67);
                this.test26_blahblah1(yP_TCD_DesignAccesObject68);
                this.test26_blahblah1(yP_TCD_DesignAccesObject69);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject70 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test27.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject71 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test27.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject72 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test27.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test27.class, 0, 64, null);
                this.test27_blahblah1(yP_TCD_DesignAccesObject70);
                this.test27_blahblah1(yP_TCD_DesignAccesObject71);
                this.test27_blahblah1(yP_TCD_DesignAccesObject72);
                this.test27_blahblah1(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah2(yP_TCD_DesignAccesObject70);
                this.test27_blahblah2(yP_TCD_DesignAccesObject71);
                this.test27_blahblah2(yP_TCD_DesignAccesObject72);
                this.test27_blahblah2(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah3(yP_TCD_DesignAccesObject70);
                this.test27_blahblah3(yP_TCD_DesignAccesObject71);
                this.test27_blahblah3(yP_TCD_DesignAccesObject72);
                this.test27_blahblah3(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah4(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah5(yP_TCD_DesignAccesObject70);
                this.test27_blahblah5(yP_TCD_DesignAccesObject71);
                this.test27_blahblah5(yP_TCD_DesignAccesObject72);
                this.test27_blahblah5(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah6(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah7(yP_TCD_DesignAccesObject70);
                this.test27_blahblah7(yP_TCD_DesignAccesObject71);
                this.test27_blahblah7(yP_TCD_DesignAccesObject72);
                this.test27_blahblah7(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah8(yP_TCD_DesignAccesObject70);
                this.test27_blahblah8(yP_TCD_DesignAccesObject71);
                this.test27_blahblah8(yP_TCD_DesignAccesObject72);
                this.test27_blahblah8(yP_TCD_DAO_SQL_Transaction);
                this.test27_blahblah9(yP_TCD_DesignAccesObject70);
                this.test27_blahblah9(yP_TCD_DesignAccesObject71);
                this.test27_blahblah9(yP_TCD_DesignAccesObject72);
                this.test27_blahblah9(yP_TCD_DAO_SQL_Transaction);
                this.test27_maxWithEqualAfter(yP_TCD_DesignAccesObject70);
                this.test27_maxWithEqualAfter(yP_TCD_DesignAccesObject71);
                this.test27_maxWithEqualAfter(yP_TCD_DesignAccesObject72);
                this.test27_maxWithEqualAfter(yP_TCD_DAO_SQL_Transaction);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction2 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test28.class, 0, 64, null);
                YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk = (YP_TCD_DAO_SQL_Disk)this.newPluginByName("DAO_Disk", DAO_Test28.class, 0, 72, null);
                this.test28_blahblah1(yP_TCD_DAO_SQL_Transaction2, yP_TCD_DAO_SQL_Disk);
                this.test28_blahblah2(yP_TCD_DAO_SQL_Transaction2, yP_TCD_DAO_SQL_Disk);
                this.test28_blahblah3(yP_TCD_DAO_SQL_Transaction2, yP_TCD_DAO_SQL_Disk);
                this.test28_blahblah4(yP_TCD_DAO_SQL_Transaction2, yP_TCD_DAO_SQL_Disk);
                this.test28_maxWithEqualAfter(yP_TCD_DAO_SQL_Transaction2, yP_TCD_DAO_SQL_Disk);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject73 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test29.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject74 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test29.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject75 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test29.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction3 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test29.class, 0, 64, null);
                this.test29_IndexCreation(yP_TCD_DesignAccesObject73);
                this.test29_IndexCreation(yP_TCD_DesignAccesObject74);
                this.test29_IndexCreation(yP_TCD_DesignAccesObject75);
                this.test29_IndexCreation(yP_TCD_DAO_SQL_Transaction3);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject76 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test30.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject77 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test30.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject78 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test30.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction4 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test30.class, 0, 64, null);
                this.test30_PartitionTimestampCreation(yP_TCD_DesignAccesObject76);
                this.test30_PartitionTimestampCreation(yP_TCD_DesignAccesObject77);
                this.test30_PartitionTimestampCreation(yP_TCD_DesignAccesObject78);
                this.test30_PartitionTimestampCreation(yP_TCD_DAO_SQL_Transaction4);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject79 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test31.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject80 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test31.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject81 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test31.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction5 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test31.class, 0, 64, null);
                this.test30_PartitionMSCreation(yP_TCD_DesignAccesObject79);
                this.test30_PartitionMSCreation(yP_TCD_DesignAccesObject80);
                this.test30_PartitionMSCreation(yP_TCD_DesignAccesObject81);
                this.test30_PartitionMSCreation(yP_TCD_DAO_SQL_Transaction5);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject82 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test32.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject83 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test32.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject84 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test32.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction6 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test32.class, 0, 64, null);
                this.test32_SpecialsChars(yP_TCD_DesignAccesObject82);
                this.test32_SpecialsChars(yP_TCD_DesignAccesObject83);
                this.test32_SpecialsChars(yP_TCD_DesignAccesObject84);
                this.test32_SpecialsChars(yP_TCD_DAO_SQL_Transaction6);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction7 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test33.class, 0, 64, null);
                this.test33_TableNameExtensions(yP_TCD_DAO_SQL_Transaction7);
                if (UtilsYP.getInstanceRole() == 1) {
                    this.newPluginByName("DAO_Transaction", org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.test34.pk1.DAO_Test34.class, 0, 64, null);
                    this.newPluginByName("DAO_Transaction", org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.test34.pk2.DAO_Test34.class, 0, 64, null);
                    this.newPluginByName("DAO_Transaction", DAO_Test34.class, 0, 64, null);
                    yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Transaction", org.yp.framework.ondemandcomponents.applications.test.designaccesobjects.test34.pk1.DAO_Test34.class, 0, 64, null);
                    yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, "DROP TABLE " + yP_TCD_DesignAccesObject.getFullTableName(), 0);
                }
                yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Table", DAO_Test35.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject85 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Memory", DAO_Test35.class, 0, 64, null);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject86 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test35.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction8 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test35.class, 0, 64, null);
                this.test35_SpecialsColumnName(yP_TCD_DesignAccesObject);
                this.test35_SpecialsColumnName(yP_TCD_DesignAccesObject85);
                this.test35_SpecialsColumnName(yP_TCD_DesignAccesObject86);
                this.test35_SpecialsColumnName(yP_TCD_DAO_SQL_Transaction8);
                this.test35_MultipleGabarit(yP_TCD_DesignAccesObject);
                this.test35_MultipleGabarit(yP_TCD_DesignAccesObject85);
                this.test35_MultipleGabarit(yP_TCD_DesignAccesObject86);
                this.test35_MultipleGabarit(yP_TCD_DAO_SQL_Transaction8);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject87 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test36.class, 0, 64, null);
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction9 = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_Test36.class, 0, 64, null);
                this.test36_extendedTVRTestTransaction(yP_TCD_DesignAccesObject87);
                this.test36_extendedTVRTestTransaction(yP_TCD_DAO_SQL_Transaction9);
                this.test36_extendedTVROfflineTransaction(yP_TCD_DesignAccesObject87);
                this.test36_extendedTVROfflineTransaction(yP_TCD_DAO_SQL_Transaction9);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject88 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test37.class, 0, 64, null);
                this.test37_bigTable(yP_TCD_DesignAccesObject88);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject89 = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_Test38.class, 0, 64, null);
                this.test38_ticketTrim(yP_TCD_DesignAccesObject89);
            }
        }
        catch (Exception exception) {
            this.logger(2, "initialise()" + exception);
        }
        return 1;
    }

    private int test1_blahblah(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.EQUAL, 0L) != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.EQUAL, "") != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.EQUAL, 0.0f) != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0L) != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.EQUAL, 0L) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Long", YP_ComplexGabarit.OPERATOR.EQUAL, 0L) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        if (yP_ComplexGabarit2.set("test1Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah10(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test1_blahblah10() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test1Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah10() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah10() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah11(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah11() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test1Long", YP_ComplexGabarit.OPERATOR.EQUAL, 0L) != 1) {
            this.logger(2, "test1_blahblah11() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah11() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah12(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah12() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test1Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test1_blahblah12() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah12() ");
            return -1;
        }
        return 1;
    }

    private int test1_blahblah13(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test1Int", YP_ComplexGabarit.OPERATOR.IN, 0) != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Long", YP_ComplexGabarit.OPERATOR.IN, 0L) != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1CharArray", YP_ComplexGabarit.OPERATOR.IN, "") != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Timestamp", YP_ComplexGabarit.OPERATOR.IN, new Timestamp(0L)) != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Float", YP_ComplexGabarit.OPERATOR.IN, 0.0f) != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test1Date", YP_ComplexGabarit.OPERATOR.IN, new Date(0L)) != 1) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test1_blahblah13() ");
            return -1;
        }
        return 1;
    }

    private int test2_Init(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_Row yP_Row;
        block3: {
            try {
                yP_TCD_DesignAccesObject.deleteRows(true);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                if (yP_Row != null) break block3;
                this.logger(2, "test2_Init() ");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "test2_Init() ", exception);
                return -1;
            }
        }
        yP_TCD_DesignAccesObject.addRow(yP_Row);
        yP_TCD_DesignAccesObject.persist();
        return 1;
    }

    private int test2_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test2_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test2_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test2_blahblah3() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0) != 1) {
            this.logger(2, "test2_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 0) != 1) {
            this.logger(2, "test2_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah7() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test2Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah8() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test2Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test2_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah10(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Date", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test2_blahblah10() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah10() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah11(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0L) != 1) {
            this.logger(2, "test2_blahblah11() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah11() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah12(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test2_blahblah12() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah12() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah13(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Timestamp", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Timestamp(0L)) != 1) {
            this.logger(2, "test2_blahblah13() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah13() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah14(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0.0f) != 1) {
            this.logger(2, "test2_blahblah14() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah14() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah15(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(0L)) != 1) {
            this.logger(2, "test2_blahblah15() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah15() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah16(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.LESS, 0) != 1) {
            this.logger(2, "test2_blahblah16() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah16() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah17(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Long", YP_ComplexGabarit.OPERATOR.LESS, 0L) != 1) {
            this.logger(2, "test2_blahblah17() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah17() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah18(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Date", YP_ComplexGabarit.OPERATOR.LESS, new Date(0L)) != 1) {
            this.logger(2, "test2_blahblah18() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah18() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah19(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Timestamp", YP_ComplexGabarit.OPERATOR.LESS, new Timestamp(0L)) != 1) {
            this.logger(2, "test2_blahblah19() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah19() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah20(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Float", YP_ComplexGabarit.OPERATOR.LESS, 0.0f) != 1) {
            this.logger(2, "test2_blahblah20() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test2_blahblah20() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah21(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2CharArray", YP_ComplexGabarit.OPERATOR.EQUAL, "") != 1) {
            this.logger(2, "test2_blahblah21() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah21() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah22(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1) != 1) {
            this.logger(2, "test2_blahblah22() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test2_blahblah22() ");
            return -1;
        }
        return 1;
    }

    private int test2_blahblah23(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test2CharArray", YP_ComplexGabarit.OPERATOR.DIFFERENT, "") != 1) {
            this.logger(2, "test2_blahblah23() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 0) {
            this.logger(2, "test2_blahblah23() ");
            return -1;
        }
        return 1;
    }

    private int test3_Init(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_Row yP_Row;
        block5: {
            YP_Row yP_Row2;
            block4: {
                try {
                    yP_TCD_DesignAccesObject.deleteRows(true);
                    yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                    if (yP_Row2 != null) break block4;
                    this.logger(2, "test3_Init() ");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "test3_Init() ", exception);
                    return -1;
                }
            }
            yP_TCD_DesignAccesObject.addRow(yP_Row2);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            if (yP_Row != null) break block5;
            this.logger(2, "test3_Init() ");
            return -1;
        }
        yP_TCD_DesignAccesObject.addRow(yP_Row);
        yP_TCD_DesignAccesObject.persist();
        return 1;
    }

    private int test3_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test3_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test3_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test3_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah3()  ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0) != 1) {
            this.logger(2, "test3_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 0) != 1) {
            this.logger(2, "test3_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah7() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test3Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah8() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test3Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test3_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah10(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah10() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah10() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah11(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah11() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah11() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah12(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test3_blahblah12() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah12() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.IN, 0) != 1) {
            this.logger(2, "test3_blahblah12() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah12() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah13(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1) != 1) {
            this.logger(2, "test3_blahblah13() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah13() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah14(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1) != 1) {
            this.logger(2, "test3_blahblah14() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test3_blahblah14() ");
            return -1;
        }
        List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(1, 1, yP_ComplexGabarit);
        if (list2 == null || list2.size() != 1) {
            this.logger(2, "test3_blahblah14() ");
            return -1;
        }
        if (list2.get(0).equals(list.get(0))) {
            this.logger(2, "test3_blahblah14() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah15(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1) != 1) {
            this.logger(2, "test3_blahblah15() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(2, 100, yP_ComplexGabarit);
        if (list != null && !list.isEmpty()) {
            this.logger(2, "test3_blahblah15() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah16(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction && UtilsYP.getInstanceRole() != 1) {
            return 0;
        }
        YP_Row yP_Row = yP_TCD_DesignAccesObject.getRowAt(0);
        if (yP_Row == null) {
            this.logger(2, "test3_blahblah16() ");
            return -1;
        }
        YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getRowAt(1);
        if (yP_Row2 == null) {
            this.logger(2, "test3_blahblah16() ");
            return -1;
        }
        YP_Row yP_Row3 = yP_TCD_DesignAccesObject.getRowAt(2);
        if (yP_Row3 != null) {
            this.logger(2, "test3_blahblah16() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah17(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah17() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah17() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah18(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah18() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah18() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah19(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah19() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.GROUP) != 1) {
            this.logger(2, "test3_blahblah19() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah19() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah20(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Float", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah20() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.GROUP) != 1) {
            this.logger(2, "test3_blahblah20() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah20() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah21(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah21() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah21() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah22(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah22() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah22() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah23(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test3_blahblah23() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test3Long", YP_ComplexGabarit.OPERATOR.GROUP) != 1) {
            this.logger(2, "test3_blahblah23() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah23() ");
            return -1;
        }
        return 1;
    }

    private int test3_blahblah24(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test3Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test3_blahblah24() ");
            return -1;
        }
        if (yP_ComplexGabarit.set("test3Long", YP_ComplexGabarit.OPERATOR.GROUP) != 1) {
            this.logger(2, "test3_blahblah24() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test3_blahblah24() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test4_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah1() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test4_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test4_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test4_blahblah3() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah3() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test4_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah4() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0) != 1) {
            this.logger(2, "test4_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah5() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 0) != 1) {
            this.logger(2, "test4_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah6() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test4_blahblah7() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test4Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test4_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah7() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test4_blahblah8() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test4Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test4_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah8() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test4_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test4Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test4_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test4_blahblah9() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test4_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) != 1) {
            this.logger(2, "test5_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test5_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test5_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || !list.isEmpty()) {
                this.logger(2, "test5_blahblah2() ");
                return -1;
            }
        } else if (list == null || list.size() != 1) {
            this.logger(2, "test5_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test5_blahblah3() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test5_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test5_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test5_blahblah4() ");
                return -1;
            }
        } else if (list == null || list.size() != 1) {
            this.logger(2, "test5_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0) != 1) {
            this.logger(2, "test5_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test5_blahblah5() ");
                return -1;
            }
        } else if (list == null || list.size() != 3) {
            this.logger(2, "test5_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 0) != 1) {
            this.logger(2, "test5_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test5_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test5_blahblah7() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test5Long", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test5_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test5_blahblah7() ");
                return -1;
            }
        } else if (list == null || list.size() != 1) {
            this.logger(2, "test5_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test5_blahblah8() ");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit2.set("test5Long", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) != 1) {
            this.logger(2, "test5_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test5_blahblah8() ");
                return -1;
            }
        } else if (list == null || list.size() != 1) {
            this.logger(2, "test5_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test5_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test5Float", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test5_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (UtilsYP.getInstanceRole() != 2) {
            if (list == null || list.size() != 2) {
                this.logger(2, "test5_blahblah9() ");
                return -1;
            }
        } else if (list == null || list.size() != 1) {
            this.logger(2, "test5_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test6_Init(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_Row yP_Row;
        block5: {
            YP_Row yP_Row2;
            block4: {
                try {
                    yP_TCD_DesignAccesObject.deleteRows(true);
                    yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                    if (yP_Row2 != null) break block4;
                    this.logger(2, "test6_Init() ");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "test6_Init() ", exception);
                    return -1;
                }
            }
            yP_TCD_DesignAccesObject.addRow(yP_Row2);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            if (yP_Row != null) break block5;
            this.logger(2, "test6_Init() ");
            return -1;
        }
        yP_Row.set("test6Long", 1L);
        yP_Row.set("test6Int", 1);
        yP_Row.set("test6Float", 1.0);
        yP_Row.set("test6CharArray", "1");
        yP_Row.set("test6Timestamp", new Timestamp(1000L));
        yP_Row.set("test6Date", new Date(86400000L));
        yP_TCD_DesignAccesObject.addRow(yP_Row);
        yP_TCD_DesignAccesObject.persist();
        return 1;
    }

    private int test6_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Int", YP_ComplexGabarit.OPERATOR.MIN) != 1) {
            this.logger(2, "test6_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Int", YP_ComplexGabarit.OPERATOR.MAX) != 1) {
            this.logger(2, "test6_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        List<String> list = yP_TCD_DesignAccesObject.getDistinctStringValueList("test6Int");
        if (list == null || list.size() != 2) {
            this.logger(2, "test6_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        int n;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Int", YP_ComplexGabarit.OPERATOR.ORDER_ASC) != 1) {
            this.logger(2, "test6_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test6_blahblah4() ");
            return -1;
        }
        int n2 = (Integer)list.get(0).getFieldValueByName("test6Int");
        if (n2 > (n = ((Integer)list.get(1).getFieldValueByName("test6Int")).intValue())) {
            this.logger(2, "test6_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        int n;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Int", YP_ComplexGabarit.OPERATOR.ORDER_DESC) != 1) {
            this.logger(2, "test6_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test6_blahblah5() ");
            return -1;
        }
        int n2 = (Integer)list.get(0).getFieldValueByName("test6Int");
        if (n2 < (n = ((Integer)list.get(1).getFieldValueByName("test6Int")).intValue())) {
            this.logger(2, "test6_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Date", YP_ComplexGabarit.OPERATOR.GREATER, new Date(0L)) != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Date", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(0L)) != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Date", YP_ComplexGabarit.OPERATOR.IN, new Date(0L)) != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Timestamp", YP_ComplexGabarit.OPERATOR.GREATER, new Timestamp(0L)) != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Timestamp", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(0L)) != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Timestamp", YP_ComplexGabarit.OPERATOR.IN, new Timestamp(0L)) != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test6_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Date", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, new Date(0L)) != 1) {
            this.logger(2, "test6_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test6_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test6_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test6Timestamp", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, new Timestamp(0L)) != 1) {
            this.logger(2, "test6_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test6_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test7_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block23: {
            List<YP_Row> list;
            block22: {
                YP_ComplexGabarit yP_ComplexGabarit;
                block21: {
                    block20: {
                        List<YP_Row> list2;
                        block19: {
                            YP_ComplexGabarit yP_ComplexGabarit2;
                            block18: {
                                YP_Row yP_Row;
                                block17: {
                                    YP_Row yP_Row2;
                                    block16: {
                                        block15: {
                                            block14: {
                                                try {
                                                    if (UtilsYP.getInstanceRole() == 1) break block14;
                                                    return 0;
                                                }
                                                catch (Exception exception) {
                                                    this.logger(2, "test7_blahblah1() " + exception);
                                                    return -1;
                                                }
                                            }
                                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block15;
                                            this.logger(2, "test7_blahblah1() ");
                                            return -1;
                                        }
                                        yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                                        if (yP_Row2 != null) break block16;
                                        this.logger(2, "test7_blahblah1() ");
                                        return -1;
                                    }
                                    yP_Row2.set("test7Int", 1);
                                    yP_TCD_DesignAccesObject.addRow(yP_Row2);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    if (yP_Row != null) break block17;
                                    this.logger(2, "test7_blahblah1() ");
                                    return -1;
                                }
                                yP_Row.set("test7Int", 2);
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                    yP_TCD_DesignAccesObject.persist();
                                }
                                if ((yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test7Int", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block18;
                                this.logger(2, "test7_blahblah1() ");
                                return -1;
                            }
                            list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2);
                            if (list2 != null && list2.size() == 1) break block19;
                            this.logger(2, "test7_blahblah1() ");
                            return -1;
                        }
                        if ((Integer)list2.get(0).getFieldValueByName("test7Int") == 1) break block20;
                        this.logger(2, "test7_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    if (yP_ComplexGabarit.set("test7Int", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block21;
                    this.logger(2, "test7_blahblah1() ");
                    return -1;
                }
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block22;
                this.logger(2, "test7_blahblah1() ");
                return -1;
            }
            if ((Integer)list.get(0).getFieldValueByName("test7Int") == 2) break block23;
            this.logger(2, "test7_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test7_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test7_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block15: {
            YP_ComplexGabarit yP_ComplexGabarit;
            block14: {
                YP_Row yP_Row;
                block13: {
                    YP_Row yP_Row2;
                    block12: {
                        block11: {
                            block10: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block10;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test7_blahblah2() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block11;
                            this.logger(2, "test7_blahblah2() ");
                            return -1;
                        }
                        yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                        if (yP_Row2 != null) break block12;
                        this.logger(2, "test7_blahblah2() ");
                        return -1;
                    }
                    yP_Row2.set("test7Int", 1);
                    yP_TCD_DesignAccesObject.addRow(yP_Row2);
                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                    if (yP_Row != null) break block13;
                    this.logger(2, "test7_blahblah2() ");
                    return -1;
                }
                yP_Row.set("test7Int", 2);
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                    yP_TCD_DesignAccesObject.persist();
                }
                if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test7Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1) == 1) break block14;
                this.logger(2, "test7_blahblah2() ");
                return -1;
            }
            if (yP_TCD_DesignAccesObject.deleteRowsSuchAs(yP_ComplexGabarit) == 1) break block15;
            this.logger(2, "test7_blahblah2() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRowsSuchAs(null) != 1) {
            this.logger(2, "test7_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test8_Init(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            yP_TCD_DesignAccesObject.deleteRows(true);
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test8CharArray", "XXX");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row2.set("test8CharArray", "YXXX");
            yP_TCD_DesignAccesObject.addRow(yP_Row2);
            YP_Row yP_Row3 = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row3.set("test8CharArray", "XXXY");
            yP_TCD_DesignAccesObject.addRow(yP_Row3);
            YP_Row yP_Row4 = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row4.set("test8CharArray", "YXXXY");
            yP_TCD_DesignAccesObject.addRow(yP_Row4);
            YP_Row yP_Row5 = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row5.set("test8CharArray", "456");
            yP_TCD_DesignAccesObject.addRow(yP_Row5);
            yP_TCD_DesignAccesObject.persist();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "test8_Init() ", exception);
            return -1;
        }
    }

    private int test8_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.EQUAL, "XXX") != 1) {
            this.logger(2, "test8_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.EQUAL, "XXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "YXX") != 1) {
            this.logger(2, "test8_blahblah2() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah2() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "YXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah2() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah2() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "XXY") != 1) {
            this.logger(2, "test8_blahblah3() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah3() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "XXY".getBytes()) != 1) {
            this.logger(2, "test8_blahblah3() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah3() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah4(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "XXX") != 1) {
            this.logger(2, "test8_blahblah4() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 4) {
            this.logger(2, "test8_blahblah4() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.CONTAIN, "XXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah4() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 4) {
            this.logger(2, "test8_blahblah4() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XXXX") != 1) {
            this.logger(2, "test8_blahblah5() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah5() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XXXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah5() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah5() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah6(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XXX") != 1) {
            this.logger(2, "test8_blahblah6() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah6() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah6() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 1) {
            this.logger(2, "test8_blahblah6() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XX") != 1) {
            this.logger(2, "test8_blahblah7() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test8_blahblah7() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "XX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah7() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test8_blahblah7() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.START_WITH, "XXXX") != 1) {
            this.logger(2, "test8_blahblah8() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test8_blahblah8() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.START_WITH, "XXXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah8() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test8_blahblah8() ");
            return -1;
        }
        return 1;
    }

    private int test8_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.START_WITH, "XXX") != 1) {
            this.logger(2, "test8_blahblah9() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah9() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test8CharArray", YP_ComplexGabarit.OPERATOR.START_WITH, "XXX".getBytes()) != 1) {
            this.logger(2, "test8_blahblah9() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() != 2) {
            this.logger(2, "test8_blahblah9() ");
            return -1;
        }
        return 1;
    }

    private int test9_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT * FROM ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        String string = yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DesignAccesObject);
        if (string != null && !string.isEmpty()) {
            stringBuilder.append("WHERE " + string + "\r\n");
        }
        yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString());
        return 1;
    }

    private int test10_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_MANUAL.toString()) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_MANUAL) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        EntryModeEnumeration entryModeEnumeration = EntryModeEnumeration.ENTRY_MODE_MANUAL;
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)entryModeEnumeration) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.IN, EntryModeEnumeration.ENTRY_MODE_MANUAL.toString()) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.IN, EntryModeEnumeration.ENTRY_MODE_MANUAL) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (yP_ComplexGabarit.set("test10Enumeration", YP_ComplexGabarit.OPERATOR.IN, (Object)entryModeEnumeration) != 1) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || !list.isEmpty()) {
            this.logger(2, "test10_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test11_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block35: {
            List<YP_Row> list;
            block34: {
                YP_ComplexGabarit yP_ComplexGabarit;
                block33: {
                    block32: {
                        List<YP_Row> list2;
                        block31: {
                            YP_ComplexGabarit yP_ComplexGabarit2;
                            block30: {
                                block29: {
                                    block28: {
                                        block27: {
                                            block26: {
                                                block25: {
                                                    block24: {
                                                        YP_Row yP_Row;
                                                        block23: {
                                                            YP_Row yP_Row2;
                                                            block22: {
                                                                block21: {
                                                                    block20: {
                                                                        try {
                                                                            if (UtilsYP.getInstanceRole() == 1) break block20;
                                                                            return 0;
                                                                        }
                                                                        catch (Exception exception) {
                                                                            this.logger(2, "test11_blahblah1() " + exception);
                                                                            return -1;
                                                                        }
                                                                    }
                                                                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block21;
                                                                    this.logger(2, "test11_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                                                                if (yP_Row2 != null) break block22;
                                                                this.logger(2, "test11_blahblah1() ");
                                                                return -1;
                                                            }
                                                            yP_Row2.set("test11Enumeration", EntryModeEnumeration.ENTRY_MODE_MANUAL.toString());
                                                            yP_TCD_DesignAccesObject.addRow(yP_Row2);
                                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                            if (yP_Row != null) break block23;
                                                            this.logger(2, "test11_blahblah1() ");
                                                            return -1;
                                                        }
                                                        yP_Row.set("test11Enumeration", EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS);
                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                            yP_TCD_DesignAccesObject.persist();
                                                        }
                                                        if ((yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test11Enumeration", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_MANUAL) == 1) break block24;
                                                        this.logger(2, "test11_blahblah1() ");
                                                        return -1;
                                                    }
                                                    list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2);
                                                    if (list2 != null && list2.size() == 1) break block25;
                                                    this.logger(2, "test11_blahblah1() ");
                                                    return -1;
                                                }
                                                if (list2.get(0).getFieldValueByName("test11Enumeration") == EntryModeEnumeration.ENTRY_MODE_MANUAL) break block26;
                                                this.logger(2, "test11_blahblah1() ");
                                                return -1;
                                            }
                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                            if (yP_ComplexGabarit.set("test11Enumeration", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS.toString()) == 1) break block27;
                                            this.logger(2, "test11_blahblah1() ");
                                            return -1;
                                        }
                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                        if (list != null && list.size() == 1) break block28;
                                        this.logger(2, "test11_blahblah1() ");
                                        return -1;
                                    }
                                    if (list.get(0).getFieldValueByName("test11Enumeration") == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) break block29;
                                    this.logger(2, "test11_blahblah1() ");
                                    return -1;
                                }
                                yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                if (yP_ComplexGabarit2.set("test11Enumeration", YP_ComplexGabarit.OPERATOR.IN, EntryModeEnumeration.ENTRY_MODE_MANUAL) == 1) break block30;
                                this.logger(2, "test11_blahblah1() ");
                                return -1;
                            }
                            list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2);
                            if (list2 != null && list2.size() == 1) break block31;
                            this.logger(2, "test11_blahblah1() ");
                            return -1;
                        }
                        if (list2.get(0).getFieldValueByName("test11Enumeration") == EntryModeEnumeration.ENTRY_MODE_MANUAL) break block32;
                        this.logger(2, "test11_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    if (yP_ComplexGabarit.set("test11Enumeration", YP_ComplexGabarit.OPERATOR.IN, EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS.toString()) == 1) break block33;
                    this.logger(2, "test11_blahblah1() ");
                    return -1;
                }
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block34;
                this.logger(2, "test11_blahblah1() ");
                return -1;
            }
            if (list.get(0).getFieldValueByName("test11Enumeration") == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) break block35;
            this.logger(2, "test11_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test11_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test12_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block41: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block40: {
                block39: {
                    block38: {
                        block37: {
                            block36: {
                                block35: {
                                    block34: {
                                        block33: {
                                            block32: {
                                                block31: {
                                                    block30: {
                                                        block29: {
                                                            block28: {
                                                                block27: {
                                                                    block26: {
                                                                        YP_Row yP_Row;
                                                                        block25: {
                                                                            block24: {
                                                                                block23: {
                                                                                    try {
                                                                                        if (UtilsYP.getInstanceRole() == 1) break block23;
                                                                                        return 0;
                                                                                    }
                                                                                    catch (Exception exception) {
                                                                                        this.logger(2, "test12_blahblah1() " + exception);
                                                                                        return -1;
                                                                                    }
                                                                                }
                                                                                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block24;
                                                                                this.logger(2, "test12_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                            if (yP_Row != null) break block25;
                                                                            this.logger(2, "test12_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        yP_Row.set("test12Array", "5");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test12Array", "50");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test12Array", "500");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test12Array", "1");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test12Array", "10");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test12Array", "100");
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                            yP_TCD_DesignAccesObject.persist();
                                                                        }
                                                                        if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test12Array", YP_ComplexGabarit.OPERATOR.GREATER, "500") == 1) break block26;
                                                                        this.logger(2, "test12_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                    if (list != null && list.isEmpty()) break block27;
                                                                    this.logger(2, "test12_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.LESS, "1") == 1) break block28;
                                                                this.logger(2, "test12_blahblah1() ");
                                                                return -1;
                                                            }
                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                            if (list != null && list.isEmpty()) break block29;
                                                            this.logger(2, "test12_blahblah1() ");
                                                            return -1;
                                                        }
                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                        if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, "500") == 1) break block30;
                                                        this.logger(2, "test12_blahblah1() ");
                                                        return -1;
                                                    }
                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                    if (list != null && list.size() == 1) break block31;
                                                    this.logger(2, "test12_blahblah1() ");
                                                    return -1;
                                                }
                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, "1") == 1) break block32;
                                                this.logger(2, "test12_blahblah1() ");
                                                return -1;
                                            }
                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                            if (list != null && list.size() == 1) break block33;
                                            this.logger(2, "test12_blahblah1() ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, "10") == 1) break block34;
                                        this.logger(2, "test12_blahblah1() ");
                                        return -1;
                                    }
                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                    if (list != null && list.size() == 5) break block35;
                                    this.logger(2, "test12_blahblah1() ");
                                    return -1;
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.GREATER, "10") == 1) break block36;
                                this.logger(2, "test12_blahblah1() ");
                                return -1;
                            }
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 4) break block37;
                            this.logger(2, "test12_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.LESS, "6") == 1) break block38;
                        this.logger(2, "test12_blahblah1() ");
                        return -1;
                    }
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 6) break block39;
                    this.logger(2, "test12_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                if (yP_ComplexGabarit.set("test12Array", YP_ComplexGabarit.OPERATOR.GREATER, "6") == 1) break block40;
                this.logger(2, "test12_blahblah1() ");
                return -1;
            }
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.isEmpty()) break block41;
            this.logger(2, "test12_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test12_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test13_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block43: {
            List<YP_Row> list;
            block42: {
                YP_ComplexGabarit yP_ComplexGabarit;
                block41: {
                    block40: {
                        block39: {
                            block38: {
                                block37: {
                                    block36: {
                                        block35: {
                                            block34: {
                                                block33: {
                                                    block32: {
                                                        block31: {
                                                            block30: {
                                                                block29: {
                                                                    block28: {
                                                                        block27: {
                                                                            YP_Row yP_Row;
                                                                            block26: {
                                                                                block25: {
                                                                                    block24: {
                                                                                        try {
                                                                                            if (UtilsYP.getInstanceRole() == 1) break block24;
                                                                                            return 0;
                                                                                        }
                                                                                        catch (Exception exception) {
                                                                                            this.logger(2, "test13_blahblah1() " + exception);
                                                                                            return -1;
                                                                                        }
                                                                                    }
                                                                                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block25;
                                                                                    this.logger(2, "test13_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                if (yP_Row != null) break block26;
                                                                                this.logger(2, "test13_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            yP_Row.set("test13Long", 5);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            yP_Row.set("test13Long", 50);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            yP_Row.set("test13Long", 500);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            yP_Row.set("test13Long", 1);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            yP_Row.set("test13Long", 10);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            yP_Row.set("test13Long", 100);
                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                                yP_TCD_DesignAccesObject.persist();
                                                                            }
                                                                            if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test13Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block27;
                                                                            this.logger(2, "test13_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                        if (list != null && list.size() == 1) break block28;
                                                                        this.logger(2, "test13_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    if ((Long)list.get(0).getFieldValueByName("test13Long") == 500L) break block29;
                                                                    this.logger(2, "test13_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block30;
                                                                this.logger(2, "test13_blahblah1() ");
                                                                return -1;
                                                            }
                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                            if (list != null && list.size() == 1) break block31;
                                                            this.logger(2, "test13_blahblah1() ");
                                                            return -1;
                                                        }
                                                        if ((Long)list.get(0).getFieldValueByName("test13Long") == 1L) break block32;
                                                        this.logger(2, "test13_blahblah1() ");
                                                        return -1;
                                                    }
                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                    if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block33;
                                                    this.logger(2, "test13_blahblah1() ");
                                                    return -1;
                                                }
                                                if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.LESS, 100) == 1) break block34;
                                                this.logger(2, "test13_blahblah1() ");
                                                return -1;
                                            }
                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                            if (list != null && list.size() == 1) break block35;
                                            this.logger(2, "test13_blahblah1() ");
                                            return -1;
                                        }
                                        if ((Long)list.get(0).getFieldValueByName("test13Long") == 50L) break block36;
                                        this.logger(2, "test13_blahblah1() ");
                                        return -1;
                                    }
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block37;
                                    this.logger(2, "test13_blahblah1() ");
                                    return -1;
                                }
                                if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.GREATER, 50) == 1) break block38;
                                this.logger(2, "test13_blahblah1() ");
                                return -1;
                            }
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 1) break block39;
                            this.logger(2, "test13_blahblah1() ");
                            return -1;
                        }
                        if ((Long)list.get(0).getFieldValueByName("test13Long") == 100L) break block40;
                        this.logger(2, "test13_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    if (yP_ComplexGabarit.set("test13Long", YP_ComplexGabarit.OPERATOR.IN, 500) == 1) break block41;
                    this.logger(2, "test13_blahblah1() ");
                    return -1;
                }
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block42;
                this.logger(2, "test13_blahblah1() ");
                return -1;
            }
            if ((Long)list.get(0).getFieldValueByName("test13Long") == 500L) break block43;
            this.logger(2, "test13_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test13_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test14_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block93: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block92: {
                block91: {
                    block90: {
                        block89: {
                            YP_Row yP_Row;
                            block88: {
                                block87: {
                                    block86: {
                                        block85: {
                                            block84: {
                                                block83: {
                                                    block82: {
                                                        block81: {
                                                            block80: {
                                                                block79: {
                                                                    block78: {
                                                                        block77: {
                                                                            block76: {
                                                                                block75: {
                                                                                    block74: {
                                                                                        block73: {
                                                                                            block72: {
                                                                                                block71: {
                                                                                                    block70: {
                                                                                                        block69: {
                                                                                                            block68: {
                                                                                                                block67: {
                                                                                                                    block66: {
                                                                                                                        block65: {
                                                                                                                            block64: {
                                                                                                                                block63: {
                                                                                                                                    block62: {
                                                                                                                                        block61: {
                                                                                                                                            block60: {
                                                                                                                                                block59: {
                                                                                                                                                    block58: {
                                                                                                                                                        block57: {
                                                                                                                                                            block56: {
                                                                                                                                                                block55: {
                                                                                                                                                                    block54: {
                                                                                                                                                                        block53: {
                                                                                                                                                                            block52: {
                                                                                                                                                                                block51: {
                                                                                                                                                                                    block50: {
                                                                                                                                                                                        block49: {
                                                                                                                                                                                            try {
                                                                                                                                                                                                if (UtilsYP.getInstanceRole() == 1) break block49;
                                                                                                                                                                                                return 0;
                                                                                                                                                                                            }
                                                                                                                                                                                            catch (Exception exception) {
                                                                                                                                                                                                this.logger(2, "test14_blahblah1() " + exception);
                                                                                                                                                                                                return -1;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                        if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block50;
                                                                                                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                                        return -1;
                                                                                                                                                                                    }
                                                                                                                                                                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                                                                                                                    if (yP_Row != null) break block51;
                                                                                                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                                    return -1;
                                                                                                                                                                                }
                                                                                                                                                                                yP_Row.set("test14Array", "number1");
                                                                                                                                                                                yP_Row.set("test14Long", 5);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number1");
                                                                                                                                                                                yP_Row.set("test14Long", 5);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number1");
                                                                                                                                                                                yP_Row.set("test14Long", 50);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number1");
                                                                                                                                                                                yP_Row.set("test14Long", 5);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number1");
                                                                                                                                                                                yP_Row.set("test14Long", 500);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number2");
                                                                                                                                                                                yP_Row.set("test14Long", 1);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number2");
                                                                                                                                                                                yP_Row.set("test14Long", 10);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                yP_Row.set("test14Array", "number2");
                                                                                                                                                                                yP_Row.set("test14Long", 100);
                                                                                                                                                                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                                                                                                                                    yP_TCD_DesignAccesObject.persist();
                                                                                                                                                                                }
                                                                                                                                                                                if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block52;
                                                                                                                                                                                this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                                return -1;
                                                                                                                                                                            }
                                                                                                                                                                            if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block53;
                                                                                                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                            return -1;
                                                                                                                                                                        }
                                                                                                                                                                        if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block54;
                                                                                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                        return -1;
                                                                                                                                                                    }
                                                                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                    if (list != null && list.size() == 2) break block55;
                                                                                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                    return -1;
                                                                                                                                                                }
                                                                                                                                                                if ((Long)list.get(0).getFieldValueByName("test14Long") == 100L) break block56;
                                                                                                                                                                this.logger(2, "test14_blahblah1() ");
                                                                                                                                                                return -1;
                                                                                                                                                            }
                                                                                                                                                            if (list.get(0).getFieldStringValueByName("test14Array").contentEquals("number2")) break block57;
                                                                                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                                                                                            return -1;
                                                                                                                                                        }
                                                                                                                                                        if ((Long)list.get(1).getFieldValueByName("test14Long") == 500L) break block58;
                                                                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                                                                        return -1;
                                                                                                                                                    }
                                                                                                                                                    if (list.get(1).getFieldStringValueByName("test14Array").contentEquals("number1")) break block59;
                                                                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                                                                    return -1;
                                                                                                                                                }
                                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block60;
                                                                                                                                                this.logger(2, "test14_blahblah1() ");
                                                                                                                                                return -1;
                                                                                                                                            }
                                                                                                                                            if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block61;
                                                                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                                                                            return -1;
                                                                                                                                        }
                                                                                                                                        if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.LESS, 100) == 1) break block62;
                                                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                                                        return -1;
                                                                                                                                    }
                                                                                                                                    if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block63;
                                                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                                                    return -1;
                                                                                                                                }
                                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                if (list != null && list.size() == 2) break block64;
                                                                                                                                this.logger(2, "test14_blahblah1()  ");
                                                                                                                                return -1;
                                                                                                                            }
                                                                                                                            if ((Long)list.get(0).getFieldValueByName("test14Long") == 10L) break block65;
                                                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                                                            return -1;
                                                                                                                        }
                                                                                                                        if (list.get(0).getFieldStringValueByName("test14Array").contentEquals("number2")) break block66;
                                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                                        return -1;
                                                                                                                    }
                                                                                                                    if ((Long)list.get(1).getFieldValueByName("test14Long") == 50L) break block67;
                                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                                    return -1;
                                                                                                                }
                                                                                                                if (list.get(1).getFieldStringValueByName("test14Array").contentEquals("number1")) break block68;
                                                                                                                this.logger(2, "test14_blahblah1() ");
                                                                                                                return -1;
                                                                                                            }
                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                            if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block69;
                                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                                            return -1;
                                                                                                        }
                                                                                                        if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block70;
                                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                                        return -1;
                                                                                                    }
                                                                                                    if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block71;
                                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                                    return -1;
                                                                                                }
                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                if (list != null && list.size() == 4) break block72;
                                                                                                this.logger(2, "test14_blahblah1()  ");
                                                                                                return -1;
                                                                                            }
                                                                                            if ((Long)list.get(0).getFieldValueByName("test14Long") == 1L) break block73;
                                                                                            this.logger(2, "test14_blahblah1() ");
                                                                                            return -1;
                                                                                        }
                                                                                        if (list.get(0).getFieldStringValueByName("test14Array").contentEquals("number2")) break block74;
                                                                                        this.logger(2, "test14_blahblah1() ");
                                                                                        return -1;
                                                                                    }
                                                                                    if ((Long)list.get(1).getFieldValueByName("test14Long") == 5L) break block75;
                                                                                    this.logger(2, "test14_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                if (list.get(1).getFieldStringValueByName("test14Array").contentEquals("number1")) break block76;
                                                                                this.logger(2, "test14_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                            if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block77;
                                                                            this.logger(2, "test14_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block78;
                                                                        this.logger(2, "test14_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.GREATER, 5) == 1) break block79;
                                                                    this.logger(2, "test14_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block80;
                                                                this.logger(2, "test14_blahblah1() ");
                                                                return -1;
                                                            }
                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                            if (list != null && list.size() == 2) break block81;
                                                            this.logger(2, "test14_blahblah1()  ");
                                                            return -1;
                                                        }
                                                        if ((Long)list.get(0).getFieldValueByName("test14Long") == 10L) break block82;
                                                        this.logger(2, "test14_blahblah1() ");
                                                        return -1;
                                                    }
                                                    if (list.get(0).getFieldStringValueByName("test14Array").contentEquals("number2")) break block83;
                                                    this.logger(2, "test14_blahblah1() ");
                                                    return -1;
                                                }
                                                if ((Long)list.get(1).getFieldValueByName("test14Long") == 50L) break block84;
                                                this.logger(2, "test14_blahblah1() ");
                                                return -1;
                                            }
                                            if (list.get(1).getFieldStringValueByName("test14Array").contentEquals("number1")) break block85;
                                            this.logger(2, "test14_blahblah1() ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block86;
                                        this.logger(2, "test14_blahblah1() ");
                                        return -1;
                                    }
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("test14Array", "numbersMax");
                                    yP_TCD_DesignAccesObject.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block87;
                                    this.logger(2, "test14_blahblah1() ");
                                    return -1;
                                }
                                if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block88;
                                this.logger(2, "test14_blahblah1() ");
                                return -1;
                            }
                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                            yP_Row.set("test14Array", "numbersMax");
                            yP_TCD_DesignAccesObject.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block89;
                            this.logger(2, "test14_blahblah1() ");
                            return -1;
                        }
                        if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block90;
                        this.logger(2, "test14_blahblah1() ");
                        return -1;
                    }
                    if (yP_ComplexGabarit.set("test14Long", YP_ComplexGabarit.OPERATOR.EQUAL, 5) == 1) break block91;
                    this.logger(2, "test14_blahblah1() ");
                    return -1;
                }
                if (yP_ComplexGabarit.set("test14Array", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block92;
                this.logger(2, "test14_blahblah1() ");
                return -1;
            }
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 3) break block93;
            this.logger(2, "test14_blahblah1()  ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test14_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test15_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        List<YP_Row> list;
        block186: {
            block185: {
                block184: {
                    block183: {
                        YP_ComplexGabarit yP_ComplexGabarit;
                        block182: {
                            block181: {
                                block180: {
                                    block179: {
                                        block178: {
                                            block177: {
                                                block176: {
                                                    block175: {
                                                        block174: {
                                                            block173: {
                                                                block172: {
                                                                    block171: {
                                                                        block170: {
                                                                            block169: {
                                                                                block168: {
                                                                                    block167: {
                                                                                        block166: {
                                                                                            block165: {
                                                                                                block164: {
                                                                                                    block163: {
                                                                                                        block162: {
                                                                                                            block161: {
                                                                                                                block160: {
                                                                                                                    block159: {
                                                                                                                        block158: {
                                                                                                                            block157: {
                                                                                                                                block156: {
                                                                                                                                    block155: {
                                                                                                                                        block154: {
                                                                                                                                            block153: {
                                                                                                                                                block152: {
                                                                                                                                                    block151: {
                                                                                                                                                        block150: {
                                                                                                                                                            block149: {
                                                                                                                                                                block148: {
                                                                                                                                                                    block147: {
                                                                                                                                                                        block146: {
                                                                                                                                                                            block145: {
                                                                                                                                                                                block144: {
                                                                                                                                                                                    block143: {
                                                                                                                                                                                        block142: {
                                                                                                                                                                                            block141: {
                                                                                                                                                                                                block140: {
                                                                                                                                                                                                    block139: {
                                                                                                                                                                                                        block138: {
                                                                                                                                                                                                            block137: {
                                                                                                                                                                                                                block136: {
                                                                                                                                                                                                                    block135: {
                                                                                                                                                                                                                        block134: {
                                                                                                                                                                                                                            block133: {
                                                                                                                                                                                                                                block132: {
                                                                                                                                                                                                                                    block131: {
                                                                                                                                                                                                                                        block130: {
                                                                                                                                                                                                                                            block129: {
                                                                                                                                                                                                                                                block128: {
                                                                                                                                                                                                                                                    block127: {
                                                                                                                                                                                                                                                        block126: {
                                                                                                                                                                                                                                                            block125: {
                                                                                                                                                                                                                                                                block124: {
                                                                                                                                                                                                                                                                    block123: {
                                                                                                                                                                                                                                                                        block122: {
                                                                                                                                                                                                                                                                            block121: {
                                                                                                                                                                                                                                                                                block120: {
                                                                                                                                                                                                                                                                                    block119: {
                                                                                                                                                                                                                                                                                        block118: {
                                                                                                                                                                                                                                                                                            block117: {
                                                                                                                                                                                                                                                                                                block116: {
                                                                                                                                                                                                                                                                                                    block115: {
                                                                                                                                                                                                                                                                                                        block114: {
                                                                                                                                                                                                                                                                                                            YP_ComplexGabarit yP_ComplexGabarit2;
                                                                                                                                                                                                                                                                                                            long l;
                                                                                                                                                                                                                                                                                                            block113: {
                                                                                                                                                                                                                                                                                                                block112: {
                                                                                                                                                                                                                                                                                                                    block111: {
                                                                                                                                                                                                                                                                                                                        block110: {
                                                                                                                                                                                                                                                                                                                            block109: {
                                                                                                                                                                                                                                                                                                                                block108: {
                                                                                                                                                                                                                                                                                                                                    block107: {
                                                                                                                                                                                                                                                                                                                                        block106: {
                                                                                                                                                                                                                                                                                                                                            block105: {
                                                                                                                                                                                                                                                                                                                                                int n;
                                                                                                                                                                                                                                                                                                                                                block104: {
                                                                                                                                                                                                                                                                                                                                                    block103: {
                                                                                                                                                                                                                                                                                                                                                        block102: {
                                                                                                                                                                                                                                                                                                                                                            block101: {
                                                                                                                                                                                                                                                                                                                                                                block100: {
                                                                                                                                                                                                                                                                                                                                                                    block99: {
                                                                                                                                                                                                                                                                                                                                                                        block98: {
                                                                                                                                                                                                                                                                                                                                                                            block97: {
                                                                                                                                                                                                                                                                                                                                                                                block96: {
                                                                                                                                                                                                                                                                                                                                                                                    block95: {
                                                                                                                                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                                                                                                                                            if (UtilsYP.getInstanceRole() == 2) break block95;
                                                                                                                                                                                                                                                                                                                                                                                            yP_TCD_DesignAccesObject.getRowList();
                                                                                                                                                                                                                                                                                                                                                                                            return 0;
                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                        catch (Exception exception) {
                                                                                                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() " + exception);
                                                                                                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                                    if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) break block96;
                                                                                                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block97;
                                                                                                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                                                            if (list != null && list.size() == 1) break block98;
                                                                                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                        if ((Long)list.get(0).getFieldValueByName("test15Long") == 500L) break block99;
                                                                                                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block100;
                                                                                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                n = yP_TCD_DesignAccesObject.getCountSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                                                if (n == 1) break block101;
                                                                                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block102;
                                                                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                        n = yP_TCD_DesignAccesObject.getCountSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                                        if (n == 2) break block103;
                                                                                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1) == 1) break block104;
                                                                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                n = yP_TCD_DesignAccesObject.getCountSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                                if (n == 3) break block105;
                                                                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block106;
                                                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        l = yP_TCD_DesignAccesObject.getSumSuchAs("test15Long", yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                        if (l == 500L) break block107;
                                                                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block108;
                                                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                l = yP_TCD_DesignAccesObject.getSumSuchAs("test15Long", yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                                if (l == 20L) break block109;
                                                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1) == 1) break block110;
                                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                        l = yP_TCD_DesignAccesObject.getSumSuchAs("test15Long", yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                                                        if (l == 560L) break block111;
                                                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block112;
                                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                                if (yP_ComplexGabarit2.set("test15Long", YP_ComplexGabarit.OPERATOR.MIN) == 1) break block113;
                                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                            l = yP_TCD_DesignAccesObject.getSumSuchAs("test15Long", yP_ComplexGabarit, yP_ComplexGabarit2);
                                                                                                                                                                                                                                                                                                            if (l == 520L) break block114;
                                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block115;
                                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 1) == 1) break block116;
                                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block117;
                                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block118;
                                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                                        if (list != null && list.size() == 3) break block119;
                                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1()  ");
                                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block120;
                                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block121;
                                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block122;
                                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                                        if (list != null && list.size() == 3) break block123;
                                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block124;
                                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block125;
                                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block126;
                                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block127;
                                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                                    if (list != null && list.size() == 8) break block128;
                                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block129;
                                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block130;
                                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block131;
                                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block132;
                                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                                                if (list != null && list.size() == 8) break block133;
                                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block134;
                                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block135;
                                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block136;
                                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                                }
                                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block137;
                                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                                return -1;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                                            if (list != null && list.size() == 6) break block138;
                                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                            return -1;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                                                                        if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block139;
                                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                        return -1;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block140;
                                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                    return -1;
                                                                                                                                                                                                }
                                                                                                                                                                                                if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1) == 1) break block141;
                                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                                return -1;
                                                                                                                                                                                            }
                                                                                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block142;
                                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                            return -1;
                                                                                                                                                                                        }
                                                                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                                                        if (list != null && list.size() == 3) break block143;
                                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                        return -1;
                                                                                                                                                                                    }
                                                                                                                                                                                    if ((Long)list.get(0).getFieldValueByName("test15Long") == 10L) break block144;
                                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                    return -1;
                                                                                                                                                                                }
                                                                                                                                                                                if (list.get(0).getFieldStringValueByName("test15Array").contentEquals("user1")) break block145;
                                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                                return -1;
                                                                                                                                                                            }
                                                                                                                                                                            if ((Long)list.get(1).getFieldValueByName("test15Long") == 50L) break block146;
                                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                            return -1;
                                                                                                                                                                        }
                                                                                                                                                                        if (list.get(1).getFieldStringValueByName("test15Array").contentEquals("user2")) break block147;
                                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                        return -1;
                                                                                                                                                                    }
                                                                                                                                                                    if ((Long)list.get(2).getFieldValueByName("test15Long") == 500L) break block148;
                                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                    return -1;
                                                                                                                                                                }
                                                                                                                                                                if (list.get(2).getFieldStringValueByName("test15Array").contentEquals("user3")) break block149;
                                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                                return -1;
                                                                                                                                                            }
                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                            if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block150;
                                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                                            return -1;
                                                                                                                                                        }
                                                                                                                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block151;
                                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                                        return -1;
                                                                                                                                                    }
                                                                                                                                                    if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, 1) == 1) break block152;
                                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                                    return -1;
                                                                                                                                                }
                                                                                                                                                if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block153;
                                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                                return -1;
                                                                                                                                            }
                                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                            if (list != null && list.size() == 1) break block154;
                                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                                            return -1;
                                                                                                                                        }
                                                                                                                                        if ((Long)list.get(0).getFieldValueByName("test15Long") == 500L) break block155;
                                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                                        return -1;
                                                                                                                                    }
                                                                                                                                    if (list.get(0).getFieldStringValueByName("test15Array").contentEquals("user3")) break block156;
                                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                                    return -1;
                                                                                                                                }
                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block157;
                                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                                return -1;
                                                                                                                            }
                                                                                                                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block158;
                                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                                            return -1;
                                                                                                                        }
                                                                                                                        if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, 2) == 1) break block159;
                                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                                        return -1;
                                                                                                                    }
                                                                                                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block160;
                                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                                    return -1;
                                                                                                                }
                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                if (list != null && list.size() == 2) break block161;
                                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                                return -1;
                                                                                                            }
                                                                                                            if ((Long)list.get(0).getFieldValueByName("test15Long") == 100L) break block162;
                                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                                            return -1;
                                                                                                        }
                                                                                                        if ((Long)list.get(1).getFieldValueByName("test15Long") == 100L) break block163;
                                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                                        return -1;
                                                                                                    }
                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                    if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block164;
                                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                                    return -1;
                                                                                                }
                                                                                                if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block165;
                                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                                return -1;
                                                                                            }
                                                                                            if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1) == 1) break block166;
                                                                                            this.logger(2, "test15_blahblah1() ");
                                                                                            return -1;
                                                                                        }
                                                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block167;
                                                                                        this.logger(2, "test15_blahblah1() ");
                                                                                        return -1;
                                                                                    }
                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                    if (list != null && list.size() == 3) break block168;
                                                                                    this.logger(2, "test15_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                if ((Long)list.get(0).getFieldValueByName("test15Long") == 10L) break block169;
                                                                                this.logger(2, "test15_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            if ((Long)list.get(1).getFieldValueByName("test15Long") == 100L) break block170;
                                                                            this.logger(2, "test15_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        if ((Long)list.get(2).getFieldValueByName("test15Long") == 100L) break block171;
                                                                        this.logger(2, "test15_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                    if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block172;
                                                                    this.logger(2, "test15_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block173;
                                                                this.logger(2, "test15_blahblah1() ");
                                                                return -1;
                                                            }
                                                            if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, 2) == 1) break block174;
                                                            this.logger(2, "test15_blahblah1() ");
                                                            return -1;
                                                        }
                                                        if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block175;
                                                        this.logger(2, "test15_blahblah1() ");
                                                        return -1;
                                                    }
                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                    if (list != null && list.size() == 1) break block176;
                                                    this.logger(2, "test15_blahblah1() ");
                                                    return -1;
                                                }
                                                if ((Long)list.get(0).getFieldValueByName("test15Long") == 500L) break block177;
                                                this.logger(2, "test15_blahblah1() ");
                                                return -1;
                                            }
                                            if (list.get(0).getFieldStringValueByName("test15Array").contentEquals("user3")) break block178;
                                            this.logger(2, "test15_blahblah1() ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        if (yP_ComplexGabarit.set("test15Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block179;
                                        this.logger(2, "test15_blahblah1() ");
                                        return -1;
                                    }
                                    if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block180;
                                    this.logger(2, "test15_blahblah1() ");
                                    return -1;
                                }
                                if (yP_ComplexGabarit.set("test15Int", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, 1, 2) == 1) break block181;
                                this.logger(2, "test15_blahblah1() ");
                                return -1;
                            }
                            if (yP_ComplexGabarit.set("test15Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block182;
                            this.logger(2, "test15_blahblah1() ");
                            return -1;
                        }
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 3) break block183;
                        this.logger(2, "test15_blahblah1() ");
                        return -1;
                    }
                    if ((Long)list.get(0).getFieldValueByName("test15Long") == 100L) break block184;
                    this.logger(2, "test15_blahblah1() ");
                    return -1;
                }
                if ((Long)list.get(1).getFieldValueByName("test15Long") == 100L) break block185;
                this.logger(2, "test15_blahblah1() ");
                return -1;
            }
            if ((Long)list.get(2).getFieldValueByName("test15Long") == 500L) break block186;
            this.logger(2, "test15_blahblah1() ");
            return -1;
        }
        if (!list.get(2).getFieldStringValueByName("test15Array").contentEquals("user3")) {
            this.logger(2, "test15_blahblah1() ");
            return -1;
        }
        return 1;
    }

    private int test16_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block89: {
            List<YP_Row> list;
            block88: {
                block87: {
                    YP_ComplexGabarit yP_ComplexGabarit;
                    block86: {
                        block85: {
                            block84: {
                                block83: {
                                    block82: {
                                        block81: {
                                            block80: {
                                                block79: {
                                                    block78: {
                                                        block77: {
                                                            block76: {
                                                                block75: {
                                                                    block74: {
                                                                        block73: {
                                                                            block72: {
                                                                                block71: {
                                                                                    block70: {
                                                                                        block69: {
                                                                                            block68: {
                                                                                                block67: {
                                                                                                    block66: {
                                                                                                        block65: {
                                                                                                            block64: {
                                                                                                                block63: {
                                                                                                                    block62: {
                                                                                                                        block61: {
                                                                                                                            block60: {
                                                                                                                                block59: {
                                                                                                                                    block58: {
                                                                                                                                        block57: {
                                                                                                                                            block56: {
                                                                                                                                                block55: {
                                                                                                                                                    block54: {
                                                                                                                                                        block53: {
                                                                                                                                                            block52: {
                                                                                                                                                                block51: {
                                                                                                                                                                    block50: {
                                                                                                                                                                        YP_Row yP_Row;
                                                                                                                                                                        block49: {
                                                                                                                                                                            block48: {
                                                                                                                                                                                block47: {
                                                                                                                                                                                    try {
                                                                                                                                                                                        if (UtilsYP.getInstanceRole() == 1) break block47;
                                                                                                                                                                                        return 0;
                                                                                                                                                                                    }
                                                                                                                                                                                    catch (Exception exception) {
                                                                                                                                                                                        this.logger(2, "test16_blahblah1() " + exception);
                                                                                                                                                                                        return -1;
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block48;
                                                                                                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                                                                                                return -1;
                                                                                                                                                                            }
                                                                                                                                                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                                                                                                            if (yP_Row != null) break block49;
                                                                                                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                                                                                                            return -1;
                                                                                                                                                                        }
                                                                                                                                                                        yP_Row.set("test16Array", "number1");
                                                                                                                                                                        yP_Row.set("test16Long", 100);
                                                                                                                                                                        yP_Row.set("test16Int", 0);
                                                                                                                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                        yP_Row.set("test16Array", "number2");
                                                                                                                                                                        yP_Row.set("test16Long", 200);
                                                                                                                                                                        yP_Row.set("test16Int", 1);
                                                                                                                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                        yP_Row.set("test16Array", "number1");
                                                                                                                                                                        yP_Row.set("test16Long", 300);
                                                                                                                                                                        yP_Row.set("test16Int", 1);
                                                                                                                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                        yP_Row.set("test16Array", "number2");
                                                                                                                                                                        yP_Row.set("test16Long", 400);
                                                                                                                                                                        yP_Row.set("test16Int", 0);
                                                                                                                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                                                                                                                            yP_TCD_DesignAccesObject.persist();
                                                                                                                                                                        }
                                                                                                                                                                        if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test16Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block50;
                                                                                                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                                                                                                        return -1;
                                                                                                                                                                    }
                                                                                                                                                                    if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block51;
                                                                                                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                                                                                                    return -1;
                                                                                                                                                                }
                                                                                                                                                                if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0) == 1) break block52;
                                                                                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                                                                                return -1;
                                                                                                                                                            }
                                                                                                                                                            if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block53;
                                                                                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                                                                                            return -1;
                                                                                                                                                        }
                                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                        if (list != null && list.size() == 2) break block54;
                                                                                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                                                                                        return -1;
                                                                                                                                                    }
                                                                                                                                                    if ((Long)list.get(0).getFieldValueByName("test16Long") == 100L) break block55;
                                                                                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                                                                                    return -1;
                                                                                                                                                }
                                                                                                                                                if (list.get(0).getFieldStringValueByName("test16Array").contentEquals("number1")) break block56;
                                                                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                                                                return -1;
                                                                                                                                            }
                                                                                                                                            if ((Long)list.get(1).getFieldValueByName("test16Long") == 400L) break block57;
                                                                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                                                                            return -1;
                                                                                                                                        }
                                                                                                                                        if (list.get(1).getFieldStringValueByName("test16Array").contentEquals("number2")) break block58;
                                                                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                                                                        return -1;
                                                                                                                                    }
                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                    if (yP_ComplexGabarit.set("test16Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block59;
                                                                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                                                                    return -1;
                                                                                                                                }
                                                                                                                                if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block60;
                                                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                                                return -1;
                                                                                                                            }
                                                                                                                            if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, 0) == 1) break block61;
                                                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                                                            return -1;
                                                                                                                        }
                                                                                                                        if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block62;
                                                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                                                        return -1;
                                                                                                                    }
                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                    if (list != null && list.size() == 1) break block63;
                                                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                                                    return -1;
                                                                                                                }
                                                                                                                if ((Long)list.get(0).getFieldValueByName("test16Long") == 400L) break block64;
                                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                                return -1;
                                                                                                            }
                                                                                                            if (list.get(0).getFieldStringValueByName("test16Array").contentEquals("number2")) break block65;
                                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                                            return -1;
                                                                                                        }
                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                        if (yP_ComplexGabarit.set("test16Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block66;
                                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                                        return -1;
                                                                                                    }
                                                                                                    if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block67;
                                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                                    return -1;
                                                                                                }
                                                                                                if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0) == 1) break block68;
                                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                                return -1;
                                                                                            }
                                                                                            if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block69;
                                                                                            this.logger(2, "test16_blahblah1() ");
                                                                                            return -1;
                                                                                        }
                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                        if (list != null && list.size() == 2) break block70;
                                                                                        this.logger(2, "test16_blahblah1() ");
                                                                                        return -1;
                                                                                    }
                                                                                    if ((Long)list.get(0).getFieldValueByName("test16Long") == 200L) break block71;
                                                                                    this.logger(2, "test16_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                if (list.get(0).getFieldStringValueByName("test16Array").contentEquals("number2")) break block72;
                                                                                this.logger(2, "test16_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            if ((Long)list.get(1).getFieldValueByName("test16Long") == 300L) break block73;
                                                                            this.logger(2, "test16_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        if (list.get(1).getFieldStringValueByName("test16Array").contentEquals("number1")) break block74;
                                                                        this.logger(2, "test16_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                    if (yP_ComplexGabarit.set("test16Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block75;
                                                                    this.logger(2, "test16_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block76;
                                                                this.logger(2, "test16_blahblah1() ");
                                                                return -1;
                                                            }
                                                            if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP, 0) == 1) break block77;
                                                            this.logger(2, "test16_blahblah1() ");
                                                            return -1;
                                                        }
                                                        if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block78;
                                                        this.logger(2, "test16_blahblah1() ");
                                                        return -1;
                                                    }
                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                    if (list != null && list.size() == 1) break block79;
                                                    this.logger(2, "test16_blahblah1() ");
                                                    return -1;
                                                }
                                                if ((Long)list.get(0).getFieldValueByName("test16Long") == 300L) break block80;
                                                this.logger(2, "test16_blahblah1() ");
                                                return -1;
                                            }
                                            if (list.get(0).getFieldStringValueByName("test16Array").contentEquals("number1")) break block81;
                                            this.logger(2, "test16_blahblah1() ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        if (yP_ComplexGabarit.set("test16Array", YP_ComplexGabarit.OPERATOR.GROUP) == 1) break block82;
                                        this.logger(2, "test16_blahblah1() ");
                                        return -1;
                                    }
                                    if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.MAX) == 1) break block83;
                                    this.logger(2, "test16_blahblah1() ");
                                    return -1;
                                }
                                if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, 0, 15, 154) == 1) break block84;
                                this.logger(2, "test16_blahblah1() ");
                                return -1;
                            }
                            if (yP_ComplexGabarit.set("test16Int", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, 0, 15, 154) == 1) break block85;
                            this.logger(2, "test16_blahblah1() ");
                            return -1;
                        }
                        if (yP_ComplexGabarit.set("test16Long", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block86;
                        this.logger(2, "test16_blahblah1() ");
                        return -1;
                    }
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 1) break block87;
                    this.logger(2, "test16_blahblah1() ");
                    return -1;
                }
                if ((Long)list.get(0).getFieldValueByName("test16Long") == 400L) break block88;
                this.logger(2, "test16_blahblah1() ");
                return -1;
            }
            if (list.get(0).getFieldStringValueByName("test16Array").contentEquals("number2")) break block89;
            this.logger(2, "test16_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test16_blahblah1()");
            return -1;
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int test17_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            int n = 10;
            if (UtilsYP.getInstanceRole() != 1) {
                return 0;
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                this.logger(2, "test17_blahblah1() ");
                return -1;
            }
            this.logger(4, "test17_blahblah1() start");
            YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table = yP_TCD_DesignAccesObject.createTemporaryTable(false);
            YP_Row yP_Row = yP_TCD_DAO_LOC_Table.getNewRow();
            yP_Row.set("test17Array", "0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789");
            long l = 1L;
            while (l <= (long)n) {
                yP_Row.set("idTest17", l);
                yP_TCD_DAO_LOC_Table.addRow(yP_Row);
                ++l;
            }
            yP_TCD_DAO_LOC_Table.persist();
            this.logger(4, "test17_blahblah1() mid");
            int n2 = ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).getLogLevel();
            ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).setLogLevel(4);
            long l2 = 1L;
            while (l2 <= (long)n) {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                if (yP_ComplexGabarit.set("idTest17", YP_ComplexGabarit.OPERATOR.EQUAL, l2) != 1) {
                    this.logger(2, "test17_blahblah1() ");
                    return -1;
                }
                yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                ++l2;
            }
            ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).setLogLevel(n2);
            this.logger(4, "test17_blahblah1() end");
            if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
                this.logger(2, "test17_blahblah1()");
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "test17_blahblah1() " + exception);
            return -1;
        }
    }

    private int test18_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block41: {
            List<YP_Row> list;
            block40: {
                block39: {
                    YP_ComplexGabarit yP_ComplexGabarit;
                    block38: {
                        block37: {
                            block36: {
                                block35: {
                                    block34: {
                                        block33: {
                                            block32: {
                                                block31: {
                                                    block30: {
                                                        block29: {
                                                            block28: {
                                                                block27: {
                                                                    block26: {
                                                                        YP_Row yP_Row;
                                                                        block25: {
                                                                            block24: {
                                                                                block23: {
                                                                                    try {
                                                                                        if (UtilsYP.getInstanceRole() == 1) break block23;
                                                                                        return 0;
                                                                                    }
                                                                                    catch (Exception exception) {
                                                                                        this.logger(2, "test18_blahblah1() " + exception);
                                                                                        return -1;
                                                                                    }
                                                                                }
                                                                                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block24;
                                                                                this.logger(2, "test18_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                            if (yP_Row != null) break block25;
                                                                            this.logger(2, "test18_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        yP_Row.set("test18Array", "number1");
                                                                        yP_Row.set("test18Long", 100);
                                                                        yP_Row.set("test18Int", 0);
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test18Array", "number2");
                                                                        yP_Row.set("test18Long", 200);
                                                                        yP_Row.set("test18Int", 1);
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test18Array", "number1");
                                                                        yP_Row.set("test18Long", 300);
                                                                        yP_Row.set("test18Int", 1);
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row.set("test18Array", "number2");
                                                                        yP_Row.set("test18Long", 400);
                                                                        yP_Row.set("test18Int", 0);
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                            yP_TCD_DesignAccesObject.persist();
                                                                        }
                                                                        if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("test18Array", YP_ComplexGabarit.OPERATOR.IN, "number1", "number3") == 1) break block26;
                                                                        this.logger(2, "test18_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                    if (list != null && list.size() == 2) break block27;
                                                                    this.logger(2, "test18_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                if (list.get(0).getFieldStringValueByName("test18Array").contentEquals("number1")) break block28;
                                                                this.logger(2, "test18_blahblah1() ");
                                                                return -1;
                                                            }
                                                            if (list.get(1).getFieldStringValueByName("test18Array").contentEquals("number1")) break block29;
                                                            this.logger(2, "test18_blahblah1() ");
                                                            return -1;
                                                        }
                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                        if (yP_ComplexGabarit.set("test18Int", YP_ComplexGabarit.OPERATOR.IN, 0, 1, 2) == 1) break block30;
                                                        this.logger(2, "test18_blahblah1() ");
                                                        return -1;
                                                    }
                                                    if (yP_ComplexGabarit.set("test18Int", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block31;
                                                    this.logger(2, "test18_blahblah1() ");
                                                    return -1;
                                                }
                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                if (list != null && list.size() == 4) break block32;
                                                this.logger(2, "test18_blahblah1() ");
                                                return -1;
                                            }
                                            if ((Integer)list.get(0).getFieldValueByName("test18Int") == 0) break block33;
                                            this.logger(2, "test18_blahblah1() ");
                                            return -1;
                                        }
                                        if ((Integer)list.get(1).getFieldValueByName("test18Int") == 0) break block34;
                                        this.logger(2, "test18_blahblah1() ");
                                        return -1;
                                    }
                                    if ((Integer)list.get(2).getFieldValueByName("test18Int") == 1) break block35;
                                    this.logger(2, "test18_blahblah1() ");
                                    return -1;
                                }
                                if ((Integer)list.get(3).getFieldValueByName("test18Int") == 1) break block36;
                                this.logger(2, "test18_blahblah1() ");
                                return -1;
                            }
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            if (yP_ComplexGabarit.set("test18Long", YP_ComplexGabarit.OPERATOR.IN, 100L, 200L) == 1) break block37;
                            this.logger(2, "test18_blahblah1() ");
                            return -1;
                        }
                        if (yP_ComplexGabarit.set("test18Long", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block38;
                        this.logger(2, "test18_blahblah1() ");
                        return -1;
                    }
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 2) break block39;
                    this.logger(2, "test18_blahblah1() ");
                    return -1;
                }
                if ((Long)list.get(0).getFieldValueByName("test18Long") == 200L) break block40;
                this.logger(2, "test18_blahblah1() ");
                return -1;
            }
            if ((Long)list.get(1).getFieldValueByName("test18Long") == 100L) break block41;
            this.logger(2, "test18_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test18_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test19_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_Row yP_Row;
        long l;
        block9: {
            block8: {
                block7: {
                    l = 0L;
                    if (UtilsYP.getInstanceRole() == 1) break block7;
                    return 0;
                }
                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block8;
                this.logger(2, "test19_blahblah1() ");
                return -1;
            }
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            if (yP_Row != null) break block9;
            this.logger(2, "test19_blahblah1() ");
            return -1;
        }
        try {
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            long l2 = System.currentTimeMillis();
            long l3 = l2 + l;
            int n = ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).getLogLevel();
            ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).setLogLevel(4);
            int n2 = 0;
            this.logger(4, "test19_blahblah1() start");
            do {
                ++n2;
                yP_TCD_DesignAccesObject.getRowList();
            } while (System.currentTimeMillis() < l3);
            ((YP_Object)((Object)yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater)).setLogLevel(n);
            this.logger(4, "test19_blahblah1() end " + n2);
            if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
                this.logger(2, "test19_blahblah1()");
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "test19_blahblah1() " + exception);
            return -1;
        }
    }

    private int test20_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block47: {
            List<YP_Row> list;
            block46: {
                block45: {
                    block44: {
                        block43: {
                            YP_ComplexGabarit yP_ComplexGabarit;
                            block42: {
                                block41: {
                                    block40: {
                                        block39: {
                                            block38: {
                                                block37: {
                                                    block36: {
                                                        block35: {
                                                            block34: {
                                                                block33: {
                                                                    block32: {
                                                                        block31: {
                                                                            block30: {
                                                                                block29: {
                                                                                    YP_Row yP_Row;
                                                                                    block28: {
                                                                                        block27: {
                                                                                            block26: {
                                                                                                try {
                                                                                                    if (UtilsYP.getInstanceRole() == 1) break block26;
                                                                                                    return 0;
                                                                                                }
                                                                                                catch (Exception exception) {
                                                                                                    this.logger(2, "test20_blahblah1() " + exception);
                                                                                                    return -1;
                                                                                                }
                                                                                            }
                                                                                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block27;
                                                                                            this.logger(2, "test20_blahblah1() ");
                                                                                            return -1;
                                                                                        }
                                                                                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                        if (yP_Row != null) break block28;
                                                                                        this.logger(2, "test20_blahblah1() ");
                                                                                        return -1;
                                                                                    }
                                                                                    yP_Row.set("order1", 2);
                                                                                    yP_Row.set("order2", 4);
                                                                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                    yP_Row.set("order1", 1);
                                                                                    yP_Row.set("order2", 2);
                                                                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                    yP_Row.set("order1", 3);
                                                                                    yP_Row.set("order2", 3);
                                                                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                    yP_Row.set("order1", 2);
                                                                                    yP_Row.set("order2", 1);
                                                                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                    if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                                        yP_TCD_DesignAccesObject.persist();
                                                                                    }
                                                                                    if ((yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject)).set("order1", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block29;
                                                                                    this.logger(2, "test20_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                if (list != null && list.size() == 4) break block30;
                                                                                this.logger(2, "test20_blahblah1() ");
                                                                                return -1;
                                                                            }
                                                                            if (list.get(0).getFieldStringValueByName("order1").contentEquals("1")) break block31;
                                                                            this.logger(2, "test20_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        if (list.get(1).getFieldStringValueByName("order1").contentEquals("2")) break block32;
                                                                        this.logger(2, "test20_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    if (list.get(2).getFieldStringValueByName("order1").contentEquals("2")) break block33;
                                                                    this.logger(2, "test20_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                if (list.get(3).getFieldStringValueByName("order1").contentEquals("3")) break block34;
                                                                this.logger(2, "test20_blahblah1() ");
                                                                return -1;
                                                            }
                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                            if (yP_ComplexGabarit.set("order2", YP_ComplexGabarit.OPERATOR.ORDER_DESC) == 1) break block35;
                                                            this.logger(2, "test20_blahblah1() ");
                                                            return -1;
                                                        }
                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                        if (list != null && list.size() == 4) break block36;
                                                        this.logger(2, "test20_blahblah1() ");
                                                        return -1;
                                                    }
                                                    if (list.get(0).getFieldStringValueByName("order2").contentEquals("4")) break block37;
                                                    this.logger(2, "test20_blahblah1() ");
                                                    return -1;
                                                }
                                                if (list.get(1).getFieldStringValueByName("order2").contentEquals("3")) break block38;
                                                this.logger(2, "test20_blahblah1() ");
                                                return -1;
                                            }
                                            if (list.get(2).getFieldStringValueByName("order2").contentEquals("2")) break block39;
                                            this.logger(2, "test20_blahblah1() ");
                                            return -1;
                                        }
                                        if (list.get(3).getFieldStringValueByName("order2").contentEquals("1")) break block40;
                                        this.logger(2, "test20_blahblah1() ");
                                        return -1;
                                    }
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    if (yP_ComplexGabarit.set("order1", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block41;
                                    this.logger(2, "test20_blahblah1() ");
                                    return -1;
                                }
                                if (yP_ComplexGabarit.set("order2", YP_ComplexGabarit.OPERATOR.ORDER_ASC) == 1) break block42;
                                this.logger(2, "test20_blahblah1() ");
                                return -1;
                            }
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 4) break block43;
                            this.logger(2, "test20_blahblah1() ");
                            return -1;
                        }
                        if (list.get(0).getFieldStringValueByName("order2").contentEquals("2")) break block44;
                        this.logger(2, "test20_blahblah1()  ");
                        return -1;
                    }
                    if (list.get(1).getFieldStringValueByName("order2").contentEquals("1")) break block45;
                    this.logger(2, "test20_blahblah1() ");
                    return -1;
                }
                if (list.get(2).getFieldStringValueByName("order2").contentEquals("4")) break block46;
                this.logger(2, "test20_blahblah1() ");
                return -1;
            }
            if (list.get(3).getFieldStringValueByName("order2").contentEquals("3")) break block47;
            this.logger(2, "test20_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test20_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test21_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block21: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block20: {
                block19: {
                    block18: {
                        block17: {
                            block16: {
                                block15: {
                                    block14: {
                                        block13: {
                                            try {
                                                if (UtilsYP.getInstanceRole() == 1) break block13;
                                                return 0;
                                            }
                                            catch (Exception exception) {
                                                this.logger(2, "test21_blahblah1() " + exception);
                                                return -1;
                                            }
                                        }
                                        if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block14;
                                        this.logger(2, "test21_blahblah1() ");
                                        return -1;
                                    }
                                    YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "");
                                    yP_Row.set("array2", "");
                                    yP_Row.set("array3", "");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "");
                                    yP_Row.set("array2", "");
                                    yP_Row.set("array3", "");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "  ");
                                    yP_Row.set("array2", "  ");
                                    yP_Row.set("array3", "  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "  ");
                                    yP_Row.set("array2", "  ");
                                    yP_Row.set("array3", "  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "X  ");
                                    yP_Row.set("array2", "X  ");
                                    yP_Row.set("array3", "X  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array1", "X  ");
                                    yP_Row.set("array2", "X  ");
                                    yP_Row.set("array3", "X  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array2", "");
                                    yP_Row.set("array3", "  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row);
                                    yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                    yP_Row.set("array2", "");
                                    yP_Row.set("array3", "  ");
                                    yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                    if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                        yP_TCD_DesignAccesObject.persist();
                                    }
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.EQUAL, "");
                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                    if (list != null && list.size() == 6) break block15;
                                    this.logger(2, "test21_blahblah1() ");
                                    return -1;
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.EQUAL, " ");
                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                if (list != null && list.size() == 6) break block16;
                                this.logger(2, "test21_blahblah1() ");
                                return -1;
                            }
                            list = yP_TCD_DesignAccesObject.getRowList();
                            if (list != null && list.size() == 8) break block17;
                            this.logger(2, "test21_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.DIFFERENT, "");
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 2) break block18;
                        this.logger(2, "test21_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.DIFFERENT, " ");
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 2) break block19;
                    this.logger(2, "test21_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.EQUAL, "X");
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 2) break block20;
                this.logger(2, "test21_blahblah1() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("array1", YP_ComplexGabarit.OPERATOR.EQUAL, "X  ");
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 2) break block21;
            this.logger(2, "test21_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test21_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test22_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block39: {
            List<YP_Row> list;
            block38: {
                YP_ComplexGabarit yP_ComplexGabarit;
                block37: {
                    block36: {
                        block35: {
                            block34: {
                                block33: {
                                    block32: {
                                        block31: {
                                            block30: {
                                                block29: {
                                                    block28: {
                                                        block27: {
                                                            block26: {
                                                                block25: {
                                                                    block24: {
                                                                        block23: {
                                                                            block22: {
                                                                                try {
                                                                                    if (UtilsYP.getInstanceRole() == 1) break block22;
                                                                                    return 0;
                                                                                }
                                                                                catch (Exception exception) {
                                                                                    this.logger(2, "test22_blahblah1() " + exception);
                                                                                    return -1;
                                                                                }
                                                                            }
                                                                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block23;
                                                                            this.logger(2, "test22_blahblah1() ");
                                                                            return -1;
                                                                        }
                                                                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                        yP_Row.set("int1", 4);
                                                                        yP_Row.set("int2", 0);
                                                                        Calendar calendar = UtilsYP.getSystemGMTTime();
                                                                        calendar.set(1, 2004);
                                                                        yP_Row.set("timestamp1", new Timestamp(calendar.getTimeInMillis()));
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                        yP_Row.set("int1", 10);
                                                                        yP_Row.set("int2", 0);
                                                                        calendar = UtilsYP.getSystemGMTTime();
                                                                        calendar.set(1, 2010);
                                                                        yP_Row.set("timestamp1", new Timestamp(calendar.getTimeInMillis()));
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                                                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                        yP_Row.set("int1", 0);
                                                                        yP_Row.set("int2", 1);
                                                                        calendar = UtilsYP.getSystemGMTTime();
                                                                        calendar.set(1, 2000);
                                                                        yP_Row.set("timestamp1", new Timestamp(calendar.getTimeInMillis()));
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                        yP_Row.set("int1", 2);
                                                                        yP_Row.set("int2", 1);
                                                                        calendar = UtilsYP.getSystemGMTTime();
                                                                        calendar.set(1, 2002);
                                                                        yP_Row.set("timestamp1", new Timestamp(calendar.getTimeInMillis()));
                                                                        yP_TCD_DesignAccesObject.addRow(yP_Row, true);
                                                                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                            yP_TCD_DesignAccesObject.persist();
                                                                        }
                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                        yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                                                        yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                        if (list != null && list.size() == 2) break block24;
                                                                        this.logger(2, "test22_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    if ((Integer)list.get(0).getFieldValueByName("int1") == 2) break block25;
                                                                    this.logger(2, "test22_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                                                yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                if (list != null && list.size() == 2) break block26;
                                                                this.logger(2, "test22_blahblah1() ");
                                                                return -1;
                                                            }
                                                            if ((Integer)list.get(0).getFieldValueByName("int1") == 0) break block27;
                                                            this.logger(2, "test22_blahblah1() ");
                                                            return -1;
                                                        }
                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                        yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                                                        yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                        if (list != null && list.size() == 2) break block28;
                                                        this.logger(2, "test22_blahblah1() ");
                                                        return -1;
                                                    }
                                                    if ((Integer)list.get(0).getFieldValueByName("int1") == 10) break block29;
                                                    this.logger(2, "test22_blahblah1() ");
                                                    return -1;
                                                }
                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                                                yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                if (list != null && list.size() == 2) break block30;
                                                this.logger(2, "test22_blahblah1() ");
                                                return -1;
                                            }
                                            if ((Integer)list.get(0).getFieldValueByName("int1") == 4) break block31;
                                            this.logger(2, "test22_blahblah1() ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                        yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                                        if (list != null && list.size() == 1) break block32;
                                        this.logger(2, "test22_blahblah1() ");
                                        return -1;
                                    }
                                    if ((Integer)list.get(0).getFieldValueByName("int1") == 2) break block33;
                                    this.logger(2, "test22_blahblah1() ");
                                    return -1;
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                                if (list != null && list.size() == 1) break block34;
                                this.logger(2, "test22_blahblah1() ");
                                return -1;
                            }
                            if ((Integer)list.get(0).getFieldValueByName("int1") == 0) break block35;
                            this.logger(2, "test22_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                        yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                        if (list != null && list.size() == 1) break block36;
                        this.logger(2, "test22_blahblah1() ");
                        return -1;
                    }
                    if ((Integer)list.get(0).getFieldValueByName("int1") == 10) break block37;
                    this.logger(2, "test22_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("int2", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                yP_ComplexGabarit.set("timestamp1", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block38;
                this.logger(2, "test22_blahblah1() ");
                return -1;
            }
            if ((Integer)list.get(0).getFieldValueByName("int1") == 4) break block39;
            this.logger(2, "test22_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test22_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test23_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block19: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block18: {
                block17: {
                    block16: {
                        block15: {
                            block14: {
                                block13: {
                                    block12: {
                                        try {
                                            if (UtilsYP.getInstanceRole() == 1) break block12;
                                            return 0;
                                        }
                                        catch (Exception exception) {
                                            this.logger(2, "test23_blahblah1() " + exception);
                                            return -1;
                                        }
                                    }
                                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block13;
                                    this.logger(2, "test23_blahblah1() ");
                                    return -1;
                                }
                                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test23Int", 1);
                                yP_Row.set("test23Boolean", true);
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test23Int", 2);
                                yP_Row.set("test23Boolean", false);
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test23Int", 3);
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test23Int", 4);
                                yP_Row.set("test23Boolean", true);
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                    yP_TCD_DesignAccesObject.persist();
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                yP_ComplexGabarit.set("test23Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                if (list != null && list.size() == 1) break block14;
                                this.logger(2, "test23_blahblah1() ");
                                return -1;
                            }
                            if (((Boolean)list.get(0).getFieldValueByName("test23Boolean")).booleanValue()) break block15;
                            this.logger(2, "test23_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("test23Int", YP_ComplexGabarit.OPERATOR.EQUAL, 3);
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 1) break block16;
                        this.logger(2, "test23_blahblah1() ");
                        return -1;
                    }
                    if (list.get(0).getFieldValueByName("test23Boolean") == null) break block17;
                    this.logger(2, "test23_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test23Boolean", YP_ComplexGabarit.OPERATOR.EQUAL, true);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 2) break block18;
                this.logger(2, "test23_blahblah1() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test23Boolean", YP_ComplexGabarit.OPERATOR.IN, true);
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 2) break block19;
            this.logger(2, "test23_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test23_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test24_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block25: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block24: {
                block23: {
                    block22: {
                        block21: {
                            block20: {
                                block19: {
                                    block18: {
                                        block17: {
                                            block16: {
                                                block15: {
                                                    try {
                                                        if (UtilsYP.getInstanceRole() == 1) break block15;
                                                        return 0;
                                                    }
                                                    catch (Exception exception) {
                                                        this.logger(2, "test24_blahblah1() " + exception);
                                                        return -1;
                                                    }
                                                }
                                                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block16;
                                                this.logger(2, "test24_blahblah1() ");
                                                return -1;
                                            }
                                            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 1);
                                            yP_Row.set("test24Bitmap", new Bitmap(1L));
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 2);
                                            yP_Row.set("test24Bitmap", new Bitmap(3L));
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 3);
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 4);
                                            yP_Row.set("test24Bitmap", new Bitmap(64L));
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 5);
                                            yP_Row.set("test24Bitmap", 9);
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 6);
                                            yP_Row.set("test24Bitmap", "4");
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                            yP_Row.set("test24Int", 7);
                                            yP_Row.set("test24Bitmap", new Bitmap().set(63));
                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                yP_TCD_DesignAccesObject.persist();
                                            }
                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                            yP_ComplexGabarit.set("test24Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                            if (list != null && list.size() == 1) break block17;
                                            this.logger(2, "test24_blahblah1() ");
                                            return -1;
                                        }
                                        if (((Bitmap)list.get(0).getFieldValueByName("test24Bitmap")).getBitmap() == 1L) break block18;
                                        this.logger(2, "test24_blahblah1() ");
                                        return -1;
                                    }
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    yP_ComplexGabarit.set("test24Int", YP_ComplexGabarit.OPERATOR.EQUAL, 3);
                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                    if (list != null && list.size() == 1) break block19;
                                    this.logger(2, "test24_blahblah1() ");
                                    return -1;
                                }
                                if (list.get(0).getFieldValueByName("test24Bitmap") == null) break block20;
                                this.logger(2, "test24_blahblah1() ");
                                return -1;
                            }
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            yP_ComplexGabarit.set("test24Bitmap", YP_ComplexGabarit.OPERATOR.CONTAIN, 1);
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 3) break block21;
                            this.logger(2, "test24_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("test24Bitmap", YP_ComplexGabarit.OPERATOR.EQUAL, new Bitmap(64L));
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 1) break block22;
                        this.logger(2, "test24_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("test24Bitmap", YP_ComplexGabarit.OPERATOR.IN, new Bitmap(64L));
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 1) break block23;
                    this.logger(2, "test24_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test24Bitmap", YP_ComplexGabarit.OPERATOR.DIFFERENT, 1);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 6) break block24;
                this.logger(2, "test24_blahblah1() ");
                return -1;
            }
            if (!(yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC)) break block25;
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test24Bitmap", YP_ComplexGabarit.OPERATOR.DIFFERENT, (Bitmap)null);
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 6) break block25;
            this.logger(2, "test24_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test24_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test25_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block19: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block18: {
                block17: {
                    block16: {
                        block15: {
                            block14: {
                                block13: {
                                    block12: {
                                        try {
                                            if (UtilsYP.getInstanceRole() == 1) break block12;
                                            return 0;
                                        }
                                        catch (Exception exception) {
                                            this.logger(2, "test25_blahblah1() " + exception);
                                            return -1;
                                        }
                                    }
                                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block13;
                                    this.logger(2, "test25_blahblah1() ");
                                    return -1;
                                }
                                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test25Array", "aaaa");
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test25Array", "zzzz");
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test25Array", "AAAA");
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test25Array", "ZZZZ");
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                yP_Row.set("test25Array", "aBcD");
                                yP_TCD_DesignAccesObject.addRow(yP_Row);
                                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                    yP_TCD_DesignAccesObject.persist();
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "aaaa");
                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                if (list != null && list.size() == 2) break block14;
                                this.logger(2, "test25_blahblah1() ");
                                return -1;
                            }
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "AAAA");
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 2) break block15;
                            this.logger(2, "test25_blahblah1() ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "zzzz");
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 2) break block16;
                        this.logger(2, "test25_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "ZZZZ");
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 2) break block17;
                    this.logger(2, "test25_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "abcd");
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block18;
                this.logger(2, "test25_blahblah1() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "ABCD");
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 1) break block19;
            this.logger(2, "test25_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test25_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test25_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block9: {
            block8: {
                block7: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block7;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test25_blahblah2() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block8;
                this.logger(2, "test25_blahblah2() ");
                return -1;
            }
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test25Array", "aaaa");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test25Array", "zzzz");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test25Array", "AAAA");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test25Array", "ZZZZ");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test25Array", "aBcD");
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                yP_TCD_DesignAccesObject.persist();
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test25Array", YP_ComplexGabarit.OPERATOR.LIKE, "_a%");
            List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 2) break block9;
            this.logger(2, "test25_blahblah2() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test25_blahblah2()");
            return -1;
        }
        return 1;
    }

    private int test26_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block81: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block80: {
                block79: {
                    block78: {
                        block77: {
                            block76: {
                                block75: {
                                    block74: {
                                        block73: {
                                            block72: {
                                                block71: {
                                                    block70: {
                                                        block69: {
                                                            block68: {
                                                                block67: {
                                                                    block66: {
                                                                        block65: {
                                                                            block64: {
                                                                                block63: {
                                                                                    block62: {
                                                                                        block61: {
                                                                                            block60: {
                                                                                                block59: {
                                                                                                    block58: {
                                                                                                        block57: {
                                                                                                            block56: {
                                                                                                                block55: {
                                                                                                                    block54: {
                                                                                                                        block53: {
                                                                                                                            block52: {
                                                                                                                                block51: {
                                                                                                                                    block50: {
                                                                                                                                        block49: {
                                                                                                                                            block48: {
                                                                                                                                                block47: {
                                                                                                                                                    block46: {
                                                                                                                                                        block45: {
                                                                                                                                                            block44: {
                                                                                                                                                                block43: {
                                                                                                                                                                    try {
                                                                                                                                                                        if (UtilsYP.getInstanceRole() == 1) break block43;
                                                                                                                                                                        return 0;
                                                                                                                                                                    }
                                                                                                                                                                    catch (Exception exception) {
                                                                                                                                                                        this.logger(2, "test26_blahblah1() " + exception);
                                                                                                                                                                        return -1;
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block44;
                                                                                                                                                                this.logger(2, "test26_blahblah1() ");
                                                                                                                                                                return -1;
                                                                                                                                                            }
                                                                                                                                                            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                                                                                            yP_Row.set("test26Array", "5");
                                                                                                                                                            yP_Row.set("test26Int", 5);
                                                                                                                                                            yP_Row.set("test26Long", 5);
                                                                                                                                                            yP_Row.set("test26Float", 5);
                                                                                                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                                                                                                                                                            yP_Row.set("test26Array", "456");
                                                                                                                                                            yP_Row.set("test26Int", 456);
                                                                                                                                                            yP_Row.set("test26Long", 456);
                                                                                                                                                            yP_Row.set("test26Float", 456);
                                                                                                                                                            yP_TCD_DesignAccesObject.addRow(yP_Row);
                                                                                                                                                            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                                                                                                                                                                yP_TCD_DesignAccesObject.persist();
                                                                                                                                                            }
                                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                            yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "456");
                                                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                            if (list != null && list.size() == 1) break block45;
                                                                                                                                                            this.logger(2, "test26_blahblah1() ");
                                                                                                                                                            return -1;
                                                                                                                                                        }
                                                                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                        yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.CONTAIN, "456");
                                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                        if (list != null && list.size() == 1) break block46;
                                                                                                                                                        this.logger(2, "test26_blahblah1() ");
                                                                                                                                                        return -1;
                                                                                                                                                    }
                                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                    yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.CONTAIN, 456);
                                                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                    if (list != null && list.size() == 1) break block47;
                                                                                                                                                    this.logger(2, "test26_blahblah1()  ");
                                                                                                                                                    return -1;
                                                                                                                                                }
                                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                                yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.CONTAIN, 456L);
                                                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                                if (list != null && list.size() == 1) break block48;
                                                                                                                                                this.logger(2, "test26_blahblah1() ");
                                                                                                                                                return -1;
                                                                                                                                            }
                                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                            yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.CONTAIN, "5");
                                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                            if (list != null && list.size() == 2) break block49;
                                                                                                                                            this.logger(2, "test26_blahblah1() ");
                                                                                                                                            return -1;
                                                                                                                                        }
                                                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                        yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.CONTAIN, 5);
                                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                        if (list != null && list.size() == 2) break block50;
                                                                                                                                        this.logger(2, "test26_blahblah1()  ");
                                                                                                                                        return -1;
                                                                                                                                    }
                                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                    yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.CONTAIN, 5L);
                                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                    if (list != null && list.size() == 2) break block51;
                                                                                                                                    this.logger(2, "test26_blahblah1() ");
                                                                                                                                    return -1;
                                                                                                                                }
                                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "4");
                                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                                if (list != null && list.size() == 0) break block52;
                                                                                                                                this.logger(2, "test26_blahblah1()  ");
                                                                                                                                return -1;
                                                                                                                            }
                                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                            yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, 4);
                                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                            if (list != null && list.size() == 0) break block53;
                                                                                                                            this.logger(2, "test26_blahblah1()  ");
                                                                                                                            return -1;
                                                                                                                        }
                                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                        yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, 4L);
                                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                        if (list != null && list.size() == 0) break block54;
                                                                                                                        this.logger(2, "test26_blahblah1() ");
                                                                                                                        return -1;
                                                                                                                    }
                                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                    yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, "4567");
                                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                    if (list != null && list.size() == 1) break block55;
                                                                                                                    this.logger(2, "test26_blahblah1()  ");
                                                                                                                    return -1;
                                                                                                                }
                                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                                yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, 4567);
                                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                                if (list != null && list.size() == 1) break block56;
                                                                                                                this.logger(2, "test26_blahblah1()  ");
                                                                                                                return -1;
                                                                                                            }
                                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                            yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, 4567L);
                                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                            if (list != null && list.size() == 1) break block57;
                                                                                                            this.logger(2, "test26_blahblah1() ");
                                                                                                            return -1;
                                                                                                        }
                                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                        yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.START_WITH, "4");
                                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                        if (list != null && list.size() == 1) break block58;
                                                                                                        this.logger(2, "test26_blahblah1()  ");
                                                                                                        return -1;
                                                                                                    }
                                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                    yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.START_WITH, 4);
                                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                    if (list != null && list.size() == 1) break block59;
                                                                                                    this.logger(2, "test26_blahblah1()  ");
                                                                                                    return -1;
                                                                                                }
                                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                                yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.START_WITH, 4L);
                                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                                if (list != null && list.size() == 1) break block60;
                                                                                                this.logger(2, "test26_blahblah1() ");
                                                                                                return -1;
                                                                                            }
                                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                            yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.START_WITH, "4567");
                                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                            if (list != null && list.size() == 0) break block61;
                                                                                            this.logger(2, "test26_blahblah1()  ");
                                                                                            return -1;
                                                                                        }
                                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                        yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.START_WITH, 4567);
                                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                        if (list != null && list.size() == 0) break block62;
                                                                                        this.logger(2, "test26_blahblah1()  ");
                                                                                        return -1;
                                                                                    }
                                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                    yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.START_WITH, 4567L);
                                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                    if (list != null && list.size() == 0) break block63;
                                                                                    this.logger(2, "test26_blahblah1() ");
                                                                                    return -1;
                                                                                }
                                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.GREATER, "456");
                                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                                if (list != null && list.size() == 1) break block64;
                                                                                this.logger(2, "test26_blahblah1()  ");
                                                                                return -1;
                                                                            }
                                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                            yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.GREATER, 456);
                                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                            if (list != null && list.size() == 0) break block65;
                                                                            this.logger(2, "test26_blahblah1()  ");
                                                                            return -1;
                                                                        }
                                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                        yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.GREATER, 456L);
                                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                        if (list != null && list.size() == 0) break block66;
                                                                        this.logger(2, "test26_blahblah1() ");
                                                                        return -1;
                                                                    }
                                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                    yP_ComplexGabarit.set("test26Float", YP_ComplexGabarit.OPERATOR.GREATER, 456.0f);
                                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                    if (list != null && list.size() == 0) break block67;
                                                                    this.logger(2, "test26_blahblah1() ");
                                                                    return -1;
                                                                }
                                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, "456");
                                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                                if (list != null && list.size() == 2) break block68;
                                                                this.logger(2, "test26_blahblah1()  ");
                                                                return -1;
                                                            }
                                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                            yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 456);
                                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                            if (list != null && list.size() == 1) break block69;
                                                            this.logger(2, "test26_blahblah1()  ");
                                                            return -1;
                                                        }
                                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                        yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 456L);
                                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                        if (list != null && list.size() == 1) break block70;
                                                        this.logger(2, "test26_blahblah1() ");
                                                        return -1;
                                                    }
                                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                    yP_ComplexGabarit.set("test26Float", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 456.0f);
                                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                    if (list != null && list.size() == 1) break block71;
                                                    this.logger(2, "test26_blahblah1() ");
                                                    return -1;
                                                }
                                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.LESS, "456");
                                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                                if (list != null && list.size() == 0) break block72;
                                                this.logger(2, "test26_blahblah1() ");
                                                return -1;
                                            }
                                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                            yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.LESS, 456);
                                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                            if (list != null && list.size() == 1) break block73;
                                            this.logger(2, "test26_blahblah1()  ");
                                            return -1;
                                        }
                                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                        yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.LESS, 456L);
                                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                        if (list != null && list.size() == 1) break block74;
                                        this.logger(2, "test26_blahblah1() ");
                                        return -1;
                                    }
                                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                    yP_ComplexGabarit.set("test26Float", YP_ComplexGabarit.OPERATOR.LESS, 456.0f);
                                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                    if (list != null && list.size() == 1) break block75;
                                    this.logger(2, "test26_blahblah1() ");
                                    return -1;
                                }
                                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, "456");
                                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                                if (list != null && list.size() == 1) break block76;
                                this.logger(2, "test26_blahblah1()  ");
                                return -1;
                            }
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            yP_ComplexGabarit.set("test26Int", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 456);
                            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                            if (list != null && list.size() == 2) break block77;
                            this.logger(2, "test26_blahblah1()  ");
                            return -1;
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("test26Long", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 456L);
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 2) break block78;
                        this.logger(2, "test26_blahblah1() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("test26Float", YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL, 456.0f);
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 2) break block79;
                    this.logger(2, "test26_blahblah1() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, "456");
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block80;
                this.logger(2, "test26_blahblah1() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test26Array", YP_ComplexGabarit.OPERATOR.EQUAL, "456");
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 1) break block81;
            this.logger(2, "test26_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test26_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah1(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block7: {
            block6: {
                try {
                    if (UtilsYP.getInstanceRole() == 1) break block6;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "test27_blahblah1() " + exception);
                    return -1;
                }
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block7;
            this.logger(2, "test27_blahblah1() ");
            return -1;
        }
        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
        yP_TCD_DesignAccesObject.addRow(yP_Row);
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
            yP_TCD_DesignAccesObject.persist();
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah1()");
            return -1;
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int test27_blahblah2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            List<YP_Row> list;
            if (UtilsYP.getInstanceRole() != 1) {
                return 0;
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                this.logger(2, "test27_blahblah2() ");
                return -1;
            }
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                yP_TCD_DesignAccesObject.persist();
            }
            if ((list = yP_TCD_DesignAccesObject.getRowList()) == null || list.size() != 2) {
                this.logger(2, "test27_blahblah2()");
                return -1;
            }
            for (YP_Row yP_Row2 : list) {
                yP_Row2.set("test27Int", 1);
                yP_Row2.setIsItAClonedRow(false);
            }
            YP_Row.persistList(list);
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC_Memory) {
                yP_TCD_DesignAccesObject.reload();
            }
            if ((list = yP_TCD_DesignAccesObject.getRowList()) == null || list.size() != 2) {
                this.logger(2, "test27_blahblah2()");
                return -1;
            }
            for (YP_Row yP_Row2 : list) {
                int n = (Integer)yP_Row2.getFieldValueByName("test27Int");
                if (n == 1) continue;
                this.logger(2, "test27_blahblah2()");
                return -1;
            }
            list.clear();
            list.add(yP_TCD_DesignAccesObject.getNewRow());
            list.add(yP_TCD_DesignAccesObject.getNewRow());
            for (YP_Row yP_Row2 : list) {
                yP_Row2.setIsItAClonedRow(false);
            }
            YP_Row.persistList(list);
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                yP_TCD_DesignAccesObject.reload();
            }
            if ((list = yP_TCD_DesignAccesObject.getRowList()) == null || list.size() != 4) {
                this.logger(2, "test27_blahblah2()");
                return -1;
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
                this.logger(2, "test27_blahblah2()");
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "test27_blahblah2() " + exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int test27_blahblah3(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block20: {
                YP_Row yP_Row;
                int n;
                if (UtilsYP.getInstanceRole() != 1) {
                    return 0;
                }
                if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                    this.logger(2, "test27_blahblah3() ");
                    return -1;
                }
                YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                yP_TCD_DesignAccesObject.addRow(yP_Row2);
                yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                yP_TCD_DesignAccesObject.addRow(yP_Row2);
                yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                yP_TCD_DesignAccesObject.addRow(yP_Row2);
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                    yP_TCD_DesignAccesObject.persist();
                }
                YP_Row yP_Row3 = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row3.set("test27Int", 1);
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test27Int", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                if (yP_TCD_DesignAccesObject.updateRowSuchAs(yP_Row3, yP_ComplexGabarit) != 3) {
                    this.logger(2, "test27_blahblah3()");
                    return -1;
                }
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC_Table) {
                    yP_TCD_DesignAccesObject.persist();
                }
                if ((list = yP_TCD_DesignAccesObject.getRowList()) == null || list.size() != 3) {
                    this.logger(2, "test27_blahblah3()");
                    return -1;
                }
                Iterator<YP_Row> iterator = list.iterator();
                do {
                    if (iterator.hasNext()) continue;
                    yP_Row3 = yP_TCD_DesignAccesObject.getNewRow();
                    yP_Row3.set("test27Int", 2);
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("test27Int", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                    yP_ComplexGabarit.set(yP_TCD_DesignAccesObject.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                    if (yP_TCD_DesignAccesObject.updateRowSuchAs(yP_Row3, 2, yP_ComplexGabarit) != 2) {
                        this.logger(2, "test27_blahblah3()");
                        return -1;
                    }
                    break block20;
                } while ((n = ((Integer)(yP_Row = iterator.next()).getFieldValueByName("test27Int")).intValue()) == 1);
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC_Table) {
                yP_TCD_DesignAccesObject.persist();
            }
            if ((list = yP_TCD_DesignAccesObject.getRowList()) == null || list.size() != 3) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            int n = 0;
            Iterator<YP_Row> iterator = list.iterator();
            while (true) {
                if (!iterator.hasNext()) {
                    if (n == 5) break;
                    this.logger(2, "test27_blahblah3()");
                    return -1;
                }
                YP_Row yP_Row = iterator.next();
                int n2 = (Integer)yP_Row.getFieldValueByName("test27Int");
                if (n2 != 1 && n2 != 2) {
                    this.logger(2, "test27_blahblah3()");
                    return -1;
                }
                n += n2;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set(yP_TCD_DesignAccesObject.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.ORDER_DESC);
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.size() != 3) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            if ((Integer)list.get(0).getFieldValueByName("test27Int") != 2) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            if ((Integer)list.get(1).getFieldValueByName("test27Int") != 2) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            if ((Integer)list.get(2).getFieldValueByName("test27Int") != 1) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
                this.logger(2, "test27_blahblah3()");
                return -1;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "test27_blahblah3() " + exception);
            return -1;
        }
    }

    private int test27_blahblah4(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        block8: {
            block7: {
                block6: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block6;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test27_blahblah4() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block7;
                this.logger(2, "test27_blahblah4() ");
                return -1;
            }
            ArrayList<YP_TCD_DAO_SQL_Transaction> arrayList = new ArrayList<YP_TCD_DAO_SQL_Transaction>();
            arrayList.add(yP_TCD_DAO_SQL_Transaction);
            arrayList.add(yP_TCD_DAO_SQL_Transaction);
            if (this.dataBaseConnector.sql_Formater.isSlaveTransactionEmpty(this.dataBaseConnector, arrayList)) break block8;
            this.logger(2, "test27_blahblah4()");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah4()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah5(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block14: {
            List<YP_Row> list;
            block13: {
                long[] lArray;
                block12: {
                    block11: {
                        block10: {
                            try {
                                if (UtilsYP.getInstanceRole() == 1) break block10;
                                return 0;
                            }
                            catch (Exception exception) {
                                this.logger(2, "test27_blahblah5() " + exception);
                                return -1;
                            }
                        }
                        if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block11;
                        this.logger(2, "test27_blahblah5() ");
                        return -1;
                    }
                    lArray = new long[]{1L, 2L};
                    if (this.getDataBaseConnector().sql_Formater.deleteFromWhere(yP_TCD_DesignAccesObject, this.dataBaseConnector, yP_TCD_DesignAccesObject.getFullTableName(), "test27Long", lArray) == 0) break block12;
                    this.logger(2, "test27_blahblah5()");
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Long", 1L);
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Long", 2L);
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Long", 3L);
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Long", 4L);
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                    yP_TCD_DesignAccesObject.persist();
                }
                if (this.getDataBaseConnector().sql_Formater.deleteFromWhere(yP_TCD_DesignAccesObject, this.dataBaseConnector, yP_TCD_DesignAccesObject.getFullTableName(), "test27Long", lArray) == 2) break block13;
                this.logger(2, "test27_blahblah5()");
                return -1;
            }
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                yP_TCD_DesignAccesObject.reload();
            }
            if ((list = yP_TCD_DesignAccesObject.getRowList()) != null && list.size() == 2) break block14;
            this.logger(2, "test27_blahblah5()");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah5()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah6(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        block14: {
            List<YP_Row> list;
            block13: {
                block12: {
                    block11: {
                        block10: {
                            block9: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block9;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test27_blahblah6() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block10;
                            this.logger(2, "test27_blahblah6() ");
                            return -1;
                        }
                        list = this.getDataBaseConnector().sql_Formater.selectFrom(this.dataBaseConnector, yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullTableName(), 0, 1);
                        if (list != null && list.size() == 0) break block11;
                        this.logger(2, "test27_blahblah6()");
                        return -1;
                    }
                    YP_Row yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    list = this.getDataBaseConnector().sql_Formater.selectFrom(this.dataBaseConnector, yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullTableName(), 0, 2);
                    if (list != null && list.size() == 2) break block12;
                    this.logger(2, "test27_blahblah6()");
                    return -1;
                }
                list = this.getDataBaseConnector().sql_Formater.selectFrom(this.dataBaseConnector, yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullTableName(), 0, 100);
                if (list != null && list.size() == 4) break block13;
                this.logger(2, "test27_blahblah6()");
                return -1;
            }
            list = this.getDataBaseConnector().sql_Formater.selectFrom(this.dataBaseConnector, yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullTableName(), 0, 0);
            if (list != null && list.size() == 4) break block14;
            this.logger(2, "test27_blahblah6()");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah6()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah7(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block15: {
            List<Object> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block14: {
                block13: {
                    List<String> list2;
                    block12: {
                        block11: {
                            block10: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block10;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test27_blahblah7() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block11;
                            this.logger(2, "test27_blahblah7() ");
                            return -1;
                        }
                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "1");
                        yP_Row.set("test27Long", 1);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "1");
                        yP_Row.set("test27Long", 1);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "2");
                        yP_Row.set("test27Long", 2);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "2");
                        yP_Row.set("test27Long", 2);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "3");
                        yP_Row.set("test27Long", 3);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "3");
                        yP_Row.set("test27Long", 3);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "4");
                        yP_Row.set("test27Long", 4);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "4");
                        yP_Row.set("test27Long", 4);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                            yP_TCD_DesignAccesObject.persist();
                        }
                        if ((list2 = yP_TCD_DesignAccesObject.getDistinctStringValueList("test27Array")) != null && list2.size() == 4) break block12;
                        this.logger(2, "test27_blahblah7()");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("test27Array", YP_ComplexGabarit.OPERATOR.GREATER, "2");
                    list2 = yP_TCD_DesignAccesObject.getDistinctStringValueListSuchAs("test27Array", yP_ComplexGabarit);
                    if (list2 != null && list2.size() == 2) break block13;
                    this.logger(2, "test27_blahblah7()");
                    return -1;
                }
                list = yP_TCD_DesignAccesObject.getDistinctValueList("test27Long");
                if (list != null && list.size() == 4) break block14;
                this.logger(2, "test27_blahblah7() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test27Long", YP_ComplexGabarit.OPERATOR.GREATER, 2L);
            list = yP_TCD_DesignAccesObject.getDistinctValueListSuchAs("test27Long", yP_ComplexGabarit);
            if (list != null && list.size() == 2) break block15;
            this.logger(2, "test27_blahblah7()");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah7()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah8(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block19: {
            List<String> list;
            String string;
            StringBuilder stringBuilder;
            block18: {
                block17: {
                    List<YP_Row> list2;
                    block16: {
                        block15: {
                            block14: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block14;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test27_blahblah8() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block15;
                            this.logger(2, "test27_blahblah8() ");
                            return -1;
                        }
                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "1");
                        yP_Row.set("test27Long", 1);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "1");
                        yP_Row.set("test27Long", 1);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "2");
                        yP_Row.set("test27Long", 2);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "2");
                        yP_Row.set("test27Long", 2);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "3");
                        yP_Row.set("test27Long", 3);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "3");
                        yP_Row.set("test27Long", 3);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "4");
                        yP_Row.set("test27Long", 4);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("test27Array", "4");
                        yP_Row.set("test27Long", 4);
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                            yP_TCD_DesignAccesObject.persist();
                        }
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT * FROM ");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                        stringBuilder.append(" WHERE test27Array = ");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue("3"));
                        string = yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DesignAccesObject);
                        if (string != null && !string.isEmpty()) {
                            stringBuilder.append("AND " + string + "\r\n");
                        }
                        if ((list2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null && list2.size() == 2) break block16;
                        this.logger(2, "test27_blahblah8()");
                        return -1;
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT * FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(" WHERE test27Array = ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue("4"));
                    stringBuilder.append(" AND test27Long = ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlValue(4));
                    if (string != null && !string.isEmpty()) {
                        stringBuilder.append("AND " + string + "\r\n");
                    }
                    if ((list2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null && list2.size() == 2) break block17;
                    this.logger(2, "test27_blahblah8()");
                    return -1;
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlDate("test27Timestamp"));
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                if (string != null && !string.isEmpty()) {
                    stringBuilder.append("WHERE " + string + "\r\n");
                }
                if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealStringListQuery(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null && list.size() == 8) break block18;
                this.logger(2, "test27_blahblah8()");
                return -1;
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT SUM(");
            stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlIF());
            stringBuilder.append("(test27Long = 4, 1, 0)) AS mySum\r\n");
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            if (string != null && !string.isEmpty()) {
                stringBuilder.append(" WHERE " + string + "\r\n");
            }
            if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealStringListQuery(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null && list.size() == 1) break block19;
            this.logger(2, "test27_blahblah8()");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah8()");
            return -1;
        }
        return 1;
    }

    private int test27_blahblah9(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block9: {
            block8: {
                block7: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block7;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test27_blahblah9() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block8;
                this.logger(2, "test27_blahblah9() ");
                return -1;
            }
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("test27Date", new Date(System.currentTimeMillis()));
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                yP_TCD_DesignAccesObject.persist();
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test27Date", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(System.currentTimeMillis()));
            List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block9;
            this.logger(2, "test27_blahblah9() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_blahblah9()");
            return -1;
        }
        return 1;
    }

    private int test27_maxWithEqualAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block11: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block10: {
                block9: {
                    block8: {
                        try {
                            if (UtilsYP.getInstanceRole() == 1) break block8;
                            return 0;
                        }
                        catch (Exception exception) {
                            this.logger(2, "test27_maxWithEqualAfter() " + exception);
                            return -1;
                        }
                    }
                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block9;
                    this.logger(2, "test27_maxWithEqualAfter() ");
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Date", new Date(System.currentTimeMillis()));
                yP_Row.set("test27Array", "1");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test27Date", new Date(0L));
                yP_Row.set("test27Array", "2");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                    yP_TCD_DesignAccesObject.persist();
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test27Date", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit.set("test27Array", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, "1");
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block10;
                this.logger(2, "test27_maxWithEqualAfter() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("test27Date", YP_ComplexGabarit.OPERATOR.MAX);
            yP_ComplexGabarit.set("test27Array", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, "2");
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.isEmpty()) break block11;
            this.logger(2, "test27_maxWithEqualAfter() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) <= 0) {
            this.logger(2, "test27_maxWithEqualAfter()");
            return -1;
        }
        return 1;
    }

    private int test28_blahblah1(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk) {
        block8: {
            block7: {
                block6: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block6;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test28_blahblah1() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block7;
                this.logger(2, "test28_blahblah1() ");
                return -1;
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("test28Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0);
            YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("test28Long", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0L);
            List<YP_Row> list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, yP_ComplexGabarit, yP_ComplexGabarit2);
            if (list != null) break block8;
            this.logger(2, "test28_blahblah1() ");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test28_blahblah1()");
            return -1;
        }
        return 1;
    }

    private int test28_blahblah2(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk) {
        block8: {
            block7: {
                block6: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block6;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test28_blahblah1() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block7;
                this.logger(2, "test28_blahblah2() ");
                return -1;
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("test28Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0);
            yP_ComplexGabarit.set("test28Long", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
            List<YP_Row> list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, yP_ComplexGabarit);
            if (list != null) break block8;
            this.logger(2, "test28_blahblah2() ");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test28_blahblah2()");
            return -1;
        }
        return 1;
    }

    private int test28_blahblah3(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk) {
        block10: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block9: {
                block8: {
                    block7: {
                        try {
                            if (UtilsYP.getInstanceRole() == 1) break block7;
                            return 0;
                        }
                        catch (Exception exception) {
                            this.logger(2, "test28_blahblah3() " + exception);
                            return -1;
                        }
                    }
                    if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block8;
                    this.logger(2, "test28_blahblah3() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
                yP_ComplexGabarit.set("test28Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0);
                yP_ComplexGabarit.set("test28Long", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
                list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, 0, 10, yP_ComplexGabarit);
                if (list != null) break block9;
                this.logger(2, "test28_blahblah3() ");
                return -1;
            }
            list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, 10, 20, yP_ComplexGabarit);
            if (list != null) break block10;
            this.logger(2, "test28_blahblah3() ");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test28_blahblah3()");
            return -1;
        }
        return 1;
    }

    private int test28_blahblah4(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk) {
        block8: {
            block7: {
                block6: {
                    try {
                        if (UtilsYP.getInstanceRole() == 1) break block6;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "test28_blahblah4() " + exception);
                        return -1;
                    }
                }
                if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block7;
                this.logger(2, "test28_blahblah4() ");
                return -1;
            }
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("test28Int", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, 0);
            if (yP_TCD_DAO_SQL_Transaction.archiveRowsSuchAs((YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, true, yP_ComplexGabarit) == 0) break block8;
            this.logger(2, "test28_blahblah4() ");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test28_blahblah4()");
            return -1;
        }
        return 1;
    }

    private int test28_maxWithEqualAfter(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DAO_SQL_Disk yP_TCD_DAO_SQL_Disk) {
        block12: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            block11: {
                block10: {
                    block9: {
                        block8: {
                            try {
                                if (UtilsYP.getInstanceRole() == 1) break block8;
                                return 0;
                            }
                            catch (Exception exception) {
                                this.logger(2, "test28_maxWithEqualAfter() " + exception);
                                return -1;
                            }
                        }
                        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) >= 0) break block9;
                        this.logger(2, "test28_maxWithEqualAfter() ");
                        return -1;
                    }
                    YP_Row yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_Row.set("test28Date", new Date(System.currentTimeMillis()));
                    yP_Row.set("test28Array", "1");
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
                    yP_Row.set("test28Date", new Date(0L));
                    yP_Row.set("test28Array", "2");
                    yP_TCD_DAO_SQL_Transaction.addRow(yP_Row);
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
                    yP_ComplexGabarit.set("test28Date", YP_ComplexGabarit.OPERATOR.MAX);
                    yP_ComplexGabarit.set("test28Array", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, "2");
                    list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, yP_ComplexGabarit);
                    if (list != null && list.isEmpty()) break block10;
                    this.logger(2, "test28_maxWithEqualAfter() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
                yP_ComplexGabarit.set("test28Date", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit.set("test28Array", YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP, "1");
                list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) break block11;
                this.logger(2, "test28_maxWithEqualAfter() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("test28Date", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
            yP_ComplexGabarit.set("test28Array", YP_ComplexGabarit.OPERATOR.EQUAL, "1");
            list = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, (YP_TCD_DesignAccesObject)yP_TCD_DAO_SQL_Disk, 0, 10, yP_ComplexGabarit);
            if (list != null && !list.isEmpty()) break block12;
            this.logger(2, "test28_maxWithEqualAfter() ");
            return -1;
        }
        if (yP_TCD_DAO_SQL_Transaction.deleteRows(true) <= 0) {
            this.logger(2, "test28_maxWithEqualAfter()");
            return -1;
        }
        return 1;
    }

    private int test29_IndexCreation(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block6: {
            block5: {
                try {
                    if (UtilsYP.getInstanceRole() == 1) break block5;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "test29_IndexCreation() " + exception);
                    return -1;
                }
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block6;
            this.logger(2, "test29_IndexCreation() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test29_IndexCreation() ");
            return -1;
        }
        return 1;
    }

    private int test30_PartitionTimestampCreation(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block6: {
            block5: {
                try {
                    if (UtilsYP.getInstanceRole() == 1) break block5;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "test30_PartitionTimestampCreation() " + exception);
                    return -1;
                }
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block6;
            this.logger(2, "test30_PartitionTimestampCreation() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test30_PartitionTimestampCreation() ");
            return -1;
        }
        return 1;
    }

    private int test30_PartitionMSCreation(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block6: {
            block5: {
                try {
                    if (UtilsYP.getInstanceRole() == 1) break block5;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "test30_PartitionMSCreation() " + exception);
                    return -1;
                }
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block6;
            this.logger(2, "test30_PartitionMSCreation() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test30_PartitionMSCreation() ");
            return -1;
        }
        return 1;
    }

    private int test32_SpecialsChars(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block12: {
            block11: {
                block10: {
                    block9: {
                        if (UtilsYP.getInstanceRole() == 1) break block9;
                        return 0;
                    }
                    if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block10;
                    this.logger(2, "test32_SpecialsChars() ");
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "\u00e2\u00e4\u00e0\u00e9\u00ea\u00eb\u00e8\u00ef\u00ee");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row.set("test32Array", "\u00e2\u00e4\u00e0\u00e9\u00ea\u00eb\u00e8\u00ef\u00ee".getBytes("UTF-8"));
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "'");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "\\");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "\"");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "[");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                yP_Row.set("test32Array", "]");
                yP_TCD_DesignAccesObject.addRow(yP_Row);
                if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                    yP_TCD_DesignAccesObject.persist();
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("test32Array", YP_ComplexGabarit.OPERATOR.EQUAL, "\u00e2\u00e4\u00e0\u00e9\u00ea\u00eb\u00e8\u00ef\u00ee");
                List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 2) break block11;
                this.logger(2, "test32_SpecialsChars() ");
                return -1;
            }
            try {
                int n = 0;
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string = yP_Row.getFieldStringValueByName("test32Array");
                    if (!string.contentEquals("\u00e2\u00e4\u00e0\u00e9\u00ea\u00eb\u00e8\u00ef\u00ee")) continue;
                    ++n;
                }
                if (n == 2) break block12;
                this.logger(2, "test32_SpecialsChars() ");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "test32_SpecialsChars() " + exception);
                return -1;
            }
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test32_SpecialsChars() ");
            return -1;
        }
        return 1;
    }

    private int test33_TableNameExtensions(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block6: {
            block5: {
                try {
                    if (UtilsYP.getInstanceRole() == 1) break block5;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "test33_TableNameExtensions() " + exception);
                    return -1;
                }
            }
            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block6;
            this.logger(2, "test33_TableNameExtensions() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test33_TableNameExtensions() ");
            return -1;
        }
        return 1;
    }

    private int test35_SpecialsColumnName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block15: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            long l;
            block14: {
                block13: {
                    block12: {
                        block11: {
                            block10: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block10;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test35_SpecialsColumnName() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block11;
                            this.logger(2, "test35_SpecialsColumnName() ");
                            return -1;
                        }
                        l = System.currentTimeMillis();
                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("MIN", 1);
                        yP_Row.set("MAX", 999);
                        yP_Row.set("SELECT", 1.2);
                        yP_Row.set("WHERE", "WHERE");
                        yP_Row.set("IN", new Timestamp(l));
                        yP_Row.set("MOY", new Date(l));
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                            yP_TCD_DesignAccesObject.persist();
                        }
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                        yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                        yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.2);
                        yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                        yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                        yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                        if (list != null && list.size() == 1) break block12;
                        this.logger(2, "test35_SpecialsColumnName() ");
                        return -1;
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                    yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                    yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.2);
                    yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                    yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                    yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                    yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
                    yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.MAX);
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && list.size() == 1) break block13;
                    this.logger(2, "test35_SpecialsColumnName() ");
                    return -1;
                }
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.2);
                yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.GROUP);
                yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.MAX);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null && list.size() == 1) break block14;
                this.logger(2, "test35_SpecialsColumnName() ");
                return -1;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
            yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
            yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.2);
            yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
            yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
            yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
            yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.MIN);
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.size() == 1) break block15;
            this.logger(2, "test35_SpecialsColumnName() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test35_SpecialsColumnName() ");
            return -1;
        }
        return 1;
    }

    private int test35_MultipleGabarit(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block15: {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit;
            YP_ComplexGabarit yP_ComplexGabarit2;
            long l;
            block14: {
                block13: {
                    block12: {
                        block11: {
                            block10: {
                                try {
                                    if (UtilsYP.getInstanceRole() == 1) break block10;
                                    return 0;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "test35_MultipleGabarit() " + exception);
                                    return -1;
                                }
                            }
                            if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block11;
                            this.logger(2, "test35_MultipleGabarit() ");
                            return -1;
                        }
                        l = System.currentTimeMillis();
                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("MIN", 1);
                        yP_Row.set("MAX", 999);
                        yP_Row.set("SELECT", 1.1);
                        yP_Row.set("WHERE", "WHERE");
                        yP_Row.set("IN", new Timestamp(l));
                        yP_Row.set("MOY", new Date(l));
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("MIN", 1);
                        yP_Row.set("MAX", 999);
                        yP_Row.set("SELECT", 2.2);
                        yP_Row.set("WHERE", "WHERE");
                        yP_Row.set("IN", new Timestamp(l));
                        yP_Row.set("MOY", new Date(l));
                        yP_TCD_DesignAccesObject.addRow(yP_Row);
                        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC) {
                            yP_TCD_DesignAccesObject.persist();
                        }
                        yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                        yP_ComplexGabarit2.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                        yP_ComplexGabarit2.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.1);
                        yP_ComplexGabarit2.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                        yP_ComplexGabarit2.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                        yP_ComplexGabarit2.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                        yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                        yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)2.2);
                        yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                        yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                        yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                        yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
                        yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.MAX);
                        list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2, yP_ComplexGabarit);
                        if (list != null && list.size() == 2) break block12;
                        this.logger(2, "test35_MultipleGabarit()  ");
                        return -1;
                    }
                    list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit, yP_ComplexGabarit2);
                    if (list != null && list.size() == 2) break block13;
                    this.logger(2, "test35_MultipleGabarit() ");
                    return -1;
                }
                yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                yP_ComplexGabarit2.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                yP_ComplexGabarit2.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)1.1);
                yP_ComplexGabarit2.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                yP_ComplexGabarit2.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                yP_ComplexGabarit2.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
                yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.MIN);
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
                yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
                yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)2.2);
                yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
                yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
                yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
                yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
                yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.MAX);
                list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2, yP_ComplexGabarit);
                if (list != null && list.size() == 2) break block14;
                this.logger(2, "test35_MultipleGabarit() ");
                return -1;
            }
            yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
            yP_ComplexGabarit2.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
            yP_ComplexGabarit2.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)3.3);
            yP_ComplexGabarit2.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
            yP_ComplexGabarit2.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
            yP_ComplexGabarit2.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
            yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit2.set("MIN", YP_ComplexGabarit.OPERATOR.MIN);
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.EQUAL, 1);
            yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.EQUAL, 999);
            yP_ComplexGabarit.set("SELECT", YP_ComplexGabarit.OPERATOR.EQUAL, (Object)2.2);
            yP_ComplexGabarit.set("WHERE", YP_ComplexGabarit.OPERATOR.EQUAL, "WHERE");
            yP_ComplexGabarit.set("IN", YP_ComplexGabarit.OPERATOR.EQUAL, new Timestamp(l));
            yP_ComplexGabarit.set("MOY", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(l));
            yP_ComplexGabarit.set("MIN", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("MAX", YP_ComplexGabarit.OPERATOR.MAX);
            list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2, yP_ComplexGabarit);
            if (list != null && list.size() == 1) break block15;
            this.logger(2, "test35_MultipleGabarit() ");
            return -1;
        }
        if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
            this.logger(2, "test35_MultipleGabarit() ");
            return -1;
        }
        return 1;
    }

    private int test36_extendedTVRTestTransaction(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block4: {
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            ExtendedTVR extendedTVR = new ExtendedTVR();
            extendedTVR.add(ExtendedTVREnumeration.TEST_CARD);
            yP_Row.set("extendedTVR", extendedTVR.toString());
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("extendedTVR", YP_ComplexGabarit.OPERATOR.LIKE, "____________[89ABCDEF]%");
            List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.isEmpty()) break block4;
            this.logger(2, "test36_extendedTVRTestTransaction() ");
            return -1;
        }
        try {
            if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                this.logger(2, "test36_extendedTVRTestTransaction() ");
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "test36_extendedTVRTestTransaction() ", exception);
            exception.printStackTrace();
        }
        return 1;
    }

    private int test36_extendedTVROfflineTransaction(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        block4: {
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            ExtendedTVR extendedTVR = new ExtendedTVR();
            extendedTVR.add(ExtendedTVREnumeration.OFFLINE_TRS);
            yP_Row.set("extendedTVR", extendedTVR.toString());
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("extendedTVR", YP_ComplexGabarit.OPERATOR.LIKE, "________________[2468ACE]%");
            List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null && list.isEmpty()) break block4;
            this.logger(2, "test36_extendedTVROfflineTransaction() ");
            return -1;
        }
        try {
            if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                this.logger(2, "test36_extendedTVROfflineTransaction() ");
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "test36_extendedTVROfflineTransaction() ", exception);
            exception.printStackTrace();
        }
        return 1;
    }

    private int test37_bigTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>(1000);
            int n = 0;
            while (n < 1000) {
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                arrayList.add(yP_Row);
                ++n;
            }
            yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlUpdateRowList(yP_TCD_DesignAccesObject, arrayList);
            if (yP_TCD_DesignAccesObject.deleteRows(true) < 0) {
                this.logger(2, "test37_bigTable() ");
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "test37_bigTable() ", exception);
            exception.printStackTrace();
        }
        return 1;
    }

    private int test38_ticketTrim(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_Row yP_Row;
        String string;
        block6: {
            block5: {
                if (yP_TCD_DesignAccesObject.deleteRows(true) >= 0) break block5;
                this.logger(2, "test38_ticketTrim() ");
                return -1;
            }
            string = "\n  CARTE BANCAIRE\n      SANS CONTACT\nCREDIT AGRICOLE \n        ANJOU MAINE\nA0000000421010\nCB\nLe 24/10/2020 a 18:13:03\nASCA SECTION TENNIS 72650\nLA MILESSE\n2622423 33924093900027 17906\n2010\n5132395002552929\n8943721A57E13000\nfin  31/03/23\n001 001 000001 C @ \nNUM AUTO : 794917\nMONTANT :\n         2,00 EUR\nDEBIT\n\nTICKET COMMERCANT\nA CONSERVER\nMERCI AU REVOIR \n          112_M_CACL\n";
            yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            yP_Row.set("ticket", string);
            yP_TCD_DesignAccesObject.addRow(yP_Row);
            yP_Row = yP_TCD_DesignAccesObject.getUniqueRow();
            if (yP_Row != null) break block6;
            this.logger(2, "test38_ticketTrim()  ");
            return -1;
        }
        try {
            String string2 = yP_Row.getFieldStringValueByName("ticket");
            if (!string2.contentEquals(string)) {
                this.logger(2, "test38_ticketTrim() ");
            }
        }
        catch (Exception exception) {
            this.logger(2, "test38_ticketTrim() ", exception);
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        return null;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerTest";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    @Override
    public String getTransactionTicket(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl, int n) {
        return null;
    }
}

