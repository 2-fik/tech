/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicInteger;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.UtilsYP;

public abstract class YP_TCD_DAO_LOC
extends YP_TCD_DesignAccesObject {
    protected static final int NOT_LOADED = 0;
    protected static final int LOADING = 1;
    protected static final int LOADED = 2;
    protected static final int UNLOADING = 3;
    protected volatile boolean persistInProcess = false;
    protected final AtomicInteger nbConcurrentReadAccess = new AtomicInteger(0);
    protected int isLoadedInMemory = 0;
    protected Calendar loadedSinceGMTTime = null;
    protected final AtomicInteger nbtimeUsedSinceReload = new AtomicInteger(0);
    private static boolean firstReloadSuccessfull = false;

    protected int prepare() {
        this.nbtimeUsedSinceReload.incrementAndGet();
        if (this.isLoadedInMemory != 2) {
            try {
                this.lock();
                if (this.isLoadedInMemory != 1 && this.isLoadedInMemory != 2) {
                    do {
                        if (this.reload() >= 0) {
                            firstReloadSuccessfull = true;
                            continue;
                        }
                        this.logger(2, "prepare() server won't go on as the DB seems offline");
                        UtilsYP.sleep(5000);
                    } while (!firstReloadSuccessfull);
                }
            }
            finally {
                this.unlock();
            }
        }
        return 1;
    }

    public YP_TCD_DAO_LOC(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    public abstract int unload();

    public abstract boolean isEmpty();

    /*
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<YP_Row> getRowListSuchAs(int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            int n3;
            boolean bl = false;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null || yP_ComplexGabaritArray[0].size() == 0) {
                bl = true;
            } else {
                YP_ComplexGabarit yP_ComplexGabarit;
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                int n4 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n4) {
                    yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.groupFieldNameList != null) {
                        if (yP_ComplexGabaritArray.length > 1) {
                            Object object;
                            HashSet<YP_Row> hashSet = new HashSet<YP_Row>();
                            YP_ComplexGabarit[] yP_ComplexGabaritArray3 = yP_ComplexGabaritArray;
                            int n5 = yP_ComplexGabaritArray.length;
                            int n6 = 0;
                            while (n6 < n5) {
                                object = yP_ComplexGabaritArray3[n6];
                                List<YP_Row> list = this.getRowListSuchAs(n, n2, new YP_ComplexGabarit[]{object});
                                if (list == null) {
                                    this.logger(2, "getRowListSuchAs() failed on multiple group");
                                } else {
                                    hashSet.addAll(list);
                                }
                                ++n6;
                            }
                            object = new ArrayList();
                            object.addAll(hashSet);
                            return YP_TCD_DAO_LOC.orderRowList((List<YP_Row>)object, yP_ComplexGabaritArray);
                        }
                        if (!yP_ComplexGabarit.gabaritHasOneMinOrMax) {
                            this.logger(2, "getRowListSuchAs()  group operator is for aggregated columns (MIN, MAX)");
                            return null;
                        }
                    }
                    ++n3;
                }
                yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n4 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n4) {
                    yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.gabaritHasOneMinOrMax) {
                        return YP_TCD_DAO_LOC.orderRowList(this.getRowListSuchAsForMinMax(n, n2, yP_ComplexGabaritArray), yP_ComplexGabaritArray);
                    }
                    ++n3;
                }
            }
            boolean bl2 = !this.isLockedByMe();
            List<YP_Row> list = new ArrayList<YP_Row>();
            int n7 = this.size();
            if (n7 < 0) {
                return null;
            }
            int n8 = 0;
            while (n8 < n7) {
                YP_Row yP_Row = this.getRowAt(n8, bl2);
                if (yP_Row.getModifierFlag() != 1) {
                    if (bl) {
                        n3 = 1;
                    } else {
                        n3 = 0;
                        YP_ComplexGabarit[] yP_ComplexGabaritArray4 = yP_ComplexGabaritArray;
                        int n9 = yP_ComplexGabaritArray.length;
                        int n10 = 0;
                        while (n10 < n9) {
                            YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray4[n10];
                            if (yP_ComplexGabarit.match(yP_Row)) {
                                n3 = 1;
                                break;
                            }
                            ++n10;
                        }
                    }
                    if (n3 != 0) {
                        list.add(yP_Row);
                    }
                }
                ++n8;
            }
            list = YP_TCD_DAO_LOC.orderRowList(list, yP_ComplexGabaritArray);
            if (n != 0) {
                if (n > list.size()) {
                    list.clear();
                } else {
                    n8 = 0;
                    while (n8 < n) {
                        list.remove(0);
                        ++n8;
                    }
                }
            }
            if (n2 > 0) {
                while (list.size() > n2) {
                    list.remove(list.size() - 1);
                }
            }
            return list;
        }
        catch (Exception exception) {
            this.logger(2, "getRowListSuchAs()  ", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private List<YP_Row> getRowListSuchAsForMinMax(int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null || yP_ComplexGabaritArray[0].size() == 0) {
                this.logger(2, "getRowListSuchAsForMinMax() Not possible... ");
                return null;
            }
            boolean bl = !this.isLockedByMe();
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            int n3 = this.size();
            if (n3 < 0) {
                return null;
            }
            ArrayList[] arrayListArray = new ArrayList[yP_ComplexGabaritArray.length];
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                object = yP_ComplexGabaritArray[n4];
                if (((YP_ComplexGabarit)object).gabaritHasOneMinOrMax) {
                    arrayListArray[n4] = new ArrayList();
                }
                ++n4;
            }
            n4 = 0;
            while (n4 < n3) {
                object = this.getRowAt(n4, bl);
                if (((YP_Row)object).getModifierFlag() != 1) {
                    int n5 = 0;
                    while (n5 < yP_ComplexGabaritArray.length) {
                        YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n5];
                        if (yP_ComplexGabarit.match((YP_Row)object, 0)) {
                            arrayList.add((YP_Row)object);
                            if (yP_ComplexGabarit.gabaritHasOneMinOrMax) {
                                arrayListArray[n5].add(object);
                            }
                        }
                        ++n5;
                    }
                }
                ++n4;
            }
            n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                object = yP_ComplexGabaritArray[n4];
                if (((YP_ComplexGabarit)object).gabaritHasOneMinOrMax) {
                    int n6;
                    int n7;
                    String string;
                    if (((YP_ComplexGabarit)object).minFieldName != null) {
                        string = ((YP_ComplexGabarit)object).minFieldName;
                        n7 = 0;
                    } else {
                        if (((YP_ComplexGabarit)object).maxFieldName == null) {
                            this.logger(2, "getRowListSuchAsForMinMax() Not possible... ");
                            return null;
                        }
                        string = ((YP_ComplexGabarit)object).maxFieldName;
                        n7 = 1;
                    }
                    List<YP_Row> list = ((YP_ComplexGabarit)object).groupFieldList != null ? YP_TCD_DAO_LOC.getMinMaxRowListSuchAsGrouped(this, string, n7, arrayListArray[n4], ((YP_ComplexGabarit)object).groupFieldList) : YP_TCD_DAO_LOC.getMinMaxRowListSuchAs(this, string, n7, arrayListArray[n4]);
                    if (list == null) {
                        this.logger(2, "getRowListSuchAsForMinMax()  unable to get rowList");
                        return null;
                    }
                    for (YP_Row yP_Row : list) {
                        n6 = 0;
                        while (n6 < arrayListArray[n4].size()) {
                            if (arrayListArray[n4].get(n6) == yP_Row) {
                                arrayListArray[n4].remove(n6);
                            }
                            ++n6;
                        }
                    }
                    for (YP_Row yP_Row : arrayListArray[n4]) {
                        n6 = 0;
                        while (n6 < arrayList.size()) {
                            if (arrayList.get(n6) == yP_Row) {
                                arrayList.remove(n6);
                            }
                            ++n6;
                        }
                    }
                }
                ++n4;
            }
            n4 = 0;
            int n8 = 0;
            while (n8 < yP_ComplexGabaritArray.length) {
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n8];
                int n9 = 0;
                while (n9 < yP_ComplexGabarit.size()) {
                    if (yP_ComplexGabarit.getOperatorAt(n9) == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP || yP_ComplexGabarit.getOperatorAt(n9) == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP || yP_ComplexGabarit.getOperatorAt(n9) == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP || yP_ComplexGabarit.getOperatorAt(n9) == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                        n4 = 1;
                        break;
                    }
                    ++n9;
                }
                ++n8;
            }
            if (n4 != 0) {
                n8 = arrayList.size() - 1;
                while (n8 >= 0) {
                    YP_Row yP_Row = (YP_Row)arrayList.get(n8);
                    boolean bl2 = false;
                    int n10 = 0;
                    while (n10 < yP_ComplexGabaritArray.length) {
                        YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n10];
                        if (yP_ComplexGabarit.match(yP_Row, 2)) {
                            bl2 = true;
                        }
                        if (!bl2) {
                            arrayList.remove(n8);
                        }
                        ++n10;
                    }
                    --n8;
                }
            }
            n8 = 0;
            while (n8 < arrayList.size() - 1) {
                if (arrayList.get(n8) == arrayList.get(n8 + 1)) {
                    arrayList.remove(n8);
                }
                ++n8;
            }
            if (n != 0) {
                if (n > arrayList.size()) {
                    arrayList.clear();
                } else {
                    n8 = 0;
                    while (n8 < n) {
                        arrayList.remove(0);
                        ++n8;
                    }
                }
            }
            if (n2 > 0) {
                while (arrayList.size() > n2) {
                    arrayList.remove(arrayList.size() - 1);
                }
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getRowListSuchAsForMinMax()  ", exception);
            return null;
        }
    }

    @Override
    public List<String> getDistinctStringValueList(String string) {
        try {
            boolean bl = !this.isLockedByMe();
            ArrayList<String> arrayList = new ArrayList<String>();
            Field field = this.getFieldByName(string);
            int n = this.size();
            int n2 = 0;
            while (n2 < n) {
                YP_Row yP_Row = this.getRowAt(n2, bl);
                if (yP_Row.getModifierFlag() != 1) {
                    String string2 = yP_Row.getFieldStringValue(field);
                    boolean bl2 = false;
                    for (String string3 : arrayList) {
                        if (!string3.contentEquals(string2)) continue;
                        bl2 = true;
                        break;
                    }
                    if (!bl2) {
                        arrayList.add(string2);
                    }
                }
                ++n2;
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getDistinctStringValueList() ", exception);
            return null;
        }
    }

    @Override
    public List<String> getDistinctStringValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        List<YP_Row> list;
        block6: {
            list = this.getRowListSuchAs(yP_ComplexGabaritArray);
            if (list != null) break block6;
            return null;
        }
        try {
            ArrayList<String> arrayList = new ArrayList<String>();
            if (list.isEmpty()) {
                return arrayList;
            }
            Field field = this.getFieldByName(string);
            for (YP_Row yP_Row : list) {
                String string2 = yP_Row.getFieldStringValue(field);
                boolean bl = false;
                for (String string3 : arrayList) {
                    if (!string3.contentEquals(string2)) continue;
                    bl = true;
                    break;
                }
                if (bl) continue;
                arrayList.add(string2);
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getDistinctStringValueListSuchAs() ", exception);
            return null;
        }
    }

    @Override
    public List<Object> getDistinctValueList(String string) {
        try {
            boolean bl = !this.isLockedByMe();
            Field field = this.getFieldByName(string);
            ArrayList<Object> arrayList = new ArrayList<Object>();
            int n = this.size();
            int n2 = 0;
            while (n2 < n) {
                YP_Row yP_Row = this.getRowAt(n2, bl);
                if (yP_Row.getModifierFlag() != 1) {
                    Object object = yP_Row.getFieldValue(field);
                    boolean bl2 = false;
                    for (Object e : arrayList) {
                        if (YP_ComplexGabarit.compare(e, object) != 0) continue;
                        bl2 = true;
                        break;
                    }
                    if (!bl2) {
                        arrayList.add(object);
                    }
                }
                ++n2;
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getDistinctValueList() ", exception);
            return null;
        }
    }

    @Override
    public List<Object> getDistinctValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        List<YP_Row> list;
        block6: {
            list = this.getRowListSuchAs(yP_ComplexGabaritArray);
            if (list != null) break block6;
            return null;
        }
        try {
            ArrayList<Object> arrayList = new ArrayList<Object>();
            if (list.isEmpty()) {
                return arrayList;
            }
            Field field = this.getFieldByName(string);
            for (YP_Row yP_Row : list) {
                Object object = yP_Row.getFieldValue(field);
                boolean bl = false;
                for (Object e : arrayList) {
                    if (YP_ComplexGabarit.compare(e, object) != 0) continue;
                    bl = true;
                    break;
                }
                if (bl) continue;
                arrayList.add(object);
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getDistinctValueListSuchAs() ", exception);
            return null;
        }
    }

    @Override
    public long getSumSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        List<YP_Row> list;
        long l;
        block4: {
            l = 0L;
            list = this.getRowListSuchAs(yP_ComplexGabaritArray);
            if (list != null && !list.isEmpty()) break block4;
            return 0L;
        }
        try {
            int n = 0;
            while (n < list.size()) {
                l += ((Long)list.get(n).getFieldValueByName(string)).longValue();
                ++n;
            }
            return l;
        }
        catch (Exception exception) {
            this.logger(2, "getSumSuchAs() ", exception);
            return -1L;
        }
    }

    @Override
    public int getCountSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        List<YP_Row> list;
        block3: {
            try {
                list = this.getRowListSuchAs(yP_ComplexGabaritArray);
                if (list != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "getCountSuchAs() ", exception);
                return -1;
            }
        }
        return list.size();
    }

    @Override
    public Iterator<YP_Row> iterator() {
        return new DAOIterator<YP_Row>();
    }

    class DAOIterator<T>
    implements Iterator<T> {
        int count = 0;
        int daoSize;

        DAOIterator() {
            this.daoSize = YP_TCD_DAO_LOC.this.size();
        }

        @Override
        public boolean hasNext() {
            return this.count < this.daoSize;
        }

        @Override
        public T next() {
            if (this.count == this.daoSize) {
                throw new NoSuchElementException();
            }
            return (T)YP_TCD_DAO_LOC.this.getRowAt(this.count++);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}

