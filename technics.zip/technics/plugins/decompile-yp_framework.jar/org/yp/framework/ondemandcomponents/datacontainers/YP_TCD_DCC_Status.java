/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.status.DAO_ConnectionStatus;
import org.yp.designaccesobjects.technic.status.DAO_ContractStatus;
import org.yp.designaccesobjects.technic.status.DAO_CryptoModuleStatus;
import org.yp.designaccesobjects.technic.status.DAO_PluginStatus;
import org.yp.designaccesobjects.technic.status.DAO_ServiceStatus;
import org.yp.designaccesobjects.technic.status.DAO_TerminalStatus;
import org.yp.designaccesobjects.technic.status.DAO_UserStatus;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.IdentificationLevelEnumeration;

public class YP_TCD_DCC_Status
extends YP_TCD_DC_Context {
    private YP_TCD_DesignAccesObject connectionStatus;
    private final List<YP_Row> connectionStatusCached = new ArrayList<YP_Row>();
    public YP_TCD_DesignAccesObject contractStatus;
    private final List<YP_Row> contractStatusCached = new ArrayList<YP_Row>();
    private YP_TCD_DesignAccesObject userStatus;
    private final List<YP_Row> userStatusCached = new ArrayList<YP_Row>();
    private YP_TCD_DesignAccesObject terminalStatus;
    private final List<YP_Row> terminalStatusCached = new ArrayList<YP_Row>();
    private YP_TCD_DesignAccesObject serviceStatus;
    private final List<YP_Row> serviceStatusCached = new ArrayList<YP_Row>();
    private YP_TCD_DesignAccesObject pluginStatus;
    private final List<YP_Row> pluginStatusCached = new ArrayList<YP_Row>();
    private YP_TCD_DesignAccesObject cryptoModuleStatus;
    private final List<YP_Row> cryptoModuleStatusCached = new ArrayList<YP_Row>();

    public YP_TCD_DCC_Status(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.connectionStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ConnectionStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.connectionStatus, this.connectionStatusCached);
            this.contractStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ContractStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.contractStatus, this.contractStatusCached);
            this.userStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_UserStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.userStatus, this.userStatusCached);
            this.terminalStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_TerminalStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.terminalStatus, this.terminalStatusCached);
            this.serviceStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_ServiceStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.serviceStatus, this.serviceStatusCached);
            this.pluginStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_PluginStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.pluginStatus, this.pluginStatusCached);
            this.cryptoModuleStatus = (YP_TCD_DesignAccesObject)this.newPluginByName("DAO_Disk", DAO_CryptoModuleStatus.class, 0, 2, null);
            YP_TCD_DCC_Status.loadOneStatusCache(this.pluginStatus, this.pluginStatusCached);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "DataContainerStatus";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.connectionStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() connectionStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() contractStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() userStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() terminalStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.serviceStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() serviceStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pluginStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() pluginStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.cryptoModuleStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() cryptoModuleStatus");
            }
            return 1;
        }
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.connectionStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() connectionStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() contractStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() userStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() terminalStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.serviceStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() serviceStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pluginStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() pluginStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.cryptoModuleStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() cryptoModuleStatus");
            }
            return 1;
        }
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.connectionStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() connectionStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.contractStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() contractStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.userStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() userStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.terminalStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() terminalStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.serviceStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() serviceStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.pluginStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() pluginStatus");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.cryptoModuleStatus) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() cryptoModuleStatus");
            }
            return 1;
        }
        return super.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    private static int loadOneStatusCache(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list) {
        list.clear();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
        yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(System.currentTimeMillis()));
        List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list2 == null) {
            return -1;
        }
        list.addAll(list2);
        return list.size();
    }

    private static int flushOneTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list) {
        if (!yP_TCD_DesignAccesObject.isItAModifiedDAO()) {
            return 0;
        }
        try {
            try {
                yP_TCD_DesignAccesObject.lock();
                if (yP_TCD_DesignAccesObject.isItAModifiedDAO()) {
                    YP_Row.persistList(list);
                    yP_TCD_DesignAccesObject.setIsItAModifiedDAO(false);
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
                yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.DIFFERENT, new Date(System.currentTimeMillis()));
                List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(list, yP_ComplexGabarit);
                if (list2 != null && !list2.isEmpty()) {
                    int n = 0;
                    while (n < list2.size()) {
                        list.remove(list2.get(n));
                        ++n;
                    }
                }
            }
            catch (ConcurrentModificationException concurrentModificationException) {
                System.out.println("flushOneTable() exception ignored" + concurrentModificationException);
                yP_TCD_DesignAccesObject.unlock();
            }
        }
        finally {
            yP_TCD_DesignAccesObject.unlock();
        }
        return 1;
    }

    public int flushTables() {
        int n = 0;
        n += YP_TCD_DCC_Status.flushOneTable(this.connectionStatus, this.connectionStatusCached);
        n += YP_TCD_DCC_Status.flushOneTable(this.contractStatus, this.contractStatusCached);
        n += YP_TCD_DCC_Status.flushOneTable(this.userStatus, this.userStatusCached);
        n += YP_TCD_DCC_Status.flushOneTable(this.terminalStatus, this.terminalStatusCached);
        n += YP_TCD_DCC_Status.flushOneTable(this.pluginStatus, this.pluginStatusCached);
        n += YP_TCD_DCC_Status.flushOneTable(this.serviceStatus, this.serviceStatusCached);
        return (n += YP_TCD_DCC_Status.flushOneTable(this.cryptoModuleStatus, this.cryptoModuleStatusCached)) > 0 ? 1 : 0;
    }

    public int updateConnectionStatus(boolean bl, YP_Row yP_Row, long l) {
        if (UtilsYP.isMoroccoServer()) {
            return 1;
        }
        try {
            long l2 = System.currentTimeMillis();
            Timestamp timestamp = new Timestamp(l2);
            Date date = new Date(l2);
            String string = yP_Row.getPrimaryKeyName();
            long l3 = yP_Row.getPrimaryKey();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.connectionStatus);
            yP_ComplexGabarit.set(string, YP_ComplexGabarit.OPERATOR.EQUAL, l3);
            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, date);
            try {
                YP_Row yP_Row2;
                this.connectionStatus.lock();
                List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.connectionStatusCached, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) {
                    yP_Row2 = list.get(0);
                } else {
                    list = this.connectionStatus.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && !list.isEmpty()) {
                        yP_Row2 = list.get(0);
                    } else {
                        yP_Row2 = this.connectionStatus.getNewRow();
                        yP_Row2.set(string, l3);
                        yP_Row2.set("instanceNumber", UtilsYP.getInstanceNumber());
                        yP_Row2.set("date", date);
                        this.connectionStatus.addRow(yP_Row2, true);
                    }
                    this.connectionStatusCached.add(yP_Row2);
                }
                if (bl) {
                    int n = (Integer)yP_Row2.getFieldValueByName("nbOK");
                    int n2 = (Integer)yP_Row2.getFieldValueByName("minTimeOK");
                    int n3 = (Integer)yP_Row2.getFieldValueByName("maxTimeOK");
                    int n4 = (Integer)yP_Row2.getFieldValueByName("averageTimeOK");
                    if (n2 == 0 || l < (long)n2) {
                        yP_Row2.set("minTimeOK", l);
                    }
                    if (l > (long)n3) {
                        yP_Row2.set("maxTimeOK", l);
                    }
                    n4 = (int)(((long)(n4 * n) + l) / (long)(n + 1));
                    yP_Row2.set("nbOK", ++n);
                    yP_Row2.set("averageTimeOK", n4);
                    yP_Row2.set("lastOKSystemLocalTime", timestamp);
                } else {
                    int n = (Integer)yP_Row2.getFieldValueByName("nbKO");
                    int n5 = (Integer)yP_Row2.getFieldValueByName("minTimeKO");
                    int n6 = (Integer)yP_Row2.getFieldValueByName("maxTimeKO");
                    int n7 = (Integer)yP_Row2.getFieldValueByName("averageTimeKO");
                    if (n5 == 0 || l < (long)n5) {
                        yP_Row2.set("minTimeKO", l);
                    }
                    if (l > (long)n6) {
                        yP_Row2.set("maxTimeKO", l);
                    }
                    n7 = (int)(((long)(n7 * n) + l) / (long)(n + 1));
                    yP_Row2.set("nbKO", ++n);
                    yP_Row2.set("averageTimeKO", n7);
                    yP_Row2.set("lastKOSystemLocalTime", timestamp);
                }
            }
            finally {
                this.connectionStatus.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateConnectionStatus() ", exception);
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int adjustConnectionStatusIssues(YP_Row yP_Row, ConnectionStatusIssueEnumeration connectionStatusIssueEnumeration) {
        if (UtilsYP.isMoroccoServer()) {
            return 0;
        }
        if (yP_Row == null || connectionStatusIssueEnumeration == null) {
            this.logger(2, "adjustConnectionStatusIssues() bad parameters");
            return -1;
        }
        try {
            long l = System.currentTimeMillis();
            Date date = new Date(l);
            String string = yP_Row.getPrimaryKeyName();
            long l2 = yP_Row.getPrimaryKey();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.connectionStatus);
            yP_ComplexGabarit.set(string, YP_ComplexGabarit.OPERATOR.EQUAL, l2);
            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, date);
            try {
                YP_Row yP_Row2;
                this.connectionStatus.lock();
                List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.connectionStatusCached, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) {
                    yP_Row2 = list.get(0);
                } else {
                    list = this.connectionStatus.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null) return 0;
                    if (list.isEmpty()) return 0;
                    yP_Row2 = list.get(0);
                    this.connectionStatusCached.add(yP_Row2);
                }
                switch (connectionStatusIssueEnumeration) {
                    case CONNECT_BROKEN: {
                        int n = (Integer)yP_Row2.getFieldValueByName("nbConnectBroken");
                        yP_Row2.set("nbConnectBroken", ++n);
                        return 1;
                    }
                    case CONNECT_TIMEOUT: {
                        int n = (Integer)yP_Row2.getFieldValueByName("nbConnectTimeout");
                        yP_Row2.set("nbConnectTimeout", ++n);
                        return 1;
                    }
                    case CONNECT_PROTOCOL: {
                        int n = (Integer)yP_Row2.getFieldValueByName("nbConnectProtocol");
                        yP_Row2.set("nbConnectProtocol", ++n);
                        return 1;
                    }
                    case RECEIVE_BROKEN: {
                        int n = (Integer)yP_Row2.getFieldValueByName("nbReceiveBroken");
                        yP_Row2.set("nbReceiveBroken", ++n);
                        return 1;
                    }
                    case RECEIVE_TIMEOUT: {
                        int n = (Integer)yP_Row2.getFieldValueByName("nbReceiveTimeout");
                        yP_Row2.set("nbReceiveTimeout", ++n);
                        return 1;
                    }
                }
                this.logger(2, "adjustConnectionStatusIssues() unhandled issue " + (Object)((Object)connectionStatusIssueEnumeration));
                return 0;
            }
            finally {
                this.connectionStatus.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "adjustConnectionStatusIssues() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public int updateContractStatus(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (UtilsYP.isMoroccoServer()) {
            return 1;
        }
        YP_Row yP_Row = yP_TCD_DCC_Business.getContractRow();
        try {
            Object object;
            Date date = new Date(System.currentTimeMillis());
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.contractStatus);
            yP_ComplexGabarit.set(yP_Row.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getPrimaryKey());
            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, date);
            List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.contractStatusCached, yP_ComplexGabarit);
            if ((list == null || list.isEmpty()) && ((list = this.contractStatus.getRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty())) {
                try {
                    this.contractStatus.lock();
                    list = this.contractStatus.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null || list.isEmpty()) {
                        object = this.contractStatus.getNewRow();
                        ((YP_Row)object).set(yP_Row.getPrimaryKeyName(), yP_Row.getPrimaryKey());
                        ((YP_Row)object).set("instanceNumber", UtilsYP.getInstanceNumber());
                        ((YP_Row)object).set("date", date);
                        this.contractStatus.addRow((YP_Row)object);
                        list = this.contractStatus.getRowListSuchAs(yP_ComplexGabarit);
                        if (list == null || list.isEmpty()) {
                            this.logger(2, "updatecontractStatus() impossible to be here... ");
                            return -1;
                        }
                    }
                }
                finally {
                    this.contractStatus.unlock();
                }
            }
            YP_Row yP_Row2 = list.get(0);
            object = new YP_ComplexGabarit(this.contractStatus);
            ((YP_ComplexGabarit)object).set(yP_Row2.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row2.getPrimaryKey());
            try {
                this.contractStatus.lock();
                switch (yP_TCD_DC_Transaction.getRequestType()) {
                    default: 
                }
                list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.contractStatusCached, new YP_ComplexGabarit[]{object});
                if (list == null || list.isEmpty()) {
                    this.contractStatusCached.add(yP_Row2);
                }
            }
            finally {
                this.contractStatus.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateContractStatus() ", exception);
            return -1;
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int updateUserStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, IdentificationLevelEnumeration identificationLevelEnumeration) {
        YP_Row yP_Row;
        java.util.Date date;
        if (UtilsYP.isMoroccoServer()) {
            return 1;
        }
        try {
            date = new Date(System.currentTimeMillis());
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.userStatus);
            yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DC_Transaction.userHandler.getUserIdentifier());
            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, (Date)date);
            List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.userStatusCached, yP_ComplexGabarit);
            if ((list == null || list.isEmpty()) && ((list = this.userStatus.getRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty())) {
                try {
                    this.userStatus.lock();
                    list = this.userStatus.getRowListSuchAs(yP_ComplexGabarit);
                    if (list == null || list.isEmpty()) {
                        YP_Row yP_Row2 = this.userStatus.getNewRow();
                        yP_Row2.set("idUser", yP_TCD_DC_Transaction.userHandler.getUserIdentifier());
                        yP_Row2.set("instanceNumber", UtilsYP.getInstanceNumber());
                        yP_Row2.set("date", (Date)date);
                        this.userStatus.addRow(yP_Row2);
                        list = this.userStatus.getRowListSuchAs(yP_ComplexGabarit);
                        if (list == null || list.isEmpty()) {
                            this.logger(2, "updateUserStatus() impossible to be here... ");
                            return -1;
                        }
                    }
                }
                finally {
                    this.userStatus.unlock();
                }
            }
            yP_Row = list.get(0);
            list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.userStatusCached, yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.userStatusCached.add(yP_Row);
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateUserStatus() " + exception);
            return -1;
        }
        try {
            try {
                date = UtilsYP.getNowSqlTimeStamp();
                this.userStatus.lock();
                switch (identificationLevelEnumeration) {
                    case PASSWORD: {
                        int n = (Integer)yP_Row.getFieldValueByName("nbPasswordConnection");
                        yP_Row.set("nbPasswordConnection", ++n);
                        yP_Row.set("lastPasswordConnection", (Timestamp)date);
                        return 1;
                    }
                    case TOKEN: {
                        int n = (Integer)yP_Row.getFieldValueByName("nbTokenConnection");
                        yP_Row.set("nbTokenConnection", ++n);
                        yP_Row.set("lastTokenConnection", (Timestamp)date);
                        return 1;
                    }
                    case PERMANENT_TOKEN: {
                        int n = (Integer)yP_Row.getFieldValueByName("nbPermanentTokenConnection");
                        yP_Row.set("nbPermanentTokenConnection", ++n);
                        yP_Row.set("lastPermanentTokenConnection", (Timestamp)date);
                        return 1;
                    }
                }
                int n = (Integer)yP_Row.getFieldValueByName("nbFailedConnection");
                yP_Row.set("nbFailedConnection", ++n);
                yP_Row.set("lastFailedConnection", (Timestamp)date);
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "updateUserStatus() " + exception);
                this.userStatus.unlock();
                return 1;
            }
        }
        finally {
            this.userStatus.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int updateTerminalStatus(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row) {
        YP_Row yP_Row2;
        List<YP_Row> list;
        Field[] fieldArray;
        java.util.Date date;
        if (UtilsYP.isMoroccoServer()) {
            return 1;
        }
        try {
            date = new Date(System.currentTimeMillis());
            fieldArray = new YP_ComplexGabarit(this.terminalStatus);
            fieldArray.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldValueByName("terminalManufacturerID"));
            fieldArray.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldValueByName("terminalSerialNumber"));
            fieldArray.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            fieldArray.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, (Date)date);
            list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.terminalStatusCached, new YP_ComplexGabarit[]{fieldArray});
            if ((list == null || list.isEmpty()) && ((list = this.terminalStatus.getRowListSuchAs(new YP_ComplexGabarit[]{fieldArray})) == null || list.isEmpty())) {
                try {
                    this.terminalStatus.lock();
                    list = this.terminalStatus.getRowListSuchAs(new YP_ComplexGabarit[]{fieldArray});
                    if (list == null || list.isEmpty()) {
                        YP_Row yP_Row3 = this.terminalStatus.getNewRow();
                        yP_Row3.set("terminalManufacturerID", yP_Row.getFieldValueByName("terminalManufacturerID"));
                        yP_Row3.set("terminalSerialNumber", yP_Row.getFieldValueByName("terminalSerialNumber"));
                        yP_Row3.set("instanceNumber", UtilsYP.getInstanceNumber());
                        yP_Row3.set("date", (Date)date);
                        this.terminalStatus.addRow(yP_Row3);
                        list = this.terminalStatus.getRowListSuchAs(new YP_ComplexGabarit[]{fieldArray});
                        if (list == null || list.isEmpty()) {
                            this.logger(2, "updateTerminalStatus() impossible to be here... ");
                            return -1;
                        }
                    }
                }
                finally {
                    this.terminalStatus.unlock();
                }
            }
            yP_Row2 = list.get(0);
            list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.terminalStatusCached, new YP_ComplexGabarit[]{fieldArray});
            if (list == null || list.isEmpty()) {
                this.terminalStatusCached.add(yP_Row2);
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateTerminalStatus() " + exception);
            return -1;
        }
        try {
            try {
                date = UtilsYP.getNowSqlTimeStamp();
                fieldArray = yP_Row2.getFieldList();
                list = new HashMap();
                Field[] fieldArray2 = fieldArray;
                int n = fieldArray.length;
                int n2 = 0;
                while (n2 < n) {
                    Field field = fieldArray2[n2];
                    Field field2 = yP_Row.getFieldByName(field.getName());
                    if (field2 != null) {
                        list.put(field, field2);
                    }
                    ++n2;
                }
                this.terminalStatus.lock();
                for (Map.Entry entry : list.entrySet()) {
                    yP_Row2.setFieldValue((Field)entry.getKey(), yP_Row.getFieldValue((Field)entry.getValue()));
                }
                yP_Row2.set("lastGMTTime", (Timestamp)date);
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "updateTerminalStatus() " + exception);
                this.terminalStatus.unlock();
                return 1;
            }
        }
        finally {
            this.terminalStatus.unlock();
        }
    }

    @Deprecated
    public List<YP_Row> getTerminalStatusListByMerchant(List<Long> list) {
        if (list == null) {
            return null;
        }
        if (list.isEmpty()) {
            return new ArrayList<YP_Row>();
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalStatus);
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)list);
        yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
        yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.MAX);
        yP_ComplexGabarit.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.GROUP);
        List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(this.terminalStatusCached, yP_ComplexGabarit);
        if (list2 == null || list2.isEmpty()) {
            list2 = this.terminalStatus.getRowListSuchAs(yP_ComplexGabarit);
        }
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getTerminalStatusListByMerchant() list null");
            }
            return null;
        }
        if (list2.isEmpty()) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getTerminalStatusListByMerchant() list empty");
            }
            return null;
        }
        return list2;
    }

    public List<YP_Row> getTerminalStatusList() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.terminalStatus);
        yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
        yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.MAX);
        yP_ComplexGabarit.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.GROUP);
        YP_TCD_DCC_Status.flushOneTable(this.terminalStatus, this.terminalStatusCached);
        List<YP_Row> list = this.terminalStatus.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null) {
            this.logger(2, "getTerminalStatusList() list null");
        } else if (list.isEmpty()) {
            this.logger(3, "getTerminalStatusList() list empty");
        }
        return list;
    }

    public int updateServiceStatus() {
        this.serviceStatus.lock();
        try {
            Date date = new Date(System.currentTimeMillis());
            int n = this.getSupervisor().getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object = this.getSupervisor().getChildByRank(n2);
                if (YP_Service.class.isInstance(yP_Object)) {
                    YP_Row yP_Row;
                    YP_Service yP_Service = (YP_Service)yP_Object;
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.serviceStatus);
                    yP_ComplexGabarit.set("serviceName", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Service.toString());
                    yP_ComplexGabarit.set("instanceID", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Service.getRankInFatherChildList());
                    yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
                    yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, date);
                    List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.serviceStatusCached, yP_ComplexGabarit);
                    boolean bl = false;
                    if (list == null || list.isEmpty()) {
                        yP_Row = this.serviceStatus.getNewRow();
                        yP_Row.set("serviceName", yP_Service.toString());
                        yP_Row.set("instanceID", yP_Service.getRankInFatherChildList());
                        yP_Row.set("instanceNumber", UtilsYP.getInstanceNumber());
                        yP_Row.set("date", date);
                        this.serviceStatus.addRow(yP_Row);
                        list = this.serviceStatus.getRowListSuchAs(yP_ComplexGabarit);
                        bl = true;
                    }
                    if (list == null || list.isEmpty()) {
                        this.logger(2, "updateServiceStatus() no row...");
                        return -1;
                    }
                    yP_Row = list.get(0);
                    if (bl) {
                        this.serviceStatusCached.add(yP_Row);
                    }
                    yP_Row.set("status", yP_Service.getObjectStatus());
                    yP_Row.set("preferredName", yP_Service.getPreferredName());
                    int n3 = yP_Service.getRunningChildNB();
                    yP_Row.set("currentChildNB", n3);
                    yP_Row.set("peakChildNB", yP_Service.getChildNB());
                    yP_Row.set("peakChildDayNB", yP_Service.getChildPeakByDay(date, n3));
                    yP_Row.set("maximumChildNB", yP_Service.getMaxChild());
                    yP_Row.set("lastTop", new Timestamp(yP_Service.getWatchDogTimer()));
                }
                ++n2;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "updateServiceStatus() " + exception);
            return -1;
        }
        finally {
            this.serviceStatus.unlock();
        }
    }

    public List<YP_Row> getServiceStatusList() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.serviceStatus);
        yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
        yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.MAX);
        return this.serviceStatus.getRowListSuchAs(yP_ComplexGabarit);
    }

    public int updatePluginStatus() {
        this.pluginStatus.lock();
        try {
            int n = this.getSupervisor().getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object = this.getSupervisor().getChildByRank(n2);
                if (yP_Object != null) {
                    String string = yP_Object.getVersion();
                    if (string == null || string.isEmpty()) {
                        this.logger(2, "updatepluginStatus() Plugin version is mandatory");
                    } else {
                        String string2 = yP_Object.toString();
                        if (string2 == null || string2.isEmpty()) {
                            this.logger(2, "updatepluginStatus() Plugin name is mandatory");
                        } else {
                            YP_Row yP_Row;
                            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pluginStatus);
                            yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                            yP_ComplexGabarit.set("version", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                            yP_ComplexGabarit.set("instanceID", YP_ComplexGabarit.OPERATOR.EQUAL, n2);
                            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
                            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, new Date(System.currentTimeMillis()));
                            List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.pluginStatusCached, yP_ComplexGabarit);
                            boolean bl = false;
                            if (list == null || list.isEmpty()) {
                                yP_Row = this.pluginStatus.getNewRow();
                                yP_Row.set("pluginName", string2);
                                yP_Row.set("version", string);
                                yP_Row.set("instanceID", n2);
                                yP_Row.set("instanceNumber", UtilsYP.getInstanceNumber());
                                yP_Row.set("date", new Date(System.currentTimeMillis()));
                                this.pluginStatus.addRow(yP_Row);
                                list = this.pluginStatus.getRowListSuchAs(yP_ComplexGabarit);
                                bl = true;
                            }
                            if (list == null || list.isEmpty()) {
                                this.logger(2, "updatepluginStatus() no row...");
                                return -1;
                            }
                            yP_Row = list.get(0);
                            if (bl) {
                                this.pluginStatusCached.add(yP_Row);
                            }
                            yP_Row.set("status", yP_Object.getObjectStatus());
                            yP_Row.set("preferredName", yP_Object.getPreferredName());
                            String string3 = yP_Object.getPropertyFileName();
                            if (string3 == null) {
                                yP_Row.set("propertiesFileName", "");
                            } else {
                                yP_Row.set("propertiesFileName", string3);
                            }
                            yP_Row.set("cptCreation", yP_Object.getCptCreation());
                            yP_Row.set("cptCurrent", yP_Object.getCptCurrent());
                            yP_Row.set("cptMax", yP_Object.getCptMax());
                            yP_Row.set("lastCreation", new Timestamp(yP_Object.getLastCreationTime()));
                        }
                    }
                }
                ++n2;
            }
            return 1;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.logger(2, "updatepluginStatus() " + exception);
            return -1;
        }
        finally {
            this.pluginStatus.unlock();
        }
    }

    public List<YP_Row> getPluginStatusList() {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.pluginStatus);
        yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
        yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.MAX);
        return this.pluginStatus.getRowListSuchAs(yP_ComplexGabarit);
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }

    public int updateCryptoStatus(YP_Row yP_Row, String string, boolean bl, long l, long l2) {
        if (UtilsYP.isMoroccoServer()) {
            return 1;
        }
        try {
            long l3 = System.currentTimeMillis();
            Timestamp timestamp = new Timestamp(l3);
            Date date = new Date(l3);
            String string2 = yP_Row.getPrimaryKeyName();
            long l4 = yP_Row.getPrimaryKey();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.cryptoModuleStatus);
            yP_ComplexGabarit.set(string2, YP_ComplexGabarit.OPERATOR.EQUAL, l4);
            yP_ComplexGabarit.set("instanceNumber", YP_ComplexGabarit.OPERATOR.EQUAL, UtilsYP.getInstanceNumber());
            yP_ComplexGabarit.set("date", YP_ComplexGabarit.OPERATOR.EQUAL, date);
            yP_ComplexGabarit.set("algoName", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            try {
                YP_Row yP_Row2;
                this.cryptoModuleStatus.lock();
                List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.cryptoModuleStatusCached, yP_ComplexGabarit);
                if (list != null && !list.isEmpty()) {
                    yP_Row2 = list.get(0);
                } else {
                    list = this.cryptoModuleStatus.getRowListSuchAs(yP_ComplexGabarit);
                    if (list != null && !list.isEmpty()) {
                        yP_Row2 = list.get(0);
                    } else {
                        yP_Row2 = this.cryptoModuleStatus.getNewRow();
                        yP_Row2.set(string2, l4);
                        yP_Row2.set("instanceNumber", UtilsYP.getInstanceNumber());
                        yP_Row2.set("date", date);
                        yP_Row2.set("algoName", string);
                        this.cryptoModuleStatus.addRow(yP_Row2, true);
                    }
                    this.cryptoModuleStatusCached.add(yP_Row2);
                }
                if (bl) {
                    int n;
                    long l5;
                    int n2;
                    int n3;
                    int n4 = (Integer)yP_Row2.getFieldValueByName("nbOK");
                    ++n4;
                    if (l >= 0L) {
                        n3 = (Integer)yP_Row2.getFieldValueByName("minConnectionTimeOK");
                        n2 = (Integer)yP_Row2.getFieldValueByName("maxConnectionTimeOK");
                        l5 = (Long)yP_Row2.getFieldValueByName("sumConnectionTimeOK");
                        if (n3 == 0 || l < (long)n3) {
                            yP_Row2.set("minConnectionTimeOK", l);
                        }
                        if (l > (long)n2) {
                            yP_Row2.set("maxConnectionTimeOK", l);
                        }
                        yP_Row2.set("sumConnectionTimeOK", l5 += l);
                        n = (int)(l5 / (long)n4);
                        yP_Row2.set("averageConnectionTimeOK", n);
                    }
                    if (l2 >= 0L) {
                        n3 = (Integer)yP_Row2.getFieldValueByName("minProcessingTimeOK");
                        n2 = (Integer)yP_Row2.getFieldValueByName("maxProcessingTimeOK");
                        l5 = (Long)yP_Row2.getFieldValueByName("sumProcessingTimeOK");
                        if (n3 == 0 || l2 < (long)n3) {
                            yP_Row2.set("minProcessingTimeOK", l2);
                        }
                        if (l2 > (long)n2) {
                            yP_Row2.set("maxProcessingTimeOK", l2);
                        }
                        yP_Row2.set("sumProcessingTimeOK", l5 += l2);
                        n = (int)(l5 / (long)n4);
                        yP_Row2.set("averageProcessingTimeOK", n);
                    }
                    yP_Row2.set("nbOK", n4);
                    yP_Row2.set("lastOKSystemLocalTime", timestamp);
                } else {
                    int n;
                    long l6;
                    int n5;
                    int n6;
                    int n7 = (Integer)yP_Row2.getFieldValueByName("nbKO");
                    ++n7;
                    if (l >= 0L) {
                        n6 = (Integer)yP_Row2.getFieldValueByName("minConnectionTimeKO");
                        n5 = (Integer)yP_Row2.getFieldValueByName("maxConnectionTimeKO");
                        l6 = (Long)yP_Row2.getFieldValueByName("sumConnectionTimeKO");
                        if (n6 == 0 || l < (long)n6) {
                            yP_Row2.set("minConnectionTimeKO", l);
                        }
                        if (l > (long)n5) {
                            yP_Row2.set("maxConnectionTimeKO", l);
                        }
                        yP_Row2.set("sumConnectionTimeKO", l6 += l);
                        n = (int)(l6 / (long)n7);
                        yP_Row2.set("averageConnectionTimeKO", n);
                    }
                    if (l2 >= 0L) {
                        n6 = (Integer)yP_Row2.getFieldValueByName("minProcessingTimeKO");
                        n5 = (Integer)yP_Row2.getFieldValueByName("maxProcessingTimeKO");
                        l6 = (Long)yP_Row2.getFieldValueByName("sumProcessingTimeKO");
                        if (n6 == 0 || l2 < (long)n6) {
                            yP_Row2.set("minProcessingTimeKO", l2);
                        }
                        if (l2 > (long)n5) {
                            yP_Row2.set("maxProcessingTimeKO", l2);
                        }
                        yP_Row2.set("sumProcessingTimeKO", l6 += l2);
                        n = (int)(l6 / (long)n7);
                        yP_Row2.set("averageProcessingTimeKO", n);
                    }
                    yP_Row2.set("nbKO", n7);
                    yP_Row2.set("lastKOSystemLocalTime", timestamp);
                }
            }
            finally {
                this.cryptoModuleStatus.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "updateCryptoStatus() " + exception);
        }
        return 1;
    }

    public static enum ConnectionStatusIssueEnumeration {
        UNKNOWN(0),
        CONNECT_TIMEOUT(1),
        CONNECT_BROKEN(2),
        CONNECT_PROTOCOL(3),
        RECEIVE_TIMEOUT(4),
        RECEIVE_BROKEN(5);

        public final int connectionStatusIssue;

        private ConnectionStatusIssueEnumeration(int n2) {
            this.connectionStatusIssue = n2;
        }

        public int getValue() {
            return this.connectionStatusIssue;
        }
    }
}

