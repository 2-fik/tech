/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Interface;

public interface YP_TCD_CRYPTO_DigestAlgo_Interface
extends YP_TCD_CRYPTO_Interface {
    public String digest(String var1, String var2) throws Exception;

    public String digest(String var1, byte[] var2) throws Exception;

    public int isDigestSupported(String var1);
}

