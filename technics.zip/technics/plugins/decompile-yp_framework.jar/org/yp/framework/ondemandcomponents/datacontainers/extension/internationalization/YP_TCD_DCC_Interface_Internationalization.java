/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCC_Interface_Internationalization
extends YP_TCD_DCB_Interface_Extension {
    public long getIdLabel(String var1);

    public YP_Row createNewLabel(String var1);

    public String getTranslatedText(long var1, String var3);

    public String getTranslatedText(String var1, String var2);

    public String getTranslatedText(Enum<?> var1, String var2);

    public YP_Row createTranslatedText(long var1, String var3, String var4);
}

