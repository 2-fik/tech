/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols;

import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.xml.jaxb.ypproperties.Property;

public interface YP_PROT_Interface_AutoStateMachine {
    public int setParameters(YP_TCD_DCC_Business var1, YP_TCD_DC_Transaction var2, YP_PROT_Interface_Prot.SERVICEDEMANDE var3, List<Property> var4, YP_PROT_Interface_Prot var5, YP_Object var6, Object ... var7);

    public void setServiceRequested(YP_PROT_Interface_Prot.SERVICEDEMANDE var1);

    public int send(String var1);

    public int shutdown();

    public String format();

    public int getError();

    public int resetError();

    public static enum AUTOSTATEMACHINE {
        autoPrepareRequest,
        autoConnect,
        autoProcess,
        autoAnalyseResponse,
        autoEnd;

    }
}

