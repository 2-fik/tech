/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.extendedapplication;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.applications.YP_Print;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;

public abstract class YP_ExtendedApplication_Print
extends YP_Print {
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE;

    public YP_ExtendedApplication_Print(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        super(yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
    }

    protected abstract String functionnalParameterReport();

    protected abstract String hardwareReport();

    protected abstract String incidentsReport();

    protected abstract String reconciliationReport(YP_Row var1);

    protected abstract String referenceParameterReport();

    protected abstract String remoteParameterizationReport();

    /*
     * Unable to fully structure code
     */
    @Override
    public String getTicket() {
        var1_1 = this.dataContainerTransaction.getSubRequestType();
        if (var1_1 == null) {
            this.dataContainer.logger(2, "getTicket() no sub request");
            return null;
        }
        switch (YP_ExtendedApplication_Print.$SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE()[var1_1.ordinal()]) {
            case 6: 
            case 7: {
                return this.summaryReport(var1_1);
            }
            case 4: {
                return this.functionnalParameterReport();
            }
            case 3: {
                var3_2 = YP_TCD_DCC_EFT_Business.getSessionNumber(this.dataContainerTransaction);
                if (var3_2 > 0) ** GOTO lbl27
                this.dataContainer.logger(4, "getTicket() No Session number. We use the last one");
                try {
                    var2_3 = this.dataContainer.getDataContainerBrand().getLastSession(this.dataContainer);
                    if (var2_3 == null) {
                        this.dataContainer.logger(3, "getTicket() let's assume that no TLC has never been done");
                        return "";
                    }
                    ** GOTO lbl34
                }
                catch (Exception var4_4) {
                    this.dataContainer.logger(2, "getTicket() unable to get the session " + var4_4);
                    return null;
                }
lbl27:
                // 1 sources

                try {
                    var2_3 = this.dataContainer.getDataContainerBrand().getSession(this.dataContainer, var3_2);
                }
                catch (Exception var4_5) {
                    this.dataContainer.logger(2, "getTicket() unable to get the session " + var4_5);
                    return null;
                }
lbl34:
                // 2 sources

                if (var2_3 == null) {
                    this.dataContainer.logger(2, "getTicket() unable to get the session");
                    return null;
                }
                return this.reconciliationReport(var2_3);
            }
            case 5: {
                return this.referenceParameterReport();
            }
            case 9: {
                return this.incidentsReport();
            }
            case 8: {
                return this.hardwareReport();
            }
            case 2: {
                return this.remoteParameterizationReport();
            }
        }
        return super.getTicket();
    }

    public String getTicket(String string, YP_Row yP_Row) {
        if (string.contentEquals("RemoteParameterizationReport")) {
            return this.remoteParameterizationReport();
        }
        if (string.contentEquals("ReconciliationReport")) {
            return this.reconciliationReport(yP_Row);
        }
        if (string.contentEquals("ReferenceParameterReport")) {
            return this.referenceParameterReport();
        }
        if (string.contentEquals("FunctionnalParameterReport")) {
            return this.functionnalParameterReport();
        }
        this.dataContainer.logger(2, "getTicket() unknown variable :" + string);
        return null;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE() {
        if ($SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE != null) {
            return $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE;
        }
        int[] nArray = new int[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.values().length];
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AdditionalReport.ordinal()] = 31;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Annulation.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ApduCommands.ordinal()] = 30;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Authorization.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AuthorizationAndCompletion.ordinal()] = 32;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Change.ordinal()] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.CloseCXAndShutdownWhenIdle.ordinal()] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion.ordinal()] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Credit.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Debit.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.DeleteCustomerData.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Diary.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ForcedShutdown.ordinal()] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.FunctionnalParameterReport.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.GetBrandList.ordinal()] = 33;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.GetCustomerData.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.HardwareReport.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.IncidentsReport.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.NonAboutie.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.None.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC.ordinal()] = 29;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ReconciliationReport.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ReferenceParameterReport.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Reload.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.RemoteParameterizationReport.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Reset.ordinal()] = 28;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ShutdownWhenIdle.ordinal()] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.SummaryReport.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalRiskManagement.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalSummaryReport.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$SUB_REQUEST_TYPE = nArray;
        return nArray;
    }
}

