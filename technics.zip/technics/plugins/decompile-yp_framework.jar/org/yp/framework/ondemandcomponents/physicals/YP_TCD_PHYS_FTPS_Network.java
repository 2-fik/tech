/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.net.ftp.FTPReply
 *  org.apache.commons.net.ftp.FTPSClient
 */
package org.yp.framework.ondemandcomponents.physicals;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URI;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Interface;
import org.yp.utils.UtilsYP;

public class YP_TCD_PHYS_FTPS_Network
extends YP_TCD_PHYS_Interface {
    private static final int DEFAULT_CONNECTION_TIMEOUT = 3499;
    private final String PROTOCOL = "TLSv1.2";
    private final String KEYSTOREALGORITHM = "SunX509";
    private final String TRUSTSTOREALGORITHM = "SunX509";
    private final String KEYSTORETYPE_JCEKS = "JCEKS";
    private final String TRUSTSTORETYPE_JCEKS = "JCEKS";
    private final String KEYSTORETYPE_JKS = "jks";
    private final String TRUSTSTORETYPE_JKS = "jks";
    private DataOutputStream outputStream = null;
    private BufferedReader inputStream = null;
    private SSLServerSocket serverSocket = null;
    private SSLSocketFactory sslsocketfactory = null;
    private String ipServer = null;
    private int portServer = 0;
    private String ressource = null;
    private int connectionTimeoutMS = 3499;
    private String trustStorePath = null;
    private String trustStorePasswd = null;
    private String keyStorePath = null;
    private String keyStorePasswd = null;
    private String keyAlias = null;
    private String enabledCipherSuites = null;
    private String enabledProtocols = null;
    private String authentificationNeeded = null;
    private String sessionTimeOut = null;
    private FTPSClient ftps = null;
    private String USER_ID;
    private String PASSWORD;
    private String REMOTE_LOCATION;

    public YP_TCD_PHYS_FTPS_Network(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    private SSLContext getSSLContext(String string, String string2, String string3, String string4, String string5) {
        block23: {
            TrustManagerFactory trustManagerFactory = null;
            KeyManagerFactory keyManagerFactory = null;
            TrustManager[] trustManagerArray = null;
            try {
                KeyStore keyStore;
                SSLContext sSLContext = SSLContext.getInstance("TLSv1.2");
                if (string != null && !string.isEmpty()) {
                    keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string), string2.toCharArray());
                    keyManagerFactory.init(keyStore, string2.toCharArray());
                }
                if (string4 != null && !string4.isEmpty()) {
                    trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                    keyStore = KeyStore.getInstance(string4.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
                    keyStore.load(new FileInputStream(String.valueOf(UtilsYP.getPath()) + string4), string5.toCharArray());
                    trustManagerFactory.init(keyStore);
                } else {
                    trustManagerArray = new X509TrustManager[]{new X509TrustManager(){

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                        }
                    }};
                }
                if (keyManagerFactory == null && trustManagerFactory == null) {
                    sSLContext.init(null, trustManagerArray, null);
                } else if (keyManagerFactory == null && trustManagerFactory != null) {
                    sSLContext.init(null, trustManagerFactory.getTrustManagers(), null);
                } else if (keyManagerFactory != null && trustManagerFactory == null) {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerArray, null);
                } else {
                    sSLContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
                }
                return sSLContext;
            }
            catch (FileNotFoundException fileNotFoundException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() FileNotFoundException:" + fileNotFoundException);
                }
            }
            catch (KeyStoreException keyStoreException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() KeyStoreException:" + keyStoreException);
                }
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() NoSuchAlgorithmException:" + noSuchAlgorithmException);
                }
            }
            catch (CertificateException certificateException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() CertificateException:" + certificateException);
                }
            }
            catch (IOException iOException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() IOException:" + iOException);
                }
            }
            catch (UnrecoverableKeyException unrecoverableKeyException) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getSSLContext() UnrecoverableKeyException:" + unrecoverableKeyException);
                }
            }
            catch (KeyManagementException keyManagementException) {
                if (this.getLogLevel() < 2) break block23;
                this.logger(2, "getSSLContext() KeyManagementException:" + keyManagementException);
            }
        }
        return null;
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int close() {
        if (this.serverSocket != null) {
            try {
                this.serverSocket.close();
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "close() Server HTTPS closed...");
                }
                this.serverSocket = null;
            }
            catch (IOException iOException) {
                this.logger(2, "close() Server HTTPS close failed  :" + iOException);
            }
        }
        try {
            if (this.outputStream != null) {
                this.outputStream.flush();
                this.outputStream.close();
                this.outputStream = null;
            }
            if (this.inputStream != null) {
                this.inputStream.close();
                this.inputStream = null;
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "close() Stream closed...");
            }
        }
        catch (IOException iOException) {
            this.logger(2, "close() HTTPS close error :" + iOException);
        }
        if (this.ftps != null) {
            try {
                this.ftps.disconnect();
            }
            catch (IOException iOException) {
                this.logger(5, "close() Client FTPS closed pb: " + iOException);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "close() Client FTPS closed...");
            }
            this.ftps = null;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return this.close();
    }

    @Override
    public String toString() {
        return "FTPSConnectionHandler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public boolean isKeystoreEmpty(String string) {
        FileInputStream fileInputStream;
        if (string == null || string.isEmpty()) {
            this.logger(4, "isKeystoreEmpty() keystore name missing");
            return true;
        }
        try {
            fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + string);
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileInputStream = null;
        }
        try {
            KeyStore keyStore = KeyStore.getInstance(string.toUpperCase().endsWith("JCEKS") ? "JCEKS" : "jks");
            keyStore.load(fileInputStream, this.keyStorePasswd.toCharArray());
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            return keyStore.size() <= 0;
        }
        catch (Exception exception) {
            this.logger(2, "isKeystoreEmpty() " + exception);
            return true;
        }
    }

    @Override
    public int openServer() {
        this.logger(2, "openServer() not done");
        return -1;
    }

    @Override
    public Object waitConnection() {
        this.logger(2, "waitConnection() not done");
        return null;
    }

    @Override
    public int recv(byte[] byArray, int n, int n2, int n3) {
        return 0;
    }

    @Override
    public int clean(int n) {
        return 1;
    }

    @Override
    public int available() {
        return 1;
    }

    @Override
    public int send(byte[] byArray, int n) {
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byArray);
            if (this.ftps.storeFile(this.REMOTE_LOCATION, (InputStream)byteArrayInputStream)) {
                return 1;
            }
        }
        catch (IOException iOException) {
            this.logger(2, "send :" + iOException);
            return -1;
        }
        this.logger(2, "send failed");
        return 0;
    }

    @Override
    public int closeHandle(Object object) {
        try {
            ((Socket)object).close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "closeHandle() close error..." + iOException);
            return -1;
        }
    }

    @Override
    public String getIP() {
        return null;
    }

    /*
     * Loose catch block
     */
    @Override
    public int openClient(Object ... objectArray) {
        boolean bl;
        block53: {
            block52: {
                URI uRI;
                String string;
                block51: {
                    block50: {
                        block49: {
                            if (objectArray != null) break block49;
                            this.logger(2, "openClient() missing parameters");
                            return -1;
                        }
                        if (objectArray.length == 1 && objectArray[0] instanceof YP_Row) {
                            if (this.ipServer == null) {
                                this.ipServer = ((YP_Row)objectArray[0]).getFieldStringValueByName("adresseIP");
                            }
                            if (this.portServer == 0) {
                                this.portServer = Integer.parseInt(((YP_Row)objectArray[0]).getFieldStringValueByName("port"));
                            }
                            if (this.ressource == null) {
                                this.ressource = ((YP_Row)objectArray[0]).getFieldStringValueByName("ressource");
                            }
                            if (this.connectionTimeoutMS == 3499) {
                                this.connectionTimeoutMS = (Integer)((YP_Row)objectArray[0]).getFieldValueByName("connectionTimeoutMS");
                            }
                            if (this.sslsocketfactory == null) {
                                if (this.trustStorePath == null) {
                                    this.trustStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePath");
                                }
                                if (this.trustStorePasswd == null) {
                                    this.trustStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("trustStorePasswd");
                                }
                                if (this.keyStorePath == null) {
                                    this.keyStorePath = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePath");
                                }
                                if (this.keyStorePasswd == null) {
                                    this.keyStorePasswd = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyStorePasswd");
                                }
                                if (this.keyAlias == null) {
                                    this.keyAlias = ((YP_Row)objectArray[0]).getFieldStringValueByName("keyAlias");
                                }
                                if (this.enabledCipherSuites == null) {
                                    this.enabledCipherSuites = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledCipherSuites");
                                    this.enabledCipherSuites = this.enabledCipherSuites.trim();
                                }
                                if (this.enabledProtocols == null) {
                                    this.enabledProtocols = ((YP_Row)objectArray[0]).getFieldStringValueByName("enabledProtocols");
                                    this.enabledProtocols = this.enabledProtocols.trim();
                                }
                                if (this.authentificationNeeded == null) {
                                    this.authentificationNeeded = ((YP_Row)objectArray[0]).getFieldStringValueByName("authentificationNeeded");
                                }
                                if (this.sessionTimeOut == null) {
                                    this.sessionTimeOut = ((YP_Row)objectArray[0]).getFieldStringValueByName("sessionTimeOut");
                                }
                                SSLContext sSLContext = this.getSSLContext(this.keyStorePath, this.keyStorePasswd, this.keyAlias, this.trustStorePath, this.trustStorePasswd);
                                this.sslsocketfactory = sSLContext.getSocketFactory();
                            }
                            this.USER_ID = ((YP_Row)objectArray[0]).getExtensionValueAsString("userID");
                            this.PASSWORD = ((YP_Row)objectArray[0]).getExtensionValueAsString("password");
                            this.REMOTE_LOCATION = ((YP_Row)objectArray[0]).getExtensionValueAsString("remoteLocation");
                        } else if (objectArray.length >= 3 && objectArray[0] instanceof String && objectArray[1] instanceof String && objectArray[2] instanceof String) {
                            if (this.ipServer == null) {
                                this.ipServer = (String)objectArray[0];
                            }
                            if (this.portServer == 0) {
                                this.portServer = Integer.parseInt((String)objectArray[1]);
                            }
                            if (objectArray.length > 3 && objectArray[3] instanceof Integer) {
                                this.connectionTimeoutMS = (Integer)objectArray[3];
                            }
                        }
                        if (this.ipServer != null) break block50;
                        this.logger(2, "openClient() missing parameters");
                        return -1;
                    }
                    if (this.USER_ID != null && this.PASSWORD != null && this.REMOTE_LOCATION != null) break block51;
                    this.logger(2, "openClient() missing parameters user/password/remoteLocation");
                    return -1;
                }
                boolean bl2 = false;
                bl = true;
                if (this.ressource != null && !this.ressource.isEmpty() && (string = (uRI = new URI("ftps://server" + this.ressource)).getQuery()) != null) {
                    String[] stringArray;
                    String[] stringArray2 = stringArray = string.split("&");
                    int n = stringArray.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String string2 = stringArray2[n2];
                        String[] stringArray3 = string2.split("=");
                        if (stringArray3.length == 2) {
                            if (stringArray3[0].contentEquals("isImplicit")) {
                                if (stringArray3[1].toLowerCase().contentEquals("true")) {
                                    bl2 = true;
                                }
                            } else if (stringArray3[0].contentEquals("isPassive") && stringArray3[1].toLowerCase().contentEquals("false")) {
                                bl = false;
                            }
                        }
                        ++n2;
                    }
                }
                this.ftps = this.sslsocketfactory != null ? new FTPSClient(this.enabledProtocols, bl2) : new FTPSClient(bl2);
                this.ftps.setConnectTimeout(this.connectionTimeoutMS);
                if (this.portServer > 0) {
                    this.ftps.connect(this.ipServer, this.portServer);
                } else {
                    this.ftps.connect(this.ipServer);
                }
                int n = this.ftps.getReplyCode();
                if (FTPReply.isPositiveCompletion((int)n)) break block52;
                this.ftps.disconnect();
                this.ftps = null;
                this.logger(2, "openClient() FTP server refused connection!!!");
                return -2;
                {
                    catch (Exception exception) {
                        this.logger(2, "openClient() failed : " + exception);
                        return -1;
                    }
                }
            }
            if (this.ftps.login(this.USER_ID, this.PASSWORD)) break block53;
            this.ftps.disconnect();
            this.ftps = null;
            this.logger(2, "openClient() FTP server refused userID/password!!!");
            return -3;
        }
        try {
            if (this.getLogLevel() >= 6) {
                this.logger(6, "openClient() login successful: " + this.USER_ID);
            }
            this.ftps.enterLocalPassiveMode();
            if (this.getLogLevel() >= 6) {
                this.logger(6, "openClient() enter passive mode");
            }
            this.ftps.execPBSZ(0L);
            if (this.getLogLevel() >= 6) {
                this.logger(6, "openClient() set PBSZ to 0");
            }
            this.ftps.execPROT("P");
            if (this.getLogLevel() >= 6) {
                this.logger(6, "openClient() set Prot to P");
            }
            this.ftps.setFileType(2);
            if (this.getLogLevel() >= 6) {
                this.logger(6, "openClient() binary mode");
            }
            if (!bl) {
                this.ftps.enterLocalActiveMode();
            }
        }
        catch (Exception exception) {
            this.logger(2, "openClient() " + this.ipServer + ":" + this.portServer + " " + exception);
            this.ipServer = null;
            if (this.ftps != null) {
                try {
                    this.ftps.disconnect();
                }
                catch (IOException iOException) {
                    this.logger(2, "openClient() pb disconnect: " + exception);
                }
            }
            this.ftps = null;
            this.portServer = 0;
            this.ressource = null;
            this.connectionTimeoutMS = 3499;
            this.sslsocketfactory = null;
            this.trustStorePath = null;
            this.trustStorePasswd = null;
            this.keyStorePath = null;
            this.keyStorePasswd = null;
            this.keyAlias = null;
            this.enabledCipherSuites = null;
            this.enabledProtocols = null;
            this.authentificationNeeded = null;
            return -1;
        }
        if (this.getLogLevel() >= 4) {
            this.printSocketInfo(this.ftps);
        }
        return this.initialize();
    }

    @Override
    public Socket createSocket(Object ... objectArray) {
        this.logger(2, "createSocket() for HTTPS !!!");
        return null;
    }

    private void printSocketInfo(FTPSClient fTPSClient) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("printFtpsConnectionInfo() ");
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("Fttps class: ");
            stringBuilder.append(fTPSClient.getClass());
            stringBuilder.append(UtilsYP.lineSeparator);
            stringBuilder.append("   Remote address = ");
            stringBuilder.append(UtilsYP.lineSeparator);
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {
            return;
        }
    }

    @Override
    public int setParameter(String string, String string2) {
        return 0;
    }
}

