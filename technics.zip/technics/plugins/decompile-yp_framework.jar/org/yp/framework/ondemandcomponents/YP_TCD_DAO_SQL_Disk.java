/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DAO_SQL_Disk
extends YP_TCD_DesignAccesObject {
    private static boolean firstReloadSuccessfull = false;

    public YP_TCD_DAO_SQL_Disk(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "DAO_Disk";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int reload() {
        this.logger(3, "reload() : meaningless on a DAO SQL Disk!");
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "reload() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int persist() {
        if (this.isItAModifiedDAO()) {
            try {
                this.getDataContainerContext().onSaveBefore(this, null, null);
            }
            catch (Exception exception) {
                this.logger(3, "persist() onSaveBefore" + exception);
            }
            this.setIsItAModifiedDAO(false);
            this.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            this.getDataContainerContext().updateTableStatus(this);
            try {
                this.getDataContainerContext().onSaveAfter(this, null, null);
            }
            catch (Exception exception) {
                this.logger(3, "persist() onSaveAfter" + exception);
            }
            try {
                this.getDataContainerContext().onChange(this);
            }
            catch (Exception exception) {
                this.logger(2, "persist() onChange" + exception);
            }
            this.notifyWatcher();
        }
        this.logger(3, "persist() : No persist on a DAO SQL. Use persist on the row !");
        return 0;
    }

    @Override
    public int persist(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        try {
            this.getDataContainerContext().onSaveBefore(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveBefore" + exception);
        }
        int n = yP_TCD_DAO_LOC_Table.generique.size();
        while (n > 0) {
            if (yP_TCD_DAO_LOC_Table.generique.get(n - 1).getModifierFlag() == 1) {
                yP_TCD_DAO_LOC_Table.generique.remove(n - 1);
            }
            --n;
        }
        if ((0x100 & this.getTableType()) == 0) {
            this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
            this.getDataBaseConnector().sql_Formater.sqlFillTable(yP_TCD_DAO_LOC_Table);
        }
        this.setIsItAModifiedDAO(false);
        for (YP_Row yP_Row : yP_TCD_DAO_LOC_Table.generique) {
            yP_Row.setModifierFlag(0);
        }
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int persistOptimized(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        try {
            this.getDataContainerContext().onSaveBefore(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveBefore" + exception);
        }
        int n = yP_TCD_DAO_LOC_Table.generique.size();
        while (n > 0) {
            if (yP_TCD_DAO_LOC_Table.generique.get(n - 1).getModifierFlag() == 1) {
                yP_TCD_DAO_LOC_Table.generique.remove(n - 1);
            }
            --n;
        }
        this.getDataBaseConnector().sql_Formater.sqlFillTable(yP_TCD_DAO_LOC_Table);
        this.setIsItAModifiedDAO(false);
        for (YP_Row yP_Row : yP_TCD_DAO_LOC_Table.generique) {
            yP_Row.setModifierFlag(0);
        }
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int updateBatch(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, Field[] fieldArray, Field[] fieldArray2) {
        try {
            this.getDataContainerContext().onSaveBefore(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveBefore" + exception);
        }
        int n = yP_TCD_DAO_LOC_Table.generique.size();
        while (n > 0) {
            if (yP_TCD_DAO_LOC_Table.generique.get(n - 1).getModifierFlag() == 1) {
                yP_TCD_DAO_LOC_Table.generique.remove(n - 1);
            }
            --n;
        }
        this.getDataBaseConnector().sql_Formater.sqlBatchUpdate(yP_TCD_DAO_LOC_Table, fieldArray, fieldArray2);
        this.setIsItAModifiedDAO(false);
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int deleteBatch(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, Field[] fieldArray) {
        try {
            this.getDataContainerContext().onSaveBefore(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveBefore" + exception);
        }
        this.getDataBaseConnector().sql_Formater.sqlBatchDelete(yP_TCD_DAO_LOC_Table, fieldArray);
        this.setIsItAModifiedDAO(false);
        yP_TCD_DAO_LOC_Table.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        this.getDataContainerContext().updateTableStatus(yP_TCD_DAO_LOC_Table);
        this.getDataContainerContext().retrieveTableStatus(this);
        try {
            this.getDataContainerContext().onSaveAfter(this, yP_TCD_DAO_LOC_Table.generique, null);
        }
        catch (Exception exception) {
            this.logger(3, "persist() onSaveAfter" + exception);
        }
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "persist() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int addRow(YP_Row yP_Row) throws Exception {
        YP_Row yP_Row2 = (YP_Row)yP_Row.clone();
        yP_Row2.setIsItAClonedRow(false);
        yP_Row2.setModifierFlag(3);
        yP_Row2.persist();
        return 1;
    }

    @Override
    public int addRow(YP_Row yP_Row, boolean bl) throws Exception {
        if (!bl) {
            return this.addRow(yP_Row);
        }
        yP_Row.setIsItAClonedRow(false);
        yP_Row.setModifierFlag(3);
        yP_Row.persist();
        return 1;
    }

    @Override
    public int updateRowSuchAs(YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRowSuchAs() is not allowed !!!");
        }
        return this.getDataBaseConnector().sql_Formater.updateRowSuchAs(this, yP_Row, n, yP_ComplexGabaritArray);
    }

    @Override
    public final int deleteRows(boolean bl) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRows() is not allowed !!!");
        }
        if (!bl) {
            this.logger(2, "deleteRows() persit mandatory for SQL type");
            return -1;
        }
        try {
            this.lock();
            int n = this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
            if (n >= 0) {
                this.setIsItAModifiedDAO(true);
                this.persist();
                return 1;
            }
            int n2 = n;
            return n2;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int deleteRowsSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRowsSuchAs() is not allowed !!!");
        }
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            return this.deleteRows(true);
        }
        try {
            this.lock();
            int n = this.getDataBaseConnector().sql_Formater.deleteRowsSuchAs((YP_TCD_DesignAccesObject)this, yP_ComplexGabaritArray);
            if (n <= 0) {
                int n2 = n;
                return n2;
            }
            this.setIsItAModifiedDAO(true);
            this.persist();
            int n3 = n;
            return n3;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public YP_Row getRowByPrimaryKey(long l) {
        return this.getDataBaseConnector().sql_Formater.sqlSelectRow(this, l);
    }

    @Override
    public List<YP_Row> getRowListSuchAs(int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        List<YP_Row> list;
        if (n == 0 && n2 == 1 && yP_ComplexGabaritArray != null && yP_ComplexGabaritArray.length == 1 && yP_ComplexGabaritArray[0].isOrdered) {
            List<YP_Row> list2 = this.getDataBaseConnector().sql_Formater.sqlSelectSuchAs(this, n, 2, yP_ComplexGabaritArray);
            if (list2 != null && list2.size() == 2) {
                list2.remove(1);
            }
            return list2;
        }
        do {
            if ((list = this.getDataBaseConnector().sql_Formater.sqlSelectSuchAs(this, n, n2, yP_ComplexGabaritArray)) != null) {
                firstReloadSuccessfull = true;
                continue;
            }
            if (firstReloadSuccessfull) continue;
            this.logger(2, "getRowListSuchAs() server won't go on as the DB seems offline");
            UtilsYP.sleep(5000);
        } while (!firstReloadSuccessfull);
        return list;
    }

    @Override
    public int getCountSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getDataBaseConnector().sql_Formater.sqlSelectCountSuchAs(this, yP_ComplexGabaritArray);
    }

    @Override
    public long getSumSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getDataBaseConnector().sql_Formater.sqlSelectSumSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public List<String> getDistinctStringValueList(String string) {
        return this.getDistinctStringValueListSuchAs(string, null);
    }

    @Override
    public List<String> getDistinctStringValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getDataBaseConnector().sql_Formater.getDistinctStringValueListSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public List<Object> getDistinctValueList(String string) {
        return this.getDistinctValueListSuchAs(string, null);
    }

    @Override
    public List<Object> getDistinctValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return this.getDataBaseConnector().sql_Formater.getDistinctValueListSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public int size() {
        return this.getDataBaseConnector().sql_Formater.sqlSelectCount(this);
    }

    @Override
    public YP_Row getRowAt(int n) {
        return this.getDataBaseConnector().sql_Formater.sqlSelectOne(this, n);
    }

    @Override
    protected YP_Row getRowAt(int n, boolean bl) {
        return this.getRowAt(n);
    }

    @Override
    protected boolean checkIfModificationsAllowed() {
        if (UtilsYP.isMoroccoServer() && UtilsYP.getInstanceRole() == 3) {
            return true;
        }
        return super.checkIfModificationsAllowed();
    }
}

