/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.YP_TCD_DCC_Interface_Internationalization;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects.DAO_Internationalization;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.designaccessobjects.DAO_InternationalizationLabel;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DCC_Internationalization
extends YP_OnDemandComponent
implements YP_TCD_DCC_Interface_Internationalization {
    private YP_TCD_DC_Context dataContainer;
    public YP_TCD_DesignAccesObject internationalization;
    public YP_TCD_DesignAccesObject internationalizationLabel;
    private final Map<String, String> i18Finder = new ConcurrentHashMap<String, String>();
    private YP_Object enumerationPlugin = null;

    public YP_TCD_DCC_Internationalization(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DC_Context) {
            this.dataContainer = (YP_TCD_DC_Context)yP_Object;
            this.dataContainer.addExtension(this);
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        try {
            this.internationalization = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_Internationalization.class, 0, 0, null);
            this.internationalizationLabel = (YP_TCD_DesignAccesObject)this.dataContainer.newPluginByName("DAO_Table", DAO_InternationalizationLabel.class, 0, 0, null);
        }
        catch (Exception exception) {
            this.logger(2, "YP_TCD_DCC_Internationalization", exception);
        }
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerExtension_Internationalization";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.50";
    }

    @Override
    public String get(String string) {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == this.internationalization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() internationalization");
            }
            this.i18Finder.clear();
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.internationalizationLabel) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onChange() internationalizationLabel");
            }
            this.i18Finder.clear();
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.internationalization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() internationalization");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.internationalizationLabel) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveBefore() internationalizationLabel");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (yP_TCD_DesignAccesObject == this.internationalization) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() internationalization");
            }
            return 1;
        }
        if (yP_TCD_DesignAccesObject == this.internationalizationLabel) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "onSaveAfter() internationalizationLabel");
            }
            return 1;
        }
        return 0;
    }

    @Override
    public String getTranslatedText(String string, String string2) {
        List<YP_Row> list;
        String string3;
        String string4;
        block7: {
            try {
                StringBuilder stringBuilder = new StringBuilder(32);
                stringBuilder.append(string);
                stringBuilder.append(' ');
                stringBuilder.append(string2);
                string4 = stringBuilder.toString();
                string3 = this.i18Finder.get(string4);
                if (string3 != null) {
                    return string3;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.internationalizationLabel);
                yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.internationalizationLabel.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null) break block7;
                this.logger(2, "getTranslatedText() key not found:" + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTranslatedText() ", exception);
                return null;
            }
        }
        if (list.isEmpty()) {
            this.logger(2, "getTranslatedText() key not found:" + string);
            list.add(this.createNewLabel(string));
        }
        if (list.size() > 1) {
            this.logger(3, "getTranslatedText() more than one key found for " + string + ". We take the first one");
        }
        DAO_InternationalizationLabel dAO_InternationalizationLabel = (DAO_InternationalizationLabel)list.get(0);
        long l = dAO_InternationalizationLabel.idLabel;
        string3 = this.getTranslatedText(l, string2);
        if (string3 == null) {
            this.createTranslatedText(l, string2, string);
            string3 = string;
        }
        this.i18Finder.put(string4, string3);
        return string3;
    }

    @Override
    public String getTranslatedText(long l, String string) {
        List<YP_Row> list;
        String string2;
        String string3;
        block10: {
            block9: {
                block8: {
                    try {
                        if (l > 0L) break block8;
                        this.logger(2, "getTranslatedText() 0 label given ");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "getTranslatedText() ", exception);
                        return null;
                    }
                }
                StringBuilder stringBuilder = new StringBuilder(32);
                stringBuilder.append(l);
                stringBuilder.append(' ');
                stringBuilder.append(string);
                string3 = stringBuilder.toString();
                string2 = this.i18Finder.get(string3);
                if (string2 != null) {
                    return string2;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.internationalization);
                yP_ComplexGabarit.set("idLabel", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                yP_ComplexGabarit.set("languageCode", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.internationalization.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null) break block9;
                this.logger(2, "getTranslatedText() translation not found:" + l + " " + string);
                return null;
            }
            if (!list.isEmpty()) break block10;
            YP_Row yP_Row = this.internationalizationLabel.getRowByPrimaryKey(l);
            if (yP_Row != null) {
                String string4 = yP_Row.getFieldStringValueByName("key");
                this.createTranslatedText(l, string, string4);
                return string4;
            }
            this.logger(2, "getTranslatedText() translation not found:" + l + " " + string);
            return null;
        }
        if (list.size() > 1) {
            this.logger(3, "getTranslatedText() more than one translation found:" + l + " " + string + ". We take the first one");
        }
        DAO_Internationalization dAO_Internationalization = (DAO_Internationalization)list.get(0);
        string2 = YP_Row.getStringValue(dAO_Internationalization.translatedText);
        this.i18Finder.put(string3, string2);
        return string2;
    }

    @Override
    public YP_Row createTranslatedText(long l, String string, String string2) {
        block3: {
            try {
                if (UtilsYP.getInstanceRole() == 1) break block3;
                this.logger(2, "createTranslatedText() can be done only on master");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "createTranslatedText() ", exception);
                return null;
            }
        }
        YP_Row yP_Row = this.internationalization.getNewRow();
        yP_Row.set("idLabel", l);
        yP_Row.set("translatedText", string2);
        yP_Row.set("languageCode", string);
        this.internationalization.addRow(yP_Row, true);
        this.internationalization.persist();
        return yP_Row;
    }

    @Override
    public long getIdLabel(String string) {
        List<YP_Row> list;
        block5: {
            try {
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.internationalizationLabel);
                yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                list = this.internationalizationLabel.getRowListSuchAs(yP_ComplexGabarit);
                if (list != null) break block5;
                this.logger(2, "getIdLabel() key not found:" + string);
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "getIdLabel() ", exception);
                return -1L;
            }
        }
        if (list.isEmpty()) {
            this.logger(2, "getIdLabel() key not found:" + string);
            return this.createNewLabel(string).getPrimaryKey();
        }
        if (list.size() > 1) {
            this.logger(3, "getIdLabel() more than one key found for " + string + ". We take the first one");
        }
        return list.get(0).getPrimaryKey();
    }

    @Override
    public YP_Row createNewLabel(String string) {
        try {
            YP_Row yP_Row = this.internationalizationLabel.getNewRow();
            yP_Row.set("key", string);
            this.internationalizationLabel.addRow(yP_Row, true);
            this.internationalizationLabel.persist();
            return yP_Row;
        }
        catch (Exception exception) {
            this.logger(2, "createNewLabel() ", exception);
            return null;
        }
    }

    @Override
    public String getTranslatedText(Enum<?> enum_, String string) {
        long l;
        block6: {
            block5: {
                try {
                    if (this.enumerationPlugin == null) {
                        this.enumerationPlugin = this.getPluginByName("Enumeration");
                    }
                    if (this.enumerationPlugin != null) break block5;
                    this.logger(2, "getTranslatedText() enumerationPlugin not found");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "getTranslatedText() ", exception);
                    return null;
                }
            }
            l = (Long)this.enumerationPlugin.dealRequest(this, "getIdLabel", enum_);
            if (l > 0L) break block6;
            this.logger(2, "getTranslatedText() idLabel not found " + enum_);
            return null;
        }
        return this.getTranslatedText(l, string);
    }
}

