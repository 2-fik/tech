/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import java.util.Calendar;
import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.utils.enums.EntryModeEnumeration;

public interface YP_PROT_Account {
    public long getCustomerIdentifier();

    public int setCustomerIdentifier(long var1);

    public String getCustomerMerchantIdentifier();

    public int setCustomerMerchantIdentifier(String var1);

    public String getCustomerName();

    public int setCustomerName(String var1);

    public String getCustomerMailAddress();

    public int setCustomerMailAddress(String var1);

    public String getCustomerIPAddress();

    public int setCustomerIPAddress(String var1);

    public String getCustomerPrimaryPhone();

    public int setCustomerPrimaryPhone(String var1);

    public int addOneMeanOfPaymentInstance();

    public long getMeanOfPaymentIdentifier();

    public int setMeanOfPaymentIdentifier(long var1);

    public String getAccountIdentifier();

    public int setAccountIdentifier(String var1);

    public String getMaskedAccountIdentifier();

    public int setMaskedAccountIdentifier(String var1);

    public String getAccountHolderName();

    public int setAccountHolderName(String var1);

    public String getAccountAlias();

    public int setAccountAlias(String var1);

    public Calendar getAccountExpirationDate();

    public int setAccountExpirationDate(Calendar var1);

    public Calendar getAccountEffectiveDate();

    public int setAccountEffectiveDate(Calendar var1);

    public String getAccountType();

    public int setAccountType(String var1);

    public EntryModeEnumeration getEntryMode();

    public void setEntryMode(EntryModeEnumeration var1);

    public String getCardType();

    public int setCardType(String var1);

    public String getCardCVV();

    public String getCardSequenceNumber();

    public int setCardSequenceNumber(String var1);

    public List<AccountHandler.ADF> getADFList(AccountHandler var1);

    public void setADFList(List<AccountHandler.ADF> var1);

    public String getTrack1();

    public String getTrack2();

    public String getTrack3();

    public String getSBANCountryCode();

    public int setSBANCountryCode(String var1);

    public String getSBANKey();

    public int setSBANKey(String var1);

    public String getSBANBIC();

    public int setSBANBIC(String var1);

    public String getSBANBBAN();

    public String getCMC7Track();
}

