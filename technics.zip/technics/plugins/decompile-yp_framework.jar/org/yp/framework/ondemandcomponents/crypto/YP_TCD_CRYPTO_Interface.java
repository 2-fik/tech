/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

public interface YP_TCD_CRYPTO_Interface {
    public int isCryptoSupported(String var1);
}

