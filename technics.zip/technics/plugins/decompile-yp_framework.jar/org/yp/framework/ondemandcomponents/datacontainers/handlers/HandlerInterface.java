/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import org.yp.designaccesobjects.YP_Row;

public interface HandlerInterface {
    public int readRequest();

    public int prepareResponse();

    public int load(YP_Row var1);

    public int persist();

    public int shutdown();

    public int clear();
}

