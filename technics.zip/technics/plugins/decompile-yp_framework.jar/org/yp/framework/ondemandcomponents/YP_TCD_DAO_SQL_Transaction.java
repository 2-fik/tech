/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.utils.UtilsYP;

public final class YP_TCD_DAO_SQL_Transaction
extends YP_TCD_DesignAccesObject {
    private final List<YP_Row> cacheTable = new ArrayList<YP_Row>();
    private boolean cacheActivated = false;
    private String slaveTableName;
    private String masterTableName;
    private String fullSlaveTableName;
    private String fullMasterTableName;

    public YP_TCD_DAO_SQL_Transaction(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if ((this.getTableType() & 0x20) != 0) {
            this.cacheActivated = true;
        }
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "DAO_Transaction";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public int shutdown() {
        if (this.isFlushNeeded()) {
            this.persist();
        }
        return super.shutdown();
    }

    @Override
    public int reload() {
        try {
            this.getDataContainerContext().onChange(this);
        }
        catch (Exception exception) {
            this.logger(2, "reload() onChange" + exception);
        }
        this.notifyWatcher();
        return 0;
    }

    @Override
    public int persist() {
        try {
            this.lock();
            this.flushIfNeeded(false, new YP_ComplexGabarit[0]);
            if (this.isItAModifiedDAO()) {
                try {
                    this.getDataContainerContext().onSaveBefore(this, null, null);
                }
                catch (Exception exception) {
                    this.logger(3, "persist() onSaveBefore" + exception);
                }
                this.setIsItAModifiedDAO(false);
                this.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                this.getDataContainerContext().updateTableStatus(this);
                try {
                    this.getDataContainerContext().onSaveAfter(this, null, null);
                }
                catch (Exception exception) {
                    this.logger(3, "persist() onSaveAfter" + exception);
                }
                try {
                    this.getDataContainerContext().onChange(this);
                }
                catch (Exception exception) {
                    this.logger(2, "persist() onChange" + exception);
                }
                this.notifyWatcher();
            }
            return 0;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int persist(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        this.logger(2, "persist() Transaction tables have no temporary table...");
        return -1;
    }

    @Override
    public int addRow(YP_Row yP_Row) throws Exception {
        return this.addRow(yP_Row, false);
    }

    @Override
    public int addRow(YP_Row yP_Row, boolean bl) throws Exception {
        try {
            this.lock();
            if (!bl) {
                yP_Row = (YP_Row)yP_Row.clone();
            }
            yP_Row.setIsItAClonedRow(false);
            yP_Row.setModifierFlag(3);
            if (this.cacheActivated) {
                this.cacheTable.add(yP_Row);
            } else {
                yP_Row.persist();
            }
            this.getDataContainerContext().logTransaction(yP_Row);
            return 1;
        }
        finally {
            this.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int flushIfNeeded(boolean bl, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        if (!this.isFlushNeeded()) {
            return 0;
        }
        if (bl) {
            this.lock();
        }
        boolean bl2 = false;
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            bl2 = true;
        }
        List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(this.cacheTable, yP_ComplexGabaritArray);
        if (list == null) {
            return -1;
        }
        if (list.isEmpty()) {
            return 0;
        }
        bl2 = true;
        return bl2 ? 1 : 0;
        finally {
            if (bl2) {
                YP_Row.persistList(this.cacheTable);
                this.cacheTable.clear();
                return 1;
            }
            return 0;
        }
    }

    @Override
    public int updateRowSuchAs(YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("updateRowSuchAs() is not allowed !!!");
        }
        try {
            this.lock();
            this.flushIfNeeded(false, yP_ComplexGabaritArray);
            int n2 = this.getDataBaseConnector().sql_Formater.updateRowSuchAs(this, yP_Row, n, yP_ComplexGabaritArray);
            return n2;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public final int deleteRows(boolean bl) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRows() is not allowed !!!");
        }
        if (!bl) {
            this.logger(2, "deleteRows() persit mandatory for SQL type");
            return -1;
        }
        if (UtilsYP.getInstanceRole() != 1) {
            this.logger(2, "deleteRows() forbidden on slave !!!");
            return -1;
        }
        try {
            this.lock();
            this.flushIfNeeded(false, new YP_ComplexGabarit[0]);
            int n = this.getDataBaseConnector().sql_Formater.sqlEmptyTable(this);
            if (n >= 0) {
                this.setIsItAModifiedDAO(true);
                this.persist();
                return 1;
            }
            int n2 = n;
            return n2;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public int deleteRowsSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) throws Exception {
        if (!this.checkIfModificationsAllowed()) {
            throw new Exception("deleteRowsSuchAs() is not allowed !!!");
        }
        if (UtilsYP.getInstanceRole() != 1) {
            this.logger(2, "deleteRowsSuchAs() forbidden on slave !!!");
            return -1;
        }
        if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
            return this.deleteRows(true);
        }
        try {
            this.lock();
            this.flushIfNeeded(false, yP_ComplexGabaritArray);
            int n = this.getDataBaseConnector().sql_Formater.deleteRowsSuchAs((YP_TCD_DesignAccesObject)this, yP_ComplexGabaritArray);
            if (n <= 0) {
                int n2 = n;
                return n2;
            }
            this.setIsItAModifiedDAO(true);
            this.persist();
            int n3 = n;
            return n3;
        }
        finally {
            this.unlock();
        }
    }

    @Override
    public YP_Row getRowByPrimaryKey(long l) {
        this.flushIfNeeded(true, new YP_ComplexGabarit[0]);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.sqlSelectRowForSlave(this, l);
        }
        return this.getDataBaseConnector().sql_Formater.sqlSelectRow(this, l);
    }

    @Override
    public List<YP_Row> getRowListSuchAs(int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.sqlSelectSuchAsForSlave(this, n, n2, yP_ComplexGabaritArray);
        }
        return this.getDataBaseConnector().sql_Formater.sqlSelectSuchAs(this, n, n2, yP_ComplexGabaritArray);
    }

    @Override
    public int getCountSuchAs(YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.sqlSelectCountSuchAsForSlave(this, yP_ComplexGabaritArray);
        }
        return this.getDataBaseConnector().sql_Formater.sqlSelectCountSuchAs(this, yP_ComplexGabaritArray);
    }

    @Override
    public long getSumSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.sqlSelectSumSuchAsForSlave(this, string, 0, 0, yP_ComplexGabaritArray);
        }
        return this.getDataBaseConnector().sql_Formater.sqlSelectSumSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public List<String> getDistinctStringValueList(String string) {
        return this.getDistinctStringValueListSuchAs(string, null);
    }

    @Override
    public List<String> getDistinctStringValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.getDistinctStringValueListSuchAsForSlave(this, string, 0, 0, yP_ComplexGabaritArray);
        }
        return this.getDataBaseConnector().sql_Formater.getDistinctStringValueListSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public List<Object> getDistinctValueList(String string) {
        return this.getDistinctValueListSuchAs(string, null);
    }

    @Override
    public List<Object> getDistinctValueListSuchAs(String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        if (UtilsYP.getInstanceRole() == 2) {
            return this.getDataBaseConnector().sql_Formater.getDistinctValueListSuchAsForSlave(this, string, 0, 0, yP_ComplexGabaritArray);
        }
        return this.getDataBaseConnector().sql_Formater.getDistinctValueListSuchAs(this, string, 0, 0, yP_ComplexGabaritArray);
    }

    @Override
    public int size() {
        if (UtilsYP.getInstanceRole() == 2) {
            this.logger(2, "size() forbidden on slave !!!");
            return -1;
        }
        this.flushIfNeeded(true, new YP_ComplexGabarit[0]);
        return this.getDataBaseConnector().sql_Formater.sqlSelectCount(this);
    }

    @Override
    public YP_Row getRowAt(int n) {
        if (UtilsYP.getInstanceRole() == 2) {
            this.logger(2, "getRowAt() forbidden on slave !!!");
            return null;
        }
        this.flushIfNeeded(true, new YP_ComplexGabarit[0]);
        return this.getDataBaseConnector().sql_Formater.sqlSelectOne(this, n);
    }

    @Override
    protected YP_Row getRowAt(int n, boolean bl) {
        return this.getRowAt(n);
    }

    public final String getSlaveTableName() {
        if (this.slaveTableName != null) {
            return this.slaveTableName;
        }
        this.slaveTableName = this.getRowTemplate().getSlaveTableName();
        return this.slaveTableName;
    }

    public final String getFullSlaveTableName() {
        if (this.fullSlaveTableName != null) {
            return this.fullSlaveTableName;
        }
        this.fullSlaveTableName = this.getDataBaseConnector().sql_Formater.sqlFullSlaveTableName(this);
        return this.fullSlaveTableName;
    }

    public final String getMasterTableName() {
        if (this.masterTableName != null) {
            return this.masterTableName;
        }
        this.masterTableName = this.getRowTemplate().getMasterTableName();
        return this.masterTableName;
    }

    public final String getFullMasterTableName() {
        if (this.fullMasterTableName != null) {
            return this.fullMasterTableName;
        }
        this.fullMasterTableName = this.getDataBaseConnector().sql_Formater.sqlFullMasterTableName(this);
        return this.fullMasterTableName;
    }

    public int archiveRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, boolean bl, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        if (UtilsYP.getInstanceRole() != 1) {
            this.logger(2, "archiveRowsSuchAs() forbidden on slave !!!");
            return -1;
        }
        this.flushIfNeeded(true, yP_ComplexGabaritArray);
        int n = this.getDataBaseConnector().sql_Formater.archiveRowsSuchAs(this, yP_TCD_DesignAccesObject, yP_ComplexGabaritArray);
        if (n <= 0) {
            this.logger(3, "archiveRowsSuchAs() no trs uploaded to archive...");
            return 0;
        }
        this.setIsItAModifiedDAO(true);
        if (bl) {
            try {
                this.getDataBaseConnector().sql_Formater.deleteRowsSuchAs((YP_TCD_DesignAccesObject)this, yP_ComplexGabaritArray);
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "archiveRowsSuchAs() " + exception);
                }
                return -1;
            }
        }
        this.persist();
        return n;
    }

    public int archiveRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, boolean bl, String string) {
        if (UtilsYP.getInstanceRole() != 1) {
            this.logger(2, "archiveRowsSuchAs() forbidden on slave !!!");
            return -1;
        }
        this.flushIfNeeded(true, new YP_ComplexGabarit[0]);
        int n = this.getDataBaseConnector().sql_Formater.archiveRowsSuchAs(this, yP_TCD_DesignAccesObject, string);
        if (n <= 0) {
            this.logger(3, "archiveRowsSuchAs() no trs uploaded to archive...");
            return 0;
        }
        this.setIsItAModifiedDAO(true);
        if (bl) {
            try {
                this.getDataBaseConnector().sql_Formater.deleteRowsSuchAs((YP_TCD_DesignAccesObject)this, string);
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "archiveRowsSuchAs() " + exception);
                }
                return -1;
            }
        }
        this.persist();
        return n;
    }

    public int synchronizeOneTransaction(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, long l) {
        if (UtilsYP.getInstanceRole() != 1) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "synchronizeOneTransaction() forbidden on slave !!!");
            }
            return -1;
        }
        if ((this.getTableType() & 0x40) != 0) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "synchronizeOneTransaction() don't synchronize GAME_TEST_TABLE");
            }
            return 0;
        }
        YP_Row yP_Row = this.getDataBaseConnector().sql_Formater.selectFromWhere(yP_TCD_DataBaseConnector, this, this.getFullSlaveTableName(), this.getPrimaryKeyName(), l);
        if (yP_Row == null) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "synchronizeOneTransaction() no transaction... ");
            }
            return 0;
        }
        yP_Row.setIsItAClonedRow(false);
        yP_Row.setModifierFlag(3);
        try {
            yP_Row.persist();
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "synchronizeOneTransaction()" + exception);
            }
            return -1;
        }
        long[] lArray = new long[]{l};
        this.getDataBaseConnector().sql_Formater.deleteFromWhere(this, yP_TCD_DataBaseConnector, this.getFullSlaveTableName(), this.getPrimaryKeyName(), lArray);
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int synchronizeAllTransaction(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) {
        if (UtilsYP.getInstanceRole() != 1) {
            this.logger(2, "synchronizeAllTransaction() forbidden on slave !!!");
            return -1;
        }
        if ((this.getTableType() & 0x40) != 0) {
            this.logger(4, "synchronizeOneTransaction() don't synchronize GAME_TEST_TABLE");
            return 0;
        }
        try {
            boolean bl = false;
            block2: while (true) {
                List<YP_Row> list;
                if ((list = this.getDataBaseConnector().sql_Formater.selectFrom(yP_TCD_DataBaseConnector, this, this.getFullSlaveTableName(), 0, 1000)) == null || list.isEmpty()) {
                    if (!bl) {
                        this.logger(4, "synchronizeAllTransaction() no transaction...");
                        return 0;
                    }
                    this.logger(4, "synchronizeAllTransaction() no more transaction...");
                    return 1;
                }
                bl = true;
                long[] lArray = new long[list.size()];
                int n = 0;
                Iterator<YP_Row> iterator = list.iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        this.getDataBaseConnector().sql_Formater.deleteFromWhere(this, yP_TCD_DataBaseConnector, this.getFullSlaveTableName(), this.getPrimaryKeyName(), lArray);
                        if (list != null) continue block2;
                        return 1;
                    }
                    YP_Row yP_Row = iterator.next();
                    yP_Row.setIsItAClonedRow(false);
                    yP_Row.setModifierFlag(3);
                    yP_Row.persist();
                    lArray[n++] = yP_Row.getPrimaryKey();
                }
                break;
            }
        }
        catch (Exception exception) {
            if (this.getLogLevel() < 2) return -1;
            this.logger(2, "synchronizeAllTransaction() ???:" + exception);
            return -1;
        }
    }

    public static boolean synchronizationNeeded(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, List<YP_TCD_DAO_SQL_Transaction> list) throws Exception {
        if (UtilsYP.getInstanceRole() != 1) {
            yP_TCD_DataBaseConnector.logger(2, "synchronizationNeeded() forbidden on slave !!!");
            return false;
        }
        try {
            return !yP_TCD_DataBaseConnector.sql_Formater.isSlaveTransactionEmpty(yP_TCD_DataBaseConnector, list);
        }
        catch (Exception exception) {
            try {
                if (yP_TCD_DataBaseConnector.getLogLevel() >= 2) {
                    yP_TCD_DataBaseConnector.logger(2, "synchronizationNeeded() ???:" + exception);
                }
                throw exception;
            }
            catch (Exception exception2) {
                if (yP_TCD_DataBaseConnector.getLogLevel() >= 2) {
                    yP_TCD_DataBaseConnector.logger(2, "synchronizationNeeded() ???:" + exception2);
                }
                throw exception2;
            }
        }
    }

    public static final List<YP_Row> getRowListSuchAsForTransaction(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject, 0, 0, yP_ComplexGabaritArray);
    }

    public static final List<YP_Row> getRowListSuchAsForTransaction(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        yP_TCD_DAO_SQL_Transaction.flushIfNeeded(true, yP_ComplexGabaritArray);
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().sql_Formater.sqlSelectSuchAsForTransaction(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject, n, n2, yP_ComplexGabaritArray);
    }

    @Deprecated
    public static final List<YP_Row> getRowListSuchAsForTransaction(YP_TCD_DCC_Brand yP_TCD_DCC_Brand, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DCC_Brand, n, n2, null, yP_ComplexGabaritArray);
    }

    /*
     * WARNING - void declaration
     */
    public static final List<YP_Row> getRowListSuchAsForTransaction(YP_TCD_DCC_Brand yP_TCD_DCC_Brand, int n, int n2, List<YP_Gabarit> list, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        Object object;
        Object object2;
        YP_TCD_DCC_Business object4 = null;
        if (UtilsYP.getTableStructureMode() != 1) {
            if (yP_TCD_DCC_Brand != null) {
                yP_TCD_DCC_Brand.logger(2, "getRowListSuchAsForTransaction() not adequat table strcuture !!!");
            }
            return null;
        }
        HashMap<String, YP_TCD_DCC_Business> object5 = new HashMap<String, YP_TCD_DCC_Business>();
        for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                if (yP_TCD_DCC_Business.transaction == null) continue;
                yP_TCD_DCC_Business.transaction.flushIfNeeded(true, yP_ComplexGabaritArray);
                object5.put(yP_TCD_DCC_Business.transaction.getFullTableName(), yP_TCD_DCC_Business);
            }
        }
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        if (object5.isEmpty()) {
            if (yP_TCD_DCC_Brand != null) {
                yP_TCD_DCC_Brand.logger(3, "getRowListSuchAsForTransaction() no DAO !!!");
            }
            return arrayList;
        }
        if (list != null && !list.isEmpty()) {
            HashMap<String, YP_TCD_DCC_Business> hashMap = new HashMap<String, YP_TCD_DCC_Business>();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : object5.values()) {
                boolean bl = true;
                for (YP_Gabarit yP_Gabarit : list) {
                    object2 = yP_TCD_DCC_Business.transaction.getFieldByName(yP_Gabarit.fieldName);
                    if (object2 == null) {
                        bl = false;
                        break;
                    }
                    object4 = yP_TCD_DCC_Business;
                }
                if (!bl) continue;
                hashMap.put(yP_TCD_DCC_Business.transaction.getFullTableName(), yP_TCD_DCC_Business);
            }
            if (!hashMap.isEmpty()) {
                object5 = hashMap;
                for (YP_Gabarit yP_Gabarit : list) {
                    Field field = object4.transaction.getFieldByName(yP_Gabarit.fieldName);
                    if (field == null) continue;
                    YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                    int n3 = yP_ComplexGabaritArray.length;
                    int n4 = 0;
                    while (n4 < n3) {
                        YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n4];
                        if (yP_Gabarit.objectTosearch != null && yP_Gabarit.objectTosearch instanceof String) {
                            yP_ComplexGabarit.set(field, yP_Gabarit.operator, (String)yP_Gabarit.objectTosearch);
                        }
                        ++n4;
                    }
                }
            }
        }
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : object5.values()) {
            object = yP_TCD_DCC_Business.transaction.getDataBaseConnector().sql_Formater.sqlSelectSuchAsForTransaction(yP_TCD_DCC_Business.transaction, yP_TCD_DCC_Business.transactionArchive, n, n2, yP_ComplexGabaritArray);
            if (object == null) continue;
            arrayList.addAll((Collection<YP_Row>)object);
        }
        if (object4 != null) {
            for (YP_Gabarit yP_Gabarit : list) {
                void var12_32;
                object = object4.transaction.getFieldByName(yP_Gabarit.fieldName);
                if (object == null) continue;
                object2 = yP_ComplexGabaritArray;
                int n5 = yP_ComplexGabaritArray.length;
                boolean bl = false;
                while (var12_32 < n5) {
                    YP_ComplexGabarit yP_ComplexGabarit = object2[var12_32];
                    if (yP_Gabarit.objectTosearch != null && yP_Gabarit.objectTosearch instanceof String) {
                        yP_ComplexGabarit.reset(yP_Gabarit.fieldName, null, null);
                    }
                    ++var12_32;
                }
            }
        }
        return arrayList;
    }

    public boolean isFlushNeeded() {
        if (!this.cacheActivated) {
            return false;
        }
        return this.cacheTable != null && !this.cacheTable.isEmpty();
    }

    public int getNbTransactionsToFlush() {
        if (!this.cacheActivated) {
            return 0;
        }
        if (this.cacheTable == null) {
            return 0;
        }
        return this.cacheTable.size();
    }

    @Override
    protected boolean checkIfModificationsAllowed() {
        if (UtilsYP.getInstanceRole() == 3) {
            return true;
        }
        return super.checkIfModificationsAllowed();
    }
}

