/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.currency.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_STD_Currency
extends YP_Row {
    @PrimaryKey
    public long idCurrency = 0L;
    public int currencyNumericalCode = 0;
    public byte[] currencyAlphabeticalCode = new byte[3];
    public int currencyFraction = 0;
    public int currencyActivationCode = 0;
    public byte[] currencyName = new byte[50];
    public int conversionRatePrintingActivationCode = 0;
    public int counterValuePrintingActivationCode = 0;
    public long currencyMinAmount = 0L;
    public long currencyMaxAmount = 0L;
    public long currencyDoubleAuthentificationAmount = 0L;
    public byte[] externalReference = new byte[30];
}

