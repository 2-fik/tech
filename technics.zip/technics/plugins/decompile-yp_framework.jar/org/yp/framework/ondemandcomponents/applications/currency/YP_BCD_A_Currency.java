/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.currency;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public class YP_BCD_A_Currency
extends YP_Application {
    public YP_BCD_A_Currency(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public int applicationSelection(YP_Object yP_Object, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        return YP_BCD_A_Currency.applicationSelectionStatic(yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
    }

    public static int applicationSelectionStatic(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (yP_TCD_DCC_Business != null) {
            yP_TCD_DCC_Business.logger(3, "applicationSelection() not a real application !!!");
        }
        return 0;
    }

    @Override
    public YP_TCD_DCC_Business getNewDataContainer(YP_Service yP_Service) {
        return (YP_TCD_DCC_Business)yP_Service.newPluginByName("DataContainerCurrency", this);
    }

    @Override
    public String toString() {
        return "Currency";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        this.logger(2, "dealRequest() empty... ");
        return null;
    }
}

