/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.token;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.applications.token.designaccesobjects.DAO_TokenTable;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.utils.UtilsYP;

public final class YP_BCD_A_DCC_Token
extends YP_TCD_DCC_Business {
    protected final AtomicInteger nbTokenFoundInCache = new AtomicInteger(0);
    protected final AtomicInteger nbTokenRequested = new AtomicInteger(0);
    protected final AtomicInteger nbValueFoundInCache = new AtomicInteger(0);
    protected final AtomicInteger nbValueRequested = new AtomicInteger(0);
    private static final long TWO_YEARS = 63072000000L;
    private static int NB_TOKEN_TABLE = 256;
    private final boolean cacheActivated = true;
    private final YP_TCD_DAO_SQL_Transaction[] tokenTableList = new YP_TCD_DAO_SQL_Transaction[NB_TOKEN_TABLE];
    private static final Date emptyEndOfValidity = new Date(0L);
    private static final int MAX_TOKEN_IN_CACHE = 1000000;
    private final Map<String, Long> tokenCacheMap = Collections.synchronizedMap(new LinkedHashMap<String, Long>(){
        private static final long serialVersionUID = 3553548312394890476L;

        @Override
        protected boolean removeEldestEntry(Map.Entry entry) {
            return this.size() > 1000000;
        }
    });
    private final Map<Long, String> valueCacheMap = Collections.synchronizedMap(new LinkedHashMap<Long, String>(){
        private static final long serialVersionUID = 901338685872837725L;

        @Override
        protected boolean removeEldestEntry(Map.Entry entry) {
            return this.size() > 1000000;
        }
    });
    private static final int NB_SECURED_WRITE = 2;

    public YP_BCD_A_DCC_Token(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        this.setContainerBusinessType(this.getContainerBusinessType() | 1);
        super.initialize();
        try {
            int n = 16;
            n |= 0x20;
            int n2 = 0;
            while (n2 < NB_TOKEN_TABLE) {
                this.tokenTableList[n2] = (YP_TCD_DAO_SQL_Transaction)this.newPluginByName("DAO_Transaction", DAO_TokenTable.class, 0, n, String.format("%04d", n2));
                ++n2;
            }
        }
        catch (Exception exception) {
            this.logger(2, "initialise()" + exception);
        }
        return 1;
    }

    private String getHash(YP_Object yP_Object, String string) throws Exception {
        String string2;
        byte[] byArray = new byte[32];
        int n = 0;
        while (n < 32) {
            byArray[n] = (byte)string.charAt(n % string.length());
            ++n;
        }
        try {
            string2 = (String)yP_Object.dealRequest(this, "sha256Hash", new Object[]{byArray});
        }
        catch (Exception exception) {
            this.logger(2, "getHash() " + exception);
            throw exception;
        }
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "getHash() pb during hash");
            throw new Exception("pb during hash");
        }
        return string2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public long getToken(String var1_1, boolean[] var2_2, Timestamp var3_3) {
        try {
            this.nbTokenRequested.incrementAndGet();
            var4_4 = this.tokenCacheMap.get(var1_1);
            if (var4_4 != null) {
                this.nbTokenFoundInCache.incrementAndGet();
                var2_2[0] = false;
                return var4_4;
            }
            ** GOTO lbl15
        }
        catch (Exception var4_5) {
            try {
                block24: {
                    block22: {
                        this.logger(2, "getToken() Exception ignored to avoid regression " + var4_5);
lbl15:
                        // 2 sources

                        if (var1_1.length() > 32) {
                            this.logger(2, "getToken() max size is 32");
                            return -1L;
                        }
                        var4_6 = var3_3.getTime();
                        if (var4_6 < System.currentTimeMillis()) {
                            this.logger(3, "getToken() Expiration date :" + var3_3 + " is in the past");
                            var4_6 = System.currentTimeMillis();
                        }
                        var6_8 = new Date(var4_6 + 63072000000L);
                        var7_9 = this.getPluginByName("CryptoManager");
                        var8_10 = this.getHash(var7_9, var1_1);
                        if (YP_BCD_A_DCC_Token.NB_TOKEN_TABLE == 16) {
                            var9_11 = UtilsYP.intValue(var8_10.charAt(0));
                        }
                        if ((var9_11 = YP_BCD_A_DCC_Token.NB_TOKEN_TABLE == 256 ? (UtilsYP.intValue(var8_10.charAt(0)) << 4) + UtilsYP.intValue(var8_10.charAt(1)) : 1) < 0) {
                            var9_11 *= -1;
                        }
                        var10_12 = new YP_ComplexGabarit(this.tokenTableList[var9_11]);
                        var11_13 = 1L;
                        var13_14 = 0L;
                        var15_15 = var8_10.length();
                        var16_16 = 0;
                        while (true) {
                            if (var16_16 >= 7 || var15_15 - var16_16 <= 0) {
                                var10_12.set("hashedIndex", YP_ComplexGabarit.OPERATOR.EQUAL, var13_14);
                                var10_12.set("hashedValue", YP_ComplexGabarit.OPERATOR.EQUAL, var8_10);
                                var10_12.set("endOfValidity", YP_ComplexGabarit.OPERATOR.IN, new Object[]{YP_BCD_A_DCC_Token.emptyEndOfValidity, var6_8});
                                var18_18 = this.tokenTableList[var9_11].getRowListSuchAs(new YP_ComplexGabarit[]{var10_12});
                                if (var18_18 == null || var18_18.isEmpty()) {
                                    var19_19 = this.tokenTableList[var9_11].getNewRow();
                                    var19_19.set("hashedIndex", var13_14);
                                    var19_19.set("hashedValue", var8_10);
                                    var20_21 = null;
                                    try {
                                        var20_21 = (String[])var7_9.dealRequest(this, "encryptToken", new Object[]{var1_1});
                                        break;
                                    }
                                    catch (Exception var21_22) {
                                        this.sysLog(2, "getToken() failed Exception during encryptToken() " + var21_22);
                                        return -1L;
                                    }
                                }
                                break block22;
                            }
                            var13_14 += (long)UtilsYP.intValue(var8_10.charAt(var16_16)) * var11_13;
                            var11_13 *= 16L;
                            ++var16_16;
                        }
                        if (var20_21 == null || var20_21.length != 3) {
                            this.sysLog(2, "getToken() failed encryptToken() is invalid");
                            return -1L;
                        }
                        var19_19.set("cryptedValue", var20_21[0]);
                        var19_19.set("keyIdentifier", var20_21[1]);
                        var16_17 = this.tokenTableList[var9_11].getNextPrimaryKey();
                        var19_19.set("idToken", var16_17 += (long)var9_11 << 48);
                        var19_19.set("endOfValidity", var6_8);
                        try {
                            this.tokenTableList[var9_11].lock();
                            this.tokenTableList[var9_11].addRow(var19_19, true);
                        }
                        finally {
                            this.tokenTableList[var9_11].unlock();
                        }
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "getToken() token added :" + var16_17);
                        }
                        this.logger(-2, var19_19.serialize());
                        var2_2[0] = true;
                        break block24;
                    }
                    this.checkForOldToken(var18_18, var6_8);
                    if (var18_18.size() > 1) {
                        this.logger(3, "getToken() " + var18_18.size() + " tokens found for " + var13_14 + " " + var8_10);
                    }
                    var2_2[0] = false;
                    var16_17 = var18_18.get(0).getPrimaryKey();
                }
                try {
                    this.tokenCacheMap.put(var1_1, var16_17);
                    this.valueCacheMap.put(var16_17, var1_1);
                    return var16_17;
                }
                catch (Exception var19_20) {
                    this.logger(2, "getToken() Exception ignored to avoid regression " + var19_20);
                }
                return var16_17;
            }
            catch (Exception var4_7) {
                this.sysLog(2, "getToken() failed: " + var4_7);
                return -1L;
            }
        }
    }

    private void checkForOldToken(List<YP_Row> list, Date date) {
        try {
            for (YP_Row yP_Row : list) {
                Date date2 = (Date)yP_Row.getFieldValueByName("endOfValidity");
                if (date2.getTime() != 0L) continue;
                this.logger(3, "checkForOldToken() Old token found, we have to update it");
                yP_Row.set("endOfValidity", date);
                yP_Row.persist();
            }
        }
        catch (Exception exception) {
            this.logger(3, "checkForOldToken() " + exception);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getClearValue(long var1_1) {
        try {
            this.nbValueRequested.incrementAndGet();
            var3_2 = this.valueCacheMap.get(var1_1);
            if (var3_2 != null) {
                this.nbValueFoundInCache.incrementAndGet();
                return var3_2;
            }
            ** GOTO lbl14
        }
        catch (Exception var3_3) {
            try {
                this.logger(2, "getClearValue() Exception ignored to avoid regression " + var3_3);
lbl14:
                // 2 sources

                if (YP_BCD_A_DCC_Token.NB_TOKEN_TABLE == 16) {
                    var3_4 = ((var1_1 & 0xF0000000000000L) >> 52) * 1L;
                }
                if (YP_BCD_A_DCC_Token.NB_TOKEN_TABLE == 256) {
                    var3_5 = ((var1_1 & 0xF0000000000000L) >> 52) * 16L;
                    var3_5 += ((var1_1 & 0xF000000000000L) >> 48) * 1L;
                } else {
                    var3_5 = 1L;
                }
                var5_7 = new YP_ComplexGabarit(this.tokenTableList[(int)var3_5]);
                var5_7.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, var1_1);
                var6_8 = null;
                var6_8 = this.tokenTableList[(int)var3_5].getRowListSuchAs(new YP_ComplexGabarit[]{var5_7});
                if (var6_8 == null || var6_8.isEmpty()) {
                    this.logger(2, "getClearValue() token not found:" + var1_1);
                    return null;
                }
                if (var6_8.size() > 1) {
                    this.logger(2, "getClearValue() too many tokens found for " + var1_1);
                }
                var7_9 = var6_8.get(0);
                var8_10 = var7_9.getFieldStringValueByName("cryptedValue");
                var9_11 = var7_9.getFieldStringValueByName("keyIdentifier");
                try {
                    var10_12 = (String)this.getPluginByName("CryptoManager").dealRequest(this, "decryptToken", new Object[]{var9_11, var8_10});
                    if (var10_12 == null) return null;
                    try {
                        this.tokenCacheMap.put(var10_12, var1_1);
                        this.valueCacheMap.put(var1_1, var10_12);
                        return var10_12;
                    }
                    catch (Exception var11_14) {
                        this.logger(2, "getClearValue() Exception ignored to avoid regression " + var11_14);
                    }
                    return var10_12;
                }
                catch (Exception var10_13) {
                    this.logger(2, "getClearValue()" + var10_13);
                    return null;
                }
            }
            catch (Exception var3_6) {
                this.logger(2, "getClearValue() " + var3_6);
                return null;
            }
        }
    }

    private int secureDeleteExpiredToken(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, List<Long> list) {
        try {
            YP_Row yP_Row = yP_TCD_DAO_SQL_Transaction.getNewRow();
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
            yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.IN, (Object)list);
            Random random = new Random();
            byte[] byArray = new byte[64];
            int n = 0;
            while (n < 2) {
                random.nextBytes(byArray);
                yP_Row.set("cryptedValue", UtilsYP.devHexa(byArray));
                yP_TCD_DAO_SQL_Transaction.updateRowSuchAs(yP_Row, yP_ComplexGabarit);
                ++n;
            }
            n = yP_TCD_DAO_SQL_Transaction.deleteRowsSuchAs(yP_ComplexGabarit);
            if (n > 0) {
                this.logger(4, "secureDeleteExpiredToken()  " + n + " tokens deleted from " + yP_TCD_DAO_SQL_Transaction.getTableName());
            } else if (n != 0) {
                this.logger(2, "secureDeleteExpiredToken() " + n);
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "secureDeleteExpiredToken() " + exception);
            return -1;
        }
    }

    public int deleteExpiredToken() {
        int n = 0;
        Date date = new Date(System.currentTimeMillis());
        try {
            YP_TCD_DAO_SQL_Transaction[] yP_TCD_DAO_SQL_TransactionArray = this.tokenTableList;
            int n2 = this.tokenTableList.length;
            int n3 = 0;
            while (n3 < n2) {
                int n4;
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction = yP_TCD_DAO_SQL_TransactionArray[n3];
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
                yP_ComplexGabarit.set("endOfValidity", YP_ComplexGabarit.OPERATOR.LESS, date);
                yP_ComplexGabarit.set("endOfValidity", YP_ComplexGabarit.OPERATOR.DIFFERENT, emptyEndOfValidity);
                List<Object> list = yP_TCD_DAO_SQL_Transaction.getDistinctValueListSuchAs("idToken", yP_ComplexGabarit);
                if (list != null && !list.isEmpty() && (n4 = this.secureDeleteExpiredToken(yP_TCD_DAO_SQL_Transaction, list)) > 0) {
                    n += n4;
                }
                ++n3;
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "deleteExpiredToken() " + exception);
            return -1;
        }
    }

    private int transcryptOneToken(YP_Object yP_Object, YP_Row yP_Row) {
        String[] stringArray;
        block7: {
            block6: {
                String string;
                block5: {
                    try {
                        long l = (Long)yP_Row.getFieldValueByName("idToken");
                        string = this.getClearValue(l);
                        String string2 = this.getHash(yP_Object, string);
                        String string3 = yP_Row.getFieldStringValueByName("hashedValue");
                        if (!string3.contentEquals(string2)) break block5;
                        this.sysLog(2, "transcryptOneToken() hashed value are not corrects !");
                        return -1;
                    }
                    catch (Exception exception) {
                        this.sysLog(2, "transcryptOneToken() " + exception);
                        return -1;
                    }
                }
                stringArray = (String[])yP_Object.dealRequest(this, "encryptToken", string);
                if (stringArray != null && stringArray.length == 3) break block6;
                this.sysLog(2, "transcryptOneToken() failed encryptToken() is invalid");
                return -1;
            }
            String string = yP_Row.getFieldStringValueByName("keyIdentifier");
            if (!string.contentEquals(stringArray[1])) break block7;
            this.sysLog(2, "transcryptOneToken() the keys are the same !!! " + string);
            return -1;
        }
        yP_Row.set("keyIdentifier", stringArray[1]);
        yP_Row.set("cryptedValue", stringArray[0]);
        yP_Row.setIsItAClonedRow(false);
        yP_Row.persist();
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int transcryptToken() {
        int n = 0;
        try {
            YP_Object yP_Object = this.getPluginByName("CryptoManager");
            String string = (String)yP_Object.dealRequest(this, "getTokenKeyLabel", new Object[0]);
            YP_TCD_DAO_SQL_Transaction[] yP_TCD_DAO_SQL_TransactionArray = this.tokenTableList;
            int n2 = this.tokenTableList.length;
            int n3 = 0;
            while (true) {
                List<YP_Row> list;
                if (n3 >= n2) {
                    return n;
                }
                YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction = yP_TCD_DAO_SQL_TransactionArray[n3];
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_SQL_Transaction);
                yP_ComplexGabarit.set("keyIdentifier", YP_ComplexGabarit.OPERATOR.DIFFERENT, string);
                do {
                    if ((list = yP_TCD_DAO_SQL_Transaction.getRowListSuchAs(0, 1000, yP_ComplexGabarit)) == null || list.isEmpty()) continue;
                    this.logger(3, "transcryptToken() token(s) to transcrypt found");
                    UtilsYP.sleep(100);
                    for (YP_Row yP_Row : list) {
                        int n4 = this.transcryptOneToken(yP_Object, yP_Row);
                        if (n4 != 1) {
                            this.sysLog(2, "transcryptToken() safer to stop " + n + " " + n4);
                            return -1;
                        }
                        ++n;
                    }
                } while (list != null && !list.isEmpty());
                ++n3;
            }
        }
        catch (Exception exception) {
            this.sysLog(2, "transcryptToken() " + n + " " + exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getToken")) {
                if (!(objectArray != null && objectArray.length == 3 && objectArray[0] instanceof String && objectArray[1] instanceof boolean[] && objectArray[2] instanceof Timestamp)) {
                    this.logger(2, "dealRequest() bad parameters for getToken");
                    return null;
                }
                String string2 = (String)objectArray[0];
                if (string2 == null || string2.length() == 0) {
                    this.logger(2, "dealRequest() bad parameters for getToken the PAN must be set");
                    return null;
                }
                boolean[] blArray = (boolean[])objectArray[1];
                if (blArray != null && blArray.length != 0) {
                    Timestamp timestamp = (Timestamp)objectArray[2];
                    if (timestamp != null) return this.getToken(string2, blArray, timestamp);
                    this.logger(2, "dealRequest() bad parameters for getToken ");
                    return null;
                }
                this.logger(2, "dealRequest() bad parameters for getToken ");
                return null;
            }
            if (string.contentEquals("getClearValue")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof Long) {
                    long l = (Long)objectArray[0];
                    if (l != 0L) return this.getClearValue(l);
                    this.logger(2, "dealRequest() bad parameters for getClearValue 0 must not be used...");
                    return null;
                }
                this.logger(2, "dealRequest() bad parameters for getClearValue");
                return null;
            }
            if (string.contentEquals("deleteExpiredToken")) {
                return this.deleteExpiredToken();
            }
            if (string.contentEquals("transcryptToken")) {
                return 0;
            }
            if (!string.contentEquals("printStats")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            try {
                this.logger(4, "printStats() " + Integer.toString(this.nbTokenRequested.get()) + " " + Integer.toString(this.nbTokenFoundInCache.get()) + "  " + Integer.toString(this.nbValueRequested.get()) + " " + Integer.toString(this.nbValueFoundInCache.get()));
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "printStats() " + exception);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    @Override
    public final int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public final String toString() {
        return "DataContainerToken";
    }

    @Override
    public final String getVersion() {
        return "V1.4.0.14";
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        return 0;
    }
}

