/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.emv.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.EntryModeEnumeration;

public class DAO_EMV_AID
extends YP_Row {
    @PrimaryKey
    public long idEMV_AID = 0L;
    public byte[] rid = new byte[10];
    public byte[] pix = new byte[22];
    public EntryModeEnumeration entryMode;
    public Boolean partialSelectionAllowed;
    public int priority = 0;
    public Boolean forcingAllowed;
    public int terminalApplicationVersionNumber = 0;
    public byte[] externalReference = new byte[30];
}

