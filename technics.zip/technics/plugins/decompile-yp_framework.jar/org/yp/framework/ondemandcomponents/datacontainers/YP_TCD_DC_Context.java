/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.token.designaccesobjects.DAO_TokenTable;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;
import org.yp.framework.ondemandcomponents.datacontainers.extension.sessionpersister.YP_TCD_DCB_Interface_SessionPersister;
import org.yp.framework.ondemandcomponents.datacontainers.extension.sms.YP_TCD_DCB_Interface_SMS;
import org.yp.framework.ondemandcomponents.datacontainers.extension.trspersister.YP_TCD_DCB_Interface_TRSPersister;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_TCD_DC_Context
extends YP_TCD_DataContainer {
    private List<YP_TCD_DCB_Interface_Extension> extensionList;
    private YP_TCD_DCC_Technique dataContainerTechnique;
    protected Set<YP_TCD_DCB_Interface_TRSPersister> persisterSet;
    private Set<YP_TCD_DCB_Interface_SessionPersister> sessionPersisters;
    private Set<YP_TCD_DCB_Interface_SMS> smsPlugins;
    protected Map<String, NullableValue> storedParameters;

    public int addExtension(YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension) {
        if (this.extensionList == null) {
            this.extensionList = new ArrayList<YP_TCD_DCB_Interface_Extension>();
        }
        this.extensionList.add(yP_TCD_DCB_Interface_Extension);
        return 1;
    }

    public YP_TCD_DC_Context(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.dataBaseConnector == null) {
            return 0;
        }
        return 1;
    }

    @Override
    public int shutdown() {
        if (this.extensionList != null) {
            this.extensionList.clear();
            this.extensionList = null;
        }
        if (this.persisterSet != null) {
            this.persisterSet.clear();
            this.persisterSet = null;
        }
        if (this.sessionPersisters != null) {
            this.sessionPersisters.clear();
            this.sessionPersisters = null;
        }
        if (this.smsPlugins != null) {
            this.smsPlugins.clear();
            this.smsPlugins = null;
        }
        this.dataContainerTechnique = null;
        return super.shutdown();
    }

    @Override
    public String get(String string) {
        if (this.extensionList != null) {
            for (YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension : this.extensionList) {
                String string2 = yP_TCD_DCB_Interface_Extension.get(string);
                if (string2 == null) continue;
                return string2;
            }
        }
        this.logger(2, "get() has not been found for :" + string);
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (this.extensionList != null) {
            for (YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension : this.extensionList) {
                if (yP_TCD_DCB_Interface_Extension.onChange(yP_TCD_DesignAccesObject) != 1) continue;
                return 1;
            }
        }
        return 0;
    }

    public abstract List<Action> getActionList(String var1, YP_Row var2);

    public abstract int executeAction(YP_Transaction var1, String var2, YP_Row var3, Action var4);

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (this.extensionList != null) {
            for (YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension : this.extensionList) {
                yP_TCD_DCB_Interface_Extension.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
            }
        }
        return 0;
    }

    @Override
    public int onSaveAfter(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        if (this.extensionList != null) {
            for (YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension : this.extensionList) {
                yP_TCD_DCB_Interface_Extension.onSaveAfter(yP_TCD_DesignAccesObject, list, yP_Row);
            }
        }
        return 0;
    }

    public YP_TCD_DCB_Interface_Extension getExtensionByType(Class<?> clazz) {
        if (this.extensionList != null) {
            for (YP_TCD_DCB_Interface_Extension yP_TCD_DCB_Interface_Extension : this.extensionList) {
                if (!clazz.isAssignableFrom(yP_TCD_DCB_Interface_Extension.getClass())) continue;
                return yP_TCD_DCB_Interface_Extension;
            }
        }
        return null;
    }

    private void getDataContainerTechniqueIfNeeded() {
        if (this.dataContainerTechnique == null) {
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
        if (this.dataContainerTechnique == null && this.getLogLevel() >= 2) {
            this.logger(2, "getDataContainerTechniqueIfNeeded() ");
        }
    }

    public int retrieveTableStatus(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            this.getDataContainerTechniqueIfNeeded();
            return this.dataContainerTechnique.retrieveTableStatus(yP_TCD_DesignAccesObject);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "retrieveTableStatus() " + exception);
            }
            return -1;
        }
    }

    public int updateTableStatus(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            this.getDataContainerTechniqueIfNeeded();
            return this.dataContainerTechnique.updateTableStatus(yP_TCD_DesignAccesObject);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "updateTableStatus() " + exception);
            }
            return -1;
        }
    }

    public final String getTableVersion(int n) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByNumber(n);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableVersion()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableVersion();
    }

    public final String getTableVersion(String string) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByName(string);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableVersion()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableVersion();
    }

    public final String getTableVersion(int n, String string) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByNumberAndVersion(n, string);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableVersion()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableVersion();
    }

    public final String getTableCksum(int n) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByNumber(n);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableCksum()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableCksum();
    }

    public final String getTableCksum(String string) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByName(string);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableCksum()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableCksum();
    }

    public final String getTableCksum(int n, String string) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByNumberAndVersion(n, string);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "getTableCksum()...");
            return null;
        }
        return yP_TCD_DesignAccesObject.getTableCksum();
    }

    public final int synchronizeTransactions() {
        try {
            this.flushCachedTables();
            return (Integer)this.getPluginByName("DataContainerManager").dealRequest(this, "synchronizeSlaveTransactions", this);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "synchronizeTransactions() " + exception);
            }
            return -1;
        }
    }

    public void logTransaction(YP_Row yP_Row) {
        block3: {
            try {
                if (yP_Row instanceof DAO_TokenTable) {
                    return;
                }
                this.logger(-1, yP_Row.serialize());
            }
            catch (Exception exception) {
                if (this.getLogLevel() < 2) break block3;
                this.logger(2, "logTransaction() ???:" + exception);
            }
        }
    }

    public Set<String> getParameters(Object ... objectArray) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        return yP_TCD_DCC_Technique.getParameters(this, objectArray);
    }

    public String getParameter(String string, boolean bl) {
        String string2;
        try {
            if (bl && this.storedParameters != null && this.storedParameters.containsKey(string)) {
                NullableValue nullableValue = this.storedParameters.get(string);
                return nullableValue == null ? null : nullableValue.get();
            }
        }
        catch (Exception exception) {
            this.logger(2, "getParameter() " + exception);
        }
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        Set<String> set = yP_TCD_DCC_Technique.getParameters(this, string);
        if (set == null) {
            string2 = null;
        } else if (set.isEmpty()) {
            string2 = null;
        } else {
            if (set.size() > 1) {
                this.logger(2, "getParameter() too many for " + string);
            }
            string2 = set.iterator().next();
        }
        try {
            if (bl) {
                if (this.storedParameters == null) {
                    this.storedParameters = new ConcurrentHashMap<String, NullableValue>();
                }
                this.storedParameters.put(string, new NullableValue(string2));
            }
        }
        catch (Exception exception) {
            this.logger(2, "getParameter()  ", exception);
        }
        return string2;
    }

    @Deprecated
    public String getParameter(String string) {
        return this.getParameter(string, false);
    }

    public boolean setParameter(String string, String string2) {
        try {
            if (this.storedParameters != null && this.storedParameters.containsKey(string)) {
                this.storedParameters.put(string, new NullableValue(string2));
            }
        }
        catch (Exception exception) {
            this.logger(2, "setParameter() " + exception);
        }
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        return yP_TCD_DCC_Technique.setParameter(this, string, string2);
    }

    public Map<String, Set<String>> getParametersMap(Object ... objectArray) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        return yP_TCD_DCC_Technique.getParametersMap(this, objectArray);
    }

    public boolean addSessionPersister(YP_TCD_DCB_Interface_SessionPersister yP_TCD_DCB_Interface_SessionPersister) {
        if (this.sessionPersisters == null) {
            this.sessionPersisters = new HashSet<YP_TCD_DCB_Interface_SessionPersister>();
        }
        return this.sessionPersisters.add(yP_TCD_DCB_Interface_SessionPersister);
    }

    protected Set<YP_TCD_DCB_Interface_SessionPersister> getSessionPersisters() {
        return this.sessionPersisters;
    }

    public boolean addSMSPlugin(YP_TCD_DCB_Interface_SMS yP_TCD_DCB_Interface_SMS) {
        if (this.smsPlugins == null) {
            this.smsPlugins = new HashSet<YP_TCD_DCB_Interface_SMS>();
        }
        return this.smsPlugins.add(yP_TCD_DCB_Interface_SMS);
    }

    protected Set<YP_TCD_DCB_Interface_SMS> getSMSPlugins() {
        return this.smsPlugins;
    }

    public List<Property> getPropertiesParameters() {
        return null;
    }

    public boolean addPersister(YP_TCD_DCB_Interface_TRSPersister yP_TCD_DCB_Interface_TRSPersister) {
        if (this.persisterSet == null) {
            this.persisterSet = new HashSet<YP_TCD_DCB_Interface_TRSPersister>();
        }
        return this.persisterSet.add(yP_TCD_DCB_Interface_TRSPersister);
    }

    public static class Action {
        public static final String STANDARD_NO_CONFIRMATION_FORM = "StandardNoConfirmationForm";
        public static final String STANDARD_CONFIRMATION_FORM = "StandardConfirmationForm";
        public static final String STANDARD_CHECKBOX_LIST_FORM = "StandardCheckboxListForm";
        public static final String STANDARD_GENERIC_FORM = "StandardGenericForm";
        public static final String LOAD_FILE_FORM = "LoadFileForm";
        public static final String PARAMETERS_EDITION_FORM = "ParametersEditionForm";
        public static final String DEFAULT_ACTION = "DefaultAction";
        public List<Property> propertiesList;
        public String id;
        public String label;
        public String applicationIdentifier;
        public String formName;
    }

    public class NullableValue {
        private final String value;

        public NullableValue(String string) {
            this.value = string;
        }

        public String get() {
            return this.value;
        }
    }
}

