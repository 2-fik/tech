/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto;

import java.util.List;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Interface;
import org.yp.xml.jaxb.ypproperties.Property;

public interface YP_TCD_CRYPTO_MacAlgo_Interface
extends YP_TCD_CRYPTO_Interface {
    public String computeMAC(String var1, List<Property> var2, byte[] var3, Object ... var4) throws Exception;

    public boolean verifyMAC(String var1, List<Property> var2, byte[] var3, String var4, Object ... var5) throws Exception;

    public int isMACSupported(String var1);
}

