/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.soft;

import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_DigestAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_RandomNumberGenerator_Interface;
import org.yp.framework.ondemandcomponents.crypto.soft.YP_TCD_CRYPTO_Soft_CipherSym;
import org.yp.framework.ondemandcomponents.crypto.soft.YP_TCD_CRYPTO_Soft_DigestAlgo;
import org.yp.framework.ondemandcomponents.crypto.soft.YP_TCD_CRYPTO_Soft_RandomNumberGenerator;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCD_CRYPTO_Soft
extends YP_TCD_CRYPTO_Module
implements YP_TCD_CRYPTO_CipherSym_Interface,
YP_TCD_CRYPTO_DigestAlgo_Interface,
YP_TCD_CRYPTO_RandomNumberGenerator_Interface {
    public YP_TCD_CRYPTO_Soft(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        boolean cfr_ignored_0 = yP_Object instanceof YP_TS_GlobalProcessManager;
    }

    @Override
    public int initialize() {
        this.myCipherSym = new YP_TCD_CRYPTO_Soft_CipherSym(this);
        this.myDigest = new YP_TCD_CRYPTO_Soft_DigestAlgo(this);
        this.myRandomData = new YP_TCD_CRYPTO_Soft_RandomNumberGenerator(this);
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        return super.shutdown();
    }

    @Override
    public String toString() {
        return "CryptoSoft";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.1";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :" + exception);
            return null;
        }
    }

    @Override
    public String decrypt(String string, String string2, List<Property> list, String string3, String string4, String string5) throws Exception {
        return this.myCipherSym.decrypt(string, string2, list, string3, string4, string5);
    }

    @Override
    public byte[] decrypt(byte[] byArray, String string, List<Property> list, String string2, String string3, String string4) throws Exception {
        return this.myCipherSym.decrypt(byArray, string, list, string2, string3, string4);
    }

    @Override
    public String decryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        return this.myCipherSym.decryptToken(string, list, string2, string3);
    }

    @Override
    public String[] encrypt(String string, String string2, List<Property> list, String string3, String string4) throws Exception {
        return this.myCipherSym.encrypt(string, string2, list, string3, string4);
    }

    @Override
    public byte[][] encrypt(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.myCipherSym.encrypt(byArray, string, list, string2, string3);
    }

    @Override
    public String[] encryptToken(String string, List<Property> list, String string2, String string3) throws Exception {
        return this.myCipherSym.encryptToken(string, list, string2, string3);
    }

    @Override
    public int addKey(String string, List<Property> list, byte[] byArray, String string2) throws Exception {
        return this.myCipherSym.addKey(string, list, byArray, string2);
    }

    @Override
    public String digest(String string, String string2) throws Exception {
        return this.myDigest.digest(string, string2);
    }

    @Override
    public String digest(String string, byte[] byArray) throws Exception {
        return this.myDigest.digest(string, byArray);
    }

    @Override
    public byte[] generateRandomBytes(int n, String string, byte[] byArray, int n2) throws Exception {
        return this.myRandomData.generateRandomBytes(n, string, byArray, n2);
    }

    @Override
    public byte[] generateSeed(int n, String string, int n2) throws Exception {
        return this.myRandomData.generateSeed(n, string, n2);
    }

    @Override
    public void setSeed(int n, String string, byte[] byArray) throws Exception {
        this.myRandomData.setSeed(n, string, byArray);
    }

    @Override
    public int isCryptoSupported(String string) {
        int n = this.isCipherSymSupported(string);
        if (n >= 1) {
            return n;
        }
        n = this.isDigestSupported(string);
        if (n >= 1) {
            return n;
        }
        n = this.isRandomSupported(string);
        if (n >= 1) {
            return n;
        }
        return 0;
    }

    @Override
    public int isCipherSymSupported(String string) {
        return this.myCipherSym.isCipherSymSupported(string);
    }

    @Override
    public int isDigestSupported(String string) {
        return this.myDigest.isDigestSupported(string);
    }

    @Override
    public int isRandomSupported(String string) {
        return this.myRandomData.isRandomSupported(string);
    }

    @Override
    public byte[] decryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.myCipherSym.decryptPIN(byArray, string, list, string2, string3);
    }

    @Override
    public byte[] translatePIN(byte[] byArray, String string, String string2, String string3, List<Property> list, String string4, String string5, String string6, String string7, List<Property> list2, String string8, String string9) throws Exception {
        throw new Exception("translatePIN() Not done");
    }

    @Override
    public byte[] exportKey(String string, List<Property> list, String string2, List<Property> list2) {
        this.logger(2, "exportKey() Not done");
        return null;
    }

    @Override
    public byte[] importKey(String string, String string2, List<Property> list) {
        this.logger(2, "importKey() Not done");
        return null;
    }

    @Override
    public byte[][] encryptPIN(byte[] byArray, String string, List<Property> list, String string2, String string3) throws Exception {
        return this.myCipherSym.encryptPIN(byArray, string, list, string2, string3);
    }
}

