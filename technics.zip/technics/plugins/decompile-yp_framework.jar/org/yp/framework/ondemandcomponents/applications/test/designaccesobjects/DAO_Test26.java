/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test26
extends YP_Row {
    @PrimaryKey
    public long idTest26 = 0L;
    public byte[] test26Array = new byte[12];
    public int test26Int = 0;
    public long test26Long = 0L;
    public float test26Float = 0.0f;
}

