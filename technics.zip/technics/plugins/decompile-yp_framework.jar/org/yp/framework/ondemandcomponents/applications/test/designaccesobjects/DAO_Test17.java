/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test17
extends YP_Row {
    @PrimaryKey
    public long idTest17 = 0L;
    public byte[] test17Array = new byte[1000];
}

