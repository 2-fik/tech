/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.crypto.soft;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_RandomNumberGenerator_Interface;

public class YP_TCD_CRYPTO_Soft_RandomNumberGenerator
implements YP_TCD_CRYPTO_RandomNumberGenerator_Interface {
    private final YP_TCD_CRYPTO_Module father;
    private final List<MySecureRandom> secureRandomList = new ArrayList<MySecureRandom>();
    private final ReentrantLock secureRandomListMutex = new ReentrantLock();

    public YP_TCD_CRYPTO_Soft_RandomNumberGenerator(YP_Object yP_Object) {
        this.father = (YP_TCD_CRYPTO_Module)yP_Object;
    }

    private MySecureRandom createSecureRandomElement(String string) {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance(string);
            return new MySecureRandom(secureRandom, secureRandom.hashCode(), 1, string);
        }
        catch (Exception exception) {
            this.father.logger(2, "createSecureRandomElement()" + exception);
            return null;
        }
    }

    private int recreateSecureRandomElement(MySecureRandom mySecureRandom) {
        try {
            SecureRandom secureRandom;
            mySecureRandom.secureRandom = secureRandom = SecureRandom.getInstance(mySecureRandom.algo);
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "recreateSecureRandomElement()" + exception);
            return 0;
        }
    }

    private MySecureRandom getSecureRandomElement(int n, String string) {
        this.secureRandomListMutex.lock();
        try {
            MySecureRandom mySecureRandom2;
            for (MySecureRandom mySecureRandom2 : this.secureRandomList) {
                if (mySecureRandom2.status != 0 || mySecureRandom2.myHandle != n) continue;
                mySecureRandom2.status = 1;
                MySecureRandom mySecureRandom3 = mySecureRandom2;
                return mySecureRandom3;
            }
            mySecureRandom2 = this.createSecureRandomElement(string);
            this.secureRandomList.add(mySecureRandom2);
            MySecureRandom mySecureRandom4 = mySecureRandom2;
            return mySecureRandom4;
        }
        catch (Exception exception) {
            this.father.logger(2, "getSecureRandomElement()" + exception);
            return null;
        }
        finally {
            this.secureRandomListMutex.unlock();
        }
    }

    private int releaseSecureRandomElement(MySecureRandom mySecureRandom) {
        for (MySecureRandom mySecureRandom2 : this.secureRandomList) {
            if (mySecureRandom2.myHandle != mySecureRandom.myHandle) continue;
            mySecureRandom2.status = 0;
            return 1;
        }
        if (this.father.getLogLevel() >= 2) {
            this.father.logger(2, "releaseMessageDigest() not found !!!");
        }
        return 0;
    }

    @Override
    public byte[] generateRandomBytes(int n, String string, byte[] byArray, int n2) throws Exception {
        MySecureRandom mySecureRandom;
        if (this.father.getLogLevel() >= 4) {
            this.father.logger(4, "generateRandomBytes() " + string);
        }
        if ((mySecureRandom = this.getSecureRandomElement(n, string)) == null && this.father.getLogLevel() >= 2) {
            this.father.logger(2, "generateRandomBytes() not found :" + n + " " + string);
            return null;
        }
        try {
            if (byArray != null) {
                mySecureRandom.secureRandom.setSeed(byArray);
            }
            byte[] byArray2 = new byte[n2];
            mySecureRandom.secureRandom.nextBytes(byArray2);
            byte[] byArray3 = byArray2;
            return byArray3;
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "generateRandomBytes() " + exception);
            }
            this.recreateSecureRandomElement(mySecureRandom);
            throw exception;
        }
        finally {
            this.releaseSecureRandomElement(mySecureRandom);
        }
    }

    @Override
    public byte[] generateSeed(int n, String string, int n2) throws Exception {
        MySecureRandom mySecureRandom;
        if (this.father.getLogLevel() >= 4) {
            this.father.logger(4, "generateSeed() " + string);
        }
        if ((mySecureRandom = this.getSecureRandomElement(n, string)) == null && this.father.getLogLevel() >= 2) {
            this.father.logger(2, "generateSeed() not found :" + n + " " + string);
            return null;
        }
        try {
            byte[] byArray = mySecureRandom.secureRandom.generateSeed(n2);
            return byArray;
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "generateSeed() " + exception);
            }
            this.recreateSecureRandomElement(mySecureRandom);
            throw exception;
        }
        finally {
            this.releaseSecureRandomElement(mySecureRandom);
        }
    }

    @Override
    public void setSeed(int n, String string, byte[] byArray) throws Exception {
        if (this.father.getLogLevel() >= 4) {
            this.father.logger(4, "setSeed() " + string);
        }
        if (byArray == null) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "setSeed() bad parameters");
            }
            return;
        }
        MySecureRandom mySecureRandom = this.getSecureRandomElement(n, string);
        if (mySecureRandom == null) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "setSeed() not found :" + n + " " + string);
            }
            return;
        }
        try {
            mySecureRandom.secureRandom.setSeed(byArray);
            return;
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 2) {
                this.father.logger(2, "setSeed() " + exception);
            }
            this.recreateSecureRandomElement(mySecureRandom);
            throw exception;
        }
        finally {
            this.releaseSecureRandomElement(mySecureRandom);
        }
    }

    @Override
    public int isCryptoSupported(String string) {
        try {
            MessageDigest.getInstance(string, this.father.getProviderName());
        }
        catch (Exception exception) {
            if (this.father.getLogLevel() >= 3) {
                this.father.logger(3, "isCryptoSupported() algo not supported:" + string + " " + exception);
            }
            return -1;
        }
        return 1;
    }

    @Override
    public int isRandomSupported(String string) {
        return this.isCryptoSupported(string);
    }

    private class MySecureRandom {
        public SecureRandom secureRandom;
        public int status;
        private final String algo;
        public int myHandle;

        public MySecureRandom(SecureRandom secureRandom, int n, int n2, String string) {
            this.secureRandom = secureRandom;
            this.myHandle = n;
            this.algo = string;
            this.status = n2;
        }
    }
}

