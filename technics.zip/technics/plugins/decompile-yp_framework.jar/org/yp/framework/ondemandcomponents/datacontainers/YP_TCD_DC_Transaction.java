/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers;

import java.lang.reflect.Field;
import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Schedule;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.CommonHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.ContextHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.ReservationHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UserHandler;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_Scheduler;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_ISO8583;
import org.yp.utils.ExtendedResult;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EncryptionMethodEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.KeyUpdateCodeEnumeration;
import org.yp.utils.enums.MACFormatEnumeration;
import org.yp.utils.enums.PINCheckEnumeration;
import org.yp.utils.enums.PINFormatEnumeration;
import org.yp.utils.enums.SecurityDataUsedEnumeration;
import org.yp.utils.enums.SessionStatusEnumeration;
import org.yp.utils.enums.UpdateKeyTypeEnumeration;
import org.yp.utils.enums.UploadStatusEnumeration;
import org.yp.utils.enums.sorec.SorecRequestEnumeration;

public abstract class YP_TCD_DC_Transaction
extends YP_TCD_DataContainer {
    private static final int MAX_SESSION_IN_CACHE = 100000;
    public static final Map<String, byte[]> sessionKeyCacheMap = Collections.synchronizedMap(new LinkedHashMap<String, byte[]>(){
        private static final long serialVersionUID = -2550345596243957862L;

        @Override
        protected boolean removeEldestEntry(Map.Entry entry) {
            return this.size() > 100000;
        }
    });
    private byte[] v_sessionKey;
    public final ContextHandler contextHandler = new ContextHandler(this);
    public final AccountHandler accountHandler = new AccountHandler(this);
    public final UserHandler userHandler = new UserHandler(this);
    public final CommonHandler commonHandler = new CommonHandler(this);
    public final ReservationHandler reservationHandler = new ReservationHandler(this);
    public final UpdateHandler updateHandler = new UpdateHandler(this);
    public final StringBuilder xmlResponse = new StringBuilder();
    private SorecRequestEnumeration sorecRequest;
    private String fileName;
    private String fileContent;
    private int taskerNumber;
    private String dateReunion;
    private String numeroTicket;
    private String numeroReunion;
    private String numeroCourse;
    private String dateSessionVoucher;
    private String terminalIp;
    private long idContract;
    public long systemGMTTimeMS = 0L;
    public boolean transactionPersisted = false;
    private YP_Service tokenManager = null;
    private YP_Service cryptoManager = null;
    private ExtendedTVR t_extendedTVR = null;
    private YP_TCD_PosProtocol.REQUEST_TYPE requestType;
    private YP_TCD_PosProtocol.SUB_REQUEST_TYPE subRequestType;
    private boolean t_mposTrs = false;
    private YP_Row v_TerminalRow = null;
    private int v_RealNLPA = -1;
    private String t_TerminalSerialNumber = "";
    private YP_Transaction transactionProcessFather = null;
    private YP_TCD_PosProtocol protocolEFT = null;
    private YP_TCD_DCC_Brand dataContainerBrand = null;
    private DAO_Schedule scheduleRow = null;
    private List<YP_Row> transactionList;
    private List<YP_Row> sessionList;
    private int v_CurrentTry = 0;
    private int v_MaxTries = 0;
    private int v_HostID = 0;
    private String v_Ticket = "";
    private String c_ProviderAID = "";
    private String c_TerminalIdentification = "";
    private String c_MerchantCategoryCode = "";
    private String c_MerchantContract = "";
    private String c_ApplicationEnvironmentType = "";
    private String c_ManufacturerAID = "";
    private String c_AcquiringInstitutionIdentificationCode = "";
    private String c_CardAcceptorIdentificationCode = "";
    private String t_IDPA = "";
    private String t_NLPA = "";
    private String t_CashierID = "";
    private SecurityDataUsedEnumeration securityDataUsed;
    private PINCheckEnumeration pinCheck;
    private MACFormatEnumeration macFormat;
    private EncryptionMethodEnumeration encryptionMethod;
    private PINFormatEnumeration pinFormat;
    private int pinEncryptionKeyIndex = 0;
    private int keyEncryptionKeyIndex = 0;
    private int updateKeyIndex = 0;
    private int macKeyIndex = 0;
    private KeyUpdateCodeEnumeration keyUpdateCode;
    private UpdateKeyTypeEnumeration updateKeyType;
    private String t_AuthResponseBuffer = "";
    private String authorisationApprovalCode = "";
    private String authorisationResponseCode = "";
    private long authorisationReasonList = 0L;
    private long authorisationReasonListExtended = 0L;
    private List<Object> extensionList = null;
    private final Map<String, Object> temporaryValueList = new HashMap<String, Object>();
    private static final String CARD_HASH_SALT = "Just a simple passphrase to salt";

    public ExtendedTVR getExtendedTVR() {
        if (this.t_extendedTVR == null) {
            this.t_extendedTVR = new ExtendedTVR();
        }
        return this.t_extendedTVR;
    }

    public void setExtendedTVR(ExtendedTVR extendedTVR) {
        this.t_extendedTVR = extendedTVR;
    }

    public YP_TCD_PosProtocol.REQUEST_TYPE getRequestType() {
        if (this.requestType != null) {
            return this.requestType;
        }
        if (this.protocolEFT == null) {
            return null;
        }
        return this.protocolEFT.getRequestType();
    }

    public boolean getTestMode() {
        if (this.protocolEFT == null) {
            return false;
        }
        return this.protocolEFT.getTestMode();
    }

    public void setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE rEQUEST_TYPE) {
        this.requestType = rEQUEST_TYPE;
    }

    public YP_TCD_PosProtocol.SUB_REQUEST_TYPE getSubRequestType() {
        if (this.subRequestType != null) {
            return this.subRequestType;
        }
        if (this.protocolEFT == null) {
            return null;
        }
        return this.protocolEFT.getSubRequestType();
    }

    public void setSubRequestType(YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE) {
        this.subRequestType = sUB_REQUEST_TYPE;
    }

    public YP_TCD_PosProtocol getProtocolEFT() {
        return this.protocolEFT;
    }

    public YP_TCD_DC_Transaction(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    private YP_TCD_PosProtocol getPOSProtocol(byte[] byArray, int n) {
        try {
            return (YP_TCD_PosProtocol)this.getPluginByName("ProtocolSelector").dealRequest(this, "getProtocol", byArray, n);
        }
        catch (Exception exception) {
            this.logger(2, "getPOSProtocol() unknown :" + new String(byArray, 0, n), exception);
            return null;
        }
    }

    public int load(byte[] byArray, int n) {
        block10: {
            block9: {
                block8: {
                    block7: {
                        if (YP_TCD_PHYS_Scheduler.class.isInstance(this.getTransactionProcessFather().getClientConnectionHandler().getPhysicalInterface())) {
                            this.scheduleRow = new DAO_Schedule();
                            this.scheduleRow.deserialize(new String(byArray, 0, n));
                            byArray = (byte[])this.scheduleRow.getFieldValueByName("requestXML");
                            n = byArray.length;
                            this.setCurrentTry((Integer)this.scheduleRow.getFieldValueByName("currentTry"));
                            this.setMaxTries((Integer)this.scheduleRow.getFieldValueByName("maxTries"));
                        }
                        try {
                            this.protocolEFT = this.getPOSProtocol(byArray, n);
                            if (this.protocolEFT != null) break block7;
                            this.logger(2, "load() failed to get protocol ");
                            return -1;
                        }
                        catch (Exception exception) {
                            this.logger(2, "load()  ", exception);
                            return -1;
                        }
                    }
                    if (this.protocolEFT.getErrorStatus() == 0) break block8;
                    this.logger(2, "load() failed to load request from protocol");
                    return -1;
                }
                if (this.protocolEFT.readRequest(this) >= 0) break block9;
                this.logger(2, "load() Bad request ???");
                return -1;
            }
            if (this.checkSecurityTrailer()) break block10;
            YP_TCD_DCC_Business.setGlobalResult(this, YP_TCD_PosProtocol.RESULT_TYPE.Error);
            this.getExtendedTVR().add(ExtendedTVREnumeration.MAC_ERROR);
            YP_TCD_DCC_Business.setExtendedResult(this, new ExtendedResult(91));
            return -1;
        }
        this.extractDUKPTTrack2FromRequest();
        this.extractTrack2FromRequestEMVTags();
        this.extractDUKPTTrack1FromRequest();
        this.extractMerchantPrivateDataFromRequest();
        this.extractMerchantPOSAliasFromRequest();
        return 1;
    }

    public String getEFTResponse(YP_Transaction yP_Transaction) {
        Object object;
        Object object2;
        if (this.protocolEFT == null) {
            return null;
        }
        YP_TCD_PosProtocol.REQUEST_TYPE rEQUEST_TYPE = this.getRequestType();
        if (rEQUEST_TYPE != null) {
            switch (rEQUEST_TYPE) {
                // Empty switch
            }
        }
        if (this.protocolEFT.getErrorStatus() == 0) {
            this.protocolEFT.prepareResponse(this);
            if (this.v_sessionKey != null) {
                try {
                    object2 = new TLVHandler();
                    ((TLVHandler)object2).add(-538738349, "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
                    object = new TLVHandler();
                    ((TLVHandler)object).add(-2064046, (TLVHandler)object2);
                    this.protocolEFT.setSecurityTrailer(((TLVHandler)object).toString());
                }
                catch (Exception exception) {
                    this.logger(2, "getEFTResponse() securityTrailer ", exception);
                }
            }
        }
        if ((object2 = this.protocolEFT.getResponse()) == null) {
            this.logger(2, "getEFTResponse()  ");
            return null;
        }
        if (this.v_sessionKey != null) {
            try {
                object = this.getPluginByName("CryptoManager");
                String string = (String)((YP_Object)object).dealRequest(this, "sha256Hash", object2);
                if (string == null || string.isEmpty()) {
                    this.logger(2, "getEFTResponse() pb during hash");
                } else {
                    IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[16]);
                    SecretKeySpec secretKeySpec = new SecretKeySpec(this.v_sessionKey, "AES");
                    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
                    cipher.init(1, (Key)secretKeySpec, ivParameterSpec);
                    byte[] byArray = cipher.doFinal(UtilsYP.redHexa(string));
                    String string2 = UtilsYP.devHexa(byArray);
                    object2 = ((String)object2).replace("DFE3815330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "DFE3815330" + string2);
                }
            }
            catch (Exception exception) {
                this.logger(2, "getEFTResponse() During macing ", exception);
            }
        }
        return object2;
    }

    @Override
    public int shutdown() {
        this.tokenManager = null;
        this.cryptoManager = null;
        this.extensionList = null;
        this.sessionList = null;
        this.dataContainerBrand = null;
        this.transactionProcessFather = null;
        this.scheduleRow = null;
        this.transactionList = null;
        this.temporaryValueList.clear();
        if (this.protocolEFT != null) {
            this.protocolEFT.shutdown();
            this.protocolEFT = null;
        }
        this.contextHandler.shutdown();
        this.accountHandler.shutdown();
        this.userHandler.shutdown();
        this.commonHandler.shutdown();
        this.reservationHandler.shutdown();
        this.v_TerminalRow = null;
        return super.shutdown();
    }

    public void setTransactionProcessFather(YP_Transaction yP_Transaction) {
        this.transactionProcessFather = yP_Transaction;
    }

    public YP_Transaction getTransactionProcessFather() {
        return this.transactionProcessFather;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String createScheduledRequest(YP_Object yP_Object, String string) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol;
        block3: {
            try {
                if (this.protocolEFT != null) return this.protocolEFT.createScheduledRequest(yP_Object, string);
                yP_TCD_PosProtocol = (YP_TCD_PosProtocol)this.newPluginByName("XPDE_JIBX", new Object[0]);
                int n = yP_TCD_PosProtocol.initialize();
                if (n == 1) break block3;
                this.logger(2, "createScheduledRequest():" + n);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "createScheduledRequest():", exception);
                return null;
            }
        }
        String string2 = yP_TCD_PosProtocol.createScheduledRequest(yP_Object, string);
        yP_TCD_PosProtocol.shutdown();
        return string2;
    }

    public List<YP_Row> getSessionListToUpload(String string) {
        try {
            this.sessionList = this.getDataContainerBrand(string).getSessionListToUpload(string);
        }
        catch (Exception exception) {
            this.logger(2, "getSessionListToUpload() ", exception);
            return null;
        }
        return this.sessionList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int isAllSessionUploaded() {
        try {
            YP_Row yP_Row;
            if (this.sessionList == null) {
                return -1;
            }
            Iterator<YP_Row> iterator = this.sessionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                return 1;
            } while ((SessionStatusEnumeration)((Object)(yP_Row = iterator.next()).getFieldValueByName("status")) == SessionStatusEnumeration.UPLOADED);
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "isAllSessionUploaded() ", exception);
            return -2;
        }
    }

    public List<YP_Row> getSessionListUploaded() {
        block4: {
            if (this.sessionList != null) break block4;
            return null;
        }
        try {
            ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
            for (YP_Row yP_Row : this.sessionList) {
                if ((SessionStatusEnumeration)((Object)yP_Row.getFieldValueByName("status")) != SessionStatusEnumeration.UPLOADED) continue;
                arrayList.add(yP_Row);
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getSessionListUploaded() ", exception);
            return null;
        }
    }

    public boolean isItACronRequest() {
        return this.scheduleRow != null;
    }

    @Override
    public String get(String string) {
        if (this.protocolEFT == null) {
            return null;
        }
        return this.protocolEFT.get(string);
    }

    /*
     * Exception decompiling
     */
    public int transactionRowToTransactionDatas(YP_Row var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:94)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public int transactionDatasToTransactionRow(YP_Row var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:94)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public int initTransaction(YP_Application yP_Application, boolean bl) {
        if (bl) {
            Timestamp timestamp;
            YP_TCD_DCC_Business yP_TCD_DCC_Business = yP_Application.getDataContainerBusiness();
            this.setMerchantContract(yP_TCD_DCC_Business.getMerchantContract());
            this.setAcquiringInstitutionIdentificationCode(yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode());
            if (this.getMerchantCategoryCode() == null || this.getMerchantCategoryCode().isEmpty()) {
                this.setMerchantCategoryCode(yP_TCD_DCC_Business.getMerchantCategoryCode());
            }
            this.setTerminalIdentification(yP_TCD_DCC_Business.getTerminalIdentification());
            this.setApplicationEnvironmentType(yP_TCD_DCC_Business.getApplicationPlugin().getApplicationEnvironmentType());
            this.setManufacturerAID(yP_TCD_DCC_Business.getApplicationPlugin().getManufacturerAID());
            this.setProviderAID(yP_TCD_DCC_Business.getApplicationPlugin().getProviderAID());
            if (yP_TCD_DCC_Business instanceof YP_PROT_Interface_ISO8583) {
                YP_PROT_Interface_ISO8583 yP_PROT_Interface_ISO8583 = (YP_PROT_Interface_ISO8583)((Object)yP_TCD_DCC_Business);
                this.setCardAcceptorIdentificationCode(yP_PROT_Interface_ISO8583.getCardAcceptorIdentificationCode());
            }
            this.commonHandler.setTransactionPrimaryKey(yP_TCD_DCC_Business.transaction.getNextPrimaryKey());
            this.commonHandler.setTransactionSystemGMTTimeMS(UtilsYP.getSystemGMTTime(this.getStartTime()).getTimeInMillis());
            long l = this.getStartTime();
            Timestamp timestamp2 = new Timestamp(yP_Application.getDataContainerBusiness().timeInterface.getAppliGMTTime(l).getTimeInMillis());
            timestamp2.setNanos(0);
            this.commonHandler.setTransactionAppliGMTTime(timestamp2);
            Timestamp timestamp3 = new Timestamp(yP_Application.getDataContainerBusiness().timeInterface.getAppliLocalTime(l).getTimeInMillis());
            timestamp3.setNanos(0);
            this.commonHandler.setTransactionAppliLocalTime(timestamp3);
            this.contextHandler.setInstanceNumber(UtilsYP.getInstanceNumber());
            YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getSubRequestType();
            if (sUB_REQUEST_TYPE != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalRiskManagement && sUB_REQUEST_TYPE != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Authorization && sUB_REQUEST_TYPE != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion) {
                int n = yP_Application.getDataContainerBusiness().getNextTransactionNumber();
                this.commonHandler.setTransactionNumber(n);
            }
            if (this.getNLPA3_6() == null || this.getNLPA3_6().isEmpty()) {
                this.setNLPA(yP_Application.getRankInDCC() + 1001);
            }
            if ((timestamp = this.commonHandler.getTransactionUploadAppliLocalTime()).after(this.commonHandler.getTransactionAppliGMTTime())) {
                this.commonHandler.setTransactionUploadStatus(UploadStatusEnumeration.NOT_YET_UPLOADABLE);
            } else if (this.getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Authorization) {
                this.commonHandler.setTransactionUploadStatus(UploadStatusEnumeration.NOT_UPLOADABLE);
            } else {
                this.commonHandler.setTransactionUploadStatus(UploadStatusEnumeration.UPLOADABLE);
            }
        }
        return 1;
    }

    public void setTicket(String string) {
        this.v_Ticket = string;
    }

    public void addTicket(String string) {
        this.v_Ticket = this.v_Ticket == null || this.v_Ticket.isEmpty() ? string : String.valueOf(this.v_Ticket) + string;
    }

    public String getTicket() {
        return this.v_Ticket;
    }

    public void setMerchantCategoryCode(String string) {
        this.c_MerchantCategoryCode = string;
    }

    public String getMerchantCategoryCode() {
        return this.c_MerchantCategoryCode;
    }

    public void setAcquiringInstitutionIdentificationCode(String string) {
        this.c_AcquiringInstitutionIdentificationCode = string;
    }

    public String getAcquiringInstitutionIdentificationCode() {
        return this.c_AcquiringInstitutionIdentificationCode;
    }

    public void setAuthorisationApprovalCode(String string) {
        this.authorisationApprovalCode = string;
    }

    public String getAuthorisationApprovalCode() {
        return this.authorisationApprovalCode;
    }

    public void setAuthorisationResponseCode(String string) {
        this.authorisationResponseCode = string;
    }

    public String getAuthorisationResponseCode() {
        return this.authorisationResponseCode;
    }

    public void setCardAcceptorIdentificationCode(String string) {
        this.c_CardAcceptorIdentificationCode = string;
    }

    public String getCardAcceptorIdentificationCode() {
        return this.c_CardAcceptorIdentificationCode;
    }

    public void setAuthorisationReasonList(long l) {
        this.authorisationReasonList = l;
    }

    public long getAuthorisationReasonList() {
        return this.authorisationReasonList;
    }

    public void setAuthorisationReasonListExtended(long l) {
        this.authorisationReasonListExtended = l;
    }

    public long getAuthorisationReasonListExtended() {
        return this.authorisationReasonListExtended;
    }

    public void setApplicationEnvironmentType(String string) {
        this.c_ApplicationEnvironmentType = string;
    }

    public String getApplicationEnvironmentType() {
        return this.c_ApplicationEnvironmentType;
    }

    public void setManufacturerAID(String string) {
        this.c_ManufacturerAID = string;
    }

    public String getManufacturerAID() {
        return this.c_ManufacturerAID;
    }

    public void setMerchantContract(String string) {
        this.c_MerchantContract = string;
    }

    public String getMerchantContract() {
        return this.c_MerchantContract;
    }

    public void setProviderAID(String string) {
        this.c_ProviderAID = string;
    }

    public String getProviderAID() {
        return this.c_ProviderAID;
    }

    public void setTerminalIdentification(String string) {
        this.c_TerminalIdentification = string;
    }

    public String getTerminalIdentification() {
        return this.c_TerminalIdentification;
    }

    public int getCurrentTry() {
        return this.v_CurrentTry;
    }

    public void setCurrentTry(int n) {
        this.v_CurrentTry = n;
    }

    public int getMaxTries() {
        return this.v_MaxTries;
    }

    public void setMaxTries(int n) {
        this.v_MaxTries = n;
    }

    public void setHostID(int n) {
        this.v_HostID = n;
    }

    public int getHostID() {
        return this.v_HostID;
    }

    public void setIDPA(String string) {
        if (string == null) {
            this.t_IDPA = "";
            return;
        }
        this.t_IDPA = string;
    }

    public String getIDPA() {
        return this.t_IDPA;
    }

    public void setTerminalRow(YP_Row yP_Row) {
        this.v_TerminalRow = yP_Row;
    }

    public YP_Row getTerminalRow() {
        return this.v_TerminalRow;
    }

    public void setNLPA(String string) {
        try {
            if (string != null && !string.isEmpty()) {
                this.v_RealNLPA = Integer.parseInt(string);
            }
        }
        catch (Exception exception) {}
        this.t_NLPA = string;
    }

    public void setNLPA(int n) {
        this.v_RealNLPA = n;
        this.t_NLPA = String.format("%03d", n);
    }

    @Deprecated
    public String getNLPA() {
        return this.getNLPA3();
    }

    public void setTerminalSerialNumber(String string) {
        this.t_TerminalSerialNumber = string;
    }

    public String getTerminalSerialNumber() {
        return this.t_TerminalSerialNumber;
    }

    public String getNLPA3() {
        if (this.t_NLPA != null && this.t_NLPA.length() > 3) {
            String string = this.t_NLPA.substring(this.t_NLPA.length() - 3);
            if ("000".contentEquals(string)) {
                return "999";
            }
            return string;
        }
        return this.t_NLPA;
    }

    public String getNLPA3_6() {
        return this.t_NLPA;
    }

    public void setRealNLPA(int n) {
        this.v_RealNLPA = n;
    }

    public int getRealNLPA() {
        int n = 0;
        try {
            if (this.v_RealNLPA > 0) {
                n = this.v_RealNLPA;
            }
            if (n <= 0 && this.t_NLPA != null && !this.t_NLPA.isEmpty()) {
                n = Integer.parseInt(this.t_NLPA);
            }
        }
        catch (Exception exception) {
            this.logger(2, "getRealNLPA() ", exception);
        }
        return n;
    }

    public void setMPosTrs(boolean bl) {
        this.t_mposTrs = bl;
    }

    public boolean isMPosTrs() {
        return this.t_mposTrs;
    }

    public void setCashierID(String string) {
        this.t_CashierID = string;
    }

    public String getCashierID() {
        return this.t_CashierID;
    }

    public void setAuthResponseBuffer(String string) {
        this.t_AuthResponseBuffer = string;
    }

    public String getAuthResponseBuffer() {
        return this.t_AuthResponseBuffer;
    }

    public void setDataContainerBrand(YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        this.dataContainerBrand = yP_TCD_DCC_Brand;
    }

    public YP_TCD_DCC_Brand getDataContainerBrand() {
        block4: {
            try {
                if (this.dataContainerBrand != null) {
                    return this.dataContainerBrand;
                }
                String string = this.getContractIdentifier();
                if (string == null || string.isEmpty()) break block4;
                this.dataContainerBrand = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", string);
                if (this.dataContainerBrand != null) break block4;
                this.logger(2, "getDataContainerBrand() failed to get data Container Brand for " + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDataContainerBrand()  ", exception);
                return null;
            }
        }
        return this.dataContainerBrand;
    }

    public YP_TCD_DCC_Brand getDataContainerBrand(String string) {
        block3: {
            try {
                if (string == null || string.isEmpty()) break block3;
                this.dataContainerBrand = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", string);
                if (this.dataContainerBrand != null) break block3;
                this.logger(2, "getDataContainerBrand() failed to get data Container Brand for " + string);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDataContainerBrand()  ", exception);
                return null;
            }
        }
        return this.dataContainerBrand;
    }

    public void setTransactionList(List<YP_Row> list) {
        this.transactionList = list;
    }

    public List<YP_Row> getTransactionList() {
        if (this.transactionList == null) {
            this.transactionList = new ArrayList<YP_Row>();
        }
        return this.transactionList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int setExtensionValue(String string, Object object) {
        if (this.extensionList == null) return 0;
        if (this.extensionList.isEmpty()) {
            return 0;
        }
        try {
            Iterator<Object> iterator = this.extensionList.iterator();
            block2: while (true) {
                if (!iterator.hasNext()) {
                    return -1;
                }
                Object object2 = iterator.next();
                Field[] fieldArray = object2.getClass().getDeclaredFields();
                int n = fieldArray.length;
                int n2 = 0;
                while (true) {
                    if (n2 >= n) continue block2;
                    Field field = fieldArray[n2];
                    if (field.getName().contentEquals(string)) {
                        if (object instanceof String) {
                            field.set(object2, YP_Row.getXMLBytes((String)object));
                            return 1;
                        }
                        field.set(object2, object);
                        return 1;
                    }
                    ++n2;
                }
                break;
            }
        }
        catch (Exception exception) {
            this.logger(2, "setExtensionValue() :" + string + " ", exception);
        }
        return -1;
    }

    public Object getExtensionValue(String string) throws Exception {
        if (this.extensionList == null) {
            throw new Exception("null :" + string);
        }
        if (this.extensionList.isEmpty()) {
            throw new Exception("empty :" + string);
        }
        try {
            for (Object object : this.extensionList) {
                Field[] fieldArray = object.getClass().getDeclaredFields();
                int n = fieldArray.length;
                int n2 = 0;
                while (n2 < n) {
                    Field field = fieldArray[n2];
                    if (field.getName().contentEquals(string)) {
                        return field.get(object);
                    }
                    ++n2;
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "getExtensionValue() :" + string + " ", exception);
            throw exception;
        }
        throw new Exception("not found:" + string);
    }

    public void addExtension(Object object) {
        if (this.extensionList == null) {
            this.extensionList = new ArrayList<Object>();
        }
        for (Object object2 : this.extensionList) {
            if (object2.getClass() != object.getClass()) continue;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "addExtension() already added :" + object2.getClass().toString());
            }
            return;
        }
        this.extensionList.add(object);
    }

    public void resetTemporaryValues() {
        this.temporaryValueList.clear();
    }

    public int setTemporaryValue(String string, Object object) {
        return this.temporaryValueList.put(string, object) != null ? 0 : 1;
    }

    public Object getTemporaryValue(String string) throws Exception {
        return this.temporaryValueList.get(string);
    }

    public SecurityDataUsedEnumeration getSecurityDataUsed() {
        return this.securityDataUsed;
    }

    public void setSecurityDataUsed(SecurityDataUsedEnumeration securityDataUsedEnumeration) {
        this.securityDataUsed = securityDataUsedEnumeration;
    }

    public PINCheckEnumeration getPinCheck() {
        return this.pinCheck;
    }

    public void setPinCheck(PINCheckEnumeration pINCheckEnumeration) {
        this.pinCheck = pINCheckEnumeration;
    }

    public MACFormatEnumeration getMacFormat() {
        return this.macFormat;
    }

    public void setMacFormat(MACFormatEnumeration mACFormatEnumeration) {
        this.macFormat = mACFormatEnumeration;
    }

    public EncryptionMethodEnumeration getEncryptionMethod() {
        return this.encryptionMethod;
    }

    public void setEncryptionMethod(EncryptionMethodEnumeration encryptionMethodEnumeration) {
        this.encryptionMethod = encryptionMethodEnumeration;
    }

    public PINFormatEnumeration getPinFormat() {
        return this.pinFormat;
    }

    public void setPinFormat(PINFormatEnumeration pINFormatEnumeration) {
        this.pinFormat = pINFormatEnumeration;
    }

    public int getPinEncryptionKeyIndex() {
        return this.pinEncryptionKeyIndex;
    }

    public void setPinEncryptionKeyIndex(int n) {
        this.pinEncryptionKeyIndex = n;
    }

    public int getKeyEncryptionKeyIndex() {
        return this.keyEncryptionKeyIndex;
    }

    public void setKeyEncryptionKeyIndex(int n) {
        this.keyEncryptionKeyIndex = n;
    }

    public int getUpdateKeyIndex() {
        return this.updateKeyIndex;
    }

    public void setUpdateKeyIndex(int n) {
        this.updateKeyIndex = n;
    }

    public int getMacKeyIndex() {
        return this.macKeyIndex;
    }

    public void setMacKeyIndex(int n) {
        this.macKeyIndex = n;
    }

    public KeyUpdateCodeEnumeration getKeyUpdateCode() {
        return this.keyUpdateCode;
    }

    public void setKeyUpdateCode(KeyUpdateCodeEnumeration keyUpdateCodeEnumeration) {
        this.keyUpdateCode = keyUpdateCodeEnumeration;
    }

    public UpdateKeyTypeEnumeration getUpdateKeyType() {
        return this.updateKeyType;
    }

    public void setUpdateKeyType(UpdateKeyTypeEnumeration updateKeyTypeEnumeration) {
        this.updateKeyType = updateKeyTypeEnumeration;
    }

    public YP_Row getScheduleRow() {
        return this.scheduleRow;
    }

    private int extractDUKPTTrack1FromRequest() {
        List<TLV> list;
        block8: {
            String string;
            block7: {
                block6: {
                    try {
                        String string2 = this.accountHandler.getTrack1();
                        if (string2 == null || string2.isEmpty()) break block6;
                        if (this.getLogLevel() >= 6) {
                            this.logger(6, "extractDUKPTTrack1FromRequest() already done");
                        }
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "extractDUKPTTrack1FromRequest()  ", exception);
                        return -1;
                    }
                }
                string = this.commonHandler.getRequestAppTags();
                if (string != null && !string.isEmpty()) break block7;
                return 0;
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            list = tLVHandler.getTLVList(-2064071);
            if (list != null && list.size() != 0) break block8;
            return 0;
        }
        return this.decryptDUKPTTrack1(list.get(list.size() - 1));
    }

    private int extractTrack2FromRequestEMVTags() {
        TLV tLV;
        block8: {
            String string;
            block7: {
                block6: {
                    try {
                        String string2 = this.accountHandler.getTrack2();
                        if (string2 == null || string2.isEmpty()) break block6;
                        if (this.getLogLevel() >= 6) {
                            this.logger(6, "extractTrack2FromRequestEMVTags() already done");
                        }
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "extractTrack2FromRequestEMVTags()  ", exception);
                        return -1;
                    }
                }
                string = this.commonHandler.getRequestEMVTags();
                if (string != null && !string.isEmpty()) break block7;
                return 0;
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            tLV = tLVHandler.getTLV(87);
            if (tLV != null) break block8;
            return 0;
        }
        this.accountHandler.setTrack2(UtilsYP.devHexa(tLV.value));
        return 1;
    }

    private int extractDUKPTTrack2FromRequest() {
        List<TLV> list;
        block8: {
            String string;
            block7: {
                block6: {
                    try {
                        String string2 = this.accountHandler.getTrack2();
                        if (string2 == null || string2.isEmpty()) break block6;
                        if (this.getLogLevel() >= 6) {
                            this.logger(6, "extractDUKPTTrack2FromRequest() already done");
                        }
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "extractDUKPTTrack2FromRequest()  ", exception);
                        return -1;
                    }
                }
                string = this.commonHandler.getRequestAppTags();
                if (string != null && !string.isEmpty()) break block7;
                return 0;
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            list = tLVHandler.getTLVList(16769892);
            if (list != null && list.size() != 0) break block8;
            return 0;
        }
        return this.decryptDUKPTTrack2(list.get(list.size() - 1));
    }

    private int extractMerchantPrivateDataFromRequest() {
        TLV tLV;
        block5: {
            String string;
            block4: {
                try {
                    string = this.commonHandler.getRequestAppTags();
                    if (string != null && !string.isEmpty()) break block4;
                    return 0;
                }
                catch (Exception exception) {
                    this.logger(2, "extractMerchantPrivateDataFromRequest() ", exception);
                    return -1;
                }
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            tLV = tLVHandler.getTLV(-538738381);
            if (tLV != null) break block5;
            return 0;
        }
        this.commonHandler.setMerchantPrivateData(new String(tLV.value));
        return 1;
    }

    private int extractMerchantPOSAliasFromRequest() {
        TLV tLV;
        block7: {
            TLV tLV2;
            block6: {
                String string;
                block5: {
                    try {
                        string = this.commonHandler.getRequestAppTags();
                        if (string != null && !string.isEmpty()) break block5;
                        return 0;
                    }
                    catch (Exception exception) {
                        this.logger(2, "extractMerchantPOSAliasFromRequest() ", exception);
                        return -1;
                    }
                }
                TLVHandler tLVHandler = new TLVHandler(string);
                tLV2 = tLVHandler.getTLV(16769880);
                if (tLV2 != null) break block6;
                return 0;
            }
            TLVHandler tLVHandler = new TLVHandler(tLV2.value);
            tLV = tLVHandler.getTLV(-538738324);
            if (tLV != null) break block7;
            return 0;
        }
        this.commonHandler.setMerchantPOSAlias(new String(tLV.value));
        return 1;
    }

    private int decryptDUKPTTrack1(TLV tLV) {
        Object object2;
        String string;
        String string2;
        int n;
        block12: {
            block11: {
                n = -1;
                string2 = null;
                string = null;
                try {
                    TLVHandler tLVHandler = new TLVHandler(UtilsYP.devHexa(tLV.value));
                    for (Object object2 : tLVHandler) {
                        switch (((TLV)object2).tag) {
                            case 14672737: {
                                string2 = UtilsYP.devHexa(((TLV)object2).value);
                                break;
                            }
                            case 14672738: {
                                string = UtilsYP.devHexa(((TLV)object2).value);
                                break;
                            }
                            case 14672483: {
                                n = TLVHandler.getDCBInt(((TLV)object2).value);
                            }
                        }
                    }
                    if (string2 != null && string != null) break block11;
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "decryptDUKPTTrack1() DUKPT_TRACK1 ", exception);
                    return -1;
                }
            }
            if (string.length() != 16) break block12;
            return 0;
        }
        object2 = n <= 0 ? DUKPT.decryptData(string2, string) : DUKPT.decryptData(string2, string, n);
        Object object3 = UtilsYP.redHexa((String)object2);
        if (object3 != null) {
            object2 = new String((byte[])object3);
        }
        this.accountHandler.setTrack1((String)object2);
        return 1;
    }

    private int decryptDUKPTTrack2(TLV tLV) {
        Object object2;
        String string;
        String string2;
        int n;
        block11: {
            n = -1;
            string2 = null;
            string = null;
            try {
                TLVHandler tLVHandler = new TLVHandler(UtilsYP.devHexa(tLV.value));
                for (Object object2 : tLVHandler) {
                    switch (((TLV)object2).tag) {
                        case 14672737: {
                            string2 = UtilsYP.devHexa(((TLV)object2).value);
                            break;
                        }
                        case 14672738: {
                            string = UtilsYP.devHexa(((TLV)object2).value);
                            break;
                        }
                        case 14672483: {
                            n = TLVHandler.getDCBInt(((TLV)object2).value);
                        }
                    }
                }
                if (string2 != null && string != null) break block11;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "decryptDUKPTTrack2() DUKPT_TRACK2 ", exception);
                return -1;
            }
        }
        object2 = n <= 0 ? DUKPT.decryptData(string2, string) : DUKPT.decryptData(string2, string, n);
        if (object2 != null && ((String)object2).length() > 2 && ((String)object2).startsWith("3B")) {
            int n2 = ((String)object2).indexOf("3F");
            if (n2 > 0) {
                object2 = ((String)object2).substring(0, n2);
            }
            object2 = new String(UtilsYP.redHexa((String)object2));
        }
        this.accountHandler.setTrack2((String)object2);
        return 1;
    }

    public String getTokenHash() throws Exception {
        long l = this.accountHandler.getIDToken();
        if (l <= 0L) {
            this.logger(3, "getTokenHash() it's probably not a PAN (No token)");
            return null;
        }
        return this.getTokenHash(l);
    }

    public String getTokenHash(long l) throws Exception {
        String string;
        block6: {
            if (l <= 0L) {
                this.logger(3, "getTokenHash() Bad token");
                return null;
            }
            StringBuilder stringBuilder = new StringBuilder(48);
            while (stringBuilder.length() < 32) {
                stringBuilder.append(l);
            }
            byte[] byArray = stringBuilder.substring(0, 32).getBytes();
            int n = 0;
            while (n < byArray.length) {
                byArray[n] = (byte)(byArray[n] + CARD_HASH_SALT.charAt(n) & 0xFF);
                ++n;
            }
            try {
                string = (String)this.getPluginByName("CryptoManager").dealRequest(this, "sha256Hash", new Object[]{byArray});
                if (string != null && !string.isEmpty()) break block6;
                this.logger(2, "getTokenHash() pb during hash");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getTokenHash() ", exception);
                return null;
            }
        }
        return string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean checkSecurityTrailer() {
        this.v_sessionKey = null;
        String string = this.getProtocolEFT().getSecurityTrailer();
        if (string != null && !string.isEmpty()) {
            try {
                Object object;
                TLVHandler tLVHandler = new TLVHandler(string);
                TLV tLV = tLVHandler.getTLV(-2064046);
                if (tLV == null) {
                    this.logger(2, "checkSecurityTrailer() securityTrailer not yet handled");
                    return false;
                }
                TLVHandler tLVHandler2 = new TLVHandler(tLV.value);
                TLV tLV2 = tLVHandler2.getTLV(14672737);
                TLV tLV3 = tLVHandler2.getTLV(14672757);
                TLV tLV4 = tLVHandler2.getTLV(-538738349);
                if (tLV3 == null || tLV2 == null || tLV4 == null) {
                    this.logger(2, "checkSecurityTrailer() securityTrailer not well formated");
                    return false;
                }
                String string2 = UtilsYP.devHexa(tLV4.value);
                String string3 = this.getProtocolEFT().getInitialRequest();
                String string4 = string3.replace(string2, "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
                YP_Object yP_Object = this.getPluginByName("CryptoManager");
                String string5 = (String)yP_Object.dealRequest(this, "sha256Hash", string4);
                if (string5 == null || string5.isEmpty()) {
                    this.logger(2, "checkSecurityTrailer() pb during hash");
                    return false;
                }
                String string6 = UtilsYP.devHexa(tLV3.value);
                byte[] byArray = sessionKeyCacheMap.get(string6);
                boolean bl = false;
                if (byArray == null) {
                    object = DUKPT.decryptData(UtilsYP.devHexa(tLV2.value), string6, "0000000000000000", DUKPT.PaddingType.PKCS5Padding);
                    if (object == null) {
                        this.logger(2, "checkSecurityTrailer() Unable to retreive SK");
                        return false;
                    }
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "checkSecurityTrailer() Session key retreived using DUKPT key");
                    }
                    byArray = UtilsYP.redHexa((String)object);
                    bl = true;
                }
                object = new IvParameterSpec(new byte[16]);
                SecretKeySpec secretKeySpec = new SecretKeySpec(byArray, "AES");
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
                cipher.init(2, (Key)secretKeySpec, (AlgorithmParameterSpec)object);
                byte[] byArray2 = cipher.doFinal(UtilsYP.redHexa(string2));
                if (byArray2 == null) {
                    this.logger(2, "checkSecurityTrailer() pb during decryption");
                    return false;
                }
                if (!string5.contentEquals(UtilsYP.devHexa(byArray2))) {
                    this.logger(2, "checkSecurityTrailer() wrong MAC from SK");
                    return false;
                }
                this.v_sessionKey = byArray;
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "checkSecurityTrailer() securityTrailer verified using session key");
                }
                if (bl) {
                    sessionKeyCacheMap.put(string6, byArray);
                }
                return true;
            }
            catch (Exception exception) {
                this.logger(2, "checkSecurityTrailer() securityTrailer ", exception);
                return false;
            }
        }
        return true;
    }

    public SorecRequestEnumeration getSorecRequest() {
        return this.sorecRequest;
    }

    public void setSorecRequest(SorecRequestEnumeration sorecRequestEnumeration) {
        this.sorecRequest = sorecRequestEnumeration;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String string) {
        this.fileName = string;
    }

    public String getFileContent() {
        return this.fileContent;
    }

    public void setFileContent(String string) {
        this.fileContent = string;
    }

    public int getTaskerNumber() {
        return this.taskerNumber;
    }

    public void setTaskerNumber(int n) {
        this.taskerNumber = n;
    }

    public String getDateReunion() {
        return this.dateReunion;
    }

    public void setDateReunion(String string) {
        this.dateReunion = string;
    }

    public String getDateSessionVoucher() {
        return this.dateSessionVoucher;
    }

    public void setDateSessionVoucher(String string) {
        this.dateSessionVoucher = string;
    }

    public String getNumeroTicket() {
        return this.numeroTicket;
    }

    public void setNumeroTicket(String string) {
        this.numeroTicket = string;
    }

    public String getNumeroReunion() {
        return this.numeroReunion;
    }

    public void setNumeroReunion(String string) {
        this.numeroReunion = string;
    }

    public String getNumeroCourse() {
        return this.numeroCourse;
    }

    public void setNumeroCourse(String string) {
        this.numeroCourse = string;
    }

    public String getTerminalIp() {
        return this.terminalIp;
    }

    public void setTerminalIp(String string) {
        this.terminalIp = string;
    }

    public long getIdContract() {
        return this.idContract;
    }

    public void setIdContract(long l) {
        this.idContract = l;
    }

    public long getSystemGMTTimeMS() {
        return this.systemGMTTimeMS;
    }

    public void setSystemGMTTimeMS(long l) {
        this.systemGMTTimeMS = l;
    }
}

