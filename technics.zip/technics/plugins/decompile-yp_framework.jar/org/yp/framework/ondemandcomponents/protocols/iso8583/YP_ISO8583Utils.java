/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.iso8583;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.protocols.iso8583.YP_ISO8583Exception;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.iso8583.ISO8583LengthType;
import org.yp.xml.jaxb.iso8583.ISO8583Message;

public class YP_ISO8583Utils {
    public static final char ISOTrackStx = '%';
    public static final char ISOTrackFormatCode = 'B';
    public static final char ISOTrackSeparator = '^';
    public static final char ISOTrackEtx = '?';
    private final YP_Object father;
    private String myTag;
    private int myFormatedLength;
    private int myLength;
    private String myValue;
    private FieldFormat myFieldFormat;
    private DataFormat myTransmissionFormat;
    private DataFormat myDataFormat;
    private DataFormat myGroupDataFormat;
    private byte[] myFormatedData;
    private byte[] myValueFromTLV;
    private int myParsingIndex;
    private int lengthOfTag;
    private int lengthOfLength;
    private int lengthOfFieldLength;
    public ISO8583Message myISO8583Message;
    private int myEndTlvIndex;

    public static DataFormat getMyDataFormat(String string) {
        if (string == null) {
            return null;
        }
        switch (string) {
            case "ISO8583Alpha": {
                return DataFormat.ALPHA;
            }
            case "ISO8583Num": {
                return DataFormat.NUMERIC;
            }
            case "ISO8583NumEBCDIC": {
                return DataFormat.NUMERIC_EBCDIC;
            }
            case "ISO8583AlphaNum": {
                return DataFormat.ALPHANUM;
            }
            case "ISO8583AlphaNumSpecial": {
                return DataFormat.ALPHANUM;
            }
            case "ISO8583AlphaNumEBCDIC": {
                return DataFormat.ALPHANUM_EBCDIC;
            }
            case "ISO8583AlphaNumSpecialEBCDIC": {
                return DataFormat.ALPHANUM_EBCDIC;
            }
            case "ISO8583Binary": {
                return DataFormat.BINARY;
            }
            case "ISO8583ISO23Rep": {
                return DataFormat.ISO_TRACK;
            }
            case "ISO8583CMC7": {
                return DataFormat.CMC7_TRACK;
            }
            case "ISO8583DebCred": {
                return DataFormat.ALPHA;
            }
            case "DigitString": {
                return DataFormat.DIGIT_STRING;
            }
            case "DigitStringEBCDIC": {
                return DataFormat.DIGIT_STRING_EBCDIC;
            }
        }
        return DataFormat.NUMERIC;
    }

    public static FieldFormat getMyFieldFormat(ISO8583LengthType iSO8583LengthType) {
        return YP_ISO8583Utils.getMyFieldFormat(iSO8583LengthType.name());
    }

    private static FieldFormat getMyFieldFormat(String string) {
        switch (string) {
            case "FIXE": {
                return FieldFormat.fixe;
            }
            case "VARIABLE": {
                return FieldFormat.variable;
            }
            case "NVAR": {
                return FieldFormat.NVAR;
            }
            case "NNVAR": {
                return FieldFormat.NNVAR;
            }
            case "AVAR": {
                return FieldFormat.AVAR;
            }
            case "AAVAR": {
                return FieldFormat.AAVAR;
            }
            case "AAAVAR": {
                return FieldFormat.AAAVAR;
            }
            case "NNEEVAR": {
                return FieldFormat.NNEEVAR;
            }
            case "NNNEEVAR": {
                return FieldFormat.NNNEEVAR;
            }
            case "LVAR": {
                return FieldFormat.LVAR;
            }
            case "LLVAR": {
                return FieldFormat.LLVAR;
            }
            case "LLLVAR": {
                return FieldFormat.LLLVAR;
            }
            case "TTLV_A": {
                return FieldFormat.TTLV_a;
            }
            case "TTLV_B": {
                return FieldFormat.TTLV_b;
            }
            case "TTLLV_B": {
                return FieldFormat.TTLLV_b;
            }
            case "TTLLV_C": {
                return FieldFormat.TTLLV_c;
            }
            case "TTLLLV_C": {
                return FieldFormat.TTLLLV_c;
            }
            case "TTTTLLLLV_C": {
                return FieldFormat.TTTTLLLLV_c;
            }
            case "STRUCTURE": {
                return FieldFormat.structure;
            }
            case "BER_TLV": {
                return FieldFormat.BER_TLV;
            }
            case "TTLLV_ZC": {
                return FieldFormat.TTLLV_zc;
            }
        }
        String string2 = string.toUpperCase();
        if (!string2.contentEquals(string)) {
            return YP_ISO8583Utils.getMyFieldFormat(string2);
        }
        return FieldFormat.fixe;
    }

    public YP_ISO8583Utils(YP_Object yP_Object, FieldFormat fieldFormat, DataFormat dataFormat, DataFormat dataFormat2, int n) {
        this.father = yP_Object;
        this.YP_SetFormat(fieldFormat, dataFormat, dataFormat2, n);
        this.myEndTlvIndex = -1;
    }

    public YP_ISO8583Utils(YP_Object yP_Object) {
        this.father = yP_Object;
    }

    public void YP_SetFieldFormat(DataFormat dataFormat) {
        this.myDataFormat = dataFormat;
        switch (this.myDataFormat) {
            case NUMERIC: 
            case HHMMSS: 
            case AAMM: 
            case MMJJ: {
                this.myGroupDataFormat = DataFormat.NUMERIC;
                return;
            }
            case NUMERIC_EBCDIC: {
                this.myGroupDataFormat = DataFormat.NUMERIC_EBCDIC;
                return;
            }
            case BINARY: {
                this.myGroupDataFormat = DataFormat.BINARY;
                return;
            }
            case ALPHA: 
            case ALPHANUM: {
                this.myGroupDataFormat = DataFormat.ALPHA;
                return;
            }
            case ALPHANUM_EBCDIC: {
                this.myGroupDataFormat = DataFormat.ALPHANUM_EBCDIC;
                return;
            }
            case NUMERIC_SIGNED: {
                this.myGroupDataFormat = DataFormat.NUMERIC_SIGNED;
                return;
            }
            case ISO_TRACK: {
                this.myGroupDataFormat = DataFormat.ISO_TRACK;
                return;
            }
            case CMC7_TRACK: {
                this.myGroupDataFormat = DataFormat.CMC7_TRACK;
                return;
            }
            case DIGIT_STRING: {
                this.myGroupDataFormat = DataFormat.DIGIT_STRING;
                return;
            }
            case DIGIT_STRING_EBCDIC: {
                this.myGroupDataFormat = DataFormat.DIGIT_STRING_EBCDIC;
                return;
            }
        }
        this.father.logger(2, "YP_SetFieldFormat() Unknown format");
    }

    public final void YP_SetFormat(FieldFormat fieldFormat, DataFormat dataFormat, DataFormat dataFormat2, int n) {
        this.myFieldFormat = fieldFormat;
        switch (this.myFieldFormat) {
            case fixe: {
                break;
            }
            case variable: {
                break;
            }
            case NVAR: 
            case AVAR: 
            case LVAR: {
                this.lengthOfFieldLength = 1;
                break;
            }
            case NNVAR: 
            case AAVAR: 
            case NNEEVAR: 
            case LLVAR: {
                this.lengthOfFieldLength = 2;
                break;
            }
            case AAAVAR: 
            case NNNEEVAR: 
            case LLLVAR: {
                this.lengthOfFieldLength = 3;
                break;
            }
            case TTLV_a: {
                this.lengthOfTag = 2;
                this.lengthOfLength = 1;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case TTLV_b: {
                this.lengthOfTag = 2;
                this.lengthOfLength = 1;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case TTLLV_b: 
            case TTLLV_c: 
            case TTLLV_zc: {
                this.lengthOfLength = 2;
                this.lengthOfTag = 2;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case TTLLLV_c: {
                this.lengthOfTag = 2;
                this.lengthOfLength = 3;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case TTTTLLLLV_c: {
                this.lengthOfLength = 4;
                this.lengthOfTag = 4;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            case BER_TLV: {
                this.lengthOfTag = -1;
                this.lengthOfLength = -1;
                this.lengthOfFieldLength = n;
                this.myEndTlvIndex = -1;
                break;
            }
            default: {
                this.father.logger(2, "YP_SetFormat() Unknown format");
                return;
            }
        }
        this.myTransmissionFormat = dataFormat2;
        this.YP_SetFieldFormat(dataFormat);
    }

    public void YP_SetMyLength(int n) {
        if (n > 0) {
            this.myLength = n;
        }
    }

    public void YP_SetTag(String string) {
        if (string != null && string.length() != 0) {
            this.myTag = string;
        }
    }

    public String YP_GetTag() {
        return this.myTag;
    }

    public void setValue(String string) {
        if (string != null && string.length() != 0) {
            this.myValue = string;
        }
    }

    public String getValue() throws YP_ISO8583Exception {
        if (this.myFieldFormat == FieldFormat.TTLV_b || this.myFieldFormat == FieldFormat.TTLLV_b) {
            if (this.myGroupDataFormat == DataFormat.ALPHA) {
                try {
                    this.myValue = new String(this.myValueFromTLV, "ISO-8859-1");
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    this.father.logger(2, "getValue() " + unsupportedEncodingException);
                    throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                }
            }
            if (this.myGroupDataFormat == DataFormat.ALPHANUM_EBCDIC) {
                try {
                    this.myValue = new String(this.myValueFromTLV, "ISO-8859-1");
                }
                catch (Exception exception) {
                    this.father.logger(2, "getValue() " + exception);
                    throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                }
            }
        }
        if (this.myFieldFormat == FieldFormat.BER_TLV) {
            if (this.myGroupDataFormat == DataFormat.ALPHA) {
                try {
                    this.myValue = new String(this.myValueFromTLV, "ISO-8859-1");
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    this.father.logger(2, "getValue() " + unsupportedEncodingException);
                    throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
                }
            }
            try {
                this.myValue = UtilsYP.devHexa(this.myValueFromTLV);
            }
            catch (Exception exception) {
                this.father.logger(2, "getValue() " + exception);
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            }
        }
        return this.myValue;
    }

    public void YP_ResetFormatedTLV() {
        this.myFormatedData = new byte[0];
    }

    public void YP_SetFormatedTLV(byte[] byArray) {
        if (byArray != null && byArray.length != 0) {
            this.myFormatedData = byArray;
        }
    }

    public byte[] YP_GetFormatedData() {
        return this.myFormatedData;
    }

    public byte[] YP_GetValueFromTLV() {
        return this.myValueFromTLV;
    }

    public int YP_GetFormatedLength() {
        return this.myFormatedLength;
    }

    public int YP_FormatData() throws YP_ISO8583Exception {
        if (!this.isDataFormatValid()) {
            this.father.logger(2, "YP_FormatData() data format not valid");
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, null, null, null);
        }
        switch (this.myFieldFormat) {
            case fixe: {
                this.YP_SetFixValue();
                return 1;
            }
            case variable: {
                this.YP_SetVariableValue();
                return 1;
            }
            case LVAR: 
            case LLVAR: 
            case LLLVAR: {
                if (this.myFieldFormat == FieldFormat.LVAR && this.myLength > 255) {
                    this.father.logger(2, "YP_FormatData() WTF ???");
                    this.myFieldFormat = FieldFormat.LLVAR;
                    this.lengthOfFieldLength = 2;
                }
                this.YP_SetLVariableValue();
                return 1;
            }
            case NVAR: 
            case NNVAR: {
                if (this.myFieldFormat == FieldFormat.NVAR && this.myLength > 99) {
                    this.father.logger(2, "YP_FormatData() WTF ???");
                    this.myFieldFormat = FieldFormat.NNVAR;
                    this.lengthOfFieldLength = 2;
                }
                this.YP_SetNVariableValue();
                return 1;
            }
            case AVAR: 
            case AAVAR: 
            case AAAVAR: {
                if (this.myFieldFormat == FieldFormat.AVAR && this.myLength > 99) {
                    this.father.logger(2, "YP_FormatData() WTF ???");
                    this.myFieldFormat = FieldFormat.AAVAR;
                    this.lengthOfFieldLength = 2;
                }
                this.YP_SetAVariableValue();
                return 1;
            }
            case NNEEVAR: 
            case NNNEEVAR: {
                this.YP_SetNEEVariableValue();
                return 1;
            }
            case TTLV_a: {
                this.YP_Set_TLV_a(true);
                return 1;
            }
            case TTLV_b: 
            case TTLLV_b: {
                this.YP_Set_TLV_b();
                return 1;
            }
            case TTLLV_c: 
            case TTLLLV_c: 
            case TTTTLLLLV_c: {
                this.YP_Set_TLV_c();
                return 1;
            }
            case TTLLV_zc: {
                this.YP_Set_TLV_zc();
                return 1;
            }
            case BER_TLV: {
                this.YP_Set_BER_TLV();
                return 1;
            }
        }
        this.father.logger(2, "YP_FormatData() unknown format:" + (Object)((Object)this.myFieldFormat));
        return -1;
    }

    public int YP_FormatTLVData(byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            this.father.logger(2, "YP_FormatTLVData() null or empty");
            return -1;
        }
        switch (this.myFieldFormat) {
            case TTLV_b: 
            case TTLLV_b: {
                this.YP_Set_TLV_b(byArray);
                return 1;
            }
            case TTLLV_c: 
            case TTLLLV_c: 
            case TTTTLLLLV_c: 
            case TTLLV_zc: {
                this.YP_Set_TLV_c(byArray);
                return 1;
            }
            case BER_TLV: {
                this.YP_Set_BER_TLV();
                return 1;
            }
        }
        this.father.logger(2, "YP_FormatTLVData() bad field format " + (Object)((Object)this.myFieldFormat));
        return 0;
    }

    public int YP_ParseData(boolean bl) throws YP_ISO8583Exception {
        if (bl) {
            this.myParsingIndex = 0;
        }
        if (this.myParsingIndex >= this.myFormatedData.length) {
            return 0;
        }
        switch (this.myFieldFormat) {
            case fixe: {
                this.YP_GetFixValue();
                break;
            }
            case variable: {
                this.YP_GetVariableValue();
                break;
            }
            case LVAR: 
            case LLVAR: 
            case LLLVAR: {
                this.YP_GetLVariableValue();
                break;
            }
            case NVAR: 
            case NNVAR: {
                this.YP_GetNVariableValue();
                break;
            }
            case AVAR: {
                this.YP_GetAVariableValue(1);
                break;
            }
            case AAVAR: {
                this.YP_GetAVariableValue(2);
                break;
            }
            case AAAVAR: {
                this.YP_GetAVariableValue(3);
                break;
            }
            case NNEEVAR: 
            case NNNEEVAR: {
                this.YP_GetNEEVariableValue();
                break;
            }
            case TTLV_a: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    String string = new String(byArray);
                    int n = Integer.parseInt(string);
                    this.myEndTlvIndex = this.myParsingIndex + n;
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                this.lengthOfTag = 1;
                if (this.YP_Get_TLV_b() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_TLV_b error ");
                return -1;
            }
            case TTLV_b: 
            case TTLLV_b: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    this.myEndTlvIndex = this.myParsingIndex + this.ConvertByteToDecimal(byArray);
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                if (this.YP_Get_TLV_b() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_TLV_b error ");
                return -1;
            }
            case TTLLV_c: 
            case TTLLLV_c: 
            case TTTTLLLLV_c: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    this.myEndTlvIndex = this.myParsingIndex + this.ConvertByteToDecimal(byArray);
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                if (this.YP_Get_TLV_c() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_TLV_c error ");
                return -1;
            }
            case TTLLV_zc: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    this.myEndTlvIndex = this.myParsingIndex + this.ConvertByteToDecimal(byArray);
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                if (this.YP_Get_TLV_zc() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_TLV_zc error ");
                return -1;
            }
            case BER_TLV: {
                if (this.myEndTlvIndex == -1) {
                    byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + this.lengthOfFieldLength);
                    this.myParsingIndex += this.lengthOfFieldLength;
                    this.myEndTlvIndex = this.myParsingIndex + this.ConvertByteDCBToDecimal(byArray);
                }
                if (this.myParsingIndex >= this.myEndTlvIndex) {
                    return 0;
                }
                if (this.YP_Get_BER_TLV() == 1) break;
                this.father.logger(2, "YP_ParseData() YP_Get_BER_TLV error ");
                return -1;
            }
            default: {
                this.father.logger(2, "YP_ParseData() bad field format " + (Object)((Object)this.myFieldFormat));
                return -1;
            }
        }
        if (!this.isDataFormatValid()) {
            this.father.logger(2, "YP_ParseData() data format not valid");
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.syntaxError, null, null, null);
        }
        return 1;
    }

    public static boolean YP_IsNumeric(String string) {
        if (string == null) {
            return false;
        }
        int n = string.length();
        if (n == 0) {
            return false;
        }
        int n2 = 0;
        while (n2 < n) {
            char c = string.charAt(n2);
            if (c < '0' || c > '9') {
                return false;
            }
            ++n2;
        }
        return true;
    }

    public static boolean YP_IsAlpha(String string) {
        int n = 0;
        while (n < string.length()) {
            if (!Character.isLetter(string.charAt(n))) {
                return false;
            }
            ++n;
        }
        return true;
    }

    public static boolean YP_IsNumericOrAlpha(String string) {
        int n = 0;
        while (n < string.length()) {
            if (!Character.isLetterOrDigit(string.charAt(n))) {
                return false;
            }
            ++n;
        }
        return true;
    }

    public static boolean YP_IsXFormat(String string) {
        if (string == null) {
            return false;
        }
        int n = string.length();
        if (n == 0) {
            return false;
        }
        char c = string.charAt(0);
        if (c != 'C' && c != 'D' && c != 'c' && c != 'd') {
            return false;
        }
        int n2 = 1;
        while (n2 < n) {
            char c2 = string.charAt(n2);
            if (c2 < '0' || c2 > '9') {
                return false;
            }
            ++n2;
        }
        return true;
    }

    public static boolean YP_IsTrack1Format(String string) {
        return true;
    }

    public static boolean YP_IsZFormat(String string) {
        if (string == null) {
            return false;
        }
        int n = string.length();
        if (n == 0) {
            return true;
        }
        if (string.charAt(0) == '%') {
            return YP_ISO8583Utils.YP_IsTrack1Format(string);
        }
        int n2 = string.indexOf(68);
        if (n2 <= 0 && (n2 = string.indexOf(61)) <= 0) {
            return false;
        }
        int n3 = 0;
        while (n3 < n2) {
            char c = string.charAt(n3);
            if (c < '0' || c > '9') {
                return false;
            }
            ++n3;
        }
        return true;
    }

    public boolean isDataFormatValid() {
        switch (this.myDataFormat) {
            case NUMERIC: 
            case NUMERIC_EBCDIC: 
            case DIGIT_STRING: 
            case DIGIT_STRING_EBCDIC: {
                return YP_ISO8583Utils.YP_IsNumeric(this.myValue);
            }
            case BINARY: {
                return true;
            }
            case ALPHA: {
                return YP_ISO8583Utils.YP_IsAlpha(this.myValue);
            }
            case ALPHANUM: {
                return true;
            }
            case ALPHANUM_EBCDIC: {
                return true;
            }
            case NUMERIC_SIGNED: {
                return YP_ISO8583Utils.YP_IsXFormat(this.myValue);
            }
            case ISO_TRACK: {
                this.father.logger(3, "isDataFormatValid() TODO Check this");
                return true;
            }
            case CMC7_TRACK: {
                return true;
            }
            case HHMMSS: {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HHmmss");
                simpleDateFormat.setLenient(false);
                try {
                    simpleDateFormat.parse(this.myValue);
                }
                catch (ParseException parseException) {
                    this.father.logger(2, "isDataFormatValid() HHMMSS " + this.myValue + " " + parseException);
                    return false;
                }
                return true;
            }
            case AAMM: {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyMM");
                simpleDateFormat.setLenient(false);
                try {
                    simpleDateFormat.parse(this.myValue);
                }
                catch (ParseException parseException) {
                    this.father.logger(2, "isDataFormatValid() AAMM " + this.myValue + " " + parseException);
                    return false;
                }
                return true;
            }
            case MMJJ: {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMdd");
                simpleDateFormat.setLenient(false);
                try {
                    simpleDateFormat.parse(this.myValue);
                }
                catch (ParseException parseException) {
                    this.father.logger(2, "isDataFormatValid() MMJJ " + this.myValue + " " + parseException);
                    return false;
                }
                return true;
            }
        }
        this.father.logger(2, "isDataFormatValid() unknown format" + (Object)((Object)this.myDataFormat));
        return false;
    }

    private static byte[] YP_ISO8583ToBcd(String string) {
        if (string.length() % 2 == 1) {
            string = String.valueOf('0') + string;
        }
        byte[] byArray = new byte[string.length() / 2];
        int n = 0;
        int n2 = 0;
        while (n < string.length()) {
            byArray[n2] = (byte)(string.charAt(n) - 48 << 4 | string.charAt(n + 1) - 48);
            n += 2;
            ++n2;
        }
        return byArray;
    }

    private static StringBuilder YP_FormatPaddingTag(int n, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = n - string.length();
        int n3 = 0;
        while (n3 < n2) {
            stringBuilder.append('0');
            ++n3;
        }
        stringBuilder.append(string);
        return stringBuilder;
    }

    private static StringBuilder YP_FormatPaddingEBCDICTag(int n, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = n - string.length();
        int n3 = 0;
        while (n3 < n2) {
            stringBuilder.append('0');
            ++n3;
        }
        stringBuilder.append(EBCDICConverter.convertASCIIToEBCDIC(string));
        return stringBuilder;
    }

    private static StringBuilder YP_FormatPaddingString(int n, String string) {
        StringBuilder stringBuilder = new StringBuilder(string);
        int n2 = n - string.length();
        int n3 = 0;
        while (n3 < n2) {
            stringBuilder.append(' ');
            ++n3;
        }
        return stringBuilder;
    }

    private static StringBuilder YP_FormatPaddingHexa(int n, int n2) {
        String string = Integer.toHexString(n2);
        StringBuilder stringBuilder = new StringBuilder(n);
        int n3 = n - string.length();
        int n4 = 0;
        while (n4 < n3) {
            stringBuilder.append('0');
            ++n4;
        }
        stringBuilder.append(string);
        return stringBuilder;
    }

    private static StringBuilder YP_FormatPadding(int n, int n2) {
        String string = Integer.toString(n2);
        StringBuilder stringBuilder = new StringBuilder(n);
        int n3 = n - string.length();
        int n4 = 0;
        while (n4 < n3) {
            stringBuilder.append('0');
            ++n4;
        }
        stringBuilder.append(string);
        return stringBuilder;
    }

    private static String YP_FormatPaddingEBCDIC(int n, int n2) {
        String string = Integer.toString(n2);
        StringBuilder stringBuilder = new StringBuilder(n);
        int n3 = n - string.length();
        int n4 = 0;
        while (n4 < n3) {
            stringBuilder.append('0');
            ++n4;
        }
        stringBuilder.append(string);
        return EBCDICConverter.convertASCIIToEBCDIC(stringBuilder.toString());
    }

    private static String YP_TrimLeadingZeroes(String string) {
        int n = 0;
        while (n < string.length()) {
            if (string.charAt(n) != '0' || string.charAt(n + 1) != '0') {
                return string.substring(n);
            }
            n += 2;
        }
        return null;
    }

    private static String YP_TrimNumericLeadingZeroes(String string) {
        if (string == null || string.isEmpty()) {
            return string;
        }
        int n = 0;
        while (n < string.length()) {
            if (string.charAt(n) != '0') {
                return string.substring(n);
            }
            ++n;
        }
        return "0";
    }

    private byte[] YP_ExtractData(byte[] byArray, int n, int n2) {
        if (n < 0 || n2 < 0) {
            this.father.logger(2, "YP_ExtractData() bad indexes");
            return null;
        }
        if (n > n2) {
            this.father.logger(2, "YP_ExtractData() bad indexes");
            return null;
        }
        byte[] byArray2 = new byte[n2 - n];
        int n3 = 0;
        while (n3 < n2 - n) {
            byArray2[n3] = byArray[n3 + n];
            ++n3;
        }
        return byArray2;
    }

    private static byte[] ConvertDecimalToByte(int n, int n2) {
        Object object;
        String string = Integer.toHexString(n);
        int n3 = 2 * n2 - string.length();
        if (n3 > 0) {
            object = new StringBuilder("");
            int n4 = 0;
            while (n4 < n3) {
                ((StringBuilder)object).append('0');
                ++n4;
            }
            ((StringBuilder)object).append(string);
            string = ((StringBuilder)object).toString();
        }
        object = new byte[string.length() / 2];
        UtilsYP.redHexa((byte[])object, string, string.length() / 2);
        return object;
    }

    private static byte[] ConvertDecimalToByteDCB(int n, int n2) {
        String string = "" + n;
        int n3 = 2 * n2 - string.length();
        if (n3 > 0) {
            StringBuilder stringBuilder = new StringBuilder("");
            int n4 = 0;
            while (n4 < n3) {
                stringBuilder.append('0');
                ++n4;
            }
            stringBuilder.append(string);
            string = stringBuilder.toString();
            byte[] byArray = new byte[string.length() / 2];
            UtilsYP.redHexa(byArray, string, string.length() / 2);
            return byArray;
        }
        byte[] byArray = new byte[n2];
        UtilsYP.redHexa(byArray, string, string.length() / 2);
        return byArray;
    }

    public int ConvertByteToDecimal(byte[] byArray) {
        return Integer.parseInt(UtilsYP.devHexa(byArray), 16);
    }

    public int ConvertByteDCBToDecimal(byte[] byArray) {
        return Integer.parseInt(UtilsYP.devHexa(byArray));
    }

    private byte[] YP_AppendFormatedData(byte[] byArray, byte[] byArray2, int n, boolean bl) {
        if (byArray == null) {
            byArray = new byte[n + byArray2.length];
            System.arraycopy(byArray2, 0, byArray, n, byArray2.length);
            if (n > 0) {
                byte[] byArray3 = bl ? String.format("%03d", byArray2.length).getBytes() : YP_ISO8583Utils.ConvertDecimalToByte(byArray2.length, n);
                System.arraycopy(byArray3, 0, byArray, 0, n);
            }
        } else {
            byte[] byArray4 = byArray;
            byArray = new byte[byArray4.length + byArray2.length];
            System.arraycopy(byArray4, 0, byArray, 0, byArray4.length);
            System.arraycopy(byArray2, 0, byArray, byArray4.length, byArray2.length);
            if (n > 0) {
                byte[] byArray5 = bl ? String.format("%03d", byArray4.length + byArray2.length - n).getBytes() : YP_ISO8583Utils.ConvertDecimalToByte(byArray4.length + byArray2.length - n, n);
                System.arraycopy(byArray5, 0, byArray, 0, n);
            }
        }
        return byArray;
    }

    private byte[] YP_AppendFormatedData(byte[] byArray, byte[] byArray2, int n) {
        return this.YP_AppendFormatedData(byArray, byArray2, n, false);
    }

    private byte[] YP_AppendFormatedDataDCBLg(byte[] byArray, byte[] byArray2, int n) {
        if (byArray == null) {
            byArray = new byte[n + byArray2.length];
            System.arraycopy(byArray2, 0, byArray, n, byArray2.length);
            if (n > 0) {
                byte[] byArray3 = YP_ISO8583Utils.ConvertDecimalToByteDCB(byArray2.length, n);
                System.arraycopy(byArray3, 0, byArray, 0, n);
            }
        } else {
            byte[] byArray4 = byArray;
            byArray = new byte[byArray4.length + byArray2.length];
            System.arraycopy(byArray4, 0, byArray, 0, byArray4.length);
            System.arraycopy(byArray2, 0, byArray, byArray4.length, byArray2.length);
            if (n > 0) {
                byte[] byArray5 = YP_ISO8583Utils.ConvertDecimalToByteDCB(byArray4.length + byArray2.length - n, n);
                System.arraycopy(byArray5, 0, byArray, 0, n);
            }
        }
        return byArray;
    }

    private byte[] YP_Set_TLV_a(boolean bl) {
        byte[] byArray;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.myTag);
        switch (this.myDataFormat) {
            case NUMERIC: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder2);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.myTag.length() + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            case BINARY: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                StringBuilder stringBuilder3 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder3);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.myTag.length() / 2 + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            default: {
                StringBuilder stringBuilder4 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length());
                stringBuilder.append((CharSequence)stringBuilder4);
                try {
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes("ISO-8859-1")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes()));
                }
                byArray = new byte[this.myTag.length() + this.lengthOfLength + this.myValue.length()];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
            }
        }
        this.myFormatedData = bl ? this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength, true) : this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength, false);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_b(byte[] byArray) {
        StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(2 * this.lengthOfTag, this.myTag);
        StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, byArray.length);
        stringBuilder.append((CharSequence)stringBuilder2);
        byte[] byArray2 = new byte[stringBuilder.length() / 2];
        UtilsYP.redHexa(byArray2, stringBuilder.toString(), stringBuilder.length() / 2);
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray2, this.lengthOfFieldLength);
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_b() {
        byte[] byArray;
        StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(2 * this.lengthOfTag, this.myTag);
        switch (this.myDataFormat) {
            case NUMERIC: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder2);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.lengthOfTag + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            case BINARY: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                StringBuilder stringBuilder3 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder3);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.lengthOfTag + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            default: {
                StringBuilder stringBuilder4 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length());
                stringBuilder.append((CharSequence)stringBuilder4);
                try {
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes("ISO-8859-1")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes()));
                }
                byArray = new byte[this.lengthOfTag + this.lengthOfLength + this.myValue.length()];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
            }
        }
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_c(byte[] byArray) {
        byte[] byArray2;
        StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.lengthOfTag, this.myTag);
        StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPadding(this.lengthOfLength, byArray.length);
        stringBuilder.append((CharSequence)stringBuilder2);
        try {
            byArray2 = stringBuilder.toString().getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray2 = stringBuilder.toString().getBytes();
        }
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray2, 0);
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_c() {
        byte[] byArray;
        StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.lengthOfTag, this.myTag);
        StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPadding(this.lengthOfLength, this.myValue.length());
        stringBuilder.append((CharSequence)stringBuilder2);
        stringBuilder.append(this.myValue);
        try {
            byArray = stringBuilder.toString().getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = stringBuilder.toString().getBytes();
        }
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private byte[] YP_Set_TLV_zc() {
        byte[] byArray;
        StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingEBCDICTag(this.lengthOfTag, this.myTag);
        stringBuilder.append(YP_ISO8583Utils.YP_FormatPaddingEBCDIC(this.lengthOfLength, this.myValue.length()));
        stringBuilder.append(EBCDICConverter.convertASCIIToEBCDIC(this.myValue));
        try {
            byArray = stringBuilder.toString().getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = stringBuilder.toString().getBytes();
        }
        this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, this.lengthOfFieldLength);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private int YP_Get_TLV_c() {
        try {
            byte[] byArray = new byte[this.lengthOfTag];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfTag);
            this.myParsingIndex += this.lengthOfTag;
            this.myTag = new String(byArray, "ISO-8859-1");
            this.myTag = YP_ISO8583Utils.YP_TrimLeadingZeroes(this.myTag);
            byArray = new byte[this.lengthOfLength];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfLength);
            this.myParsingIndex += this.lengthOfLength;
            int n = Integer.parseInt(new String(byArray, "ISO-8859-1"));
            this.myValueFromTLV = new byte[n];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, this.myValueFromTLV, 0, n);
            this.myParsingIndex += n;
            this.myValue = new String(this.myValueFromTLV, "ISO-8859-1");
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "YP_Get_TLV_c() " + exception);
            return -1;
        }
    }

    private int YP_Get_TLV_zc() {
        try {
            byte[] byArray = new byte[this.lengthOfTag];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfTag);
            this.myParsingIndex += this.lengthOfTag;
            this.myTag = new String(EBCDICConverter.convertEBCDICToASCII(byArray), "ISO-8859-1");
            byArray = new byte[this.lengthOfLength];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, byArray, 0, this.lengthOfLength);
            this.myParsingIndex += this.lengthOfLength;
            int n = Integer.parseInt(new String(EBCDICConverter.convertEBCDICToASCII(byArray), "ISO-8859-1"));
            this.myValueFromTLV = new byte[n];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, this.myValueFromTLV, 0, n);
            this.myParsingIndex += n;
            this.myValue = new String(EBCDICConverter.convertEBCDICToASCII(this.myValueFromTLV), "ISO-8859-1");
            return 1;
        }
        catch (Exception exception) {
            this.father.logger(2, "YP_Get_TLV_zc() " + exception);
            return -1;
        }
    }

    private int YP_Get_TLV_b() {
        try {
            this.myTag = YP_ISO8583Utils.YP_TrimLeadingZeroes(UtilsYP.devHexa(this.myFormatedData, this.myParsingIndex, this.lengthOfTag));
            this.myParsingIndex += this.lengthOfTag;
            int n = Integer.parseInt(UtilsYP.devHexa(this.myFormatedData, this.myParsingIndex, this.lengthOfLength), 16);
            this.myParsingIndex += this.lengthOfLength;
            this.myValueFromTLV = new byte[n];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, this.myValueFromTLV, 0, n);
            this.myParsingIndex += n;
            this.myValue = this.myDataFormat == DataFormat.ALPHA ? this.myValueFromTLV.toString() : UtilsYP.devHexa(this.myValueFromTLV);
        }
        catch (Exception exception) {
            this.father.logger(2, "YP_Get_TLV_b() " + exception);
            return -1;
        }
        return 1;
    }

    private int YP_Get_BER_TLV() {
        try {
            int n;
            byte by;
            this.myTag = "";
            do {
                by = this.myFormatedData[this.myParsingIndex];
                this.myTag = String.valueOf(this.myTag) + UtilsYP.devHexa(this.myFormatedData, this.myParsingIndex, 1);
                ++this.myParsingIndex;
            } while ((by & 0x1F) == 31);
            int n2 = this.myFormatedData[this.myParsingIndex];
            ++this.myParsingIndex;
            if ((n2 & 0x80) == 128) {
                if (n2 == 128) {
                    int n3 = 1;
                    while ((this.myFormatedData[this.myParsingIndex] & 0x80) == 128) {
                        ++n3;
                    }
                    this.father.logger(2, "YP_Get_BER_TLV() TODO");
                    n = 0;
                    this.myParsingIndex += n3;
                } else {
                    int n4 = n2 & 0x7F;
                    n = Integer.parseInt(UtilsYP.devHexa(this.myFormatedData, this.myParsingIndex, n4), 16);
                    this.myParsingIndex += n4;
                }
            } else {
                n = n2;
            }
            this.myValueFromTLV = new byte[n];
            System.arraycopy(this.myFormatedData, this.myParsingIndex, this.myValueFromTLV, 0, n);
            this.myParsingIndex += n;
            this.myValue = this.myDataFormat == DataFormat.ALPHA ? this.myValueFromTLV.toString() : UtilsYP.devHexa(this.myValueFromTLV);
        }
        catch (Exception exception) {
            this.father.logger(2, "YP_Get_TLV_b() " + exception);
            return -1;
        }
        return 1;
    }

    private byte[] YP_Set_BER_TLV() {
        byte[] byArray = null;
        StringBuilder stringBuilder = new StringBuilder(this.myTag);
        switch (this.myDataFormat) {
            case NUMERIC: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                if (this.myValue.length() / 2 <= 255) {
                    this.lengthOfLength = 1;
                }
                this.lengthOfTag = this.myTag.length() / 2;
                StringBuilder stringBuilder2 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder2);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.lengthOfTag + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            case BINARY: {
                if (this.myValue.length() % 2 != 0) {
                    this.myValue = "0" + this.myValue;
                }
                if (this.myValue.length() / 2 <= 255) {
                    this.lengthOfLength = 1;
                }
                this.lengthOfTag = this.myTag.length() / 2;
                StringBuilder stringBuilder3 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length() / 2);
                stringBuilder.append((CharSequence)stringBuilder3);
                stringBuilder.append(this.myValue);
                byArray = new byte[this.lengthOfTag + this.lengthOfLength + this.myValue.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
                break;
            }
            default: {
                this.lengthOfTag = this.myTag.length();
                if (this.myValue.length() <= 255) {
                    this.lengthOfLength = 1;
                }
                StringBuilder stringBuilder4 = YP_ISO8583Utils.YP_FormatPaddingHexa(2 * this.lengthOfLength, this.myValue.length());
                stringBuilder.append((CharSequence)stringBuilder4);
                try {
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes("ISO-8859-1")));
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    unsupportedEncodingException.printStackTrace();
                    stringBuilder.append(UtilsYP.devHexa(this.myValue.getBytes()));
                }
                byArray = new byte[stringBuilder.length() / 2];
                UtilsYP.redHexa(byArray, stringBuilder.toString(), stringBuilder.length() / 2);
            }
        }
        this.myFormatedData = this.YP_AppendFormatedDataDCBLg(this.myFormatedData, byArray, this.lengthOfFieldLength);
        this.myFormatedLength = this.myFormatedData.length;
        return this.myFormatedData;
    }

    private void YP_SetLVariableValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                byArray = this.YP_SetLVariableNumericalValue();
                break;
            }
            case NUMERIC_EBCDIC: {
                byArray = this.YP_SetLVariableNumericalEBCDICValue();
                break;
            }
            case DIGIT_STRING: {
                this.father.logger(1, "YP_SetLVariableValue() DIGIT_STRING Not done");
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                this.father.logger(1, "YP_SetLVariableValue() DIGIT_STRING_EBCDIC Not done");
                break;
            }
            case ISO_TRACK: {
                byArray = this.YP_SetZValue();
                break;
            }
            case CMC7_TRACK: {
                byArray = this.YP_SetCMC7Value();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        byArray = this.YP_SetLVariableNumericalValue();
                        break block0;
                    }
                    case NUMERIC_EBCDIC: {
                        byArray = this.YP_SetLVariableNumericalEBCDICValue();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetLVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        byArray = this.YP_SetLVariableBinaryValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        byArray = this.YP_SetLVariableNumericalSignedValueBinary();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_SetLVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        byArray = this.YP_SetLVariableNumericalValueAlpha();
                        break block0;
                    }
                    case NUMERIC_EBCDIC: {
                        byArray = this.YP_SetLVariableNumericalEBCDICValueAlpha();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetLVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        byArray = this.YP_SetLVariableNumericalValueAlpha();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                    case ALPHANUM_EBCDIC: {
                        byArray = this.YP_SetLVariableAlphabeticalEBCCDICValueAlpha();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetLVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private void YP_GetLVariableValue() throws YP_ISO8583Exception {
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                this.YP_GetLVariableNumericalValue();
                break;
            }
            case NUMERIC_EBCDIC: {
                this.YP_GetLVariableNumericalEBCDICValue();
                break;
            }
            case DIGIT_STRING: {
                this.father.logger(1, "YP_GetLVariableValue() DIGIT_STRING Not done");
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                this.father.logger(1, "YP_GetLVariableValue() DIGIT_STRING_EBCDIC Not done");
                break;
            }
            case ISO_TRACK: {
                this.YP_GetZValue();
                break;
            }
            case CMC7_TRACK: {
                this.YP_GetCMC7Value();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        this.YP_GetLVariableNumericalValue();
                        break block0;
                    }
                    case ALPHA: {
                        this.YP_GetLVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        this.YP_GetLVariableBinaryValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        this.YP_GetLVariableNumericalSignedValueBinary();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_GetLVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case ALPHANUM_EBCDIC: {
                this.YP_GetLVariableAlphabeticalEBCDICValue();
                break;
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: {
                        this.YP_GetLVariableAlphabeticalValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                    case ISO_TRACK: {
                        this.YP_GetZVariableBinaryValue();
                        break block0;
                    }
                    case CMC7_TRACK: {
                        this.YP_GetCMC7VariableBinaryValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetLVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private byte[] YP_SetLVariableNumericalValueAlpha() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength) {
            byte[] byArray2;
            try {
                byArray2 = this.myValue.substring(this.myValue.length() - this.myLength).getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray2 = this.myValue.substring(this.myValue.length() - this.myLength).getBytes();
            }
            byArray = YP_ISO8583Utils.ConvertDecimalToByte(this.myLength + 1, this.lengthOfFieldLength);
            byArray = this.YP_AppendFormatedData(byArray, byArray2, 0);
        } else {
            byte[] byArray3;
            try {
                byArray3 = this.myValue.getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray3 = this.myValue.getBytes();
            }
            byArray = YP_ISO8583Utils.ConvertDecimalToByte(this.myValue.length() + 1, this.lengthOfFieldLength);
            byArray = this.YP_AppendFormatedData(byArray, byArray3, 0);
        }
        return byArray;
    }

    private byte[] YP_SetLVariableNumericalEBCDICValueAlpha() {
        return EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetLVariableNumericalEBCDICValueAlpha());
    }

    private byte[] YP_SetLVariableNumericalSignedValueBinary() {
        byte[] byArray;
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        try {
            byArray = this.myValue.substring(0, 1).getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = this.myValue.substring(0, 1).getBytes();
        }
        this.myValue = this.myValue.substring(1);
        byte[] byArray2 = this.YP_SetFixNumericalValue();
        byte[] byArray3 = YP_ISO8583Utils.ConvertDecimalToByte(this.myLength + 1, this.lengthOfFieldLength);
        this.myLength = n;
        byArray3 = this.YP_AppendFormatedData(byArray3, byArray, 0);
        byArray3 = this.YP_AppendFormatedData(byArray3, byArray2, 0);
        return byArray3;
    }

    private byte[] YP_SetLVariableNumericalValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixNumericalValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByte(this.myLength, this.lengthOfFieldLength);
        this.myLength = n;
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        return byArray2;
    }

    private byte[] YP_SetLVariableNumericalEBCDICValue() {
        return EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetLVariableNumericalValue());
    }

    private byte[] YP_SetZValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength * 2) {
            this.myLength = this.myValue.length() / 2 + this.myValue.length() % 2;
        }
        byte[] byArray = this.YP_SetFixBinaryValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByte(this.myValue.length(), this.lengthOfFieldLength);
        this.myLength = n;
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        return byArray2;
    }

    private byte[] YP_SetCMC7Value() {
        return this.YP_SetZValue();
    }

    private byte[] YP_SetLVariableBinaryValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength * 2) {
            this.myLength = this.myValue.length() / 2 + this.myValue.length() % 2;
        }
        byte[] byArray = this.YP_SetFixBinaryValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByte(byArray.length, this.lengthOfFieldLength);
        this.myLength = n;
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        return byArray2;
    }

    private byte[] YP_SetLVariableAlphabeticalValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixAlphabeticalValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByte(this.myLength, this.lengthOfFieldLength);
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        this.myLength = n;
        return byArray2;
    }

    private byte[] YP_SetLVariableAlphabeticalEBCCDICValueAlpha() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetFixAlphabeticalValue());
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByte(this.myLength, this.lengthOfFieldLength);
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        this.myLength = n;
        return byArray2;
    }

    private void YP_GetLVariableNumericalSignedValueBinary() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + 1);
        ++this.myParsingIndex;
        this.myValue = byArray.toString();
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, n);
        this.myParsingIndex += n;
        this.myValue = String.valueOf(this.myValue) + UtilsYP.devHexa(byArray);
        System.out.println("!!!!!!!!!!!!!!!!!!!!TODO not debugged!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    }

    private void YP_GetLVariableNumericalValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        if (n == 0) {
            this.myValue = "";
            return;
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2);
        if (byArray != null) {
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetLVariableNumericalEBCDICValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        if (n == 0) {
            this.myValue = "";
            return;
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2);
        if ((byArray = EBCDICConverter.convertEBCDICToASCII(byArray)) != null) {
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetZValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        if (n == 0) {
            this.myValue = "";
            return;
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2);
        if (byArray != null) {
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetCMC7Value() {
        this.YP_GetZValue();
    }

    private void YP_GetLVariableBinaryValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        if ((byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n)) != null) {
            this.myParsingIndex += n;
            this.myValue = UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetZVariableBinaryValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        if ((byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2)) != null) {
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetCMC7VariableBinaryValue() {
        this.YP_GetZVariableBinaryValue();
    }

    private void YP_GetLVariableAlphabeticalValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        this.myParsingIndex += n;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetLVariableAlphabeticalValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetLVariableAlphabeticalEBCDICValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteToDecimal(byArray);
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        byArray = EBCDICConverter.convertEBCDICToASCII(byArray);
        this.myParsingIndex += n;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetLVariableAlphabeticalEBCDICValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_SetVariableValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                byArray = this.YP_SetVariableBinaryValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: {
                        byArray = this.YP_SetVariableBinaryValue();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: {
                        byArray = this.YP_SetVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private void YP_GetVariableValue() throws YP_ISO8583Exception {
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                this.YP_GetVariableBinaryValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: {
                        this.YP_GetVariableBinaryValue();
                        break block0;
                    }
                    case ALPHA: {
                        this.YP_GetVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: {
                        this.YP_GetVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private byte[] YP_SetVariableBinaryValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength * 2) {
            this.myLength = this.myValue.length() / 2 + this.myValue.length() % 2;
        }
        byte[] byArray = this.YP_SetFixBinaryValue();
        this.myLength = n;
        return byArray;
    }

    private void YP_GetVariableBinaryValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myFormatedData.length);
        this.myParsingIndex = this.myFormatedData.length;
        this.myValue = UtilsYP.devHexa(byArray);
    }

    private byte[] YP_SetVariableAlphabeticalValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixAlphabeticalValue();
        this.myLength = n;
        return byArray;
    }

    private void YP_GetVariableAlphabeticalValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myFormatedData.length);
        this.myParsingIndex = this.myFormatedData.length;
        this.myValue = byArray.toString();
    }

    private void YP_SetNVariableValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                byArray = this.YP_SetNVariableNumericalValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        byArray = this.YP_SetNVariableNumericalValue();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetNVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        byArray = this.YP_SetNVariableBinaryValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: 
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        byArray = this.YP_SetNVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private void YP_SetAVariableValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetAVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetAVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: 
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        byArray = this.YP_SetAVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_SetAVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private void YP_GetNVariableValue() throws YP_ISO8583Exception {
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                this.YP_GetNVariableNumericalValue();
                break;
            }
            case ISO_TRACK: 
            case CMC7_TRACK: {
                this.YP_GetNVariableAlphabeticalValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        this.YP_GetNVariableNumericalValue();
                        break block0;
                    }
                    case ALPHA: {
                        this.YP_GetNVariableAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        this.YP_GetNVariableBinaryValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: {
                        this.YP_GetNVariableAlphabeticalValue();
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private void YP_GetAVariableValue(int n) throws YP_ISO8583Exception {
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                this.YP_GetAVariableNumericalValue(n);
                break;
            }
            case ISO_TRACK: 
            case CMC7_TRACK: {
                this.YP_GetAVariableAlphabeticalValue(n);
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        this.YP_GetAVariableNumericalValue(n);
                        break block0;
                    }
                    case ALPHA: {
                        this.YP_GetAVariableAlphabeticalValue(n);
                        break block0;
                    }
                    case BINARY: {
                        this.YP_GetAVariableBinaryValue(n);
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: 
                    case BINARY: 
                    case ALPHA: {
                        this.YP_GetAVariableAlphabeticalValue(n);
                        break block0;
                    }
                }
                this.father.logger(2, "YP_GetNVariableValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private byte[] YP_SetNVariableNumericalValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixNumericalValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByteDCB(this.myLength, this.lengthOfFieldLength);
        this.myLength = n;
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        return byArray2;
    }

    private void YP_GetNVariableNumericalValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteDCBToDecimal(byArray);
        if ((byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2)) != null) {
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetAVariableNumericalValue(int n) {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n2 = byArray[0] * 10 + byArray[1];
        switch (n) {
            default: {
                n2 = byArray[0] - 48;
                break;
            }
            case 2: {
                n2 = (byArray[0] - 48) * 10 + (byArray[1] - 48);
                break;
            }
            case 3: {
                n2 = (byArray[0] - 48) * 100 + (byArray[1] - 48) * 10 + (byArray[2] - 48);
            }
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n2 + 1) / 2);
        if (byArray != null) {
            this.myParsingIndex += (n2 + 1) / 2;
            this.myValue = n2 % 2 == 1 ? UtilsYP.devHexa(byArray).substring(1) : UtilsYP.devHexa(byArray);
        }
    }

    private byte[] YP_SetNVariableBinaryValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength * 2) {
            this.myLength = this.myValue.length() / 2 + this.myValue.length() % 2;
        }
        byte[] byArray = this.YP_SetFixBinaryValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByteDCB(byArray.length, this.lengthOfFieldLength);
        this.myLength = n;
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        return byArray2;
    }

    private void YP_GetNVariableBinaryValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteDCBToDecimal(byArray);
        if ((byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n)) != null) {
            this.myParsingIndex += n;
            this.myValue = UtilsYP.devHexa(byArray);
        }
    }

    private void YP_GetAVariableBinaryValue(int n) {
        int n2;
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        switch (n) {
            default: {
                n2 = byArray[0] - 48;
                break;
            }
            case 2: {
                n2 = (byArray[0] - 48) * 10 + (byArray[1] - 48);
                break;
            }
            case 3: {
                n2 = (byArray[0] - 48) * 100 + (byArray[1] - 48) * 10 + (byArray[2] - 48);
            }
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n2);
        if (byArray != null) {
            this.myParsingIndex += n2;
            this.myValue = UtilsYP.devHexa(byArray);
        }
    }

    private byte[] YP_SetAVariableAlphabeticalValue() {
        byte[] byArray;
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray2 = this.YP_SetFixAlphabeticalValue();
        switch (this.lengthOfFieldLength) {
            case 1: {
                byArray = String.format("%01d", byArray2.length).getBytes();
                break;
            }
            case 2: {
                byArray = String.format("%02d", byArray2.length).getBytes();
                break;
            }
            case 3: {
                byArray = String.format("%03d", byArray2.length).getBytes();
                break;
            }
            default: {
                byArray = String.format("%01d", byArray2.length).getBytes();
            }
        }
        byArray = this.YP_AppendFormatedData(byArray, byArray2, 0);
        this.myLength = n;
        return byArray;
    }

    private byte[] YP_SetNVariableAlphabeticalValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixAlphabeticalValue();
        byte[] byArray2 = YP_ISO8583Utils.ConvertDecimalToByteDCB(this.myLength, this.lengthOfFieldLength);
        byArray2 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        this.myLength = n;
        return byArray2;
    }

    private void YP_GetNVariableAlphabeticalValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        int n = this.ConvertByteDCBToDecimal(byArray);
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        this.myParsingIndex += n;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetNVariableAlphabeticalValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetAVariableAlphabeticalValue(int n) throws YP_ISO8583Exception {
        int n2;
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        switch (n) {
            default: {
                n2 = byArray[0] - 48;
                break;
            }
            case 2: {
                n2 = (byArray[0] - 48) * 10 + (byArray[1] - 48);
                break;
            }
            case 3: {
                n2 = (byArray[0] - 48) * 100 + (byArray[1] - 48) * 10 + (byArray[2] - 48);
            }
        }
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n2);
        this.myParsingIndex += n2;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetAVariableAlphabeticalValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_SetNEEVariableValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        switch (this.myTransmissionFormat) {
            case NUMERIC_EBCDIC: {
                byArray = this.YP_SetNEEVariableNumericalEbcdicValue();
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                byArray = this.YP_SetNEEVariableDigitStringEbcdicValue();
                break;
            }
            case BINARY: {
                byArray = this.YP_SetNEEVariableBinaryValue();
                break;
            }
            case ALPHANUM_EBCDIC: {
                byArray = this.YP_SetNEEVariableAlphabeticalEbcdicValue();
                break;
            }
            default: {
                this.father.logger(2, "YP_SetNEEVariableValue() unknown Transmission Data Format " + (Object)((Object)this.myTransmissionFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private void YP_GetNEEVariableValue() throws YP_ISO8583Exception {
        switch (this.myTransmissionFormat) {
            case NUMERIC_EBCDIC: {
                this.YP_GetNEEVariableNumericalEbcdicValue();
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                this.YP_GetNEEVariableDigitStringEbcdicValue();
                break;
            }
            case BINARY: {
                this.YP_GetNEEVariableBinaryValue();
                break;
            }
            case ALPHANUM_EBCDIC: {
                this.YP_GetNEEVariableAlphabeticalEbcdicValue();
                break;
            }
            default: {
                this.father.logger(2, "YP_GetNEEVariableValue() unknown Transmission Data Format " + (Object)((Object)this.myTransmissionFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private byte[] YP_SetNEEVariableDigitStringEbcdicValue() {
        int n = this.myLength;
        if (this.myValue.length() < this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixDigitStringEBCDICValue();
        byte[] byArray2 = String.format("%0" + this.lengthOfFieldLength + "d", this.myLength).getBytes();
        byte[] byArray3 = EBCDICConverter.convertASCIIToEBCDIC(byArray2);
        this.myLength = n;
        byte[] byArray4 = this.YP_AppendFormatedData(byArray3, byArray, 0);
        return byArray4;
    }

    private void YP_GetNEEVariableDigitStringEbcdicValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        byte[] byArray2 = EBCDICConverter.convertEBCDICToASCII(byArray);
        int n = Integer.parseInt(new String(byArray2));
        byte[] byArray3 = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        if (byArray3 != null) {
            byte[] byArray4 = EBCDICConverter.convertEBCDICToASCII(byArray3);
            this.myParsingIndex += n;
            this.myValue = new String(byArray4);
        }
    }

    private byte[] YP_SetNEEVariableNumericalEbcdicValue() {
        this.father.logger(2, "YP_SetNEEVariableNumericalEbcdicValue() not done");
        int n = this.myLength;
        if (this.myValue.length() < this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixNumericalValue();
        byte[] byArray2 = String.format("%0" + this.lengthOfFieldLength + "d", this.myLength).getBytes();
        this.myLength = n;
        byte[] byArray3 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        byte[] byArray4 = EBCDICConverter.convertASCIIToEBCDIC(byArray3);
        return byArray4;
    }

    private void YP_GetNEEVariableNumericalEbcdicValue() {
        this.father.logger(2, "YP_GetNEEVariableNumericalEbcdicValue() not done");
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        byte[] byArray2 = EBCDICConverter.convertEBCDICToASCII(byArray);
        int n = Integer.parseInt(new String(byArray2));
        byte[] byArray3 = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + (n + 1) / 2);
        if (byArray3 != null) {
            byte[] byArray4 = EBCDICConverter.convertEBCDICToASCII(byArray3);
            this.myParsingIndex += (n + 1) / 2;
            this.myValue = n % 2 == 1 ? UtilsYP.devHexa(byArray4).substring(1) : UtilsYP.devHexa(byArray4);
        }
    }

    private byte[] YP_SetNEEVariableBinaryValue() {
        int n = this.myLength;
        if (this.myValue.length() <= this.myLength * 2) {
            this.myLength = this.myValue.length() / 2 + this.myValue.length() % 2;
        }
        byte[] byArray = this.YP_SetFixBinaryValue();
        byte[] byArray2 = String.format("%0" + this.lengthOfFieldLength + "d", this.myLength).getBytes();
        byte[] byArray3 = EBCDICConverter.convertASCIIToEBCDIC(byArray2);
        this.myLength = n;
        byte[] byArray4 = this.YP_AppendFormatedData(byArray3, byArray, 0);
        return byArray4;
    }

    private void YP_GetNEEVariableBinaryValue() {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        byte[] byArray2 = EBCDICConverter.convertEBCDICToASCII(byArray);
        int n = Integer.parseInt(new String(byArray2));
        byte[] byArray3 = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        this.myParsingIndex += n;
        this.myValue = UtilsYP.devHexa(byArray3);
    }

    private byte[] YP_SetNEEVariableAlphabeticalEbcdicValue() {
        int n = this.myLength;
        if (this.myValue.length() < this.myLength) {
            this.myLength = this.myValue.length();
        }
        byte[] byArray = this.YP_SetFixAlphabeticalValue();
        byte[] byArray2 = String.format("%0" + this.lengthOfFieldLength + "d", this.myLength).getBytes();
        this.myLength = n;
        byte[] byArray3 = this.YP_AppendFormatedData(byArray2, byArray, 0);
        byte[] byArray4 = EBCDICConverter.convertASCIIToEBCDIC(byArray3);
        return byArray4;
    }

    private void YP_GetNEEVariableAlphabeticalEbcdicValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.lengthOfFieldLength + this.myParsingIndex);
        this.myParsingIndex += this.lengthOfFieldLength;
        byte[] byArray2 = EBCDICConverter.convertEBCDICToASCII(byArray);
        int n = Integer.parseInt(new String(byArray2));
        byte[] byArray3 = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myParsingIndex + n);
        if (byArray3 != null) {
            byte[] byArray4 = EBCDICConverter.convertEBCDICToASCII(byArray3);
            this.myParsingIndex += n;
            try {
                this.myValue = new String(byArray4, "ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                this.father.logger(2, "YP_GetNEEVariableAlphabeticalEbcdicValue() " + unsupportedEncodingException);
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
            }
        }
    }

    private void YP_SetFixValue() throws YP_ISO8583Exception {
        byte[] byArray = null;
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                byArray = this.YP_SetFixNumericalValue();
                break;
            }
            case NUMERIC_EBCDIC: {
                byArray = this.YP_SetFixNumericalEBCDICValue();
                break;
            }
            case DIGIT_STRING: {
                byArray = this.YP_SetFixDigitStringValue();
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                byArray = this.YP_SetFixDigitStringEBCDICValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        byArray = this.YP_SetFixNumericalValue();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetFixAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        byArray = this.YP_SetFixBinaryValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        byArray = this.YP_SetFixNumericalSignedValue();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_SetFixValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case NUMERIC_SIGNED: {
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case ISO_TRACK: 
            case CMC7_TRACK: {
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case ALPHANUM_EBCDIC: {
                byArray = this.YP_SetFixAlphabeticalEBCDICValue();
                break;
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        byArray = this.YP_SetFixNumericalValueAlpha();
                        break block0;
                    }
                    case ALPHA: {
                        byArray = this.YP_SetFixAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        byArray = this.YP_SetFixBinaryValueAlpha();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        byArray = this.YP_SetFixNumericalSignedValueAlpha();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_SetFixValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
        if (byArray != null) {
            this.myFormatedData = this.YP_AppendFormatedData(this.myFormatedData, byArray, 0);
            this.myFormatedLength = this.myFormatedData.length;
        }
    }

    private byte[] YP_SetFixNumericalSignedValueAlpha() {
        byte[] byArray;
        try {
            byArray = this.myValue.substring(0, 1).getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = this.myValue.substring(0, 1).getBytes();
        }
        this.myValue = this.myValue.substring(1);
        byte[] byArray2 = this.YP_SetFixNumericalValueAlpha();
        byArray2 = this.YP_AppendFormatedData(byArray, byArray2, 0);
        return byArray2;
    }

    private byte[] YP_SetFixNumericalValueAlpha() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength) {
            try {
                byArray = this.myValue.substring(this.myValue.length() - this.myLength).getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.substring(this.myValue.length() - this.myLength).getBytes();
            }
        } else if (this.myValue.length() < this.myLength) {
            StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.myLength, this.myValue);
            try {
                byArray = stringBuilder.toString().getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = stringBuilder.toString().getBytes();
            }
        } else {
            try {
                byArray = this.myValue.getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.getBytes();
            }
        }
        return byArray;
    }

    private byte[] YP_SetFixBinaryValueAlpha() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength) {
            try {
                byArray = this.myValue.substring(this.myValue.length() - this.myLength).getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.substring(this.myValue.length() - this.myLength).getBytes();
            }
        } else if (this.myValue.length() < this.myLength) {
            StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.myLength, this.myValue);
            try {
                byArray = stringBuilder.toString().getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = stringBuilder.toString().getBytes();
            }
        } else {
            try {
                byArray = this.myValue.getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.getBytes();
            }
        }
        return byArray;
    }

    private byte[] YP_SetFixNumericalValue() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength) {
            byArray = YP_ISO8583Utils.YP_ISO8583ToBcd(this.myValue.substring(this.myValue.length() - this.myLength));
        } else if (this.myValue.length() < this.myLength) {
            StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.myLength, this.myValue);
            byArray = YP_ISO8583Utils.YP_ISO8583ToBcd(stringBuilder.toString());
        } else {
            byArray = YP_ISO8583Utils.YP_ISO8583ToBcd(this.myValue);
        }
        return byArray;
    }

    private byte[] YP_SetFixNumericalSignedValue() {
        byte[] byArray;
        try {
            byArray = this.myValue.substring(0, 1).getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = this.myValue.substring(0, 1).getBytes();
        }
        this.myValue = this.myValue.substring(1);
        byte[] byArray2 = this.YP_SetFixNumericalValue();
        byArray2 = this.YP_AppendFormatedData(byArray, byArray2, 0);
        return byArray2;
    }

    private byte[] YP_SetFixAlphabeticalValue() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength) {
            this.myValue = this.myValue.substring(this.myValue.length() - this.myLength);
            try {
                byArray = this.myValue.getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.getBytes();
            }
        } else if (this.myValue.length() < this.myLength) {
            StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingString(this.myLength, this.myValue);
            try {
                byArray = stringBuilder.toString().getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = stringBuilder.toString().getBytes();
            }
        } else {
            try {
                byArray = this.myValue.getBytes("ISO-8859-1");
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
                byArray = this.myValue.getBytes();
            }
        }
        return byArray;
    }

    private byte[] YP_SetFixDigitStringValue() {
        try {
            byte[] byArray;
            if (this.myValue.length() > this.myLength) {
                byArray = this.myValue.substring(this.myValue.length() - this.myLength).getBytes("ISO-8859-1");
            } else if (this.myValue.length() < this.myLength) {
                StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.myLength, this.myValue);
                byArray = stringBuilder.toString().getBytes("ISO-8859-1");
            } else {
                byArray = this.myValue.getBytes("ISO-8859-1");
            }
            return byArray;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            return null;
        }
    }

    private byte[] YP_SetFixAlphabeticalEBCDICValue() {
        return EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetFixAlphabeticalValue());
    }

    private byte[] YP_SetFixNumericalEBCDICValue() {
        return EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetFixNumericalValue());
    }

    private byte[] YP_SetFixDigitStringEBCDICValue() {
        return EBCDICConverter.convertASCIIToEBCDIC(this.YP_SetFixDigitStringValue());
    }

    private byte[] YP_SetFixBinaryValue() {
        byte[] byArray;
        if (this.myValue.length() > this.myLength * 2) {
            if (this.father != null && this.father.getLogLevel() >= 5) {
                this.father.logger(5, "YP_SetFixBinaryValue() Value too long:" + this.myValue);
            }
            StringBuilder stringBuilder = new StringBuilder(this.myValue.substring(this.myValue.length() - this.myLength * 2));
            byArray = new byte[this.myLength];
            UtilsYP.redHexa(byArray, stringBuilder.toString(), this.myLength);
        } else if (this.myValue.length() < this.myLength * 2) {
            StringBuilder stringBuilder = YP_ISO8583Utils.YP_FormatPaddingTag(this.myLength * 2, this.myValue);
            byArray = new byte[this.myLength];
            UtilsYP.redHexa(byArray, stringBuilder.toString(), this.myLength);
        } else {
            byArray = new byte[this.myLength];
            UtilsYP.redHexa(byArray, this.myValue, this.myLength);
        }
        return byArray;
    }

    private void YP_GetFixValue() throws YP_ISO8583Exception {
        block0 : switch (this.myTransmissionFormat) {
            case NUMERIC: {
                this.YP_GetFixNumericValue();
                break;
            }
            case NUMERIC_EBCDIC: {
                this.YP_GetFixNumericEBCDICValue();
                break;
            }
            case DIGIT_STRING: {
                this.YP_GetFixDigitStringValue();
                break;
            }
            case DIGIT_STRING_EBCDIC: {
                this.YP_GetFixDigitStringEBCDICValue();
                break;
            }
            case BINARY: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        this.YP_GetFixNumericValue();
                        break block0;
                    }
                    case ALPHA: {
                        this.YP_GetFixAlphabeticalValue();
                        break block0;
                    }
                    case BINARY: {
                        this.YP_GetFixBinaryValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        this.YP_GetFixNumericalSignedValue();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_GetFixValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case NUMERIC_SIGNED: {
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case ISO_TRACK: 
            case CMC7_TRACK: {
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
            case ALPHANUM_EBCDIC: {
                this.YP_GetFixAlphabeticalEBCDICValue();
                break;
            }
            default: {
                switch (this.myGroupDataFormat) {
                    case NUMERIC: {
                        this.YP_GetFixNumericalValueAlpha();
                        break block0;
                    }
                    case BINARY: 
                    case ALPHA: {
                        this.YP_GetFixAlphabeticalValue();
                        break block0;
                    }
                    case NUMERIC_SIGNED: {
                        this.YP_GetFixNumericalSignedValueAlpha();
                        break block0;
                    }
                    case ISO_TRACK: 
                    case CMC7_TRACK: {
                        throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
                    }
                }
                this.father.logger(2, "YP_GetFixValue() unknown Group Data Format " + (Object)((Object)this.myGroupDataFormat));
                throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.formatNotSupported, null, null, null);
            }
        }
    }

    private void YP_GetFixBinaryValue() {
        StringBuilder stringBuilder = new StringBuilder("");
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        UtilsYP.devHexa(byArray, stringBuilder, this.myLength);
        this.myValue = stringBuilder.toString();
    }

    private void YP_GetFixNumericValue() {
        StringBuilder stringBuilder = new StringBuilder("");
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, (this.myLength + 1) / 2 + this.myParsingIndex);
        this.myParsingIndex += (this.myLength + 1) / 2;
        UtilsYP.devHexa(byArray, stringBuilder, (this.myLength + 1) / 2);
        if (this.myLength % 2 == 1) {
            this.myValue = stringBuilder.substring(1);
            return;
        }
        this.myValue = stringBuilder.toString();
    }

    private void YP_GetFixAlphabeticalValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        try {
            this.myValue = new String(byArray, "ISO-8859-1").substring(0, this.myLength).trim();
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetFixAlphabeticalValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetFixAlphabeticalEBCDICValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        byArray = EBCDICConverter.convertEBCDICToASCII(byArray);
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetFixAlphabeticalEBCDICValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetFixNumericEBCDICValue() throws YP_ISO8583Exception {
        StringBuilder stringBuilder = new StringBuilder("");
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, (this.myLength + 1) / 2 + this.myParsingIndex);
        this.myParsingIndex += (this.myLength + 1) / 2;
        byArray = EBCDICConverter.convertEBCDICToASCII(byArray);
        UtilsYP.devHexa(byArray, stringBuilder, (this.myLength + 1) / 2);
        if (this.myLength % 2 == 1) {
            this.myValue = stringBuilder.substring(1);
            return;
        }
        this.myValue = stringBuilder.toString();
    }

    private void YP_GetFixDigitStringValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetFixDigitStringValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetFixDigitStringEBCDICValue() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        byArray = EBCDICConverter.convertEBCDICToASCII(byArray);
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetFixDigitStringEBCDICValue() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
    }

    private void YP_GetFixNumericalSignedValueAlpha() {
        byte[] byArray;
        try {
            byArray = this.myValue.substring(0, 1).getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            byArray = this.myValue.substring(0, 1).getBytes();
        }
        this.myValue = this.myValue.substring(1);
        this.YP_AppendFormatedData(byArray, this.YP_SetFixNumericalValueAlpha(), 0);
    }

    private void YP_GetFixNumericalSignedValue() {
        StringBuilder stringBuilder = new StringBuilder("");
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, 1 + this.myParsingIndex);
        ++this.myParsingIndex;
        String string = Byte.toString(byArray[0]);
        byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength / 2 + this.myParsingIndex);
        this.myParsingIndex += this.myLength / 2;
        UtilsYP.devHexa(byArray, stringBuilder, this.myLength / 2);
        if (this.myLength % 2 == 1) {
            this.myValue = String.valueOf(string) + stringBuilder.substring(1);
            return;
        }
        this.myValue = String.valueOf(string) + stringBuilder.toString();
    }

    private void YP_GetFixNumericalValueAlpha() throws YP_ISO8583Exception {
        byte[] byArray = this.YP_ExtractData(this.myFormatedData, this.myParsingIndex, this.myLength + this.myParsingIndex);
        this.myParsingIndex += this.myLength;
        try {
            this.myValue = new String(byArray, "ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            this.father.logger(2, "YP_GetFixNumericalValueAlpha() " + unsupportedEncodingException);
            throw new YP_ISO8583Exception(YP_ISO8583Exception.ErrorType.internalError, null, null, null);
        }
        this.myValue = YP_ISO8583Utils.YP_TrimNumericLeadingZeroes(this.myValue);
    }

    public static enum DataFormat {
        NUMERIC,
        BINARY,
        ALPHA,
        ALPHANUM,
        NUMERIC_SIGNED,
        ISO_TRACK,
        HHMMSS,
        AAMM,
        MMJJ,
        ALPHANUM_EBCDIC,
        CMC7_TRACK,
        NUMERIC_EBCDIC,
        DIGIT_STRING,
        DIGIT_STRING_EBCDIC;

    }

    public static class EBCDICConverter {
        private static final byte[] ASCII2EBCDIC;
        private static final byte[] EBCDIC2ASCII;

        static {
            byte[] byArray = new byte[256];
            byArray[1] = 1;
            byArray[2] = 2;
            byArray[3] = 3;
            byArray[4] = 55;
            byArray[5] = 45;
            byArray[6] = 46;
            byArray[7] = 47;
            byArray[8] = 22;
            byArray[9] = 5;
            byArray[10] = 37;
            byArray[11] = 11;
            byArray[12] = 12;
            byArray[13] = 13;
            byArray[14] = 14;
            byArray[15] = 15;
            byArray[16] = 16;
            byArray[17] = 17;
            byArray[18] = 18;
            byArray[19] = 19;
            byArray[20] = 60;
            byArray[21] = 61;
            byArray[22] = 50;
            byArray[23] = 38;
            byArray[24] = 24;
            byArray[25] = 25;
            byArray[26] = 63;
            byArray[27] = 39;
            byArray[28] = 28;
            byArray[29] = 29;
            byArray[30] = 30;
            byArray[31] = 31;
            byArray[32] = 64;
            byArray[33] = 79;
            byArray[34] = 127;
            byArray[35] = 123;
            byArray[36] = 91;
            byArray[37] = 108;
            byArray[38] = 80;
            byArray[39] = 125;
            byArray[40] = 77;
            byArray[41] = 93;
            byArray[42] = 92;
            byArray[43] = 78;
            byArray[44] = 107;
            byArray[45] = 96;
            byArray[46] = 75;
            byArray[47] = 97;
            byArray[48] = -16;
            byArray[49] = -15;
            byArray[50] = -14;
            byArray[51] = -13;
            byArray[52] = -12;
            byArray[53] = -11;
            byArray[54] = -10;
            byArray[55] = -9;
            byArray[56] = -8;
            byArray[57] = -7;
            byArray[58] = 122;
            byArray[59] = 94;
            byArray[60] = 76;
            byArray[61] = 126;
            byArray[62] = 110;
            byArray[63] = 111;
            byArray[64] = 124;
            byArray[65] = -63;
            byArray[66] = -62;
            byArray[67] = -61;
            byArray[68] = -60;
            byArray[69] = -59;
            byArray[70] = -58;
            byArray[71] = -57;
            byArray[72] = -56;
            byArray[73] = -55;
            byArray[74] = -47;
            byArray[75] = -46;
            byArray[76] = -45;
            byArray[77] = -44;
            byArray[78] = -43;
            byArray[79] = -42;
            byArray[80] = -41;
            byArray[81] = -40;
            byArray[82] = -39;
            byArray[83] = -30;
            byArray[84] = -29;
            byArray[85] = -28;
            byArray[86] = -27;
            byArray[87] = -26;
            byArray[88] = -25;
            byArray[89] = -24;
            byArray[90] = -23;
            byArray[91] = 74;
            byArray[92] = -32;
            byArray[93] = 90;
            byArray[94] = 95;
            byArray[95] = 109;
            byArray[96] = 121;
            byArray[97] = -127;
            byArray[98] = -126;
            byArray[99] = -125;
            byArray[100] = -124;
            byArray[101] = -123;
            byArray[102] = -122;
            byArray[103] = -121;
            byArray[104] = -120;
            byArray[105] = -119;
            byArray[106] = -111;
            byArray[107] = -110;
            byArray[108] = -109;
            byArray[109] = -108;
            byArray[110] = -107;
            byArray[111] = -106;
            byArray[112] = -105;
            byArray[113] = -104;
            byArray[114] = -103;
            byArray[115] = -94;
            byArray[116] = -93;
            byArray[117] = -92;
            byArray[118] = -91;
            byArray[119] = -90;
            byArray[120] = -89;
            byArray[121] = -88;
            byArray[122] = -87;
            byArray[123] = -64;
            byArray[124] = 106;
            byArray[125] = -48;
            byArray[126] = -95;
            byArray[127] = 7;
            byArray[128] = 32;
            byArray[129] = 33;
            byArray[130] = 34;
            byArray[131] = 35;
            byArray[132] = 36;
            byArray[133] = 21;
            byArray[134] = 6;
            byArray[135] = 23;
            byArray[136] = 40;
            byArray[137] = 41;
            byArray[138] = 42;
            byArray[139] = 43;
            byArray[140] = 44;
            byArray[141] = 9;
            byArray[142] = 10;
            byArray[143] = 27;
            byArray[144] = 48;
            byArray[145] = 49;
            byArray[146] = 26;
            byArray[147] = 51;
            byArray[148] = 52;
            byArray[149] = 53;
            byArray[150] = 54;
            byArray[151] = 8;
            byArray[152] = 56;
            byArray[153] = 57;
            byArray[154] = 58;
            byArray[155] = 59;
            byArray[156] = 4;
            byArray[157] = 20;
            byArray[158] = 62;
            byArray[159] = -31;
            byArray[160] = 65;
            byArray[161] = 66;
            byArray[162] = 67;
            byArray[163] = 68;
            byArray[164] = 69;
            byArray[165] = 70;
            byArray[166] = 71;
            byArray[167] = 72;
            byArray[168] = 73;
            byArray[169] = 81;
            byArray[170] = 82;
            byArray[171] = 83;
            byArray[172] = 84;
            byArray[173] = 85;
            byArray[174] = 86;
            byArray[175] = 87;
            byArray[176] = 88;
            byArray[177] = 89;
            byArray[178] = 98;
            byArray[179] = 99;
            byArray[180] = 100;
            byArray[181] = 101;
            byArray[182] = 102;
            byArray[183] = 103;
            byArray[184] = 104;
            byArray[185] = 105;
            byArray[186] = 112;
            byArray[187] = 113;
            byArray[188] = 114;
            byArray[189] = 115;
            byArray[190] = 116;
            byArray[191] = 117;
            byArray[192] = 118;
            byArray[193] = 119;
            byArray[194] = 120;
            byArray[195] = -128;
            byArray[196] = -118;
            byArray[197] = -117;
            byArray[198] = -116;
            byArray[199] = -115;
            byArray[200] = -114;
            byArray[201] = -113;
            byArray[202] = -112;
            byArray[203] = -102;
            byArray[204] = -101;
            byArray[205] = -100;
            byArray[206] = -99;
            byArray[207] = -98;
            byArray[208] = -97;
            byArray[209] = -96;
            byArray[210] = -86;
            byArray[211] = -85;
            byArray[212] = -84;
            byArray[213] = -83;
            byArray[214] = -82;
            byArray[215] = -81;
            byArray[216] = -80;
            byArray[217] = -79;
            byArray[218] = -78;
            byArray[219] = -77;
            byArray[220] = -76;
            byArray[221] = -75;
            byArray[222] = -74;
            byArray[223] = -73;
            byArray[224] = -72;
            byArray[225] = -71;
            byArray[226] = -70;
            byArray[227] = -69;
            byArray[228] = -68;
            byArray[229] = -67;
            byArray[230] = -66;
            byArray[231] = -65;
            byArray[232] = -54;
            byArray[233] = -53;
            byArray[234] = -52;
            byArray[235] = -51;
            byArray[236] = -50;
            byArray[237] = -49;
            byArray[238] = -38;
            byArray[239] = -37;
            byArray[240] = -36;
            byArray[241] = -35;
            byArray[242] = -34;
            byArray[243] = -33;
            byArray[244] = -22;
            byArray[245] = -21;
            byArray[246] = -20;
            byArray[247] = -19;
            byArray[248] = -18;
            byArray[249] = -17;
            byArray[250] = -6;
            byArray[251] = -5;
            byArray[252] = -4;
            byArray[253] = -3;
            byArray[254] = -2;
            byArray[255] = -1;
            ASCII2EBCDIC = byArray;
            byte[] byArray2 = new byte[255];
            byArray2[1] = 1;
            byArray2[2] = 2;
            byArray2[3] = 3;
            byArray2[4] = -100;
            byArray2[5] = 9;
            byArray2[6] = -122;
            byArray2[7] = 127;
            byArray2[8] = -105;
            byArray2[9] = -115;
            byArray2[10] = -114;
            byArray2[11] = 11;
            byArray2[12] = 12;
            byArray2[13] = 13;
            byArray2[14] = 14;
            byArray2[15] = 15;
            byArray2[16] = 16;
            byArray2[17] = 17;
            byArray2[18] = 18;
            byArray2[19] = 19;
            byArray2[20] = -99;
            byArray2[21] = -123;
            byArray2[22] = 8;
            byArray2[23] = -121;
            byArray2[24] = 24;
            byArray2[25] = 25;
            byArray2[26] = -110;
            byArray2[27] = -113;
            byArray2[28] = 28;
            byArray2[29] = 29;
            byArray2[30] = 30;
            byArray2[31] = 31;
            byArray2[32] = -128;
            byArray2[33] = -127;
            byArray2[34] = -126;
            byArray2[35] = -125;
            byArray2[36] = -124;
            byArray2[37] = 10;
            byArray2[38] = 23;
            byArray2[39] = 27;
            byArray2[40] = -120;
            byArray2[41] = -119;
            byArray2[42] = -118;
            byArray2[43] = -117;
            byArray2[44] = -116;
            byArray2[45] = 5;
            byArray2[46] = 6;
            byArray2[47] = 7;
            byArray2[48] = -112;
            byArray2[49] = -111;
            byArray2[50] = 22;
            byArray2[51] = -109;
            byArray2[52] = -108;
            byArray2[53] = -107;
            byArray2[54] = -106;
            byArray2[55] = 4;
            byArray2[56] = -104;
            byArray2[57] = -103;
            byArray2[58] = -102;
            byArray2[59] = -101;
            byArray2[60] = 20;
            byArray2[61] = 21;
            byArray2[62] = -98;
            byArray2[63] = 26;
            byArray2[64] = 32;
            byArray2[65] = -96;
            byArray2[66] = -95;
            byArray2[67] = -94;
            byArray2[68] = -93;
            byArray2[69] = -92;
            byArray2[70] = -91;
            byArray2[71] = -90;
            byArray2[72] = -89;
            byArray2[73] = -88;
            byArray2[74] = 91;
            byArray2[75] = 46;
            byArray2[76] = 60;
            byArray2[77] = 40;
            byArray2[78] = 43;
            byArray2[79] = 33;
            byArray2[80] = 38;
            byArray2[81] = -87;
            byArray2[82] = -86;
            byArray2[83] = -85;
            byArray2[84] = -84;
            byArray2[85] = -83;
            byArray2[86] = -82;
            byArray2[87] = -81;
            byArray2[88] = -80;
            byArray2[89] = -79;
            byArray2[90] = 93;
            byArray2[91] = 36;
            byArray2[92] = 42;
            byArray2[93] = 41;
            byArray2[94] = 59;
            byArray2[95] = 94;
            byArray2[96] = 45;
            byArray2[97] = 47;
            byArray2[98] = -78;
            byArray2[99] = -77;
            byArray2[100] = -76;
            byArray2[101] = -75;
            byArray2[102] = -74;
            byArray2[103] = -73;
            byArray2[104] = -72;
            byArray2[105] = -71;
            byArray2[106] = 124;
            byArray2[107] = 44;
            byArray2[108] = 37;
            byArray2[109] = 95;
            byArray2[110] = 62;
            byArray2[111] = 63;
            byArray2[112] = -70;
            byArray2[113] = -69;
            byArray2[114] = -68;
            byArray2[115] = -67;
            byArray2[116] = -66;
            byArray2[117] = -65;
            byArray2[118] = -64;
            byArray2[119] = -63;
            byArray2[120] = -62;
            byArray2[121] = 96;
            byArray2[122] = 58;
            byArray2[123] = 35;
            byArray2[124] = 64;
            byArray2[125] = 39;
            byArray2[126] = 61;
            byArray2[127] = 34;
            byArray2[128] = -61;
            byArray2[129] = 97;
            byArray2[130] = 98;
            byArray2[131] = 99;
            byArray2[132] = 100;
            byArray2[133] = 101;
            byArray2[134] = 102;
            byArray2[135] = 103;
            byArray2[136] = 104;
            byArray2[137] = 105;
            byArray2[138] = -60;
            byArray2[139] = -59;
            byArray2[140] = -58;
            byArray2[141] = -57;
            byArray2[142] = -56;
            byArray2[143] = -55;
            byArray2[144] = -54;
            byArray2[145] = 106;
            byArray2[146] = 107;
            byArray2[147] = 108;
            byArray2[148] = 109;
            byArray2[149] = 110;
            byArray2[150] = 111;
            byArray2[151] = 112;
            byArray2[152] = 113;
            byArray2[153] = 114;
            byArray2[154] = -53;
            byArray2[155] = -52;
            byArray2[156] = -51;
            byArray2[157] = -50;
            byArray2[158] = -49;
            byArray2[159] = -48;
            byArray2[160] = -47;
            byArray2[161] = 126;
            byArray2[162] = 115;
            byArray2[163] = 116;
            byArray2[164] = 117;
            byArray2[165] = 118;
            byArray2[166] = 119;
            byArray2[167] = 120;
            byArray2[168] = 121;
            byArray2[169] = 122;
            byArray2[170] = -46;
            byArray2[171] = -45;
            byArray2[172] = -44;
            byArray2[173] = -43;
            byArray2[174] = -42;
            byArray2[175] = -41;
            byArray2[176] = -40;
            byArray2[177] = -39;
            byArray2[178] = -38;
            byArray2[179] = -37;
            byArray2[180] = -36;
            byArray2[181] = -35;
            byArray2[182] = -34;
            byArray2[183] = -33;
            byArray2[184] = -32;
            byArray2[185] = -31;
            byArray2[186] = -30;
            byArray2[187] = -29;
            byArray2[188] = -28;
            byArray2[189] = -27;
            byArray2[190] = -26;
            byArray2[191] = -25;
            byArray2[192] = 123;
            byArray2[193] = 65;
            byArray2[194] = 66;
            byArray2[195] = 67;
            byArray2[196] = 68;
            byArray2[197] = 69;
            byArray2[198] = 70;
            byArray2[199] = 71;
            byArray2[200] = 72;
            byArray2[201] = 73;
            byArray2[202] = -24;
            byArray2[203] = -23;
            byArray2[204] = -22;
            byArray2[205] = -21;
            byArray2[206] = -20;
            byArray2[207] = -19;
            byArray2[208] = 125;
            byArray2[209] = 74;
            byArray2[210] = 75;
            byArray2[211] = 76;
            byArray2[212] = 77;
            byArray2[213] = 78;
            byArray2[214] = 79;
            byArray2[215] = 80;
            byArray2[216] = 81;
            byArray2[217] = 82;
            byArray2[218] = -18;
            byArray2[219] = -17;
            byArray2[220] = -16;
            byArray2[221] = -15;
            byArray2[222] = -14;
            byArray2[223] = -13;
            byArray2[224] = 92;
            byArray2[225] = -97;
            byArray2[226] = 83;
            byArray2[227] = 84;
            byArray2[228] = 85;
            byArray2[229] = 86;
            byArray2[230] = 87;
            byArray2[231] = 88;
            byArray2[232] = 89;
            byArray2[233] = 90;
            byArray2[234] = -12;
            byArray2[235] = -11;
            byArray2[236] = -10;
            byArray2[237] = -9;
            byArray2[238] = -8;
            byArray2[239] = -7;
            byArray2[240] = 48;
            byArray2[241] = 49;
            byArray2[242] = 50;
            byArray2[243] = 51;
            byArray2[244] = 52;
            byArray2[245] = 53;
            byArray2[246] = 54;
            byArray2[247] = 55;
            byArray2[248] = 56;
            byArray2[249] = 57;
            byArray2[250] = -6;
            byArray2[251] = -5;
            byArray2[252] = -4;
            byArray2[253] = -3;
            byArray2[254] = -2;
            EBCDIC2ASCII = byArray2;
        }

        private static byte convertByteA2E(byte by) {
            return ASCII2EBCDIC[by & 0xFF];
        }

        private static byte convertByteE2A(byte by) {
            return EBCDIC2ASCII[by & 0xFF];
        }

        public static byte[] convertASCIIToEBCDIC(byte[] byArray) {
            if (byArray != null) {
                byte[] byArray2 = new byte[byArray.length];
                int n = 0;
                while (n < byArray.length) {
                    byArray2[n] = EBCDICConverter.convertByteA2E(byArray[n]);
                    ++n;
                }
                return byArray2;
            }
            return null;
        }

        public static String convertASCIIToEBCDIC(String string) {
            try {
                byte[] byArray;
                if (string != null && (byArray = EBCDICConverter.convertASCIIToEBCDIC(string.getBytes("ISO-8859-1"))) != null) {
                    return new String(byArray, "ISO-8859-1");
                }
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {}
            return null;
        }

        public static byte[] convertEBCDICToASCII(byte[] byArray) {
            if (byArray != null) {
                return EBCDICConverter.convertEBCDICToASCII(byArray, byArray.length);
            }
            return null;
        }

        public static byte[] convertEBCDICToASCII(byte[] byArray, int n) {
            if (byArray != null) {
                byte[] byArray2 = new byte[n];
                int n2 = 0;
                while (n2 < n) {
                    byArray2[n2] = EBCDICConverter.convertByteE2A(byArray[n2]);
                    ++n2;
                }
                return byArray2;
            }
            return null;
        }
    }

    public static enum FieldFormat {
        fixe,
        variable,
        NVAR,
        NNVAR,
        AVAR,
        AAVAR,
        AAAVAR,
        NNEEVAR,
        NNNEEVAR,
        LVAR,
        LLVAR,
        LLLVAR,
        TTLV_a,
        TTLV_b,
        TTLLV_b,
        TTLLV_c,
        TTLLLV_c,
        TTTTLLLLV_c,
        structure,
        BER_TLV,
        TTLLV_zc;

    }
}

