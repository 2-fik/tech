/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBContext
 *  javax.xml.bind.JAXBElement
 *  javax.xml.bind.Marshaller
 *  javax.xml.bind.UnmarshalException
 *  javax.xml.bind.Unmarshaller
 */
package org.yp.framework.ondemandcomponents.parsers;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.UnmarshalException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.parsers.YP_TCD_XMLParser_Interface;

public final class YP_TCD_XMLParser_JAXB
extends YP_OnDemandComponent
implements YP_TCD_XMLParser_Interface {
    private JAXBContext myJaxbContext;
    private SchemaFactory mySchemaFactory;
    private Schema mySchemaGrammar;
    private Marshaller globalMarshaller;
    private Unmarshaller globalUnmarshaller;
    private String jaxbFile = null;
    private String schema = null;
    private String xsdFile = null;

    public YP_TCD_XMLParser_JAXB(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        if (this.getPropertyFileName() != null) {
            String string = this.getProperty(this.getPropertyFileName(), "jaxbFile");
            if (string != null) {
                this.jaxbFile = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "schema")) != null) {
                this.schema = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "xsdFile")) != null) {
                this.xsdFile = string;
            }
        }
        if (this.jaxbFile == null) {
            this.logger(2, "initialize() missing mandatory parameter : jaxbFile");
            return -1;
        }
        if (this.schema == null) {
            this.logger(2, "initialize() missing mandatory parameter : schema");
            return -1;
        }
        if (this.xsdFile == null) {
            this.logger(2, "initialize() missing mandatory parameter : xsdFile");
            return -1;
        }
        try {
            this.myJaxbContext = JAXBContext.newInstance((String)this.jaxbFile);
            this.mySchemaFactory = SchemaFactory.newInstance(this.schema);
            this.mySchemaGrammar = this.mySchemaFactory.newSchema(new File(this.xsdFile));
            this.globalMarshaller = this.myJaxbContext.createMarshaller();
            this.globalUnmarshaller = this.myJaxbContext.createUnmarshaller();
            this.globalUnmarshaller.setSchema(this.mySchemaGrammar);
        }
        catch (Exception exception) {
            this.logger(2, "initialize()  " + exception);
        }
        return 1;
    }

    @Override
    public final String toString() {
        return "XMLParserJAXB";
    }

    @Override
    public final String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    @Override
    public String objectToXML(Object object) {
        try {
            StringWriter stringWriter = new StringWriter();
            this.globalMarshaller.marshal(object, (Writer)stringWriter);
            return stringWriter.toString();
        }
        catch (Exception exception) {
            this.logger(2, "objectToXML() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(String string) throws UnmarshalException {
        try {
            StringReader stringReader = new StringReader(string);
            Object object = this.globalUnmarshaller.unmarshal((Reader)stringReader);
            if (!(object instanceof JAXBElement)) {
                return object;
            }
            return ((JAXBElement)object).getValue();
        }
        catch (UnmarshalException unmarshalException) {
            throw unmarshalException;
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(byte[] byArray) {
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(byArray));
            Object object = this.globalUnmarshaller.unmarshal((Reader)inputStreamReader);
            if (!(object instanceof JAXBElement)) {
                return object;
            }
            return ((JAXBElement)object).getValue();
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }
}

