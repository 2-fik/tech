/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.none;

import java.util.Arrays;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.UtilsYP;

public class YP_TCD_PROT_None
extends YP_OnDemandComponent
implements YP_PROT_Interface_Com {
    private YP_PHYS_Interface physicalInterface;
    private int physicalInterfaceToShutdown = 0;
    private static final int DEFAULT_TNR_MS = 30000;
    private int tnrMS = 30000;
    public final int blockLength = 3000;
    byte[] readBuffer = new byte[3000];

    public YP_TCD_PROT_None(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PHYS_Interface) {
            this.physicalInterface = (YP_PHYS_Interface)objectArray[0];
        }
    }

    @Override
    public int setParameters(Object ... objectArray) {
        try {
            if (objectArray != null && objectArray.length == 7) {
                this.tnrMS = (Integer)objectArray[4];
                if (this.tnrMS < 3000 || this.tnrMS > 600000) {
                    this.logger(2, "setParameters() Invalid tnrMS:" + this.tnrMS);
                    this.tnrMS = 30000;
                }
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setParameters() " + exception);
            return -1;
        }
    }

    @Override
    public int waitConnection() {
        return 1;
    }

    @Override
    public int connect(YP_Row yP_Row) {
        if (this.physicalInterface != null) {
            return 0;
        }
        try {
            YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
            this.physicalInterface = (YP_PHYS_Interface)yP_Service.dealRequest(this, "openConnection", yP_Row);
            if (this.physicalInterface == null) {
                this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "connect() impossible to get the connection plugin for: " + yP_Row.getPrimaryKey());
            return -1;
        }
        this.physicalInterfaceToShutdown = 1;
        return 1;
    }

    @Override
    public void send(byte[] byArray, boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException {
        int n = this.physicalInterface.send(byArray, byArray.length);
        if (n < 0) {
            this.logger(2, "send() broken connection");
            throw new YP_PROT_Interface_Com.DisconnectionException();
        }
    }

    @Override
    public byte[] receive(boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException, YP_PROT_Interface_Com.BadFormatException {
        int n = 0;
        try {
            int n2;
            long l = System.currentTimeMillis();
            do {
                if (this.readBuffer.length < n + 3000) {
                    byte[] byArray = this.readBuffer;
                    this.readBuffer = Arrays.copyOf(byArray, n + 3000);
                }
                if ((n2 = this.physicalInterface.recv(this.readBuffer, n, 3000, 3000)) <= 0) continue;
                n += n2;
                if (n2 != 3000) continue;
                n2 = 0;
            } while (n2 == 0 && !UtilsYP.isTimeout(l, this.tnrMS));
        }
        catch (Exception exception) {
            this.logger(2, "connect() " + exception);
        }
        if (n > 0) {
            return Arrays.copyOfRange(this.readBuffer, 0, n);
        }
        return null;
    }

    @Override
    public int disconnect() {
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public String toString() {
        return "NONEPROTOCOL";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String getParameter(String string) {
        return null;
    }

    @Override
    public int waitDisconnection() {
        return 0;
    }

    @Override
    public int setComParameter(String string, String string2) {
        return 0;
    }
}

