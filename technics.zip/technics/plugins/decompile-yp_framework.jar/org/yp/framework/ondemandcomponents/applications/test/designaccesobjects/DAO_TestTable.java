/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_TestTable
extends YP_Row {
    @PrimaryKey
    public long idTest = 0L;
    public long testLong = 0L;
    public int testInt = 0;
    public byte[] testCharArray = new byte[50];
    public Timestamp testTimestamp = new Timestamp(0L);
}

