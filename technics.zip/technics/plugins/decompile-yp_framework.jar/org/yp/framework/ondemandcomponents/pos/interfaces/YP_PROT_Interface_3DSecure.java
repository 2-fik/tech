/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public interface YP_PROT_Interface_3DSecure {
    public String getMerchantURL();

    public String getUserAgentHeader();

    public String getAcceptHeader();

    public int setPaReq(String var1, String var2, String var3);

    public String getPaRes();

    public int is3DSActive(YP_TCD_DCC_Business var1, YP_TCD_DC_Transaction var2);

    public int is3DSResponse(YP_TCD_DCC_Business var1, YP_TCD_DC_Transaction var2);
}

