/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.Partition;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test30
extends YP_Row {
    @PrimaryKey
    public long idTest30 = 0L;
    @Index
    @Partition(name="archiveOrderedByDatePS", tableType=8)
    public Timestamp test30Timestamp = new Timestamp(0L);
}

