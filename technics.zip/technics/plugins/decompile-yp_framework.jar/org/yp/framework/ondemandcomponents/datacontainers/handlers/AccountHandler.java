/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.handlers;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.HandlerInterface;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Account;
import org.yp.utils.EMV;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;

public class AccountHandler
implements HandlerInterface {
    public static final char ISOTrackStx = '%';
    public static final char ISOTrackFormatCode = 'B';
    public static final char ISOTrackSeparator = '^';
    public static final char ISOTrackEtx = '?';
    private boolean loadAccountPostponed = false;
    private YP_TCD_DC_Transaction dataContainerTransaction;
    private int customerDatasReceived = 0;
    private YP_Row currentCustomerRow;
    private int meanOfPaymentDatasReceived = 0;
    private YP_Row currentMOPRow;
    private List<YP_Row> currentMOPRowList;
    private long t_IDToken = 0L;
    private boolean v_IsItANewToken = false;
    private long t_CustomerIdentifier = 0L;
    private String t_CustomerMerchantIdentifier = "";
    private String t_CustomerName = "";
    private String t_CustomerMailAddress = "";
    private String t_CustomerIPAddress = "";
    private int v_CustomerStatus = 0;
    private String v_CustomerPrimaryPhone = "";
    private long t_IDMeanOfPayment = 0L;
    private String t_MaskedAccountIdentifier = "";
    private Timestamp t_AccountExpirationDate = new Timestamp(0L);
    private Timestamp t_AccountEffectiveDate = new Timestamp(0L);
    private String v_AccountIdentifier = "";
    private String t_AccountHolderName = "";
    private String t_AccountAlias = "";
    private String t_AccountType = "";
    private int v_AccountStatus = AccountStatusEnumeration.UNKNOWN.getValue();
    private String v_CardCVV = "";
    private String t_CardType = "";
    private String t_CardSequenceNumber = "";
    private String t_CardServiceCode = "";
    private String v_Track1 = "";
    private String v_Track2 = "";
    private String t_Track2DiscretionnaryData = "";
    private String t_Track2DiscretionnaryDataKeyIdentifier = "";
    private String t_networkData = "";
    private List<ADF> v_ADFList;
    private String t_SBANCountryCode = "";
    private String t_SBANKey = "";
    private String t_SBANBIC = "";
    private String v_SBANBBAN = "";
    private String t_Scheme = "";
    private String lastAccountIdentifier = null;

    @Override
    public int shutdown() {
        this.dataContainerTransaction = null;
        this.currentCustomerRow = null;
        if (this.currentMOPRowList != null) {
            this.currentMOPRowList.clear();
        }
        return 1;
    }

    @Override
    public int clear() {
        this.v_IsItANewToken = false;
        this.v_CustomerStatus = 0;
        this.v_CustomerPrimaryPhone = "";
        this.v_AccountIdentifier = "";
        this.v_AccountStatus = 0;
        this.v_CardCVV = "";
        this.v_Track1 = "";
        this.v_Track2 = "";
        this.v_ADFList = null;
        this.v_SBANBBAN = "";
        this.setTrack2DiscretionnaryData("");
        this.setTrack2DiscretionnaryDataKeyIdentifier("");
        return 1;
    }

    public int clearAll() {
        this.t_IDToken = 0L;
        this.t_CustomerIdentifier = 0L;
        this.t_CustomerMerchantIdentifier = "";
        this.t_CustomerName = "";
        this.t_CustomerMailAddress = "";
        this.t_CustomerIPAddress = "";
        this.t_IDMeanOfPayment = 0L;
        this.t_MaskedAccountIdentifier = "";
        this.t_AccountExpirationDate = new Timestamp(0L);
        this.t_AccountEffectiveDate = new Timestamp(0L);
        this.t_AccountHolderName = "";
        this.t_AccountAlias = "";
        this.t_AccountType = "";
        this.t_CardType = "";
        this.t_CardSequenceNumber = "";
        this.t_CardServiceCode = "";
        this.t_Track2DiscretionnaryData = "";
        this.t_Track2DiscretionnaryDataKeyIdentifier = "";
        this.t_SBANCountryCode = "";
        this.t_SBANKey = "";
        this.t_SBANBIC = "";
        this.t_Scheme = "";
        return this.clear();
    }

    public AccountHandler(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        this.dataContainerTransaction = yP_TCD_DC_Transaction;
    }

    public int getCustomerDatasReceived() {
        return this.customerDatasReceived;
    }

    public void setCustomerDatasReceived(int n) {
        this.customerDatasReceived = n;
    }

    public int getMeanOfPaymentDatasReceived() {
        return this.meanOfPaymentDatasReceived;
    }

    public void setMeanOfPaymentDatasReceived(int n) {
        this.meanOfPaymentDatasReceived = n;
    }

    public void setIDToken(long l) {
        this.t_IDToken = l;
    }

    public long getIDToken() {
        return this.t_IDToken;
    }

    public void setIsItANewToken(boolean bl) {
        this.v_IsItANewToken = bl;
    }

    public boolean isItANewToken() {
        return this.v_IsItANewToken;
    }

    public void setIDMeanOfPayment(long l) {
        this.t_IDMeanOfPayment = l;
    }

    public long getIDMeanOfPayment() {
        return this.t_IDMeanOfPayment;
    }

    public void setAccountIdentifier(String string) {
        this.v_AccountIdentifier = string;
    }

    public String getAccountIdentifier() {
        return this.v_AccountIdentifier;
    }

    public void setMaskedAccountIdentifier(String string) {
        this.t_MaskedAccountIdentifier = string;
    }

    public String getMaskedAccountIdentifier() {
        return this.t_MaskedAccountIdentifier;
    }

    public void setAccountExpirationDate(Timestamp timestamp) {
        this.t_AccountExpirationDate = timestamp;
    }

    public void setAccountExpirationDate(String string) {
        if (string == null) {
            return;
        }
        if (string.length() == 4) {
            Timestamp timestamp = new Timestamp(UtilsYP.parseAAMMDate(string).getTimeInMillis());
            this.t_AccountExpirationDate = UtilsYP.convertAAMMEndOfValitdityToAAMMJJ(timestamp);
        } else if (string.length() == 6) {
            this.t_AccountExpirationDate = new Timestamp(UtilsYP.parseAAMMJJDate(string).getTimeInMillis());
        }
    }

    public Timestamp getAccountExpirationDate() {
        return this.t_AccountExpirationDate;
    }

    public void setAccountEffectiveDate(Timestamp timestamp) {
        this.t_AccountEffectiveDate = timestamp;
    }

    public Timestamp getAccountEffectiveDate() {
        return this.t_AccountEffectiveDate;
    }

    public void setCardCVV(String string) {
        this.v_CardCVV = string;
    }

    public String getCardCVV() {
        return this.v_CardCVV;
    }

    public void setAccountHolderName(String string) {
        this.t_AccountHolderName = string;
    }

    public String getAccountHolderName() {
        return this.t_AccountHolderName;
    }

    public void setAccountType(String string) {
        this.t_AccountType = string;
    }

    public String getAccountType() {
        return this.t_AccountType;
    }

    public void setAccountAlias(String string) {
        this.t_AccountAlias = string;
    }

    public String getAccountAlias() {
        return this.t_AccountAlias;
    }

    public void setCustomerIdentifier(long l) {
        this.t_CustomerIdentifier = l;
    }

    public long getCustomerIdentifier() {
        return this.t_CustomerIdentifier;
    }

    public void setCustomerMerchantIdentifier(String string) {
        this.t_CustomerMerchantIdentifier = string;
    }

    public String getCustomerMerchantIdentifier() {
        return this.t_CustomerMerchantIdentifier;
    }

    public void setCustomerName(String string) {
        this.t_CustomerName = string;
    }

    public String getCustomerName() {
        return this.t_CustomerName;
    }

    public void setCustomerMailAddress(String string) {
        this.t_CustomerMailAddress = string;
    }

    public String getCustomerMailAddress() {
        return this.t_CustomerMailAddress;
    }

    public void setCustomerIPAddress(String string) {
        this.t_CustomerIPAddress = string;
    }

    public String getCustomerIPAddress() {
        return this.t_CustomerIPAddress;
    }

    public int getCustomerStatus() {
        return this.v_CustomerStatus;
    }

    public void setCustomerStatus(int n) {
        this.v_CustomerStatus = n;
    }

    public String getCustomerPrimaryPhoneFromRequest() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            return null;
        }
        return ((YP_PROT_Account)((Object)yP_TCD_PosProtocol)).getCustomerPrimaryPhone();
    }

    public String getCustomerPrimaryPhone() {
        return this.v_CustomerPrimaryPhone;
    }

    public void setCustomerPrimaryPhone(String string) {
        this.v_CustomerPrimaryPhone = string;
    }

    public int getAccountStatus() {
        return this.v_AccountStatus;
    }

    public void setAccountStatus(int n) {
        this.v_AccountStatus = n;
    }

    public void setCardSequenceNumber(String string) {
        this.t_CardSequenceNumber = string;
    }

    public String getCardSequenceNumber() {
        return this.t_CardSequenceNumber;
    }

    public void setCardType(String string) {
        this.t_CardType = string;
    }

    public String getCardType() {
        return this.t_CardType;
    }

    public String getCardServiceCode() {
        return this.t_CardServiceCode;
    }

    public void setCardServiceCode(String string) {
        this.t_CardServiceCode = string;
    }

    public String getTrack1() {
        return this.v_Track1;
    }

    public void setTrack1(String string) {
        if (string == null || string.isEmpty()) {
            this.dataContainerTransaction.logger(2, "setTrack1() track1 missing or empty");
            return;
        }
        try {
            int n;
            if (string.charAt(0) != '%') {
                if (string.charAt(0) != 'B') {
                    this.dataContainerTransaction.logger(2, "setTrack1() format error, must start with : % or for NFC B");
                    return;
                }
                string = String.valueOf('%') + string;
            } else if (string.charAt(1) != 'B') {
                this.dataContainerTransaction.logger(2, "setTrack1() format error, must start with : %B");
                return;
            }
            int n2 = string.indexOf(94);
            if (n2 < 0) {
                this.dataContainerTransaction.logger(2, "setTrack1() format error, missing separator : ^");
                return;
            }
            int n3 = 2;
            while (n3 < n2) {
                n = string.charAt(n3);
                if ((n < 48 || n > 57) && n != 32) {
                    this.dataContainerTransaction.logger(2, "setTrack1() format error, PAN has not a numerical value");
                    return;
                }
                ++n3;
            }
            this.v_Track1 = string;
            String string2 = this.v_Track1.substring(2, n2);
            if (string2 != null && string2.contains(" ")) {
                string2 = string2.replace(" ", "");
            }
            if (this.v_AccountIdentifier == null || this.v_AccountIdentifier.isEmpty()) {
                this.v_AccountIdentifier = string2;
            } else if (!this.v_AccountIdentifier.contentEquals(string2)) {
                this.dataContainerTransaction.logger(3, "setTrack1() PAN are differents!!!");
            }
            n = this.v_Track1.indexOf(94, ++n2);
            if (n <= 0) {
                return;
            }
            String string3 = this.v_Track1.substring(n2, n);
            if (this.t_AccountHolderName == null || this.t_AccountHolderName.isEmpty()) {
                this.t_AccountHolderName = string3;
            } else if (!this.t_AccountHolderName.contentEquals(string3)) {
                this.dataContainerTransaction.logger(3, "setTrack1() Account holder name are differents!!!");
            }
            Timestamp timestamp = new Timestamp(UtilsYP.parseAAMMDate(this.v_Track1.substring(n + 1, n + 5)).getTimeInMillis());
            timestamp = UtilsYP.convertAAMMEndOfValitdityToAAMMJJ(timestamp);
            if (this.t_AccountExpirationDate == null || this.t_AccountExpirationDate.getTime() == 0L) {
                this.t_AccountExpirationDate = timestamp;
            } else if (this.t_AccountExpirationDate.compareTo(timestamp) != 0) {
                this.dataContainerTransaction.logger(3, "setTrack1() Expiration date are differents!!!");
            }
            String string4 = this.v_Track1.substring(n + 5, n + 8);
            if (this.t_CardServiceCode == null || this.t_CardServiceCode.isEmpty()) {
                this.t_CardServiceCode = string4;
            } else if (!this.t_CardServiceCode.contentEquals(string4)) {
                this.dataContainerTransaction.logger(3, "setTrack1() Service code are differents!!!");
            }
        }
        catch (Exception exception) {
            this.dataContainerTransaction.logger(2, "setTrack1() pb with track 1 format after separator");
            return;
        }
    }

    public String getTrack2DiscretionnaryData() {
        return this.t_Track2DiscretionnaryData;
    }

    public void setTrack2DiscretionnaryData(String string) {
        this.t_Track2DiscretionnaryData = string;
    }

    public String getTrack2DiscretionnaryDataKeyIdentifier() {
        return this.t_Track2DiscretionnaryDataKeyIdentifier;
    }

    public void setTrack2DiscretionnaryDataKeyIdentifier(String string) {
        this.t_Track2DiscretionnaryDataKeyIdentifier = string;
    }

    public String getTrack2() {
        if (this.v_Track2 != null && !this.v_Track2.isEmpty()) {
            return this.v_Track2;
        }
        this.v_Track2 = this.getTrack2EquivalentData();
        if (this.v_Track2 != null && this.v_Track2.endsWith("F")) {
            this.v_Track2 = this.v_Track2.substring(0, this.v_Track2.length() - 1);
        }
        return this.v_Track2;
    }

    public String getTrack2EquivalentData() {
        String string = this.getAccountIdentifier();
        if (string == null || string.isEmpty()) {
            return null;
        }
        Timestamp timestamp = this.getAccountExpirationDate();
        if (timestamp == null || timestamp.getTime() == 0L) {
            return null;
        }
        String string2 = UtilsYP.getAAMMJJHHMMSSTime(UtilsYP.getCalendar(timestamp)).substring(0, 4);
        return String.valueOf(this.getAccountIdentifier()) + 'D' + string2 + this.getCardServiceCode() + this.getTrack2DiscretionnaryData();
    }

    public void setTrack2(String string) {
        int n;
        this.v_Track2 = string;
        this.v_Track2 = this.v_Track2.replace('=', 'D');
        if (this.v_Track2 != null && !this.v_Track2.isEmpty() && this.v_Track2.charAt(0) == ';') {
            this.v_Track2 = this.v_Track2.substring(1);
        }
        if ((n = this.v_Track2.indexOf(63)) > 0) {
            this.v_Track2 = this.v_Track2.substring(0, n);
        }
        if (this.v_Track2 != null && !this.v_Track2.isEmpty()) {
            int n2 = this.v_Track2.indexOf(68);
            if (n2 == -1 && this.v_Track2.length() >= 16 && this.v_Track2.length() <= 20) {
                n2 = this.v_Track2.endsWith("F") ? this.v_Track2.length() - 1 : this.v_Track2.length();
            }
            if (n2 > 0) {
                Object object;
                boolean bl = false;
                String string2 = this.v_Track2.substring(0, n2);
                String string3 = this.getAccountIdentifier();
                if (string3 == null || string3.isEmpty()) {
                    this.setAccountIdentifier(string2);
                    bl = true;
                    this.setMaskedAccountIdentifier(UtilsYP.maskPAN(string2));
                } else if (!string3.contentEquals(string2)) {
                    this.dataContainerTransaction.logger(2, "setTrack2() PAN are differents!!!");
                }
                if (this.v_Track2.length() > n2 + 4) {
                    object = new Timestamp(UtilsYP.parseAAMMDate(this.v_Track2.substring(n2 + 1, n2 + 5)).getTimeInMillis());
                    object = UtilsYP.convertAAMMEndOfValitdityToAAMMJJ((Timestamp)object);
                    if (this.t_AccountExpirationDate == null || this.t_AccountExpirationDate.getTime() == 0L) {
                        this.t_AccountExpirationDate = object;
                    } else if (this.t_AccountExpirationDate.compareTo((Timestamp)object) != 0) {
                        this.dataContainerTransaction.logger(3, "setTrack2() Expiration date are differents " + ((Timestamp)object).toString() + " vs " + this.t_AccountExpirationDate.toString());
                    }
                }
                if (bl) {
                    this.updateToken(this.getAccountIdentifier(), this.getAccountExpirationDate());
                }
                if (this.v_Track2.length() > n2 + 7) {
                    object = this.v_Track2.substring(n2 + 5, n2 + 8);
                    if (this.t_CardServiceCode == null || this.t_CardServiceCode.isEmpty()) {
                        this.t_CardServiceCode = object;
                    } else if (!this.t_CardServiceCode.contentEquals((CharSequence)object)) {
                        this.dataContainerTransaction.logger(2, "setTrack2() Service code are differents!!!");
                    }
                }
                if (this.v_Track2.length() > n2 + 8) {
                    n = this.v_Track2.indexOf(70);
                    if (n > 0) {
                        this.v_Track2 = this.v_Track2.substring(0, n);
                    } else {
                        n = this.v_Track2.indexOf(102);
                        if (n > 0) {
                            this.v_Track2 = this.v_Track2.substring(0, n);
                        }
                    }
                    object = this.v_Track2.substring(n2 + 8);
                    this.setTrack2DiscretionnaryData((String)object);
                }
            }
        }
    }

    public String getSBANCountryCode() {
        return this.t_SBANCountryCode;
    }

    public void setSBANCountryCode(String string) {
        this.t_SBANCountryCode = string;
    }

    public String getSBANKey() {
        return this.t_SBANKey;
    }

    public void setSBANKey(String string) {
        this.t_SBANKey = string;
    }

    public String getSBANBIC() {
        return this.t_SBANBIC;
    }

    public void setSBANBIC(String string) {
        this.t_SBANBIC = string;
    }

    public String getSBANBBAN() {
        return this.v_SBANBBAN;
    }

    public void setSBANBBAN(String string) {
        this.v_SBANBBAN = string;
    }

    public String getScheme() {
        try {
            String string = YP_Row.getStringValue(this.dataContainerTransaction.getExtensionValue("aid"));
            if (string != null && !(string = string.trim()).isEmpty()) {
                this.t_Scheme = EMV.getAIDName(string, this.getAccountIdentifier());
            }
        }
        catch (Exception exception) {}
        if (this.t_Scheme == null || this.t_Scheme.isEmpty() || this.t_Scheme.contentEquals("UNKNOWN")) {
            this.t_Scheme = this.getCardType();
            if (!(this.dataContainerTransaction.getLogLevel() < 5 || this.t_Scheme == null && this.t_Scheme.isEmpty())) {
                this.dataContainerTransaction.logger(5, "getScheme() " + this.t_Scheme);
            }
        }
        if (this.t_Scheme == null || this.t_Scheme.isEmpty() || this.t_Scheme.contentEquals("UNKNOWN")) {
            this.t_Scheme = EMV.getAIDNameByPAN(this.getAccountIdentifier());
        }
        if (this.t_Scheme == null) {
            this.t_Scheme = "";
        }
        return this.t_Scheme;
    }

    public void setScheme(String string) {
        this.t_Scheme = string;
    }

    private int prepareMOP(YP_PROT_Account yP_PROT_Account) {
        EntryModeEnumeration entryModeEnumeration;
        String string;
        String string2;
        String string3;
        Timestamp timestamp;
        Timestamp timestamp2;
        String string4;
        boolean bl = false;
        long l = this.getIDMeanOfPayment();
        if (l > 0L) {
            yP_PROT_Account.addOneMeanOfPaymentInstance();
            yP_PROT_Account.setMeanOfPaymentIdentifier(l);
            bl = true;
        }
        if ((string4 = this.getAccountType()) != null && !string4.isEmpty()) {
            yP_PROT_Account.setAccountType(string4);
            bl = true;
        }
        if ((timestamp2 = this.getAccountEffectiveDate()) != null && timestamp2.getTime() != 0L) {
            yP_PROT_Account.setAccountEffectiveDate(UtilsYP.getCalendar(timestamp2));
            bl = true;
        }
        if ((timestamp = this.getAccountExpirationDate()) != null && timestamp.getTime() != 0L) {
            yP_PROT_Account.setAccountExpirationDate(UtilsYP.getCalendar(timestamp));
            bl = true;
        }
        if ((string3 = this.getAccountHolderName()) != null && !string3.isEmpty()) {
            yP_PROT_Account.setAccountHolderName(string3);
            bl = true;
        }
        if ((string2 = this.getAccountAlias()) != null && !string2.isEmpty()) {
            yP_PROT_Account.setAccountAlias(string2);
            bl = true;
        }
        if ((string = this.getMaskedAccountIdentifier()) != null && !string.isEmpty()) {
            yP_PROT_Account.setMaskedAccountIdentifier(string);
            bl = true;
        }
        if (string4 != null) {
            if (string4.compareTo("Card") == 0) {
                this.prepareCardData(yP_PROT_Account);
                bl = true;
            } else if (string4.compareTo("SBAN") == 0) {
                this.prepareSBANData(yP_PROT_Account);
                bl = true;
            } else if (string4.compareTo("BBAN") == 0) {
                this.prepareBBANData(yP_PROT_Account);
                bl = true;
            } else if (string4.compareTo("QRCode") == 0) {
                this.prepareQRCodeData(yP_PROT_Account);
                bl = true;
            } else if (string4.compareTo("PartialPAN") == 0) {
                this.preparePartialPANData(yP_PROT_Account);
                bl = true;
            }
        }
        if ((entryModeEnumeration = this.dataContainerTransaction.commonHandler.getPaymentTechnology()) != null && (bl || entryModeEnumeration != EntryModeEnumeration.UNKNOWN)) {
            yP_PROT_Account.setEntryMode(entryModeEnumeration);
        }
        return 1;
    }

    private int readMOP(YP_PROT_Account yP_PROT_Account) {
        EntryModeEnumeration entryModeEnumeration;
        String string;
        String string2;
        String string3;
        Calendar calendar;
        String string4;
        Object object;
        Object object2;
        long l = yP_PROT_Account.getMeanOfPaymentIdentifier();
        if (l > 0L) {
            block28: {
                long l2;
                block29: {
                    if (this.dataContainerTransaction.getContractIdentifier().contentEquals("KERNEL")) {
                        this.loadAccountPostponed = true;
                        return 0;
                    }
                    l2 = this.dataContainerTransaction.accountHandler.getCustomerIdentifier();
                    if (l2 <= 0L) {
                        this.dataContainerTransaction.logger(4, "readMOP() the customer Identifier is not set");
                    }
                    this.currentMOPRow = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "getMeanOfPaymentByIdentifiers", l2, l);
                    if (this.currentMOPRow != null) break block28;
                    if (this.loadAccountPostponed || this.dataContainerTransaction.userHandler.getUserUID() == null || this.dataContainerTransaction.userHandler.getUserUID().isEmpty()) break block29;
                    this.loadAccountPostponed = true;
                    return 0;
                }
                try {
                    if (this.dataContainerTransaction.userHandler.getUserIdentifier() > 0L && this.dataContainerTransaction.contextHandler.brandContainers.size() > 1) {
                        object2 = this.dataContainerTransaction.contextHandler.brandContainers.iterator();
                        while (object2.hasNext()) {
                            object = (YP_TCD_DCC_Brand)object2.next();
                            if (object == this.dataContainerTransaction.getDataContainerBrand()) continue;
                            this.currentMOPRow = (YP_Row)((YP_TCD_DCC_Brand)object).dealRequest(this.dataContainerTransaction, "getMeanOfPaymentByIdentifiers", l2, l);
                            if (this.currentMOPRow != null) break;
                        }
                    }
                    if (this.currentMOPRow != null) break block28;
                    this.dataContainerTransaction.logger(2, "readMOP() unable to find MOP with id: " + l);
                    return -1;
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "readMOP() " + exception);
                    return -1;
                }
            }
            this.unMapCurrentMOPRow();
            this.setMeanOfPaymentDatasReceived(2);
        }
        if ((string4 = yP_PROT_Account.getAccountType()) != null) {
            this.setAccountType(string4);
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((calendar = yP_PROT_Account.getAccountEffectiveDate()) != null) {
            this.setAccountEffectiveDate(new Timestamp(calendar.getTimeInMillis()));
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((object = yP_PROT_Account.getAccountExpirationDate()) != null) {
            this.setAccountExpirationDate(UtilsYP.convertAAMMEndOfValitdityToAAMMJJ(new Timestamp(((Calendar)object).getTimeInMillis())));
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((object2 = yP_PROT_Account.getAccountHolderName()) != null && !((String)object2).isEmpty()) {
            this.setAccountHolderName((String)object2);
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((string3 = yP_PROT_Account.getAccountAlias()) != null && !string3.isEmpty()) {
            this.setAccountAlias(string3);
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((string2 = yP_PROT_Account.getMaskedAccountIdentifier()) != null && !string2.isEmpty()) {
            this.setMaskedAccountIdentifier(string2);
            this.setMeanOfPaymentDatasReceived(1);
        }
        if ((string = yP_PROT_Account.getAccountIdentifier()) != null && !string.isEmpty()) {
            this.setAccountIdentifier(string);
            this.setMeanOfPaymentDatasReceived(1);
        }
        if (string4 != null) {
            if (string4.contentEquals("Card")) {
                this.readCardData(yP_PROT_Account);
            } else if (string4.contentEquals("SBAN")) {
                this.readSBANData(yP_PROT_Account);
            } else if (string4.contentEquals("BBAN")) {
                this.readBBANData(yP_PROT_Account);
            } else if (string4.contentEquals("Cheque")) {
                this.readChequeData(yP_PROT_Account);
            } else if (!string4.contentEquals("QRCode")) {
                string4.contentEquals("PartialPAN");
            }
        }
        if ((entryModeEnumeration = yP_PROT_Account.getEntryMode()) != null) {
            this.dataContainerTransaction.commonHandler.setPaymentTechnology(entryModeEnumeration);
        }
        if (!(string4 != null && string4.contentEquals("QRCode") || string4 != null && string4.contentEquals("PartialPAN") || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_CMC7 || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_CMC7_KEYED || this.updateToken(this.getAccountIdentifier(), this.getAccountExpirationDate()) >= 0)) {
            return -1;
        }
        return 1;
    }

    @Deprecated
    public int updateToken() {
        return this.updateToken(this.getAccountIdentifier(), this.getAccountExpirationDate());
    }

    public int updateToken(String string, Timestamp timestamp) {
        if (string != null && !string.isEmpty()) {
            long l;
            boolean[] blArray;
            block5: {
                if (this.lastAccountIdentifier != null && this.lastAccountIdentifier.contentEquals(string) && YP_TCD_DCC_Business.getIDToken(this.dataContainerTransaction) > 0L) {
                    return 1;
                }
                this.lastAccountIdentifier = string;
                try {
                    YP_Service yP_Service = (YP_Service)this.dataContainerTransaction.getPluginByName("TokenManager");
                    blArray = new boolean[1];
                    l = (Long)yP_Service.dealRequest(this.dataContainerTransaction, "getToken", string, blArray, timestamp);
                    if (l > 0L) break block5;
                    this.dataContainerTransaction.logger(2, "updateToken() Unable to get token !!!");
                    return -1;
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "updateToken() Unable to get token" + exception);
                    return -1;
                }
            }
            YP_TCD_DCC_Business.setIDToken(this.dataContainerTransaction, l);
            YP_TCD_DCC_Business.setIsItANewToken(this.dataContainerTransaction, blArray[0]);
            return 1;
        }
        return 0;
    }

    private int expandCardIdentifier() {
        String string = this.getAccountIdentifier();
        if (string != null && !string.isEmpty()) {
            this.setMaskedAccountIdentifier(UtilsYP.maskPAN(string));
            return 1;
        }
        return 0;
    }

    private int prepareCardData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2 = this.getCardType();
        if (string2 != null) {
            yP_PROT_Account.setCardType(string2);
        }
        if ((string = this.getCardSequenceNumber()) != null) {
            yP_PROT_Account.setCardSequenceNumber(string);
        }
        if (this.v_ADFList != null) {
            yP_PROT_Account.setADFList(this.v_ADFList);
        }
        if (this.getAccountType() != null && (this.getAccountType().contentEquals("QRCode") || this.getAccountType().contentEquals("PartialPAN"))) {
            yP_PROT_Account.setAccountIdentifier(this.getAccountIdentifier());
        }
        return 1;
    }

    private int prepareQRCodeData(YP_PROT_Account yP_PROT_Account) {
        yP_PROT_Account.setAccountIdentifier(this.getAccountIdentifier());
        return 1;
    }

    private int preparePartialPANData(YP_PROT_Account yP_PROT_Account) {
        yP_PROT_Account.setAccountIdentifier(this.getAccountIdentifier());
        return 1;
    }

    private int readCardData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6 = yP_PROT_Account.getCardType();
        if (string6 != null) {
            this.setCardType(string6);
        }
        if ((string5 = yP_PROT_Account.getCardCVV()) != null && !string5.isEmpty()) {
            this.setCardCVV(string5);
        }
        if ((string4 = yP_PROT_Account.getTrack2()) != null && !string4.isEmpty()) {
            this.setTrack2(string4);
        }
        if ((string3 = yP_PROT_Account.getTrack1()) != null && !string3.isEmpty()) {
            this.setTrack1(string3);
        }
        if ((string2 = yP_PROT_Account.getTrack3()) != null) {
            string2.isEmpty();
        }
        if ((string = yP_PROT_Account.getCardSequenceNumber()) != null) {
            this.setCardSequenceNumber(string);
        }
        this.v_ADFList = yP_PROT_Account.getADFList(this);
        this.expandCardIdentifier();
        return 1;
    }

    private int readChequeData(YP_PROT_Account yP_PROT_Account) {
        String string = yP_PROT_Account.getCMC7Track();
        if (string != null) {
            try {
                if (string.indexOf(94) != -1) {
                    if (Pattern.matches("^[=][0-9]{7}[=][0-9]{12}[\\^][0-9]{12}[/]$", string)) {
                        string = string.replace('=', 'D').replace('^', 'F').replace('/', 'B');
                    }
                } else if (string.indexOf(97) != -1 && string.indexOf(114) != -1 && string.indexOf(105) != -1) {
                    string = string.replace('a', 'D').replace('r', 'F').replace('i', 'B');
                }
            }
            catch (Exception exception) {}
            this.setAccountIdentifier(string);
        }
        this.expandChequeIdentifier();
        return 1;
    }

    private int expandChequeIdentifier() {
        String string = this.getAccountIdentifier();
        if (string != null && !string.isEmpty()) {
            this.setMaskedAccountIdentifier(UtilsYP.maskCMC7(string));
            return 1;
        }
        return 0;
    }

    private int expandSBANIdentifier() {
        String string = this.getAccountIdentifier();
        if (string != null && !string.isEmpty()) {
            String string2;
            String string3;
            this.setMaskedAccountIdentifier(UtilsYP.maskSBAN(string));
            String string4 = this.getSBANCountryCode();
            if (string4 == null || string4.isEmpty()) {
                this.setSBANCountryCode(string.substring(0, 2));
            }
            if ((string3 = this.getSBANKey()) == null || string3.isEmpty()) {
                this.setSBANKey(string.substring(2, 4));
            }
            if ((string2 = this.getSBANBBAN()) == null || string2.isEmpty()) {
                this.setSBANBBAN(string.substring(4));
            }
            return 1;
        }
        return 0;
    }

    private int prepareSBANData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2;
        String string3 = this.getSBANCountryCode();
        if (string3 != null) {
            yP_PROT_Account.setSBANCountryCode(string3);
        }
        if ((string2 = this.getSBANKey()) != null) {
            yP_PROT_Account.setSBANKey(string2);
        }
        if ((string = this.getSBANBIC()) != null) {
            yP_PROT_Account.setSBANBIC(string);
        }
        return 1;
    }

    private int readSBANData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2;
        String string3;
        String string4 = yP_PROT_Account.getSBANCountryCode();
        if (string4 != null) {
            this.setSBANCountryCode(string4);
        }
        if ((string3 = yP_PROT_Account.getSBANKey()) != null && !string3.isEmpty()) {
            this.setSBANKey(string3);
        }
        if ((string2 = yP_PROT_Account.getSBANBIC()) != null) {
            this.setSBANBIC(string2);
        }
        if ((string = yP_PROT_Account.getSBANBBAN()) != null) {
            this.setSBANBBAN(string);
        }
        this.expandSBANIdentifier();
        return 1;
    }

    private int expandBBANIdentifier() {
        String string = this.getAccountIdentifier();
        if (string != null && !string.isEmpty()) {
            this.setMaskedAccountIdentifier(UtilsYP.maskBBAN(string));
            return 1;
        }
        return 0;
    }

    private int prepareBBANData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2;
        String string3 = this.getSBANCountryCode();
        if (string3 != null) {
            yP_PROT_Account.setSBANCountryCode(string3);
        }
        if ((string2 = this.getSBANKey()) != null) {
            yP_PROT_Account.setSBANKey(string2);
        }
        if ((string = this.getSBANBIC()) != null) {
            yP_PROT_Account.setSBANBIC(string);
        }
        return 1;
    }

    private int readBBANData(YP_PROT_Account yP_PROT_Account) {
        String string;
        String string2;
        String string3;
        String string4 = yP_PROT_Account.getSBANCountryCode();
        if (string4 != null) {
            this.setSBANCountryCode(string4);
        }
        if ((string3 = yP_PROT_Account.getSBANKey()) != null && !string3.isEmpty()) {
            this.setSBANKey(string3);
        }
        if ((string2 = yP_PROT_Account.getSBANBIC()) != null) {
            this.setSBANBIC(string2);
        }
        if ((string = yP_PROT_Account.getSBANBBAN()) != null) {
            this.setSBANBBAN(string);
        }
        this.expandBBANIdentifier();
        return 1;
    }

    @Override
    public int readRequest() {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "readRequest() POS protocol is not compatible with account");
            }
            return 0;
        }
        YP_PROT_Account yP_PROT_Account = (YP_PROT_Account)((Object)yP_TCD_PosProtocol);
        long l = yP_PROT_Account.getCustomerIdentifier();
        if (l > 0L) {
            block22: {
                if (this.dataContainerTransaction.getContractIdentifier().contentEquals("KERNEL")) {
                    this.loadAccountPostponed = true;
                    return 0;
                }
                try {
                    this.currentCustomerRow = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "getCustomerByIdentifier", l);
                    if (this.currentCustomerRow != null) break block22;
                    if (this.dataContainerTransaction.getLogLevel() >= 2) {
                        this.dataContainerTransaction.logger(2, "readRequest() unable to find customer with id:" + l);
                    }
                    return -1;
                }
                catch (Exception exception) {
                    if (this.dataContainerTransaction.getLogLevel() >= 2) {
                        this.dataContainerTransaction.logger(2, "readRequest() " + exception);
                    }
                    return -1;
                }
            }
            this.unMapCurrentCustomerRow();
            this.setCustomerDatasReceived(2);
        }
        if ((string5 = yP_PROT_Account.getCustomerMerchantIdentifier()) != null && !string5.isEmpty()) {
            block23: {
                this.setCustomerMerchantIdentifier(string5);
                if (this.dataContainerTransaction.getContractIdentifier().contentEquals("KERNEL")) {
                    this.loadAccountPostponed = true;
                    return 0;
                }
                try {
                    this.currentCustomerRow = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "getCustomerByMerchantIdentifier", string5);
                    if (this.currentCustomerRow != null) break block23;
                    if (this.dataContainerTransaction.getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData) {
                        if (this.dataContainerTransaction.getLogLevel() >= 2) {
                            this.dataContainerTransaction.logger(2, "readRequest() unable to find customer with id:" + string5);
                        }
                        return -1;
                    }
                }
                catch (Exception exception) {
                    if (this.dataContainerTransaction.getLogLevel() >= 2) {
                        this.dataContainerTransaction.logger(2, "readRequest() " + exception);
                    }
                    return -1;
                }
            }
            this.unMapCurrentCustomerRow();
            this.setCustomerDatasReceived(2);
        }
        if ((string4 = yP_PROT_Account.getCustomerName()) != null && !string4.isEmpty()) {
            this.setCustomerName(string4);
            this.setCustomerDatasReceived(1);
        }
        if ((string3 = yP_PROT_Account.getCustomerMailAddress()) != null && !string3.isEmpty()) {
            this.setCustomerMailAddress(string3);
            this.setCustomerDatasReceived(1);
        }
        if ((string2 = yP_PROT_Account.getCustomerIPAddress()) != null && !string2.isEmpty()) {
            this.setCustomerIPAddress(string2);
            this.setCustomerDatasReceived(1);
        }
        if ((string = yP_PROT_Account.getCustomerPrimaryPhone()) != null && !string.isEmpty()) {
            this.setCustomerPrimaryPhone(string);
            this.setCustomerDatasReceived(1);
        }
        if (this.readMOP(yP_PROT_Account) < 0) {
            return -1;
        }
        return 1;
    }

    @Override
    public int prepareResponse() {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.dataContainerTransaction.getProtocolEFT();
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            if (this.dataContainerTransaction.getLogLevel() >= 5) {
                this.dataContainerTransaction.logger(5, "prepareResponse() POS protocol is not compatible with account");
            }
            return 0;
        }
        YP_PROT_Account yP_PROT_Account = (YP_PROT_Account)((Object)yP_TCD_PosProtocol);
        long l = this.getCustomerIdentifier();
        if (l != 0L) {
            yP_PROT_Account.setCustomerIdentifier(l);
        }
        if ((string5 = this.getCustomerMerchantIdentifier()) != null && !string5.isEmpty()) {
            yP_PROT_Account.setCustomerMerchantIdentifier(string5);
        }
        if ((string4 = this.getCustomerName()) != null && !string4.isEmpty()) {
            yP_PROT_Account.setCustomerName(string4);
        }
        if ((string3 = this.getCustomerMailAddress()) != null && !string3.isEmpty()) {
            yP_PROT_Account.setCustomerMailAddress(string3);
        }
        if ((string2 = this.getCustomerPrimaryPhoneFromRequest()) != null && !string2.isEmpty()) {
            yP_PROT_Account.setCustomerPrimaryPhone(string2);
        }
        if ((string = this.getCustomerIPAddress()) != null && !string.isEmpty()) {
            yP_PROT_Account.setCustomerIPAddress(string);
        }
        if (this.getCurrentMOPRowList() != null && !this.getCurrentMOPRowList().isEmpty()) {
            Iterator<YP_Row> iterator = this.getCurrentMOPRowList().iterator();
            while (iterator.hasNext()) {
                YP_Row yP_Row;
                this.currentMOPRow = yP_Row = iterator.next();
                this.unMapCurrentMOPRow();
                this.prepareMOP(yP_PROT_Account);
            }
        } else {
            this.prepareMOP(yP_PROT_Account);
        }
        return 0;
    }

    @Override
    public int load(YP_Row yP_Row) {
        Object object;
        if (this.dataContainerTransaction.getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Loyalty) {
            long l = this.getCustomerIdentifier();
            if (l <= 0L) {
                if (this.dataContainerTransaction.getLogLevel() >= 2) {
                    this.dataContainerTransaction.logger(2, "load() No customer identifier provided !!!");
                }
                return -1;
            }
            try {
                this.setCurrentMOPRowList((List)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "getMeanOfPaymentListByCustomerIdentifier", l));
            }
            catch (Exception exception) {
                if (this.dataContainerTransaction.getLogLevel() >= 2) {
                    this.dataContainerTransaction.logger(2, "load()  unable to load MOP list from customer " + l + " " + exception);
                }
                return -1;
            }
            if (this.getCurrentMOPRowList() == null) {
                if (this.dataContainerTransaction.getLogLevel() >= 2) {
                    this.dataContainerTransaction.logger(2, "load()  unable to load MOP list from customer " + l);
                }
                return -1;
            }
            if (this.getCurrentMOPRowList().isEmpty()) {
                if (this.dataContainerTransaction.getLogLevel() >= 3) {
                    this.dataContainerTransaction.logger(3, "load()  no MOP from customer " + l);
                }
                return 0;
            }
            return 1;
        }
        Field[] fieldArray = yP_Row.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            object = fieldArray[n2];
            String string = null;
            try {
                Object object2 = yP_Row.getFieldValue((Field)object);
                if (object2 instanceof byte[]) {
                    object2 = YP_Row.getStringValue(object2);
                }
                switch (string = ((Field)object).getName()) {
                    case "idToken": {
                        this.setIDToken((Long)object2);
                        break;
                    }
                    case "idCustomer": {
                        this.setCustomerIdentifier((Long)object2);
                        break;
                    }
                    case "customerMerchantIdentifier": {
                        this.setCustomerMerchantIdentifier((String)object2);
                        break;
                    }
                    case "customerName": {
                        this.setCustomerName((String)object2);
                        break;
                    }
                    case "customerMailAddress": {
                        this.setCustomerMailAddress((String)object2);
                        break;
                    }
                    case "customerIPAddress": {
                        this.setCustomerIPAddress((String)object2);
                        break;
                    }
                    case "idMeanOfPayment": {
                        this.setIDMeanOfPayment((Long)object2);
                        break;
                    }
                    case "accountAlias": {
                        this.setAccountAlias((String)object2);
                        break;
                    }
                    case "maskedAccountIdentifier": {
                        this.setMaskedAccountIdentifier((String)object2);
                        break;
                    }
                    case "accountEffectiveDate": {
                        this.setAccountEffectiveDate((Timestamp)object2);
                        break;
                    }
                    case "accountExpirationDate": {
                        this.setAccountExpirationDate((Timestamp)object2);
                        break;
                    }
                    case "accountHolderName": {
                        this.setAccountHolderName((String)object2);
                        break;
                    }
                    case "accountType": {
                        this.setAccountType((String)object2);
                        break;
                    }
                    case "cardSequenceNumber": {
                        this.setCardSequenceNumber((String)object2);
                        break;
                    }
                    case "cardType": {
                        this.setCardType((String)object2);
                        break;
                    }
                    case "cardServiceCode": {
                        this.setCardServiceCode((String)object2);
                        break;
                    }
                    case "track2DiscretionnaryData": {
                        this.setTrack2DiscretionnaryData((String)object2);
                        break;
                    }
                    case "track2DiscretionnaryDataKeyIdentifier": {
                        this.setTrack2DiscretionnaryDataKeyIdentifier((String)object2);
                        break;
                    }
                    case "sbanCountryCode": {
                        this.setSBANCountryCode((String)object2);
                        break;
                    }
                    case "sbanKey": {
                        this.setSBANKey((String)object2);
                        break;
                    }
                    case "sbanBIC": {
                        this.setSBANBIC((String)object2);
                        break;
                    }
                }
            }
            catch (Exception exception) {
                this.dataContainerTransaction.logger(2, "load() " + string + " " + exception);
            }
            ++n2;
        }
        if (this.getIDToken() != 0L) {
            try {
                object = (String)this.dataContainerTransaction.getPluginByName("TokenManager").dealRequest(this.dataContainerTransaction, "getClearValue", this.getIDToken());
                if (object == null) {
                    this.dataContainerTransaction.logger(2, "load() unable to get account Identifier !!!");
                } else {
                    this.setAccountIdentifier((String)object);
                }
            }
            catch (Exception exception) {
                this.dataContainerTransaction.logger(2, "load() unable to get account Identifier !!!" + exception);
                return -11;
            }
        }
        return 1;
    }

    private int getClearValue(long l) {
        String string;
        block3: {
            YP_Service yP_Service = (YP_Service)this.dataContainerTransaction.getPluginByName("TokenManager");
            try {
                string = (String)yP_Service.dealRequest(this.dataContainerTransaction, "getClearValue", l);
                if (string != null) break block3;
                this.dataContainerTransaction.logger(2, "getClearValue() unable to get clear Value !!!");
                return -1;
            }
            catch (Exception exception) {
                this.dataContainerTransaction.logger(2, "getClearValue() unable to get clear Value !!!" + exception);
                return -1;
            }
        }
        this.setAccountIdentifier(string);
        return 1;
    }

    private int fieldCurrentCustomerRow() {
        block3: {
            try {
                if (this.currentCustomerRow != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        this.currentCustomerRow.set("idCustomer", this.getCustomerIdentifier());
        this.currentCustomerRow.set("merchantIdentifier", this.getCustomerMerchantIdentifier());
        this.currentCustomerRow.set("name", this.getCustomerName());
        this.currentCustomerRow.set("mailAddress", this.getCustomerMailAddress());
        this.currentCustomerRow.set("ipAddress", this.getCustomerIPAddress());
        this.currentCustomerRow.set("status", this.getCustomerStatus());
        return 1;
    }

    private int unMapCurrentCustomerRow() {
        block3: {
            try {
                if (this.currentCustomerRow != null) break block3;
                return -1;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        this.setCustomerIdentifier((Long)this.currentCustomerRow.getFieldValueByName("idCustomer"));
        this.setCustomerMerchantIdentifier(this.currentCustomerRow.getFieldStringValueByName("merchantIdentifier"));
        this.setCustomerName(this.currentCustomerRow.getFieldStringValueByName("name"));
        this.setCustomerMailAddress(this.currentCustomerRow.getFieldStringValueByName("mailAddress"));
        this.setCustomerIPAddress(this.currentCustomerRow.getFieldStringValueByName("ipAddress"));
        this.setCustomerStatus((Integer)this.currentCustomerRow.getFieldValueByName("status"));
        return 1;
    }

    private int fieldCurrentMOPRow() {
        block6: {
            try {
                if (this.currentMOPRow != null) break block6;
                return -1;
            }
            catch (Exception exception) {
                return -1;
            }
        }
        this.currentMOPRow.set("idMeanOfPayment", this.getIDMeanOfPayment());
        this.currentMOPRow.set("idCustomer", this.getCustomerIdentifier());
        this.currentMOPRow.set("status", this.getAccountStatus());
        this.currentMOPRow.set("idToken", this.getIDToken());
        this.currentMOPRow.set("alias", this.getAccountAlias());
        this.currentMOPRow.set("holderName", this.getAccountHolderName());
        this.currentMOPRow.set("effectiveDate", this.getAccountEffectiveDate());
        this.currentMOPRow.set("expirationDate", this.getAccountExpirationDate());
        this.currentMOPRow.set("meanOfPaymentType", this.getAccountType());
        this.currentMOPRow.set("sbanCountryCode", this.getSBANCountryCode());
        this.currentMOPRow.set("sbanKey", this.getSBANKey());
        this.currentMOPRow.set("sbanBIC", this.getSBANBIC());
        this.currentMOPRow.set("cardType", this.getCardType());
        this.currentMOPRow.set("cardSequenceNumber", this.getCardSequenceNumber());
        this.currentMOPRow.set("networkData", this.getNetworkData());
        try {
            String string = YP_Row.getStringValue(this.dataContainerTransaction.getExtensionValue("paresStatus"));
            if (string != null && string.contentEquals("Y")) {
                this.currentMOPRow.set("last3DSVerificationTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            }
        }
        catch (Exception exception) {}
        return 1;
    }

    private int unMapCurrentMOPRow() {
        String string;
        block11: {
            block10: {
                try {
                    if (this.currentMOPRow != null) break block10;
                    return -1;
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "unMapCurrentMOPRow() " + exception);
                    return -1;
                }
            }
            this.setIDMeanOfPayment((Long)this.currentMOPRow.getFieldValueByName("idMeanOfPayment"));
            this.setAccountEffectiveDate((Timestamp)this.currentMOPRow.getFieldValueByName("effectiveDate"));
            this.setAccountExpirationDate((Timestamp)this.currentMOPRow.getFieldValueByName("expirationDate"));
            this.setAccountHolderName(this.currentMOPRow.getFieldStringValueByName("holderName"));
            this.setAccountAlias(this.currentMOPRow.getFieldStringValueByName("alias"));
            this.setAccountStatus((Integer)this.currentMOPRow.getFieldValueByName("status"));
            this.setNetworkData(this.currentMOPRow.getFieldStringValueByName("networkData"));
            YP_TCD_DCC_Business.setIDToken(this.dataContainerTransaction, (Long)this.currentMOPRow.getFieldValueByName("idToken"));
            this.setCustomerIdentifier((Long)this.currentMOPRow.getFieldValueByName("idCustomer"));
            this.getClearValue(YP_TCD_DCC_Business.getIDToken(this.dataContainerTransaction));
            string = this.currentMOPRow.getFieldStringValueByName("meanOfPaymentType");
            this.setAccountType(string);
            if (string != null && !string.isEmpty()) break block11;
            this.dataContainerTransaction.logger(2, "unMapCurrentMOPRow() ");
            return -1;
        }
        if (string.compareTo("Card") == 0) {
            this.setCardType(this.currentMOPRow.getFieldStringValueByName("cardType"));
            this.setCardSequenceNumber(this.currentMOPRow.getFieldStringValueByName("cardSequenceNumber"));
            this.dataContainerTransaction.commonHandler.setPaymentTechnology(EntryModeEnumeration.ENTRY_MODE_KEYED);
            this.expandCardIdentifier();
        } else if (string.compareTo("SBAN") == 0) {
            this.setSBANCountryCode(this.currentMOPRow.getFieldStringValueByName("sbanCountryCode"));
            this.setSBANKey(this.currentMOPRow.getFieldStringValueByName("sbanKey"));
            this.setSBANBIC(this.currentMOPRow.getFieldStringValueByName("sbanBIC"));
            this.expandSBANIdentifier();
        } else if (string.compareTo("BBAN") == 0) {
            this.setSBANCountryCode(this.currentMOPRow.getFieldStringValueByName("sbanCountryCode"));
            this.setSBANKey(this.currentMOPRow.getFieldStringValueByName("sbanKey"));
            this.setSBANBIC(this.currentMOPRow.getFieldStringValueByName("sbanBIC"));
            this.expandBBANIdentifier();
        } else {
            this.dataContainerTransaction.logger(2, "unMapCurrentMOPRow() unknow mop Type");
            return -1;
        }
        return 1;
    }

    @Override
    public int persist() {
        if (this.dataContainerTransaction.getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Loyalty) {
            String string;
            if (this.dataContainerTransaction.getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData && this.dataContainerTransaction.getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.DeleteCustomerData) {
                return 0;
            }
            if (!(this.getCustomerIdentifier() == 0L && this.getCustomerMerchantIdentifier().isEmpty() && this.getCustomerName().isEmpty() && this.getCustomerMailAddress().isEmpty())) {
                int n;
                this.dataContainerTransaction.logger(4, "persist() A new customer must be created");
                if (this.currentCustomerRow == null) {
                    try {
                        this.currentCustomerRow = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "createNewCustomer", new Object[0]);
                    }
                    catch (Exception exception) {
                        this.dataContainerTransaction.logger(2, "persist() unable to create customer " + exception);
                        return -1;
                    }
                    if (this.currentCustomerRow == null) {
                        this.dataContainerTransaction.logger(2, "persist() unable to create customer");
                        return -1;
                    }
                    this.setCustomerIdentifier(this.currentCustomerRow.getPrimaryKey());
                    this.setCustomerStatus(1);
                } else if (this.dataContainerTransaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData) {
                    this.dataContainerTransaction.logger(4, "persist() A customer must be updated");
                } else if (this.dataContainerTransaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.DeleteCustomerData) {
                    this.dataContainerTransaction.logger(4, "persist() A customer must be deleted");
                }
                this.fieldCurrentCustomerRow();
                try {
                    n = (Integer)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "updateCustomer", this.currentCustomerRow);
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "persist() unable to update customer " + exception);
                    return -1;
                }
                if (n < 0) {
                    this.dataContainerTransaction.logger(2, "persist() unable to update customer");
                    return -1;
                }
            }
            if ((string = this.getAccountIdentifier()) == null || string.isEmpty()) {
                this.dataContainerTransaction.logger(4, "persist() No MOP to persist");
            } else {
                int n;
                if (this.currentMOPRow == null) {
                    this.dataContainerTransaction.logger(4, "persist() A new MOP must be created");
                    try {
                        this.currentMOPRow = (YP_Row)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "createNewMeanOfPayment", new Object[0]);
                    }
                    catch (Exception exception) {
                        this.dataContainerTransaction.logger(2, "persist() unable to create MOP " + exception);
                        return -1;
                    }
                    if (this.currentMOPRow == null) {
                        this.dataContainerTransaction.logger(2, "persist() unable to create MOP");
                        return -1;
                    }
                    this.setIDMeanOfPayment(this.currentMOPRow.getPrimaryKey());
                    this.setAccountStatus(AccountStatusEnumeration.ACTIVE.getValue());
                } else if (this.dataContainerTransaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AddCustomerData) {
                    this.dataContainerTransaction.logger(4, "persist() A MOP must be updated");
                } else if (this.dataContainerTransaction.getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.DeleteCustomerData) {
                    this.dataContainerTransaction.logger(4, "persist() A MOP must be deleted");
                }
                this.fieldCurrentMOPRow();
                try {
                    n = (Integer)this.dataContainerTransaction.getDataContainerBrand().dealRequest(this.dataContainerTransaction, "updateMeanOfPayment", this.currentMOPRow);
                }
                catch (Exception exception) {
                    this.dataContainerTransaction.logger(2, "persist() unable to update MOP " + exception);
                    return -1;
                }
                if (n < 0) {
                    this.dataContainerTransaction.logger(2, "persist() unable to update MOP");
                    return -1;
                }
            }
            return 1;
        }
        this.dataContainerTransaction.logger(2, "persist() TODO");
        return 0;
    }

    public List<YP_Row> getCurrentMOPRowList() {
        return this.currentMOPRowList;
    }

    public void setCurrentMOPRowList(List<YP_Row> list) {
        this.currentMOPRowList = list;
    }

    public List<ADF> getADFList() {
        return this.v_ADFList;
    }

    public void setADFList(List<ADF> list) {
        this.v_ADFList = list;
    }

    public boolean isLoadAccountPostponed() {
        return this.loadAccountPostponed;
    }

    public String getNetworkData() {
        return this.t_networkData;
    }

    public void setNetworkData(String string) {
        this.t_networkData = string;
    }

    public int checkMopStats() {
        if (this.currentMOPRow == null) {
            return 0;
        }
        return 1;
    }

    public int updateMopStats() {
        if (this.currentMOPRow == null) {
            return 0;
        }
        try {
            Timestamp timestamp = (Timestamp)this.currentMOPRow.getFieldValueByName("firstSystemGMTTime");
            Timestamp timestamp2 = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
            if (timestamp.getTime() == 0L) {
                this.currentMOPRow.set("firstSystemGMTTime", timestamp2);
            }
            this.currentMOPRow.set("lastSystemGMTTime", timestamp2);
            int n = (Integer)this.currentMOPRow.getFieldValueByName("nbTransaction");
            this.currentMOPRow.set("nbTransaction", ++n);
            TransactionStatusEnumeration transactionStatusEnumeration = YP_TCD_DCC_Business.getTransactionStatus(this.dataContainerTransaction);
            if (transactionStatusEnumeration != TransactionStatusEnumeration.ACCEPTED) {
                String string;
                int n2 = (Integer)this.currentMOPRow.getFieldValueByName("nbRefused");
                this.currentMOPRow.set("nbRefused", ++n2);
                String string2 = this.dataContainerTransaction.getAuthorisationResponseCode();
                if (string2 != null && !string2.isEmpty() && ((string = this.dataContainerTransaction.getAuthorisationApprovalCode()) == null || string.isEmpty())) {
                    int n3 = (Integer)this.currentMOPRow.getFieldValueByName("nbAuthRefused");
                    this.currentMOPRow.set("nbAuthRefused", ++n3);
                }
            } else {
                this.dataContainerTransaction.commonHandler.getTransactionAmount();
                switch (this.dataContainerTransaction.getRequestType()) {
                    // Empty switch
                }
            }
            try {
                String string = YP_Row.getStringValue(this.dataContainerTransaction.getExtensionValue("paresStatus"));
                if (string != null && string.contentEquals("Y")) {
                    this.currentMOPRow.set("last3DSVerificationTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                }
            }
            catch (Exception exception) {}
            this.currentMOPRow.setIsItAClonedRow(false);
            this.currentMOPRow.persist();
            return 1;
        }
        catch (Exception exception) {
            this.dataContainerTransaction.logger(2, "updateMopStats() unable to update MOP ", exception);
            return -1;
        }
    }

    public class ADF {
        public String aid;
        public String label;
        public String preferredName;
        public String priorityIndicator;
        public String languagePreference;
        public String issuerCodeTableIndex;
        public String issuerDiscretionaryData;
        public String appTagsExtension;
        public String emvTagsExtension;
    }

    public static enum AccountStatusEnumeration {
        UNKNOWN(0),
        CREATED(1),
        ACTIVE(2),
        INACTIVE(3),
        FORBIDDEN(4);

        public final int cardHolderAuthentication;

        private AccountStatusEnumeration(int n2) {
            this.cardHolderAuthentication = n2;
        }

        public int getValue() {
            return this.cardHolderAuthentication;
        }
    }
}

