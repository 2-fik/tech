/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.extendedapplication;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.business.DAO_Transaction;
import org.yp.designaccesobjects.technic.DAO_Contract;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.extendedapplication.YP_ExtendedApplication_Print;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.bin.YP_TCD_DCB_Interface_BIN;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.YP_TCD_DCB_Interface_Currency;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.protocol.YP_PROT_Interface_Extension;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.YP_TCD_DCB_Interface_Time;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_ISO8583;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class YP_BCD_A_DCC_Template
extends YP_TCD_DCC_EFT_Business
implements YP_PROT_Interface_ISO8583 {
    public YP_PROT_Interface_Extension protocolExtension;
    public YP_TCD_DCB_Interface_EMV emvExtension;
    public YP_TCD_DCB_Interface_BIN binExtension;
    private boolean maskTrack2DiscretionnaryData = true;

    public YP_BCD_A_DCC_Template(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    protected abstract YP_TCD_DCB_Interface_EMV createEmvExtension();

    protected abstract YP_PROT_Interface_Extension createProtocolExtension();

    protected abstract YP_ExtendedApplication_Print createPrint(YP_TCD_DC_Transaction var1);

    @Override
    public int initialize() {
        super.initialize();
        this.timeInterface = (YP_TCD_DCB_Interface_Time)((Object)this.newPluginByName("PLUGIN_TIME", this));
        this.timeInterface.initialize();
        this.currencyInterface = (YP_TCD_DCB_Interface_Currency)((Object)this.newPluginByName("PLUGIN_CURRENCY", this));
        this.currencyInterface.initialize();
        this.emvExtension = this.createEmvExtension();
        this.protocolExtension = this.createProtocolExtension();
        if (this.protocolExtension != null) {
            this.protocolExtension.initialize();
        }
        this.emvExtension.initialize();
        this.binExtension = (YP_TCD_DCB_Interface_BIN)((Object)this.newPluginByName("DataContainerExtensionBIN", this));
        this.binExtension.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        if (this.protocolExtension != null) {
            this.protocolExtension.shutdown();
            this.protocolExtension = null;
        }
        if (this.emvExtension != null) {
            this.emvExtension.shutdown();
            this.emvExtension = null;
        }
        if (this.binExtension != null) {
            this.binExtension.shutdown();
            this.binExtension = null;
        }
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "DataContainerTemplate";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String getCardAcceptorIdentificationCode() {
        return null;
    }

    @Override
    public int onChange(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return super.onChange(yP_TCD_DesignAccesObject);
    }

    @Override
    public int onSaveBefore(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list, YP_Row yP_Row) {
        return super.onSaveBefore(yP_TCD_DesignAccesObject, list, yP_Row);
    }

    @Override
    public int persistTransaction(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) throws Exception {
        try {
            String string;
            this.logTransactionStatus(yP_TCD_DC_Transaction);
            if (this.maskTrack2DiscretionnaryData && (string = yP_TCD_DC_Transaction.accountHandler.getTrack2DiscretionnaryData()) != null && !string.isEmpty()) {
                StringBuilder stringBuilder = new StringBuilder(string.length());
                int n = 0;
                while (n < string.length()) {
                    stringBuilder.append('E');
                    ++n;
                }
                yP_TCD_DC_Transaction.accountHandler.setTrack2DiscretionnaryData(stringBuilder.toString());
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return super.persistTransaction(yP_TCD_DC_Transaction);
    }

    @Override
    public List<YP_TCD_DC_Context.Action> getActionList(String string, YP_Row yP_Row) {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int executeAction(YP_Transaction yP_Transaction, String string, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        try {
            if (string.contentEquals("View_Contract")) {
                if (!(yP_Row instanceof DAO_Contract)) return 0;
                switch (action.id) {
                    case "FirstInit": {
                        this.logger(2, "executeAction() firstInit is a get/setdata on initParam and a remoteParameterization !!!");
                        return -1;
                    }
                    case "Deactivation": {
                        this.logger(4, "executeAction() deactivation  needed");
                        return 0;
                    }
                    default: {
                        this.logger(2, "executeAction() unknown action " + action.id);
                        return -1;
                    }
                    case "Closure": 
                    case "IncidentsReport": 
                    case "RemoteParameterizationReport": 
                    case "FunctionnalParameterReport": 
                    case "HardwareReport": 
                    case "Reconciliation": 
                    case "RemoteParameterization": 
                    case "SummaryReport": 
                    case "ReferenceParameterReport": 
                }
                return 0;
            }
            if (!string.contentEquals("View_Transaction")) return 0;
            if (!(yP_Row instanceof DAO_Transaction)) return 0;
            DAO_Transaction dAO_Transaction = (DAO_Transaction)yP_Row;
            switch (action.id) {
                case "Reprint": 
                case "ReprintMerchant": 
                case "ReprintCustomer": {
                    switch (action.id) {
                        case "Reprint": {
                            yP_Transaction.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.Reprint);
                            break;
                        }
                        case "ReprintCustomer": {
                            yP_Transaction.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.ReprintCustomer);
                            break;
                        }
                        case "ReprintMerchant": {
                            yP_Transaction.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.ReprintMerchant);
                            break;
                        }
                    }
                    if (action.propertiesList != null) {
                        for (Property property : action.propertiesList) {
                            if (!property.getName().contentEquals("TicketFormat")) continue;
                            yP_Transaction.getDataContainerTransaction().commonHandler.setPrintFormat(property.getValue());
                        }
                    }
                    yP_Transaction.getDataContainerTransaction().setSubRequestType(null);
                    yP_Transaction.getDataContainerTransaction().commonHandler.setReferenceTransactionPrimaryKey(dAO_Transaction.getPrimaryKey());
                    YP_Application yP_Application = this.newApplicationPlugin(yP_Transaction);
                    yP_Transaction.getDataContainerTransaction().setContractIdentifier(action.applicationIdentifier);
                    yP_Application.setContractIdentifier(action.applicationIdentifier);
                    yP_Application.initialize();
                    yP_Application.dealRequest(yP_Transaction, "dealTransaction", dAO_Transaction);
                    yP_Application.shutdown();
                }
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "executeAction()" + exception);
            return -1;
        }
    }

    @Override
    public String getTransactionTicket(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, boolean bl, int n) {
        YP_ExtendedApplication_Print yP_ExtendedApplication_Print = this.createPrint(yP_TCD_DC_Transaction);
        return yP_ExtendedApplication_Print.ticket(bl, n);
    }

    public boolean getMaskTrack2DiscretionnaryData() {
        return this.maskTrack2DiscretionnaryData;
    }

    public void setMaskTrack2DiscretionnaryData(boolean bl) {
        this.maskTrack2DiscretionnaryData = bl;
    }
}

