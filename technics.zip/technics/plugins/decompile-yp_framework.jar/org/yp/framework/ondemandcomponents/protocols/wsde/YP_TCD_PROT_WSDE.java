/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.wsde;

import java.util.Arrays;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.framework.services.YP_TS_GlobalProcessManager;

public class YP_TCD_PROT_WSDE
extends YP_OnDemandComponent
implements YP_PROT_Interface_Com {
    private YP_PHYS_Interface physicalInterface;
    private int physicalInterfaceToShutdown = 0;

    public YP_TCD_PROT_WSDE(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (!(yP_Object instanceof YP_TS_GlobalProcessManager) && objectArray != null && objectArray.length > 0 && objectArray[0] instanceof YP_PHYS_Interface) {
            this.physicalInterface = (YP_PHYS_Interface)objectArray[0];
        }
    }

    @Override
    public int setParameters(Object ... objectArray) {
        return 0;
    }

    @Override
    public int waitConnection() {
        return 0;
    }

    @Override
    public int connect(YP_Row yP_Row) {
        return 0;
    }

    @Override
    public void send(byte[] byArray, boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException {
        int n = byArray.length;
        byte[] byArray2 = new byte[n += 19];
        byArray2[0] = -49;
        byArray2[1] = -68;
        byArray2[2] = -67;
        byArray2[3] = (byte)(0xFF & (byte)((n - 6) / 65536));
        byArray2[4] = (byte)(0xFF & (byte)((n - 6) / 256));
        byArray2[5] = (byte)(0xFF & (byte)((n - 6) % 256));
        byArray2[6] = 0;
        byArray2[7] = 0;
        byArray2[8] = 1;
        byArray2[9] = 0;
        byArray2[10] = 0;
        byArray2[11] = 1;
        byArray2[12] = 1;
        byArray2[13] = 0;
        byArray2[14] = 0;
        byArray2[15] = 2;
        byArray2[16] = (byte)(0xFF & (byte)(byArray.length / 65536));
        byArray2[17] = (byte)(0xFF & (byte)(byArray.length / 256));
        byArray2[18] = (byte)(0xFF & (byte)(byArray.length % 256));
        System.arraycopy(byArray, 0, byArray2, 19, byArray.length);
        int n2 = this.physicalInterface.send(byArray2, byArray2.length);
        if (n2 < 0) {
            this.logger(2, "send() broken connection");
            throw new YP_PROT_Interface_Com.DisconnectionException();
        }
    }

    @Override
    public byte[] receive(boolean bl) throws YP_PROT_Interface_Com.TimeOutException, YP_PROT_Interface_Com.DisconnectionException, YP_PROT_Interface_Com.BadFormatException {
        try {
            int n = 0;
            byte[] byArray = new byte[6];
            do {
                if ((n = this.physicalInterface.recv(byArray, 0, 6, 3000)) < 0) {
                    this.logger(2, "receive() broken connection");
                    throw new YP_PROT_Interface_Com.DisconnectionException();
                }
                if (n == 0) {
                    this.logger(2, "receive() TimeOut");
                    throw new YP_PROT_Interface_Com.TimeOutException();
                }
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "receive() Length received ");
            } while (n == 0);
            if (n != 6) {
                this.logger(2, "receive() bad mess 1");
                throw new YP_PROT_Interface_Com.BadFormatException();
            }
            if ((byArray[0] & 0xFF) != 207 || (byArray[1] & 0xFF) != 188 || (byArray[2] & 0xFF) != 189) {
                this.logger(2, "receive() bad mess 2");
                throw new YP_PROT_Interface_Com.BadFormatException();
            }
            int n2 = (byArray[3] & 0xFF) * 256 * 256 + (byArray[4] & 0xFF) * 256 + (byArray[5] & 0xFF);
            byte[] byArray2 = new byte[n2];
            int n3 = 0;
            do {
                if ((n = this.physicalInterface.recv(byArray2, n3, n2 - n3, 3000)) < 0) {
                    this.logger(2, "receive() broken connection");
                    throw new YP_PROT_Interface_Com.DisconnectionException();
                }
                if (n == 0) {
                    this.logger(2, "receive() TimeOut");
                    throw new YP_PROT_Interface_Com.TimeOutException();
                }
                n3 += n;
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "receive() Data received " + n);
            } while (n >= 0 && n3 != n2);
            byte[] byArray3 = this.getValue(byArray2, 0, byArray2.length, 1);
            if (byArray3 == null) {
                this.logger(2, "receive() no version");
                throw new YP_PROT_Interface_Com.BadFormatException();
            }
            if (byArray3.length == 0) {
                this.logger(2, "receive() bad version value");
                throw new YP_PROT_Interface_Com.BadFormatException();
            }
            return this.getValue(byArray2, 0, byArray2.length, 2);
        }
        catch (Exception exception) {
            this.logger(2, "receive() " + exception);
            return null;
        }
    }

    private byte[] getValue(byte[] byArray, int n, int n2, int n3) {
        byte[] byArray2 = new byte[]{(byte)(0xFF & (byte)(n3 / 65536)), (byte)(0xFF & (byte)(n3 / 256)), (byte)(0xFF & (byte)(n3 % 256))};
        int n4 = n;
        while (n4 <= n2 - 6) {
            int n5 = (byArray[n4 + 3] & 0xFF) * 256 * 256 + (byArray[n4 + 4] & 0xFF) * 256 + (byArray[n4 + 5] & 0xFF);
            if (byArray[n4 + 0] == byArray2[0] && byArray[n4 + 1] == byArray2[1] && byArray[n4 + 2] == byArray2[2]) {
                if (n5 == 0) {
                    return new byte[0];
                }
                if (n2 < n4 + 6 + n5) {
                    this.logger(2, "getValue() bad format");
                    return null;
                }
                return Arrays.copyOfRange(byArray, n4 + 6, n4 + 6 + n5);
            }
            n4 += 3;
            n4 += 3;
            n4 += n5;
        }
        this.logger(4, "getValue() not found" + Integer.toHexString(n3));
        return null;
    }

    @Override
    public int disconnect() {
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        if (this.physicalInterfaceToShutdown == 1) {
            try {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("ConnectionManager");
                yP_Service.dealRequest(this, "closeConnection", this.physicalInterface);
            }
            catch (Exception exception) {
                this.logger(2, "connect() impossible to release the connection plugin " + exception);
            }
            this.physicalInterfaceToShutdown = 0;
        }
        this.physicalInterface = null;
        return 1;
    }

    @Override
    public String toString() {
        return "WSDE";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public String getParameter(String string) {
        return null;
    }

    @Override
    public int waitDisconnection() {
        return 0;
    }

    @Override
    public int setComParameter(String string, String string2) {
        return 0;
    }
}

