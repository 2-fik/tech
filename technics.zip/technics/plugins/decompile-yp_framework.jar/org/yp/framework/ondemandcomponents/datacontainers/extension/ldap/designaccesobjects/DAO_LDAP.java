/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.ldap.designaccesobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_LDAP
extends YP_Row {
    @PrimaryKey
    public long idLDAP = 0L;
    public byte[] contextFactory = new byte[128];
    public byte[] serverURL = new byte[64];
    public byte[] baseDN = new byte[128];
    public byte[] userDNFormat = new byte[128];
    public byte[] authenficationMode = new byte[64];
    public byte[] referralMode = new byte[64];
}

