/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.emv;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.YP_TCD_DCB_Interface_Extension;

public interface YP_TCD_DCB_Interface_EMV
extends YP_TCD_DCB_Interface_Extension {
    public YP_TCD_DesignAccesObject getAIDTable();

    public long getAIDTableChecksum();

    public YP_TCD_DesignAccesObject getAIDParametersTable();

    public long getAIDParametersTableChecksum();

    public YP_TCD_DesignAccesObject getKeysTable();

    public long getKeysTableChecksum();

    public YP_Row getAIDParameters(String var1);

    public YP_Row getAIDData(String var1);

    public List<YP_Row> getAIDList(String var1);

    public List<Integer> getTAVNList(String var1);

    public int setTVR(YP_TCD_DC_Transaction var1, int var2, int var3);

    public int resetTVR(YP_TCD_DC_Transaction var1);
}

