/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.iso8583;

import org.yp.xml.jaxb.iso8583.ISO8583Message;

final class ISO8583MessageObject {
    final String name;
    final ISO8583Message iso8583Message;
    int onUse = 1;

    public ISO8583MessageObject(String string, ISO8583Message iSO8583Message) {
        this.name = string;
        this.iso8583Message = iSO8583Message;
    }
}

