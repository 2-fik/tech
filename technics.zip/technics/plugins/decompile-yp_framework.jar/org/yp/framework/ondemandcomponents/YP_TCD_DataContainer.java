/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.utils.UtilsYP;

public abstract class YP_TCD_DataContainer
extends YP_OnDemandComponent {
    private final List<YP_TCD_DesignAccesObject> dao_List = new ArrayList<YP_TCD_DesignAccesObject>();
    protected YP_TCD_DataBaseConnector dataBaseConnector = null;
    protected List<YP_TCD_DataBaseConnector> dataBaseConnectorList = null;

    public YP_TCD_DataContainer(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        if (this.getDataBaseConnectorList() == null && this.getPropertyFileName() != null) {
            this.setDataBaseConnectorList(new ArrayList<YP_TCD_DataBaseConnector>());
            String string = this.getProperty(this.getPropertyFileName(), "dataBaseConnectorName");
            int n = 0;
            while (true) {
                String string2 = this.getProperty(this.getPropertyFileName(), "dataBaseConnectorProperties_" + ++n);
                if (string == null || string2 == null) break;
                YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = (YP_TCD_DataBaseConnector)this.newPluginByName(string, new Object[0]);
                yP_TCD_DataBaseConnector.setPropertyFileName(string2);
                yP_TCD_DataBaseConnector.initialize();
                if (UtilsYP.getInstanceNumber() == yP_TCD_DataBaseConnector.getSiteIdentifier()) {
                    this.setDataBaseConnector(yP_TCD_DataBaseConnector);
                }
                this.getDataBaseConnectorList().add(yP_TCD_DataBaseConnector);
            }
        }
        return 1;
    }

    @Override
    public int shutdown() {
        try {
            this.flushCachedTables();
            for (YP_TCD_DesignAccesObject yP_OnDemandComponent : this.dao_List) {
                if (yP_OnDemandComponent.getFather() != this) {
                    this.logger(2, "shutdown() designAccesObject no shutdown if not ours....");
                    continue;
                }
                yP_OnDemandComponent.shutdown();
            }
            this.dao_List.clear();
            if (this.dataBaseConnectorList != null) {
                for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : this.dataBaseConnectorList) {
                    yP_TCD_DataBaseConnector.shutdown();
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "shutdown() error :" + exception);
        }
        return super.shutdown();
    }

    public YP_TCD_DesignAccesObject getDesignAccesObject_ByNumber(int n) {
        for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
            if (yP_TCD_DesignAccesObject == null || yP_TCD_DesignAccesObject.getTableNumber() != n) continue;
            return yP_TCD_DesignAccesObject;
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDesignAccesObject_ByNumberAndVersion(int n, String string) {
        for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
            String string2;
            if (yP_TCD_DesignAccesObject == null || yP_TCD_DesignAccesObject.getTableNumber() != n || (string2 = yP_TCD_DesignAccesObject.getTableVersion()) == null || !string2.contentEquals(string)) continue;
            return yP_TCD_DesignAccesObject;
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDesignAccesObject_ByName(String string) {
        return this.getDesignAccesObject_ByName(string, false);
    }

    public YP_TCD_DesignAccesObject getDesignAccesObject_ByName(String string, boolean bl) {
        for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
            if (yP_TCD_DesignAccesObject == null || (!bl || !yP_TCD_DesignAccesObject.getTableName().equalsIgnoreCase(string)) && (bl || !yP_TCD_DesignAccesObject.getTableName().contentEquals(string))) continue;
            return yP_TCD_DesignAccesObject;
        }
        if (!bl) {
            for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
                if (yP_TCD_DesignAccesObject == null || !yP_TCD_DesignAccesObject.getTableName().equalsIgnoreCase(string)) continue;
                this.logger(2, "getDesignAccesObject_ByName() maybe you should have used " + yP_TCD_DesignAccesObject.getTableName() + " instead of " + string);
                break;
            }
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDesignAccesObject_ByFullTableName(String string) {
        for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
            if (yP_TCD_DesignAccesObject == null || yP_TCD_DesignAccesObject.getFullTableName().compareTo(string) != 0) continue;
            return yP_TCD_DesignAccesObject;
        }
        return null;
    }

    public int flushCachedTables() {
        int n = 0;
        for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : this.getDAOList()) {
            int n2;
            if (!(yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) || (n2 = ((YP_TCD_DAO_SQL_Transaction)yP_TCD_DesignAccesObject).getNbTransactionsToFlush()) <= 0) continue;
            this.processIsAlive();
            yP_TCD_DesignAccesObject.persist();
            n += n2;
        }
        return n;
    }

    public void setDataBaseConnector(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) {
        this.dataBaseConnector = yP_TCD_DataBaseConnector;
    }

    public YP_TCD_DataBaseConnector getDataBaseConnector() {
        return this.dataBaseConnector;
    }

    public void setDataBaseConnectorList(List<YP_TCD_DataBaseConnector> list) {
        this.dataBaseConnectorList = list;
    }

    public List<YP_TCD_DataBaseConnector> getDataBaseConnectorList() {
        return this.dataBaseConnectorList;
    }

    public int dealParameterUpdate(YP_Row yP_Row) {
        String string = yP_Row.getFieldStringValueByName("DB_Table");
        if (string == null) {
            this.logger(2, "dealParameterUpdate() DB_Table not found...");
            return -1;
        }
        return this.dealParameterUpdate(string);
    }

    public int dealParameterUpdate(String string) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDesignAccesObject_ByName(string);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "dealParameterUpdate()" + string + " not found...");
            return -1;
        }
        try {
            try {
                yP_TCD_DesignAccesObject.lock();
                if (UtilsYP.getInstanceRole() == 1 && this instanceof YP_TCD_DC_Context) {
                    yP_TCD_DesignAccesObject.getTableSystemGMTTime();
                    yP_TCD_DesignAccesObject.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                    ((YP_TCD_DC_Context)this).updateTableStatus(yP_TCD_DesignAccesObject);
                }
                yP_TCD_DesignAccesObject.reload();
            }
            catch (Exception exception) {
                this.logger(2, "dealParameterUpdate()" + exception);
                yP_TCD_DesignAccesObject.unlock();
                return -1;
            }
        }
        finally {
            yP_TCD_DesignAccesObject.unlock();
        }
        return 1;
    }

    public int size() {
        return this.getDAOList().size();
    }

    public abstract String get(String var1);

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    public abstract int onChange(YP_TCD_DesignAccesObject var1);

    public abstract int onSaveBefore(YP_TCD_DesignAccesObject var1, List<YP_Row> var2, YP_Row var3);

    public abstract int onSaveAfter(YP_TCD_DesignAccesObject var1, List<YP_Row> var2, YP_Row var3);

    public final List<YP_TCD_DesignAccesObject> getDAOList() {
        return this.dao_List;
    }
}

