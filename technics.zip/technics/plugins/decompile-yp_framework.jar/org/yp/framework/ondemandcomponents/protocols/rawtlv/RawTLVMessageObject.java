/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.protocols.rawtlv;

import org.yp.xml.jaxb.rawtlv.RawTLVMessage;

final class RawTLVMessageObject {
    final String name;
    final RawTLVMessage rawtTLVMessage;
    int onUse = 1;

    public RawTLVMessageObject(String string, RawTLVMessage rawTLVMessage) {
        this.name = string;
        this.rawtTLVMessage = rawTLVMessage;
    }
}

