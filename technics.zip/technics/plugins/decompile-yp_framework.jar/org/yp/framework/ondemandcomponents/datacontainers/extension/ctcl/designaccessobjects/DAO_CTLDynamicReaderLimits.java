/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.designaccessobjects;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_CTLDynamicReaderLimits
extends YP_Row {
    @PrimaryKey
    public long idDAO_CTLDynamicReaderLimits = 0L;
    public byte[] kernelID = new byte[2];
    public byte[] applicationPgmId = new byte[32];
    public byte[] numericalCurrencyCode = new byte[3];
    public byte[] ctlTransactionLimit = new byte[12];
    public byte[] ctlFloorLimit = new byte[12];
    public byte[] CVMRequiredLimit = new byte[12];
    public Boolean statusCheckSupport;
    public Boolean zeroAmountAllowedSupport;
    public byte[] externalReference = new byte[30];
}

