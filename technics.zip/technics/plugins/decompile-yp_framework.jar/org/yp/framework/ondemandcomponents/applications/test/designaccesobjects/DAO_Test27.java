/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.Bitmap;
import org.yp.utils.enums.EntryModeEnumeration;

public class DAO_Test27
extends YP_Row {
    @PrimaryKey
    public long idTest27 = 0L;
    @Index
    public byte[] test27Array = new byte[12];
    @Index
    public int test27Int = 0;
    @Index
    public long test27Long = 0L;
    @Index
    public float test27Float = 0.0f;
    @Index
    public Timestamp test27Timestamp = new Timestamp(0L);
    @Index
    public Date test27Date = new Date(0L);
    @Index
    public EntryModeEnumeration test27Enumeration;
    @Index
    public Boolean test27Boolean;
    @Index
    public Bitmap test27Bitmap;
}

