/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.pos.interfaces;

import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;

public interface YP_PROT_Update {
    public List<UpdateHandler.ParameterFile> getParameterFileList(UpdateHandler var1);

    public void setParameterFileList(List<UpdateHandler.ParameterFile> var1);
}

