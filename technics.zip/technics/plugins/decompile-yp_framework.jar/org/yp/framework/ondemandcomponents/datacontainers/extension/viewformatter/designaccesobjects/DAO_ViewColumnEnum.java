/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.designaccessobjects.DAO_Enumeration;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;

public class DAO_ViewColumnEnum
extends YP_Row {
    @PrimaryKey
    public long idViewColumnEnum = 0L;
    @ForeignKey(name=DAO_ViewColumn.class)
    public long idViewColumn = 0L;
    @ForeignKey(name=DAO_Enumeration.class)
    public long idEnum = 0L;
}

