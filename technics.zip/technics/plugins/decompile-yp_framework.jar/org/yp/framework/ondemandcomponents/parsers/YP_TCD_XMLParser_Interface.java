/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.UnmarshalException
 */
package org.yp.framework.ondemandcomponents.parsers;

import javax.xml.bind.UnmarshalException;

public interface YP_TCD_XMLParser_Interface {
    public String objectToXML(Object var1);

    public Object xmlToObject(String var1) throws UnmarshalException;

    public Object xmlToObject(byte[] var1);
}

