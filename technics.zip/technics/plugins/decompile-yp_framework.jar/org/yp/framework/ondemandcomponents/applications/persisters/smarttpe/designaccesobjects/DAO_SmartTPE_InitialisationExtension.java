/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.persisters.smarttpe.designaccesobjects;

public class DAO_SmartTPE_InitialisationExtension {
    public byte[] webServiceURL = new byte[128];
    public byte[] method = new byte[12];
    public byte[] proxyHost = new byte[32];
    public int proxyPort = 0;
    public byte[] trustStorePath = new byte[120];
    public byte[] trustStorePasswd = new byte[32];
    public byte[] keyStorePath = new byte[120];
    public byte[] keyStorePasswd = new byte[32];
    public byte[] keyAlias = new byte[32];
}

