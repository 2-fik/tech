/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.applications.test.designaccesobjects;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Test35
extends YP_Row {
    @PrimaryKey
    public long idTest35 = 0L;
    public int MIN = 0;
    public long MAX = 0L;
    public float SELECT = 0.0f;
    public byte[] WHERE = new byte[50];
    public Timestamp IN = new Timestamp(0L);
    public Date MOY = new Date(0L);
}

