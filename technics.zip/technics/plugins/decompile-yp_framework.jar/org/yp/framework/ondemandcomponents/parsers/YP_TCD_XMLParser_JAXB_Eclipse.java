/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.JAXBContext
 *  javax.xml.bind.Marshaller
 *  javax.xml.bind.Unmarshaller
 */
package org.yp.framework.ondemandcomponents.parsers;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.parsers.YP_TCD_XMLParser_Interface;
import org.yp.xml.jaxb.xpde.XPDERequest;
import org.yp.xml.jaxb.xpde.XPDEResponse;

public final class YP_TCD_XMLParser_JAXB_Eclipse
extends YP_OnDemandComponent
implements YP_TCD_XMLParser_Interface {
    private Marshaller globalMarshallerResponse;
    private Marshaller globalMarshallerRequest;
    private Unmarshaller globalUnmarshaller;

    public YP_TCD_XMLParser_JAXB_Eclipse(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        try {
            JAXBContext jAXBContext = JAXBContext.newInstance((Class[])new Class[]{XPDERequest.class});
            JAXBContext jAXBContext2 = JAXBContext.newInstance((Class[])new Class[]{XPDEResponse.class});
            this.globalMarshallerResponse = jAXBContext2.createMarshaller();
            this.globalMarshallerResponse.setProperty("jaxb.formatted.output", (Object)Boolean.TRUE);
            this.globalMarshallerRequest = jAXBContext.createMarshaller();
            this.globalMarshallerRequest.setProperty("jaxb.formatted.output", (Object)Boolean.TRUE);
            this.globalUnmarshaller = jAXBContext.createUnmarshaller();
        }
        catch (Exception exception) {
            this.logger(2, "initialize()  " + exception);
        }
        return 1;
    }

    @Override
    public final String toString() {
        return "XMLParserJAXB_Eclipse";
    }

    @Override
    public final String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    @Override
    public String objectToXML(Object object) {
        try {
            StringWriter stringWriter = new StringWriter();
            if (object instanceof XPDEResponse) {
                this.globalMarshallerResponse.marshal(object, (Writer)stringWriter);
            } else {
                this.globalMarshallerRequest.marshal(object, (Writer)stringWriter);
            }
            return stringWriter.toString();
        }
        catch (Exception exception) {
            this.logger(2, "objectToXML() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(String string) {
        try {
            StringReader stringReader = new StringReader(string);
            return this.globalUnmarshaller.unmarshal((Reader)stringReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }

    @Override
    public Object xmlToObject(byte[] byArray) {
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(new ByteArrayInputStream(byArray));
            return this.globalUnmarshaller.unmarshal((Reader)inputStreamReader);
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() " + exception);
            return null;
        }
    }
}

