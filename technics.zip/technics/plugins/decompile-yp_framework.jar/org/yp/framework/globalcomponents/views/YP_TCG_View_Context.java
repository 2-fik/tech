/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.util.HashSet;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.StoreStatusEnumeration;

public class YP_TCG_View_Context
extends YP_TCG_View {
    public static final int NB_MAX_CONTRACT_IN_CONTEXT = 40000;
    public static final String CONTEXT_TYPE_GROUP = "G";
    public static final String CONTEXT_TYPE_GROUP_BRAND = "G_B";
    public static final String CONTEXT_TYPE_BRAND = "B";
    public static final String CONTEXT_TYPE_MERCHANT = "M";
    public static final String CONTEXT_TYPE_APPLICATION = "A";
    public static final String CONTEXT_TYPE_CONTRACT = "C";
    public static final String CONTEXT_TYPE_STORE = "S";
    public static final String CONTEXT_TYPE_USER = "U";
    public static final String CONTEXT_TYPE_VIEW = "V";
    public static final String CONTEXT_TYPE_SERVER = "SV";
    public static final String CONTEXT_COLUMN_TYPE = "1";
    public static final String CONTEXT_COLUMN_NAME = "2";
    public static final String CONTEXT_COLUMN_LABEL = "3";
    public static final String CONTEXT_COLUMN_EXTRA = "4";
    public static final String CONTEXT_SERVER_VERSION = "MainVersion";
    public static final String CONTEXT_USER_ACESS_LEVEL = "AccessLevel";
    public static final String CONTEXT_USER_CASHIER_CREATION_ALLOWED = "CashierCreationAllowed";
    private YP_TS_DataContainerManager dataContainerManager;
    private YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Context(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Context";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.133";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        yP_View.addCustomColumn(CONTEXT_COLUMN_TYPE, "Type", "string", 1);
        yP_View.addCustomColumn(CONTEXT_COLUMN_NAME, "Name", "string", 2);
        yP_View.addCustomColumn(CONTEXT_COLUMN_LABEL, "Label", "string", 3);
        yP_View.addCustomColumn(CONTEXT_COLUMN_EXTRA, "Extra", "string", 4, true);
        return yP_View;
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        block67: {
            block66: {
                block64: {
                    block65: {
                        var6_5 = this.createEmptyView(var1_1, var2_2, var3_3, var5_4);
                        if (var6_5 == null) {
                            this.logger(2, "getView() ");
                            return null;
                        }
                        var7_6 = 0;
                        var8_7 = false;
                        var9_8 = false;
                        var6_5.setRowID(var7_6, Integer.toString(var7_6));
                        var6_5.addFieldValue(var7_6, "1", "SV");
                        var6_5.addFieldValue(var7_6, "2", "MainVersion");
                        var6_5.addFieldValue(var7_6, "3", this.getVersion());
                        ++var7_6;
                        var10_9 = var2_2.getGroupList();
                        var11_10 = var2_2.getBrandList();
                        var12_11 = var2_2.getMerchantList();
                        var13_12 = var2_2.getApplicationList();
                        if (var10_9 == null || var11_10 == null || var12_11 == null || var13_12 == null) {
                            this.logger(3, "getView() null exception avoided");
                            return null;
                        }
                        var14_13 = new HashSet<YP_TCD_DCC_Merchant>(var12_11);
                        for (Object var15_16 : var13_12) {
                            if (var15_16 == null) continue;
                            var14_13.add(var15_16.getDataContainerMerchant());
                        }
                        var15_16 = new HashSet<YP_TCD_DCC_Brand>(var11_10);
                        for (Object var16_14 : var14_13) {
                            var15_16.add(var16_14.getDataContainerBrand());
                        }
                        for (Object var16_14 : var10_9) {
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "G");
                            var6_5.addFieldValue(var7_6, "2", UtilsYP.cryptInfo(var16_14.getGroupName()));
                            var6_5.addFieldValue(var7_6, "3", var16_14.getGroupLabel());
                            ++var7_6;
                        }
                        var16_15 = var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel();
                        var18_18 = var15_16.iterator();
                        while (var18_18.hasNext()) {
                            var17_17 = (YP_TCD_DCC_Brand)var18_18.next();
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "B");
                            var6_5.addFieldValue(var7_6, "2", UtilsYP.cryptInfo(var17_17.getBrandName()));
                            var6_5.addFieldValue(var7_6, "3", var17_17.getBrandLabel());
                            if (!(var16_15 != 1 && var16_15 != 2 || (var19_19 = this.dataContainerTechnique.getApplicationListInsideBrand((YP_TCD_DCC_Brand)var17_17)) == null || var19_19.isEmpty())) {
                                var20_21 = new StringBuilder();
                                var22_26 = var19_19.iterator();
                                while (var22_26.hasNext()) {
                                    var21_25 = (YP_Row)var22_26.next();
                                    var23_29 = (Long)var21_25.getFieldValueByName("idApplication");
                                    for (Object var25_35 : this.dataContainerTechnique.application) {
                                        var27_38 = (Long)var25_35.getFieldValueByName("idApplication");
                                        if (var27_38 != var23_29) continue;
                                        var20_21.append(var25_35.getFieldStringValueByName("applicationLabel"));
                                        var20_21.append("|;");
                                    }
                                }
                                var6_5.addFieldValue(var7_6, "4", var20_21.toString());
                            }
                            if (!var9_8 && !var17_17.isReservationDetailsEmpty()) {
                                var9_8 = true;
                            }
                            ++var7_6;
                        }
                        for (Object var17_17 : var14_13) {
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "M");
                            var6_5.addFieldValue(var7_6, "2", String.valueOf(UtilsYP.cryptInfo(var17_17.getDataContainerBrand().getBrandName())) + '_' + UtilsYP.cryptInfo(var17_17.getMerchantName()));
                            var6_5.addFieldValue(var7_6, "3", var17_17.getMerchantLabel());
                            ++var7_6;
                        }
                        for (Object var17_17 : this.dataContainerTechnique.application) {
                            var19_20 = false;
                            if (var16_15 == 2 || var16_15 == 1) {
                                var20_22 = (Long)var17_17.getFieldValueByName("idBrand");
                                if (var20_22 == 0L) {
                                    var19_20 = true;
                                } else {
                                    for (Object var22_26 : var11_10) {
                                        if (var22_26.getIDBrand() != var20_22) continue;
                                        var19_20 = true;
                                        break;
                                    }
                                    if (!var19_20) {
                                        var22_27 = var17_17.getPrimaryKey();
                                        for (Object var24_41 : var13_12) {
                                            if (var24_41 == null || var22_27 != (var26_37 = var24_41.getApplicationPlugin().getApplicationRow().getPrimaryKey())) continue;
                                            var19_20 = true;
                                            break;
                                        }
                                    }
                                }
                            } else {
                                var20_22 = var17_17.getPrimaryKey();
                                for (Object var22_26 : var13_12) {
                                    if (var22_26 == null || var20_22 != (var24_42 = var22_26.getApplicationPlugin().getApplicationRow().getPrimaryKey())) continue;
                                    var19_20 = true;
                                    break;
                                }
                            }
                            if (!var19_20) continue;
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "A");
                            var6_5.addFieldValue(var7_6, "2", UtilsYP.cryptInfo(var17_17.getFieldStringValueByName("applicationName")));
                            var6_5.addFieldValue(var7_6, "3", var17_17.getFieldStringValueByName("applicationLabel"));
                            ++var7_6;
                        }
                        var17_17 = var2_2.getDataContainerTransaction().contextHandler.getStoreIdentifier();
                        if (var17_17 == null || var17_17.isEmpty()) break block64;
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "getView() We are on a store, we must only send back our store");
                        }
                        if (var12_11.size() <= 1) break block65;
                        this.logger(2, "getView() too many merchants for one store");
                        break block66;
                    }
                    var18_18 = null;
                    if (var12_11.size() == 1) {
                        var18_18 = var12_11.get(0);
                    } else {
                        var19_19 = var14_13.toArray();
                        if (((Object[])var19_19).length == 1) {
                            var18_18 = (YP_TCD_DCC_Merchant)var19_19[0];
                        }
                    }
                    if (var18_18 == null) break block66;
                    var6_5.setRowID(var7_6, Integer.toString(var7_6));
                    var6_5.addFieldValue(var7_6, "1", "S");
                    var6_5.addFieldValue(var7_6, "2", String.valueOf(UtilsYP.cryptInfo(var18_18.getDataContainerBrand().getBrandName())) + '_' + UtilsYP.cryptInfo(var18_18.getMerchantName()) + '_' + (String)var17_17);
                    var6_5.addFieldValue(var7_6, "3", var18_18.getDataContainerBrand().getStoreLabel(var18_18.getIDMerchant(), (String)var17_17));
                    ++var7_6;
                    var8_7 = true;
                    break block66;
                }
                var18_18 = null;
                if (var12_11.size() > 1) {
                    var18_18 = new HashSet<E>();
                    var20_21 = var15_16.iterator();
                    while (var20_21.hasNext()) {
                        var19_19 = (YP_TCD_DCC_Brand)var20_21.next();
                        var21_25 = var19_19.getIdMerchantWithStore();
                        if (var21_25 == null) continue;
                        var18_18.addAll(var21_25);
                    }
                }
                if (var18_18 == null || !var18_18.isEmpty()) {
                    var20_21 = var12_11.iterator();
                    while (var20_21.hasNext()) {
                        var19_19 = var20_21.next();
                        if (var18_18 != null && !var18_18.contains(var19_19.getIDMerchant()) || (var21_25 = var19_19.getDataContainerBrand().getStoreList(var19_19.getIDMerchant())) == null || var21_25.isEmpty()) continue;
                        for (Object var22_26 : var21_25) {
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "S");
                            var6_5.addFieldValue(var7_6, "2", String.valueOf(UtilsYP.cryptInfo(var19_19.getDataContainerBrand().getBrandName())) + '_' + UtilsYP.cryptInfo(var19_19.getMerchantName()) + '_' + var19_19.getDataContainerBrand().getStoreIdentifier((YP_Row)var22_26));
                            var6_5.addFieldValue(var7_6, "3", var19_19.getDataContainerBrand().getStoreLabel((YP_Row)var22_26));
                            ++var7_6;
                            var8_7 = true;
                        }
                    }
                }
                if (var12_11.isEmpty() && (var19_19 = var2_2.getDataContainerTransaction().userHandler.getUserUID()) != null && !var19_19.isEmpty() && (var20_21 = var2_2.getDataContainerTransaction().contextHandler.storeMap) != null && !var20_21.isEmpty()) {
                    for (List<Long> var21_25 : var20_21.keySet()) {
                        var23_33 = (List<YP_Row>)var20_21.get(var21_25);
                        if (var23_33 == null || var23_33.isEmpty()) continue;
                        var24_41 = new YP_ComplexGabarit(((YP_Row)var23_33.get(0)).getFather());
                        var24_41.set("storeLabel", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
                        var24_41.set("storeStatus", YP_ComplexGabarit.OPERATOR.DIFFERENT, StoreStatusEnumeration.DELETED);
                        var23_33 = YP_TCD_DesignAccesObject.getRowListSuchAs(var23_33, new YP_ComplexGabarit[]{var24_41});
                        for (Object var25_35 : var23_33) {
                            var6_5.setRowID(var7_6, Integer.toString(var7_6));
                            var6_5.addFieldValue(var7_6, "1", "S");
                            var6_5.addFieldValue(var7_6, "2", String.valueOf(UtilsYP.cryptInfo(var21_25.getDataContainerBrand().getBrandName())) + '_' + UtilsYP.cryptInfo(var21_25.getMerchantName()) + '_' + var21_25.getDataContainerBrand().getStoreIdentifier((YP_Row)var25_35));
                            var6_5.addFieldValue(var7_6, "3", var21_25.getDataContainerBrand().getStoreLabel((YP_Row)var25_35));
                            ++var7_6;
                            var8_7 = true;
                        }
                    }
                }
            }
            if (var13_12.size() > 40000) {
                this.logger(3, "getView() too many contracts : " + var13_12.size());
            } else {
                for (Object var18_18 : var13_12) {
                    if (var18_18 == null) continue;
                    var20_21 = var18_18.getContractRow().getFieldStringValueByName("applicationIndex");
                    var21_25 = var18_18.getApplicationPlugin().getApplicationRow().getFieldStringValueByName("applicationName");
                    var6_5.setRowID(var7_6, Integer.toString(var7_6));
                    var6_5.addFieldValue(var7_6, "1", "C");
                    var6_5.addFieldValue(var7_6, "2", UtilsYP.cryptInfo(String.valueOf(var18_18.getDataContainerMerchant().getDataContainerBrand().getBrandName()) + '_' + var18_18.getDataContainerMerchant().getMerchantName() + '_' + var21_25 + '_' + (String)var20_21));
                    var6_5.addFieldValue(var7_6, "3", var18_18.getContractRow().getFieldStringValueByName("contractLabel"));
                    ++var7_6;
                }
            }
            var18_18 = var2_2.getDataContainerTransaction().userHandler.getUserUID();
            if (var18_18 != null && !var18_18.isEmpty()) {
                var6_5.setRowID(var7_6, Integer.toString(var7_6));
                var6_5.addFieldValue(var7_6, "1", "U");
                var6_5.addFieldValue(var7_6, "2", "AccessLevel");
                var6_5.addFieldValue(var7_6, "3", Long.toString(var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel()));
                var6_5.setRowID(++var7_6, Integer.toString(var7_6));
                var6_5.addFieldValue(var7_6, "1", "U");
                var6_5.addFieldValue(var7_6, "2", "CashierCreationAllowed");
                var19_19 = var2_2.getDataContainerTransaction().userHandler.isCashierCreationAllowed();
                if (var19_19 != null) {
                    var6_5.addFieldValue(var7_6, "3", String.valueOf(var19_19));
                } else {
                    var6_5.addFieldValue(var7_6, "3", "false");
                }
                ++var7_6;
            }
            if (var18_18 == null || var18_18.isEmpty()) break block67;
            var19_19 = var1_1.getViewList(var16_15);
            var20_23 = false;
            if (var19_19 == null) break block67;
            if (var16_15 == 2 && (var21_25 = this.dataContainerTechnique.getUserParameters(var2_2.getDataContainerTransaction().userHandler.getUserIdentifier(), new Object[]{"restrictionForMaintenance"})).size() == 1) {
                var20_23 = true;
            }
            var22_26 = var19_19.iterator();
            block29: while (var22_26.hasNext()) {
                var21_25 = (String)var22_26.next();
                if (!var20_23) ** GOTO lbl-1000
                var23_34 = var21_25;
                tmp = -1;
                switch (var23_34.hashCode()) {
                    case 430038309: {
                        if (var23_34.equals("View_User")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 1516034812: {
                        if (var23_34.equals("View_Session")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 1532921924: {
                        if (var23_34.equals("View_Transaction")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 1968373772: {
                        if (var23_34.equals("View_Summary")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 2075379052: {
                        if (var23_34.equals("View_Contract")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 2137030178: {
                        if (var23_34.equals("View_Merchant")) {
                            tmp = 1;
                        }
                        break;
                    }
                }
                switch (tmp) {
                    case 1: {
                        if (UtilsYP.isSATIMServer()) continue block29;
                    }
                    default: lbl-1000:
                    // 2 sources

                    {
                        if (var21_25.contentEquals("View_Store") && !var8_7 && var16_15 != 1 && var16_15 != 2 || var21_25.contentEquals("View_ReservationDetails") && (var16_15 > 3 || !var9_8)) continue block29;
                        if (!var21_25.contentEquals("View_LinkPay")) ** GOTO lbl314
                        if (var16_15 != 1 && var16_15 != 2 && var16_15 != 3) continue block29;
                        var24_43 = false;
                        if (var16_15 != 1) ** GOTO lbl298
                        var24_43 = true;
                        ** GOTO lbl313
lbl298:
                        // 1 sources

                        if (var16_15 != 2) ** GOTO lbl307
                        var26_36 = var15_16.iterator();
                        while (var26_36.hasNext()) {
                            var25_35 = (YP_TCD_DCC_Brand)var26_36.next();
                            var27_39 = var25_35.getParameter("linkPayEnabled", true);
                            if (!UtilsYP.isTrue(var27_39)) continue;
                            var24_43 = true;
                            ** GOTO lbl313
                        }
                        ** GOTO lbl313
lbl307:
                        // 1 sources

                        if (var16_15 == 3) {
                            for (Object var25_35 : var14_13) {
                                var27_40 = var25_35.getParameter("linkPayEnabled", true);
                                if (!UtilsYP.isTrue(var27_40)) continue;
                                var24_43 = true;
                                break;
                            }
                        }
lbl313:
                        // 7 sources

                        if (!var24_43) continue block29;
lbl314:
                        // 2 sources

                        var6_5.setRowID(var7_6, Integer.toString(var7_6));
                        var6_5.addFieldValue(var7_6, "1", "V");
                        var6_5.addFieldValue(var7_6, "2", (String)var21_25);
                        var6_5.addFieldValue(var7_6, "3", "");
                        ++var7_6;
                    }
                    case 2: 
                }
            }
        }
        for (Object var19_19 : var10_9) {
            var21_25 = this.dataContainerTechnique.getIdBrandListByGroup(var19_19.getIDGroup());
            if (var21_25 == null) continue;
            for (long var22_28 : var21_25) {
                var25_35 = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", new Object[]{var22_28});
                if (var25_35 == null) continue;
                var6_5.setRowID(var7_6, Integer.toString(var7_6));
                var6_5.addFieldValue(var7_6, "1", "G_B");
                var6_5.addFieldValue(var7_6, "2", String.valueOf(UtilsYP.cryptInfo(var19_19.getGroupName())) + '_' + UtilsYP.cryptInfo(var25_35.getBrandName()));
                var6_5.addFieldValue(var7_6, "3", "");
                ++var7_6;
            }
        }
        return var6_5;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "createInView() Key must not be set !");
        }
        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
        return -1;
    }
}

