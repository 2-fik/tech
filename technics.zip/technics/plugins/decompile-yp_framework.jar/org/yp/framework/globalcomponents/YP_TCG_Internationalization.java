/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.YP_TCD_DCC_Interface_Internationalization;
import org.yp.framework.ondemandcomponents.datacontainers.extension.internationalization.YP_TCD_DCC_Internationalization;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_Internationalization
extends YP_GlobalComponent {
    YP_TCD_DCC_Interface_Internationalization interfaceInternationalization;
    YP_TCD_DCC_Internationalization extensionInternationalization;

    public YP_TCG_Internationalization(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "initialize() no DCC_Technique...");
            return -1;
        }
        this.extensionInternationalization = (YP_TCD_DCC_Internationalization)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtension_Internationalization", new Object[0]);
        this.extensionInternationalization.initialize();
        this.interfaceInternationalization = this.extensionInternationalization;
        return 1;
    }

    @Override
    public String toString() {
        return "Internationalization";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.50";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getTranslatedText")) {
                if (objectArray == null || objectArray.length != 2 || !(objectArray[1] instanceof String)) {
                    this.logger(2, "dealRequest() bad parameters for " + string);
                    return null;
                }
                String string2 = (String)objectArray[1];
                if (objectArray[0] instanceof Long) {
                    long l = (Long)objectArray[0];
                    return this.interfaceInternationalization.getTranslatedText(l, string2);
                }
                if (objectArray[0] instanceof String) {
                    String string3 = (String)objectArray[0];
                    return this.interfaceInternationalization.getTranslatedText(string3, string2);
                }
                if (objectArray[0] instanceof Enum) {
                    Enum enum_ = (Enum)objectArray[0];
                    return this.interfaceInternationalization.getTranslatedText(enum_, string2);
                }
                this.logger(2, "dealRequest() bad first parameters for " + string);
                return null;
            }
            if (string.contentEquals("createTranslatedText")) {
                if (objectArray != null && objectArray.length == 3 && objectArray[0] instanceof Long && objectArray[1] instanceof String && objectArray[2] instanceof String) {
                    long l = (Long)objectArray[0];
                    String string4 = (String)objectArray[1];
                    String string5 = (String)objectArray[2];
                    return this.interfaceInternationalization.createTranslatedText(l, string4, string5);
                }
                this.logger(2, "dealRequest() bad parameters for " + string);
                return null;
            }
            if (string.contentEquals("getIdLabel")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                    String string6 = (String)objectArray[0];
                    return this.interfaceInternationalization.getIdLabel(string6);
                }
                this.logger(2, "dealRequest() bad parameters for " + string);
                return null;
            }
            if (!string.contentEquals("createNewLabel")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                String string7 = (String)objectArray[0];
                return this.interfaceInternationalization.createNewLabel(string7);
            }
            this.logger(2, "dealRequest() bad parameters for " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : ", exception);
            return null;
        }
    }
}

