/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.designaccesobjects.eft.DAO_EFT_Reservation;
import org.yp.designaccesobjects.transaction.DAO_TRS_EXT_3DS;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_View_Transaction
extends YP_TCG_View {
    private static final int NB_MAX_CONTRACT_AT_ONE_TIME = 500;
    private YP_TS_DataContainerManager dataContainerManager;
    private YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Transaction(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Transaction";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.1";
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        var6_5 = new YP_View(this);
        var7_6 = var2_2.getDataContainerTransaction().userHandler.getUserIdentifier();
        var9_7 = var1_1.getColumnCustomization(var7_6, var5_4);
        if (var9_7 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        var10_8 = var2_2.getApplicationList();
        if (var10_8 == null) {
            this.logger(2, "createEmptyView() error while retrieving applicationList");
            return null;
        }
        if (var10_8.isEmpty()) {
            this.logger(3, "createEmptyView() no application List");
            return var6_5;
        }
        var11_9 = null;
        for (YP_OnDemandComponent var12_11 : var10_8) {
            if (var12_11.transaction == null || (var15_13 = (var14_12 = var12_11.transaction.getRowTemplate()).getExtensionList()) == null) continue;
            var17_15 = var15_13.iterator();
            while (var17_15.hasNext()) {
                var16_14 = var17_15.next();
                if (!(var16_14 instanceof DAO_TRS_EXT_3DS)) continue;
                var11_9 = var12_11.transaction;
                break;
            }
            if (var11_9 != null) break;
        }
        if (var11_9 == null) {
            for (YP_OnDemandComponent var12_11 : var10_8) {
                if (var12_11.transaction == null || (var15_13 = (var14_12 = var12_11.transaction.getRowTemplate()).getExtensionList()) == null) continue;
                var17_15 = var15_13.iterator();
                while (var17_15.hasNext()) {
                    var16_14 = var17_15.next();
                    if (!(var16_14 instanceof DAO_EFT_Reservation)) continue;
                    var11_9 = var12_11.transaction;
                    break;
                }
                if (var11_9 != null) break;
            }
        }
        if (var11_9 == null) {
            for (YP_OnDemandComponent var12_11 : var10_8) {
                if (var12_11.transaction == null) continue;
                var11_9 = var12_11.transaction;
                break;
            }
        }
        if (var11_9 == null) {
            this.logger(3, "createEmptyView() no DAO transaction found");
            return var6_5;
        }
        var12_11 = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        for (Object var13_10 : var5_4) {
            block45: {
                block49: {
                    block48: {
                        block47: {
                            block46: {
                                block44: {
                                    var16_14 = YP_Row.getStringValue(var13_10.columnName);
                                    var17_15 = this.getLabel(var13_10.idLabel, (String)var16_14);
                                    var18_16 = var11_9.getFieldByName((String)var16_14);
                                    if (var18_16 == null) break block44;
                                    var15_13 = var11_9;
                                    break block45;
                                }
                                var18_16 = this.dataContainerTechnique.contract.getFieldByName((String)var16_14);
                                if (var18_16 == null) break block46;
                                var15_13 = this.dataContainerTechnique.contract;
                                break block45;
                            }
                            var18_16 = this.dataContainerTechnique.merchant.getFieldByName((String)var16_14);
                            if (var18_16 == null) break block47;
                            var15_13 = this.dataContainerTechnique.merchant;
                            break block45;
                        }
                        var18_16 = this.dataContainerTechnique.brand.getFieldByName((String)var16_14);
                        if (var18_16 == null) break block48;
                        var15_13 = this.dataContainerTechnique.brand;
                        break block45;
                    }
                    var18_16 = var12_11.getFieldByName((String)var16_14);
                    if (var18_16 == null) break block49;
                    var15_13 = var12_11;
                    break block45;
                }
                var19_17 = var16_14;
                tmp = -1;
                switch (var19_17.hashCode()) {
                    case -1806879190: {
                        if (var19_17.equals("issuerCountryCode")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case -959346587: {
                        if (var19_17.equals("numDossier")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 3540558: {
                        if (var19_17.equals("stan")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 231837153: {
                        if (var19_17.equals("paresStatus")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 560136652: {
                        if (var19_17.equals("transactionAmountFormated")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 872673531: {
                        if (var19_17.equals("offlineTransaction")) {
                            tmp = 3;
                        }
                        break;
                    }
                    case 903805587: {
                        if (var19_17.equals("storeLabel")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 1138659485: {
                        if (var19_17.equals("stanReference")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 1481770732: {
                        if (var19_17.equals("testTransaction")) {
                            tmp = 3;
                        }
                        break;
                    }
                }
                switch (tmp) {
                    case 2: {
                        var6_5.addCustomColumn((String)var16_14, (String)var17_15, "string", var13_10.defaultRank);
                        var15_13 = null;
                        break;
                    }
                    case 3: {
                        var6_5.addCustomColumn((String)var16_14, (String)var17_15, "enum", var13_10.defaultRank);
                        var15_13 = null;
                        break;
                    }
                    default: {
                        if (this.getLogLevel() < 2) break;
                        this.logger(2, "createEmptyView() unknown column:" + (String)var16_14);
                        break;
                    }
                }
            }
            if (var15_13 != null && var6_5.addColumn((String)var16_14, (String)var17_15, (YP_TCD_DesignAccesObject)var15_13, var18_16, var13_10.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + (String)var16_14);
            }
            if (var6_5.getColumnFormat((String)var16_14).contentEquals("enum")) {
                this.dealEnumColumn(var1_1, var2_2, var6_5, var1_1.getIdEnum(var13_10.idViewColumn), (String)var16_14, var18_16);
            }
            if (var9_7 != null && !var9_7.isEmpty()) {
                for (DAO_ViewColumnCustomization var20_18 : var9_7) {
                    if (var20_18.idViewColumn != var13_10.idViewColumn) continue;
                    var6_5.setColumnRank((String)var16_14, var20_18.rank);
                    if (var20_18.width <= 0) break;
                    var6_5.getColumnProperties((String)var16_14).put("width", Integer.toString(var20_18.width));
                    break;
                }
            }
            if (var13_10.writeAccessList != null && var13_10.writeAccessList.isSet(var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                var6_5.getColumnProperties((String)var16_14).put("writeAllowed", "1");
            } else {
                var6_5.getColumnProperties((String)var16_14).put("writeAllowed", "0");
            }
            if (var13_10.searchAccessList != null && var13_10.searchAccessList.isSet(var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                var6_5.getColumnProperties((String)var16_14).put("searchAllowed", "1");
                ** break;
            }
            var6_5.getColumnProperties((String)var16_14).put("searchAllowed", "0");
            {
                ** case 1:
            }
lbl172:
            // 5 sources

        }
        return var6_5;
    }

    /*
     * Exception decompiling
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Can't sort instructions [@NONE, blocks:[35] lbl462 : CaseStatement: default:\u000a, @NONE, blocks:[35] lbl462 : CaseStatement: default:\u000a]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:8)
         *     at java.base/java.util.TimSort.countRunAndMakeAscending(TimSort.java:360)
         *     at java.base/java.util.TimSort.sort(TimSort.java:220)
         *     at java.base/java.util.Arrays.sort(Arrays.java:1307)
         *     at java.base/java.util.ArrayList.sort(ArrayList.java:1721)
         *     at java.base/java.util.Collections.sort(Collections.java:179)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.buildSwitchCases(SwitchReplacer.java:271)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitch(SwitchReplacer.java:258)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:66)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        List list = (List)this.dataContainerManager.dealRequest(this, "getDataContainerList", yP_Transaction, action.applicationIdentifier, "");
        if (list == null || list.isEmpty()) {
            return -1;
        }
        return ((YP_TCD_DCC_Business)list.get(0)).executeAction(yP_Transaction, this.toString(), yP_Row, action);
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        this.logger(2, "createInView() Not yet done");
        return 0;
    }
}

