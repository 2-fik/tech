/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.designaccesobjects.brand.DAO_ReservationDetails;
import org.yp.designaccesobjects.eft.DAO_EFT_Reservation;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.ReservationStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_ReservationDetails
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_ReservationDetails(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_ReservationDetails";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        List<YP_TCD_DCC_Business> list3 = yP_Transaction.getApplicationList();
        if (list3 == null) {
            this.logger(2, "createEmptyView() error while retrieving applicationList");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(3, "createEmptyView() no application List");
            return yP_View;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = list3.get((int)0).getDataContainerBrand().reservationDetails;
        YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction = null;
        for (YP_TCD_DCC_Business object : list3) {
            if (object.transaction == null) continue;
            yP_TCD_DAO_SQL_Transaction = object.transaction;
            break;
        }
        if (yP_TCD_DAO_SQL_Transaction == null) {
            this.logger(3, "createEmptyView() no DAO transaction");
            return yP_View;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
            Field field;
            String string;
            String string2;
            block21: {
                block25: {
                    block24: {
                        block23: {
                            block22: {
                                block20: {
                                    string2 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                                    string = this.getLabel(dAO_ViewColumn.idLabel, string2);
                                    field = yP_TCD_DesignAccesObject.getFieldByName(string2);
                                    if (field == null) break block20;
                                    yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
                                    break block21;
                                }
                                if (yP_TCD_DAO_SQL_Transaction != null) {
                                    field = yP_TCD_DAO_SQL_Transaction.getFieldByName(string2);
                                }
                                if (field == null) break block22;
                                yP_TCD_DesignAccesObject2 = yP_TCD_DAO_SQL_Transaction;
                                break block21;
                            }
                            field = this.dataContainerTechnique.contract.getFieldByName(string2);
                            if (field == null) break block23;
                            yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.contract;
                            break block21;
                        }
                        field = this.dataContainerTechnique.merchant.getFieldByName(string2);
                        if (field == null) break block24;
                        yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.merchant;
                        break block21;
                    }
                    field = this.dataContainerTechnique.brand.getFieldByName(string2);
                    if (field == null) break block25;
                    yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.brand;
                    break block21;
                }
                switch (string2) {
                    case "transactionAmountFormated": {
                        yP_View.addCustomColumn(string2, string, "string", dAO_ViewColumn.defaultRank);
                        yP_TCD_DesignAccesObject2 = null;
                        break;
                    }
                    default: {
                        this.logger(2, "createEmptyView() unknown column:" + string2);
                        break;
                    }
                }
                continue;
            }
            if (yP_View.addColumn(string2, string, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0) {
                this.logger(2, "createEmptyView() error while adding column:" + string2);
            }
            if (yP_View.getColumnFormat(string2).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string2, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string2, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string2).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string2).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string2).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        var6_5 = this.createEmptyView(var1_1, var2_2, var3_3, var5_4);
        if (var6_5 == null) {
            this.logger(2, "getView() ");
            return null;
        }
        var7_6 = var2_2.getDataContainerTransaction().getProtocolEFT();
        if (var7_6 == null) {
            this.logger(2, "getView() No protocol...");
            return null;
        }
        if (!(var7_6 instanceof YP_PROT_IHM)) {
            this.logger(2, "getView() bad interface");
            return null;
        }
        var8_7 = (YP_PROT_IHM)var7_6;
        var9_8 = var8_7.getMaxRecords();
        if (var9_8 == 0) {
            return var6_5;
        }
        if (var9_8 < 0) {
            var9_8 = 1000;
        }
        ++var9_8;
        var10_9 = var8_7.getStartIndex();
        if (var10_9 < 0) {
            var10_9 = 0;
        } else {
            var9_8 += var10_9;
        }
        var11_10 = var2_2.getApplicationList();
        if (var11_10 == null) {
            this.logger(2, "getView() error while retrieving applicationList");
            return null;
        }
        if (var11_10.isEmpty()) {
            this.logger(3, "getView() no application List");
            return var6_5;
        }
        var12_11 = var11_10.get((int)0).getDataContainerBrand().reservationDetails;
        var13_12 = null;
        for (Object var14_14 : var11_10) {
            if (var14_14.transaction == null) continue;
            var16_15 = var14_14.transaction.getRowTemplate();
            for (Object var17_16 : var16_15.getExtensionList()) {
                if (!(var17_16 instanceof DAO_EFT_Reservation)) continue;
                var13_12 = var14_14.transaction;
                break;
            }
            if (var13_12 != null) break;
        }
        if (var13_12 == null) {
            for (Object var14_14 : var11_10) {
                if (var14_14.transaction == null) continue;
                var13_12 = var14_14.transaction;
                break;
            }
        }
        if (var13_12 == null) {
            this.logger(3, "getView() no transaction");
            return var6_5;
        }
        var14_14 = var13_12.getRowTemplate();
        var15_13 = new HashSet<E>();
        for (Object var16_15 : var11_10) {
            var15_13.add(var16_15.getDataContainerBrand());
        }
        var16_15 = new HashMap<K, V>();
        for (Object var17_16 : var11_10) {
            var16_15.put(var17_16.getContractIdentifier(), var17_16);
        }
        var17_16 = new HashMap<K, V>();
        var18_17 = null;
        if (this.getContractIdentifier().indexOf(95) > 0) {
            var18_17 = var2_2.getBrandList(true);
        }
        var19_18 = new ArrayList<Object>();
        var20_19 = new boolean[1];
        var21_20 = null;
        var22_21 = var8_7.getSearchGabarit();
        if (var22_21 != null && !var22_21.isEmpty()) {
            for (ArrayList<Object> var23_23 : var22_21) {
                if (var23_23.fullTableName == null) continue;
                var21_20 = this.getDAO(var1_1, var2_2, var23_23.fullTableName);
                break;
            }
        }
        if (var21_20 != null && var21_20.getDataContainerContext() instanceof YP_TCD_DCC_Brand) {
            var15_13.clear();
            var15_13.add((YP_TCD_DCC_Brand)var21_20.getDataContainerContext());
        }
        var24_22 = var15_13.iterator();
        while (var24_22.hasNext()) {
            var23_23 = (YP_TCD_DCC_Brand)var24_22.next();
            var25_24 = null;
            var26_27 = this.getComplexGabarit(var8_7, var12_11, var6_5, var2_2, var11_10, var20_19, (List<YP_TCD_DCC_Brand>)var18_17, (YP_TCD_DCC_Brand)var23_23);
            var25_24 = var23_23.reservationDetails.getRowListSuchAs(0, var9_8, new YP_ComplexGabarit[]{var26_27});
            if (var25_24 == null) {
                this.logger(2, "getView() null list");
                return null;
            }
            for (Object var27_29 : var25_24) {
                var19_18.add(var27_29);
                var17_16.put(var27_29, var23_23);
            }
        }
        if (var19_18.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return var6_5;
        }
        var23_23 = var19_18;
        var24_22 = new HashMap<K, V>();
        var25_25 = 0;
        while (var25_25 < var23_23.size()) {
            var26_27 = (YP_Row)var23_23.get(var25_25);
            var27_29 = var26_27.getFieldStringValueByName("contractIdentifier");
            var28_31 = (Long)var26_27.getFieldValueByName("idTransaction");
            var30_32 = (ArrayList<Long>)var24_22.get(var27_29);
            if (var30_32 == null) {
                var30_32 = new ArrayList<Long>();
                var24_22.put(var27_29, var30_32);
            }
            var30_32.add(var28_31);
            ++var25_25;
        }
        var25_26 = new HashMap<Long, Object>();
        for (Object var26_27 : var24_22.entrySet()) {
            var28_30 = (String)var26_27.getKey();
            var29_33 = (List)var26_27.getValue();
            var30_32 = (YP_TCD_DCC_Business)var16_15.get(var28_30);
            if (var30_32 == null) continue;
            var31_34 = new YP_ComplexGabarit(var30_32.transaction);
            var31_34.set("idTransaction", YP_ComplexGabarit.OPERATOR.IN, var29_33);
            var32_35 = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(var30_32.transaction, var30_32.transactionArchive, new YP_ComplexGabarit[]{var31_34});
            if (var32_35 == null) {
                this.logger(2, "getView() unable to retrieve list !!!");
                continue;
            }
            var34_37 = var32_35.iterator();
            while (var34_37.hasNext()) {
                var33_36 = (YP_Row)var34_37.next();
                var25_26.put(var33_36.getPrimaryKey(), var33_36);
            }
        }
        var26_28 = -1;
        for (Object var27_29 : var23_23) {
            var29_33 = (YP_TCD_DCC_Business)var16_15.get(var27_29.getFieldStringValueByName("contractIdentifier"));
            if (var29_33 == null) continue;
            var30_32 = var29_33.getContractRow();
            var31_34 = var29_33.getDataContainerMerchant();
            var32_35 = var31_34.getMerchantRow();
            var33_36 = var31_34.getDataContainerBrand();
            var34_37 = var33_36.getBrandRow();
            var35_38 = (YP_Row)var25_26.get(var27_29.getFieldValueByName("idTransaction"));
            var6_5.setRowID(++var26_28, String.valueOf(var27_29.getFather().getFullTableName()) + "#" + var27_29.getPrimaryKeyName() + "#" + var27_29.getPrimaryKey());
            if (!var20_19[0]) {
                var6_5.setRowActionable(var26_28, true);
                if (var23_23.size() == 1 && var35_38 != null) {
                    var36_39 = this.getActionList((YP_Row)var27_29, var2_2, var35_38);
                    var6_5.setRowActionList(var26_28, (List<YP_TCD_DC_Context.Action>)var36_39);
                }
            }
            block20: for (Object var36_39 : var5_4) {
                block49: {
                    block48: {
                        block47: {
                            block46: {
                                block45: {
                                    var38_41 = YP_Row.getStringValue(var36_39.columnName);
                                    var39_42 = null;
                                    var40_43 = var12_11.getFieldByName(var38_41);
                                    var41_44 = false;
                                    if (var40_43 == null) break block45;
                                    var39_42 = var27_29;
                                    ** GOTO lbl-1000
                                }
                                var40_43 = var13_12.getFieldByName(var38_41);
                                if (var40_43 == null) break block46;
                                var39_42 = var35_38;
                                ** GOTO lbl-1000
                            }
                            var40_43 = this.dataContainerTechnique.contract.getFieldByName(var38_41);
                            if (var40_43 == null) break block47;
                            var39_42 = var30_32;
                            ** GOTO lbl-1000
                        }
                        var40_43 = this.dataContainerTechnique.merchant.getFieldByName(var38_41);
                        if (var40_43 == null) break block48;
                        var39_42 = var32_35;
                        ** GOTO lbl-1000
                    }
                    var40_43 = this.dataContainerTechnique.brand.getFieldByName(var38_41);
                    if (var40_43 == null) break block49;
                    var39_42 = var34_37;
                    ** GOTO lbl-1000
                }
                var42_45 = var38_41;
                tmp = -1;
                switch (var42_45.hashCode()) {
                    case 560136652: {
                        if (var42_45.equals("transactionAmountFormated")) {
                            tmp = 1;
                        }
                        break;
                    }
                }
                switch (tmp) {
                    case 1: {
                        try {
                            if (var35_38 == null) continue block20;
                            var43_46 = (Long)var35_38.getFieldValueByName("transactionAmount");
                            var45_48 = (Integer)var35_38.getFieldValueByName("transactionAmountFraction");
                            var46_49 = var35_38.getFieldStringValueByName("transactionCurrencyAlpha");
                            if (var43_46 == 0L && var45_48 == 0 && var46_49.isEmpty()) continue block20;
                            var47_50 = String.valueOf(UtilsYP.formatAmount(var43_46, var45_48, Locale.FRANCE)) + " " + var46_49;
                            var41_44 = true;
                            var6_5.addFieldValue(var26_28, var38_41, var47_50);
                        }
                        catch (Exception var43_47) {
                            this.logger(3, "getView() Exception while formating amount ", var43_47);
                        }
                        continue block20;
                    }
                    default: lbl-1000:
                    // 6 sources

                    {
                        if (var40_43 != null && var39_42 != null) {
                            this.addFieldValue(var6_5, var40_43, (YP_Row)var39_42, var38_41, var26_28);
                            break;
                        }
                        if (var40_43 == null && !var41_44) {
                            this.logger(2, "getView() unknown column:" + var38_41);
                            break;
                        }
                        if (var35_38 == null) {
                            this.addFieldValue(var6_5, var40_43, (YP_Row)var14_14, var38_41, var26_28);
                            break;
                        }
                        this.logger(2, "getView() ??? :" + var38_41);
                    }
                }
            }
        }
        return var6_5;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    private List<YP_TCD_DC_Context.Action> getActionList(YP_Row yP_Row, YP_Transaction yP_Transaction, YP_Row yP_Row2) {
        try {
            DAO_ReservationDetails dAO_ReservationDetails = (DAO_ReservationDetails)yP_Row;
            ArrayList<YP_TCD_DC_Context.Action> arrayList = new ArrayList<YP_TCD_DC_Context.Action>();
            int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
            if (n == 1 || n == 2 || n == 3) {
                this.addClosingAction(yP_Transaction, dAO_ReservationDetails, arrayList, yP_Row2);
                this.addComplementaryPaymentAction(yP_Transaction, dAO_ReservationDetails, arrayList, yP_Row2);
                YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                action.id = "RESERVATIONS_ARCHIVES";
                action.label = this.getLabel("RESERVATIONS_ARCHIVES");
                action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                action.formName = "RESERVATIONS_ARCHIVES";
                if (arrayList.isEmpty()) {
                    ArrayList<Property> arrayList2 = new ArrayList<Property>();
                    Property property = new Property();
                    property.setName("DefaultAction");
                    property.setValue("1");
                    arrayList2.add(property);
                    action.propertiesList = arrayList2;
                }
                arrayList.add(action);
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getActionList()", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        switch (action.id) {
            case "CLOSURE_RESERVATION": {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3) break;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            case "COMPLEMENTARY_PAYMENT": {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3) break;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            case "RESERVATIONS_ARCHIVES": {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3) break;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
        }
        switch (action.id) {
            case "CLOSURE_RESERVATION": {
                Object object;
                List<YP_TCD_DCC_Business> list = yP_Transaction.getApplicationList();
                if (list == null || list.isEmpty()) {
                    this.logger(2, "executeAction() application of reservation's row not found");
                    return -1;
                }
                if (list.size() > 1) {
                    this.logger(2, "executeAction() more than one application found for reservation row");
                    return -1;
                }
                YP_TCD_DCC_Business yP_TCD_DCC_Business = list.get(0);
                yP_Transaction.getDataContainerTransaction().setSubRequestType(null);
                yP_Transaction.getDataContainerTransaction().reservationHandler.setReservationReference(yP_Row.getFieldStringValueByName("reservationReference"));
                Long l = null;
                Iterator<Property> iterator = action.propertiesList.iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        if (l != null) break;
                        this.logger(2, "Unable to close reservation, closing amount is null");
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Unable to close reservation, closing amount is null");
                        return -1;
                    }
                    Property property = iterator.next();
                    if (!property.getName().contains("closingAmount")) continue;
                    object = new JSONObject(property.getValue());
                    l = Long.parseLong(object.get("text").toString().replaceAll("[^0-9]", ""));
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = yP_Transaction.getDataContainerTransaction().getDataContainerBrand();
                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionAmount(l);
                yP_Transaction.getDataContainerTransaction().setContractIdentifier(action.applicationIdentifier);
                try {
                    int n = yP_TCD_DCC_Brand.checkValidRequest(yP_Transaction);
                    if (n != 1) {
                        return -1;
                    }
                    object = yP_TCD_DCC_Business.newApplicationPlugin(yP_Transaction);
                    ((YP_Object)object).setContractIdentifier(action.applicationIdentifier);
                    ((YP_Object)object).initialize();
                    ((YP_OnDemandComponent)object).dealRequest(yP_Transaction, "dealTransaction", new Object[0]);
                    ((YP_Application)object).shutdown();
                    YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Business.getDataContainerBrand().reservationDetails;
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("reservationReference"));
                    yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.GROUP);
                    yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.MAX);
                    List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    ReservationStatusEnumeration reservationStatusEnumeration = (ReservationStatusEnumeration)((Object)list2.get(0).getFieldValueByName("status"));
                    if (list2.size() > 1) {
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Erreur interne : Le dossier n'a pas \u00e9t\u00e9 cl\u00f4tur\u00e9");
                        return -1;
                    }
                    if (reservationStatusEnumeration == ReservationStatusEnumeration.CLOSED || reservationStatusEnumeration == ReservationStatusEnumeration.CANCELED) return 0;
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Erreur interne : Le dossier n'a pas \u00e9t\u00e9 cl\u00f4tur\u00e9");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "executeAction() ", exception);
                    return -1;
                }
            }
            case "COMPLEMENTARY_PAYMENT": {
                Object object;
                List<YP_TCD_DCC_Business> list = yP_Transaction.getApplicationList();
                if (list == null || list.isEmpty()) {
                    this.logger(2, "executeAction() application of reservation's row not found");
                    return -1;
                }
                if (list.size() > 1) {
                    this.logger(2, "executeAction() more than one application found for reservation row");
                    return -1;
                }
                YP_TCD_DCC_Business yP_TCD_DCC_Business = list.get(0);
                yP_Transaction.getDataContainerTransaction().setSubRequestType(null);
                yP_Transaction.getDataContainerTransaction().reservationHandler.setReservationReference(yP_Row.getFieldStringValueByName("reservationReference"));
                Long l = null;
                Iterator<Property> iterator = action.propertiesList.iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        if (l != null) break;
                        this.logger(2, "Unable to perform complementary payment, amount is null");
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Unable to perform complementary payment, amount is nul");
                        return -1;
                    }
                    Property property = iterator.next();
                    if (!property.getName().contains("complementaryPaymentAmount")) continue;
                    object = new JSONObject(property.getValue());
                    l = Long.parseLong(object.get("text").toString().replaceAll("[^0-9]", ""));
                }
                if (l <= 0L) {
                    this.logger(2, "Unable to perform complementary payment, amount is invalid");
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Unable to perform complementary payment, amount is invalid");
                    return -1;
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = yP_Transaction.getDataContainerTransaction().getDataContainerBrand();
                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionAmount(l);
                yP_Transaction.getDataContainerTransaction().setContractIdentifier(action.applicationIdentifier);
                try {
                    int n = yP_TCD_DCC_Brand.checkValidRequest(yP_Transaction);
                    if (n != 1) {
                        return -1;
                    }
                    object = yP_TCD_DCC_Business.newApplicationPlugin(yP_Transaction);
                    ((YP_Object)object).setContractIdentifier(action.applicationIdentifier);
                    ((YP_Object)object).initialize();
                    ((YP_OnDemandComponent)object).dealRequest(yP_Transaction, "dealTransaction", new Object[0]);
                    ((YP_Application)object).shutdown();
                    YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Business.getDataContainerBrand().reservationDetails;
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                    yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("reservationReference"));
                    yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.GROUP);
                    yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.MAX);
                    List<YP_Row> list3 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                    ReservationStatusEnumeration reservationStatusEnumeration = (ReservationStatusEnumeration)((Object)list3.get(0).getFieldValueByName("status"));
                    if (list3.size() > 1) {
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Erreur interne : Le paiement n'a pas \u00e9t\u00e9 effectu\u00e9");
                        return -1;
                    }
                    if (reservationStatusEnumeration == ReservationStatusEnumeration.COMPLEMENTARY) return 0;
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Erreur interne : Le paiement n'a pas \u00e9t\u00e9 effectu\u00e9");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "executeAction() ", exception);
                    return -1;
                }
            }
            default: {
                yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Unknown action !");
                return -1;
            }
        }
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        this.logger(2, "createInView() Not yet done");
        return 0;
    }

    private int addClosingAction(YP_Transaction yP_Transaction, DAO_ReservationDetails dAO_ReservationDetails, List<YP_TCD_DC_Context.Action> list, YP_Row yP_Row) {
        if (dAO_ReservationDetails.status == ReservationStatusEnumeration.INITIAL) {
            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
            action.applicationIdentifier = new String(dAO_ReservationDetails.contractIdentifier);
            action.formName = "StandardGenericForm";
            action.id = "CLOSURE_RESERVATION";
            action.label = this.getLabel("CLOSURE_RESERVATION");
            action.propertiesList = new ArrayList<Property>();
            Property property = new Property();
            property.setName("USER_MESSAGE");
            property.setValue("CLOSURE_RESERVATION");
            action.propertiesList.add(property);
            property = new Property();
            property.setName("NUM_DOSSIER_TEXT_FIELD");
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("label", (Object)this.getLabel("numDossier"));
            jSONObject.put("text", (Object)dAO_ReservationDetails.getFieldStringValueByName("reservationReference"));
            jSONObject.put("enabled", false);
            String string = jSONObject.toString();
            property.setValue(string);
            action.propertiesList.add(property);
            property = new Property();
            property.setName("closingAmountTEXT_FIELD_AMOUNT");
            jSONObject = new JSONObject();
            jSONObject.put("label", (Object)"Montant");
            jSONObject.put("text", (Object)"");
            jSONObject.put("currencyFraction", (Object)yP_Row.getFieldStringValueByName("transactionAmountFraction"));
            jSONObject.put("currency", (Object)yP_Row.getFieldStringValueByName("transactionCurrencyAlpha"));
            jSONObject.put("enabled", true);
            string = jSONObject.toString();
            property.setValue(string);
            action.propertiesList.add(property);
            list.add(action);
        }
        return 1;
    }

    private int addComplementaryPaymentAction(YP_Transaction yP_Transaction, DAO_ReservationDetails dAO_ReservationDetails, List<YP_TCD_DC_Context.Action> list, YP_Row yP_Row) {
        if (dAO_ReservationDetails.status == ReservationStatusEnumeration.CLOSED) {
            Object object;
            Object object2;
            block11: {
                block10: {
                    block9: {
                        block8: {
                            try {
                                object2 = (YP_TCD_DataContainer)this.dataContainerManager.dealRequest(this, "getDataContainer", new String(dAO_ReservationDetails.contractIdentifier));
                                if (object2 != null) break block8;
                                this.logger(2, "addComplementaryPaymentAction() unable to find data container " + new String(dAO_ReservationDetails.contractIdentifier));
                                return -1;
                            }
                            catch (Exception exception) {
                                this.logger(2, "addComplementaryPaymentAction() ", exception);
                                return -1;
                            }
                        }
                        if (object2 instanceof YP_TCD_DCC_EFT_Business) break block9;
                        this.logger(2, "addComplementaryPaymentAction() bad type of data container");
                        return -1;
                    }
                    object = ((YP_TCD_DCC_EFT_Business)object2).getTransactionTypeAllowed(yP_Transaction.getDataContainerTransaction());
                    if (object != null) break block10;
                    this.logger(2, "addComplementaryPaymentAction() unable to retrieve transactionTypeAllowed");
                    return -1;
                }
                if (((Bitmap)object).isSet(TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT.getValue())) break block11;
                this.logger(3, "addComplementaryPaymentAction() COMPLEMENTARY_PAYMENT is not allowed");
                return 0;
            }
            Timestamp timestamp = (Timestamp)yP_Row.getFieldValueByName("referenceTransactionAppliLocalTime");
            Object object3 = new Timestamp(timestamp.getTime() + 5184000000L);
            if (((Date)object3).before(((YP_TCD_DCC_EFT_Business)object2).timeInterface.getAppliLocalTime().getTime())) {
                this.logger(3, "addComplementaryPaymentAction() pre auto has expired");
                return 0;
            }
            object2 = new YP_TCD_DC_Context.Action();
            ((YP_TCD_DC_Context.Action)object2).applicationIdentifier = new String(dAO_ReservationDetails.contractIdentifier);
            ((YP_TCD_DC_Context.Action)object2).formName = "StandardGenericForm";
            ((YP_TCD_DC_Context.Action)object2).id = "COMPLEMENTARY_PAYMENT";
            ((YP_TCD_DC_Context.Action)object2).label = this.getLabel("COMPLEMENTARY_PAYMENT");
            ((YP_TCD_DC_Context.Action)object2).propertiesList = new ArrayList<Property>();
            object = new Property();
            ((Property)object).setName("USER_MESSAGE");
            ((Property)object).setValue("COMPLEMENTARY_PAYMENT");
            ((YP_TCD_DC_Context.Action)object2).propertiesList.add((Property)object);
            object = new Property();
            ((Property)object).setName("NUM_DOSSIER_TEXT_FIELD");
            timestamp = new JSONObject();
            timestamp.put("label", this.getLabel("numDossier"));
            timestamp.put("text", dAO_ReservationDetails.getFieldStringValueByName("reservationReference"));
            timestamp.put("enabled", false);
            object3 = timestamp.toString();
            ((Property)object).setValue((String)object3);
            ((YP_TCD_DC_Context.Action)object2).propertiesList.add((Property)object);
            object = new Property();
            ((Property)object).setName("complementaryPaymentAmountTEXT_FIELD_AMOUNT");
            timestamp = new JSONObject();
            timestamp.put("label", "Montant");
            timestamp.put("text", "");
            timestamp.put("currencyFraction", yP_Row.getFieldStringValueByName("transactionAmountFraction"));
            timestamp.put("currency", yP_Row.getFieldStringValueByName("transactionCurrencyAlpha"));
            timestamp.put("enabled", true);
            object3 = timestamp.toString();
            ((Property)object).setValue((String)object3);
            ((YP_TCD_DC_Context.Action)object2).propertiesList.add((Property)object);
            list.add((YP_TCD_DC_Context.Action)object2);
        }
        return 1;
    }

    private YP_ComplexGabarit getComplexGabarit(YP_PROT_IHM yP_PROT_IHM, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_View yP_View, YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, boolean[] blArray, List<YP_TCD_DCC_Brand> list2, YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        List<YP_Gabarit> list3 = yP_PROT_IHM.getSearchGabarit();
        if (list3 != null && !list3.isEmpty()) {
            for (YP_Gabarit yP_Gabarit : list3) {
                try {
                    if (yP_Gabarit.objectTosearch == null) {
                        yP_ComplexGabarit.set(yP_Gabarit.fieldName, yP_Gabarit.operator);
                        continue;
                    }
                    if (yP_Gabarit.fieldName != null && yP_Gabarit.fieldName.contentEquals("status") && yP_Gabarit.operator == YP_ComplexGabarit.OPERATOR.IN) {
                        yP_Gabarit.operator = YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP;
                    }
                    if (yP_Gabarit.fieldName != null && yP_Gabarit.fieldName.contentEquals("reservationReference")) {
                        if (yP_Gabarit.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                            blArray[0] = true;
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                            yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Gabarit.objectTosearch.toString());
                            return yP_ComplexGabarit;
                        }
                        if (yP_Gabarit.operator == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                            blArray[0] = true;
                        }
                    }
                    yP_View.dealEnumColumn(yP_Gabarit);
                    if (yP_Gabarit.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(yP_Gabarit.fieldName, yP_Gabarit.operator, yP_Gabarit.objectTosearch);
                }
                catch (Exception exception) {
                    this.logger(2, "getView()  ", exception);
                }
            }
        }
        if (yP_ComplexGabarit.maxFieldName == null) {
            yP_ComplexGabarit.set("reservationReference", YP_ComplexGabarit.OPERATOR.GROUP);
            yP_ComplexGabarit.set("appliLocalTime", YP_ComplexGabarit.OPERATOR.MAX);
        }
        long l = yP_TCD_DCC_Brand.getIDBrand();
        if (list2 != null && !list2.isEmpty()) {
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand2 : list2) {
                if (l != yP_TCD_DCC_Brand2.getIDBrand()) continue;
                return yP_ComplexGabarit;
            }
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
            if (yP_TCD_DCC_Business.getDataContainerBrand().getIDBrand() != l) continue;
            arrayList.add(yP_TCD_DCC_Business.getContractIdentifier());
        }
        if (arrayList.isEmpty()) {
            arrayList.add("ImpossibleValue");
        } else if (arrayList.size() > 100) {
            yP_ComplexGabarit.set("contractIdentifier", YP_ComplexGabarit.OPERATOR.START_WITH, String.valueOf(yP_TCD_DCC_Brand.getBrandName()) + '_');
        } else {
            yP_ComplexGabarit.set("contractIdentifier", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        }
        return yP_ComplexGabarit;
    }
}

