/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

public class DTO_Ville {
    @SerializedName(value="code")
    private String code = null;
    @SerializedName(value="designation")
    private String designation = null;
    @SerializedName(value="id")
    private Integer id = null;

    public DTO_Ville code(String string) {
        this.code = string;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String string) {
        this.code = string;
    }

    public DTO_Ville designation(String string) {
        this.designation = string;
        return this;
    }

    public String getDesignation() {
        return this.designation;
    }

    public void setDesignation(String string) {
        this.designation = string;
    }

    public DTO_Ville id(Integer n) {
        this.id = n;
        return this;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer n) {
        this.id = n;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Ville dTO_Ville = (DTO_Ville)object;
        return Objects.equals(this.code, dTO_Ville.code) && Objects.equals(this.designation, dTO_Ville.designation) && Objects.equals(this.id, dTO_Ville.id);
    }

    public int hashCode() {
        return Objects.hash(this.code, this.designation, this.id);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class VilleDto {\n");
        stringBuilder.append("    code: ").append(this.toIndentedString(this.code)).append("\n");
        stringBuilder.append("    designation: ").append(this.toIndentedString(this.designation)).append("\n");
        stringBuilder.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

