/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.sqlformaters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.globalcomponents.sqlformaters.YP_TCG_SQL_Formater;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.UtilsYP;

public class YP_TCG_ORACLE_Formater
extends YP_GlobalComponent
implements YP_TCG_SQL_Formater {
    private static final String FIELD_START = "";
    private static final String FIELD_MID = ".";
    private static final String FIELD_END = "";

    public YP_TCG_ORACLE_Formater(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "ORACLE_Formater";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "dealRequest() unhnwown request: " + string);
        }
        return null;
    }

    private String getVarType(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, Field field) {
        block17: {
            block18: {
                Object object;
                block16: {
                    block15: {
                        block14: {
                            block13: {
                                block12: {
                                    block11: {
                                        try {
                                            object = yP_Row.getFieldValue(field);
                                            if (!(object instanceof Timestamp)) break block11;
                                            return "TIMESTAMP (6) DEFAULT TO_TIMESTAMP('01/01/1970', 'DD/MM/RR HH24:MI:SS,FF') NOT NULL ENABLE";
                                        }
                                        catch (Exception exception) {
                                            this.logger(2, "getVarType() : " + exception);
                                            return null;
                                        }
                                    }
                                    if (!(object instanceof Date)) break block12;
                                    return "DATE DEFAULT TO_DATE('01/01/1970', 'DD/MM/RR') NOT NULL ENABLE";
                                }
                                if (!(object instanceof Integer)) break block13;
                                return "NUMBER DEFAULT 0 NOT NULL";
                            }
                            if (!(object instanceof Long)) break block14;
                            return "NUMBER DEFAULT 0 NOT NULL";
                        }
                        if (object instanceof byte[]) {
                            int n = ((byte[])object).length;
                            return "VARCHAR2(" + String.valueOf(n) + ")";
                        }
                        if (!(object instanceof Float)) break block15;
                        return "FLOAT(126) DEFAULT 0 NOT NULL ENABLE";
                    }
                    if (!(object instanceof Enum)) break block16;
                    return "VARCHAR2(32)";
                }
                if (object != null) break block17;
                if (!field.getType().isEnum()) break block18;
                return "VARCHAR2(32)";
            }
            this.logger(2, "getVarType() : unknown type ");
            return null;
        }
        this.logger(2, "getVarType() : unknown type ");
        return null;
    }

    private String getVarTypeForPrimaryKey(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, Field field) {
        block12: {
            Object object;
            block11: {
                block10: {
                    block9: {
                        block8: {
                            try {
                                object = yP_Row.getFieldValue(field);
                                if (!(object instanceof Timestamp)) break block8;
                                return "TIMESTAMP (6) DEFAULT TO_TIMESTAMP('01/01/1970', 'DD/MM/RR HH24:MI:SS,FF') NOT NULL ENABLE";
                            }
                            catch (Exception exception) {
                                this.logger(2, "getVarTypeForPrimaryKey() : " + exception);
                                return null;
                            }
                        }
                        if (!(object instanceof Date)) break block9;
                        return "DATE DEFAULT TO_DATE('01/01/1970', 'DD/MM/RR') NOT NULL ENABLE";
                    }
                    if (!(object instanceof Integer)) break block10;
                    return "NUMBER NOT NULL";
                }
                if (!(object instanceof Long)) break block11;
                return "NUMBER NOT NULL";
            }
            if (object instanceof byte[]) {
                int n = ((byte[])object).length;
                return "VARCHAR2(" + String.valueOf(n) + ")";
            }
            if (!(object instanceof Float)) break block12;
            return "FLOAT(126) DEFAULT 0 NOT NULL ENABLE";
        }
        this.logger(2, "getVarTypeForPrimaryKey() : unknown type ");
        return null;
    }

    @Override
    public String sqlValue(Object object) {
        if (object instanceof Object[]) {
            StringBuilder stringBuilder = new StringBuilder();
            Object[] objectArray = (Object[])object;
            int n = 0;
            while (n < objectArray.length) {
                if (n != 0) {
                    stringBuilder.append(',');
                }
                stringBuilder.append(this.sqlValue(objectArray[n]));
                ++n;
            }
            return stringBuilder.toString();
        }
        String string = YP_Row.getStringValue(object);
        if (string == null) {
            return null;
        }
        string = string.trim();
        if (!(object instanceof Integer) && !(object instanceof Long)) {
            if (object instanceof byte[] || object instanceof String || object instanceof Enum) {
                if (string.indexOf("'") != -1) {
                    string = string.replace("'", "\\'");
                }
                string = String.valueOf('\'') + string + '\'';
            } else if (object instanceof Timestamp) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string.substring(8, 10));
                stringBuilder.append('/');
                stringBuilder.append(string.substring(5, 7));
                stringBuilder.append('/');
                stringBuilder.append(string.substring(0, 4));
                stringBuilder.append(string.substring(10, 19));
                stringBuilder.append(',');
                stringBuilder.append(string.substring(20));
                string = String.valueOf('\'') + stringBuilder.toString() + '\'';
            } else if (object instanceof Date) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string.substring(8, 10));
                stringBuilder.append('/');
                stringBuilder.append(string.substring(5, 7));
                stringBuilder.append('/');
                stringBuilder.append(string.substring(0, 4));
                string = String.valueOf('\'') + stringBuilder.toString() + '\'';
            } else if (!(object instanceof Float)) {
                this.logger(2, "sqlValue() : unknown type ");
                return null;
            }
        }
        return string;
    }

    @Override
    public String sqlIF() {
        return "IF";
    }

    @Override
    public String sqlUser() {
        return "user()";
    }

    @Override
    public String sqlColumnName(String string) {
        return string;
    }

    @Override
    public String sqlDate(String string) {
        return "DATE(" + string + ")";
    }

    private int appendSQLValue(StringBuilder stringBuilder, Object object) {
        String string = YP_Row.getStringValue(object);
        if (string == null) {
            stringBuilder.append("null");
            return 1;
        }
        string = string.trim();
        if (object instanceof Integer) {
            stringBuilder.append(string);
        } else if (object instanceof Long) {
            stringBuilder.append(string);
        } else if (object instanceof byte[] || object instanceof String || object instanceof Enum) {
            stringBuilder.append('\'');
            if (string.indexOf("'") != -1) {
                string = string.replace("'", "\\'");
            }
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Timestamp) {
            stringBuilder.append('\'');
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string.substring(8, 10));
            stringBuilder2.append('/');
            stringBuilder2.append(string.substring(5, 7));
            stringBuilder2.append('/');
            stringBuilder2.append(string.substring(0, 4));
            stringBuilder2.append(string.substring(10, 19));
            stringBuilder2.append(',');
            stringBuilder2.append(string.substring(20));
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append('\'');
        } else if (object instanceof Date) {
            stringBuilder.append('\'');
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(string.substring(8, 10));
            stringBuilder3.append('/');
            stringBuilder3.append(string.substring(5, 7));
            stringBuilder3.append('/');
            stringBuilder3.append(string.substring(0, 4));
            stringBuilder.append(stringBuilder3.toString());
            stringBuilder.append('\'');
        } else if (object instanceof Float) {
            stringBuilder.append(string);
        } else if (object == null) {
            stringBuilder.append("null");
        } else {
            this.logger(2, "appendSQLValue() : unknown type ");
            return -1;
        }
        return 1;
    }

    @Override
    public int updateRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UPDATE ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append(" SET ");
        String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        boolean bl = true;
        int n = 0;
        while (n < fieldArray.length) {
            try {
                String string2 = fieldArray[n].getName();
                if (string2.compareTo(string) != 0) {
                    if (!bl) {
                        stringBuilder.append(',');
                    } else {
                        bl = false;
                    }
                    stringBuilder.append(" ");
                    stringBuilder.append(string2);
                    stringBuilder.append('=');
                    this.appendSQLValue(stringBuilder, yP_Row.getFieldValue(fieldArray[n]));
                }
            }
            catch (Exception exception) {
                this.logger(2, "updateRow() : " + exception);
            }
            ++n;
        }
        stringBuilder.append(" WHERE ");
        stringBuilder.append(string);
        stringBuilder.append('=');
        stringBuilder.append(yP_Row.getPrimaryKey());
        if (this.getLogLevel() >= 5) {
            this.logger(5, "updateRow() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    @Override
    public int updateRowSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        String string;
        StringBuilder stringBuilder;
        block7: {
            String string2;
            block6: {
                try {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("UPDATE ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(" SET ");
                    string2 = this.sqlGetSet(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_Row);
                    if (string2 != null && string2.length() != 0) break block6;
                    this.logger(2, "updateRowSuchAs() modification empty: ");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "updateRowSuchAs() : " + exception);
                    return -1;
                }
            }
            stringBuilder.append(string2);
            string = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string != null && string.length() != 0) break block7;
            this.logger(2, "updateRowSuchAs() condition empty:  ");
            return -1;
        }
        stringBuilder.append(string);
        if (n > 0) {
            stringBuilder.append(" LIMIT ");
            stringBuilder.append(n);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "updateRowSuchAs()  : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public int deleteRow(YP_TCD_DesignAccesObject var1_1, YP_Row var2_2) {
        block23: {
            block16: {
                var3_3 = new StringBuilder();
                var3_3.append("DELETE FROM ");
                var3_3.append(var1_1.getFullTableName());
                var3_3.append(" WHERE ");
                var4_4 = var2_2.getPrimaryKey();
                if (var4_4 != -1L) break block16;
                var6_5 = var1_1.getFieldList();
                var7_6 = true;
                var8_7 = 0;
                while (var8_7 < var6_5.length) {
                    block15: {
                        try {
                            block22: {
                                block21: {
                                    block20: {
                                        block19: {
                                            block18: {
                                                block17: {
                                                    var9_8 = var2_2.getFieldValue(var6_5[var8_7]);
                                                    if (var9_8 == null) break block15;
                                                    if (!(var9_8 instanceof Integer)) break block17;
                                                    if ((Integer)var9_8 == 0) {
                                                        break block15;
                                                    }
                                                    ** GOTO lbl-1000
                                                }
                                                if (!(var9_8 instanceof Long)) break block18;
                                                if ((Long)var9_8 == 0L) {
                                                    break block15;
                                                }
                                                ** GOTO lbl-1000
                                            }
                                            if (!(var9_8 instanceof byte[])) break block19;
                                            if (((byte[])var9_8).length == 0 || ((byte[])var9_8)[0] == 0) {
                                                break block15;
                                            }
                                            ** GOTO lbl-1000
                                        }
                                        if (!(var9_8 instanceof Timestamp)) break block20;
                                        if (((Timestamp)var9_8).getTime() == 0L) {
                                            break block15;
                                        }
                                        ** GOTO lbl-1000
                                    }
                                    if (!(var9_8 instanceof Date)) break block21;
                                    if (((Date)var9_8).getTime() == 0L) {
                                        break block15;
                                    }
                                    ** GOTO lbl-1000
                                }
                                if (!(var9_8 instanceof Float)) break block22;
                                if (((Float)var9_8).floatValue() == 0.0f) {
                                    break block15;
                                }
                                ** GOTO lbl-1000
                            }
                            if (!(var9_8 instanceof Enum)) {
                                this.logger(2, "deleteRow() unknown type");
                            } else lbl-1000:
                            // 7 sources

                            {
                                if (!var7_6) {
                                    var3_3.append(" AND");
                                } else {
                                    var7_6 = false;
                                }
                                var3_3.append(" ");
                                var3_3.append(var6_5[var8_7].getName());
                                var3_3.append('=');
                                this.appendSQLValue(var3_3, var9_8);
                            }
                        }
                        catch (Exception v0) {}
                    }
                    ++var8_7;
                }
                if (var7_6) {
                    this.logger(2, "deleteRow() : row without key and without gabarit...");
                    return -1;
                }
                break block23;
            }
            var3_3.append(var1_1.getPrimaryKeyName());
            var3_3.append('=');
            var3_3.append(var2_2.getPrimaryKey());
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "deleteRow() : " + var3_3);
        }
        return var1_1.getDataBaseConnector().dealUpdate(var1_1, var3_3.toString());
    }

    @Override
    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        StringBuilder stringBuilder;
        block4: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("DELETE FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                if (string != null && string.length() != 0) break block4;
                this.logger(2, "deleteRowsSuchAs() condition empty: ");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "deleteRowSuchAs() : " + exception);
                return -1;
            }
        }
        stringBuilder.append(string);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "deleteRowSuchAs() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    @Override
    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            return this.deleteRowsSuchAs(yP_TCD_DesignAccesObject, this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray));
        }
        catch (Exception exception) {
            this.logger(2, "deleteRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int createRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row) {
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        if (fieldArray.length == 0) {
            return -1;
        }
        long l = yP_Row.getPrimaryKey();
        if (l == 0L) {
            yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
        }
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder.append("INSERT INTO ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append('(');
        stringBuilder2.append(" VALUES (");
        boolean bl = true;
        Field[] fieldArray2 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block8: {
                Field field = fieldArray2[n2];
                try {
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                        stringBuilder2.append(',');
                    }
                    stringBuilder.append(field.getName());
                    this.appendSQLValue(stringBuilder2, yP_Row.getFieldValue(field));
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 5) break block8;
                    this.logger(5, "createRow() : " + exception);
                }
            }
            ++n2;
        }
        stringBuilder.append(')');
        stringBuilder2.append(')');
        stringBuilder.append((CharSequence)stringBuilder2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "createRow() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealCreate(stringBuilder.toString(), yP_TCD_DesignAccesObject);
    }

    @Override
    public void resetCache(String string) {
        UtilsYP.deleteDirectory(new File(String.valueOf(UtilsYP.getCachePath()) + string + "/"));
    }

    @Override
    public int sqlCreateTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, boolean bl) {
        int n = yP_TCD_DesignAccesObject.getDataBaseConnector().getSiteIdentifier();
        if (n != UtilsYP.getInstanceNumber()) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlCreateTable() : don't create the table of foreign databases");
            }
            if (bl) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlCreateTable() : create table needed but forbidden!!!");
                }
                return -1;
            }
            return 0;
        }
        if (UtilsYP.getInstanceRole() == 1) {
            String string = yP_TCD_DesignAccesObject.getFullTableName();
            if (bl || this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) {
                this.sqlCreateTableWithName(yP_TCD_DesignAccesObject, string);
            }
        } else if (UtilsYP.getInstanceRole() == 2) {
            if ((yP_TCD_DesignAccesObject.getTableType() & 4) == 0 && (yP_TCD_DesignAccesObject.getTableType() & 2) == 0 && !(yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction)) {
                block36: {
                    StringBuilder stringBuilder;
                    String string;
                    block35: {
                        if (bl) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table asked but forbidden on slave !!!");
                            }
                            return -1;
                        }
                        string = yP_TCD_DesignAccesObject.getFullTableName();
                        if (!this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) {
                            return 0;
                        }
                        try {
                            stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0);
                            if (stringBuilder != null) break block35;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table needed but forbidden!!!");
                            }
                            return -1;
                        }
                        catch (SQLException sQLException) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : " + sQLException);
                            }
                            return -1;
                        }
                    }
                    this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, string, stringBuilder.toString());
                    if (this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) break block36;
                    return 0;
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlCreateTable() : change on table needed but forbidden!!!");
                }
                return -1;
            }
            if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
                String string = ((YP_TCD_DAO_SQL_Transaction)yP_TCD_DesignAccesObject).getFullSlaveTableName();
                if (bl || this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) {
                    this.sqlCreateTableWithName(yP_TCD_DesignAccesObject, string);
                }
            } else {
                String string = yP_TCD_DesignAccesObject.getFullTableName();
                if (bl || this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) {
                    this.sqlCreateTableWithName(yP_TCD_DesignAccesObject, string);
                }
            }
        } else {
            if (UtilsYP.getInstanceRole() == 3) {
                String string;
                block38: {
                    StringBuilder stringBuilder;
                    block37: {
                        if (bl) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table asked but forbidden on slave shared DB !!!");
                            }
                            return -1;
                        }
                        string = yP_TCD_DesignAccesObject.getFullTableName();
                        if (!this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) {
                            return 0;
                        }
                        try {
                            stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0);
                            if (stringBuilder != null) break block37;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table needed but should be forbidden!!!");
                            }
                            this.sqlCreateTableWithName(yP_TCD_DesignAccesObject, string);
                            return 1;
                        }
                        catch (SQLException sQLException) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : " + sQLException);
                            }
                            return -1;
                        }
                    }
                    this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, string, stringBuilder.toString());
                    if (this.isCreateTableNeeded(yP_TCD_DesignAccesObject, string)) break block38;
                    return 0;
                }
                this.logger(2, "sqlCreateTable() : change on " + yP_TCD_DesignAccesObject.getFullTableName() + " needed but should beforbidden!!!");
                this.sqlCreateTableWithName(yP_TCD_DesignAccesObject, string);
                return 1;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "sqlCreateTable() : Unknown role:" + UtilsYP.getInstanceRole());
            }
        }
        return 1;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private boolean isCreateTableNeeded(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        try {
            byte[] byArray;
            Object object;
            String string2 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/" + string.replace("`", "").replace(" ", "") + ".sql";
            Object object2 = null;
            String string3 = null;
            try {
                object = new FileInputStream(string2);
                try {
                    byArray = new byte[((FileInputStream)object).available()];
                    ((FileInputStream)object).read(byArray);
                }
                finally {
                    if (object != null) {
                        ((FileInputStream)object).close();
                    }
                }
            }
            catch (Throwable throwable) {
                if (object2 == null) {
                    object2 = throwable;
                } else if (object2 != throwable) {
                    ((Throwable)object2).addSuppressed(throwable);
                }
                throw object2;
            }
            object2 = new String(byArray);
            object = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string4 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            if (string4 != null) {
                if (((String)object2).indexOf("PRIMARY KEY (\"" + string4.toUpperCase() + "\")") == -1) {
                    return true;
                }
                if (object != null && !object.isEmpty()) {
                    int n = 0;
                    while (n < object.size()) {
                        String string5 = "INDEX_NAME=\"" + yP_TCD_DesignAccesObject.getTableName().toUpperCase() + "_IDX" + n + "\" COLUMN_NAME=\"" + ((String)object.get(n)).toUpperCase() + "\"";
                        if (((String)object2).indexOf(string5) == -1) {
                            return true;
                        }
                        ++n;
                    }
                }
            } else {
                if (object == null || object.isEmpty() || object.size() < 2) {
                    this.logger(2, "sqlCreateTableWithName() : no primary key and less than two indexes is not possible for " + string);
                    return true;
                }
                if (((String)object2).indexOf("PRIMARY KEY (" + (String)object.get(0) + "," + (String)object.get(1) + ")") == -1) {
                    return true;
                }
            }
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            int n = 0;
            while (n < fieldArray.length) {
                if (string4 == null || fieldArray[n].getName().compareTo(string4) != 0) {
                    if (Modifier.isPublic(fieldArray[n].getModifiers())) {
                        string3 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                        if (((String)object2).indexOf("\"" + fieldArray[n].getName().toUpperCase() + "\" " + string3) == -1) {
                            return true;
                        }
                    }
                } else if (Modifier.isPublic(fieldArray[n].getModifiers())) {
                    string3 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                    if (((String)object2).indexOf("\"" + fieldArray[n].getName().toUpperCase() + "\" " + string3) == -1) {
                        return true;
                    }
                }
                ++n;
            }
        }
        catch (Exception exception) {
            this.logger(3, "isCreateTableNeeded() : " + exception);
            return true;
        }
        return false;
    }

    private void sqlCreateTableWithName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        try {
            CharSequence charSequence;
            String string2;
            List<String> list = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string3 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            StringBuilder stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0);
            if (stringBuilder == null) {
                if (this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, true) < 0) {
                    StringBuilder stringBuilder2;
                    String string4 = "SHOW DATABASES like '" + yP_TCD_DesignAccesObject.getSchemaName() + "'";
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTableWithName() : " + string4);
                    }
                    if ((stringBuilder2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, string4, 0)) == null) {
                        this.sqlCreateDatabase(yP_TCD_DesignAccesObject);
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, true);
                    }
                }
                return;
            }
            if (string3 != null) {
                string2 = "PRIMARY KEY (\"" + string3.toUpperCase() + "\")";
                if (stringBuilder.indexOf(string2) == -1) {
                    this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
                    return;
                }
                if (list != null && !list.isEmpty()) {
                    string2 = "SELECT table_name, index_name, column_name FROM dba_ind_columns WHERE table_name='" + yP_TCD_DesignAccesObject.getTableName().toUpperCase() + "'";
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTableWithName() : " + string2);
                    }
                    charSequence = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, string2, 0);
                    int n = 0;
                    while (n < list.size()) {
                        string2 = "INDEX_NAME=\"" + yP_TCD_DesignAccesObject.getTableName().toUpperCase() + "_IDX" + n + "\" COLUMN_NAME=\"" + list.get(n).toUpperCase() + "\"";
                        if (((StringBuilder)charSequence).indexOf(string2) == -1) {
                            this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
                            return;
                        }
                        ++n;
                    }
                    stringBuilder.append(charSequence);
                }
            } else {
                if (list == null || list.isEmpty() || list.size() < 2) {
                    this.logger(2, "sqlCreateTableWithName() : no primary key and less than two indexes is not possible for " + string);
                    return;
                }
                string2 = "PRIMARY KEY (" + list.get(0) + "," + list.get(1) + ")";
                if (stringBuilder.indexOf(string2) == -1) {
                    this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
                    return;
                }
            }
            int n = 0;
            while (n < fieldArray.length) {
                String string5;
                if (string3 == null || fieldArray[n].getName().compareTo(string3) != 0) {
                    if (Modifier.isPublic(fieldArray[n].getModifiers())) {
                        string5 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                        charSequence = "\"" + fieldArray[n].getName().toUpperCase() + "\" " + string5;
                        if (stringBuilder.indexOf((String)charSequence) == -1) {
                            this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
                            return;
                        }
                    }
                } else if (Modifier.isPublic(fieldArray[n].getModifiers())) {
                    string5 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                    charSequence = "\"" + fieldArray[n].getName().toUpperCase() + "\" " + string5;
                    if (stringBuilder.indexOf((String)charSequence) == -1) {
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
                        return;
                    }
                }
                ++n;
            }
            if (UtilsYP.getTableCreationMode() == 3 || UtilsYP.getTableCreationMode() == 4 && string.contains("management")) {
                this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, string, false);
            }
            this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, string, stringBuilder.toString());
        }
        catch (SQLException sQLException) {
            this.logger(2, "sqlCreateTableWithName() : " + sQLException);
        }
    }

    private int putCreateTableResponseInCache(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, String string2) {
        String string3 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/";
        String string4 = String.valueOf(string3) + string.replace("`", "") + ".sql";
        new File(string3).mkdirs();
        new File(string4).delete();
        Throwable throwable = null;
        Object var7_9 = null;
        PrintWriter printWriter = new PrintWriter(new FileWriter(string4, true));
        try {
            printWriter.print(string2);
            if (printWriter != null) {
                printWriter.close();
            }
            return 1;
        }
        catch (Throwable throwable2) {
            try {
                try {
                    if (printWriter != null) {
                        printWriter.close();
                    }
                    throw throwable2;
                }
                catch (Throwable throwable3) {
                    if (throwable == null) {
                        throwable = throwable3;
                    } else if (throwable != throwable3) {
                        throwable.addSuppressed(throwable3);
                    }
                    throw throwable;
                }
            }
            catch (IOException iOException) {
                this.logger(2, "putCreateTableResponseInCache() : " + iOException);
                return -1;
            }
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private int sqlCreateTableWithName2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, String string, boolean bl) {
        try {
            String string2;
            int n;
            int n2;
            String string3 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/";
            String string4 = String.valueOf(string3) + string.replace("`", "") + ".sql";
            new File(string3).mkdirs();
            new File(string4).delete();
            String string5 = null;
            List<String> list = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string6 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            if (string6 == null) {
                if (list != null && !list.isEmpty()) {
                    string6 = list.get(0);
                    n2 = 0;
                    while (n2 < fieldArray.length) {
                        if (fieldArray[n2].getName().compareTo(string6) == 0) {
                            string5 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n2]);
                            break;
                        }
                        ++n2;
                    }
                    if (string5 == null) {
                        this.logger(2, "sqlCreateTableWithName2() : " + string);
                        return -1;
                    }
                } else {
                    string6 = fieldArray[0].getName();
                    string5 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[0]);
                }
            } else {
                n2 = 0;
                while (n2 < fieldArray.length) {
                    if (fieldArray[n2].getName().compareTo(string6) == 0) {
                        string5 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n2]);
                        break;
                    }
                    ++n2;
                }
                if (string5 == null) {
                    this.logger(2, "sqlCreateTableWithName2() : " + string);
                    return -1;
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0);
            if (stringBuilder2 == null) {
                stringBuilder.append("CREATE TABLE ");
                stringBuilder.append(string);
                stringBuilder.append("\n(\n  ");
                stringBuilder.append(string6);
                stringBuilder.append(" ");
                stringBuilder.append(string5);
                stringBuilder.append("\n, CONSTRAINT ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                stringBuilder.append("_PK PRIMARY KEY\n  (\n    ");
                stringBuilder.append(string6);
                stringBuilder.append("\n  )\n)");
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                }
                if ((n = yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString())) < 0) {
                    this.sqlCreateDatabase(yP_TCD_DesignAccesObject);
                    n = yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                }
                if ((stringBuilder2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0)) == null) {
                    return -1;
                }
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append("ALTER TABLE ");
            stringBuilder.append(string);
            n = 1;
            int n3 = 0;
            while (n3 < fieldArray.length) {
                if (fieldArray[n3].getName().compareTo(string6) != 0 && Modifier.isPublic(fieldArray[n3].getModifiers())) {
                    string2 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n3]);
                    if (stringBuilder2.indexOf(fieldArray[n3].getName().toUpperCase()) == -1) {
                        if (n != 0) {
                            n = 0;
                            stringBuilder.append(" ADD (");
                        } else {
                            stringBuilder.append(',');
                        }
                        stringBuilder.append(fieldArray[n3].getName());
                        stringBuilder.append(" ");
                        stringBuilder.append(string2);
                    }
                }
                ++n3;
            }
            if (n == 0) {
                stringBuilder.append(")");
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                }
                yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                stringBuilder2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject, string), 0);
                if (stringBuilder2 == null) {
                    return -1;
                }
            }
            n3 = 0;
            while (n3 < fieldArray.length) {
                if (fieldArray[n3].getName().compareTo(string6) != 0 && Modifier.isPublic(fieldArray[n3].getModifiers())) {
                    string2 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n3]);
                    if (stringBuilder2.indexOf(fieldArray[n3].getName().toUpperCase()) == -1) {
                        this.logger(2, "sqlCreateTableWithName2() : ");
                        return -1;
                    }
                    String string7 = "\"" + fieldArray[n3].getName().toUpperCase() + "\" " + string2;
                    if (stringBuilder2.indexOf(string7) == -1) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("ALTER TABLE ");
                        stringBuilder.append(string);
                        stringBuilder.append(" MODIFY ");
                        stringBuilder.append(fieldArray[n3].getName());
                        stringBuilder.append(" ");
                        stringBuilder.append(string2.replace("NOT NULL", "").replace("ENABLE", ""));
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                        }
                        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    }
                }
                ++n3;
            }
            if (yP_TCD_DesignAccesObject.getPrimaryKeyName() != null) {
                if (list != null && !list.isEmpty()) {
                    n3 = 0;
                    while (n3 < list.size()) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("CREATE INDEX ");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                        stringBuilder.append("_IDX");
                        stringBuilder.append(n3);
                        stringBuilder.append(" ON ");
                        stringBuilder.append(string);
                        stringBuilder.append(" (");
                        stringBuilder.append(list.get(n3));
                        stringBuilder.append(")");
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                        }
                        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                        ++n3;
                    }
                }
            } else if (list != null && !list.isEmpty()) {
                if (list.size() == 2) {
                    if (list.get(0).compareTo(string6) == 0) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("ALTER TABLE ");
                        stringBuilder.append(string);
                        stringBuilder.append(" DROP PRIMARY KEY\n, ADD PRIMARY KEY (");
                        stringBuilder.append(list.get(0));
                        stringBuilder.append(",  ");
                        stringBuilder.append(list.get(1));
                        stringBuilder.append(")");
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                        }
                        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    } else {
                        this.logger(2, "sqlCreateTableWithName2() : ");
                    }
                } else {
                    this.logger(2, "sqlCreateTableWithName2() : ");
                }
            } else {
                this.logger(2, "sqlCreateTableWithName2() : ");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "sqlCreateTableWithName2() : " + exception);
            return -1;
        }
    }

    @Override
    public int sqlEmptyTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        String string = "TRUNCATE TABLE " + yP_TCD_DesignAccesObject.getFullTableName();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlEmptyTable () : " + string);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, string);
    }

    @Override
    public int sqlFillTable(YP_TCD_DAO_LOC yP_TCD_DAO_LOC) {
        Object object;
        if (yP_TCD_DAO_LOC.isEmpty()) {
            return 0;
        }
        Field[] fieldArray = yP_TCD_DAO_LOC.getFieldList();
        if (fieldArray.length == 0) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("INSERT ALL");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("\nINTO ");
        stringBuilder2.append(yP_TCD_DAO_LOC.getFullTableName());
        stringBuilder2.append(" (");
        boolean bl = true;
        Object object2 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block19: {
                object = object2[n2];
                try {
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder2.append(',');
                    }
                    stringBuilder2.append(((Field)object).getName());
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 5) break block19;
                    this.logger(5, "sqlFillTable() : " + exception);
                }
            }
            ++n2;
        }
        stringBuilder2.append(") VALUES ");
        object = stringBuilder2.toString();
        n2 = yP_TCD_DAO_LOC.size();
        n = 0;
        while (n < n2) {
            object2 = yP_TCD_DAO_LOC.getRowAt(n);
            long l = ((YP_Row)object2).getPrimaryKey();
            if (l == 0L) {
                ((YP_Row)object2).setPrimaryKey(yP_TCD_DAO_LOC.getNextPrimaryKey());
            }
            stringBuilder.append((String)object);
            stringBuilder.append('(');
            bl = true;
            Field[] fieldArray2 = fieldArray;
            int n3 = fieldArray.length;
            int n4 = 0;
            while (n4 < n3) {
                block20: {
                    Field field = fieldArray2[n4];
                    try {
                        if (bl) {
                            bl = false;
                        } else {
                            stringBuilder.append(',');
                        }
                        this.appendSQLValue(stringBuilder, ((YP_Row)object2).getFieldValue(field));
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 5) break block20;
                        this.logger(5, "sqlFillTable() : " + exception);
                    }
                }
                ++n4;
            }
            stringBuilder.append(')');
            ++n;
        }
        stringBuilder.append("\nSELECT * FROM dual");
        String string = stringBuilder.toString();
        if (this.getLogLevel() >= 5) {
            if (string.contains("BlackList")) {
                this.logger(3, "sqlFillTable() BlackList not logged even on debug mode");
            } else if (string.length() > 2048) {
                this.logger(5, "sqlFillTable() : " + string.substring(0, 2048));
            } else {
                this.logger(5, "sqlFillTable() : " + string);
            }
        }
        return yP_TCD_DAO_LOC.getDataBaseConnector().dealCreate(string, yP_TCD_DAO_LOC);
    }

    @Override
    public int sqlUpdateRowList(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list) {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "sqlUpdateRowList() : TODO");
        }
        return -1;
    }

    private void sqlCreateDatabase(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        String string = "CREATE USER " + yP_TCD_DesignAccesObject.getSchemaName() + " identified by " + yP_TCD_DesignAccesObject.getSchemaName();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlCreateDatabase() : " + string);
        }
        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, string);
        string = "ALTER USER " + yP_TCD_DesignAccesObject.getSchemaName() + " QUOTA UNLIMITED ON " + yP_TCD_DesignAccesObject.getSchemaName();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlCreateDatabase() : " + string);
        }
        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, string);
    }

    @Override
    public YP_Row selectFromWhere(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, String string2, long l) {
        List<YP_Row> list;
        block8: {
            block7: {
                block6: {
                    try {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT * FROM ");
                        stringBuilder.append(string);
                        stringBuilder.append(" WHERE ");
                        stringBuilder.append(string2);
                        stringBuilder.append('=');
                        stringBuilder.append(l);
                        if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                            this.logger(5, "selectFromWhere() : " + stringBuilder.toString());
                        }
                        if ((list = yP_TCD_DataBaseConnector.dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block6;
                        this.logger(2, "selectFromWhere() empty response");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(3, "selectFromWhere() No result from database" + exception);
                        return null;
                    }
                }
                if (!list.isEmpty()) break block7;
                this.logger(3, "selectFromWhere() empty response");
                return null;
            }
            if (list.size() <= 1) break block8;
            this.logger(2, "selectFromWhere() too many responses...");
            return null;
        }
        return list.get(0);
    }

    @Override
    public int sqlReloadMemory(YP_TCD_DAO_LOC_Memory yP_TCD_DAO_LOC_Memory) {
        try {
            return yP_TCD_DAO_LOC_Memory.getDataBaseConnector().dealReloadForMemory(yP_TCD_DAO_LOC_Memory, "select * from " + yP_TCD_DAO_LOC_Memory.getFullTableName());
        }
        catch (Exception exception) {
            this.logger(3, "sqlReloadMemory() No result from database" + exception);
            return -1;
        }
    }

    @Override
    public int sqlReloadTable(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        try {
            return yP_TCD_DAO_LOC_Table.getDataBaseConnector().dealReloadForTable(yP_TCD_DAO_LOC_Table, "select * from " + yP_TCD_DAO_LOC_Table.getFullTableName());
        }
        catch (Exception exception) {
            this.logger(3, "sqlReloadTable() No result from database" + exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private String sqlGetWhere(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            int n2;
            int n3;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
                return "";
            }
            boolean bl = false;
            String string2 = null;
            StringBuilder stringBuilder = new StringBuilder();
            boolean bl2 = false;
            ArrayList<String> arrayList = null;
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                n3 = 0;
                n2 = 0;
                boolean bl3 = false;
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n4];
                n = 1;
                object = new StringBuilder();
                int n5 = 0;
                while (n5 < yP_ComplexGabarit.size()) {
                    String string3 = yP_ComplexGabarit.getFieldNameAt(n5);
                    Object object2 = yP_ComplexGabarit.getOperatorAt(n5);
                    if (object2 == YP_ComplexGabarit.OPERATOR.MIN) {
                        string2 = string3;
                        n3 = 1;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.MAX) {
                        string2 = string3;
                        n2 = 1;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.GROUP) {
                        if (yP_ComplexGabaritArray.length > 1) {
                            this.logger(2, "sqlGetWhere() group operator is not yet possible with more than one gabarit");
                            return null;
                        }
                        bl3 = true;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                        bl = true;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                        bl = true;
                    } else {
                        if (!bl2) {
                            bl2 = true;
                            n = 0;
                            stringBuilder.append(" WHERE (");
                        } else if (n == 1) {
                            stringBuilder.append(" OR (");
                            n = 0;
                        } else {
                            object.append(" AND ");
                        }
                        Object object3 = yP_ComplexGabarit.getObjectAt(n5);
                        if (object3 == null) {
                            object.append("( 1 = 0)");
                        } else {
                            String string4 = this.sqlValue(object3);
                            object.append('(');
                            if (object2 == YP_ComplexGabarit.OPERATOR.CONTAIN) {
                                object.append(string);
                                object.append('.');
                                object.append(string3);
                                object.append(" like '%");
                                object.append(string4.substring(1, string4.length() - 1));
                                object.append("%' ");
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING) {
                                int n6;
                                if (string4.startsWith("'")) {
                                    boolean bl4 = true;
                                    n6 = string4.length() - 1;
                                    while (n6 > 0) {
                                        if (bl4) {
                                            bl4 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append(string);
                                        object.append('.');
                                        object.append(string3);
                                        object.append(" = '");
                                        object.append(string4.substring(1, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                } else {
                                    boolean bl5 = true;
                                    n6 = string4.length();
                                    while (n6 >= 0) {
                                        if (bl5) {
                                            bl5 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append(string);
                                        object.append('.');
                                        object.append(string3);
                                        object.append(" = '");
                                        object.append(string4.substring(0, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                }
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.START_WITH) {
                                object.append(string);
                                object.append('.');
                                object.append(string3);
                                object.append(" like ");
                                object.append(string4.substring(0, string4.length() - 1));
                                object.append("%' ");
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.GREATER) {
                                object.append(string);
                                object.append('.');
                                object.append(string3);
                                object.append(" > ");
                                object.append(string4);
                                object.append(' ');
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS) {
                                object.append(string);
                                object.append('.');
                                object.append(string3);
                                object.append(" < ");
                                object.append(string4);
                                object.append(' ');
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.EQUAL) {
                                boolean bl6 = false;
                                if (string4.length() == 2 && string4.contentEquals("''")) {
                                    bl6 = true;
                                    object.append('(');
                                }
                                object.append(string);
                                object.append('.');
                                object.append(string3);
                                object.append(" = ");
                                object.append(string4);
                                if (bl6) {
                                    object.append(" OR ");
                                    object.append(string);
                                    object.append('.');
                                    object.append(string3);
                                    object.append(" IS NULL)");
                                }
                                object.append(' ');
                            } else if (object2 != YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE) {
                                if (object2 == YP_ComplexGabarit.OPERATOR.LIKE) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string3);
                                    object.append(" LIKE ");
                                    object.append(string4);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.IN) {
                                    object.append(string);
                                    object.append('.');
                                    object.append(string3);
                                    object.append(" IN (");
                                    object.append(string4);
                                    object.append(") ");
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                                    object.append(string);
                                    object.append('.');
                                    object.append(string3);
                                    if (string4.length() == 2 && string4.contentEquals("''")) {
                                        object.append(" IS NOT NULL");
                                    } else {
                                        object.append(" != ");
                                        object.append(string4);
                                    }
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                                    object.append(string);
                                    object.append('.');
                                    object.append(string3);
                                    object.append(" >= ");
                                    object.append(string4);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                                    object.append(string);
                                    object.append('.');
                                    object.append(string3);
                                    object.append(" <= ");
                                    object.append(string4);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP) {
                                    String string5 = String.valueOf(string) + FIELD_MID + string3 + " = " + string4 + ' ';
                                    object.append(string5);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList<String>();
                                    }
                                    arrayList.add(string5);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP) {
                                    String string6 = String.valueOf(string) + FIELD_MID + string3 + " <> " + string4 + ' ';
                                    object.append(string6);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string6);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                                    String string7 = String.valueOf(string) + FIELD_MID + string3 + " < " + string4 + ' ';
                                    object.append(string7);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string7);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP) {
                                    String string8 = String.valueOf(string) + FIELD_MID + string3 + " IN( " + string4 + ")";
                                    object.append(string8);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string8);
                                } else {
                                    this.logger(2, "sqlGetWhere() unknown operator");
                                }
                            }
                            object.append(')');
                        }
                    }
                    ++n5;
                }
                if (n2 == 0 && n3 == 0) {
                    if (bl3) {
                        this.logger(2, "sqlGetWhere() group operator is for aggregated columns (MIN, MAX)");
                        return null;
                    }
                    if (object.length() > 0) {
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else if (bl3) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                    stringBuilder.append('.');
                    stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" IN (SELECT * FROM (SELECT ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                    stringBuilder.append('.');
                    stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(" INNER JOIN (SELECT ");
                    for (String string9 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string);
                        stringBuilder.append('.');
                        stringBuilder.append(string9);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append('.');
                    stringBuilder.append(string2);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string10 = object.toString();
                            for (String string11 : arrayList) {
                                string10 = string10.replace(string11, " 1=1 ");
                            }
                            stringBuilder.append(string10);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    for (String string12 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string);
                        stringBuilder.append('.');
                        stringBuilder.append(string12);
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append("1) tmp");
                    stringBuilder.append(" ON ");
                    for (String string13 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string);
                        stringBuilder.append('.');
                        stringBuilder.append(string13);
                        stringBuilder.append(" = tmp.");
                        stringBuilder.append(string13);
                        stringBuilder.append(" AND ");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append('.');
                    stringBuilder.append(string2);
                    stringBuilder.append(" = tmp.");
                    stringBuilder.append(string2);
                    stringBuilder.append(") tmp)");
                    if (object.length() > 0) {
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else {
                    if (object.length() == 0) {
                        if (!bl2) {
                            bl2 = true;
                            stringBuilder.append(" WHERE (");
                        } else {
                            stringBuilder.append(" OR (");
                        }
                    }
                    stringBuilder.append(string2);
                    stringBuilder.append(" = (SELECT ");
                    stringBuilder.append(string2);
                    if (n3 != 0) {
                        stringBuilder.append(" FROM (SELECT MIN(");
                    } else {
                        stringBuilder.append(" FROM (SELECT MAX(");
                    }
                    stringBuilder.append(string2);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string14 = object.toString();
                            for (String string15 : arrayList) {
                                string14 = string14.replace(string15, " 1=1 ");
                            }
                            stringBuilder.append(string14);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(") ");
                    } else {
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                    }
                }
                ++n4;
            }
            if (bl) {
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n2 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n2) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.isOrdered) {
                        stringBuilder.append(" ORDER  BY ");
                        boolean bl7 = true;
                        n = 0;
                        while (n < yP_ComplexGabarit.size()) {
                            object = yP_ComplexGabarit.getOperatorAt(n);
                            if (object == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                                stringBuilder.append('.');
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" ASC ");
                            } else if (object == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                                stringBuilder.append('.');
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" DESC ");
                            }
                            ++n;
                        }
                        break;
                    }
                    ++n3;
                }
            }
            return stringBuilder.toString();
        }
        catch (Exception exception) {
            this.logger(1, "sqlGetWhere()  " + exception);
            return null;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private String sqlGetWhereForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            int n2;
            int n3;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
                return "";
            }
            boolean bl = false;
            String string = null;
            StringBuilder stringBuilder = new StringBuilder();
            boolean bl2 = false;
            ArrayList<String> arrayList = null;
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                n3 = 0;
                n2 = 0;
                boolean bl3 = false;
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n4];
                n = 1;
                object = new StringBuilder();
                int n5 = 0;
                while (n5 < yP_ComplexGabarit.size()) {
                    String string2 = yP_ComplexGabarit.getFieldNameAt(n5);
                    Object object2 = yP_ComplexGabarit.getOperatorAt(n5);
                    if (object2 == YP_ComplexGabarit.OPERATOR.MIN) {
                        string = string2;
                        n3 = 1;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.MAX) {
                        string = string2;
                        n2 = 1;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.GROUP) {
                        if (yP_ComplexGabaritArray.length > 1) {
                            this.logger(2, "sqlGetWhereForSlave() group operator is not yet possible with more than one gabarit");
                            return null;
                        }
                        bl3 = true;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                        bl = true;
                    } else if (object2 == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                        bl = true;
                    } else {
                        if (!bl2) {
                            bl2 = true;
                            n = 0;
                            stringBuilder.append(" WHERE (");
                        } else if (n == 1) {
                            stringBuilder.append(" OR (");
                            n = 0;
                        } else {
                            object.append(" AND ");
                        }
                        Object object3 = yP_ComplexGabarit.getObjectAt(n5);
                        if (object3 == null) {
                            object.append("( 1 = 0)");
                        } else {
                            String string3 = this.sqlValue(object3);
                            object.append('(');
                            if (object2 == YP_ComplexGabarit.OPERATOR.CONTAIN) {
                                object.append(string2);
                                object.append(" like '%");
                                object.append(string3.substring(1, string3.length() - 1));
                                object.append("%' ");
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING) {
                                int n6;
                                if (string3.startsWith("'")) {
                                    boolean bl4 = true;
                                    n6 = string3.length() - 1;
                                    while (n6 > 0) {
                                        if (bl4) {
                                            bl4 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append(string2);
                                        object.append(" = '");
                                        object.append(string3.substring(1, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                } else {
                                    boolean bl5 = true;
                                    n6 = string3.length();
                                    while (n6 >= 0) {
                                        if (bl5) {
                                            bl5 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append(string2);
                                        object.append(" = '");
                                        object.append(string3.substring(0, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                }
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.START_WITH) {
                                object.append(string2);
                                object.append(" like ");
                                object.append(string3.substring(0, string3.length() - 1));
                                object.append("%' ");
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.GREATER) {
                                object.append(string2);
                                object.append(" > ");
                                object.append(string3);
                                object.append(' ');
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS) {
                                object.append(string2);
                                object.append(" < ");
                                object.append(string3);
                                object.append(' ');
                            } else if (object2 == YP_ComplexGabarit.OPERATOR.EQUAL) {
                                boolean bl6 = false;
                                if (string3.length() == 2 && string3.contentEquals("''")) {
                                    bl6 = true;
                                    object.append('(');
                                }
                                object.append(string2);
                                object.append(" = ");
                                object.append(string3);
                                if (bl6) {
                                    object.append(" OR ");
                                    object.append(string2);
                                    object.append(" IS NULL)");
                                }
                                object.append(' ');
                            } else if (object2 != YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE) {
                                if (object2 == YP_ComplexGabarit.OPERATOR.LIKE) {
                                    object.append(string2);
                                    object.append(" LIKE ");
                                    object.append(string3);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.IN) {
                                    object.append(string2);
                                    object.append(" IN (");
                                    object.append(string3);
                                    object.append(") ");
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                                    object.append(string2);
                                    if (string3.length() == 2 && string3.contentEquals("''")) {
                                        object.append(" IS NOT NULL");
                                    } else {
                                        object.append(" != ");
                                        object.append(string3);
                                    }
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                                    object.append(string2);
                                    object.append(" >= ");
                                    object.append(string3);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                                    object.append(string2);
                                    object.append(" <= ");
                                    object.append(string3);
                                    object.append(' ');
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP) {
                                    String string4 = String.valueOf(string2) + " = " + string3 + ' ';
                                    object.append(string4);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList<String>();
                                    }
                                    arrayList.add(string4);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP) {
                                    String string5 = String.valueOf(string2) + " <> " + string3 + ' ';
                                    object.append(string5);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string5);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                                    String string6 = String.valueOf(string2) + " < " + string3 + ' ';
                                    object.append(string6);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string6);
                                } else if (object2 == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP) {
                                    String string7 = String.valueOf(string2) + " IN( " + string3 + ")";
                                    object.append(string7);
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add(string7);
                                } else {
                                    this.logger(2, "sqlGetWhereForSlave() unknown operator");
                                }
                            }
                            object.append(')');
                        }
                    }
                    ++n5;
                }
                if (n2 == 0 && n3 == 0) {
                    if (bl3) {
                        this.logger(2, "sqlGetWhereForSlave() group operator is for aggregated columns (MIN, MAX)");
                        return null;
                    }
                    if (object.length() > 0) {
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else if (bl3) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" INNER JOIN (SELECT ");
                    for (String string8 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string8);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string);
                    stringBuilder.append(" FROM ( SELECT ");
                    for (String string9 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string9);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string10 = object.toString();
                            for (String string11 : arrayList) {
                                string10 = string10.replace(string11, " 1=1 ");
                            }
                            stringBuilder.append(string10);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    for (String string12 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string12);
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append("1");
                    stringBuilder.append(" UNION SELECT ");
                    for (String string13 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string13);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string14 = object.toString();
                            for (String string15 : arrayList) {
                                string14 = string14.replace(string15, " 1=1 ");
                            }
                            stringBuilder.append(string14);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    for (String string16 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string16);
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append("1) tmp");
                    stringBuilder.append(" GROUP BY ");
                    for (String string17 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string17);
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append("1) tmp");
                    stringBuilder.append(" USING ( ");
                    for (String string18 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append(string18);
                        stringBuilder.append(',');
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(')');
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else {
                    if (object.length() == 0) {
                        if (!bl2) {
                            bl2 = true;
                            stringBuilder.append(" WHERE (");
                        } else {
                            stringBuilder.append(" OR (");
                        }
                    }
                    stringBuilder.append(string);
                    if (n3 != 0) {
                        stringBuilder.append(" = ( SELECT MIN(");
                        stringBuilder.append(string);
                        stringBuilder.append(")  AS ");
                        stringBuilder.append(string);
                        stringBuilder.append(" FROM (SELECT MIN(");
                    } else {
                        stringBuilder.append(" = ( SELECT MAX(");
                        stringBuilder.append(string);
                        stringBuilder.append(")  AS ");
                        stringBuilder.append(string);
                        stringBuilder.append(" FROM (SELECT MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string19 = object.toString();
                            for (String string20 : arrayList) {
                                string19 = string19.replace(string20, " 1=1 ");
                            }
                            stringBuilder.append(string19);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    if (n3 != 0) {
                        stringBuilder.append(" UNION SELECT MIN(");
                    } else {
                        stringBuilder.append(" UNION SELECT MAX(");
                    }
                    stringBuilder.append(string);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            String string21 = object.toString();
                            for (String string22 : arrayList) {
                                string21 = string21.replace(string22, " 1=1 ");
                            }
                            stringBuilder.append(string21);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(")");
                    stringBuilder.append(')');
                    stringBuilder.append(')');
                    if (object.length() > 0) {
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(") ");
                    }
                }
                ++n4;
            }
            if (bl) {
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n2 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n2) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.isOrdered) {
                        stringBuilder.append(" ORDER  BY ");
                        boolean bl7 = true;
                        n = 0;
                        while (n < yP_ComplexGabarit.size()) {
                            object = yP_ComplexGabarit.getOperatorAt(n);
                            if (object == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" ASC ");
                            } else if (object == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" DESC ");
                            }
                            ++n;
                        }
                        break;
                    }
                    ++n3;
                }
            }
            return stringBuilder.toString();
        }
        catch (Exception exception) {
            this.logger(1, "sqlGetWhereForSlave()  " + exception);
            return null;
        }
    }

    /*
     * Unable to fully structure code
     */
    private String sqlGetSet(YP_TCD_DesignAccesObject var1_1, String var2_2, YP_Row var3_3) {
        var4_4 = var1_1.getFieldList();
        var5_5 = new StringBuilder();
        var6_6 = true;
        var7_7 = 0;
        while (var7_7 < var4_4.length) {
            block13: {
                try {
                    block19: {
                        block18: {
                            block17: {
                                block16: {
                                    block15: {
                                        block14: {
                                            var8_8 = var3_3.getFieldValue(var4_4[var7_7]);
                                            if (var8_8 == null) break block13;
                                            if (!(var8_8 instanceof Integer)) break block14;
                                            if ((Integer)var8_8 == 0) {
                                                break block13;
                                            }
                                            ** GOTO lbl-1000
                                        }
                                        if (!(var8_8 instanceof Long)) break block15;
                                        if ((Long)var8_8 == 0L) {
                                            break block13;
                                        }
                                        ** GOTO lbl-1000
                                    }
                                    if (!(var8_8 instanceof byte[])) break block16;
                                    if (((byte[])var8_8).length == 0 || ((byte[])var8_8)[0] == 0) {
                                        break block13;
                                    }
                                    ** GOTO lbl-1000
                                }
                                if (!(var8_8 instanceof Timestamp)) break block17;
                                if (((Timestamp)var8_8).getTime() == 0L) {
                                    break block13;
                                }
                                ** GOTO lbl-1000
                            }
                            if (!(var8_8 instanceof Date)) break block18;
                            if (((Date)var8_8).getTime() == 0L) {
                                break block13;
                            }
                            ** GOTO lbl-1000
                        }
                        if (!(var8_8 instanceof Float)) break block19;
                        if (((Float)var8_8).floatValue() == 0.0f) {
                            break block13;
                        }
                        ** GOTO lbl-1000
                    }
                    if (!(var8_8 instanceof Enum)) {
                        this.logger(2, "sqlGetSet() unknown type");
                    } else lbl-1000:
                    // 7 sources

                    {
                        if (var6_6) {
                            var6_6 = false;
                        } else {
                            var5_5.append(" , ");
                        }
                        var5_5.append(" ");
                        var5_5.append(var2_2);
                        var5_5.append(".");
                        var5_5.append(var4_4[var7_7].getName());
                        var5_5.append(" = ");
                        this.appendSQLValue(var5_5, var8_8);
                    }
                }
                catch (Exception v0) {}
            }
            ++var7_7;
        }
        return var5_5.toString();
    }

    @Override
    public List<YP_Row> sqlSelectSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block19: {
            block18: {
                if (UtilsYP.getInstanceRole() == 2) break block18;
                this.logger(2, "sqlSelectSuchAsForSlave() only for slave...");
                return null;
            }
            try {
                Object object;
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT ");
                boolean bl = true;
                Field[] fieldArray = yP_TCD_DAO_SQL_Transaction.getFieldList();
                int n3 = fieldArray.length;
                int n4 = 0;
                while (n4 < n3) {
                    object = fieldArray[n4];
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                    }
                    stringBuilder.append(((Field)object).getName());
                    ++n4;
                }
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                stringBuilder.append(' ');
                object = this.sqlGetWhereForSlave(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabaritArray);
                if (object == null) {
                    this.logger(3, "sqlSelectSuchAsForSlave() condition empty:  ");
                    object = "";
                }
                if ((n4 = ((String)object).indexOf(" ORDER  BY ")) >= 0) {
                    stringBuilder.append(((String)object).substring(0, n4));
                } else {
                    stringBuilder.append((String)object);
                }
                stringBuilder.append(" UNION ALL SELECT ");
                bl = true;
                Field[] fieldArray2 = yP_TCD_DAO_SQL_Transaction.getFieldList();
                int n5 = fieldArray2.length;
                int n6 = 0;
                while (n6 < n5) {
                    Field field = fieldArray2[n6];
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                    }
                    stringBuilder.append(field.getName());
                    ++n6;
                }
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
                stringBuilder.append(' ');
                stringBuilder.append((String)object);
                if (n2 > 0) {
                    stringBuilder.insert(0, "SELECT * FROM (SELECT rownum AS myRowNum, foo.* FROM (");
                    stringBuilder.append(") foo ) WHERE myRowNum >");
                    stringBuilder.append(n);
                    stringBuilder.append(" AND myRowNum<=");
                    stringBuilder.append(n2 + n);
                    break block19;
                }
                if (n <= 0) break block19;
                this.logger(2, "sqlSelectSuchAsForSlave() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlSelectSuchAsForSlave() " + exception);
                }
                return null;
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, stringBuilder.toString());
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSuchAsForSlave() start");
        }
        List<YP_Row> list = yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSuchAsForSlave() end");
        }
        return list;
    }

    @Override
    public List<YP_Row> sqlSelectSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        if (UtilsYP.getInstanceRole() == 2 && yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            return this.sqlSelectSuchAsForSlave((YP_TCD_DAO_SQL_Transaction)yP_TCD_DesignAccesObject, n, n2, yP_ComplexGabaritArray);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT * FROM ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append(' ');
        String string = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
        if (string == null) {
            this.logger(3, "sqlSelectSuchAs() condition empty:  ");
            string = "";
        }
        stringBuilder.append(string);
        if (n2 > 0) {
            if (n == 0) {
                stringBuilder.insert(0, "SELECT * FROM (");
                stringBuilder.append(") WHERE rownum <=");
                stringBuilder.append(n2);
            } else {
                stringBuilder.insert(0, "SELECT * FROM (SELECT rownum AS myRowNum, foo.* FROM (");
                stringBuilder.append(") foo ) WHERE myRowNum >");
                stringBuilder.append(n);
                stringBuilder.append(" AND myRowNum<=");
                stringBuilder.append(n2 + n);
            }
        } else if (n > 0) {
            this.logger(2, "sqlSelectSuchAs() It's not possible to set an offset but not a maxResult");
            return null;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSuchAs()" + stringBuilder.toString());
        }
        try {
            List<YP_Row> list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString());
            return list;
        }
        catch (Exception exception) {
            this.logger(3, "sqlSelectSuchAs() No result from database " + exception);
            return null;
        }
    }

    @Override
    public int sqlSelectCount(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            String string = "SELECT COUNT(*) AS count FROM " + yP_TCD_DesignAccesObject.getFullTableName();
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectCount() : " + string);
            }
            return (int)yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, string);
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectCount() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int sqlSelectCountSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        block7: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block7;
                this.logger(2, "sqlSelectCountSuchAsForSlave() only for slave...");
                return -1;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlSelectCountSuchAsForSlave() " + exception);
                }
                return -1;
            }
        }
        String string = this.sqlGetWhereForSlave(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabaritArray);
        if (string == null) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "sqlSelectCountSuchAsForSlave() condition empty:  ");
            }
            string = "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT COALESCE((SELECT COUNT(*) FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string);
        stringBuilder.append("),0) + COALESCE((SELECT COUNT(*) FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string);
        stringBuilder.append("),0) AS count FROM DUAL");
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectCountSuchAsForSlave() : " + stringBuilder.toString());
        }
        return (int)yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCountQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public int sqlSelectCountSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT COUNT(*) AS count FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(' ');
            String string = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string != null && string.length() > 0) {
                stringBuilder.append(string);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectCountSuchAs() : " + stringBuilder.toString());
            }
            return (int)yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectCountSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public YP_Row sqlSelectOne(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n) {
        List<YP_Row> list;
        block6: {
            block5: {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT * FROM ( SELECT rownum myRowNum, ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(".* FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(") WHERE myRowNum = ");
                    stringBuilder.append(n + 1);
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, stringBuilder.toString());
                    }
                    if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null) break block5;
                    this.logger(2, "sqlSelectOne() empty response");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "sqlSelectOne() ...:" + exception);
                    return null;
                }
            }
            if (!list.isEmpty()) break block6;
            this.logger(3, "sqlSelectOne() no row at index:" + n);
            return null;
        }
        return list.get(0);
    }

    @Override
    public YP_Row sqlSelectRowForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, long l) {
        List<YP_Row> list;
        block8: {
            block7: {
                block6: {
                    try {
                        if (UtilsYP.getInstanceRole() == 2) break block6;
                        this.logger(2, "sqlSelectRowForSlave() only for slave...");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "sqlSelectRowForSlave() ...:" + exception);
                        return null;
                    }
                }
                String string = yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT * FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                stringBuilder.append(" WHERE ");
                stringBuilder.append(string);
                stringBuilder.append('=');
                stringBuilder.append(l);
                stringBuilder.append(" UNION SELECT * FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
                stringBuilder.append(" WHERE ");
                stringBuilder.append(string);
                stringBuilder.append('=');
                stringBuilder.append(l);
                if (this.getLogLevel() >= 5) {
                    this.logger(5, stringBuilder.toString());
                }
                if ((list = yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block7;
                this.logger(2, "sqlSelectRowForSlave() empty response");
                return null;
            }
            if (!list.isEmpty()) break block8;
            this.logger(3, "sqlSelectRowForSlave() no row with pk:" + l);
            return null;
        }
        return list.get(0);
    }

    @Override
    public YP_Row sqlSelectRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, long l) {
        List<YP_Row> list;
        block8: {
            block7: {
                block6: {
                    try {
                        String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT * FROM ");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                        stringBuilder.append(" WHERE ");
                        stringBuilder.append(string);
                        stringBuilder.append('=');
                        stringBuilder.append(l);
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, stringBuilder.toString());
                        }
                        if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null) break block6;
                        this.logger(2, "sqlSelectRow() empty response");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "sqlSelectRow() ... :" + exception);
                        return null;
                    }
                }
                if (!list.isEmpty()) break block7;
                this.logger(3, "sqlSelectRow() empty response");
                return null;
            }
            if (list.size() <= 1) break block8;
            this.logger(2, "sqlSelectRow() too many responses...");
            return null;
        }
        return list.get(0);
    }

    @Override
    public long sqlSelectSumSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        block6: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block6;
                this.logger(2, "sqlSelectSumSuchAsForSlave() only for slave...");
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "sqlSelectSumSuchAsForSlave() ...:" + exception);
                return -1L;
            }
        }
        String string2 = this.sqlGetWhereForSlave(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabaritArray);
        if (string2 == null) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "sqlSelectSumSuchAsForSlave() condition empty:  ");
            }
            string2 = "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT COALESCE((SELECT SUM( ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append('.');
        stringBuilder.append(string);
        stringBuilder.append(") FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(string2);
        stringBuilder.append("),0) + COALESCE((SELECT SUM( ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append('.');
        stringBuilder.append(string);
        stringBuilder.append(") FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(string2);
        stringBuilder.append("),0) AS count FROM DUAL");
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSumSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCountQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public long sqlSelectSumSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT SUM(");
            stringBuilder.append(string);
            stringBuilder.append(") AS count FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(' ');
            String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string2 != null && string2.length() > 0) {
                stringBuilder.append(string2);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectSumSuchAs() : " + stringBuilder.toString());
            }
            return yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectSumSuchAs() ...:" + exception);
            return -1L;
        }
    }

    @Override
    public List<String> getDistinctStringValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        int n3;
        block7: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block7;
                this.logger(2, "getDistinctStringValueListSuchAsForSlave() only for slave...");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctStringValueListSuchAsForSlave() ...:" + exception);
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        String string2 = this.sqlGetWhereForSlave(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabaritArray);
        if (string2 == null) {
            this.logger(3, "getDistinctStringValueListSuchAsForSlave() condition empty:  ");
            string2 = "";
        }
        if ((n3 = string2.indexOf(" ORDER  BY ")) >= 0) {
            stringBuilder.append(string2.substring(0, n3));
        } else {
            stringBuilder.append(string2);
        }
        stringBuilder.append(string2);
        stringBuilder.append(" UNION SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctStringValueListSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealStringListQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public String getDistinctValueListSuchAsRequestSQL(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block6: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT DISTINCT ");
                stringBuilder.append(string);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
                if (string2 != null && string2.length() > 0) {
                    stringBuilder.append(string2);
                }
                if (n2 > 0) {
                    stringBuilder.append(" LIMIT ");
                    stringBuilder.append(n);
                    stringBuilder.append(',');
                    stringBuilder.append(n2);
                    break block6;
                }
                if (n <= 0) break block6;
                this.logger(2, "getDistinctValueListSuchAsRequestSQL() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAsRequestSQL() ...:" + exception);
                return null;
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAsRequestSQL() : " + stringBuilder.toString());
        }
        return stringBuilder.toString();
    }

    @Override
    public List<String> getDistinctStringValueListSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        String string2;
        block3: {
            try {
                string2 = this.getDistinctValueListSuchAsRequestSQL(yP_TCD_DesignAccesObject, string, n, n2, yP_ComplexGabaritArray);
                if (string2 != null && !string2.isEmpty()) break block3;
                this.logger(2, "getDistinctStringValueListSuchAs() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctStringValueListSuchAs() ...:" + exception);
                return null;
            }
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealStringListQuery(yP_TCD_DesignAccesObject, string2);
    }

    @Override
    public List<Object> getDistinctValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        int n3;
        block7: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block7;
                this.logger(2, "getDistinctValueListSuchAsForSlave() only for slave...");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAsForSlave() ...:" + exception);
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        String string2 = this.sqlGetWhereForSlave(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabaritArray);
        if (string2 == null) {
            this.logger(3, "getDistinctValueListSuchAsForSlave() condition empty:  ");
            string2 = "";
        }
        if ((n3 = string2.indexOf(" ORDER  BY ")) >= 0) {
            stringBuilder.append(string2.substring(0, n3));
        } else {
            stringBuilder.append(string2);
        }
        stringBuilder.append(string2);
        stringBuilder.append(" UNION SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealListQuery(yP_TCD_DAO_SQL_Transaction, string, stringBuilder.toString());
    }

    @Override
    public List<Object> getDistinctValueListSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block6: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT DISTINCT ");
                stringBuilder.append(string);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
                if (string2 != null && string2.length() > 0) {
                    stringBuilder.append(string2);
                }
                if (n2 > 0) {
                    stringBuilder.append(" LIMIT ");
                    stringBuilder.append(n);
                    stringBuilder.append(',');
                    stringBuilder.append(n2);
                    break block6;
                }
                if (n <= 0) break block6;
                this.logger(2, "getDistinctValueListSuchAs() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAs() ...:" + exception);
                return null;
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAs() : " + stringBuilder.toString());
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealListQuery(yP_TCD_DesignAccesObject, string, stringBuilder.toString());
    }

    @Override
    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        Field[] fieldArray;
        StringBuilder stringBuilder;
        block10: {
            block9: {
                if (UtilsYP.getInstanceRole() == 1) break block9;
                this.logger(2, "archiveRowsSuchAs() only for master...");
                return -1;
            }
            stringBuilder = new StringBuilder();
            fieldArray = yP_TCD_DAO_SQL_Transaction.getFieldList();
            if (fieldArray.length != 0) break block10;
            return -1;
        }
        try {
            boolean bl = true;
            StringBuilder stringBuilder2 = new StringBuilder();
            Field[] fieldArray2 = fieldArray;
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray2[n2];
                if (!bl) {
                    stringBuilder2.append(',');
                } else {
                    bl = false;
                }
                stringBuilder2.append(field.getName());
                ++n2;
            }
            stringBuilder.append("INSERT IGNORE INTO ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append('(');
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(") SELECT ");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullTableName());
            if (string != null && string.length() > 0) {
                stringBuilder.append(string);
            }
            if (yP_TCD_DAO_SQL_Transaction.getLogLevel() >= 5) {
                this.logger(5, "archiveRowsSuchAs() : " + stringBuilder.toString());
            }
            return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCreate(stringBuilder.toString(), yP_TCD_DesignAccesObject, yP_TCD_DAO_SQL_Transaction);
        }
        catch (Exception exception) {
            this.logger(2, "archiveRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            return this.archiveRowsSuchAs(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject, this.sqlGetWhere(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getTableName(), yP_ComplexGabaritArray));
        }
        catch (Exception exception) {
            this.logger(2, "archiveRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public List<YP_Row> selectFrom(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2) {
        List<YP_Row> list;
        block8: {
            StringBuilder stringBuilder;
            block7: {
                try {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT * FROM ");
                    stringBuilder.append(string);
                    if (n2 > 0) {
                        stringBuilder.append(" LIMIT ");
                        stringBuilder.append(n);
                        stringBuilder.append(',');
                        stringBuilder.append(n2);
                        break block7;
                    }
                    if (n <= 0) break block7;
                    this.logger(2, "selectFrom() It's not possible to set an offset but not a maxResult");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(3, "selectFrom() No result from database" + exception);
                    return null;
                }
            }
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "selectFrom() : " + stringBuilder.toString());
            }
            if ((list = yP_TCD_DataBaseConnector.dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block8;
            this.logger(2, "selectFrom() empty response");
            return null;
        }
        if (list.isEmpty()) {
            this.logger(3, "selectFrom() empty response");
            return list;
        }
        return list;
    }

    @Override
    public int deleteFromWhere(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, String string, String string2, long[] lArray) {
        block8: {
            block7: {
                if (lArray != null) break block7;
                this.logger(3, "deleteFromWhere() list == null");
                return -1;
            }
            if (lArray.length != 0) break block8;
            this.logger(3, "deleteFromWhere() empty list");
            return -1;
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DELETE FROM ");
            stringBuilder.append(string);
            stringBuilder.append(" WHERE ");
            int n = 0;
            while (n < lArray.length) {
                if (n != 0) {
                    stringBuilder.append(" OR ");
                }
                stringBuilder.append(string2);
                stringBuilder.append('=');
                stringBuilder.append(lArray[n]);
                ++n;
            }
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "deleteFromWhere() : " + stringBuilder.toString());
            }
            return yP_TCD_DataBaseConnector.dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(3, "deleteFromWhere() ...:" + exception);
            return -1;
        }
    }

    @Override
    public boolean isSlaveTransactionEmpty(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, List<YP_TCD_DAO_SQL_Transaction> list) throws Exception {
        HashSet<String> hashSet;
        boolean bl;
        block11: {
            bl = true;
            hashSet = new HashSet<String>();
            for (YP_TCD_DAO_SQL_Transaction object : list) {
                hashSet.add(object.getSlaveTableName());
            }
            if (hashSet != null && !hashSet.isEmpty()) break block11;
            return false;
        }
        try {
            int n;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT 1 As Count FROM information_schema.TABLES WHERE TABLE_ROWS > 0  AND TABLE_SCHEMA = '");
            stringBuilder.append(list.get(0).getSchemaName());
            boolean bl2 = true;
            for (String n2 : hashSet) {
                if (n2.startsWith("TokenTable_slave_")) continue;
                bl2 = false;
                break;
            }
            if (bl2) {
                stringBuilder.append("' AND ( TABLE_NAME like \"TokenTable_slave_%\")");
            } else {
                stringBuilder.append("' AND ( TABLE_NAME in (");
                for (String n2 : hashSet) {
                    if (!bl) {
                        stringBuilder.append(",'");
                    } else {
                        stringBuilder.append('\'');
                    }
                    stringBuilder.append(n2);
                    stringBuilder.append('\'');
                    bl = false;
                }
                stringBuilder.append("))");
            }
            stringBuilder.append(" LIMIT 1");
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "isSlaveTransactionEmpty() : " + stringBuilder);
            }
            return (n = (int)yP_TCD_DataBaseConnector.dealCountQuery(null, stringBuilder.toString())) <= 0;
        }
        catch (Exception exception) {
            this.logger(3, "isSlaveTransactionEmpty() :" + exception);
            throw exception;
        }
    }

    @Override
    public List<YP_Row> sqlSelectSuchAsForTransaction(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        return null;
    }

    private String getShowCreateTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select dbms_metadata.get_ddl('TABLE','");
        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName().toUpperCase());
        stringBuilder.append("', '");
        stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName().toUpperCase());
        stringBuilder.append("') FROM dual");
        String string2 = stringBuilder.toString();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getShowCreateTable() : " + string2);
        }
        return string2;
    }

    @Override
    public String getContractKeyClause(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject.getRowTemplate().contractKey > 0L) {
            return " contractKey = " + yP_TCD_DesignAccesObject.getRowTemplate().contractKey + ' ';
        }
        return "";
    }

    @Override
    public String getContractKeyClauseUsedForGlobalTransaction(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject.getRowTemplate().contractKey > 0L) {
            return "contractKey <> 0";
        }
        return "";
    }

    @Override
    public String sqlSchemaName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return yP_TCD_DesignAccesObject.getSchemaName();
    }

    @Override
    public String sqlFullTableName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DesignAccesObject)) + '.' + yP_TCD_DesignAccesObject.getTableName().toLowerCase();
    }

    @Override
    public String sqlFullSlaveTableName(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DAO_SQL_Transaction)) + '.' + yP_TCD_DAO_SQL_Transaction.getSlaveTableName().toLowerCase();
    }

    @Override
    public String sqlFullMasterTableName(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DAO_SQL_Transaction)) + '.' + yP_TCD_DAO_SQL_Transaction.getMasterTableName().toLowerCase();
    }

    @Override
    public void appendSQLColumnName(StringBuilder stringBuilder, String string, String string2) {
        stringBuilder.append("");
        stringBuilder.append(string);
        stringBuilder.append(FIELD_MID);
        stringBuilder.append(string2);
        stringBuilder.append("");
    }

    @Override
    public void appendSQLColumnName(StringBuilder stringBuilder, String string) {
        stringBuilder.append("");
        stringBuilder.append(string);
        stringBuilder.append("");
    }

    @Override
    public int sqlBatchUpdate(YP_TCD_DAO_LOC yP_TCD_DAO_LOC, Field[] fieldArray, Field[] fieldArray2) {
        return 0;
    }

    @Override
    public int sqlBatchDelete(YP_TCD_DAO_LOC yP_TCD_DAO_LOC, Field[] fieldArray) {
        return 0;
    }
}

