/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;

public final class YP_TCG_PropertiesFileReader
extends YP_GlobalComponent {
    public YP_TCG_PropertiesFileReader(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final String toString() {
        return "PropertyFileReader";
    }

    @Override
    public final String getVersion() {
        return "V1.0.0.0";
    }

    private int saveProperties(Properties properties, String string, String string2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(string);
            properties.store(fileOutputStream, string2);
            fileOutputStream.flush();
            ((OutputStream)fileOutputStream).close();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "saveProperties() " + exception);
            }
            return -1;
        }
    }

    private Properties loadProperties(String string) {
        try {
            Properties properties = new Properties();
            if (string.endsWith(".properties")) {
                properties.load(new FileInputStream(string));
            } else {
                properties.load(new FileInputStream(String.valueOf(string) + ".properties"));
            }
            return properties;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadProperties() " + exception);
            }
            return null;
        }
    }

    public String getProperty(YP_Object yP_Object, String string, String string2) {
        if (string == null) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getProperty() Plugins without properties :" + yP_Object.getSimpleName());
            }
            return null;
        }
        Properties properties = this.loadProperties(string);
        if (properties == null) {
            this.logger(2, "getProperty() load :" + string);
            return null;
        }
        String string3 = properties.getProperty(string2);
        if (string3 == null) {
            if (string2 != null && (string2.contentEquals("logLevel") || string2.contentEquals("preferredName"))) {
                return null;
            }
            this.logger(3, "getProperty() Value not found :" + string2);
            return null;
        }
        return string3.trim();
    }

    public int setProperty(YP_Object yP_Object, String string, String string2, String string3) {
        if (string == null) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "setProperty() Plugins without properties :" + yP_Object.getSimpleName());
            }
            return -1;
        }
        Properties properties = this.loadProperties(string);
        if (properties == null) {
            this.logger(2, "setProperty() load :" + string);
            return -1;
        }
        properties.setProperty(string2, string3);
        int n = this.saveProperties(properties, string, null);
        if (n != 1) {
            this.logger(2, "setProperty() Unable to save " + string2 + ":" + string3 + " in " + string);
            return -1;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "setProperty()  Saved " + string2 + ":" + string3 + " in " + string);
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getProperty")) {
                String string2 = (String)objectArray[0];
                String string3 = (String)objectArray[1];
                return this.getProperty(yP_Object, string2, string3);
            }
            if (string.contentEquals("setProperty")) {
                String string4 = (String)objectArray[0];
                String string5 = (String)objectArray[1];
                String string6 = (String)objectArray[2];
                return this.setProperty(yP_Object, string4, string5, string6);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }
}

