/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.YP_TCG_Mailer;
import org.yp.framework.globalcomponents.authentifiers.YP_Authentifiers;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.YP_TCD_DCC_User_Extension;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.IdentificationLevelEnumeration;
import org.yp.utils.enums.UserStatusEnumeration;

public class YP_TCG_User
extends YP_GlobalComponent {
    private static final long REFRESH_TOKEN_TIMEOUT = 1800000L;
    private static final long MOROCCO_REFRESH_TOKEN_TIMEOUT = 300000L;
    private static final long TOKEN_TIMEOUT = 30600000L;
    private static final long MOROCCO_TOKEN_TIMEOUT = 2700000L;
    private YP_TCD_DCC_User_Extension extensionUser;
    private YP_TS_DataContainerManager dataContainerManager = null;
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    private YP_TCD_DCC_Status dataContainerStatus = null;
    private final Map<String, UserInfos> userHashMap = new HashMap<String, UserInfos>();
    private final boolean test = false;

    public YP_TCG_User(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        if (this.dataContainerManager == null) {
            this.logger(2, "initialize() no DCC_Manager...");
            return -1;
        }
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        if (this.dataContainerTechnique == null) {
            this.logger(2, "initialize() no DCC_Technique...");
            return -1;
        }
        this.dataContainerStatus = this.dataContainerManager.getDataContainerStatus();
        if (this.dataContainerStatus == null) {
            this.logger(2, "initialize() no DCC_Status...");
            return -1;
        }
        this.extensionUser = (YP_TCD_DCC_User_Extension)this.dataContainerTechnique.newPluginByName("DataContainerExtensionUser", new Object[0]);
        this.extensionUser.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "User";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    private int updateUserAccesContext(String string) {
        UserInfos userInfos = this.userHashMap.get(string);
        if (userInfos == null) {
            return -1;
        }
        return this.updateUserAccesContext(userInfos);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private int updateUserAccesContext(UserInfos userInfos) {
        UserInfos userInfos2 = userInfos;
        synchronized (userInfos2) {
            userInfos.groupContainerSet.clear();
            userInfos.brandContainerSet.clear();
            userInfos.merchantContainerSet.clear();
            userInfos.businessContainerSet.clear();
            userInfos.storeMap.clear();
            userInfos.uniqueAccessToStoreIdentifier = null;
            try {
                if (userInfos.userAccessLevel == 1) {
                    List list = (List)this.dataContainerManager.dealRequest(this, "getDataContainerGroupList", new Object[0]);
                    userInfos.groupContainerSet.addAll(list);
                    List list2 = (List)this.dataContainerManager.dealRequest(this, "getDataContainerBrandList", new Object[0]);
                    userInfos.brandContainerSet.addAll(list2);
                    for (YP_TCD_DCC_Brand yP_TCD_DC_Context : userInfos.brandContainerSet) {
                        userInfos.merchantContainerSet.addAll(yP_TCD_DC_Context.dataContainerMerchantList);
                    }
                    for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : userInfos.merchantContainerSet) {
                        userInfos.businessContainerSet.addAll(yP_TCD_DCC_Merchant.dataContainerBusinessList);
                    }
                } else if (userInfos.userParameters != null && !userInfos.userParameters.isEmpty()) {
                    Object object;
                    List<YP_Row> list422;
                    Object object2;
                    Object object3;
                    Iterator<YP_Row> iterator;
                    YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(userInfos.userParameters.get(0).getFather());
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, userInfos.idUser);
                    yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "groupAccess");
                    List<YP_Row> list5 = YP_TCD_DesignAccesObject.getRowListSuchAs(userInfos.userParameters, yP_ComplexGabarit);
                    if (list5 != null && !list5.isEmpty()) {
                        for (YP_Row yP_Row : list5) {
                            try {
                                long list32 = Long.parseLong(yP_Row.getFieldStringValueByName("value"));
                                YP_TCD_DCC_Group yP_TCD_DCC_Group = (YP_TCD_DCC_Group)this.dataContainerManager.dealRequest(this, "getDataContainerGroup", list32);
                                if (yP_TCD_DCC_Group == null) {
                                    this.logger(2, "updateUserAccesContext() bad group access parameter found for " + userInfos.userLogin + " : " + list32);
                                    continue;
                                }
                                userInfos.groupContainerSet.add(yP_TCD_DCC_Group);
                                iterator = this.dataContainerTechnique.getIdBrandListByGroup(list32);
                                if (iterator == null) continue;
                                object3 = iterator.iterator();
                                while (object3.hasNext()) {
                                    long l = object3.next();
                                    object2 = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", l);
                                    if (object2 == null) continue;
                                    userInfos.brandContainerSet.add(object2);
                                }
                            }
                            catch (Exception exception) {
                                this.logger(2, "updateUserAccesContext() group ", exception);
                            }
                        }
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(userInfos.userParameters.get(0).getFather());
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, userInfos.idUser);
                    yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "brandAccess");
                    List<YP_Row> list = YP_TCD_DesignAccesObject.getRowListSuchAs(userInfos.userParameters, yP_ComplexGabarit);
                    if (list != null && !list.isEmpty()) {
                        for (List<YP_Row> list422 : list) {
                            try {
                                long l = Long.parseLong(((YP_Row)((Object)list422)).getFieldStringValueByName("value"));
                                iterator = this.dataContainerTechnique.brand.getRowByPrimaryKey(l);
                                if (iterator == null) {
                                    this.logger(2, "updateUserAccesContext() bad brand access parameter found for " + userInfos.userLogin + " : " + l);
                                    continue;
                                }
                                String string = ((YP_Row)((Object)iterator)).getFieldStringValueByName("brandName");
                                userInfos.brandContainerSet.add((YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", string));
                            }
                            catch (Exception exception) {
                                this.logger(2, "updateUserAccesContext() brand ", exception);
                            }
                        }
                    }
                    for (List<YP_Row> list422 : userInfos.brandContainerSet) {
                        userInfos.merchantContainerSet.addAll(((YP_TCD_DCC_Brand)((Object)list422)).dataContainerMerchantList);
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(userInfos.userParameters.get(0).getFather());
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, userInfos.idUser);
                    yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
                    list422 = YP_TCD_DesignAccesObject.getRowListSuchAs(userInfos.userParameters, yP_ComplexGabarit);
                    if (list422 != null && !list422.isEmpty()) {
                        for (YP_Row yP_Row : list422) {
                            try {
                                Object object42;
                                long l = Long.parseLong(yP_Row.getFieldStringValueByName("value"));
                                YP_Row yP_Row2 = this.dataContainerTechnique.merchant.getRowByPrimaryKey(l);
                                if (yP_Row2 == null) {
                                    this.logger(2, "updateUserAccesContext() bad merchant access parameter found for  " + userInfos.userLogin + " : " + l);
                                    continue;
                                }
                                object = yP_Row2.getFieldStringValueByName("merchantName");
                                object3 = this.dataContainerTechnique.brand.getRowByPrimaryKey((Long)yP_Row2.getFieldValueByName("idBrand"));
                                if (object3 == null) {
                                    this.logger(2, "updateUserAccesContext() no brand found for  " + userInfos.userLogin + ", merchant:" + l);
                                    continue;
                                }
                                object2 = ((YP_Row)object3).getFieldStringValueByName("brandName");
                                boolean bl = false;
                                for (Object object42 : userInfos.brandContainerSet) {
                                    if (!((YP_Object)object42).getContractIdentifier().contentEquals((CharSequence)object2)) continue;
                                    bl = true;
                                    break;
                                }
                                if (bl) continue;
                                object42 = String.valueOf(object2) + '_' + (String)object;
                                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", object42);
                                userInfos.merchantContainerSet.add(yP_TCD_DCC_Merchant);
                            }
                            catch (Exception exception) {
                                this.logger(2, "updateUserAccesContext() merchant", exception);
                            }
                        }
                    }
                    for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : userInfos.merchantContainerSet) {
                        userInfos.businessContainerSet.addAll(yP_TCD_DCC_Merchant.dataContainerBusinessList);
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(userInfos.userParameters.get(0).getFather());
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, userInfos.idUser);
                    yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "storeAccess");
                    List<YP_Row> list2 = YP_TCD_DesignAccesObject.getRowListSuchAs(userInfos.userParameters, yP_ComplexGabarit);
                    if (list2 != null && !list2.isEmpty()) {
                        for (YP_Row yP_Row : list2) {
                            try {
                                iterator = yP_Row.getFieldStringValueByName("value");
                                String[] stringArray = ((String)((Object)iterator)).split("_");
                                if (stringArray.length != 3) {
                                    this.logger(2, "updateUserAccesContext() bad store identifier :" + (String)((Object)iterator));
                                    continue;
                                }
                                if (userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet.isEmpty() && list2.size() == 1) {
                                    userInfos.uniqueAccessToStoreIdentifier = stringArray[2];
                                }
                                object = (List)this.dataContainerManager.dealRequest(this, "getDataContainerList", null, String.valueOf(stringArray[0]) + '_' + stringArray[1], stringArray[2]);
                                userInfos.businessContainerSet.addAll(object);
                                if (object == null || object.isEmpty() || (object2 = ((YP_TCD_DCC_Merchant)(object3 = ((YP_TCD_DCC_Business)object.get(0)).getDataContainerMerchant())).getDataContainerBrand().getStore(((YP_TCD_DCC_Merchant)object3).getIDMerchant(), stringArray[2])) == null) continue;
                                ArrayList<Object> arrayList = (ArrayList<Object>)userInfos.storeMap.get(object3);
                                if (arrayList == null) {
                                    arrayList = new ArrayList<Object>();
                                }
                                arrayList.add(object2);
                                userInfos.storeMap.put(object3, arrayList);
                            }
                            catch (Exception exception) {
                                this.logger(2, "updateUserAccesContext() store", exception);
                            }
                        }
                    }
                    yP_ComplexGabarit = new YP_ComplexGabarit(userInfos.userParameters.get(0).getFather());
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, userInfos.idUser);
                    yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "contractAccess");
                    List<YP_Row> list3 = YP_TCD_DesignAccesObject.getRowListSuchAs(userInfos.userParameters, yP_ComplexGabarit);
                    if (list3 != null && !list3.isEmpty()) {
                        for (YP_Row yP_Row : list3) {
                            try {
                                long l = Long.parseLong(yP_Row.getFieldStringValueByName("value"));
                                object3 = (YP_TCD_DCC_Business)this.dataContainerManager.dealRequest(this, "getDataContainerBusiness", l);
                                if (object3 == null) continue;
                                userInfos.businessContainerSet.add(object3);
                            }
                            catch (Exception exception) {
                                this.logger(2, "updateUserAccesContext() contract", exception);
                            }
                        }
                    }
                }
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "updateUserAccesContext()", exception);
                return -1;
            }
        }
    }

    private void updateUserAccesContext(YP_Transaction yP_Transaction, UserInfos userInfos, boolean bl) {
        this.updateUserAccesContext(userInfos);
        if (!bl) {
            this.updateContextWithUserInfos(yP_Transaction, userInfos);
            yP_Transaction.getDataContainerTransaction().contextHandler.groupContainers = new ArrayList<YP_TCD_DCC_Group>(userInfos.groupContainerSet);
            yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers = new ArrayList<YP_TCD_DCC_Brand>(userInfos.brandContainerSet);
            yP_Transaction.getDataContainerTransaction().contextHandler.merchantContainers = new ArrayList<YP_TCD_DCC_Merchant>(userInfos.merchantContainerSet);
            yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers = new ArrayList<YP_TCD_DCC_Business>(userInfos.businessContainerSet);
            yP_Transaction.getDataContainerTransaction().contextHandler.storeMap = new HashMap(userInfos.storeMap);
        }
    }

    private void updateContextWithUserInfos(YP_Transaction yP_Transaction, UserInfos userInfos) {
        String string = yP_Transaction.getContractIdentifier();
        if (string.contentEquals("KERNEL") && userInfos.brandContainerSet.size() <= 1) {
            if (userInfos.merchantContainerSet.size() <= 1) {
                if (userInfos.businessContainerSet.size() == 1) {
                    String string2 = ((YP_Object)userInfos.businessContainerSet.toArray()[0]).getContractIdentifier();
                    yP_Transaction.setContractIdentifier(string2);
                    yP_Transaction.getDataContainerTransaction().setContractIdentifier(string2);
                } else if (!userInfos.merchantContainerSet.isEmpty()) {
                    String string3 = ((YP_Object)userInfos.merchantContainerSet.toArray()[0]).getContractIdentifier();
                    yP_Transaction.setContractIdentifier(string3);
                    yP_Transaction.getDataContainerTransaction().setContractIdentifier(string3);
                } else if (userInfos.businessContainerSet.size() > 1) {
                    Object object2;
                    HashSet<String> hashSet = new HashSet<String>();
                    for (Object object2 : userInfos.businessContainerSet) {
                        hashSet.add(((YP_TCD_DCC_Business)object2).getDataContainerMerchant().getContractIdentifier());
                    }
                    if (hashSet.size() == 1) {
                        object2 = (String)hashSet.toArray()[0];
                        yP_Transaction.setContractIdentifier((String)object2);
                        yP_Transaction.getDataContainerTransaction().setContractIdentifier((String)object2);
                    } else {
                        object2 = new HashSet();
                        for (Object object3 : userInfos.businessContainerSet) {
                            object2.add(((YP_TCD_DCC_Business)object3).getDataContainerMerchant().getDataContainerBrand().getContractIdentifier());
                        }
                        if (object2.size() == 1) {
                            Object object3;
                            object3 = (String)object2.toArray()[0];
                            yP_Transaction.setContractIdentifier((String)object3);
                            yP_Transaction.getDataContainerTransaction().setContractIdentifier((String)object3);
                        }
                    }
                }
            } else if (!userInfos.brandContainerSet.isEmpty()) {
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)userInfos.brandContainerSet.toArray()[0];
                String string4 = yP_TCD_DCC_Brand.getContractIdentifier();
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : userInfos.merchantContainerSet) {
                    if (yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand() == yP_TCD_DCC_Brand.getIDBrand()) continue;
                    string4 = null;
                    break;
                }
                if (string4 != null) {
                    yP_Transaction.setContractIdentifier(string4);
                    yP_Transaction.getDataContainerTransaction().setContractIdentifier(string4);
                }
            } else {
                HashSet<String> hashSet = new HashSet<String>();
                for (Object object : userInfos.merchantContainerSet) {
                    hashSet.add(((YP_TCD_DCC_Merchant)object).getDataContainerBrand().getContractIdentifier());
                }
                if (hashSet.size() == 1) {
                    Object object;
                    object = (String)hashSet.toArray()[0];
                    yP_Transaction.setContractIdentifier((String)object);
                    yP_Transaction.getDataContainerTransaction().setContractIdentifier((String)object);
                }
            }
        }
        if (userInfos.uniqueAccessToStoreIdentifier != null) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "updateContextWithUserInfos() Store identifier set to " + userInfos.uniqueAccessToStoreIdentifier);
            }
            yP_Transaction.getDataContainerTransaction().contextHandler.setStoreIdentifier(userInfos.uniqueAccessToStoreIdentifier);
        }
    }

    private void createNewUserRowIfNeeded(UserInfos userInfos) throws Exception {
        if (userInfos.userRow.getModifierFlag() != 0) {
            UtilsYP.sleep(2);
            this.updateTokenInfos(userInfos);
            YP_Row yP_Row = (YP_Row)userInfos.userRow.clone();
            yP_Row.setIsItAClonedRow(false);
            yP_Row.setModifierFlag(3);
            yP_Row.setPrimaryKey(yP_Row.getFather().getNextPrimaryKey());
            yP_Row.persist();
            userInfos.userRow = yP_Row;
        } else {
            this.persistToken(userInfos);
        }
    }

    private void updateTokenInfos(UserInfos userInfos) {
        userInfos.userRow.set("token", userInfos.userToken);
        long l = System.currentTimeMillis();
        if (UtilsYP.isMoroccoServer()) {
            userInfos.userRow.set("tokenExpirationSystemTime", new Timestamp(l + 2700000L));
        } else {
            userInfos.userRow.set("tokenExpirationSystemTime", new Timestamp(l + 30600000L));
        }
        userInfos.userRow.set("lastGMTTime", new Timestamp(l));
    }

    private void persistToken(UserInfos userInfos) throws Exception {
        if (UtilsYP.getInstanceRole() != 3 && UtilsYP.getInstanceRole() != 1) {
            return;
        }
        Timestamp timestamp = UtilsYP.isMoroccoServer() ? new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() + 2700000L - 300000L) : new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() + 30600000L - 1800000L);
        String string = userInfos.userRow.getFieldStringValueByName("token");
        Timestamp timestamp2 = (Timestamp)userInfos.userRow.getFieldValueByName("tokenExpirationSystemTime");
        if (!string.equalsIgnoreCase(userInfos.userToken) || timestamp2.before(timestamp)) {
            this.updateTokenInfos(userInfos);
            userInfos.userRow.persist();
        }
    }

    private IdentificationLevelEnumeration checkToken(YP_Transaction yP_Transaction, String string, String string2, String string3) {
        try {
            if (string3 != null && !string3.isEmpty()) {
                Object object;
                Object object2;
                UserInfos userInfos = this.userHashMap.get(string);
                if (userInfos == null) {
                    userInfos = this.getUserInfos(yP_Transaction, string);
                    if (userInfos == null) {
                        return IdentificationLevelEnumeration.ACCOUNT_UNKNOWN;
                    }
                    object2 = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
                    object = (Timestamp)userInfos.userRow.getFieldValueByName("tokenExpirationSystemTime");
                    if (string3.equalsIgnoreCase(userInfos.userToken) && ((Timestamp)object).after((Timestamp)object2)) {
                        this.updateUserAccesContext(userInfos);
                        this.userHashMap.put(string, userInfos);
                    } else if (string3.equalsIgnoreCase(userInfos.userPermanentToken)) {
                        this.updateUserAccesContext(userInfos);
                        this.userHashMap.put(string, userInfos);
                    } else {
                        if (this.getLogLevel() >= 3) {
                            this.logger(3, "checkToken() Token has expired for " + string);
                        }
                        if (string2 == null || string2.isEmpty()) {
                            return IdentificationLevelEnumeration.EXPIRED_SESSION;
                        }
                    }
                }
                if (string3.equalsIgnoreCase(userInfos.userToken) || string3.equalsIgnoreCase(userInfos.userPermanentToken)) {
                    userInfos.lastRequestTimestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
                    if (string3.equalsIgnoreCase(userInfos.userToken)) {
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.TOKEN);
                    } else {
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.PERMANENT_TOKEN);
                    }
                    yP_Transaction.getDataContainerTransaction().userHandler.userParameters = userInfos.userParameters;
                    yP_Transaction.getDataContainerTransaction().contextHandler.groupContainers = new ArrayList<YP_TCD_DCC_Group>(userInfos.groupContainerSet);
                    yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers = new ArrayList<YP_TCD_DCC_Brand>(userInfos.brandContainerSet);
                    yP_Transaction.getDataContainerTransaction().contextHandler.merchantContainers = new ArrayList<YP_TCD_DCC_Merchant>(userInfos.merchantContainerSet);
                    yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers = new ArrayList<YP_TCD_DCC_Business>(userInfos.businessContainerSet);
                    yP_Transaction.getDataContainerTransaction().contextHandler.storeMap = new HashMap(userInfos.storeMap);
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserToken(userInfos.userToken);
                    yP_Transaction.getDataContainerTransaction().userHandler.setPermanentToken(userInfos.userPermanentToken);
                    object2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserPreferredLanguage();
                    if (object2 == null || ((String)object2).isEmpty()) {
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserPreferredLanguage(userInfos.preferredLanguage);
                    } else if (!((String)object2).contentEquals(userInfos.preferredLanguage)) {
                        userInfos.userRow.set("preferredLanguage", (String)object2);
                        userInfos.preferredLanguage = object2;
                    }
                    object = yP_Transaction.getDataContainerTransaction().userHandler.getUserFirstName();
                    if (object == null || ((String)object).isEmpty()) {
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserFirstName(userInfos.userFirstName);
                    } else if (!((String)object).contentEquals(userInfos.userFirstName)) {
                        userInfos.userRow.set("firstName", (String)object);
                        userInfos.userFirstName = object;
                    }
                    String string4 = yP_Transaction.getDataContainerTransaction().userHandler.getUserLastName();
                    if (string4 == null || string4.isEmpty()) {
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserLastName(userInfos.userLastName);
                    } else if (!string4.contentEquals(userInfos.userLastName)) {
                        userInfos.userRow.set("lastName", string4);
                        userInfos.userLastName = string4;
                    }
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserIdentifier(userInfos.idUser);
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserFatherIdentifier(userInfos.father);
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserAccessLevel(userInfos.userAccessLevel);
                    yP_Transaction.getDataContainerTransaction().userHandler.setVadAllowed(userInfos.vadAllowed);
                    yP_Transaction.getDataContainerTransaction().userHandler.setMerchantTicketAllowed(userInfos.merchantTicketAllowed);
                    yP_Transaction.getDataContainerTransaction().userHandler.setCashierCreationAllowed(userInfos.cashierCreationAllowed);
                    this.createNewUserRowIfNeeded(userInfos);
                    this.updateContextWithUserInfos(yP_Transaction, userInfos);
                    if (string3.equalsIgnoreCase(userInfos.userToken)) {
                        return IdentificationLevelEnumeration.TOKEN;
                    }
                    return IdentificationLevelEnumeration.PERMANENT_TOKEN;
                }
                this.userHashMap.remove(string);
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "checkToken() Wrong token used for " + string);
                }
                if (string2 == null || string2.isEmpty()) {
                    return IdentificationLevelEnumeration.ERROR;
                }
            }
            return IdentificationLevelEnumeration.NONE;
        }
        catch (Exception exception) {
            this.logger(2, "checkToken() ", exception);
            return IdentificationLevelEnumeration.ERROR;
        }
    }

    private IdentificationLevelEnumeration authenticate(YP_Transaction yP_Transaction, String string, String string2, String string3, StringBuilder stringBuilder) {
        UserInfos userInfos;
        IdentificationLevelEnumeration identificationLevelEnumeration = this.authenticateInternal(yP_Transaction, string, string2, string3, stringBuilder);
        String string4 = yP_Transaction.getContractIdentifier();
        if (string4.contentEquals("KERNEL") && (userInfos = this.userHashMap.get(string)) != null && userInfos.uniqueAccessToStoreIdentifier != null && !userInfos.uniqueAccessToStoreIdentifier.isEmpty() && userInfos.brandContainerSet != null && userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet != null && userInfos.merchantContainerSet.isEmpty() && userInfos.businessContainerSet != null && !userInfos.businessContainerSet.isEmpty()) {
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = ((YP_TCD_DCC_Business)userInfos.businessContainerSet.toArray()[0]).getDataContainerMerchant();
            yP_Transaction.getDataContainerTransaction().setContractIdentifier(yP_TCD_DCC_Merchant.getContractIdentifier());
            yP_Transaction.setContractIdentifier(yP_TCD_DCC_Merchant.getContractIdentifier());
        }
        return identificationLevelEnumeration;
    }

    private IdentificationLevelEnumeration authenticateInternal(YP_Transaction yP_Transaction, String string, String string2, String string3, StringBuilder stringBuilder) {
        try {
            Object object;
            Object object2;
            IdentificationLevelEnumeration identificationLevelEnumeration;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "authenticate() authentication for: " + string);
            }
            if ((identificationLevelEnumeration = this.checkToken(yP_Transaction, string, string2, string3)) != IdentificationLevelEnumeration.NONE) {
                return identificationLevelEnumeration;
            }
            UserInfos userInfos = this.userHashMap.remove(string);
            if (string2 == null || string2.isEmpty()) {
                this.logger(2, "authenticate() no password... for:" + string);
                return IdentificationLevelEnumeration.ERROR;
            }
            if ((userInfos = userInfos != null ? this.updateUserInfos(yP_Transaction, string, userInfos) : this.getUserInfos(yP_Transaction, string)) == null) {
                return IdentificationLevelEnumeration.ACCOUNT_UNKNOWN;
            }
            UserStatusEnumeration userStatusEnumeration = (UserStatusEnumeration)((Object)userInfos.userRow.getFieldValueByName("userStatus"));
            if (userStatusEnumeration == null) {
                this.logger(2, "authenticate() no userStatus it's OK for now, but the DB must be updated for " + userInfos.userLogin);
            } else {
                switch (userStatusEnumeration) {
                    case ACTIVE: 
                    case INITIAL: {
                        break;
                    }
                    case INACTIVE: 
                    case BLOCKED: {
                        this.logger(2, "authenticate() account deactivated for " + userInfos.userLogin);
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.BLOCKED);
                        this.createNewUserRowIfNeeded(userInfos);
                        stringBuilder = stringBuilder.append("USER_ACCOUNT_BLOCKED");
                        return IdentificationLevelEnumeration.BLOCKED;
                    }
                    case DELETED: {
                        this.logger(2, "authenticate() account deleted for " + userInfos.userLogin);
                        return IdentificationLevelEnumeration.ERROR;
                    }
                    case UNKNOWN: {
                        this.logger(2, "authenticate() userStatus unknown, it's OK for now, but the DB must be updated for " + userInfos.userLogin);
                    }
                }
            }
            this.updateUserAccesContext(yP_Transaction, userInfos, false);
            if (yP_Transaction.getContractIdentifier().contentEquals("KERNEL") && userInfos.uniqueAccessToStoreIdentifier != null && !userInfos.uniqueAccessToStoreIdentifier.isEmpty() && userInfos.brandContainerSet != null && userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet != null && userInfos.merchantContainerSet.isEmpty() && userInfos.businessContainerSet != null && !userInfos.businessContainerSet.isEmpty()) {
                object2 = ((YP_TCD_DCC_Business)userInfos.businessContainerSet.toArray()[0]).getDataContainerMerchant();
                yP_Transaction.getDataContainerTransaction().setContractIdentifier(((YP_Object)object2).getContractIdentifier());
                yP_Transaction.setContractIdentifier(((YP_Object)object2).getContractIdentifier());
            }
            object2 = YP_Authentifiers.AuthenticationResultEnumeration.UNKNOWN;
            String string4 = userInfos.userRow.getFieldStringValueByName("authPluginName");
            if (string4 != null && !string4.isEmpty()) {
                object = this.getPluginByName(string4);
                if (object == null || !(object instanceof YP_Authentifiers)) {
                    this.logger(2, "authenticate() pb with authentifier plugin :" + string4);
                    return IdentificationLevelEnumeration.IMPOSSIBLE;
                }
                object2 = ((YP_Authentifiers)object).authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
            } else {
                long l = (Long)userInfos.userRow.getFieldValueByName("idLDAP");
                if (l != 0L) {
                    YP_Object yP_Object = this.getPluginByName("LDAP");
                    if (yP_Object == null || !(yP_Object instanceof YP_Authentifiers)) {
                        this.logger(2, "authenticate() pb with ldap plugin :" + l);
                        return IdentificationLevelEnumeration.IMPOSSIBLE;
                    }
                    object2 = ((YP_Authentifiers)((Object)yP_Object)).authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
                } else {
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.getDataContainerBrandForUserAuthentication(userInfos, yP_Transaction);
                    if (yP_TCD_DCC_Brand != null) {
                        object2 = yP_TCD_DCC_Brand.authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
                    }
                }
            }
            if (object2 == null) {
                if (userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet.isEmpty() && userInfos.businessContainerSet.isEmpty()) {
                    this.logger(2, "authenticate() No access found for " + string);
                    return IdentificationLevelEnumeration.EMPTY_ACCESS;
                }
                this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.ERROR);
                return IdentificationLevelEnumeration.ERROR;
            }
            switch (YP_TCG_User.$SWITCH_TABLE$org$yp$framework$globalcomponents$authentifiers$YP_Authentifiers$AuthenticationResultEnumeration()[((Enum)object2).ordinal()]) {
                case 2: {
                    long l;
                    string4 = yP_Transaction.getDataContainerTransaction().userHandler.getUserToken();
                    if (string4 != null && !string4.isEmpty()) {
                        userInfos.userToken = string4;
                    } else {
                        object = new Random();
                        l = ((Random)object).nextLong();
                        if (l < 0L) {
                            l *= -1L;
                        }
                        userInfos.userToken = Long.toHexString(l);
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserToken(userInfos.userToken);
                    }
                    this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.PASSWORD);
                    if (userInfos.currentAttempt != 0) {
                        userInfos.userRow.set("currentAttempt", 0);
                    }
                    this.createNewUserRowIfNeeded(userInfos);
                    this.userHashMap.put(string, userInfos);
                    if (userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet.isEmpty() && userInfos.businessContainerSet.isEmpty()) {
                        this.logger(2, "authenticate() No access found for " + string);
                        return IdentificationLevelEnumeration.EMPTY_ACCESS;
                    }
                    if (userStatusEnumeration == UserStatusEnumeration.INITIAL) {
                        if (userInfos.userAccessLevel == 3 || userInfos.userAccessLevel == 4) {
                            String string5;
                            object = userInfos.userRow.getFieldStringValueByName("authPluginName");
                            if ((object == null || ((String)object).isEmpty()) && (l = ((Long)userInfos.userRow.getFieldValueByName("idLDAP")).longValue()) == 0L && (string5 = yP_Transaction.getDataContainerTransaction().commonHandler.getRequestAppTags()) != null && !string5.isEmpty()) {
                                try {
                                    TLVHandler tLVHandler = new TLVHandler(string5);
                                    TLV tLV = tLVHandler.getTLV(-538869478);
                                    if (tLV != null && TLVHandler.getBool(tLV.value)) {
                                        this.logger(4, "authenticate() password must be changed when GUI !!!: " + string);
                                        return IdentificationLevelEnumeration.EXPIRED_PASSWORD;
                                    }
                                }
                                catch (Exception exception) {
                                    this.logger(2, "authenticate()  ", exception);
                                }
                            }
                            userInfos.userRow.set("userStatus", UserStatusEnumeration.ACTIVE);
                            this.createNewUserRowIfNeeded(userInfos);
                        } else {
                            this.logger(4, "authenticate() password must be changed!!!: " + string);
                            return IdentificationLevelEnumeration.EXPIRED_PASSWORD;
                        }
                    }
                    return IdentificationLevelEnumeration.PASSWORD;
                }
                case 3: {
                    this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.EXPIRED_PASSWORD);
                    userInfos.userRow.set("currentAttempt", userInfos.currentAttempt + 1);
                    this.createNewUserRowIfNeeded(userInfos);
                    return IdentificationLevelEnumeration.EXPIRED_PASSWORD;
                }
                case 5: {
                    this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.FAILED);
                    userInfos.userRow.set("currentAttempt", userInfos.currentAttempt + 1);
                    this.createNewUserRowIfNeeded(userInfos);
                    return IdentificationLevelEnumeration.FAILED;
                }
            }
            this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.ERROR);
            return IdentificationLevelEnumeration.ERROR;
        }
        catch (Exception exception) {
            this.logger(2, "authenticate() login: " + string, exception);
            return IdentificationLevelEnumeration.ERROR;
        }
    }

    private UserInfos getUserInfos(YP_Transaction yP_Transaction, String string) {
        YP_Row yP_Row = this.extensionUser.getUserRowByLogin(string);
        if (yP_Row == null) {
            return null;
        }
        UserInfos userInfos = new UserInfos();
        return this.updateUserInfos(yP_Transaction, string, userInfos, yP_Row);
    }

    private UserInfos updateUserInfos(YP_Transaction yP_Transaction, String string, UserInfos userInfos) {
        YP_Row yP_Row = this.extensionUser.getUserRowByLogin(string);
        if (yP_Row == null) {
            return null;
        }
        return this.updateUserInfos(yP_Transaction, string, userInfos, yP_Row);
    }

    private UserInfos updateUserInfos(YP_Transaction yP_Transaction, String string, UserInfos userInfos, YP_Row yP_Row) {
        Object object;
        userInfos.userRow = yP_Row;
        userInfos.idUser = (Long)userInfos.userRow.getFieldValueByName("idUser");
        userInfos.father = (Long)userInfos.userRow.getFieldValueByName("idFather");
        userInfos.userLogin = string;
        userInfos.preferredLanguage = userInfos.userRow.getFieldStringValueByName("preferredLanguage");
        userInfos.userFirstName = userInfos.userRow.getFieldStringValueByName("firstName");
        userInfos.userLastName = userInfos.userRow.getFieldStringValueByName("lastName");
        userInfos.userAccessLevel = (Integer)userInfos.userRow.getFieldValueByName("accessLevel");
        userInfos.lastRequestTimestamp = userInfos.loginTimestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
        Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
        Timestamp timestamp2 = (Timestamp)userInfos.userRow.getFieldValueByName("tokenExpirationSystemTime");
        if (timestamp2.after(timestamp)) {
            userInfos.userToken = userInfos.userRow.getFieldStringValueByName("token");
        }
        userInfos.userPermanentToken = userInfos.userRow.getFieldStringValueByName("permanentToken");
        if (userInfos.userPermanentToken.isEmpty()) {
            object = new Random();
            long l = ((Random)object).nextLong();
            if (l < 0L) {
                l *= -1L;
            }
            userInfos.userPermanentToken = Long.toHexString(l);
            userInfos.userRow.set("permanentToken", userInfos.userPermanentToken);
        }
        yP_Transaction.getDataContainerTransaction().userHandler.setPermanentToken(userInfos.userPermanentToken);
        yP_Transaction.getDataContainerTransaction().userHandler.setUserIdentifier(userInfos.idUser);
        yP_Transaction.getDataContainerTransaction().userHandler.setUserFatherIdentifier(userInfos.father);
        yP_Transaction.getDataContainerTransaction().userHandler.setUserToken(userInfos.userToken);
        object = yP_Transaction.getDataContainerTransaction().userHandler.getUserPreferredLanguage();
        if (object == null || ((String)object).isEmpty()) {
            yP_Transaction.getDataContainerTransaction().userHandler.setUserPreferredLanguage(userInfos.preferredLanguage);
        } else if (!((String)object).contentEquals(userInfos.preferredLanguage)) {
            userInfos.userRow.set("preferredLanguage", (String)object);
            userInfos.preferredLanguage = object;
        }
        String string2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserFirstName();
        if (string2 == null || string2.isEmpty()) {
            yP_Transaction.getDataContainerTransaction().userHandler.setUserFirstName(userInfos.userFirstName);
        } else if (!string2.contentEquals(userInfos.userFirstName)) {
            userInfos.userRow.set("firstName", string2);
            userInfos.userFirstName = string2;
        }
        String string3 = yP_Transaction.getDataContainerTransaction().userHandler.getUserLastName();
        if (string3 == null || string3.isEmpty()) {
            yP_Transaction.getDataContainerTransaction().userHandler.setUserLastName(userInfos.userLastName);
        } else if (!string3.contentEquals(userInfos.userLastName)) {
            userInfos.userRow.set("lastName", string3);
            userInfos.userLastName = string3;
        }
        yP_Transaction.getDataContainerTransaction().userHandler.setUserAccessLevel(userInfos.userAccessLevel);
        userInfos.vadAllowed = (Boolean)userInfos.userRow.getFieldValueByName("vadAllowed");
        userInfos.merchantTicketAllowed = (Boolean)userInfos.userRow.getFieldValueByName("merchantTicketAllowed");
        userInfos.cashierCreationAllowed = (Boolean)userInfos.userRow.getFieldValueByName("cashierCreationAllowed");
        yP_Transaction.getDataContainerTransaction().userHandler.setVadAllowed(userInfos.vadAllowed);
        yP_Transaction.getDataContainerTransaction().userHandler.setMerchantTicketAllowed(userInfos.merchantTicketAllowed);
        yP_Transaction.getDataContainerTransaction().userHandler.setCashierCreationAllowed(userInfos.cashierCreationAllowed);
        userInfos.currentAttempt = (Integer)userInfos.userRow.getFieldValueByName("currentAttempt");
        if (userInfos.currentAttempt > 4) {
            this.logger(2, "User account blocked, too many tries for user :" + string + " getUserInfos()");
            userInfos.userRow.set("userStatus", UserStatusEnumeration.BLOCKED);
        }
        this.logger(4, "getUserInfos() user :" + string + " current try: " + userInfos.currentAttempt);
        userInfos.userParameters = this.extensionUser.getUserParameters(userInfos.idUser);
        return userInfos;
    }

    private IdentificationLevelEnumeration changePassword(YP_Transaction yP_Transaction, String string, String string2, String string3, StringBuilder stringBuilder) {
        try {
            Object object;
            if (this.getLogLevel() >= 4) {
                this.logger(4, "changePassword() authentication for: " + string);
            }
            this.userHashMap.remove(string);
            if (string2 == null || string2.isEmpty()) {
                this.logger(2, "changePassword() no password... for:" + string);
                return IdentificationLevelEnumeration.ERROR;
            }
            UserInfos userInfos = this.getUserInfos(yP_Transaction, string);
            if (userInfos == null) {
                return IdentificationLevelEnumeration.ACCOUNT_UNKNOWN;
            }
            UserStatusEnumeration userStatusEnumeration = (UserStatusEnumeration)((Object)userInfos.userRow.getFieldValueByName("userStatus"));
            if (userStatusEnumeration == null) {
                this.logger(2, "changePassword() no userStatus it's OK for now, but the DB must be updated for " + userInfos.userLogin);
            } else {
                switch (userStatusEnumeration) {
                    case ACTIVE: 
                    case INITIAL: {
                        break;
                    }
                    case INACTIVE: 
                    case BLOCKED: {
                        this.logger(2, "changePassword() account deactivated for " + userInfos.userLogin);
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.BLOCKED);
                        this.createNewUserRowIfNeeded(userInfos);
                        stringBuilder = stringBuilder.append("USER_ACCOUNT_BLOCKED");
                        return IdentificationLevelEnumeration.BLOCKED;
                    }
                    case DELETED: {
                        this.logger(2, "changePassword() account deleted for " + userInfos.userLogin);
                        return IdentificationLevelEnumeration.ERROR;
                    }
                    case UNKNOWN: {
                        this.logger(2, "changePassword() userStatus unknown, it's OK for now, but the DB must be updated for " + userInfos.userLogin);
                    }
                }
            }
            this.updateUserAccesContext(yP_Transaction, userInfos, false);
            YP_Authentifiers.AuthenticationResultEnumeration authenticationResultEnumeration = YP_Authentifiers.AuthenticationResultEnumeration.UNKNOWN;
            Object object2 = userInfos.userRow.getFieldStringValueByName("authPluginName");
            if (object2 != null && !object2.isEmpty()) {
                object = this.getPluginByName((String)object2);
                if (object == null || !(object instanceof YP_Authentifiers)) {
                    this.logger(2, "changePassword() pb with authentifier plugin :" + object2);
                    return IdentificationLevelEnumeration.IMPOSSIBLE;
                }
                authenticationResultEnumeration = ((YP_Authentifiers)object).authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
            } else {
                long l = (Long)userInfos.userRow.getFieldValueByName("idLDAP");
                if (l != 0L) {
                    YP_Object yP_Object = this.getPluginByName("LDAP");
                    if (yP_Object == null || !(yP_Object instanceof YP_Authentifiers)) {
                        this.logger(2, "changePassword() pb with ldap plugin :" + l);
                        return IdentificationLevelEnumeration.IMPOSSIBLE;
                    }
                    authenticationResultEnumeration = ((YP_Authentifiers)((Object)yP_Object)).authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
                } else {
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.getDataContainerBrandForUserAuthentication(userInfos, yP_Transaction);
                    if (yP_TCD_DCC_Brand != null) {
                        authenticationResultEnumeration = yP_TCD_DCC_Brand.authenticate(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
                    }
                }
            }
            switch (authenticationResultEnumeration) {
                case AUTHENTICATED: 
                case EXPIRED_PASSWORD: {
                    object2 = this.changePasswordByPlugin(yP_Transaction, string, string3, userInfos, stringBuilder);
                    if (object2 == IdentificationLevelEnumeration.PASSWORD) {
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.PASSWORD);
                        object = new Random();
                        long l = ((Random)object).nextLong();
                        if (l < 0L) {
                            l *= -1L;
                        }
                        userInfos.userToken = Long.toHexString(l);
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserToken(userInfos.userToken);
                        long l2 = ((Random)object).nextLong();
                        if (l2 < 0L) {
                            l2 *= -1L;
                        }
                        userInfos.userPermanentToken = Long.toHexString(l2);
                        yP_Transaction.getDataContainerTransaction().userHandler.setPermanentToken(userInfos.userPermanentToken);
                        userInfos.userRow.set("permanentToken", userInfos.userPermanentToken);
                        this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.PASSWORD);
                        if (userInfos.currentAttempt != 0) {
                            userInfos.userRow.set("currentAttempt", 0);
                        }
                        this.createNewUserRowIfNeeded(userInfos);
                        this.userHashMap.put(string, userInfos);
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "changePassword() change password successfully for: " + string);
                        }
                        return IdentificationLevelEnumeration.PASSWORD;
                    }
                    this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.FAILED);
                    return IdentificationLevelEnumeration.FAILED;
                }
                case WRONG_PASSWORD: {
                    this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.FAILED);
                    userInfos.userRow.set("currentAttempt", userInfos.currentAttempt + 1);
                    this.createNewUserRowIfNeeded(userInfos);
                    return IdentificationLevelEnumeration.FAILED;
                }
            }
            this.dataContainerStatus.updateUserStatus(yP_Transaction.getDataContainerTransaction(), IdentificationLevelEnumeration.ERROR);
            return IdentificationLevelEnumeration.ERROR;
        }
        catch (Exception exception) {
            this.logger(2, "changePassword() login: " + string, exception);
            return IdentificationLevelEnumeration.ERROR;
        }
    }

    private IdentificationLevelEnumeration resetPassword(YP_Transaction yP_Transaction, String string, StringBuilder stringBuilder) {
        try {
            this.logger(4, "resetPassword() for: " + string);
            this.userHashMap.remove(string);
            UserInfos userInfos = this.getUserInfos(yP_Transaction, string);
            if (userInfos == null) {
                this.logger(2, "resetPassword() Account unknown : " + string);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(64));
                return IdentificationLevelEnumeration.ACCOUNT_UNKNOWN;
            }
            if (userInfos.userAccessLevel == 1) {
                this.logger(2, "resetPassword() is not for admin " + userInfos.userLogin);
                stringBuilder = stringBuilder.append("Not allowed");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return IdentificationLevelEnumeration.ERROR;
            }
            UserStatusEnumeration userStatusEnumeration = (UserStatusEnumeration)((Object)userInfos.userRow.getFieldValueByName("userStatus"));
            if (userStatusEnumeration == null) {
                this.logger(2, "resetPassword() no userStatus for " + userInfos.userLogin);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return IdentificationLevelEnumeration.ERROR;
            }
            switch (userStatusEnumeration) {
                case ACTIVE: 
                case INITIAL: {
                    break;
                }
                case BLOCKED: {
                    break;
                }
                case INACTIVE: {
                    this.logger(2, "resetPassword() account inactive for " + userInfos.userLogin);
                    stringBuilder = stringBuilder.append("USER_ACCOUNT_BLOCKED");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(61));
                    return IdentificationLevelEnumeration.BLOCKED;
                }
                case DELETED: {
                    this.logger(2, "resetPassword() account deleted for " + userInfos.userLogin);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return IdentificationLevelEnumeration.ERROR;
                }
                case UNKNOWN: {
                    this.logger(2, "resetPassword() userStatus unknown for " + userInfos.userLogin);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return IdentificationLevelEnumeration.ERROR;
                }
                default: {
                    this.logger(2, "resetPassword() unknown userStatus for " + userInfos.userLogin);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return IdentificationLevelEnumeration.ERROR;
                }
            }
            this.updateUserAccesContext(yP_Transaction, userInfos, false);
            String string2 = userInfos.userRow.getFieldStringValueByName("authPluginName");
            if (string2 != null && !string2.isEmpty()) {
                this.logger(2, "resetPassword() not done for " + string2);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return IdentificationLevelEnumeration.ERROR;
            }
            long l = (Long)userInfos.userRow.getFieldValueByName("idUser");
            yP_Transaction.getDataContainerTransaction().userHandler.setUserIdentifier(l);
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.getDataContainerBrandForUserAuthentication(userInfos, yP_Transaction);
            if (yP_TCD_DCC_Brand == null) {
                this.logger(2, "resetPassword() no brand found");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return IdentificationLevelEnumeration.ERROR;
            }
            String string3 = yP_TCD_DCC_Brand.resetUser(userInfos.userRow, string);
            if (string3 == null || string3.isEmpty()) {
                this.logger(2, "resetPassword() new password not generated");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return IdentificationLevelEnumeration.ERROR;
            }
            if (YP_TCG_Mailer.sendTemporaryPasswordByMail(yP_Transaction, yP_Transaction, userInfos.userRow, string3) < 0) {
                this.logger(2, "resetPassword() mail not sent");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return IdentificationLevelEnumeration.ERROR;
            }
            userInfos.userRow.set("userStatus", UserStatusEnumeration.INITIAL);
            userInfos.userRow.set("currentAttempt", 0);
            userInfos.userRow.persist();
            return IdentificationLevelEnumeration.UNKNOWN;
        }
        catch (Exception exception) {
            this.logger(2, "resetPassword()  login: " + string, exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return IdentificationLevelEnumeration.ERROR;
        }
    }

    private IdentificationLevelEnumeration changePasswordByPlugin(YP_Transaction yP_Transaction, String string, String string2, UserInfos userInfos, StringBuilder stringBuilder) {
        try {
            boolean bl = false;
            String string3 = userInfos.userRow.getFieldStringValueByName("authPluginName");
            if (string3 != null && !string3.isEmpty()) {
                YP_Object yP_Object = this.getPluginByName(string3);
                if (yP_Object == null || !(yP_Object instanceof YP_Authentifiers)) {
                    this.logger(2, "changePasswordByPlugin() pb with auth plugin :" + string3);
                    return IdentificationLevelEnumeration.IMPOSSIBLE;
                }
                bl = ((YP_Authentifiers)((Object)yP_Object)).changePassword(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
            } else {
                long l = (Long)userInfos.userRow.getFieldValueByName("idLDAP");
                if (l != 0L) {
                    YP_Object yP_Object = this.getPluginByName("LDAP");
                    if (yP_Object == null || !(yP_Object instanceof YP_Authentifiers)) {
                        this.logger(2, "changePasswordByPlugin() pb with ldap plugin :" + l);
                        return IdentificationLevelEnumeration.IMPOSSIBLE;
                    }
                    bl = ((YP_Authentifiers)((Object)yP_Object)).changePassword(yP_Transaction.getDataContainerTransaction(), userInfos.userRow, string, string2, stringBuilder);
                } else {
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.getDataContainerBrandForUserAuthentication(userInfos, yP_Transaction);
                    if (yP_TCD_DCC_Brand == null) {
                        this.logger(2, "changePasswordByPlugin() pb with auth plugin :" + string3);
                        return IdentificationLevelEnumeration.IMPOSSIBLE;
                    }
                    bl = yP_TCD_DCC_Brand.changePassword(userInfos.userRow, string, string2, stringBuilder);
                }
            }
            if (bl) {
                userInfos.userRow.set("userStatus", UserStatusEnumeration.ACTIVE);
                this.createNewUserRowIfNeeded(userInfos);
                this.userHashMap.put(string, userInfos);
                if (userInfos.brandContainerSet.isEmpty() && userInfos.merchantContainerSet.isEmpty() && userInfos.businessContainerSet.isEmpty()) {
                    this.logger(2, "changePasswordByPlugin() No access found for " + string);
                    return IdentificationLevelEnumeration.EMPTY_ACCESS;
                }
                return IdentificationLevelEnumeration.PASSWORD;
            }
            return IdentificationLevelEnumeration.FAILED;
        }
        catch (Exception exception) {
            this.logger(2, "changePasswordByPlugin()  ", exception);
            return IdentificationLevelEnumeration.ERROR;
        }
    }

    private boolean logout(YP_Transaction yP_Transaction, String string) {
        try {
            return this.userHashMap.remove(string) != null;
        }
        catch (Exception exception) {
            this.logger(2, "logout() ", exception);
            return false;
        }
    }

    private int flushUser() {
        try {
            Timestamp timestamp = UtilsYP.isMoroccoServer() ? new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() - 2700000L) : new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() - 30600000L);
            Iterator<Map.Entry<String, UserInfos>> iterator = this.userHashMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, UserInfos> entry = iterator.next();
                UserInfos userInfos = entry.getValue();
                if (!userInfos.lastRequestTimestamp.before(timestamp)) continue;
                iterator.remove();
            }
            return 1;
        }
        catch (ConcurrentModificationException concurrentModificationException) {
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "flushUser() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "authenticate": {
                    if (objectArray == null || objectArray.length != 4 || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameters for authenticate");
                        return null;
                    }
                    if (objectArray[1] == null && objectArray[2] == null) {
                        this.logger(2, "dealRequest() bad parameters for authenticate");
                        return null;
                    }
                    if (objectArray[1] == null && !(objectArray[2] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameters for authenticate");
                        return null;
                    }
                    if (objectArray[2] == null && !(objectArray[1] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameters for authenticate");
                        return null;
                    }
                    if (!(objectArray[3] instanceof StringBuilder)) {
                        this.logger(2, "dealRequest() bad parameters for authenticate");
                        return null;
                    }
                    if (!(yP_Object instanceof YP_Transaction)) {
                        this.logger(2, "dealRequest() caller must be a transaction");
                        return null;
                    }
                    return this.authenticate((YP_Transaction)yP_Object, (String)objectArray[0], (String)objectArray[1], (String)objectArray[2], (StringBuilder)objectArray[3]);
                }
                case "changePassword": {
                    if (!(objectArray != null && objectArray.length == 4 && objectArray[0] instanceof String && objectArray[1] instanceof String && objectArray[2] instanceof String && objectArray[3] instanceof StringBuilder)) {
                        this.logger(2, "dealRequest() bad parameters for changePassword");
                        return null;
                    }
                    if (!(yP_Object instanceof YP_Transaction)) {
                        this.logger(2, "dealRequest() caller must be a transaction");
                        return null;
                    }
                    return this.changePassword((YP_Transaction)yP_Object, (String)objectArray[0], (String)objectArray[1], (String)objectArray[2], (StringBuilder)objectArray[3]);
                }
                case "resetPassword": {
                    if (objectArray == null || objectArray.length != 2 || !(objectArray[0] instanceof String) || !(objectArray[1] instanceof StringBuilder)) {
                        this.logger(2, "dealRequest() bad parameters for resetPassword");
                        return null;
                    }
                    if (!(yP_Object instanceof YP_Transaction)) {
                        this.logger(2, "dealRequest() caller must be a transaction");
                        return null;
                    }
                    return this.resetPassword((YP_Transaction)yP_Object, (String)objectArray[0], (StringBuilder)objectArray[1]);
                }
                case "logout": {
                    if (objectArray == null || objectArray.length != 1 || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameters for logout");
                        return null;
                    }
                    if (!(yP_Object instanceof YP_Transaction)) {
                        this.logger(2, "dealRequest() caller must be a transaction");
                        return null;
                    }
                    return this.logout((YP_Transaction)yP_Object, (String)objectArray[0]);
                }
                case "flushUser": {
                    return this.flushUser();
                }
                case "archiveUser": {
                    return this.extensionUser.archiveUser();
                }
                case "getUserRowByID": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof Long) {
                        return this.extensionUser.getUserRowByID((Long)objectArray[0]);
                    }
                    this.logger(2, "dealRequest() bad parameters for getUserRowByID");
                    return null;
                }
                case "getUserRowByLogin": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.extensionUser.getUserRowByLogin((String)objectArray[0]);
                    }
                    this.logger(2, "dealRequest() bad parameters for getUserRowByLogin");
                    return null;
                }
                case "updateUserAccesContext": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.updateUserAccesContext((String)objectArray[0]);
                    }
                    this.logger(2, "dealRequest() bad parameters for updateUserAccesContext");
                    return null;
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Brand getDataContainerBrandForUserAuthentication(UserInfos userInfos, YP_Transaction yP_Transaction) {
        Object object2;
        if (userInfos.userAccessLevel == 1) {
            for (Object object2 : userInfos.brandContainerSet) {
                if (!((YP_Object)object2).getContractIdentifier().contentEquals("YouPay") && userInfos.brandContainerSet.size() != 1) continue;
                return object2;
            }
        }
        if (userInfos.brandContainerSet != null && !userInfos.brandContainerSet.isEmpty()) {
            object2 = (YP_TCD_DCC_Brand)userInfos.brandContainerSet.toArray()[0];
            for (Object object3 : userInfos.brandContainerSet) {
                if (((YP_TCD_DCC_Brand)object3).getIDBrand() >= ((YP_TCD_DCC_Brand)object2).getIDBrand()) continue;
                object2 = object3;
            }
            return object2;
        }
        if (userInfos.merchantContainerSet != null && !userInfos.merchantContainerSet.isEmpty()) {
            object2 = ((YP_TCD_DCC_Merchant)userInfos.merchantContainerSet.toArray()[0]).getDataContainerBrand();
            for (Object object3 : userInfos.merchantContainerSet) {
                if (((YP_TCD_DCC_Merchant)object3).getDataContainerBrand().getIDBrand() >= ((YP_TCD_DCC_Brand)object2).getIDBrand()) continue;
                object2 = ((YP_TCD_DCC_Merchant)object3).getDataContainerBrand();
            }
            return object2;
        }
        if (userInfos.businessContainerSet != null && !userInfos.businessContainerSet.isEmpty()) {
            object2 = ((YP_TCD_DCC_Business)userInfos.businessContainerSet.toArray()[0]).getDataContainerBrand();
            for (Object object3 : userInfos.businessContainerSet) {
                if (((YP_TCD_DCC_Business)object3).getDataContainerBrand().getIDBrand() == ((YP_TCD_DCC_Brand)object2).getIDBrand()) continue;
                this.logger(2, "getDataContainerBrandForUserAuthentication() Different brands for " + userInfos.userLogin);
            }
            return object2;
        }
        this.logger(2, "getDataContainerBrandForUserAuthentication() debug log to see if it is possible for " + userInfos.userLogin);
        object2 = yP_Transaction.getContractIdentifier();
        if (!((String)object2).contentEquals("KERNEL")) {
            return yP_Transaction.getDataContainerTransaction().getDataContainerBrand();
        }
        this.logger(2, "getDataContainerBrandForUserAuthentication() not found for" + userInfos.userLogin);
        return null;
    }

    private class UserInfos {
        long idUser;
        long father;
        int userAccessLevel;
        int currentAttempt;
        YP_Row userRow;
        String userLogin;
        String userFirstName;
        String userLastName;
        String userToken;
        String userPermanentToken;
        String preferredLanguage;
        List<YP_Row> userParameters;
        Timestamp loginTimestamp;
        Timestamp lastRequestTimestamp;
        Boolean vadAllowed;
        Boolean merchantTicketAllowed;
        Boolean cashierCreationAllowed;
        private final Set<YP_TCD_DCC_Group> groupContainerSet = new HashSet<YP_TCD_DCC_Group>();
        private final Set<YP_TCD_DCC_Brand> brandContainerSet = new HashSet<YP_TCD_DCC_Brand>();
        private final Set<YP_TCD_DCC_Merchant> merchantContainerSet = new HashSet<YP_TCD_DCC_Merchant>();
        private final Set<YP_TCD_DCC_Business> businessContainerSet = new HashSet<YP_TCD_DCC_Business>();
        private final Map<YP_TCD_DCC_Merchant, List<YP_Row>> storeMap = new HashMap<YP_TCD_DCC_Merchant, List<YP_Row>>();
        private String uniqueAccessToStoreIdentifier;

        private UserInfos() {
        }
    }
}

