/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public class YP_TCG_View_Session
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Session(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Session";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "createEmptyView() error while retrieving Session DAO");
            return null;
        }
        block8: for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
            Field field;
            String string;
            String string2;
            block22: {
                block25: {
                    block24: {
                        block23: {
                            block21: {
                                string2 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                                string = this.getLabel(dAO_ViewColumn.idLabel, string2);
                                field = yP_TCD_DesignAccesObject.getFieldByName(string2);
                                if (field == null) break block21;
                                yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
                                break block22;
                            }
                            field = this.dataContainerTechnique.contract.getFieldByName(string2);
                            if (field == null) break block23;
                            yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.contract;
                            break block22;
                        }
                        field = this.dataContainerTechnique.merchant.getFieldByName(string2);
                        if (field == null) break block24;
                        yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.merchant;
                        break block22;
                    }
                    field = this.dataContainerTechnique.brand.getFieldByName(string2);
                    if (field == null) break block25;
                    yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.brand;
                    break block22;
                }
                switch (string2) {
                    case "debitAmountFormated": 
                    case "refundAmountFormated": 
                    case "reversalAmountFormated": {
                        yP_View.addCustomColumn(string2, string, "string", dAO_ViewColumn.defaultRank);
                        yP_TCD_DesignAccesObject2 = null;
                        break;
                    }
                    default: {
                        this.logger(2, "createEmptyView() unknown column:" + string2);
                        continue block8;
                    }
                }
            }
            if (yP_TCD_DesignAccesObject2 != null && yP_View.addColumn(string2, string, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string2);
            }
            if (yP_View.getColumnFormat(string2).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string2, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string2, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string2).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string2).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string2).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * Could not resolve type clashes
     * Unable to fully structure code
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        var6_5 = this.createEmptyView(var1_1, var2_2, var3_3, var5_4);
        if (var6_5 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        var7_6 = var2_2.getDataContainerTransaction().getProtocolEFT();
        if (var7_6 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(var7_6 instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        var8_7 = (YP_PROT_IHM)var7_6;
        var9_8 = var8_7.getMaxRecords();
        if (var9_8 == 0) {
            return var6_5;
        }
        if (var9_8 < 0) {
            var9_8 = 1000;
        }
        ++var9_8;
        var10_9 = var8_7.getStartIndex();
        if (var10_9 < 0) {
            var10_9 = 0;
        }
        var11_10 = var8_7.getSearchGabarit();
        var12_11 = null;
        var13_12 = new YP_ComplexGabarit(this.getDAO(var1_1, var2_2, null));
        var14_13 = 0L;
        if (var11_10 != null && !var11_10.isEmpty()) {
            for (Object var16_15 : var11_10) {
                try {
                    if (var16_15.fullTableName != null) {
                        var12_11 = this.getDAO(var1_1, var2_2, var16_15.fullTableName);
                        if (var16_15.fieldName.contentEquals("idSession") && var16_15.objectTosearch != null && var16_15.objectTosearch instanceof Long && var16_15.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                            var14_13 = (Long)var16_15.objectTosearch;
                        }
                    }
                    if (var16_15.objectTosearch == null) {
                        var13_12.set(var16_15.fieldName, var16_15.operator);
                        continue;
                    }
                    var6_5.dealEnumColumn((YP_Gabarit)var16_15);
                    if (var16_15.objectTosearch == null) continue;
                    var13_12.set(var16_15.fieldName, var16_15.operator, var16_15.objectTosearch);
                }
                catch (Exception var18_16) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView()  " + var18_16);
                }
            }
        }
        if (!var13_12.isOrdered) {
            var13_12.set("sessionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        }
        var16_15 = new HashMap<K, V>();
        if (var14_13 > 0L) {
            var18_17 = var12_11.getRowByPrimaryKey(var14_13);
            if (var18_17 == null) {
                this.logger(2, "getView() null");
                return var6_5;
            }
            var17_14 = new ArrayList<E>();
            var17_14.add((YP_Row)var18_17);
            var19_19 = (YP_TCD_DCC_Business)((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).dealRequest(this, "getDataContainer", new Object[]{var18_17.getFieldStringValueByName("applicationIdentifier")});
            if (var19_19 == null) {
                this.logger(2, "getView() dataContainerBusiness null");
                return var6_5;
            }
            var16_15.put(var19_19.getContractIdentifier(), var19_19);
        } else {
            var18_17 = var2_2.getApplicationList();
            if (var18_17 == null) {
                this.logger(2, "getView() error while retrieving applicationList");
                return var6_5;
            }
            if (var18_17.isEmpty()) {
                this.logger(3, "getView() no application List");
                return var6_5;
            }
            var19_19 = new ArrayList<String>();
            for (Object var20_22 : var18_17) {
                var19_19.add(var20_22.getContractIdentifier());
            }
            var20_22 = new HashSet<E>();
            for (Object var21_21 : var18_17) {
                var20_22.add(var21_21.getDataContainerBrand());
            }
            for (Object var21_21 : var18_17) {
                var16_15.put(var21_21.getContractIdentifier(), var21_21);
            }
            if (var12_11 != null) {
                if (var19_19.size() < 100) {
                    var13_12.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.IN, var19_19);
                } else {
                    var13_12.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.START_WITH, String.valueOf(var12_11.getDataContainerContext().getContractIdentifier()) + "_");
                }
                var17_14 = var12_11.getRowListSuchAs(0, 1000, new YP_ComplexGabarit[]{var13_12});
            } else {
                var21_21 = new ArrayList<YP_Row>();
                var23_24 = var20_22.iterator();
                while (var23_24.hasNext()) {
                    var22_23 = (YP_TCD_DCC_Brand)var23_24.next();
                    var24_25 = new ArrayList<String>();
                    for (Object var25_26 : var18_17) {
                        if (var25_26.getDataContainerBrand() != var22_23) continue;
                        var24_25.add(var25_26.getContractIdentifier());
                    }
                    if (var19_19.size() < 100) {
                        var13_12.reset("applicationIdentifier", YP_ComplexGabarit.OPERATOR.IN, var24_25);
                    } else {
                        var13_12.reset("applicationIdentifier", YP_ComplexGabarit.OPERATOR.START_WITH, String.valueOf(var22_23.getBrandName()) + "_");
                    }
                    var25_26 = var22_23.session.getRowListSuchAs(0, 1000, new YP_ComplexGabarit[]{var13_12});
                    if (var25_26 == null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "getView() null list");
                        }
                        return null;
                    }
                    var21_21.addAll(var25_26);
                }
                var17_14 = var13_12.order((List<YP_Row>)var21_21);
            }
        }
        if (var17_14.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(4, "getView() nothing found");
            }
            return var6_5;
        }
        var18_18 = -1;
        var19_20 = 0;
        while (var19_20 < var17_14.size()) {
            block56: {
                block55: {
                    var20_22 = var17_14.get(var19_20);
                    var21_21 = var20_22.getFieldStringValueByName("applicationIdentifier");
                    var22_23 = (YP_TCD_DCC_Business)var16_15.get(var21_21);
                    if (var22_23 != null) break block55;
                    this.logger(3, "getView() DC not found for " + (String)var21_21);
                    break block56;
                }
                ++var18_18;
                var23_24 = var22_23.getContractRow();
                var24_25 = var22_23.getDataContainerMerchant();
                var25_26 = var24_25.getMerchantRow();
                var26_27 = var24_25.getDataContainerBrand();
                var27_28 = var26_27.getBrandRow();
                var6_5.setRowID(var18_18, String.valueOf(var20_22.getFather().getFullTableName()) + "#" + var20_22.getPrimaryKeyName() + "#" + var20_22.getPrimaryKey());
                var6_5.setRowActionable(var18_18, true);
                if (var17_14.size() == 1 && (var28_29 = var26_27.getActionList(this.toString(), (YP_Row)var20_22)) != null) {
                    var6_5.setRowActionList(var18_18, (List<YP_TCD_DC_Context.Action>)var28_29);
                }
                for (Object var28_29 : var5_4) {
                    block60: {
                        block59: {
                            block58: {
                                block57: {
                                    var30_31 = YP_Row.getStringValue(var28_29.columnName);
                                    var31_32 = null;
                                    var32_33 = var20_22.getFieldByName(var30_31);
                                    if (var32_33 == null) break block57;
                                    var31_32 = var20_22;
                                    ** GOTO lbl-1000
                                }
                                var32_33 = this.dataContainerTechnique.contract.getFieldByName(var30_31);
                                if (var32_33 == null) break block58;
                                var31_32 = var23_24;
                                ** GOTO lbl-1000
                            }
                            var32_33 = this.dataContainerTechnique.merchant.getFieldByName(var30_31);
                            if (var32_33 == null) break block59;
                            var31_32 = var25_26;
                            ** GOTO lbl-1000
                        }
                        var32_33 = this.dataContainerTechnique.brand.getFieldByName(var30_31);
                        if (var32_33 == null) break block60;
                        var31_32 = var27_28;
                        ** GOTO lbl-1000
                    }
                    var33_34 = var30_31;
                    tmp = -1;
                    switch (var33_34.hashCode()) {
                        case -1850272934: {
                            if (var33_34.equals("debitAmountFormated")) {
                                tmp = 1;
                            }
                            break;
                        }
                        case 281213158: {
                            if (var33_34.equals("refundAmountFormated")) {
                                tmp = 2;
                            }
                            break;
                        }
                        case 2133210172: {
                            if (var33_34.equals("reversalAmountFormated")) {
                                tmp = 3;
                            }
                            break;
                        }
                    }
                    switch (tmp) {
                        case 1: {
                            this.addOneAmount(var6_5, (YP_Row)var20_22, var18_18, var30_31, (Long)var20_22.getFieldValueByName("totalAmountDebit"));
                            break;
                        }
                        case 2: {
                            this.addOneAmount(var6_5, (YP_Row)var20_22, var18_18, var30_31, (Long)var20_22.getFieldValueByName("totalAmountRefund"));
                            break;
                        }
                        case 3: {
                            this.addOneAmount(var6_5, (YP_Row)var20_22, var18_18, var30_31, (Long)var20_22.getFieldValueByName("totalAmountReversalDebit"));
                            break;
                        }
                        default: lbl-1000:
                        // 5 sources

                        {
                            if (var32_33 != null && var31_32 != null) {
                                this.addFieldValue(var6_5, var32_33, (YP_Row)var31_32, var30_31, var18_18);
                                break;
                            }
                            this.logger(2, "getView() unknown column:" + var30_31);
                        }
                    }
                }
            }
            ++var19_20;
        }
        return var6_5;
    }

    void addOneAmount(YP_View yP_View, YP_Row yP_Row, int n, String string, long l) {
        try {
            int n2 = (Integer)yP_Row.getFieldValueByName("currencyFraction");
            String string2 = yP_Row.getFieldStringValueByName("currencyAlphabeticalCode");
            if (string2 != null && string2.contentEquals("EUR")) {
                string2 = "\u20ac";
            }
            if (l != 0L || n2 != 0 || !string2.isEmpty()) {
                String string3 = String.valueOf(UtilsYP.formatAmount(l, n2, Locale.FRANCE)) + " " + string2;
                yP_View.addFieldValue(n, string, string3);
            }
        }
        catch (Exception exception) {
            this.logger(3, "getView() Exception while formating amount ", exception);
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = null;
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Session");
            if (yP_TCD_DesignAccesObject2 == null || string != null && !yP_TCD_DesignAccesObject2.getFullTableName().startsWith(string)) continue;
            if (yP_TCD_DesignAccesObject == null) {
                yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
                continue;
            }
            if (yP_TCD_DesignAccesObject2.getExtensionList() == null || yP_TCD_DesignAccesObject2.getExtensionList().isEmpty() || yP_TCD_DesignAccesObject.getExtensionList() != null && yP_TCD_DesignAccesObject.getExtensionList().size() >= yP_TCD_DesignAccesObject2.getExtensionList().size()) continue;
            yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
        }
        if (yP_TCD_DesignAccesObject != null) {
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving Session DAO");
        }
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", action.applicationIdentifier);
        if (yP_TCD_DCC_Brand == null) {
            return -1;
        }
        return yP_TCD_DCC_Brand.executeAction(yP_Transaction, this.toString(), yP_Row, action);
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        this.logger(2, "createInView() Not yet done");
        return 0;
    }
}

