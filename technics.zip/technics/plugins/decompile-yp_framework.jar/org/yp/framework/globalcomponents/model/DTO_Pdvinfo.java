/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;
import org.yp.framework.globalcomponents.model.DTO_Agence;
import org.yp.framework.globalcomponents.model.DTO_ModePayment;
import org.yp.framework.globalcomponents.model.DTO_Ville;

public class DTO_Pdvinfo {
    @SerializedName(value="agence")
    private DTO_Agence agence = null;
    @SerializedName(value="codePdv")
    private String codePdv = null;
    @SerializedName(value="designationPdv")
    private String designationPdv = null;
    @SerializedName(value="numeroPdv")
    private Integer numeroPdv = null;
    @SerializedName(value="statut")
    private String statut = null;
    @SerializedName(value="ville")
    private DTO_Ville ville = null;
    @SerializedName(value="modepayementPdv")
    private DTO_ModePayment modepayementPdv = null;

    public DTO_Pdvinfo agence(DTO_Agence dTO_Agence) {
        this.agence = dTO_Agence;
        return this;
    }

    public DTO_Agence getAgence() {
        return this.agence;
    }

    public void setAgence(DTO_Agence dTO_Agence) {
        this.agence = dTO_Agence;
    }

    public DTO_Pdvinfo codePdv(String string) {
        this.codePdv = string;
        return this;
    }

    public String getCodePdv() {
        return this.codePdv;
    }

    public void setCodePdv(String string) {
        this.codePdv = string;
    }

    public DTO_Pdvinfo designationPdv(String string) {
        this.designationPdv = string;
        return this;
    }

    public String getDesignationPdv() {
        return this.designationPdv;
    }

    public void setDesignationPdv(String string) {
        this.designationPdv = string;
    }

    public DTO_Pdvinfo numeroPdv(Integer n) {
        this.numeroPdv = n;
        return this;
    }

    public Integer getNumeroPdv() {
        return this.numeroPdv;
    }

    public void setNumeroPdv(Integer n) {
        this.numeroPdv = n;
    }

    public DTO_Pdvinfo statut(String string) {
        this.statut = string;
        return this;
    }

    public String getStatut() {
        return this.statut;
    }

    public void setStatut(String string) {
        this.statut = string;
    }

    public DTO_Pdvinfo ville(DTO_Ville dTO_Ville) {
        this.ville = dTO_Ville;
        return this;
    }

    public DTO_Ville getVille() {
        return this.ville;
    }

    public void setVille(DTO_Ville dTO_Ville) {
        this.ville = dTO_Ville;
    }

    public DTO_ModePayment getModepayementPdv() {
        return this.modepayementPdv;
    }

    public void setModepayementPdv(DTO_ModePayment dTO_ModePayment) {
        this.modepayementPdv = dTO_ModePayment;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Pdvinfo dTO_Pdvinfo = (DTO_Pdvinfo)object;
        return Objects.equals(this.agence, dTO_Pdvinfo.agence) && Objects.equals(this.codePdv, dTO_Pdvinfo.codePdv) && Objects.equals(this.designationPdv, dTO_Pdvinfo.designationPdv) && Objects.equals(this.numeroPdv, dTO_Pdvinfo.numeroPdv) && Objects.equals(this.statut, dTO_Pdvinfo.statut) && Objects.equals(this.ville, dTO_Pdvinfo.ville) && Objects.equals(this.modepayementPdv, dTO_Pdvinfo.modepayementPdv);
    }

    public int hashCode() {
        return Objects.hash(this.agence, this.codePdv, this.designationPdv, this.numeroPdv, this.statut, this.ville, this.modepayementPdv);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class PdvinfoDto {\n");
        stringBuilder.append("    agence: ").append(this.toIndentedString(this.agence)).append("\n");
        stringBuilder.append("    codePdv: ").append(this.toIndentedString(this.codePdv)).append("\n");
        stringBuilder.append("    designationPdv: ").append(this.toIndentedString(this.designationPdv)).append("\n");
        stringBuilder.append("    numeroPdv: ").append(this.toIndentedString(this.numeroPdv)).append("\n");
        stringBuilder.append("    statut: ").append(this.toIndentedString(this.statut)).append("\n");
        stringBuilder.append("    ville: ").append(this.toIndentedString(this.ville)).append("\n");
        stringBuilder.append("    modepayementPdv: ").append(this.toIndentedString(this.modepayementPdv)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

