/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;

public class YP_TCG_View_Initialization
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Initialization(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Initialization";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_Row yP_Row;
        YP_View yP_View;
        block16: {
            List<YP_TCD_DCC_Business> list2;
            block15: {
                block14: {
                    block13: {
                        yP_View = new YP_View(this);
                        list2 = yP_Transaction.getApplicationList();
                        if (list2 != null) break block13;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createEmptyView() no application List");
                        }
                        return null;
                    }
                    if (!list2.isEmpty()) break block14;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createEmptyView() application List empty");
                    }
                    return null;
                }
                if (list2.size() == 1) break block15;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "createEmptyView() only one application at a time...");
                }
                return null;
            }
            YP_TCD_DCC_Business yP_TCD_DCC_Business = list2.get(0);
            yP_Row = yP_TCD_DCC_Business.getInitialisationRow();
            if (yP_Row != null) break block16;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() should not occur");
            }
            return null;
        }
        try {
            Field[] fieldArray = yP_Row.getFieldList();
            Field field = yP_Row.getPrimaryKeyField();
            Field[] fieldArray2 = fieldArray;
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field2 = fieldArray2[n2];
                if (field != field2) {
                    String string = field2.getName();
                    String string2 = this.getLabel(string);
                    yP_View.addColumn(string, string2, yP_Row.getFather(), field2, yP_Row.getColumnIndex(field2));
                    yP_View.getColumnProperties(string).put("writeAllowed", "1");
                }
                ++n2;
            }
            return yP_View;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() " + exception);
            }
            return null;
        }
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_Row yP_Row;
        YP_View yP_View;
        block27: {
            List<YP_TCD_DCC_Business> list2;
            block26: {
                block25: {
                    block24: {
                        YP_TCD_PosProtocol yP_TCD_PosProtocol;
                        block23: {
                            block22: {
                                block21: {
                                    yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
                                    if (yP_View != null) break block21;
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "getView() ");
                                    }
                                    return null;
                                }
                                yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
                                if (yP_TCD_PosProtocol != null) break block22;
                                this.logger(2, "getView() No protocol...");
                                return null;
                            }
                            if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block23;
                            this.logger(2, "getView() bad interface");
                            return null;
                        }
                        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                        int n = yP_PROT_IHM.getMaxRecords();
                        if (n == 0) {
                            return yP_View;
                        }
                        if (n < 0) {
                            n = 1000;
                        }
                        ++n;
                        int n2 = yP_PROT_IHM.getStartIndex();
                        if (n2 < 0) {
                            n2 = 0;
                        } else {
                            n += n2;
                        }
                        list2 = yP_Transaction.getApplicationList();
                        if (list2 != null) break block24;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "getView() no application List");
                        }
                        return null;
                    }
                    if (!list2.isEmpty()) break block25;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() application List empty");
                    }
                    return null;
                }
                if (list2.size() == 1) break block26;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() only one application at a time...");
                }
                return null;
            }
            YP_TCD_DCC_Business yP_TCD_DCC_Business = list2.get(0);
            yP_Row = yP_TCD_DCC_Business.getInitialisationRow();
            if (yP_Row != null) break block27;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() should not occur");
            }
            return null;
        }
        try {
            Field[] fieldArray = yP_Row.getFieldList();
            yP_View.setRowID(0, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            yP_View.setRowActionable(0, false);
            Field field = yP_Row.getPrimaryKeyField();
            Field[] fieldArray2 = fieldArray;
            int n = fieldArray.length;
            int n3 = 0;
            while (n3 < n) {
                Field field2 = fieldArray2[n3];
                if (field != field2) {
                    String string = field2.getName();
                    yP_View.addFieldValue(0, string, yP_Row.getFieldStringValue(field2));
                }
                ++n3;
            }
            return yP_View;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() " + exception);
            }
            return null;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (true) {
                if (n >= yP_View.size()) {
                    return 1;
                }
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Key must not be set !");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                List<YP_TCD_DCC_Business> list2 = yP_Transaction.getApplicationList();
                if (list2 == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() no application List");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (list2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() application List empty");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (list2.size() > 1) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() more than one dataContainer");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = list2.get((int)0).initialisationParameters;
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() not really possible !!!");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                yP_TCD_DesignAccesObject.deleteRows(false);
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                Iterator<String> iterator = yP_View.getColumnSet().iterator();
                while (true) {
                    if (!iterator.hasNext()) {
                        if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) >= 0) break;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() Not able to add row...");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    String string2 = iterator.next();
                    String string3 = yP_View.getFieldValueAt(n, string2);
                    if (string3 == null) continue;
                    yP_Row.set(string2, string3);
                }
                if (yP_TCD_DesignAccesObject.persist() < 0) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Not able to save changes...");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                ++n;
            }
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createInView() " + exception);
            }
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }
}

