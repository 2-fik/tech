/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.designaccesobjects.brand.DAO_ContractInsideStore;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.StoreStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_Store
extends YP_TCG_View {
    private static final String ASSIGN_STORE_CONTRACTS = "assignStoreContracts";
    private static final String DELETE_STORE_CONTRACTS = "deleteStoreContracts";
    private static final String IDBRAND_PROPERTY_NAME = "IDBRAND";
    private static final String IDSTORE_PROPERTY_NAME = "IDSTORE";
    private static final String LABEL_FIELD = "LABEL_FIELD";
    private static final String CHECKBOX_FIELD = "CHECKBOX_FIELD";
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration;

    public YP_TCG_View_Store(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Store";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            return null;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.brand;
                    } else if (string.contentEquals("Needed???")) {
                        yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                        yP_TCD_DesignAccesObject2 = null;
                    } else {
                        this.logger(2, "createEmptyView() unknown column:" + string);
                        continue;
                    }
                }
            }
            if (yP_TCD_DesignAccesObject2 != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        Object object;
        Object object2;
        Object object3;
        List<YP_TCD_DCC_Business> list2;
        Iterator<YP_TCD_DCC_Merchant> iterator;
        Object object7;
        ArrayList<Long> arrayList;
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            return null;
        }
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            this.logger(2, "getView() ");
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            this.logger(2, "getView() No protocol...");
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            this.logger(2, "getView() bad interface");
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        boolean bl = false;
        boolean bl2 = false;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        List<YP_Gabarit> list22 = yP_PROT_IHM.getSearchGabarit();
        if (list22 != null && !list22.isEmpty()) {
            arrayList = list22.iterator();
            block2: while (arrayList.hasNext()) {
                object7 = arrayList.next();
                try {
                    if (((YP_Gabarit)object7).fieldName != null && ((YP_Gabarit)object7).fieldName.contentEquals("storeStatus")) {
                        bl = true;
                    }
                    if (((YP_Gabarit)object7).objectTosearch == null) {
                        yP_ComplexGabarit.set(((YP_Gabarit)object7).fieldName, ((YP_Gabarit)object7).operator);
                        continue;
                    }
                    yP_View.dealEnumColumn((YP_Gabarit)object7);
                    if (((YP_Gabarit)object7).objectTosearch == null) continue;
                    if (((YP_Gabarit)object7).fieldName != null && ((YP_Gabarit)object7).fieldName.contentEquals("merchantName")) {
                        for (YP_TCD_DCC_Merchant exception : yP_Transaction.getMerchantList()) {
                            if (!exception.getMerchantName().contentEquals((String)((YP_Gabarit)object7).objectTosearch)) continue;
                            yP_ComplexGabarit.set("idMerchant", ((YP_Gabarit)object7).operator, exception.getIDMerchant());
                            continue block2;
                        }
                        continue;
                    }
                    if (((YP_Gabarit)object7).fieldName != null && ((YP_Gabarit)object7).fieldName.contentEquals(yP_TCD_DesignAccesObject.getPrimaryKeyName())) {
                        bl2 = true;
                    }
                    yP_ComplexGabarit.set(((YP_Gabarit)object7).fieldName, ((YP_Gabarit)object7).operator, ((YP_Gabarit)object7).objectTosearch);
                }
                catch (Exception exception) {
                    this.logger(2, "getView() ", exception);
                }
            }
        }
        if ((object7 = yP_Transaction.getMerchantList()) == null) {
            this.logger(2, "getView() error while retrieving merchantList");
            return null;
        }
        if (object7.isEmpty()) {
            this.logger(3, "getView() no merchant List");
            return yP_View;
        }
        if (object7.size() <= 500) {
            arrayList = new ArrayList<Long>();
            iterator = object7.iterator();
            while (iterator.hasNext()) {
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)iterator.next();
                arrayList.add((Long)yP_TCD_DCC_Merchant.getMerchantRow().getFieldValueByName("idMerchant"));
            }
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        }
        if ((arrayList = yP_Transaction.getBrandList()) == null) {
            this.logger(2, "getView() no brand List");
            return null;
        }
        if (arrayList.isEmpty()) {
            this.logger(2, "getView() no brand");
            return yP_View;
        }
        HashMap<Object, YP_TCD_DCC_Brand> hashMap = new HashMap<Object, YP_TCD_DCC_Brand>();
        iterator = new HashMap();
        List<YP_Row> list3 = new ArrayList<YP_Row>();
        if (object7.size() == 1 && (list2 = yP_Transaction.getApplicationList()) != null && list2.size() == 1) {
            YP_TCD_DCC_Business yP_TCD_DCC_Business = list2.get(0);
            object3 = yP_TCD_DCC_Business.getDataContainerBrand().getIdStoreListByContract(yP_TCD_DCC_Business.getIDContract());
            if (object3 == null || object3.isEmpty()) {
                this.logger(4, "getView() nothing found");
                return yP_View;
            }
            object2 = object3.iterator();
            while (object2.hasNext()) {
                object = (Long)object2.next();
                YP_Row yP_Row = yP_TCD_DCC_Business.getDataContainerBrand().getStore((Long)object);
                if (yP_Row == null) continue;
                list3.add(yP_Row);
                hashMap.put(yP_Row, yP_TCD_DCC_Business.getDataContainerBrand());
                iterator.put(yP_Row, yP_TCD_DCC_Business.getDataContainerMerchant().getMerchantRow());
            }
            if (list3.isEmpty()) {
                this.logger(2, "getView() nothing found");
                return yP_View;
            }
        }
        if (list3.isEmpty()) {
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : arrayList) {
                object3 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Store").getRowListSuchAs(yP_ComplexGabarit);
                if (object3 == null) continue;
                list3.addAll((Collection<YP_Row>)object3);
                object2 = object3.iterator();
                block7: while (object2.hasNext()) {
                    object = (YP_Row)object2.next();
                    hashMap.put(object, yP_TCD_DCC_Brand);
                    long l2 = (Long)((YP_Row)object).getFieldValueByName("idMerchant");
                    for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                        if (yP_TCD_DCC_Merchant.getIDMerchant() != l2) continue;
                        iterator.put(object, yP_TCD_DCC_Merchant.getMerchantRow());
                        continue block7;
                    }
                }
            }
        }
        if (list3.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n3 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
        if (!(bl2 || bl && n3 != 3 && n3 != 4)) {
            int n4 = list3.size() - 1;
            while (n4 >= 0) {
                object3 = (YP_Row)list3.get(n4);
                object = (StoreStatusEnumeration)((Object)((YP_Row)object3).getFieldValueByName("storeStatus"));
                if (object == StoreStatusEnumeration.DELETED) {
                    list3.remove(n4);
                }
                --n4;
            }
        }
        if (yP_ComplexGabarit != null && yP_ComplexGabarit.isOrdered) {
            list3 = YP_TCD_DesignAccesObject.getRowListSuchAs(list3, yP_ComplexGabarit);
        }
        int n5 = 0;
        while (n5 < list3.size()) {
            object3 = (YP_Row)list3.get(n5);
            object = ((YP_TCD_DCC_Brand)hashMap.get(object3)).getBrandRow();
            object2 = (YP_Row)iterator.get(object3);
            yP_View.setRowID(n5, String.valueOf(((YP_Row)object3).getFather().getFullTableName()) + "#" + ((YP_Row)object3).getPrimaryKeyName() + "#" + ((YP_Row)object3).getPrimaryKey());
            if (!yP_TCD_DCC_Interface_View.isWriteAllowed(l, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.setRowActionable(n5, false);
            } else {
                yP_View.setRowActionable(n5, true);
                if (list3.size() == 1) {
                    List<YP_TCD_DC_Context.Action> list4 = this.getActionList(yP_TCD_DCC_Interface_View, yP_Transaction, (YP_Row)object, (YP_Row)object2, (YP_Row)object3, yP_View);
                    yP_View.setRowActionList(n5, list4);
                }
            }
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Object object4 = yP_TCD_DesignAccesObject.getFieldByName(string);
                List<Long> list5 = null;
                if (object4 != null) {
                    list5 = object3;
                } else {
                    object4 = this.dataContainerTechnique.merchant.getFieldByName(string);
                    if (object4 != null) {
                        list5 = object2;
                    } else {
                        object4 = this.dataContainerTechnique.brand.getFieldByName(string);
                        if (object4 != null) {
                            list5 = object;
                        }
                    }
                }
                if (object4 != null && list5 != null) {
                    this.addFieldValue(yP_View, (Field)object4, (YP_Row)((Object)list5), string, n5);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n5;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    private YP_TCD_DesignAccesObject getDAO(YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            this.logger(2, "getDAO() error while retrieving brandList");
            return null;
        }
        if (list.isEmpty()) {
            this.logger(2, "getDAO() no brand");
            return null;
        }
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Store");
            if (yP_TCD_DesignAccesObject == null || !yP_TCD_DesignAccesObject.getSchemaName().contentEquals(string)) continue;
            return yP_TCD_DesignAccesObject;
        }
        this.logger(2, "getDAO() error while retrieving Store DAO");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            this.logger(2, "getDAO() error while retrieving brandList");
            return null;
        }
        if (list.isEmpty()) {
            this.logger(2, "getDAO() no brand");
            return null;
        }
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
            if (yP_TCD_DCC_Brand == null || (yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Store")) == null || string != null && !yP_TCD_DesignAccesObject.getFullTableName().startsWith(string)) continue;
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        this.logger(2, "getDAO() error while retrieving Store DAO");
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        block22: {
            try {
                if (yP_Transaction != null) break block22;
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "executeAction() ", exception);
                return -1;
            }
        }
        switch (action.id) {
            case "deleteStoreContracts": {
                return this.deleteStoreContracts(yP_Transaction, yP_Row);
            }
            case "assignStoreContracts": {
                return this.assignStoreContracts(yP_Transaction, yP_Row, action);
            }
            case "ACTIVATE_STORE": {
                return this.activateStore(yP_Transaction, yP_Row);
            }
            case "DEACTIVATE_STORE": {
                return this.deactivateStore(yP_Transaction, yP_Row);
            }
            case "DELETE_STORE": {
                return this.deleteStore(yP_Transaction, yP_Row);
            }
        }
        this.logger(2, "executeAction() unknown action " + action.id);
        return -1;
    }

    private int deleteStoreContracts(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "deleteStoreContracts() No rights");
            return -1;
        }
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList(true);
        if (list == null) {
            this.logger(2, "deleteStoreContracts() error while retrieving brandList");
            return -1;
        }
        if (list.isEmpty()) {
            this.logger(2, "deleteStoreContracts() no brand");
            return -1;
        }
        if (list.size() > 1) {
            this.logger(2, "deleteStoreContracts() too many");
            return -1;
        }
        long l = yP_Row.getPrimaryKey();
        list.get(0).removeAllContractsFromStore(l);
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int assignStoreContracts(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        try {
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "assignStoreContracts() No rights");
                return -1;
            }
            if (action.propertiesList != null && !action.propertiesList.isEmpty()) {
                long l = 0L;
                long l2 = 0L;
                for (Property property : action.propertiesList) {
                    switch (property.getName()) {
                        case "IDBRAND": {
                            l2 = Long.parseLong(property.getValue());
                            break;
                        }
                        case "IDSTORE": {
                            l = Long.parseLong(property.getValue());
                            break;
                        }
                    }
                }
                if (l2 <= 0L) {
                    this.logger(2, "assignStoreContracts() property not found: IDBRAND");
                    return -1;
                }
                if (l <= 0L) {
                    this.logger(2, "assignStoreContracts() property not found: IDSTORE");
                    return -1;
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.getDataContainerBrand(yP_Transaction, l2);
                if (yP_TCD_DCC_Brand == null) {
                    this.logger(2, "assignStoreContracts() failed to get dataContainerBrand");
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("ContractInsideStore");
                Object object = this.getContractInsideStoreList(l, yP_TCD_DesignAccesObject);
                Map<Long, YP_Row> map = this.getContractInsideStoreMap((List<YP_Row>)object);
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                ArrayList<Long> arrayList = new ArrayList<Long>();
                boolean bl = false;
                for (Property property : action.propertiesList) {
                    DAO_ContractInsideStore dAO_ContractInsideStore;
                    if (!property.getName().contains(CHECKBOX_FIELD)) continue;
                    JSONObject jSONObject = new JSONObject(property.getValue());
                    String string = jSONObject.get("checked").toString();
                    if (string == null || !string.contentEquals("true") && !string.contentEquals("false")) {
                        this.logger(2, "assignStoreContracts() invalid checked value for " + jSONObject.get("label").toString());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    long l3 = Long.parseLong(jSONObject.get("idContract").toString());
                    if (Boolean.parseBoolean(string)) {
                        if (map.containsKey(l3)) continue;
                        dAO_ContractInsideStore = (DAO_ContractInsideStore)yP_TCD_DesignAccesObject.getNewRow();
                        dAO_ContractInsideStore.idStore = l;
                        dAO_ContractInsideStore.idContract = l3;
                        dAO_ContractInsideStore.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                        yP_TCD_DesignAccesObject.addRow(dAO_ContractInsideStore, true);
                        bl = true;
                        continue;
                    }
                    if (!map.containsKey(l3)) continue;
                    dAO_ContractInsideStore = (DAO_ContractInsideStore)map.get(l3);
                    long l4 = dAO_ContractInsideStore.idContractInsideStore;
                    arrayList.add(l4);
                    bl = true;
                }
                if (bl) {
                    if (arrayList.size() > 0) {
                        yP_ComplexGabarit.set("idContractInsideStore", YP_ComplexGabarit.OPERATOR.IN, arrayList.toArray());
                        yP_TCD_DesignAccesObject.deleteRowsSuchAs(yP_ComplexGabarit);
                    }
                    yP_TCD_DesignAccesObject.persist();
                }
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "assignStoreContracts() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                boolean bl;
                boolean bl2;
                long l;
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Key must not be set !");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                String string2 = yP_View.getFieldValueAt(n, "brandName");
                if (string2 == null || string2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:brandName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_Transaction, string2);
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() not really possible !!!");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                String string3 = null;
                boolean bl3 = false;
                block39: for (String string4 : yP_View.getColumnSet()) {
                    String string5 = yP_View.getFieldValueAt(n, string4);
                    if (string5 == null) continue;
                    switch (string4) {
                        case "idStore": {
                            if (string5.isEmpty()) continue block39;
                            this.logger(2, "createInView() Key should be empty :" + string4);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "merchantName": {
                            string3 = string5;
                            break;
                        }
                        case "storeLabel": 
                        case "storeTitle": {
                            l = UtilsYP.countOccurencesOf(string5, '/');
                            if (l >= 4L) {
                                bl3 = true;
                                String[] stringArray = string5.split("/");
                                yP_Row.set("storeTitle", stringArray.length > 0 ? stringArray[0] : "");
                                yP_Row.set("storeCity", stringArray.length > 1 ? stringArray[1] : "");
                                yP_Row.set("storeZIPCode", stringArray.length > 2 ? stringArray[2] : "");
                                yP_Row.set("facilitatorAlias", stringArray.length > 3 ? stringArray[3] : "");
                                yP_Row.set("storeLabel", stringArray.length > 4 ? stringArray[4] : "");
                                if (stringArray.length <= 5) continue block39;
                                this.logger(2, "createInView() bad format for " + string4 + ":" + string5);
                                break;
                            }
                            if (bl3) continue block39;
                            yP_Row.set(string4, string5);
                            break;
                        }
                        case "facilitatorID": 
                        case "storeCountryCodeNum": 
                        case "storeZIPCode": 
                        case "storeAddress": 
                        case "isoID": 
                        case "subMerchantID": 
                        case "facilitatorAlias": 
                        case "storeSiret": 
                        case "storeCategoryCode": 
                        case "storeIdentifier": 
                        case "storeCity": {
                            yP_Row.set(string4, string5);
                            break;
                        }
                        case "brandLabel": 
                        case "merchantLabel": {
                            if (string5.isEmpty()) continue block39;
                            this.logger(2, "createInView() field ignored :" + string4);
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string4);
                            break;
                        }
                        case "brandName": 
                    }
                }
                if (string3 == null || string3.isEmpty()) {
                    this.logger(2, "createInView() mandatory value missing:merchantName");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string3.indexOf(95) != -1) {
                    String[] stringArray = string3.split("_");
                    if (stringArray.length == 2 && stringArray[0].contentEquals(string2)) {
                        string3 = stringArray[1];
                    } else {
                        this.logger(2, "createInView() bad value for merchantName:" + string3);
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                        return -1;
                    }
                }
                boolean bl4 = false;
                String string6 = String.valueOf(string2) + '_' + string3;
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_Transaction.getDataContainerTransaction().contextHandler.merchantContainers) {
                    if (!yP_TCD_DCC_Merchant.getContractIdentifier().contentEquals(string6)) continue;
                    bl2 = true;
                    yP_Row.set("idMerchant", yP_TCD_DCC_Merchant.getIDMerchant());
                    break;
                }
                if (!bl2) {
                    for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers) {
                        if (!yP_TCD_DCC_Brand.getContractIdentifier().contentEquals(string2)) continue;
                        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", string6);
                        if (yP_TCD_DCC_Merchant == null) break;
                        bl = true;
                        yP_Row.set("idMerchant", yP_TCD_DCC_Merchant.getIDMerchant());
                        break;
                    }
                }
                if (!bl) {
                    this.logger(2, "createInView() unable to find merchant in accessList:" + string2 + " " + string3);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
                try {
                    Object object;
                    yP_TCD_DesignAccesObject.lock();
                    String string7 = yP_Row.getFieldStringValueByName("storeIdentifier");
                    if (string7 == null || string7.isEmpty()) {
                        this.logger(4, "createInView() storeIdentifier has not been sent, we must create one");
                        object = new StringBuilder();
                        ((StringBuilder)object).append("SELECT MAX(CAST(storeIdentifier AS Int)) AS count FROM " + yP_TCD_DesignAccesObject.getFullTableName() + "\r\n");
                        ((StringBuilder)object).append("WHERE storeIdentifier NOT LIKE '%[a-z]%'");
                        l = yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, ((StringBuilder)object).toString());
                        this.logger(4, "createInView() storeIdentifier retrieve:" + l);
                        if (l < 0L) {
                            this.logger(2, "createInView() Unable to retrieve storeIdentifier");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                            return -1;
                        }
                        String string8 = Long.toString(++l);
                        this.logger(4, "createInView() new storeIdentifier :" + string8);
                        yP_Row.set("storeIdentifier", string8);
                    } else {
                        if (string7.contains("_")) {
                            this.logger(2, "createInView() storeIdentifier must not contains '_'");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        object = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        ((YP_ComplexGabarit)object).set("storeIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE, string7);
                        ((YP_ComplexGabarit)object).set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row.getFieldValueByName("idMerchant"));
                        List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(new YP_ComplexGabarit[]{object});
                        if (list2 == null) {
                            this.logger(2, "createInView() unable to get list for " + string7);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                            return -1;
                        }
                        if (!list2.isEmpty()) {
                            this.logger(2, "createInView() storeIdentifier already exist:" + string7);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                            return -1;
                        }
                    }
                    object = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
                    yP_Row.set("creationGMTTime", (Timestamp)object);
                    yP_Row.set("lastModificationGMTTime", (Timestamp)object);
                    YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
                    if (yP_Process instanceof YP_Transaction) {
                        yP_Row.set("idUser", ((YP_Transaction)yP_Process).getDataContainerTransaction().userHandler.getUserIdentifier());
                    }
                    if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) < 0) {
                        this.logger(2, "createInView() Not able to add row...");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    if (yP_TCD_DesignAccesObject.persist() < 0) {
                        this.logger(2, "createInView() Not able to save changes...");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                }
                finally {
                    yP_TCD_DesignAccesObject.unlock();
                }
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() ", exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private List<YP_TCD_DC_Context.Action> getActionList(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_Row yP_Row, YP_Row yP_Row2, YP_Row yP_Row3, YP_View yP_View) {
        long l;
        String string;
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand;
        long l2;
        int n;
        YP_TCD_DC_Context.Action action;
        ArrayList<YP_TCD_DC_Context.Action> arrayList;
        block27: {
            block26: {
                block25: {
                    long l3;
                    block24: {
                        block23: {
                            block22: {
                                block21: {
                                    arrayList = new ArrayList<YP_TCD_DC_Context.Action>();
                                    action = new YP_TCD_DC_Context.Action();
                                    action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                                    action.formName = "StoreForm";
                                    action.id = "MODIFY_STORE";
                                    action.label = this.getLabel("MODIFY_STORE");
                                    arrayList.add(action);
                                    n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                                    if (n != 2 && n != 1) return arrayList;
                                    action = new YP_TCD_DC_Context.Action();
                                    action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                                    action.formName = "StandardGenericForm";
                                    action.id = ASSIGN_STORE_CONTRACTS;
                                    action.label = this.getLabel(ASSIGN_STORE_CONTRACTS);
                                    action.propertiesList = new ArrayList<Property>();
                                    l2 = (Long)yP_Row.getFieldValueByName("idBrand");
                                    if (l2 > 0L) break block21;
                                    this.logger(2, "getActionList() bad value for idBrand: " + l2);
                                    return null;
                                }
                                yP_TCD_DCC_Brand = this.getDataContainerBrand(yP_Transaction, l2);
                                if (yP_TCD_DCC_Brand != null) break block22;
                                this.logger(2, "getActionList() failed to get dataContainerBrand");
                                return null;
                            }
                            yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("ContractInsideStore");
                            if (yP_TCD_DesignAccesObject != null) break block23;
                            this.logger(2, "getActionList() failed to get daoContractInsideStore");
                            return null;
                        }
                        l3 = (Long)yP_Row2.getFieldValueByName("idMerchant");
                        if (l3 > 0L) break block24;
                        this.logger(2, "getActionList() bad value for idMerchant: " + l3);
                        return null;
                    }
                    yP_TCD_DCC_Merchant = null;
                    for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant2 : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                        if (yP_TCD_DCC_Merchant2.getIDMerchant() != l3) continue;
                        yP_TCD_DCC_Merchant = yP_TCD_DCC_Merchant2;
                        break;
                    }
                    if (yP_TCD_DCC_Merchant != null) break block25;
                    this.logger(2, "getActionList() failed to get dataContainerMerchant");
                    return null;
                }
                string = yP_Row3.getFieldStringValueByName("storeLabel");
                if (string != null) break block26;
                this.logger(2, "getActionList() bad value for storeLabel: " + string);
                return null;
            }
            l = (Long)yP_Row3.getFieldValueByName("idStore");
            if (l > 0L) break block27;
            this.logger(2, "getActionList() bad value for idStore: " + l);
            return null;
        }
        try {
            void var25_29;
            Property property = new Property();
            property.setName(IDBRAND_PROPERTY_NAME);
            property.setValue(Long.toString(l2));
            action.propertiesList.add(property);
            property = new Property();
            property.setName(IDSTORE_PROPERTY_NAME);
            property.setValue(Long.toString(l));
            action.propertiesList.add(property);
            property = new Property();
            property.setName(LABEL_FIELD);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("text", (Object)("Enseigne: " + yP_TCD_DCC_Brand.getBrandLabel()));
            jSONObject.put("hAlignment", (Object)"LEFT");
            String string2 = jSONObject.toString();
            property.setValue(string2);
            action.propertiesList.add(property);
            property = new Property();
            property.setName(LABEL_FIELD);
            jSONObject = new JSONObject();
            jSONObject.put("text", (Object)("Commer\u00e7ant: " + yP_TCD_DCC_Merchant.getMerchantLabel()));
            jSONObject.put("hAlignment", (Object)"LEFT");
            string2 = jSONObject.toString();
            property.setValue(string2);
            action.propertiesList.add(property);
            property = new Property();
            property.setName(LABEL_FIELD);
            jSONObject = new JSONObject();
            jSONObject.put("text", (Object)("Ilot: " + string));
            jSONObject.put("hAlignment", (Object)"LEFT");
            string2 = jSONObject.toString();
            property.setValue(string2);
            action.propertiesList.add(property);
            List<YP_Row> list = this.getContractInsideStoreList(l, yP_TCD_DesignAccesObject);
            Map<Long, YP_Row> map = this.getContractInsideStoreMap(list);
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                long l4 = yP_TCD_DCC_Business.getIDContract();
                property = new Property();
                property.setName(String.valueOf(l4) + "_" + CHECKBOX_FIELD);
                jSONObject = new JSONObject();
                String string3 = yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel");
                if (string3 == null) {
                    string3 = "";
                }
                jSONObject.put("label", (Object)string3);
                if (map.containsKey(l4)) {
                    jSONObject.put("checked", true);
                    YP_Row yP_Row4 = map.get(l4);
                    jSONObject.put("idContractInsideStore", (Object)yP_Row4.getFieldStringValueByName("idContractInsideStore"));
                } else {
                    jSONObject.put("checked", false);
                }
                jSONObject.put("idContract", (Object)Long.toString(l4));
                string2 = jSONObject.toString();
                property.setValue(string2);
                action.propertiesList.add(property);
            }
            arrayList.add(action);
            if (n != 1 && n != 2) return arrayList;
            StoreStatusEnumeration storeStatusEnumeration = (StoreStatusEnumeration)((Object)yP_Row3.getFieldValueByName("storeStatus"));
            if (storeStatusEnumeration == null) {
                StoreStatusEnumeration storeStatusEnumeration2 = StoreStatusEnumeration.ACTIVE;
            }
            switch (YP_TCG_View_Store.$SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration()[var25_29.ordinal()]) {
                case 2: {
                    arrayList.add(this.getAction(yP_Transaction, "DEACTIVATE_STORE"));
                    return arrayList;
                }
                case 3: {
                    arrayList.add(this.getAction(yP_Transaction, "ACTIVATE_STORE"));
                    arrayList.add(this.getConfirmAction(yP_Transaction, "DELETE_STORE"));
                    return arrayList;
                }
                case 1: {
                    arrayList.add(this.getAction(yP_Transaction, "ACTIVATE_STORE"));
                    arrayList.add(this.getAction(yP_Transaction, "DEACTIVATE_STORE"));
                    arrayList.add(this.getConfirmAction(yP_Transaction, "DELETE_STORE"));
                    return arrayList;
                }
                case 4: {
                    if (n != 1) return arrayList;
                    arrayList.add(this.getAction(yP_Transaction, "ACTIVATE_STORE"));
                    arrayList.add(this.getAction(yP_Transaction, "DEACTIVATE_STORE"));
                }
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getActionList() ", exception);
            return null;
        }
    }

    private Map<Long, YP_Row> getContractInsideStoreMap(List<YP_Row> list) {
        HashMap<Long, YP_Row> hashMap = new HashMap<Long, YP_Row>();
        for (YP_Row yP_Row : list) {
            long l = (Long)yP_Row.getFieldValueByName("idContract");
            if (l <= 0L) {
                this.logger(2, "getContractInsideStoreMap() bad value for idContract:" + l);
                continue;
            }
            hashMap.put(l, yP_Row);
        }
        return hashMap;
    }

    private YP_TCD_DCC_Brand getDataContainerBrand(YP_Transaction yP_Transaction, long l) {
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = null;
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList(true);
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand2 : list) {
            if (yP_TCD_DCC_Brand2.getIDBrand() != l) continue;
            yP_TCD_DCC_Brand = yP_TCD_DCC_Brand2;
            break;
        }
        return yP_TCD_DCC_Brand;
    }

    private List<YP_Row> getContractInsideStoreList(long l, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set("idStore", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        return list;
    }

    @Override
    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        block5: {
            try {
                long l;
                if (string == null || !string.contentEquals("storeLabel") && !string.contentEquals("storeTitle") || (l = (long)UtilsYP.countOccurencesOf(string2, '/')) < 4L) break block5;
                String[] stringArray = string2.split("/");
                yP_Row.set("storeTitle", stringArray.length > 0 ? stringArray[0] : "");
                yP_Row.set("storeCity", stringArray.length > 1 ? stringArray[1] : "");
                yP_Row.set("storeZIPCode", stringArray.length > 2 ? stringArray[2] : "");
                yP_Row.set("facilitatorAlias", stringArray.length > 3 ? stringArray[3] : "");
                yP_Row.set("storeLabel", stringArray.length > 4 ? stringArray[4] : "");
                if (stringArray.length > 5) {
                    this.logger(2, "checkModification() bad format for " + string + ":" + string2);
                }
                return 2;
            }
            catch (Exception exception) {
                this.logger(2, "checkModification() ", exception);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
        }
        yP_Row.set("lastModificationGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
        if (yP_Process instanceof YP_Transaction) {
            yP_Row.set("idUser", ((YP_Transaction)yP_Process).getDataContainerTransaction().userHandler.getUserIdentifier());
        }
        return super.checkModification(yP_Transaction, yP_Row, string, string2);
    }

    private int activateStore(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        block3: {
            try {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break block3;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "activateStore() No rights");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "activateStore() ", exception);
                return -1;
            }
        }
        yP_Row.set("storeStatus", StoreStatusEnumeration.ACTIVE);
        this.dealRowModificationsBeforePersist(yP_Row);
        yP_Row.persist();
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    private int deactivateStore(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        block3: {
            try {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break block3;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "deactivateStore() No rights");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "deactivateStore() ", exception);
                return -1;
            }
        }
        yP_Row.set("storeStatus", StoreStatusEnumeration.INACTIVE);
        this.dealRowModificationsBeforePersist(yP_Row);
        yP_Row.persist();
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    private int deleteStore(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        block3: {
            try {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break block3;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "deleteStore() No rights");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "deleteStore() ", exception);
                return -1;
            }
        }
        yP_Row.set("storeStatus", StoreStatusEnumeration.DELETED);
        this.dealRowModificationsBeforePersist(yP_Row);
        yP_Row.persist();
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    @Override
    protected void dealRowModificationsBeforePersist(YP_Row yP_Row) {
        if (yP_Row.getModifierFlag() != 0) {
            yP_Row.set("lastModificationGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
            if (yP_Process instanceof YP_Transaction) {
                yP_Row.set("idUser", ((YP_Transaction)yP_Process).getDataContainerTransaction().userHandler.getUserIdentifier());
            }
        }
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration() {
        if ($SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration != null) {
            return $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration;
        }
        int[] nArray = new int[StoreStatusEnumeration.values().length];
        try {
            nArray[StoreStatusEnumeration.ACTIVE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.DELETED.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.INACTIVE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.UNKNOWN.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration = nArray;
        return nArray;
    }
}

