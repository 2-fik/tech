/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_View_ContractStatus
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_ContractStatus(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_ContractStatus";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        YP_TCD_DCC_Status yP_TCD_DCC_Status = this.dataContainerManager.getDataContainerStatus();
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DCC_Status.contractStatus.getFieldByName(string);
            if (field == null) {
                if (this.getLogLevel() < 2) continue;
                this.logger(2, "createEmptyView() unknown column:" + string);
                continue;
            }
            if (yP_View.addColumn(string, string2, yP_TCD_DCC_Status.contractStatus, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_ComplexGabarit yP_ComplexGabarit;
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        List<YP_Gabarit> list2 = yP_PROT_IHM.getSearchGabarit();
        if (list2 != null && !list2.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerManager.getDataContainerStatus().contractStatus);
            for (YP_Gabarit object2 : list2) {
                try {
                    if (object2.objectTosearch == null) {
                        yP_ComplexGabarit.set(object2.fieldName, object2.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(object2);
                    if (object2.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(object2.fieldName, object2.operator, object2.objectTosearch);
                }
                catch (Exception yP_Row) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + yP_Row);
                }
            }
        } else {
            yP_ComplexGabarit = null;
        }
        List<YP_Row> list3 = this.dataContainerManager.getDataContainerStatus().contractStatus.getRowListSuchAs(yP_ComplexGabarit);
        if (list3 == null) {
            this.logger(2, "getView() null list");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n3 = 0;
        while (n3 < list3.size()) {
            YP_Row yP_Row = list3.get(n3);
            yP_View.setRowID(n3, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            yP_View.setRowActionable(n3, false);
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = this.dataContainerManager.getDataContainerStatus().contractStatus.getFieldByName(string);
                if (field != null) {
                    this.addFieldValue(yP_View, field, yP_Row, string, n3);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n3;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        YP_TCD_DCC_Status yP_TCD_DCC_Status = this.dataContainerManager.getDataContainerStatus();
        return yP_TCD_DCC_Status.contractStatus;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        this.logger(2, "createInView() Not yet done");
        return 0;
    }
}

