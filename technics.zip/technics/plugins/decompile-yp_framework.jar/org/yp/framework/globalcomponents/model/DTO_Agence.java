/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

public class DTO_Agence {
    @SerializedName(value="adresse")
    private String adresse = null;
    @SerializedName(value="code")
    private String code = null;
    @SerializedName(value="designation")
    private String designation = null;
    @SerializedName(value="id")
    private Integer id = null;
    @SerializedName(value="numero")
    private String numero = null;

    public DTO_Agence adresse(String string) {
        this.adresse = string;
        return this;
    }

    public String getAdresse() {
        return this.adresse;
    }

    public void setAdresse(String string) {
        this.adresse = string;
    }

    public DTO_Agence code(String string) {
        this.code = string;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String string) {
        this.code = string;
    }

    public DTO_Agence designation(String string) {
        this.designation = string;
        return this;
    }

    public String getDesignation() {
        return this.designation;
    }

    public void setDesignation(String string) {
        this.designation = string;
    }

    public DTO_Agence id(Integer n) {
        this.id = n;
        return this;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer n) {
        this.id = n;
    }

    public DTO_Agence numero(String string) {
        this.numero = string;
        return this;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setNumero(String string) {
        this.numero = string;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Agence dTO_Agence = (DTO_Agence)object;
        return Objects.equals(this.adresse, dTO_Agence.adresse) && Objects.equals(this.code, dTO_Agence.code) && Objects.equals(this.designation, dTO_Agence.designation) && Objects.equals(this.id, dTO_Agence.id) && Objects.equals(this.numero, dTO_Agence.numero);
    }

    public int hashCode() {
        return Objects.hash(this.adresse, this.code, this.designation, this.id, this.numero);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class AgenceDto {\n");
        stringBuilder.append("    adresse: ").append(this.toIndentedString(this.adresse)).append("\n");
        stringBuilder.append("    code: ").append(this.toIndentedString(this.code)).append("\n");
        stringBuilder.append("    designation: ").append(this.toIndentedString(this.designation)).append("\n");
        stringBuilder.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        stringBuilder.append("    numero: ").append(this.toIndentedString(this.numero)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

