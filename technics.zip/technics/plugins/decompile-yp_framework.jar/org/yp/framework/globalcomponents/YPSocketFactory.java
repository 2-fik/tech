/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.net.SocketFactory;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;

public class YPSocketFactory
extends SocketFactory {
    public static YPSocketFactory myYPSocketFactory;
    YP_Service connectionManager = null;
    YP_Object father = null;

    public YPSocketFactory(YP_Object yP_Object) {
        if (myYPSocketFactory != null) {
            System.out.println("myYPSocketFactory!=null");
            return;
        }
        this.father = yP_Object;
        this.connectionManager = (YP_Service)yP_Object.getPluginByName("ConnectionManager");
        myYPSocketFactory = this;
    }

    public static SocketFactory getDefault() {
        if (myYPSocketFactory == null) {
            return null;
        }
        return myYPSocketFactory;
    }

    @Override
    public Socket createSocket(String string, int n) throws IOException, UnknownHostException {
        Socket socket;
        block3: {
            try {
                socket = (Socket)this.connectionManager.dealRequest(this.father, "openHandle", string, n);
                if (socket != null) break block3;
                this.father.logger(2, "createSocket() impossible to open the connection  for: " + string + ":" + n);
                return null;
            }
            catch (Exception exception) {
                this.father.logger(2, "createSocket() " + exception);
                return null;
            }
        }
        return socket;
    }

    @Override
    public Socket createSocket(String string, int n, InetAddress inetAddress, int n2) throws IOException, UnknownHostException {
        this.father.logger(2, "createSocket(String host, int port, InetAddress localHost, int localPort) TODO");
        return null;
    }

    @Override
    public Socket createSocket(InetAddress inetAddress, int n) throws IOException {
        this.father.logger(2, "createSocket(InetAddress host, int port) TODO");
        return null;
    }

    @Override
    public Socket createSocket(InetAddress inetAddress, int n, InetAddress inetAddress2, int n2) throws IOException {
        this.father.logger(2, "createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) TODO");
        return null;
    }
}

