/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.UtilsYP;

public class YP_TCG_ProtocolSelector
extends YP_GlobalComponent {
    public YP_TCG_ProtocolSelector(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String toString() {
        return "ProtocolSelector";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public YP_TCD_PosProtocol getProtocol(YP_Object yP_Object, byte[] byArray, int n) {
        int n2;
        YP_TCD_PosProtocol yP_TCD_PosProtocol;
        String string;
        block18: {
            String string2;
            try {
                string = new String(byArray, 0, n, "UTF-8");
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "getProtocol() " + exception);
                }
                return null;
            }
            if (string.indexOf("</SaleToPOIRequest>") != -1) {
                string2 = "EPAS";
            } else if (string.indexOf("%3CSaleToPOIRequest") != -1) {
                string2 = "EPAS";
            } else if (string.indexOf("</XPDERequest>") != -1) {
                string2 = "XPDE_JIBX";
            } else if (string.indexOf("%3CXPDERequest") != -1) {
                string2 = "XPDE_JIBX";
            } else {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "getProtocol() unknow protocol " + string);
                }
                return null;
            }
            if (this.getLogLevel() == 5 || this.getLogLevel() == 4) {
                this.logger(4, UtilsYP.requestWithoutSensitiveData(string));
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "getProtocol() Protocol found : " + string2);
            }
            try {
                yP_TCD_PosProtocol = (YP_TCD_PosProtocol)yP_Object.newPluginByName(string2, new Object[0]);
                n2 = yP_TCD_PosProtocol.initialize();
                if (n2 == 1) break block18;
                this.logger(2, "getProtocol() failed to initialise protocol:" + n2);
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getProtocol() " + exception);
                return null;
            }
        }
        n2 = yP_TCD_PosProtocol.loadInitialRequest(string);
        if (n2 != 1) {
            this.logger(2, "getProtocol() failed to read request:" + n2);
            yP_TCD_PosProtocol.setErrorStatus(1);
        }
        return yP_TCD_PosProtocol;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (!string.contentEquals("getProtocol")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 2) {
                byte[] byArray = (byte[])objectArray[0];
                int n = (Integer)objectArray[1];
                return this.getProtocol(yP_Object, byArray, n);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "dealRequest() bad parameters for getProtocol");
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }
}

