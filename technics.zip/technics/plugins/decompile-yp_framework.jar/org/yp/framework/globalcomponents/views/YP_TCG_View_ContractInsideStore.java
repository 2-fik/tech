/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;

public class YP_TCG_View_ContractInsideStore
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_ContractInsideStore(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_ContractInsideStore";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = ((YP_TCD_DataContainer)yP_TCD_DesignAccesObject.getFather()).getDesignAccesObject_ByName("Store");
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject3 = yP_TCD_DesignAccesObject;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject3 = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject3 = this.dataContainerTechnique.brand;
                    } else {
                        field = yP_TCD_DesignAccesObject2.getFieldByName(string);
                        if (field != null) {
                            yP_TCD_DesignAccesObject3 = yP_TCD_DesignAccesObject2;
                        } else if (string.contentEquals("Needed???")) {
                            yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                            yP_TCD_DesignAccesObject3 = null;
                        } else {
                            if (this.getLogLevel() < 2) continue;
                            this.logger(2, "createEmptyView() unknown column:" + string);
                            continue;
                        }
                    }
                }
            }
            if (yP_TCD_DesignAccesObject3 != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject3, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        yP_View.addCustomColumn("contractLabel", "Label", "string", -1);
        return yP_View;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        void var21_24;
        List<YP_Row> list2;
        Object object;
        Object object2;
        Object object3;
        ArrayList<Long> arrayList;
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            return null;
        }
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        List<YP_Gabarit> list3 = yP_PROT_IHM.getSearchGabarit();
        if (list3 != null && !list3.isEmpty()) {
            arrayList = list3.iterator();
            while (arrayList.hasNext()) {
                object3 = arrayList.next();
                try {
                    if (((YP_Gabarit)object3).objectTosearch == null) {
                        yP_ComplexGabarit.set(((YP_Gabarit)object3).fieldName, ((YP_Gabarit)object3).operator);
                        continue;
                    }
                    yP_View.dealEnumColumn((YP_Gabarit)object3);
                    if (((YP_Gabarit)object3).objectTosearch == null) continue;
                    yP_ComplexGabarit.set(((YP_Gabarit)object3).fieldName, ((YP_Gabarit)object3).operator, ((YP_Gabarit)object3).objectTosearch);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + exception);
                }
            }
        }
        if ((object3 = yP_Transaction.getMerchantList()) == null) {
            this.logger(2, "getView() error while retrieving merchantList");
            return null;
        }
        if (object3.isEmpty()) {
            this.logger(3, "getView() no merchant List");
            return yP_View;
        }
        if (object3.size() <= 500) {
            arrayList = new ArrayList<Long>();
            object2 = object3.iterator();
            while (object2.hasNext()) {
                object = (YP_TCD_DCC_Merchant)object2.next();
                arrayList.add((Long)((YP_TCD_DCC_Merchant)object).getMerchantRow().getFieldValueByName("idMerchant"));
            }
            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        }
        if ((arrayList = yP_Transaction.getBrandList()) == null) {
            this.logger(2, "getView() no brand List");
            return null;
        }
        if (arrayList.isEmpty()) {
            this.logger(2, "getView() no brand");
            return yP_View;
        }
        object = new HashMap();
        object2 = new HashMap();
        HashMap<YP_Row, YP_Row> hashMap = new HashMap<YP_Row, YP_Row>();
        HashMap<YP_Row, YP_Row> hashMap2 = new HashMap<YP_Row, YP_Row>();
        List<YP_Row> list4 = new ArrayList<YP_Row>();
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : arrayList) {
            list2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("ContractInsideStore").getRowListSuchAs(yP_ComplexGabarit);
            if (list2 == null) continue;
            list4.addAll(list2);
            for (YP_Row yP_Row : list4) {
                object.put(yP_Row, yP_TCD_DCC_Brand);
                long yP_Row4 = (Long)yP_Row.getFieldValueByName("idContract");
                block6: for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                        if (yP_TCD_DCC_Business.getIDContract() != yP_Row4) continue;
                        object2.put(yP_Row, yP_TCD_DCC_Merchant.getMerchantRow());
                        hashMap.put(yP_Row, yP_TCD_DCC_Business.getContractRow());
                        continue block6;
                    }
                }
                long yP_TCD_DCC_Merchant = (Long)yP_Row.getFieldValueByName("idStore");
                hashMap2.put(yP_Row, yP_TCD_DCC_Brand.getStore(yP_TCD_DCC_Merchant));
            }
        }
        if (list4.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        if (yP_ComplexGabarit != null && yP_ComplexGabarit.isOrdered) {
            list4 = YP_TCD_DesignAccesObject.getRowListSuchAs(list4, yP_ComplexGabarit);
        }
        boolean n3 = false;
        while (var21_24 < list4.size()) {
            YP_Row yP_Row;
            YP_Row yP_Row2 = (YP_Row)list4.get((int)var21_24);
            list2 = ((YP_TCD_DCC_Brand)object.get(yP_Row2)).getBrandRow();
            yP_Row = (YP_Row)object2.get(yP_Row2);
            YP_Row yP_Row3 = (YP_Row)hashMap.get(yP_Row2);
            YP_Row yP_Row4 = (YP_Row)hashMap2.get(yP_Row2);
            yP_View.setRowID((int)var21_24, String.valueOf(yP_Row2.getFather().getFullTableName()) + "#" + yP_Row2.getPrimaryKeyName() + "#" + yP_Row2.getPrimaryKey());
            yP_View.setRowActionable((int)var21_24, false);
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                void var30_41;
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
                Object object4 = null;
                if (field != null) {
                    object4 = yP_Row2;
                } else {
                    Field field2 = this.dataContainerTechnique.merchant.getFieldByName(string);
                    if (field2 != null) {
                        object4 = yP_Row;
                    } else {
                        Field field3 = this.dataContainerTechnique.brand.getFieldByName(string);
                        if (field3 != null) {
                            object4 = list2;
                        } else {
                            Field field4 = this.dataContainerTechnique.contract.getFieldByName(string);
                            if (field4 != null) {
                                object4 = yP_Row3;
                            } else {
                                Field field5 = yP_Row4.getFieldByName(string);
                                if (field5 != null) {
                                    object4 = yP_Row4;
                                }
                            }
                        }
                    }
                }
                if (var30_41 != null && object4 != null) {
                    this.addFieldValue(yP_View, (Field)var30_41, (YP_Row)object4, string, (int)var21_24);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + (String)string);
            }
            ++var21_24;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    private YP_TCD_DesignAccesObject getDAO(YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("ContractInsideStore");
            if (yP_TCD_DesignAccesObject == null || !yP_TCD_DesignAccesObject.getSchemaName().contentEquals(string)) continue;
            return yP_TCD_DesignAccesObject;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving ContractInsideStore DAO");
        }
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("ContractInsideStore");
            if (yP_TCD_DesignAccesObject == null || string != null && !yP_TCD_DesignAccesObject.getFullTableName().startsWith(string)) continue;
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving ContractInsideStore DAO");
        }
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Key must not be set !");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                String string2 = yP_View.getFieldValueAt(n, "brandName");
                if (string2 == null || string2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:brandName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_Transaction, string2);
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() not really possible !!!");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)yP_TCD_DesignAccesObject.getFather();
                String string3 = null;
                String string4 = null;
                String string5 = null;
                for (String string6 : yP_View.getColumnSet()) {
                    String string7 = yP_View.getFieldValueAt(n, string6);
                    if (string7 == null) continue;
                    switch (string6) {
                        case "idContractInsideStore": {
                            if (string7.isEmpty()) break;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() Key should be empty :" + string6);
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "merchantName": {
                            string3 = string7;
                            break;
                        }
                        case "contractLabel": {
                            string4 = string7;
                            break;
                        }
                        case "storeIdentifier": {
                            string5 = string7;
                            break;
                        }
                        default: {
                            if (this.getLogLevel() < 2) break;
                            this.logger(2, "createInView() unknown field :" + string6);
                        }
                        case "brandName": 
                    }
                }
                if (string3 == null || string3.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:merchantName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string5 == null || string5.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:storeIdentifier");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string3.indexOf(95) != -1) {
                    String[] stringArray = string3.split("_");
                    if (stringArray.length == 2 && stringArray[0].contentEquals(string2)) {
                        string3 = stringArray[1];
                    } else {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() bad value for merchantName:" + string3);
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                        return -1;
                    }
                }
                ArrayList<Long> arrayList = new ArrayList<Long>();
                long l = 0L;
                boolean bl = false;
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_Transaction.getDataContainerTransaction().contextHandler.merchantContainers) {
                    if (!yP_TCD_DCC_Merchant.getContractIdentifier().contentEquals(String.valueOf(string2) + '_' + string3)) continue;
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                        String string8 = yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel");
                        if (string4 != null && !string4.isEmpty() && !string8.contentEquals(string4)) {
                            this.logger(4, "createInView() ignored " + string8);
                            continue;
                        }
                        this.logger(4, "createInView() contract to add " + string8);
                        arrayList.add(yP_TCD_DCC_Business.getIDContract());
                    }
                    l = yP_TCD_DCC_Brand.getIdStore(yP_TCD_DCC_Merchant.getIDMerchant(), string5);
                    bl = true;
                    break;
                }
                if (!bl) {
                    this.logger(2, "createInView() unable to find store :" + string5);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
                if (l <= 0L) {
                    this.logger(2, "createInView() unable to find store in accessList:" + string2 + " " + string3);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
                if (arrayList.isEmpty()) {
                    this.logger(3, "createInView() nothing found to add");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                try {
                    yP_TCD_DesignAccesObject.lock();
                    Iterator iterator = arrayList.iterator();
                    while (iterator.hasNext()) {
                        long l2 = (Long)iterator.next();
                        YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                        yP_Row.set("idContract", l2);
                        yP_Row.set("idStore", l);
                        if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) >= 0) continue;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() Not able to add row...");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    if (yP_TCD_DesignAccesObject.persist() < 0) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() Not able to save changes...");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                }
                finally {
                    yP_TCD_DesignAccesObject.unlock();
                }
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createInView() " + exception);
            }
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }
}

