/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.TerminalConfigStatusEnumeration;

public class YP_TCG_View_TerminalConfig
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_TerminalConfig(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_TerminalConfig";
    }

    @Override
    public String getVersion() {
        return "V1.3.9.10";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3 = this.dataContainerTechnique.getDesignAccesObject_ByName("Group");
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject4;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject2.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject4 = yP_TCD_DesignAccesObject2;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject4 = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject4 = this.dataContainerTechnique.brand;
                    } else {
                        field = yP_TCD_DesignAccesObject.getFieldByName(string);
                        if (field != null) {
                            yP_TCD_DesignAccesObject4 = yP_TCD_DesignAccesObject;
                        } else {
                            field = yP_TCD_DesignAccesObject3.getFieldByName(string);
                            if (field != null) {
                                yP_TCD_DesignAccesObject4 = yP_TCD_DesignAccesObject3;
                            } else {
                                if (this.getLogLevel() < 2) continue;
                                this.logger(2, "createEmptyView() unknown column:" + string);
                                continue;
                            }
                        }
                    }
                }
            }
            if (yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject4, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        List<YP_Row> exception;
        YP_ComplexGabarit yP_ComplexGabarit;
        long l2;
        Boolean bl;
        YP_View yP_View;
        block52: {
            yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
            if (yP_View == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() ");
                }
                return null;
            }
            YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
            if (yP_TCD_PosProtocol == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() No protocol...");
                }
                return null;
            }
            if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() bad interface");
                }
                return null;
            }
            YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
            int n = yP_PROT_IHM.getMaxRecords();
            if (n == 0) {
                return yP_View;
            }
            if (n < 0) {
                n = 1000;
            }
            ++n;
            int n2 = yP_PROT_IHM.getStartIndex();
            if (n2 < 0) {
                n2 = 0;
            } else {
                n += n2;
            }
            bl = null;
            l2 = 0L;
            List<YP_Gabarit> list3 = yP_PROT_IHM.getSearchGabarit();
            yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig"));
            if (list3 == null || list3.isEmpty()) break block52;
            for (YP_Gabarit object2 : list3) {
                try {
                    if (object2.objectTosearch == null) {
                        yP_ComplexGabarit.set(object2.fieldName, object2.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(object2);
                    if (object2.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(object2.fieldName, object2.operator, object2.objectTosearch);
                    switch (object2.fieldName) {
                        case "testVersion": {
                            if (object2.objectTosearch instanceof Boolean) {
                                bl = (Boolean)object2.objectTosearch;
                                break;
                            }
                            bl = UtilsYP.parseBoolean((String)object2.objectTosearch);
                            break;
                        }
                        case "idTerminalReference": {
                            l2 = Long.parseLong((String)object2.objectTosearch);
                        }
                    }
                }
                catch (Exception exception2) {
                    this.logger(2, "getView() " + exception2);
                }
            }
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("Group");
        ArrayList<Long> arrayList = new ArrayList<Long>();
        for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_Transaction.getMerchantList()) {
            arrayList.add(yP_TCD_DCC_Merchant.getIDMerchant());
        }
        if (bl != null && l2 > 0L && arrayList.size() == 1) {
            exception = this.dataContainerTechnique.getTerminalConfigList(bl, l2, (Long)arrayList.get(0));
        } else {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig");
            exception = yP_TCD_DesignAccesObject3.getRowListSuchAs(yP_ComplexGabarit);
            if (exception != null) {
                void var21_22;
                int n = exception.size() - 1;
                while (var21_22 >= 0) {
                    Object object = this.dataContainerTechnique.getTerminalConfigStatus(yP_Transaction, exception.get((int)var21_22).getPrimaryKey());
                    if (object != TerminalConfigStatusEnumeration.ACTIVE && object != TerminalConfigStatusEnumeration.DEFAULT) {
                        exception.remove((int)var21_22);
                    }
                    --var21_22;
                }
            }
        }
        if (exception == null) {
            this.logger(2, "getView() null list ");
            return null;
        }
        if (exception.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n = -1;
        for (YP_Row yP_Row : exception) {
            long l3;
            long l4;
            long l5;
            void var20_29;
            ++var20_29;
            YP_Row yP_Row2 = null;
            YP_Row yP_Row3 = null;
            YP_Row yP_Row4 = null;
            YP_Row yP_Row5 = null;
            long l6 = (Long)yP_Row.getFieldValueByName("idMerchant");
            if (l6 > 0L) {
                yP_Row2 = this.dataContainerTechnique.merchant.getRowByPrimaryKey(l6);
            }
            if ((l5 = ((Long)yP_Row.getFieldValueByName("idBrand")).longValue()) > 0L) {
                yP_Row3 = this.dataContainerTechnique.brand.getRowByPrimaryKey(l5);
            }
            if ((l4 = ((Long)yP_Row.getFieldValueByName("idGroup")).longValue()) > 0L) {
                yP_Row4 = yP_TCD_DesignAccesObject2.getRowByPrimaryKey(l4);
            }
            if ((l3 = ((Long)yP_Row.getFieldValueByName("idTerminalReference")).longValue()) > 0L) {
                yP_Row5 = yP_TCD_DesignAccesObject.getRowByPrimaryKey(l3);
            }
            yP_View.setRowID((int)var20_29, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            if (this.isActionable(yP_TCD_DCC_Interface_View, yP_Transaction, yP_Row, yP_View, l)) {
                yP_View.setRowActionable((int)var20_29, true);
                if (exception.size() == 1) {
                    this.addActionList(yP_Transaction, yP_Row, yP_View, (int)var20_29);
                }
            } else {
                yP_View.setRowActionable((int)var20_29, false);
            }
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = yP_Row.getFieldByName(string);
                YP_Row yP_Row6 = null;
                if (field != null) {
                    yP_Row6 = yP_Row;
                } else {
                    field = this.dataContainerTechnique.merchant.getFieldByName(string);
                    if (field != null) {
                        yP_Row6 = yP_Row2;
                    } else {
                        field = this.dataContainerTechnique.brand.getFieldByName(string);
                        if (field != null) {
                            yP_Row6 = yP_Row3;
                        } else {
                            field = yP_TCD_DesignAccesObject2.getFieldByName(string);
                            if (field != null) {
                                yP_Row6 = yP_Row4;
                            } else {
                                field = yP_TCD_DesignAccesObject.getFieldByName(string);
                                if (field != null) {
                                    if (yP_Row5 == null) continue;
                                    yP_Row6 = yP_Row5;
                                }
                            }
                        }
                    }
                }
                if (field != null && yP_Row6 != null) {
                    this.addFieldValue(yP_View, field, yP_Row6, string, (int)var20_29);
                    continue;
                }
                if (field != null) continue;
                this.logger(2, "getView() unknown column:" + string);
            }
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig");
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    this.logger(2, "createInView() Key must not be set !");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    this.logger(2, "createInView() not really possible !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                block38: for (String string2 : yP_View.getColumnSet()) {
                    String string3 = yP_View.getFieldValueAt(n, string2);
                    if (string3 == null) continue;
                    switch (string2) {
                        case "idTerminalConfig": {
                            if (string3.isEmpty()) continue block38;
                            this.logger(2, "createInView() Key should be empty :" + string2);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "brandName": {
                            break;
                        }
                        case "merchantName": {
                            break;
                        }
                        case "pinpadScreenSaverName": 
                        case "appCBTerminalVersion": 
                        case "biosVersion": 
                        case "idTerminalReference": 
                        case "level2CTLURL": 
                        case "appHandlerTerminalURL": 
                        case "idUser": 
                        case "level2ICCURL": 
                        case "kernelVersion": 
                        case "updateMode": 
                        case "appCBTerminalURL": 
                        case "biosURL": 
                        case "testVersion": 
                        case "idMerchant": 
                        case "level2CTLVersion": 
                        case "appHandlerTerminalVersion": 
                        case "screenSaverName": 
                        case "configName": 
                        case "kernelURL": 
                        case "level2ICCVersion": 
                        case "pinpadScreenSaverURL": 
                        case "idBrand": 
                        case "idGroup": 
                        case "screenSaverURL": {
                            yP_Row.set(string2, string3);
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string2);
                        }
                    }
                }
                yP_Row.setIsItAClonedRow(false);
                yP_Row.persist();
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() " + exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    private void addActionList(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_View yP_View, int n) {
    }

    private boolean isActionable(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_Row yP_Row, YP_View yP_View, long l) {
        return false;
    }
}

