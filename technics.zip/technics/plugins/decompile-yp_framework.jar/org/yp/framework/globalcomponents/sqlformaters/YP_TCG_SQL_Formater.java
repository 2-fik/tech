/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.sqlformaters;

import java.lang.reflect.Field;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;

public interface YP_TCG_SQL_Formater {
    public String getContractKeyClause(YP_TCD_DesignAccesObject var1);

    public String getContractKeyClauseUsedForGlobalTransaction(YP_TCD_DesignAccesObject var1);

    public String sqlSchemaName(YP_TCD_DesignAccesObject var1);

    public String sqlFullTableName(YP_TCD_DesignAccesObject var1);

    public String sqlFullSlaveTableName(YP_TCD_DAO_SQL_Transaction var1);

    public String sqlFullMasterTableName(YP_TCD_DAO_SQL_Transaction var1);

    public String sqlValue(Object var1);

    public String sqlIF();

    public String sqlColumnName(String var1);

    public String sqlDate(String var1);

    public String sqlUser();

    public int updateRow(YP_TCD_DesignAccesObject var1, YP_Row var2);

    public int updateRowSuchAs(YP_TCD_DesignAccesObject var1, YP_Row var2, int var3, YP_ComplexGabarit ... var4);

    public int deleteRow(YP_TCD_DesignAccesObject var1, YP_Row var2);

    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject var1, YP_ComplexGabarit ... var2);

    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject var1, String var2);

    public int createRow(YP_TCD_DesignAccesObject var1, YP_Row var2);

    public int sqlCreateTable(YP_TCD_DesignAccesObject var1, boolean var2);

    public int sqlEmptyTable(YP_TCD_DesignAccesObject var1);

    public int sqlFillTable(YP_TCD_DAO_LOC var1);

    public int sqlUpdateRowList(YP_TCD_DesignAccesObject var1, List<YP_Row> var2);

    public YP_Row selectFromWhere(YP_TCD_DataBaseConnector var1, YP_TCD_DAO_SQL_Transaction var2, String var3, String var4, long var5);

    public int sqlReloadMemory(YP_TCD_DAO_LOC_Memory var1);

    public int sqlReloadTable(YP_TCD_DAO_LOC_Table var1);

    public List<YP_Row> sqlSelectSuchAs(YP_TCD_DesignAccesObject var1, int var2, int var3, YP_ComplexGabarit ... var4);

    public int sqlSelectCount(YP_TCD_DesignAccesObject var1);

    public List<YP_Row> sqlSelectSuchAsForSlave(YP_TCD_DAO_SQL_Transaction var1, int var2, int var3, YP_ComplexGabarit ... var4);

    public List<YP_Row> sqlSelectSuchAsForTransaction(YP_TCD_DAO_SQL_Transaction var1, YP_TCD_DesignAccesObject var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public int sqlSelectCountSuchAsForSlave(YP_TCD_DAO_SQL_Transaction var1, YP_ComplexGabarit ... var2);

    public int sqlSelectCountSuchAs(YP_TCD_DesignAccesObject var1, YP_ComplexGabarit ... var2);

    public YP_Row sqlSelectOne(YP_TCD_DesignAccesObject var1, int var2);

    public YP_Row sqlSelectRowForSlave(YP_TCD_DAO_SQL_Transaction var1, long var2);

    public YP_Row sqlSelectRow(YP_TCD_DesignAccesObject var1, long var2);

    public long sqlSelectSumSuchAsForSlave(YP_TCD_DAO_SQL_Transaction var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public long sqlSelectSumSuchAs(YP_TCD_DesignAccesObject var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public List<String> getDistinctStringValueListSuchAs(YP_TCD_DesignAccesObject var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public List<String> getDistinctStringValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public List<Object> getDistinctValueListSuchAs(YP_TCD_DesignAccesObject var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public String getDistinctValueListSuchAsRequestSQL(YP_TCD_DesignAccesObject var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public List<Object> getDistinctValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction var1, String var2, int var3, int var4, YP_ComplexGabarit ... var5);

    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction var1, YP_TCD_DesignAccesObject var2, YP_ComplexGabarit ... var3);

    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction var1, YP_TCD_DesignAccesObject var2, String var3);

    public void resetCache(String var1);

    public List<YP_Row> selectFrom(YP_TCD_DataBaseConnector var1, YP_TCD_DAO_SQL_Transaction var2, String var3, int var4, int var5);

    public int deleteFromWhere(YP_TCD_DesignAccesObject var1, YP_TCD_DataBaseConnector var2, String var3, String var4, long[] var5);

    public boolean isSlaveTransactionEmpty(YP_TCD_DataBaseConnector var1, List<YP_TCD_DAO_SQL_Transaction> var2) throws Exception;

    public void appendSQLColumnName(StringBuilder var1, String var2, String var3);

    public void appendSQLColumnName(StringBuilder var1, String var2);

    public int sqlBatchDelete(YP_TCD_DAO_LOC var1, Field[] var2);

    public int sqlBatchUpdate(YP_TCD_DAO_LOC var1, Field[] var2, Field[] var3);
}

