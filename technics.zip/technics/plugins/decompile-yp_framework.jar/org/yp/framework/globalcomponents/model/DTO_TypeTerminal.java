/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

public class DTO_TypeTerminal {
    @SerializedName(value="code")
    private String code = null;
    @SerializedName(value="id")
    private Integer id = null;
    @SerializedName(value="libelle")
    private String libelle = null;

    public DTO_TypeTerminal code(String string) {
        this.code = string;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String string) {
        this.code = string;
    }

    public DTO_TypeTerminal id(Integer n) {
        this.id = n;
        return this;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer n) {
        this.id = n;
    }

    public DTO_TypeTerminal libelle(String string) {
        this.libelle = string;
        return this;
    }

    public String getLibelle() {
        return this.libelle;
    }

    public void setLibelle(String string) {
        this.libelle = string;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_TypeTerminal dTO_TypeTerminal = (DTO_TypeTerminal)object;
        return Objects.equals(this.code, dTO_TypeTerminal.code) && Objects.equals(this.id, dTO_TypeTerminal.id) && Objects.equals(this.libelle, dTO_TypeTerminal.libelle);
    }

    public int hashCode() {
        return Objects.hash(this.code, this.id, this.libelle);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class TypeTerminalDto {\n");
        stringBuilder.append("    code: ").append(this.toIndentedString(this.code)).append("\n");
        stringBuilder.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        stringBuilder.append("    libelle: ").append(this.toIndentedString(this.libelle)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

