/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.sqlformaters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.designaccesobjects.Identity;
import org.yp.designaccesobjects.Partition;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_PreparedValue;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.globalcomponents.sqlformaters.YP_TCG_SQL_Formater;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Memory;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Disk;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.Bitmap;
import org.yp.utils.UtilsYP;

public class YP_TCG_SQLSERVER_Formater
extends YP_GlobalComponent
implements YP_TCG_SQL_Formater {
    private static final char FIELD_START = '[';
    private static final String FIELD_MID = "].[";
    private static final char FIELD_END = ']';
    private boolean partitionDeactivated = false;
    private boolean preparedStatementDeactivated = false;
    private static final String PROPERTY_PARTITION_DEACTIVATED = "partitionDeactivated";
    private static final String PROPERTY_PREPARED_STATEMENT_DEACTIVATED = "preparedStatementDeactivated";
    private static final ReentrantLock mutexCreateTable = new ReentrantLock();
    private static final String DATABASENAME_PROPERTY = "databaseName=";

    public YP_TCG_SQLSERVER_Formater(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        String string = this.getProperty(this.getPropertyFileName(), PROPERTY_PARTITION_DEACTIVATED);
        if (string != null && !string.isEmpty()) {
            this.partitionDeactivated = UtilsYP.parseBoolean(string);
        }
        if (this.partitionDeactivated) {
            this.logger(4, "initialize() partitions are deactivated");
        } else {
            this.logger(4, "initialize() partitions are activated");
        }
        string = this.getProperty(this.getPropertyFileName(), PROPERTY_PREPARED_STATEMENT_DEACTIVATED);
        if (string != null && !string.isEmpty()) {
            this.preparedStatementDeactivated = UtilsYP.parseBoolean(string);
        }
        if (this.preparedStatementDeactivated) {
            this.logger(4, "initialize() prepared statements are deactivated");
        } else {
            this.logger(4, "initialize() prepared statements are activated");
            this.preparedStatementDeactivated = false;
        }
        return super.initialize();
    }

    @Override
    public String toString() {
        return "SQLSERVER_Formater";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        if (this.getLogLevel() >= 2) {
            this.logger(2, "dealRequest() unhnwown request: " + string);
        }
        return null;
    }

    private void appendColumnList(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, StringBuilder stringBuilder) {
        boolean bl = true;
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            Field field = fieldArray[n2];
            if (bl) {
                bl = false;
            } else {
                stringBuilder.append(',');
            }
            this.appendSQLColumnName(stringBuilder, field.getName());
            ++n2;
        }
    }

    private String getVarType(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, Field field) {
        block24: {
            block26: {
                block25: {
                    Object object;
                    block23: {
                        block22: {
                            block21: {
                                block20: {
                                    block19: {
                                        block18: {
                                            object = yP_Row.getFieldValue(field);
                                            if (!(object instanceof Timestamp)) break block18;
                                            return "datetime NOT NULL DEFAULT ('1970-01-01 00:00:00.000')";
                                        }
                                        if (!(object instanceof Date)) break block19;
                                        return "date NOT NULL DEFAULT ('1970-01-01')";
                                    }
                                    if (!(object instanceof Integer)) break block20;
                                    return "int NOT NULL DEFAULT ((0))";
                                }
                                if (!(object instanceof Long)) break block21;
                                return "bigint NOT NULL DEFAULT ((0))";
                            }
                            if (object instanceof byte[]) {
                                int n = ((byte[])object).length;
                                return "varchar(" + String.valueOf(n) + ") NOT NULL DEFAULT ('')";
                            }
                            if (!(object instanceof Float)) break block22;
                            return "float NOT NULL DEFAULT ((0))";
                        }
                        if (!(object instanceof Boolean)) break block23;
                        return "bit NULL DEFAULT (NULL)";
                    }
                    try {
                        if (object instanceof Enum) {
                            Enum[] enumArray = (Enum[])field.getType().getEnumConstants();
                            int n = 1;
                            Enum[] enumArray2 = enumArray;
                            int n2 = enumArray.length;
                            int n3 = 0;
                            while (n3 < n2) {
                                Enum enum_ = enumArray2[n3];
                                String string = enum_.toString();
                                if (string.length() > n) {
                                    n = string.length();
                                }
                                ++n3;
                            }
                            return "varchar(" + n + ") NULL DEFAULT (NULL)";
                        }
                        if (object != null) break block24;
                        if (field.getType().isEnum()) {
                            Enum[] enumArray = (Enum[])field.getType().getEnumConstants();
                            int n = 1;
                            Enum[] enumArray3 = enumArray;
                            int n4 = enumArray.length;
                            int n5 = 0;
                            while (n5 < n4) {
                                Enum enum_ = enumArray3[n5];
                                String string = enum_.toString();
                                if (string.length() > n) {
                                    n = string.length();
                                }
                                ++n5;
                            }
                            return "varchar(" + n + ") NULL DEFAULT (NULL)";
                        }
                        if (field.getType() != Boolean.class) break block25;
                        return "bit NULL DEFAULT (NULL)";
                    }
                    catch (Exception exception) {
                        this.logger(2, "getVarType() : " + exception);
                        return null;
                    }
                }
                if (field.getType() != Bitmap.class) break block26;
                return "bigint NULL DEFAULT (NULL)";
            }
            this.logger(2, "getVarType() : unknown type ");
            return null;
        }
        this.logger(2, "getVarType() : unknown type ");
        return null;
    }

    private String getVarTypeForPrimaryKey(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, Field field) {
        block16: {
            Object object;
            block15: {
                block14: {
                    block13: {
                        block12: {
                            block11: {
                                block10: {
                                    try {
                                        object = yP_Row.getFieldValue(field);
                                        if (!(object instanceof Timestamp)) break block10;
                                        return "datetime not null";
                                    }
                                    catch (Exception exception) {
                                        this.logger(2, "getVarTypeForPrimaryKey() : " + exception);
                                        return null;
                                    }
                                }
                                if (!(object instanceof Date)) break block11;
                                return "date not null";
                            }
                            if (!(object instanceof Integer)) break block12;
                            return "int not null";
                        }
                        if (!(object instanceof Long)) break block13;
                        return "bigint not null";
                    }
                    if (object instanceof byte[]) {
                        int n = ((byte[])object).length;
                        return "character varying(" + String.valueOf(n) + ") not null";
                    }
                    if (!(object instanceof Float)) break block14;
                    return "float not null";
                }
                if (!(object instanceof Boolean)) break block15;
                this.logger(2, "getVarTypeForPrimaryKey() : bad type for primary key");
                return null;
            }
            if (!(object instanceof Bitmap)) break block16;
            this.logger(2, "getVarTypeForPrimaryKey() : bad type for primary key");
            return null;
        }
        this.logger(2, "getVarTypeForPrimaryKey() : unknown type ");
        return null;
    }

    @Override
    public String sqlValue(Object object) {
        if (object instanceof Object[]) {
            StringBuilder stringBuilder = new StringBuilder();
            Object[] objectArray = (Object[])object;
            int n = 0;
            while (n < objectArray.length) {
                if (n != 0) {
                    stringBuilder.append(',');
                }
                stringBuilder.append(this.sqlValue(objectArray[n]));
                ++n;
            }
            return stringBuilder.toString();
        }
        String string = YP_Row.getStringValue(object);
        if (string == null) {
            return null;
        }
        string = string.trim();
        if (!(object instanceof Integer) && !(object instanceof Long)) {
            if (object instanceof byte[] || object instanceof String || object instanceof Enum) {
                if (string.indexOf("'") != -1) {
                    string = string.replace("'", "''");
                }
                string = String.valueOf('\'') + string + '\'';
            } else if (object instanceof Timestamp) {
                string = String.valueOf('\'') + string + '\'';
            } else if (object instanceof Date) {
                string = String.valueOf('\'') + string + '\'';
            } else if (!(object instanceof Float) && !(object instanceof Bitmap)) {
                if (object instanceof Boolean) {
                    if (((Boolean)object).booleanValue()) {
                        string = "1";
                    } else if (!((Boolean)object).booleanValue()) {
                        string = "0";
                    }
                } else {
                    this.logger(2, "sqlValue() : unknown type ");
                    return null;
                }
            }
        }
        return string;
    }

    @Override
    public String sqlIF() {
        return "IIF";
    }

    @Override
    public String sqlUser() {
        return "SYSTEM_USER";
    }

    @Override
    public String sqlColumnName(String string) {
        return String.valueOf('[') + string + ']';
    }

    @Override
    public String sqlDate(String string) {
        return "FORMAT(" + string + ", 'yyyy-MM-dd')";
    }

    private int appendSQLValue(StringBuilder stringBuilder, Object object) {
        String string = YP_Row.getStringValue(object);
        if (string == null) {
            stringBuilder.append("null");
            return 1;
        }
        string = string.trim();
        if (object instanceof Integer) {
            stringBuilder.append(string);
        } else if (object instanceof Long) {
            stringBuilder.append(string);
        } else if (object instanceof byte[] || object instanceof String || object instanceof Enum) {
            stringBuilder.append('\'');
            if (string.indexOf("'") != -1) {
                string = string.replace("'", "''");
            }
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Timestamp) {
            stringBuilder.append('\'');
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Date) {
            stringBuilder.append('\'');
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Float) {
            stringBuilder.append(string);
        } else if (object instanceof Boolean) {
            if (((Boolean)object).booleanValue()) {
                stringBuilder.append("1");
            } else if (!((Boolean)object).booleanValue()) {
                stringBuilder.append("0");
            }
        } else if (object instanceof Bitmap) {
            stringBuilder.append(string);
        } else if (object == null) {
            stringBuilder.append("null");
        } else {
            this.logger(2, "appendSQLValue() : unknown type ");
            return -1;
        }
        return 1;
    }

    @Override
    public int updateRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UPDATE ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append(" SET ");
        String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        boolean bl = true;
        int n = 0;
        while (n < fieldArray.length) {
            try {
                String string2 = fieldArray[n].getName();
                if (string2.compareTo(string) != 0) {
                    if (!bl) {
                        stringBuilder.append(',');
                    } else {
                        bl = false;
                    }
                    stringBuilder.append(' ');
                    this.appendSQLColumnName(stringBuilder, string2);
                    stringBuilder.append('=');
                    this.appendSQLValue(stringBuilder, yP_Row.getFieldValue(fieldArray[n]));
                }
            }
            catch (Exception exception) {
                this.logger(2, "updateRow() : " + exception);
            }
            ++n;
        }
        stringBuilder.append(" WHERE ");
        this.appendSQLColumnName(stringBuilder, string);
        stringBuilder.append('=');
        stringBuilder.append(yP_Row.getPrimaryKey());
        String string3 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
        if (string3 != null && !string3.isEmpty()) {
            stringBuilder.append(" AND");
            stringBuilder.append(string3);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "updateRow() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    @Override
    public int updateRowSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, int n, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        String string;
        String string2;
        block8: {
            block7: {
                try {
                    string2 = this.sqlGetSet(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_Row);
                    if (string2 != null && string2.length() != 0) break block7;
                    this.logger(2, "updateRowSuchAs() modification empty: ");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "updateRowSuchAs() : " + exception);
                    return -1;
                }
            }
            string = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string != null && string.length() != 0) break block8;
            this.logger(2, "updateRowSuchAs() condition empty:  ");
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (n > 0) {
            stringBuilder.append(";WITH CTE AS\r\n");
            stringBuilder.append("(\r\n");
            stringBuilder.append("SELECT TOP ");
            stringBuilder.append(n);
            stringBuilder.append(" *\r\n");
            stringBuilder.append("FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(" \r\n");
            stringBuilder.append(string);
            stringBuilder.append(") \r\n");
            stringBuilder.append("UPDATE CTE SET ");
            stringBuilder.append(string2);
        } else {
            stringBuilder.append("UPDATE ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(" SET ");
            stringBuilder.append(string2);
            stringBuilder.append(string);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "updateRowSuchAs() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public int deleteRow(YP_TCD_DesignAccesObject var1_1, YP_Row var2_2) {
        block24: {
            block17: {
                var3_3 = new StringBuilder();
                var3_3.append("DELETE FROM ");
                var3_3.append(var1_1.getFullTableName());
                var3_3.append(" WHERE ");
                var4_4 = var2_2.getPrimaryKey();
                if (var4_4 != -1L) break block17;
                var6_5 = var1_1.getFieldList();
                var7_6 = true;
                var8_7 = this.getContractKeyClause(var1_1);
                if (var8_7 != null && !var8_7.isEmpty()) {
                    var3_3.append(var8_7);
                }
                var9_8 = 0;
                while (var9_8 < var6_5.length) {
                    block16: {
                        try {
                            block23: {
                                block22: {
                                    block21: {
                                        block20: {
                                            block19: {
                                                block18: {
                                                    var10_9 = var2_2.getFieldValue(var6_5[var9_8]);
                                                    if (var10_9 == null) break block16;
                                                    if (!(var10_9 instanceof Integer)) break block18;
                                                    if ((Integer)var10_9 == 0) {
                                                        break block16;
                                                    }
                                                    ** GOTO lbl-1000
                                                }
                                                if (!(var10_9 instanceof Long)) break block19;
                                                if ((Long)var10_9 == 0L) {
                                                    break block16;
                                                }
                                                ** GOTO lbl-1000
                                            }
                                            if (!(var10_9 instanceof byte[])) break block20;
                                            if (((byte[])var10_9).length == 0 || ((byte[])var10_9)[0] == 0) {
                                                break block16;
                                            }
                                            ** GOTO lbl-1000
                                        }
                                        if (!(var10_9 instanceof Timestamp)) break block21;
                                        if (((Timestamp)var10_9).getTime() == 0L) {
                                            break block16;
                                        }
                                        ** GOTO lbl-1000
                                    }
                                    if (!(var10_9 instanceof Date)) break block22;
                                    if (((Date)var10_9).getTime() == 0L) {
                                        break block16;
                                    }
                                    ** GOTO lbl-1000
                                }
                                if (!(var10_9 instanceof Float)) break block23;
                                if (((Float)var10_9).floatValue() == 0.0f) {
                                    break block16;
                                }
                                ** GOTO lbl-1000
                            }
                            if (!(var10_9 instanceof Boolean) && !(var10_9 instanceof Enum)) {
                                this.logger(2, "deleteRow() unknown type");
                            } else lbl-1000:
                            // 7 sources

                            {
                                if (!var7_6) {
                                    var3_3.append(" AND");
                                } else {
                                    var7_6 = false;
                                }
                                var3_3.append(' ');
                                this.appendSQLColumnName(var3_3, var6_5[var9_8].getName());
                                var3_3.append('=');
                                this.appendSQLValue(var3_3, var10_9);
                            }
                        }
                        catch (Exception v0) {}
                    }
                    ++var9_8;
                }
                if (var7_6) {
                    this.logger(2, "deleteRow() : row without key and without gabarit...");
                    return -1;
                }
                break block24;
            }
            this.appendSQLColumnName(var3_3, var1_1.getPrimaryKeyName());
            var3_3.append('=');
            var3_3.append(var2_2.getPrimaryKey());
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "deleteRow() : " + var3_3);
        }
        return var1_1.getDataBaseConnector().dealUpdate(var1_1, var3_3.toString());
    }

    @Override
    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        StringBuilder stringBuilder;
        block6: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("DELETE ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                if (string != null && string.length() != 0) break block6;
                this.logger(2, "deleteRowsSuchAs() condition empty: ");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "deleteRowSuchAs() : " + exception);
                return -1;
            }
        }
        stringBuilder.append(string);
        String string2 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
        if (string2 != null && !string2.isEmpty()) {
            if (string != null && string.length() > 0) {
                stringBuilder.append(" AND");
            }
            stringBuilder.append(string2);
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "deleteRowSuchAs() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    @Override
    public int deleteRowsSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            return this.deleteRowsSuchAs(yP_TCD_DesignAccesObject, this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray));
        }
        catch (Exception exception) {
            this.logger(2, "deleteRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int createRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row) {
        Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
        if (fieldArray.length == 0) {
            return -1;
        }
        long l = yP_Row.getPrimaryKey();
        if (l == 0L) {
            yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
        }
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder.append("INSERT INTO ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append('(');
        stringBuilder2.append(" VALUES (");
        boolean bl = true;
        Field[] fieldArray2 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block8: {
                Field field = fieldArray2[n2];
                try {
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                        stringBuilder2.append(',');
                    }
                    this.appendSQLColumnName(stringBuilder, field.getName());
                    this.appendSQLValue(stringBuilder2, yP_Row.getFieldValue(field));
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 5) break block8;
                    this.logger(5, "createRow() : " + exception);
                }
            }
            ++n2;
        }
        stringBuilder.append(')');
        stringBuilder2.append(')');
        stringBuilder.append((CharSequence)stringBuilder2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "createRow() : " + stringBuilder);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealCreate(stringBuilder.toString(), yP_TCD_DesignAccesObject);
    }

    private void sqlCreateManagementTriggers(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, String string) {
        String string2 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CREATE TRIGGER ");
        stringBuilder.append(this.sqlSchemaName(yP_TCD_DesignAccesObject));
        stringBuilder.append(".");
        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
        stringBuilder.append("_tg");
        stringBuilder.append(n);
        stringBuilder.append("\r\n");
        stringBuilder.append("ON ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append("\r\n");
        stringBuilder.append("AFTER ");
        stringBuilder.append(string);
        stringBuilder.append("\r\n");
        stringBuilder.append("AS\r\n");
        stringBuilder.append("SET XACT_ABORT OFF;-- to prevent trigger to abort if line is already there \r\n");
        if (yP_TCD_DesignAccesObject.getTableName().contentEquals("ApplicationTableInfo")) {
            stringBuilder.append("IF SYSTEM_USER <> '");
            stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().getDBC_User());
            stringBuilder.append("'\r\n");
            stringBuilder.append("BEGIN\r\n");
        }
        stringBuilder.append("\tBEGIN TRY\r\n");
        stringBuilder.append("\t\tINSERT INTO [events].[ManagementEvent] ([DB_Name], [DB_Table], [timestamp], [user], [primaryKeyValue], [changeType])\r\n");
        stringBuilder.append("\t\tSELECT '");
        stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
        stringBuilder.append("', '");
        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
        stringBuilder.append("', GetDate(), SYSTEM_USER, ");
        if (string.contentEquals("DELETE")) {
            stringBuilder.append("deleted");
        } else {
            stringBuilder.append("inserted");
        }
        stringBuilder.append('.');
        stringBuilder.append(string2);
        stringBuilder.append(", '");
        stringBuilder.append(string);
        stringBuilder.append("'\r\n");
        stringBuilder.append("\t\tFROM ");
        if (string.contentEquals("DELETE")) {
            stringBuilder.append("deleted");
        } else {
            stringBuilder.append("inserted");
        }
        stringBuilder.append("\r\n");
        stringBuilder.append("\tEND TRY\r\n");
        stringBuilder.append("\tBEGIN CATCH\r\n");
        stringBuilder.append("\t\t--needed even if empty\r\n");
        stringBuilder.append("\tEND CATCH\r\n");
        if (yP_TCD_DesignAccesObject.getTableName().contentEquals("ApplicationTableInfo")) {
            stringBuilder.append("END\r\n");
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlCreateTriggers() : " + stringBuilder.toString());
        }
        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
    }

    private void sqlCreateTriggers(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, boolean bl) {
        StringBuilder stringBuilder;
        if ((yP_TCD_DesignAccesObject.getTableType() & 4) != 0 || (yP_TCD_DesignAccesObject.getTableType() & 2) != 0 || (yP_TCD_DesignAccesObject.getTableType() & 0x200) != 0 || (yP_TCD_DesignAccesObject.getTableType() & 8) != 0) {
            return;
        }
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            if (UtilsYP.getInstanceRole() == 1 || UtilsYP.getInstanceRole() == 3) {
                return;
            }
        } else {
            boolean cfr_ignored_0 = yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Disk;
        }
        if (!bl) {
            List<String> list;
            stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT t.name\r\n");
            stringBuilder.append("FROM sys.triggers t\r\n");
            stringBuilder.append("\tLEFT JOIN sys.all_objects o\r\n");
            stringBuilder.append("\t\tON t.parent_id = o.object_id\r\n");
            stringBuilder.append("\tLEFT JOIN sys.schemas s\r\n");
            stringBuilder.append("\t\tON s.schema_id = o.schema_id\r\n");
            stringBuilder.append("WHERE s.name = '");
            stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
            stringBuilder.append("'\r\n");
            stringBuilder.append("  AND t.name like '");
            stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
            stringBuilder.append("_tg%'");
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlCreateTriggers() : " + stringBuilder.toString());
            }
            if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealStringListQuery(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null) {
                for (String string : list) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("DROP TRIGGER ");
                    stringBuilder2.append(this.sqlSchemaName(yP_TCD_DesignAccesObject));
                    stringBuilder2.append(".");
                    stringBuilder2.append(string);
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTriggers() : " + stringBuilder2.toString());
                    }
                    yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder2.toString());
                }
            }
        }
        if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            if ((UtilsYP.getTriggerMode() & 4) != 0) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("CREATE TRIGGER ");
                stringBuilder.append(this.sqlSchemaName(yP_TCD_DesignAccesObject));
                stringBuilder.append(".");
                stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                stringBuilder.append("_tg1\r\n");
                stringBuilder.append("ON ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                stringBuilder.append("\r\n");
                stringBuilder.append("AFTER INSERT\r\n");
                stringBuilder.append("AS\r\n");
                stringBuilder.append("SET XACT_ABORT OFF;-- to prevent trigger to abort if line is already there \r\n");
                stringBuilder.append("BEGIN TRY\r\n");
                stringBuilder.append("\tINSERT INTO [events].[TransactionSlaveEvent] ([DB_Name], [DB_Table]) VALUES ('");
                stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
                stringBuilder.append("', '");
                stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                stringBuilder.append("')\r\n");
                stringBuilder.append("END TRY \r\n");
                stringBuilder.append("BEGIN CATCH\r\n");
                stringBuilder.append("\t--needed even if empty\r\n");
                stringBuilder.append("END CATCH\r\n");
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "sqlCreateTriggers() : " + stringBuilder.toString());
                }
                yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
            }
        } else if (yP_TCD_DesignAccesObject.getSchemaName().contentEquals("management")) {
            if ((UtilsYP.getTriggerMode() & 1) != 0) {
                this.sqlCreateManagementTriggers(yP_TCD_DesignAccesObject, 1, "INSERT");
                this.sqlCreateManagementTriggers(yP_TCD_DesignAccesObject, 2, "UPDATE");
                this.sqlCreateManagementTriggers(yP_TCD_DesignAccesObject, 3, "DELETE");
            }
        } else if ((UtilsYP.getTriggerMode() & 2) != 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("CREATE TRIGGER ");
            stringBuilder.append(this.sqlSchemaName(yP_TCD_DesignAccesObject));
            stringBuilder.append(".");
            stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
            stringBuilder.append("_tg1\r\n");
            stringBuilder.append("ON ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append("\r\n");
            stringBuilder.append("AFTER INSERT, UPDATE , DELETE\r\n");
            stringBuilder.append("AS\r\n");
            stringBuilder.append("SET XACT_ABORT OFF;-- to prevent trigger to abort if line is already there \r\n");
            stringBuilder.append("IF SYSTEM_USER <> '");
            stringBuilder.append(yP_TCD_DesignAccesObject.getDataBaseConnector().getDBC_User());
            stringBuilder.append("'\r\n");
            stringBuilder.append("BEGIN\r\n");
            stringBuilder.append("\tBEGIN TRY\r\n");
            stringBuilder.append("\t\tINSERT INTO [events].[applicationEvent] ([DB_Name], [DB_Table]) VALUES ('");
            stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
            stringBuilder.append("', '");
            stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
            stringBuilder.append("')\r\n");
            stringBuilder.append("\tEND TRY \r\n");
            stringBuilder.append("\tBEGIN CATCH\r\n");
            stringBuilder.append("\t\t--needed even if empty\r\n");
            stringBuilder.append("\tEND CATCH\r\n");
            stringBuilder.append("END\r\n");
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlCreateTriggers() : " + stringBuilder.toString());
            }
            yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
    }

    @Override
    public void resetCache(String string) {
        UtilsYP.deleteDirectory(new File(String.valueOf(UtilsYP.getCachePath()) + string + "/"));
    }

    @Override
    public int sqlCreateTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, boolean bl) {
        int n = yP_TCD_DesignAccesObject.getDataBaseConnector().getSiteIdentifier();
        if (n != UtilsYP.getInstanceNumber()) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlCreateTable() : don't create the table of foreign databases");
            }
            if (bl) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlCreateTable() : create table needed but forbidden!!!");
                }
                return -1;
            }
            return 0;
        }
        if (UtilsYP.getInstanceRole() == 1) {
            if (bl || this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) {
                try {
                    mutexCreateTable.lock();
                    this.sqlCreateTableWithName(yP_TCD_DesignAccesObject);
                }
                finally {
                    mutexCreateTable.unlock();
                }
            }
        } else if (UtilsYP.getInstanceRole() == 2) {
            if ((yP_TCD_DesignAccesObject.getTableType() & 4) == 0 && (yP_TCD_DesignAccesObject.getTableType() & 2) == 0 && !(yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction)) {
                block36: {
                    StringBuilder stringBuilder;
                    block35: {
                        if (bl) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table asked but forbidden on slave !!!");
                            }
                            return -1;
                        }
                        if (!this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) {
                            return 0;
                        }
                        try {
                            stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject), 0);
                            if (stringBuilder != null) break block35;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table needed but forbidden!!!");
                            }
                            return -1;
                        }
                        catch (SQLException sQLException) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : " + sQLException);
                            }
                            return -1;
                        }
                    }
                    this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    if (this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) break block36;
                    return 0;
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlCreateTable() : change on table needed but forbidden!!!");
                }
                return -1;
            }
            if (bl || this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) {
                this.sqlCreateTableWithName(yP_TCD_DesignAccesObject);
            }
        } else {
            if (UtilsYP.getInstanceRole() == 3) {
                block38: {
                    StringBuilder stringBuilder;
                    block37: {
                        if (bl) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table asked but forbidden on slave shared DB !!!");
                            }
                            return -1;
                        }
                        if (!this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) {
                            return 0;
                        }
                        try {
                            stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject), 0);
                            if (stringBuilder != null) break block37;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : create table needed but should be forbidden!!!");
                            }
                            this.sqlCreateTableWithName(yP_TCD_DesignAccesObject);
                            return 1;
                        }
                        catch (SQLException sQLException) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "sqlCreateTable() : " + sQLException);
                            }
                            return -1;
                        }
                    }
                    this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    if (this.isCreateTableNeeded(yP_TCD_DesignAccesObject)) break block38;
                    return 0;
                }
                this.logger(2, "sqlCreateTable() : change on " + yP_TCD_DesignAccesObject.getFullTableName() + " needed but should beforbidden!!!");
                this.sqlCreateTableWithName(yP_TCD_DesignAccesObject);
                return 1;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "sqlCreateTable() : Unknown role:" + UtilsYP.getInstanceRole());
            }
        }
        return 1;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private boolean isCreateTableNeeded(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            String string;
            byte[] byArray;
            Object object;
            String string2 = yP_TCD_DesignAccesObject.getFullTableName();
            String string3 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/";
            String string4 = String.valueOf(string3) + string2 + ".sql";
            Object object2 = null;
            String string5 = null;
            try {
                object = new FileInputStream(string4);
                try {
                    byArray = new byte[((FileInputStream)object).available()];
                    ((FileInputStream)object).read(byArray);
                }
                finally {
                    if (object != null) {
                        ((FileInputStream)object).close();
                    }
                }
            }
            catch (Throwable throwable) {
                if (object2 == null) {
                    object2 = throwable;
                } else if (object2 != throwable) {
                    ((Throwable)object2).addSuppressed(throwable);
                }
                throw object2;
            }
            object2 = new String(byArray);
            object = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string6 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            if (string6 != null) {
                Object object3;
                int n;
                boolean bl = false;
                string = null;
                if (!this.partitionDeactivated) {
                    Field[] fieldArray2 = yP_TCD_DesignAccesObject.getFieldList();
                    int n2 = fieldArray2.length;
                    n = 0;
                    while (n < n2) {
                        object3 = fieldArray2[n];
                        Partition partition = ((Field)object3).getAnnotation(Partition.class);
                        if (partition != null && (yP_TCD_DesignAccesObject.getTableType() & partition.tableType()) != 0) {
                            bl = true;
                            string = String.valueOf('[') + ((Field)object3).getName() + ']';
                            break;
                        }
                        ++n;
                    }
                }
                if (!((String)object2).contains((CharSequence)(object3 = bl ? "PRIMARY KEY  ([" + string6 + "], " + string + ")" : "PRIMARY KEY  ([" + string6 + "])"))) {
                    return true;
                }
                if (bl && !((String)object2).contains("ON ###PARTITION###")) {
                    return true;
                }
                if (object != null && !object.isEmpty()) {
                    n = 0;
                    while (n < object.size()) {
                        if (!((String)object2).contains(String.valueOf('\"') + (String)object.get(n) + "_idx\"")) {
                            return true;
                        }
                        ++n;
                    }
                }
            } else {
                if (object == null || object.isEmpty() || object.size() < 2) {
                    this.logger(2, "isCreateTableNeeded() : no primary key and less than two indexes is not possible for " + string2);
                    return true;
                }
                String string7 = "PRIMARY KEY  ([" + (String)object.get(0) + "], [" + (String)object.get(1) + "])";
                if (!((String)object2).contains(string7)) {
                    string = "PRIMARY KEY  ([" + (String)object.get(0) + "])";
                    if (!((String)object2).contains(string)) {
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                        return true;
                    }
                    string7 = "PRIMARY KEY  ([" + (String)object.get(1) + "])";
                }
                if (!((String)object2).contains(string7)) {
                    return true;
                }
            }
            int n = 0;
            while (n < fieldArray.length) {
                if ((string6 == null || fieldArray[n].getName().compareTo(string6) != 0) && Modifier.isPublic(fieldArray[n].getModifiers())) {
                    string5 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                    string5 = string5.substring(0, string5.indexOf(" DEFAULT ("));
                    string = "[" + fieldArray[n].getName() + "] " + string5;
                    if (!((String)object2).contains(string)) {
                        return true;
                    }
                }
                ++n;
            }
        }
        catch (Exception exception) {
            this.logger(3, "isCreateTableNeeded() : " + exception);
            return true;
        }
        return false;
    }

    private void sqlCreateTableWithName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            Object object;
            String string;
            List<String> list = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string2 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            StringBuilder stringBuilder = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject), 0);
            String string3 = stringBuilder != null ? stringBuilder.toString() : null;
            if (string3 == null || string3.contains("show_create_table=\"null\"") || string3.contains("<row =\"null\"/>")) {
                if (this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, true) < 0) {
                    StringBuilder stringBuilder2;
                    String string4 = "SELECT 1 FROM sys.schemas WHERE name like '" + yP_TCD_DesignAccesObject.getSchemaName() + "'";
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTableWithName() : " + string4);
                    }
                    if ((stringBuilder2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, string4, 0)) == null) {
                        this.sqlCreateDatabase(yP_TCD_DesignAccesObject);
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, true);
                    }
                }
                return;
            }
            if (string2 != null) {
                int n;
                boolean bl = false;
                string = null;
                if (!this.partitionDeactivated) {
                    Field[] fieldArray2 = yP_TCD_DesignAccesObject.getFieldList();
                    int n2 = fieldArray2.length;
                    n = 0;
                    while (n < n2) {
                        object = fieldArray2[n];
                        Partition partition = ((Field)object).getAnnotation(Partition.class);
                        if (partition != null && (yP_TCD_DesignAccesObject.getTableType() & partition.tableType()) != 0) {
                            bl = true;
                            string = String.valueOf('[') + ((Field)object).getName() + ']';
                            break;
                        }
                        ++n;
                    }
                }
                if (bl && !string3.contains("ON ###PARTITION###")) {
                    this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                    return;
                }
                object = bl ? "PRIMARY KEY  ([" + string2 + "], " + string + ")" : "PRIMARY KEY  ([" + string2 + "])";
                if (!string3.contains((CharSequence)object)) {
                    this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                    return;
                }
                if (list != null && !list.isEmpty()) {
                    n = 0;
                    while (n < list.size()) {
                        object = String.valueOf('\"') + list.get(n) + "_idx\"";
                        if (!string3.contains((CharSequence)object)) {
                            this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                            return;
                        }
                        ++n;
                    }
                }
            } else {
                if (list == null || list.isEmpty() || list.size() < 2) {
                    this.logger(2, "sqlCreateTableWithName() : no primary key and less than two indexes is not possible for " + yP_TCD_DesignAccesObject.getFullTableName());
                    return;
                }
                String string5 = "PRIMARY KEY  ([" + list.get(0) + "], [" + list.get(1) + "])";
                if (!string3.contains(string5)) {
                    string = "PRIMARY KEY  ([" + list.get(0) + "])";
                    if (!string3.contains(string)) {
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                        return;
                    }
                    string5 = "PRIMARY KEY  ([" + list.get(1) + "])";
                }
                if (!string3.contains(string5)) {
                    this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                    return;
                }
            }
            int n = 0;
            while (n < fieldArray.length) {
                String string6;
                if (string2 == null) {
                    if (Modifier.isPublic(fieldArray[n].getModifiers())) {
                        string = fieldArray[n].getName();
                        if (list == null || !string.contentEquals(list.get(0)) && !string.contentEquals(list.get(1))) {
                            string6 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                            string6 = string6.substring(0, string6.indexOf(" DEFAULT ("));
                            object = "[" + fieldArray[n].getName() + "] " + string6;
                            if (!string3.contains((CharSequence)object)) {
                                this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                                return;
                            }
                        }
                    }
                } else if (fieldArray[n].getName().compareTo(string2) != 0 && Modifier.isPublic(fieldArray[n].getModifiers())) {
                    string6 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n]);
                    string6 = string6.substring(0, string6.indexOf(" DEFAULT ("));
                    string = "[" + fieldArray[n].getName() + "] " + string6;
                    if (!string3.contains(string)) {
                        this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
                        return;
                    }
                }
                ++n;
            }
            if (UtilsYP.getTableCreationMode() == 3 || UtilsYP.getTableCreationMode() == 4 && yP_TCD_DesignAccesObject.getSchemaName().contains("management")) {
                this.sqlCreateTableWithName2(yP_TCD_DesignAccesObject, yP_Row, false);
            }
            this.putCreateTableResponseInCache(yP_TCD_DesignAccesObject, string3);
        }
        catch (SQLException sQLException) {
            this.logger(2, "sqlCreateTableWithName() : " + sQLException);
        }
    }

    private int putCreateTableResponseInCache(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        String string2 = yP_TCD_DesignAccesObject.getFullTableName();
        String string3 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/";
        String string4 = String.valueOf(string3) + string2 + ".sql";
        new File(string3).mkdirs();
        new File(string4).delete();
        Throwable throwable = null;
        Object var7_9 = null;
        PrintWriter printWriter = new PrintWriter(new FileWriter(string4, true));
        try {
            printWriter.print(string);
            if (printWriter != null) {
                printWriter.close();
            }
            return 1;
        }
        catch (Throwable throwable2) {
            try {
                try {
                    if (printWriter != null) {
                        printWriter.close();
                    }
                    throw throwable2;
                }
                catch (Throwable throwable3) {
                    if (throwable == null) {
                        throwable = throwable3;
                    } else if (throwable != throwable3) {
                        throwable.addSuppressed(throwable3);
                    }
                    throw throwable;
                }
            }
            catch (IOException iOException) {
                this.logger(2, "putCreateTableResponseInCache() : " + iOException);
                return -1;
            }
        }
    }

    private static String removeSpecialsChars(String string) {
        if (string.indexOf(32) != -1) {
            string = string.replace(" ", "");
        }
        if (string.indexOf(91) != -1) {
            string = string.replace("[", "");
        }
        if (string.indexOf(93) != -1) {
            string = string.replace("]", "");
        }
        if (string.indexOf(47) != -1) {
            string = string.replace("/", "");
        }
        if (string.indexOf(92) != -1) {
            string = string.replace("\\", "");
        }
        if (string.indexOf(37) != -1) {
            string = string.replace("%", "");
        }
        if (string.indexOf(46) != -1) {
            string = string.replace(".", "_");
        }
        if (string.indexOf(94) != -1) {
            string = string.replace("^", "");
        }
        if (string.indexOf(38) != -1) {
            string = string.replace("&", "");
        }
        if (string.indexOf(40) != -1) {
            string = string.replace("(", "");
        }
        if (string.indexOf(41) != -1) {
            string = string.replace(")", "");
        }
        if (string.indexOf(123) != -1) {
            string = string.replace("{", "");
        }
        if (string.indexOf(125) != -1) {
            string = string.replace("}", "");
        }
        if (string.indexOf(43) != -1) {
            string = string.replace("+", "");
        }
        if (string.indexOf(45) != -1) {
            string = string.replace("-", "");
        }
        if (string.indexOf(64) != -1) {
            string = string.replace("@", "");
        }
        if (string.indexOf(35) != -1) {
            string = string.replace("#", "");
        }
        if (string.indexOf(39) != -1) {
            string = string.replace("'", "");
        }
        return string;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private int sqlCreateTableWithName2(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_Row yP_Row, boolean bl) {
        try {
            Object object;
            Object object2;
            int n;
            Object object3;
            int n2;
            String string = yP_TCD_DesignAccesObject.getFullTableName();
            String string2 = String.valueOf(UtilsYP.getCachePath()) + yP_TCD_DesignAccesObject.getSchemaName() + "/";
            String string3 = String.valueOf(string2) + string + ".sql";
            new File(string2).mkdirs();
            new File(string3).delete();
            String string4 = null;
            List<String> list = yP_TCD_DesignAccesObject.getIndexesKeysNames();
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string5 = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            if (string5 == null) {
                if (list != null && !list.isEmpty()) {
                    string5 = list.get(0);
                    n2 = 0;
                    while (n2 < fieldArray.length) {
                        if (fieldArray[n2].getName().compareTo(string5) == 0) {
                            string4 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n2]);
                            break;
                        }
                        ++n2;
                    }
                    if (string4 == null) {
                        this.logger(2, "sqlCreateTableWithName2() : " + string);
                        return -1;
                    }
                } else {
                    string5 = fieldArray[0].getName();
                    string4 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[0]);
                }
            } else {
                n2 = 0;
                while (n2 < fieldArray.length) {
                    if (fieldArray[n2].getName().compareTo(string5) == 0) {
                        string4 = this.getVarTypeForPrimaryKey(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n2]);
                        break;
                    }
                    ++n2;
                }
                if (string4 == null) {
                    this.logger(2, "sqlCreateTableWithName2() : " + string);
                    return -1;
                }
            }
            n2 = 0;
            String string6 = null;
            String string7 = null;
            String string8 = null;
            if (!this.partitionDeactivated) {
                object3 = yP_TCD_DesignAccesObject.getFieldList();
                n = ((Field[])object3).length;
                int n3 = 0;
                while (n3 < n) {
                    object2 = object3[n3];
                    object = ((Field)object2).getAnnotation(Partition.class);
                    if (object != null && (yP_TCD_DesignAccesObject.getTableType() & object.tableType()) != 0) {
                        n2 = 1;
                        string6 = String.valueOf('[') + ((Field)object2).getName() + ']';
                        string7 = object.name();
                        string8 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, (Field)object2);
                        break;
                    }
                    ++n3;
                }
            }
            object2 = null;
            if (!bl && (object2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject), 0)) != null && ((StringBuilder)object2).indexOf("show_create_table=\"null\"") != -1) {
                object2 = null;
            }
            if (bl || object2 == null || ((StringBuilder)object2).indexOf(string) == -1) {
                int n4;
                object2 = null;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("IF OBJECT_ID(N'");
                stringBuilder.append(string);
                stringBuilder.append("', N'U') IS NULL\r\n");
                stringBuilder.append("BEGIN\r\n");
                stringBuilder.append("CREATE TABLE ");
                stringBuilder.append(string);
                stringBuilder.append(" (\r\n");
                stringBuilder.append(string5);
                stringBuilder.append(" ");
                Field field = yP_TCD_DesignAccesObject.getPrimaryKeyField();
                if (field != null && field.getAnnotation(Identity.class) != null) {
                    stringBuilder.append(string4.substring(0, string4.indexOf(32)));
                    stringBuilder.append(" IDENTITY");
                    stringBuilder.append(string4.substring(string4.indexOf(32)));
                } else {
                    stringBuilder.append(string4);
                }
                stringBuilder.append("\r\n");
                stringBuilder.append("CONSTRAINT [");
                stringBuilder.append(YP_TCG_SQLSERVER_Formater.removeSpecialsChars(string));
                stringBuilder.append("_pkey] PRIMARY KEY CLUSTERED (");
                stringBuilder.append(string5);
                stringBuilder.append(" ASC");
                if (n2 != 0) {
                    stringBuilder.append(",");
                    stringBuilder.append(string6);
                    stringBuilder.append("ASC\r\n");
                }
                stringBuilder.append(")\r\n");
                if (n2 != 0) {
                    stringBuilder.append(",");
                    stringBuilder.append(string6);
                    stringBuilder.append(" ");
                    stringBuilder.append(string8);
                    stringBuilder.append("\r\n");
                }
                stringBuilder.append(")\r\n");
                if (n2 != 0) {
                    stringBuilder.append("ON ");
                    stringBuilder.append(string7);
                    stringBuilder.append(" (");
                    stringBuilder.append(string6);
                    stringBuilder.append(")\r\n");
                }
                stringBuilder.append("END\r\n");
                stringBuilder.append("ELSE UPDATE [management].[brand] SET idBrand=0 WHERE idBRAND=0");
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                }
                if ((n4 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString())) < 0) {
                    this.sqlCreateDatabase(yP_TCD_DesignAccesObject);
                    n4 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    if (n4 < 0) {
                        return -1;
                    }
                }
                if (!bl && (object2 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, this.getShowCreateTable(yP_TCD_DesignAccesObject), 0)) != null && ((StringBuilder)object2).indexOf("show_create_table=\"null\"") != -1) {
                    object2 = null;
                }
            }
            if (!bl && object2 != null && string5 != null) {
                String string9 = n2 != 0 ? "PRIMARY KEY  ([" + string5 + "], " + string6 + ")" : "PRIMARY KEY  ([" + string5 + "])";
                if (n2 != 0 && ((StringBuilder)object2).indexOf(string9) == -1 && ((StringBuilder)object2).indexOf("PRIMARY KEY  (" + string6 + ")") != -1) {
                    string9 = "PRIMARY KEY  ([" + string5 + "])";
                }
                if (((StringBuilder)object2).indexOf(string9) == -1 || n2 != 0 && ((StringBuilder)object2).indexOf("ON ###PARTITION###") == -1) {
                    if (n2 != 0) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("ALTER TABLE ");
                        stringBuilder.append(string);
                        stringBuilder.append(" DROP CONSTRAINT [");
                        stringBuilder.append(YP_TCG_SQLSERVER_Formater.removeSpecialsChars(string));
                        stringBuilder.append("_pkey]");
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2()  : " + stringBuilder);
                        }
                        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("ALTER TABLE ");
                        stringBuilder.append(string);
                        stringBuilder.append(" ADD CONSTRAINT [");
                        stringBuilder.append(YP_TCG_SQLSERVER_Formater.removeSpecialsChars(string));
                        stringBuilder.append("_pkey] PRIMARY KEY CLUSTERED (");
                        stringBuilder.append(string5);
                        stringBuilder.append(" ASC,");
                        stringBuilder.append(string6);
                        stringBuilder.append("ASC) ON ");
                        stringBuilder.append(string7);
                        stringBuilder.append(" (");
                        stringBuilder.append(string6);
                        stringBuilder.append(")\r\n");
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2()  : " + stringBuilder);
                        }
                        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    } else {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS Tab\r\n");
                        stringBuilder.append("INNER JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE Col\r\n");
                        stringBuilder.append("ON Col.CONSTRAINT_NAME = Tab.CONSTRAINT_NAME\r\n");
                        stringBuilder.append("AND Col.TABLE_SCHEMA = Tab.TABLE_SCHEMA\r\n");
                        stringBuilder.append("AND Col.TABLE_NAME = Tab.TABLE_NAME\r\n");
                        stringBuilder.append("WHERE\r\n");
                        stringBuilder.append("Constraint_Type = 'PRIMARY KEY'\r\n");
                        stringBuilder.append("AND Col.TABLE_SCHEMA = '");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
                        stringBuilder.append("'\r\n");
                        stringBuilder.append("AND Col.TABLE_NAME = '");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
                        stringBuilder.append("'\r\n");
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                        }
                        if ((object3 = yP_TCD_DesignAccesObject.getDataBaseConnector().dealQuery(yP_TCD_DesignAccesObject, stringBuilder.toString(), 0)) != null) {
                            int n5;
                            int n6 = ((StringBuilder)object3).indexOf("COLUMN_NAME=\"");
                            if (n6 < 0) {
                                n6 = ((StringBuilder)object3).indexOf("Column_name=\"");
                            }
                            if (n6 > 0 && (n5 = ((StringBuilder)object3).indexOf("\"", n6 += "COLUMN_NAME=\"".length())) > 0) {
                                String string10 = ((StringBuilder)object3).substring(n6, n5);
                                Field field = null;
                                int n7 = 0;
                                while (n7 < fieldArray.length) {
                                    String string11 = fieldArray[n7].getName();
                                    if (string11.contentEquals(string10)) {
                                        field = fieldArray[n7];
                                        break;
                                    }
                                    ++n7;
                                }
                                if (field != null) {
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "sqlCreateTableWithName2()  : Primary key change, case not yet handle");
                                    }
                                } else if (object2 == null || ((StringBuilder)object2).indexOf(String.valueOf('[') + string5 + ']') < 0) {
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("sp_rename '");
                                    stringBuilder.append(string);
                                    stringBuilder.append(".");
                                    stringBuilder.append(string10);
                                    stringBuilder.append("',N'");
                                    stringBuilder.append(string5);
                                    stringBuilder.append("', 'COLUMN' ");
                                    if (this.getLogLevel() >= 5) {
                                        this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                                    }
                                    yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                                } else if (this.getLogLevel() >= 2) {
                                    this.logger(2, "sqlCreateTableWithName2()  : Primary key change, case not yet handle");
                                }
                            }
                        }
                    }
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ALTER TABLE ");
            stringBuilder.append(string);
            n = 1;
            int n8 = 0;
            while (n8 < fieldArray.length) {
                object = fieldArray[n8].getName();
                if (((String)object).compareTo(string5) != 0 && Modifier.isPublic(fieldArray[n8].getModifiers())) {
                    String string12 = this.getVarType(yP_TCD_DesignAccesObject, yP_Row, fieldArray[n8]);
                    if (object2 == null || ((StringBuilder)object2).indexOf(String.valueOf('[') + (String)object + ']' + ' ') == -1) {
                        if (!bl || n2 == 0 || ((String)object).length() + 2 != string6.length() || !string6.contains((CharSequence)object)) {
                            if (n != 0) {
                                n = 0;
                                stringBuilder.append(" ADD ");
                            } else {
                                stringBuilder.append(',');
                            }
                            stringBuilder.append("[");
                            stringBuilder.append((String)object);
                            stringBuilder.append("] ");
                            stringBuilder.append(string12);
                        }
                    } else {
                        string12 = string12.substring(0, string12.indexOf(" DEFAULT ("));
                        if (((StringBuilder)object2).indexOf(String.valueOf('[') + (String)object + ']' + " " + string12) == -1) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("ALTER TABLE ");
                            stringBuilder2.append(string);
                            stringBuilder2.append(" ALTER COLUMN ");
                            stringBuilder2.append("[");
                            stringBuilder2.append((String)object);
                            stringBuilder2.append("] ");
                            stringBuilder2.append(string12);
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "sqlCreateTableWithName2()  : " + stringBuilder2);
                            }
                            yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder2.toString());
                        }
                    }
                }
                ++n8;
            }
            if (n == 0) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                }
                yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
            }
            if (yP_TCD_DesignAccesObject.getPrimaryKeyName() != null) {
                if (list != null && !list.isEmpty()) {
                    n8 = 0;
                    while (n8 < list.size()) {
                        stringBuilder = new StringBuilder();
                        if (object2 == null || ((StringBuilder)object2).indexOf(String.valueOf('\"') + list.get(n8) + "_idx\"") < 0) {
                            stringBuilder.append("CREATE INDEX ");
                            stringBuilder.append(list.get(n8));
                            stringBuilder.append("_idx");
                            stringBuilder.append(" ON ");
                            stringBuilder.append(string);
                            stringBuilder.append(" (\"");
                            stringBuilder.append(list.get(n8));
                            stringBuilder.append("\")");
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "sqlCreateTableWithName2() :" + stringBuilder);
                            }
                            yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                        }
                        ++n8;
                    }
                }
            } else if (list != null && !list.isEmpty()) {
                if (list.get(0).compareTo(string5) == 0) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("ALTER TABLE ");
                    stringBuilder.append(string);
                    stringBuilder.append(" DROP CONSTRAINT [");
                    stringBuilder.append(YP_TCG_SQLSERVER_Formater.removeSpecialsChars(string));
                    stringBuilder.append("_pkey] \r\n");
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                    }
                    yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("ALTER TABLE ");
                    stringBuilder.append(string);
                    stringBuilder.append(" ADD CONSTRAINT [");
                    stringBuilder.append(YP_TCG_SQLSERVER_Formater.removeSpecialsChars(string));
                    stringBuilder.append("_pkey] PRIMARY KEY CLUSTERED (");
                    n8 = 0;
                    while (n8 < list.size()) {
                        if (n8 != 0) {
                            stringBuilder.append(',');
                        }
                        this.appendSQLColumnName(stringBuilder, list.get(n8));
                        ++n8;
                    }
                    stringBuilder.append(" ASC)\r\n");
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "sqlCreateTableWithName2() : " + stringBuilder);
                    }
                    yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
                } else {
                    this.logger(2, "sqlCreateTableWithName2() : ");
                }
            } else {
                this.logger(2, "sqlCreateTableWithName2() : ");
            }
            this.sqlCreateTriggers(yP_TCD_DesignAccesObject, bl);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "sqlCreateTableWithName2() : " + exception);
            return -1;
        }
    }

    @Override
    public int sqlEmptyTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DELETE FROM ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append(" WHERE ");
        String string = this.getContractKeyClause(yP_TCD_DesignAccesObject);
        if (string != null && !string.isEmpty()) {
            stringBuilder.append(string);
        } else {
            stringBuilder.append("1>0");
        }
        String string2 = stringBuilder.toString();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlEmptyTable () : " + string2);
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, string2);
    }

    @Override
    public int sqlFillTable(YP_TCD_DAO_LOC yP_TCD_DAO_LOC) {
        Object object;
        if (yP_TCD_DAO_LOC.isEmpty()) {
            return 0;
        }
        if (yP_TCD_DAO_LOC.size() > 100) {
            return this.sqlFillBigTable(yP_TCD_DAO_LOC);
        }
        Field[] fieldArray = yP_TCD_DAO_LOC.getFieldList();
        if (fieldArray.length == 0) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("INSERT INTO ");
        stringBuilder.append(yP_TCD_DAO_LOC.getFullTableName());
        stringBuilder.append('(');
        boolean bl = true;
        Object object2 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block28: {
                object = object2[n2];
                try {
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                    }
                    this.appendSQLColumnName(stringBuilder, ((Field)object).getName());
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 5) break block28;
                    this.logger(5, "sqlFillTable() : " + exception);
                }
            }
            ++n2;
        }
        stringBuilder.append(") VALUES ");
        object = new StringBuilder();
        n2 = yP_TCD_DAO_LOC.size();
        n = 1;
        while (n <= n2) {
            Object object3;
            object2 = yP_TCD_DAO_LOC.getRowAt(n - 1);
            long l = ((YP_Row)object2).getPrimaryKey();
            if (l == 0L) {
                ((YP_Row)object2).setPrimaryKey(yP_TCD_DAO_LOC.getNextPrimaryKey());
            }
            if (n % 250 != 1) {
                ((StringBuilder)object).append(',');
            }
            ((StringBuilder)object).append('(');
            bl = true;
            Field[] fieldArray2 = fieldArray;
            int n3 = fieldArray.length;
            int n4 = 0;
            while (n4 < n3) {
                block29: {
                    object3 = fieldArray2[n4];
                    try {
                        if (bl) {
                            bl = false;
                        } else {
                            ((StringBuilder)object).append(',');
                        }
                        this.appendSQLValue((StringBuilder)object, ((YP_Row)object2).getFieldValue((Field)object3));
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 5) break block29;
                        this.logger(5, "sqlFillTable() : " + exception);
                    }
                }
                ++n4;
            }
            ((StringBuilder)object).append(')');
            if (n % 250 == 0) {
                object3 = String.valueOf(stringBuilder.toString()) + ((StringBuilder)object).toString();
                if (this.getLogLevel() >= 5) {
                    if (((String)object3).contains("BlackList")) {
                        this.logger(3, "sqlFillTable() partial : BlackList not logged even on debug mode");
                    } else if (((String)object3).length() > 2048) {
                        this.logger(5, "sqlFillTable() partial : " + ((String)object3).substring(0, 2048));
                    } else {
                        this.logger(5, "sqlFillTable() partial: " + (String)object3);
                    }
                }
                if ((n4 = yP_TCD_DAO_LOC.getDataBaseConnector().dealCreate((String)object3, yP_TCD_DAO_LOC)) < 0 || n == n2) {
                    return n4;
                }
                object = new StringBuilder();
            }
            ++n;
        }
        String string = String.valueOf(stringBuilder.toString()) + ((StringBuilder)object).toString();
        if (this.getLogLevel() >= 5) {
            if (string.contains("BlackList")) {
                this.logger(3, "sqlFillTable() BlackList not logged even on debug mode");
            } else if (string.length() > 2048) {
                this.logger(5, "sqlFillTable() : " + string.substring(0, 2048));
            } else {
                this.logger(5, "sqlFillTable() : " + string);
            }
        }
        return yP_TCD_DAO_LOC.getDataBaseConnector().dealCreate(string, yP_TCD_DAO_LOC);
    }

    private int sqlFillBigTable(YP_TCD_DAO_LOC yP_TCD_DAO_LOC) {
        if (yP_TCD_DAO_LOC.isEmpty()) {
            return 0;
        }
        Field[] fieldArray = yP_TCD_DAO_LOC.getFieldList();
        if (fieldArray.length == 0) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("INSERT INTO ");
        stringBuilder.append(yP_TCD_DAO_LOC.getFullTableName());
        stringBuilder.append('(');
        int n = 0;
        while (n < fieldArray.length) {
            if (n != 0) {
                stringBuilder.append(',');
            }
            this.appendSQLColumnName(stringBuilder, fieldArray[n].getName());
            ++n;
        }
        stringBuilder.append(") VALUES (?");
        n = 1;
        while (n < fieldArray.length) {
            stringBuilder.append(", ?");
            ++n;
        }
        stringBuilder.append(')');
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlFillBigTable() " + yP_TCD_DAO_LOC.size() + " with " + stringBuilder.toString());
        }
        n = yP_TCD_DAO_LOC.getDataBaseConnector().dealBatchInsert(stringBuilder.toString(), yP_TCD_DAO_LOC);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlFillBigTable() done");
        }
        return n;
    }

    @Override
    public int sqlBatchUpdate(YP_TCD_DAO_LOC yP_TCD_DAO_LOC, Field[] fieldArray, Field[] fieldArray2) {
        String string;
        Field field;
        if (yP_TCD_DAO_LOC.isEmpty()) {
            return 0;
        }
        Field[] fieldArray3 = yP_TCD_DAO_LOC.getFieldList();
        if (fieldArray3.length == 0) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UPDATE ");
        stringBuilder.append(yP_TCD_DAO_LOC.getFullTableName());
        stringBuilder.append(" SET ");
        boolean bl = true;
        Field[] fieldArray4 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            field = fieldArray4[n2];
            if (field == null) {
                this.logger(2, "sqlBatchUpdate() null field in update clause");
                return -1;
            }
            string = field.getName();
            if (bl) {
                bl = false;
            } else {
                stringBuilder.append(",");
            }
            stringBuilder.append(String.valueOf(string) + "=?");
            ++n2;
        }
        stringBuilder.append(" WHERE ");
        bl = true;
        fieldArray4 = fieldArray2;
        n = fieldArray2.length;
        n2 = 0;
        while (n2 < n) {
            field = fieldArray4[n2];
            if (field == null) {
                this.logger(2, "sqlBatchUpdate() null field in where clause");
                return -1;
            }
            string = field.getName();
            if (bl) {
                bl = false;
            } else {
                stringBuilder.append(" AND ");
            }
            stringBuilder.append(String.valueOf(string) + "=?");
            ++n2;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlBatchUpdate() " + yP_TCD_DAO_LOC.size() + " with " + stringBuilder.toString());
        }
        int n3 = yP_TCD_DAO_LOC.getDataBaseConnector().dealBatchUpdate(stringBuilder.toString(), yP_TCD_DAO_LOC, fieldArray, fieldArray2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlBatchUpdate() done");
        }
        return n3;
    }

    @Override
    public int sqlBatchDelete(YP_TCD_DAO_LOC yP_TCD_DAO_LOC, Field[] fieldArray) {
        if (yP_TCD_DAO_LOC.isEmpty()) {
            return 0;
        }
        Field[] fieldArray2 = yP_TCD_DAO_LOC.getFieldList();
        if (fieldArray2.length == 0) {
            return -1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DELETE FROM ");
        stringBuilder.append(yP_TCD_DAO_LOC.getFullTableName());
        stringBuilder.append(" WHERE ");
        boolean bl = true;
        Field[] fieldArray3 = fieldArray;
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            Field field = fieldArray3[n2];
            String string = field.getName();
            if (bl) {
                bl = false;
            } else {
                stringBuilder.append(" AND ");
            }
            stringBuilder.append(String.valueOf(string) + "=?");
            ++n2;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlBatchDelete() " + yP_TCD_DAO_LOC.size() + " with " + stringBuilder.toString());
        }
        int n3 = yP_TCD_DAO_LOC.getDataBaseConnector().dealBatchDelete(stringBuilder.toString(), yP_TCD_DAO_LOC, fieldArray);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlBatchDelete() done");
        }
        return n3;
    }

    @Override
    public int sqlUpdateRowList(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list) {
        block7: {
            if (list != null && !list.isEmpty()) break block7;
            return 0;
        }
        try {
            if (list.size() <= 250) {
                return this.sqlUpdateRowListLimited(yP_TCD_DesignAccesObject, list);
            }
            int n = 0;
            LinkedList<YP_Row> linkedList = new LinkedList<YP_Row>(list);
            do {
                ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>(250);
                int n2 = 0;
                while (n2 < 250 && !linkedList.isEmpty()) {
                    arrayList.add(linkedList.removeFirst());
                    ++n2;
                }
                n2 = this.sqlUpdateRowListLimited(yP_TCD_DesignAccesObject, arrayList);
                if (n2 < 0) {
                    return n2;
                }
                n += n2;
            } while (!linkedList.isEmpty());
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "sqlUpdateRowList() : " + exception);
            return -1;
        }
    }

    private int sqlUpdateRowListLimited(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, List<YP_Row> list) {
        Field[] fieldArray;
        block32: {
            block31: {
                if (list != null && !list.isEmpty()) break block31;
                return 0;
            }
            fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            if (fieldArray.length != 0) break block32;
            return -1;
        }
        try {
            int n;
            Object object;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\nMERGE INTO ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(" target\n USING (\n");
            boolean bl = true;
            Field field = yP_TCD_DesignAccesObject.getPrimaryKeyField();
            if (field == null || field.getType() == byte[].class) {
                bl = false;
            }
            int n2 = list.size();
            int n3 = 0;
            while (n3 < n2) {
                long l;
                object = list.get(n3);
                if (bl && (l = ((YP_Row)object).getPrimaryKey()) == 0L) {
                    ((YP_Row)object).setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                }
                if (n3 != 0) {
                    stringBuilder.append("\tUNION ALL\n");
                }
                stringBuilder.append("\tSELECT ");
                n = 1;
                Field[] fieldArray2 = fieldArray;
                int n4 = fieldArray.length;
                int n5 = 0;
                while (n5 < n4) {
                    Field field2 = fieldArray2[n5];
                    if (n != 0) {
                        n = 0;
                    } else {
                        stringBuilder.append(',');
                    }
                    Comparable<java.util.Date> comparable = ((YP_Row)object).getFieldValue(field2);
                    if (comparable instanceof Timestamp) {
                        this.appendSQLValue(stringBuilder, comparable);
                    } else if (comparable instanceof Date) {
                        this.appendSQLValue(stringBuilder, comparable);
                    } else {
                        if (comparable == null) {
                            Class<?> clazz = field2.getType();
                            comparable = clazz == byte[].class ? (Comparable<java.util.Date>)new byte[0] : (clazz == Timestamp.class ? new Timestamp(0L) : (clazz == Date.class ? new Date(0L) : (clazz == Integer.TYPE ? Integer.valueOf(0) : (clazz == Long.TYPE ? Integer.valueOf(0) : (clazz == Float.TYPE ? Integer.valueOf(0) : null)))));
                        }
                        this.appendSQLValue(stringBuilder, comparable);
                    }
                    if (n3 == 0) {
                        stringBuilder.append(" AS [");
                        stringBuilder.append(field2.getName());
                        stringBuilder.append(']');
                    }
                    ++n5;
                }
                stringBuilder.append("\n");
                ++n3;
            }
            stringBuilder.append("\n)new_values\n ON (new_values.");
            stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
            stringBuilder.append(" = target.");
            stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
            stringBuilder.append(")");
            n3 = 1;
            if (fieldArray.length != 1) {
                stringBuilder.append("\n WHEN  MATCHED\n THEN UPDATE SET");
                Field[] fieldArray3 = fieldArray;
                int n6 = fieldArray.length;
                n = 0;
                while (n < n6) {
                    object = fieldArray3[n];
                    if (!((Field)object).getName().contentEquals(yP_TCD_DesignAccesObject.getPrimaryKeyName())) {
                        if (n3 != 0) {
                            n3 = 0;
                        } else {
                            stringBuilder.append(',');
                        }
                        stringBuilder.append("\n\t\t[");
                        stringBuilder.append(((Field)object).getName());
                        stringBuilder.append("] = new_values.[");
                        stringBuilder.append(((Field)object).getName());
                        stringBuilder.append(']');
                    }
                    ++n;
                }
            }
            stringBuilder.append("\nWHEN NOT MATCHED\nTHEN\n\tINSERT (");
            n3 = 1;
            Field[] fieldArray4 = fieldArray;
            int n7 = fieldArray.length;
            n = 0;
            while (n < n7) {
                object = fieldArray4[n];
                if (n3 != 0) {
                    n3 = 0;
                } else {
                    stringBuilder.append(',');
                }
                stringBuilder.append('[');
                stringBuilder.append(((Field)object).getName());
                stringBuilder.append(']');
                ++n;
            }
            stringBuilder.append(")\nVALUES (");
            n3 = 1;
            fieldArray4 = fieldArray;
            n7 = fieldArray.length;
            n = 0;
            while (n < n7) {
                object = fieldArray4[n];
                if (n3 != 0) {
                    n3 = 0;
                } else {
                    stringBuilder.append(',');
                }
                stringBuilder.append("new_values.");
                this.appendSQLColumnName(stringBuilder, ((Field)object).getName());
                ++n;
            }
            stringBuilder.append(");");
            if (this.getLogLevel() >= 5) {
                if (stringBuilder.length() > 2048) {
                    this.logger(5, "sqlUpdateRowList() : " + stringBuilder.substring(0, 2048));
                } else {
                    this.logger(5, "sqlUpdateRowList() : " + stringBuilder.toString());
                }
            }
            return yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlUpdateRowListLimited() : " + exception);
            return -1;
        }
    }

    private void sqlCreateDatabase(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        String string = "CREATE SCHEMA " + this.sqlSchemaName(yP_TCD_DesignAccesObject);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlCreateDatabase() : " + string);
        }
        yP_TCD_DesignAccesObject.getDataBaseConnector().dealUpdate(yP_TCD_DesignAccesObject, string);
    }

    @Override
    public YP_Row selectFromWhere(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, String string2, long l) {
        List<YP_Row> list;
        block9: {
            block8: {
                block7: {
                    try {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT ");
                        this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
                        stringBuilder.append(" FROM ");
                        stringBuilder.append(string);
                        stringBuilder.append(" WHERE ");
                        stringBuilder.append(string2);
                        stringBuilder.append('=');
                        stringBuilder.append(l);
                        String string3 = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction);
                        if (string3 != null && !string3.isEmpty()) {
                            stringBuilder.append(" AND");
                            stringBuilder.append(string3);
                        }
                        if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                            this.logger(5, "selectFromWhere() : " + stringBuilder.toString());
                        }
                        if ((list = yP_TCD_DataBaseConnector.dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block7;
                        this.logger(2, "selectFromWhere() empty response");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(3, "selectFromWhere() No result from database" + exception);
                        return null;
                    }
                }
                if (!list.isEmpty()) break block8;
                this.logger(3, "selectFromWhere() empty response");
                return null;
            }
            if (list.size() <= 1) break block9;
            this.logger(2, "selectFromWhere() too many responses...");
            return null;
        }
        return list.get(0);
    }

    @Override
    public int sqlReloadMemory(YP_TCD_DAO_LOC_Memory yP_TCD_DAO_LOC_Memory) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            this.appendColumnList(yP_TCD_DAO_LOC_Memory, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_LOC_Memory.getFullTableName());
            String string = this.getContractKeyClause(yP_TCD_DAO_LOC_Memory);
            if (string != null && !string.isEmpty()) {
                stringBuilder.append(" WHERE");
                stringBuilder.append(string);
            }
            return yP_TCD_DAO_LOC_Memory.getDataBaseConnector().dealReloadForMemory(yP_TCD_DAO_LOC_Memory, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(3, "sqlReloadMemory() No result from database" + exception);
            return -1;
        }
    }

    @Override
    public int sqlReloadTable(YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            this.appendColumnList(yP_TCD_DAO_LOC_Table, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_LOC_Table.getFullTableName());
            String string = this.getContractKeyClause(yP_TCD_DAO_LOC_Table);
            if (string != null && !string.isEmpty()) {
                stringBuilder.append(" WHERE");
                stringBuilder.append(string);
            }
            return yP_TCD_DAO_LOC_Table.getDataBaseConnector().dealReloadForTable(yP_TCD_DAO_LOC_Table, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(3, "sqlReloadTable() No result from database" + exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private String sqlGetWhere(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            int n2;
            int n3;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
                String string2 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
                if (string2 != null && !string2.isEmpty()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE");
                    stringBuilder.append(string2);
                    return stringBuilder.toString();
                }
                return "";
            }
            boolean bl = false;
            String string3 = null;
            String string4 = null;
            StringBuilder stringBuilder = new StringBuilder();
            boolean bl2 = false;
            ArrayList<String> arrayList = null;
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                String string52;
                n3 = 0;
                n2 = 0;
                boolean bl3 = false;
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n4];
                n = 1;
                object = new StringBuilder();
                int n5 = 0;
                while (n5 < yP_ComplexGabarit.size()) {
                    block201: {
                        block208: {
                            Iterator<Object> iterator;
                            String string6;
                            YP_ComplexGabarit.OPERATOR oPERATOR;
                            block216: {
                                block218: {
                                    block217: {
                                        block215: {
                                            block214: {
                                                block213: {
                                                    block212: {
                                                        block211: {
                                                            block210: {
                                                                block209: {
                                                                    int n6;
                                                                    int n7;
                                                                    block207: {
                                                                        block206: {
                                                                            block205: {
                                                                                block204: {
                                                                                    block203: {
                                                                                        block202: {
                                                                                            block200: {
                                                                                                string52 = yP_ComplexGabarit.getFieldNameAt(n5);
                                                                                                oPERATOR = yP_ComplexGabarit.getOperatorAt(n5);
                                                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.MIN) break block200;
                                                                                                string3 = string52;
                                                                                                string4 = String.valueOf(string52) + System.currentTimeMillis();
                                                                                                n3 = 1;
                                                                                                break block201;
                                                                                            }
                                                                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.MAX) break block202;
                                                                                            string3 = string52;
                                                                                            string4 = String.valueOf(string52) + System.currentTimeMillis();
                                                                                            n2 = 1;
                                                                                            break block201;
                                                                                        }
                                                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.GROUP) break block203;
                                                                                        if (yP_ComplexGabaritArray.length > 1) {
                                                                                            stringBuilder = new StringBuilder();
                                                                                            int n8 = 0;
                                                                                            while (n8 < yP_ComplexGabaritArray.length) {
                                                                                                string6 = this.sqlGetWhere(yP_TCD_DesignAccesObject, string, yP_ComplexGabaritArray[n8]);
                                                                                                if (n8 == 0) {
                                                                                                    stringBuilder.append(string6);
                                                                                                } else {
                                                                                                    string6 = string6.trim();
                                                                                                    stringBuilder.append(" OR (");
                                                                                                    stringBuilder.append(string6.substring("WHERE ".length()));
                                                                                                    stringBuilder.append(")");
                                                                                                }
                                                                                                ++n8;
                                                                                            }
                                                                                            return stringBuilder.toString();
                                                                                        }
                                                                                        bl3 = true;
                                                                                        break block201;
                                                                                    }
                                                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.ORDER_ASC) break block204;
                                                                                    bl = true;
                                                                                    break block201;
                                                                                }
                                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.ORDER_DESC) break block205;
                                                                                bl = true;
                                                                                break block201;
                                                                            }
                                                                            if (!bl2) {
                                                                                bl2 = true;
                                                                                n = 0;
                                                                                stringBuilder.append(" WHERE (");
                                                                            } else if (n == 1) {
                                                                                stringBuilder.append(" OR (");
                                                                                n = 0;
                                                                            } else {
                                                                                object.append(" AND ");
                                                                            }
                                                                            iterator = yP_ComplexGabarit.getObjectAt(n5);
                                                                            if (iterator != null) break block206;
                                                                            object.append("( 1 = 0)");
                                                                            break block201;
                                                                        }
                                                                        string6 = this.sqlValue(iterator);
                                                                        object.append('(');
                                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.CONTAIN) break block207;
                                                                        if (iterator instanceof Bitmap) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" & ");
                                                                            object.append(string6);
                                                                            object.append(" = ");
                                                                            object.append(string6);
                                                                            object.append(' ');
                                                                        } else if (iterator instanceof byte[]) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" like '%");
                                                                            object.append(string6.substring(1, string6.length() - 1));
                                                                            object.append("%' ");
                                                                        } else if (iterator instanceof Integer) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" like '%");
                                                                            object.append(string6);
                                                                            object.append("%' ");
                                                                        } else if (iterator instanceof Long) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" like '%");
                                                                            object.append(string6);
                                                                            object.append("%' ");
                                                                        } else {
                                                                            this.logger(2, "sqlGetWhere() unknown type for operator contain");
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" like '%");
                                                                            if (string6.startsWith("'")) {
                                                                                object.append(string6.substring(1, string6.length() - 1));
                                                                            } else {
                                                                                object.append(string6);
                                                                            }
                                                                            object.append("%' ");
                                                                        }
                                                                        break block208;
                                                                    }
                                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING) break block209;
                                                                    if (iterator instanceof byte[]) {
                                                                        boolean bl4 = true;
                                                                        n7 = string6.length() - 1;
                                                                        while (n7 > 0) {
                                                                            if (bl4) {
                                                                                bl4 = false;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" = '");
                                                                            object.append(string6.substring(1, n7));
                                                                            object.append("' ");
                                                                            --n7;
                                                                        }
                                                                    } else if (iterator instanceof Integer) {
                                                                        int n9 = (Integer)((Object)iterator);
                                                                        n7 = 1;
                                                                        n6 = string6.length();
                                                                        while (n6 >= 1) {
                                                                            if (n7 != 0) {
                                                                                n7 = 0;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" = ");
                                                                            object.append(n9);
                                                                            object.append(" ");
                                                                            n9 /= 10;
                                                                            --n6;
                                                                        }
                                                                    } else if (iterator instanceof Long) {
                                                                        long l = (Long)((Object)iterator);
                                                                        n6 = 1;
                                                                        int n10 = string6.length();
                                                                        while (n10 >= 1) {
                                                                            if (n6 != 0) {
                                                                                n6 = 0;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" = ");
                                                                            object.append(l);
                                                                            object.append(" ");
                                                                            l /= 10L;
                                                                            --n10;
                                                                        }
                                                                    } else {
                                                                        this.logger(2, "sqlGetWhere() unknown type for operator MATCH_BEGINNING");
                                                                        boolean bl5 = true;
                                                                        n7 = string6.length();
                                                                        while (n7 >= 1) {
                                                                            if (bl5) {
                                                                                bl5 = false;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                            object.append(" = '");
                                                                            object.append(string6.substring(0, n7));
                                                                            object.append("' ");
                                                                            --n7;
                                                                        }
                                                                    }
                                                                    break block208;
                                                                }
                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.START_WITH) break block210;
                                                                if (iterator instanceof byte[]) {
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                    object.append(" like ");
                                                                    object.append(string6.substring(0, string6.length() - 1));
                                                                    object.append("%' ");
                                                                } else if (iterator instanceof Integer) {
                                                                    int n11 = (Integer)((Object)iterator);
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                    object.append(" like '");
                                                                    object.append(n11);
                                                                    object.append("%' ");
                                                                } else if (iterator instanceof Long) {
                                                                    long l = (Long)((Object)iterator);
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                    object.append(" like '");
                                                                    object.append(l);
                                                                    object.append("%' ");
                                                                } else {
                                                                    this.logger(2, "sqlGetWhere() unknown type for operator START_WITH");
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                    object.append(" like ");
                                                                    object.append(string6.substring(0, string6.length() - 1));
                                                                    object.append("%' ");
                                                                }
                                                                break block208;
                                                            }
                                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.GREATER) break block211;
                                                            if (iterator instanceof byte[]) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else if (iterator instanceof Integer) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else if (iterator instanceof Long) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else if (iterator instanceof Float) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else if (iterator instanceof Timestamp) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else if (iterator instanceof Date) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            } else {
                                                                this.logger(2, "sqlGetWhere() unknown type for operator GREATER");
                                                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                                object.append(" > ");
                                                                object.append(string6);
                                                                object.append(' ');
                                                            }
                                                            break block208;
                                                        }
                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.LESS) break block212;
                                                        if (iterator instanceof byte[]) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else if (iterator instanceof Integer) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else if (iterator instanceof Long) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else if (iterator instanceof Float) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else if (iterator instanceof Timestamp) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else if (iterator instanceof Date) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        } else {
                                                            this.logger(2, "sqlGetWhere() unknown type for operator LESS");
                                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                            object.append(" < ");
                                                            object.append(string6);
                                                            object.append(' ');
                                                        }
                                                        break block208;
                                                    }
                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.EQUAL) break block213;
                                                    if (iterator instanceof byte[]) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Integer) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Long) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Float) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Timestamp) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Date) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Boolean) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Enum) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else if (iterator instanceof Bitmap) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    } else {
                                                        this.logger(2, "sqlGetWhere() unknown type for operator EQUAL");
                                                        this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                        object.append(" = ");
                                                        object.append(string6);
                                                        object.append(' ');
                                                    }
                                                    break block208;
                                                }
                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE) break block214;
                                                if (iterator instanceof byte[]) {
                                                    object.append("UPPER(");
                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                    object.append(") = UPPER(");
                                                    object.append(string6);
                                                    object.append(") ");
                                                } else {
                                                    this.logger(2, "sqlGetWhere() unknown type for operator EQUAL_IGNORE_CASE");
                                                    object.append("UPPER(");
                                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                                    object.append(") = UPPER(");
                                                    object.append(string6);
                                                    object.append(") ");
                                                }
                                                break block208;
                                            }
                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.LIKE) break block215;
                                            this.appendSQLColumnName((StringBuilder)object, string, string52);
                                            object.append(" LIKE ");
                                            object.append(string6);
                                            object.append(' ');
                                            break block208;
                                        }
                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.IN) break block216;
                                        if (iterator instanceof Object[]) break block217;
                                        this.logger(2, "sqlGetWhere() Object must be an array of object for operator IN");
                                        object.append("( 1 = 0)");
                                        break block201;
                                    }
                                    if (((Object[])iterator).length != 0) break block218;
                                    this.logger(2, "sqlGetWhere() There must be at least one object for operator IN");
                                    object.append("( 1 = 0)");
                                    break block201;
                                }
                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                object.append(" IN (");
                                object.append(string6);
                                object.append(") ");
                                break block208;
                            }
                            if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN_SQL) {
                                this.appendSQLColumnName((StringBuilder)object, string, string52);
                                object.append(" IN (");
                                object.append(iterator);
                                object.append(") ");
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                                if (iterator instanceof byte[]) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Integer) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Long) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Float) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Boolean) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Enum) {
                                    object.append('(');
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(" OR ");
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" IS NULL) ");
                                } else if (iterator instanceof Bitmap) {
                                    object.append('(');
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(" OR ");
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" IS NULL) ");
                                } else {
                                    this.logger(2, "sqlGetWhere() unknown type for operator DIFFERENT");
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <> ");
                                    object.append(string6);
                                    object.append(' ');
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                                if (iterator instanceof byte[]) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Integer) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Long) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Float) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else {
                                    this.logger(2, "sqlGetWhere() unknown type for operator GREATER_OR_EQUAL");
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" >= ");
                                    object.append(string6);
                                    object.append(' ');
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                                if (iterator instanceof byte[]) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Integer) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Long) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Float) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                } else {
                                    this.logger(2, "sqlGetWhere() unknown type for operator LESS_OR_EQUAL");
                                    this.appendSQLColumnName((StringBuilder)object, string, string52);
                                    object.append(" <= ");
                                    object.append(string6);
                                    object.append(' ');
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP) {
                                String string7 = String.valueOf('[') + string + FIELD_MID + string52 + ']' + " = " + string6 + ' ';
                                object.append(string7);
                                if (arrayList == null) {
                                    arrayList = new ArrayList<String>();
                                }
                                arrayList.add(string7);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP) {
                                String string8 = String.valueOf('[') + string + FIELD_MID + string52 + ']' + " <> " + string6 + ' ';
                                object.append(string8);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string8);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                                String string9 = String.valueOf('[') + string + FIELD_MID + string52 + ']' + " < " + string6 + ' ';
                                object.append(string9);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string9);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP) {
                                String string10 = String.valueOf('[') + string + FIELD_MID + string52 + ']' + " IN( " + string6 + ")";
                                object.append(string10);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string10);
                            } else {
                                this.logger(2, "sqlGetWhere() unknown operator");
                            }
                        }
                        object.append(')');
                    }
                    ++n5;
                }
                String string11 = this.getContractKeyClause(yP_TCD_DesignAccesObject, yP_ComplexGabarit);
                if (string11 != null && !string11.isEmpty()) {
                    if (!bl2) {
                        bl2 = true;
                        n = 0;
                        stringBuilder.append(" WHERE (");
                    } else if (n == 1) {
                        stringBuilder.append(" OR (");
                        n = 0;
                    } else {
                        object.append(" AND ");
                    }
                    object.append(string11);
                }
                if (n2 == 0 && n3 == 0) {
                    if (bl3) {
                        this.logger(2, "sqlGetWhere() group operator is for aggregated columns (MIN, MAX)");
                        return null;
                    }
                    if (object.length() > 0) {
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else if (bl3) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE ");
                    this.appendSQLColumnName(stringBuilder, yP_TCD_DesignAccesObject.getTableName(), yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" IN (SELECT * FROM (SELECT ");
                    this.appendSQLColumnName(stringBuilder, yP_TCD_DesignAccesObject.getTableName(), yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(" INNER JOIN (SELECT ");
                    for (String string52 : yP_ComplexGabarit.groupFieldNameList) {
                        this.appendSQLColumnName(stringBuilder, string, string52);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    this.appendSQLColumnName(stringBuilder, string, string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string4);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            string52 = object.toString();
                            for (String string12 : arrayList) {
                                string52 = string52.replace(string12, " 1=1 ");
                            }
                            stringBuilder.append(string52);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    boolean bl6 = true;
                    for (String string13 : yP_ComplexGabarit.groupFieldNameList) {
                        if (bl6) {
                            bl6 = false;
                        } else {
                            stringBuilder.append(", ");
                        }
                        this.appendSQLColumnName(stringBuilder, string, string13);
                    }
                    stringBuilder.append(") tmp");
                    stringBuilder.append(" ON ");
                    for (String string14 : yP_ComplexGabarit.groupFieldNameList) {
                        this.appendSQLColumnName(stringBuilder, string, string14);
                        stringBuilder.append(" = ");
                        this.appendSQLColumnName(stringBuilder, "tmp", string14);
                        stringBuilder.append(" AND ");
                    }
                    this.appendSQLColumnName(stringBuilder, string, string3);
                    stringBuilder.append(" = ");
                    this.appendSQLColumnName(stringBuilder, "tmp", string4);
                    stringBuilder.append(") tmp)");
                    if (object.length() > 0) {
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else {
                    if (stringBuilder.length() == 0) {
                        bl2 = true;
                        stringBuilder.append(" WHERE (");
                    } else if (object.length() == 0) {
                        if (!bl2) {
                            bl2 = true;
                            stringBuilder.append(" WHERE (");
                        } else {
                            stringBuilder.append(" OR (");
                        }
                    }
                    this.appendSQLColumnName(stringBuilder, string3);
                    stringBuilder.append(" = (SELECT ");
                    stringBuilder.append(string3);
                    if (n3 != 0) {
                        stringBuilder.append(" FROM (SELECT MIN(");
                    } else {
                        stringBuilder.append(" FROM (SELECT MAX(");
                    }
                    stringBuilder.append(string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            string52 = object.toString();
                            for (String string15 : arrayList) {
                                string52 = string52.replace(string15, " 1=1 ");
                            }
                            stringBuilder.append(string52);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(") ");
                    } else {
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                    }
                }
                ++n4;
            }
            if (bl) {
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n2 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n2) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.isOrdered) {
                        stringBuilder.append(" ORDER  BY ");
                        boolean bl7 = true;
                        n = 0;
                        while (n < yP_ComplexGabarit.size()) {
                            object = yP_ComplexGabarit.getOperatorAt(n);
                            if (object == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                this.appendSQLColumnName(stringBuilder, string, yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" ASC ");
                            } else if (object == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                this.appendSQLColumnName(stringBuilder, string, yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" DESC ");
                            }
                            ++n;
                        }
                        break;
                    }
                    ++n3;
                }
            }
            return stringBuilder.toString();
        }
        catch (Exception exception) {
            this.logger(1, "sqlGetWhere()  " + exception);
            return null;
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private String sqlGetPreparedWhere(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, List<YP_PreparedValue> list, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            int n2;
            int n3;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
                String string2 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
                if (string2 != null && !string2.isEmpty()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE");
                    stringBuilder.append(string2);
                    return stringBuilder.toString();
                }
                return "";
            }
            boolean bl = false;
            String string3 = null;
            String string4 = null;
            StringBuilder stringBuilder = new StringBuilder();
            boolean bl2 = false;
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                n3 = 0;
                n2 = 0;
                boolean bl3 = false;
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n4];
                n = 1;
                object = new StringBuilder();
                ArrayList<YP_PreparedValue> arrayList = new ArrayList<YP_PreparedValue>();
                int n5 = 0;
                while (n5 < yP_ComplexGabarit.size()) {
                    block233: {
                        block240: {
                            Iterator<String> iterator;
                            String string5;
                            YP_ComplexGabarit.OPERATOR oPERATOR;
                            String string6;
                            block248: {
                                Object[] objectArray;
                                int n6;
                                block250: {
                                    block249: {
                                        block247: {
                                            block246: {
                                                block245: {
                                                    block244: {
                                                        block243: {
                                                            block242: {
                                                                block241: {
                                                                    block239: {
                                                                        block238: {
                                                                            block237: {
                                                                                block236: {
                                                                                    block235: {
                                                                                        block234: {
                                                                                            block232: {
                                                                                                string6 = yP_ComplexGabarit.getFieldNameAt(n5);
                                                                                                oPERATOR = yP_ComplexGabarit.getOperatorAt(n5);
                                                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.MIN) break block232;
                                                                                                string3 = string6;
                                                                                                string4 = String.valueOf(string6) + System.currentTimeMillis();
                                                                                                n3 = 1;
                                                                                                break block233;
                                                                                            }
                                                                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.MAX) break block234;
                                                                                            string3 = string6;
                                                                                            string4 = String.valueOf(string6) + System.currentTimeMillis();
                                                                                            n2 = 1;
                                                                                            break block233;
                                                                                        }
                                                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.GROUP) break block235;
                                                                                        if (yP_ComplexGabaritArray.length > 1) {
                                                                                            stringBuilder = new StringBuilder();
                                                                                            list.clear();
                                                                                            int n7 = 0;
                                                                                            while (n7 < yP_ComplexGabaritArray.length) {
                                                                                                string5 = this.sqlGetPreparedWhere(yP_TCD_DesignAccesObject, string, list, yP_ComplexGabaritArray[n7]);
                                                                                                if (n7 == 0) {
                                                                                                    stringBuilder.append(string5);
                                                                                                } else {
                                                                                                    string5 = string5.trim();
                                                                                                    stringBuilder.append(" OR (");
                                                                                                    stringBuilder.append(string5.substring("WHERE ".length()));
                                                                                                    stringBuilder.append(")");
                                                                                                }
                                                                                                ++n7;
                                                                                            }
                                                                                            return stringBuilder.toString();
                                                                                        }
                                                                                        bl3 = true;
                                                                                        break block233;
                                                                                    }
                                                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.ORDER_ASC) break block236;
                                                                                    bl = true;
                                                                                    break block233;
                                                                                }
                                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.ORDER_DESC) break block237;
                                                                                bl = true;
                                                                                break block233;
                                                                            }
                                                                            if (!bl2) {
                                                                                bl2 = true;
                                                                                n = 0;
                                                                                stringBuilder.append(" WHERE (");
                                                                            } else if (n == 1) {
                                                                                stringBuilder.append(" OR (");
                                                                                n = 0;
                                                                            } else {
                                                                                object.append(" AND ");
                                                                            }
                                                                            iterator = yP_ComplexGabarit.getObjectAt(n5);
                                                                            if (iterator != null) break block238;
                                                                            object.append("( 1 = 0)");
                                                                            break block233;
                                                                        }
                                                                        string5 = this.sqlValue(iterator);
                                                                        object.append('(');
                                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.CONTAIN) break block239;
                                                                        if (iterator instanceof Bitmap) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" & ? = ? ");
                                                                            arrayList.add(new YP_PreparedValue(((Bitmap)((Object)iterator)).getBitmap(), -5));
                                                                            arrayList.add(new YP_PreparedValue(((Bitmap)((Object)iterator)).getBitmap(), -5));
                                                                        } else if (iterator instanceof byte[]) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" like ? ");
                                                                            arrayList.add(new YP_PreparedValue("%" + string5.substring(1, string5.length() - 1) + "%", 12));
                                                                        } else if (iterator instanceof Integer) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" like ? ");
                                                                            arrayList.add(new YP_PreparedValue("%" + string5 + "%", 12));
                                                                        } else if (iterator instanceof Long) {
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" like ? ");
                                                                            arrayList.add(new YP_PreparedValue("%" + string5 + "%", 12));
                                                                        } else {
                                                                            this.logger(2, "sqlGetPreparedWhere() unknown type for operator CONTAIN");
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" like '%");
                                                                            if (string5.startsWith("'")) {
                                                                                object.append(string5.substring(1, string5.length() - 1));
                                                                            } else {
                                                                                object.append(string5);
                                                                            }
                                                                            object.append("%' ");
                                                                        }
                                                                        break block240;
                                                                    }
                                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING) break block241;
                                                                    if (iterator instanceof byte[]) {
                                                                        String string7 = YP_Row.getStringValue((byte[])iterator);
                                                                        n6 = 1;
                                                                        int n8 = string7.length();
                                                                        while (n8 >= 0) {
                                                                            if (n6 != 0) {
                                                                                n6 = 0;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" = ? ");
                                                                            arrayList.add(new YP_PreparedValue(string7.substring(0, n8), 12));
                                                                            --n8;
                                                                        }
                                                                    } else if (iterator instanceof Integer) {
                                                                        int n9 = (Integer)((Object)iterator);
                                                                        n6 = 1;
                                                                        int n10 = string5.length();
                                                                        while (n10 >= 1) {
                                                                            if (n6 != 0) {
                                                                                n6 = 0;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" = ? ");
                                                                            arrayList.add(new YP_PreparedValue(n9, 4));
                                                                            n9 /= 10;
                                                                            --n10;
                                                                        }
                                                                    } else if (iterator instanceof Long) {
                                                                        long l = (Long)((Object)iterator);
                                                                        boolean bl4 = true;
                                                                        int n11 = string5.length();
                                                                        while (n11 >= 1) {
                                                                            if (bl4) {
                                                                                bl4 = false;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" = ? ");
                                                                            arrayList.add(new YP_PreparedValue(l, -5));
                                                                            l /= 10L;
                                                                            --n11;
                                                                        }
                                                                    } else {
                                                                        this.logger(2, "sqlGetPreparedWhere() unknown type for operator MATCH_BEGINNING");
                                                                        boolean bl5 = true;
                                                                        n6 = string5.length();
                                                                        while (n6 >= 1) {
                                                                            if (bl5) {
                                                                                bl5 = false;
                                                                            } else {
                                                                                object.append(" OR ");
                                                                            }
                                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                            object.append(" = '");
                                                                            object.append(string5.substring(0, n6));
                                                                            object.append("' ");
                                                                            --n6;
                                                                        }
                                                                    }
                                                                    break block240;
                                                                }
                                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.START_WITH) break block242;
                                                                if (iterator instanceof byte[]) {
                                                                    String string8 = YP_Row.getStringValue((byte[])iterator);
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                    object.append(" like ? ");
                                                                    arrayList.add(new YP_PreparedValue(String.valueOf(string8) + '%', 12));
                                                                } else if (iterator instanceof Integer) {
                                                                    int n12 = (Integer)((Object)iterator);
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                    object.append(" like ? ");
                                                                    arrayList.add(new YP_PreparedValue(String.valueOf(n12) + "%", 12));
                                                                } else if (iterator instanceof Long) {
                                                                    long l = (Long)((Object)iterator);
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                    object.append(" like ? ");
                                                                    arrayList.add(new YP_PreparedValue(String.valueOf(l) + "%", 12));
                                                                } else {
                                                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator START_WITH");
                                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                    object.append(" like ");
                                                                    object.append(string5.substring(0, string5.length() - 1));
                                                                    object.append("%' ");
                                                                }
                                                                break block240;
                                                            }
                                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.GREATER) break block243;
                                                            if (iterator instanceof byte[]) {
                                                                String string9 = YP_Row.getStringValue((byte[])iterator);
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(string9, 12));
                                                            } else if (iterator instanceof Integer) {
                                                                int n13 = (Integer)((Object)iterator);
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(n13, 4));
                                                            } else if (iterator instanceof Long) {
                                                                long l = (Long)((Object)iterator);
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(l, -5));
                                                            } else if (iterator instanceof Float) {
                                                                float f = ((Float)((Object)iterator)).floatValue();
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                                            } else if (iterator instanceof Timestamp) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(iterator, 93));
                                                            } else if (iterator instanceof Date) {
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ? ");
                                                                arrayList.add(new YP_PreparedValue(iterator, 91));
                                                            } else {
                                                                this.logger(2, "sqlGetPreparedWhere() unknown type for operator GREATER");
                                                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                                object.append(" > ");
                                                                object.append(string5);
                                                                object.append(' ');
                                                            }
                                                            break block240;
                                                        }
                                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.LESS) break block244;
                                                        if (iterator instanceof byte[]) {
                                                            String string10 = YP_Row.getStringValue((byte[])iterator);
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(string10, 12));
                                                        } else if (iterator instanceof Integer) {
                                                            int n14 = (Integer)((Object)iterator);
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(n14, 4));
                                                        } else if (iterator instanceof Long) {
                                                            long l = (Long)((Object)iterator);
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(l, -5));
                                                        } else if (iterator instanceof Float) {
                                                            float f = ((Float)((Object)iterator)).floatValue();
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                                        } else if (iterator instanceof Timestamp) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(iterator, 93));
                                                        } else if (iterator instanceof Date) {
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ? ");
                                                            arrayList.add(new YP_PreparedValue(iterator, 91));
                                                        } else {
                                                            this.logger(2, "sqlGetPreparedWhere() unknown type for operator LESS");
                                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                            object.append(" < ");
                                                            object.append(string5);
                                                            object.append(' ');
                                                        }
                                                        break block240;
                                                    }
                                                    if (oPERATOR != YP_ComplexGabarit.OPERATOR.EQUAL) break block245;
                                                    if (iterator instanceof byte[]) {
                                                        String string11 = YP_Row.getStringValue((byte[])iterator);
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(string11, 12));
                                                    } else if (iterator instanceof Integer) {
                                                        int n15 = (Integer)((Object)iterator);
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(n15, 4));
                                                    } else if (iterator instanceof Long) {
                                                        long l = (Long)((Object)iterator);
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(l, -5));
                                                    } else if (iterator instanceof Float) {
                                                        float f = ((Float)((Object)iterator)).floatValue();
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                                    } else if (iterator instanceof Timestamp) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(iterator, 93));
                                                    } else if (iterator instanceof Date) {
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(iterator, 91));
                                                    } else if (iterator instanceof Boolean) {
                                                        int n16 = (Boolean)((Object)iterator) != false ? 1 : 0;
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(n16, -6));
                                                    } else if (iterator instanceof Enum) {
                                                        String string12 = iterator.toString();
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(string12, 12));
                                                    } else if (iterator instanceof Bitmap) {
                                                        long l = ((Bitmap)((Object)iterator)).getBitmap();
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ? ");
                                                        arrayList.add(new YP_PreparedValue(l, -5));
                                                    } else {
                                                        this.logger(2, "sqlGetPreparedWhere() unknown type for operator EQUAL");
                                                        this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                        object.append(" = ");
                                                        object.append(string5);
                                                        object.append(' ');
                                                    }
                                                    break block240;
                                                }
                                                if (oPERATOR != YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE) break block246;
                                                if (iterator instanceof byte[]) {
                                                    String string13 = YP_Row.getStringValue((byte[])iterator);
                                                    object.append("UPPER(");
                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                    object.append(") = UPPER(?) ");
                                                    arrayList.add(new YP_PreparedValue(string13, 12));
                                                } else {
                                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator EQUAL_IGNORE_CASE");
                                                    object.append("UPPER(");
                                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                                    object.append(") = UPPER(");
                                                    object.append(string5);
                                                    object.append(") ");
                                                }
                                                break block240;
                                            }
                                            if (oPERATOR != YP_ComplexGabarit.OPERATOR.LIKE) break block247;
                                            this.appendSQLColumnName((StringBuilder)object, string, string6);
                                            object.append(" LIKE ");
                                            object.append(string5);
                                            object.append(' ');
                                            break block240;
                                        }
                                        if (oPERATOR != YP_ComplexGabarit.OPERATOR.IN) break block248;
                                        if (iterator instanceof Object[]) break block249;
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "sqlGetPreparedWhere() Object must be an array of object for operator IN");
                                        }
                                        object.append("( 1 = 0)");
                                        break block233;
                                    }
                                    objectArray = (Object[])iterator;
                                    if (objectArray.length != 0) break block250;
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "sqlGetPreparedWhere() There must be at least one object for operator IN");
                                    }
                                    object.append("( 1 = 0)");
                                    break block233;
                                }
                                if (objectArray[0] instanceof String) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], 12));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof byte[]) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        String string14 = YP_Row.getStringValue((byte[])objectArray[n6]);
                                        arrayList.add(new YP_PreparedValue(string14, 12));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Integer) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], 4));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Long) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], -5));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Float) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], 6));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], 93));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        arrayList.add(new YP_PreparedValue(objectArray[n6], 91));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Boolean) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        int n17 = (Boolean)objectArray[n6] != false ? 1 : 0;
                                        arrayList.add(new YP_PreparedValue(n17, -6));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Enum) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        String string15 = objectArray[n6].toString();
                                        arrayList.add(new YP_PreparedValue(string15, 12));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else if (objectArray[0] instanceof Bitmap) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    n6 = 0;
                                    while (n6 < objectArray.length) {
                                        if (n6 != 0) {
                                            object.append(',');
                                        }
                                        object.append("?");
                                        long l = ((Bitmap)objectArray[n6]).getBitmap();
                                        arrayList.add(new YP_PreparedValue(l, -5));
                                        ++n6;
                                    }
                                    object.append(") ");
                                } else {
                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator IN");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IN (");
                                    object.append(string5);
                                    object.append(") ");
                                }
                                break block240;
                            }
                            if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN_SQL) {
                                this.appendSQLColumnName((StringBuilder)object, string, string6);
                                object.append(" IN (");
                                object.append(iterator);
                                object.append(") ");
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                                if (iterator instanceof byte[]) {
                                    String string16 = YP_Row.getStringValue((byte[])iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(string16, 12));
                                } else if (iterator instanceof Integer) {
                                    int n18 = (Integer)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(n18, 4));
                                } else if (iterator instanceof Long) {
                                    long l = (Long)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(l, -5));
                                } else if (iterator instanceof Float) {
                                    float f = ((Float)((Object)iterator)).floatValue();
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 93));
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 91));
                                } else if (iterator instanceof Boolean) {
                                    int n19 = (Boolean)((Object)iterator) != false ? 1 : 0;
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? ");
                                    arrayList.add(new YP_PreparedValue(n19, -6));
                                } else if (iterator instanceof Enum) {
                                    String string17 = iterator.toString();
                                    object.append('(');
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? OR ");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IS NULL) ");
                                    arrayList.add(new YP_PreparedValue(string17, 12));
                                } else if (iterator instanceof Bitmap) {
                                    long l = ((Bitmap)((Object)iterator)).getBitmap();
                                    object.append('(');
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ? OR ");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" IS NULL) ");
                                    arrayList.add(new YP_PreparedValue(l, -5));
                                } else {
                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator DIFFERENT");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <> ");
                                    object.append(string5);
                                    object.append(' ');
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                                if (iterator instanceof byte[]) {
                                    String string18 = YP_Row.getStringValue((byte[])iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(string18, 12));
                                } else if (iterator instanceof Integer) {
                                    int n20 = (Integer)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(n20, 4));
                                } else if (iterator instanceof Long) {
                                    long l = (Long)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(l, -5));
                                } else if (iterator instanceof Float) {
                                    float f = ((Float)((Object)iterator)).floatValue();
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 93));
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 91));
                                } else {
                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator GREATER_OR_EQUAL");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" >= ");
                                    object.append(string5);
                                    object.append(' ');
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                                if (iterator instanceof byte[]) {
                                    String string19 = YP_Row.getStringValue((byte[])iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(string19, 12));
                                } else if (iterator instanceof Integer) {
                                    int n21 = (Integer)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(n21, 4));
                                } else if (iterator instanceof Long) {
                                    long l = (Long)((Object)iterator);
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(l, -5));
                                } else if (iterator instanceof Float) {
                                    float f = ((Float)((Object)iterator)).floatValue();
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(Float.valueOf(f), 6));
                                } else if (iterator instanceof Timestamp) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 93));
                                } else if (iterator instanceof Date) {
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ? ");
                                    arrayList.add(new YP_PreparedValue(iterator, 91));
                                } else {
                                    this.logger(2, "sqlGetPreparedWhere() unknown type for operator LESS_OR_EQUAL");
                                    this.appendSQLColumnName((StringBuilder)object, string, string6);
                                    object.append(" <= ");
                                    object.append(string5);
                                    object.append(' ');
                                }
                            } else {
                                if (oPERATOR == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP) {
                                    if (this.getLogLevel() >= 5) {
                                        this.logger(5, "sqlGetPreparedWhere() not done for EQUAL_AFTER_GROUP fall back to sqlGetWhere()");
                                    }
                                    list.clear();
                                    return this.sqlGetWhere(yP_TCD_DesignAccesObject, string, yP_ComplexGabaritArray);
                                }
                                if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP) {
                                    if (this.getLogLevel() >= 5) {
                                        this.logger(5, "sqlGetPreparedWhere() not done for DIFFERENT_AFTER_GROUP fall back to sqlGetWhere()");
                                    }
                                    list.clear();
                                    return this.sqlGetWhere(yP_TCD_DesignAccesObject, string, yP_ComplexGabaritArray);
                                }
                                if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                                    if (this.getLogLevel() >= 5) {
                                        this.logger(5, "sqlGetPreparedWhere() not done for LESS_AFTER_GROUP fall back to sqlGetWhere()");
                                    }
                                    list.clear();
                                    return this.sqlGetWhere(yP_TCD_DesignAccesObject, string, yP_ComplexGabaritArray);
                                }
                                if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP) {
                                    if (this.getLogLevel() >= 5) {
                                        this.logger(5, "sqlGetPreparedWhere() not done for IN_AFTER_GROUP fall back to sqlGetWhere()");
                                    }
                                    list.clear();
                                    return this.sqlGetWhere(yP_TCD_DesignAccesObject, string, yP_ComplexGabaritArray);
                                }
                                this.logger(2, "sqlGetPreparedWhere() unknown operator");
                            }
                        }
                        object.append(')');
                    }
                    ++n5;
                }
                String string20 = this.getContractKeyClause(yP_TCD_DesignAccesObject, yP_ComplexGabarit);
                if (string20 != null && !string20.isEmpty()) {
                    if (!bl2) {
                        bl2 = true;
                        n = 0;
                        stringBuilder.append(" WHERE (");
                    } else if (n == 1) {
                        stringBuilder.append(" OR (");
                        n = 0;
                    } else {
                        object.append(" AND ");
                    }
                    object.append(string20);
                }
                if (n2 == 0 && n3 == 0) {
                    if (bl3) {
                        this.logger(2, "sqlGetPreparedWhere() group operator is for aggregated columns (MIN, MAX)");
                        return null;
                    }
                    if (object.length() > 0) {
                        stringBuilder.append((CharSequence)object);
                        list.addAll(arrayList);
                        stringBuilder.append(')');
                    }
                } else if (bl3) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE ");
                    this.appendSQLColumnName(stringBuilder, yP_TCD_DesignAccesObject.getTableName(), yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" IN (SELECT * FROM (SELECT ");
                    this.appendSQLColumnName(stringBuilder, yP_TCD_DesignAccesObject.getTableName(), yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    stringBuilder.append(" INNER JOIN (SELECT ");
                    for (String string6 : yP_ComplexGabarit.groupFieldNameList) {
                        this.appendSQLColumnName(stringBuilder, string, string6);
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    this.appendSQLColumnName(stringBuilder, string, string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string4);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        stringBuilder.append((CharSequence)object);
                        list.addAll(arrayList);
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    boolean bl6 = true;
                    for (String string21 : yP_ComplexGabarit.groupFieldNameList) {
                        if (bl6) {
                            bl6 = false;
                        } else {
                            stringBuilder.append(", ");
                        }
                        this.appendSQLColumnName(stringBuilder, string, string21);
                    }
                    stringBuilder.append(") tmp");
                    stringBuilder.append(" ON ");
                    for (String string22 : yP_ComplexGabarit.groupFieldNameList) {
                        this.appendSQLColumnName(stringBuilder, string, string22);
                        stringBuilder.append(" = ");
                        this.appendSQLColumnName(stringBuilder, "tmp", string22);
                        stringBuilder.append(" AND ");
                    }
                    this.appendSQLColumnName(stringBuilder, string, string3);
                    stringBuilder.append(" = ");
                    this.appendSQLColumnName(stringBuilder, "tmp", string4);
                    stringBuilder.append(") tmp)");
                    if (object.length() > 0) {
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        list.addAll(arrayList);
                        stringBuilder.append(')');
                    }
                } else {
                    if (stringBuilder.length() == 0) {
                        bl2 = true;
                        stringBuilder.append(" WHERE (");
                    } else if (object.length() == 0) {
                        if (!bl2) {
                            bl2 = true;
                            stringBuilder.append(" WHERE (");
                        } else {
                            stringBuilder.append(" OR (");
                        }
                    }
                    this.appendSQLColumnName(stringBuilder, string3);
                    stringBuilder.append(" = (SELECT ");
                    stringBuilder.append(string3);
                    if (n3 != 0) {
                        stringBuilder.append(" FROM (SELECT MIN(");
                    } else {
                        stringBuilder.append(" FROM (SELECT MAX(");
                    }
                    stringBuilder.append(string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        stringBuilder.append((CharSequence)object);
                        list.addAll(arrayList);
                        stringBuilder.append(')');
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        list.addAll(arrayList);
                        stringBuilder.append(") ");
                    } else {
                        stringBuilder.append(')');
                        stringBuilder.append("tmp)");
                        stringBuilder.append(')');
                    }
                }
                ++n4;
            }
            if (bl) {
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n2 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n2) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.isOrdered) {
                        stringBuilder.append(" ORDER  BY ");
                        boolean bl7 = true;
                        n = 0;
                        while (n < yP_ComplexGabarit.size()) {
                            object = yP_ComplexGabarit.getOperatorAt(n);
                            if (object == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                this.appendSQLColumnName(stringBuilder, string, yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" ASC ");
                            } else if (object == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                                if (bl7) {
                                    bl7 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                this.appendSQLColumnName(stringBuilder, string, yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(" DESC ");
                            }
                            ++n;
                        }
                        break;
                    }
                    ++n3;
                }
            }
            return stringBuilder.toString();
        }
        catch (Exception exception) {
            this.logger(1, "sqlGetPreparedWhere()  " + exception);
            return null;
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive exception aggregation
     */
    private String sqlGetWhereForTwo(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            Object object;
            int n;
            int n2;
            int n3;
            if (yP_ComplexGabaritArray == null || yP_ComplexGabaritArray.length == 0 || yP_ComplexGabaritArray[0] == null) {
                String string2 = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction);
                if (string2 != null && !string2.isEmpty()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" WHERE");
                    stringBuilder.append(string2);
                    return stringBuilder.toString();
                }
                return "";
            }
            boolean bl = false;
            String string3 = null;
            StringBuilder stringBuilder = new StringBuilder();
            boolean bl2 = false;
            ArrayList<String> arrayList = null;
            int n4 = 0;
            while (n4 < yP_ComplexGabaritArray.length) {
                String string42;
                n3 = 0;
                n2 = 0;
                boolean bl3 = false;
                YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray[n4];
                n = 1;
                object = new StringBuilder();
                int n5 = 0;
                while (n5 < yP_ComplexGabarit.size()) {
                    Object object2;
                    string42 = yP_ComplexGabarit.getFieldNameAt(n5);
                    YP_ComplexGabarit.OPERATOR oPERATOR = yP_ComplexGabarit.getOperatorAt(n5);
                    if (oPERATOR == YP_ComplexGabarit.OPERATOR.MIN) {
                        string3 = string42;
                        String cfr_ignored_0 = String.valueOf(string42) + System.currentTimeMillis();
                        n3 = 1;
                    } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.MAX) {
                        string3 = string42;
                        String cfr_ignored_1 = String.valueOf(string42) + System.currentTimeMillis();
                        n2 = 1;
                    } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.GROUP) {
                        if (yP_ComplexGabaritArray.length > 1) {
                            void var19_50;
                            stringBuilder = new StringBuilder();
                            boolean bl4 = false;
                            while (var19_50 < yP_ComplexGabaritArray.length) {
                                object2 = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, string, yP_ComplexGabaritArray[var19_50]);
                                if (var19_50 == false) {
                                    stringBuilder.append((String)object2);
                                } else {
                                    object2 = ((String)object2).trim();
                                    stringBuilder.append(" OR (");
                                    stringBuilder.append(((String)object2).substring("WHERE ".length()));
                                    stringBuilder.append(")");
                                }
                                ++var19_50;
                            }
                            return stringBuilder.toString();
                        }
                        bl3 = true;
                    } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                        bl = true;
                    } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                        bl = true;
                    } else {
                        if (!bl2) {
                            bl2 = true;
                            n = 0;
                            stringBuilder.append(" WHERE (");
                        } else if (n == 1) {
                            stringBuilder.append(" OR (");
                            n = 0;
                        } else {
                            object.append(" AND ");
                        }
                        Object object3 = yP_ComplexGabarit.getObjectAt(n5);
                        if (object3 == null) {
                            object.append("( 1 = 0)");
                        } else {
                            object2 = this.sqlValue(object3);
                            object.append('(');
                            if (oPERATOR == YP_ComplexGabarit.OPERATOR.CONTAIN) {
                                if (object3 instanceof Bitmap) {
                                    object.append('[');
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" & ");
                                    object.append((String)object2);
                                    object.append(" = ");
                                    object.append((String)object2);
                                    object.append(' ');
                                } else if (object3 instanceof byte[]) {
                                    object.append('[');
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" like '%");
                                    object.append(((String)object2).substring(1, ((String)object2).length() - 1));
                                    object.append("%' ");
                                } else if (object3 instanceof Integer) {
                                    object.append('[');
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" like '%");
                                    object.append((String)object2);
                                    object.append("%' ");
                                } else if (object3 instanceof Long) {
                                    object.append('[');
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" like '%");
                                    object.append((String)object2);
                                    object.append("%' ");
                                } else {
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "sqlGetWhereForTwo() unknown type for operator contain");
                                    }
                                    object.append('[');
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" like '%");
                                    if (((String)object2).startsWith("'")) {
                                        object.append(((String)object2).substring(1, ((String)object2).length() - 1));
                                    } else {
                                        object.append((String)object2);
                                    }
                                    object.append("%' ");
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING) {
                                int n6;
                                if (((String)object2).startsWith("'")) {
                                    boolean bl5 = true;
                                    n6 = ((String)object2).length() - 1;
                                    while (n6 > 0) {
                                        if (bl5) {
                                            bl5 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append('[');
                                        object.append(string42);
                                        object.append(']');
                                        object.append(" = '");
                                        object.append(((String)object2).substring(1, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                } else {
                                    boolean bl6 = true;
                                    n6 = ((String)object2).length();
                                    while (n6 >= 0) {
                                        if (bl6) {
                                            bl6 = false;
                                        } else {
                                            object.append(" OR ");
                                        }
                                        object.append('[');
                                        object.append(string42);
                                        object.append(']');
                                        object.append(" = '");
                                        object.append(((String)object2).substring(0, n6));
                                        object.append("' ");
                                        --n6;
                                    }
                                }
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.START_WITH) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" like ");
                                object.append(((String)object2).substring(0, ((String)object2).length() - 1));
                                object.append("%' ");
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" > ");
                                object.append((String)object2);
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" < ");
                                object.append((String)object2);
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.EQUAL) {
                                boolean bl7 = false;
                                if (((String)object2).length() == 2 && ((String)object2).contentEquals("''")) {
                                    bl7 = true;
                                    object.append('(');
                                }
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" = ");
                                object.append((String)object2);
                                if (bl7) {
                                    object.append(" OR [");
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" IS NULL)");
                                }
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE) {
                                object.append("UPPER(");
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(") = UPPER(");
                                object.append((String)object2);
                                object.append(") ");
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" IN (");
                                object.append((String)object2);
                                object.append(") ");
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LIKE) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" LIKE ");
                                object.append((String)object2);
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                                boolean bl8 = false;
                                if (((String)object2).length() == 2 && ((String)object2).contentEquals("''")) {
                                    bl8 = true;
                                    object.append('(');
                                }
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" <> ");
                                object.append((String)object2);
                                if (bl8) {
                                    object.append(" AND [");
                                    object.append(string42);
                                    object.append(']');
                                    object.append(" IS NOT NULL)");
                                }
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" >= ");
                                object.append((String)object2);
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                                object.append('[');
                                object.append(string42);
                                object.append(']');
                                object.append(" <= ");
                                object.append((String)object2);
                                object.append(' ');
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP) {
                                String string5 = String.valueOf('[') + string42 + ']' + " = " + (String)object2 + ' ';
                                object.append(string5);
                                if (arrayList == null) {
                                    arrayList = new ArrayList<String>();
                                }
                                arrayList.add(string5);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP) {
                                String string6 = String.valueOf('[') + string42 + ']' + " <> " + (String)object2 + ' ';
                                object.append(string6);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string6);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP) {
                                String string7 = String.valueOf('[') + string42 + ']' + " < " + (String)object2 + ' ';
                                object.append(string7);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string7);
                            } else if (oPERATOR == YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP) {
                                String string8 = String.valueOf('[') + string42 + ']' + " IN( " + (String)object2 + ")";
                                object.append(string8);
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(string8);
                            } else {
                                this.logger(2, "sqlGetWhereForTwo() unknown operator");
                            }
                            object.append(')');
                        }
                    }
                    ++n5;
                }
                String string9 = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction, yP_ComplexGabarit);
                if (string9 != null && !string9.isEmpty()) {
                    if (!bl2) {
                        bl2 = true;
                        n = 0;
                        stringBuilder.append(" WHERE (");
                    } else if (n == 1) {
                        stringBuilder.append(" OR (");
                        n = 0;
                    } else {
                        object.append(" AND ");
                    }
                    object.append(string9);
                }
                if (n2 == 0 && n3 == 0) {
                    if (bl3) {
                        this.logger(2, "sqlGetWhereForTwo() group operator is for aggregated columns (MIN, MAX)");
                        return null;
                    }
                    if (object.length() > 0) {
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else if (bl3) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(" AS ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getTableName());
                    stringBuilder.append(" INNER JOIN (SELECT ");
                    for (String string42 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append('[');
                        stringBuilder.append(string42);
                        stringBuilder.append(']');
                        stringBuilder.append(" AS [");
                        stringBuilder.append(string42);
                        stringBuilder.append("TMP]");
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append('[');
                    stringBuilder.append(string3);
                    stringBuilder.append(']');
                    stringBuilder.append(") AS [");
                    stringBuilder.append(string3);
                    stringBuilder.append("TMP]");
                    stringBuilder.append(" FROM ( SELECT ");
                    for (String string42 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append('[');
                        stringBuilder.append(string42);
                        stringBuilder.append(']');
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append('[');
                    stringBuilder.append(string3);
                    stringBuilder.append(']');
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            string42 = object.toString();
                            for (String string10 : arrayList) {
                                string42 = string42.replace(string10, " 1=1 ");
                            }
                            stringBuilder.append(string42);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    boolean bl9 = true;
                    for (String string11 : yP_ComplexGabarit.groupFieldNameList) {
                        if (bl9) {
                            bl9 = false;
                        } else {
                            stringBuilder.append(", ");
                        }
                        stringBuilder.append('[');
                        stringBuilder.append(string11);
                        stringBuilder.append(']');
                        stringBuilder.append(" ");
                    }
                    stringBuilder.append(" UNION SELECT");
                    for (String string12 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append('[');
                        stringBuilder.append(string12);
                        stringBuilder.append(']');
                        stringBuilder.append(", ");
                    }
                    if (n3 != 0) {
                        stringBuilder.append("MIN(");
                    } else {
                        stringBuilder.append("MAX(");
                    }
                    stringBuilder.append('[');
                    stringBuilder.append(string3);
                    stringBuilder.append(']');
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(string);
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            void var18_37;
                            String string13 = object.toString();
                            for (String string14 : arrayList) {
                                String string15 = var18_37.replace(string14, " 1=1 ");
                            }
                            stringBuilder.append((String)var18_37);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(" GROUP BY ");
                    bl9 = true;
                    for (String string16 : yP_ComplexGabarit.groupFieldNameList) {
                        if (bl9) {
                            bl9 = false;
                        } else {
                            stringBuilder.append(", ");
                        }
                        stringBuilder.append('[');
                        stringBuilder.append(string16);
                        stringBuilder.append(']');
                    }
                    stringBuilder.append(") tmp");
                    stringBuilder.append(" GROUP BY ");
                    bl9 = true;
                    for (String string17 : yP_ComplexGabarit.groupFieldNameList) {
                        if (bl9) {
                            bl9 = false;
                        } else {
                            stringBuilder.append(", ");
                        }
                        stringBuilder.append('[');
                        stringBuilder.append(string17);
                        stringBuilder.append(']');
                    }
                    stringBuilder.append(") tmp");
                    stringBuilder.append(" ON ");
                    for (String string18 : yP_ComplexGabarit.groupFieldNameList) {
                        stringBuilder.append('[');
                        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getTableName());
                        stringBuilder.append(FIELD_MID);
                        stringBuilder.append(string18);
                        stringBuilder.append("] = tmp.");
                        stringBuilder.append(string18);
                        stringBuilder.append("TMP");
                        stringBuilder.append(" AND ");
                    }
                    stringBuilder.append('[');
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getTableName());
                    stringBuilder.append(FIELD_MID);
                    stringBuilder.append(string3);
                    stringBuilder.append("] = tmp.");
                    stringBuilder.append(string3);
                    stringBuilder.append("TMP");
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(')');
                    }
                } else {
                    if (object.length() == 0) {
                        if (!bl2) {
                            bl2 = true;
                            stringBuilder.append(" WHERE (");
                        } else {
                            stringBuilder.append(" OR (");
                        }
                    }
                    stringBuilder.append(string3);
                    if (n3 != 0) {
                        stringBuilder.append(" = ( SELECT MIN(");
                        stringBuilder.append(string3);
                        stringBuilder.append(")  AS ");
                        stringBuilder.append(string3);
                        stringBuilder.append(" FROM (SELECT MIN(");
                    } else {
                        stringBuilder.append(" = ( SELECT MAX(");
                        stringBuilder.append(string3);
                        stringBuilder.append(")  AS ");
                        stringBuilder.append(string3);
                        stringBuilder.append(" FROM (SELECT MAX(");
                    }
                    stringBuilder.append(string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            string42 = object.toString();
                            for (String string19 : arrayList) {
                                string42 = string42.replace(string19, " 1=1 ");
                            }
                            stringBuilder.append(string42);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    if (n3 != 0) {
                        stringBuilder.append(" UNION SELECT MIN(");
                    } else {
                        stringBuilder.append(" UNION SELECT MAX(");
                    }
                    stringBuilder.append(string3);
                    stringBuilder.append(") AS ");
                    stringBuilder.append(string3);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(string);
                    if (object.length() > 0) {
                        stringBuilder.append(" WHERE (");
                        if (arrayList != null) {
                            string42 = object.toString();
                            for (String string20 : arrayList) {
                                string42 = string42.replace(string20, " 1=1 ");
                            }
                            stringBuilder.append(string42);
                        } else {
                            stringBuilder.append((CharSequence)object);
                        }
                        stringBuilder.append(')');
                    }
                    stringBuilder.append(") tmp");
                    stringBuilder.append(')');
                    stringBuilder.append(')');
                    if (object.length() > 0) {
                        stringBuilder.append(" AND (");
                        stringBuilder.append((CharSequence)object);
                        stringBuilder.append(") ");
                    }
                }
                ++n4;
            }
            if (bl) {
                YP_ComplexGabarit[] yP_ComplexGabaritArray2 = yP_ComplexGabaritArray;
                n2 = yP_ComplexGabaritArray.length;
                n3 = 0;
                while (n3 < n2) {
                    YP_ComplexGabarit yP_ComplexGabarit = yP_ComplexGabaritArray2[n3];
                    if (yP_ComplexGabarit.isOrdered) {
                        stringBuilder.append(" ORDER  BY ");
                        boolean bl10 = true;
                        n = 0;
                        while (n < yP_ComplexGabarit.size()) {
                            object = yP_ComplexGabarit.getOperatorAt(n);
                            if (object == YP_ComplexGabarit.OPERATOR.ORDER_ASC) {
                                if (bl10) {
                                    bl10 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append('[');
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(']');
                                stringBuilder.append(" ASC ");
                            } else if (object == YP_ComplexGabarit.OPERATOR.ORDER_DESC) {
                                if (bl10) {
                                    bl10 = false;
                                } else {
                                    stringBuilder.append(',');
                                }
                                stringBuilder.append('[');
                                stringBuilder.append(yP_ComplexGabarit.getFieldNameAt(n));
                                stringBuilder.append(']');
                                stringBuilder.append(" DESC ");
                            }
                            ++n;
                        }
                        break;
                    }
                    ++n3;
                }
            }
            return stringBuilder.toString();
        }
        catch (Exception exception) {
            this.logger(1, "sqlGetWhereForTwo()  " + exception);
            return null;
        }
    }

    /*
     * Unable to fully structure code
     */
    private String sqlGetSet(YP_TCD_DesignAccesObject var1_1, String var2_2, YP_Row var3_3) {
        var4_4 = var1_1.getFieldList();
        var5_5 = new StringBuilder();
        var6_6 = true;
        var7_7 = 0;
        while (var7_7 < var4_4.length) {
            block13: {
                try {
                    block19: {
                        block18: {
                            block17: {
                                block16: {
                                    block15: {
                                        block14: {
                                            var8_8 = var3_3.getFieldValue(var4_4[var7_7]);
                                            if (var8_8 == null) break block13;
                                            if (!(var8_8 instanceof Integer)) break block14;
                                            if ((Integer)var8_8 == 0) break block13;
                                            if ((Integer)var8_8 == -2147483647) {
                                                var8_8 = 0;
                                            }
                                            ** GOTO lbl-1000
                                        }
                                        if (!(var8_8 instanceof Long)) break block15;
                                        if ((Long)var8_8 == 0L) break block13;
                                        if ((Long)var8_8 == -9223372036854775807L) {
                                            var8_8 = 0;
                                        }
                                        ** GOTO lbl-1000
                                    }
                                    if (!(var8_8 instanceof byte[])) break block16;
                                    if (((byte[])var8_8).length == 0 || ((byte[])var8_8)[0] == 0) {
                                        break block13;
                                    }
                                    ** GOTO lbl-1000
                                }
                                if (!(var8_8 instanceof Timestamp)) break block17;
                                if (((Timestamp)var8_8).getTime() == 0L) {
                                    break block13;
                                }
                                ** GOTO lbl-1000
                            }
                            if (!(var8_8 instanceof Date)) break block18;
                            if (((Date)var8_8).getTime() == 0L) {
                                break block13;
                            }
                            ** GOTO lbl-1000
                        }
                        if (!(var8_8 instanceof Float)) break block19;
                        if (((Float)var8_8).floatValue() == 0.0f) {
                            break block13;
                        }
                        ** GOTO lbl-1000
                    }
                    if (!(var8_8 instanceof Boolean) && !(var8_8 instanceof Enum)) {
                        this.logger(2, "sqlGetSet() unknown type");
                    } else lbl-1000:
                    // 7 sources

                    {
                        if (var6_6) {
                            var6_6 = false;
                        } else {
                            var5_5.append(" , ");
                        }
                        var5_5.append(" [");
                        var5_5.append(var4_4[var7_7].getName());
                        var5_5.append("] = ");
                        this.appendSQLValue(var5_5, var8_8);
                    }
                }
                catch (Exception v0) {}
            }
            ++var7_7;
        }
        return var5_5.toString();
    }

    @Override
    public List<YP_Row> sqlSelectSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block14: {
            int n3;
            block13: {
                try {
                    if (UtilsYP.getInstanceRole() == 2) break block13;
                    this.logger(2, "sqlSelectSuchAsForSlave() only for slave...");
                    return null;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "sqlSelectSuchAsForSlave() " + exception);
                    }
                    return null;
                }
            }
            stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
            stringBuilder.append(" WITH (NOLOCK) ");
            String string = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName(), yP_ComplexGabaritArray);
            if (string == null) {
                this.logger(3, "sqlSelectSuchAsForSlave() condition empty:  ");
                string = "";
            }
            if ((n3 = string.indexOf(" ORDER  BY ")) >= 0) {
                stringBuilder.append(string.substring(0, n3));
            } else {
                stringBuilder.append(string);
            }
            stringBuilder.append(" UNION ALL SELECT ");
            this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
            stringBuilder.append(" WITH (NOLOCK) ");
            stringBuilder.append(string);
            if (n2 > 0) {
                if (stringBuilder.indexOf(" ORDER  BY ") == -1) {
                    stringBuilder.append(" ORDER  BY ");
                    stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName());
                }
                stringBuilder.append(" OFFSET ");
                stringBuilder.append(n);
                stringBuilder.append(" ROWS ");
                stringBuilder.append(" FETCH NEXT ");
                stringBuilder.append(n2);
                stringBuilder.append(" ROWS ONLY ");
                break block14;
            }
            if (n <= 0) break block14;
            this.logger(2, "sqlSelectSuchAsForSlave() It's not possible to set an offset but not a maxResult");
            return null;
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, stringBuilder.toString());
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSuchAsForSlave() start");
        }
        List<YP_Row> list = yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSuchAsForSlave() end");
        }
        return list;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<YP_Row> sqlSelectSuchAsForTransaction(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            int n3;
            StringBuilder stringBuilder = new StringBuilder();
            if (n2 > 0 && n == 0) {
                stringBuilder.append("SELECT TOP (");
                stringBuilder.append(n2);
                stringBuilder.append(") myTableIndex, ");
                this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
                stringBuilder.append(" FROM\r\n");
                stringBuilder.append("(\r\n");
                stringBuilder.append("\t SELECT myTableIndex, ");
                this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
                stringBuilder.append(" FROM\r\n");
                stringBuilder.append("\t(\r\n");
                stringBuilder.append("\t\tSELECT TOP (");
                stringBuilder.append(n2);
                stringBuilder.append(") 1 AS myTableIndex, ");
            } else {
                stringBuilder.append("SELECT 1 AS myTableIndex, ");
            }
            this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
            stringBuilder.append(" WITH (NOLOCK) ");
            String string = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject.getFullTableName(), yP_ComplexGabaritArray);
            if (string == null) {
                this.logger(3, "sqlSelectSuchAsForTransaction() condition empty:  ");
                string = "";
            }
            if ((n3 = string.indexOf(" ORDER  BY ")) >= 0) {
                stringBuilder.append(string.substring(0, n3));
            } else {
                stringBuilder.append(string);
            }
            if (n2 > 0 && n == 0) {
                if (n3 == -1) {
                    this.logger(2, "sqlSelectSuchAsForTransaction() order is manadtory when a plage is specified");
                    return null;
                }
                stringBuilder.append(string.substring(n3));
                stringBuilder.append("\t) tmp\r\n");
            }
            stringBuilder.append(" UNION ALL ");
            if (n2 > 0 && n == 0) {
                stringBuilder.append("\t SELECT myTableIndex, ");
                this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
                stringBuilder.append(" FROM\r\n");
                stringBuilder.append("\t(\r\n");
                stringBuilder.append("\t\tSELECT TOP (");
                stringBuilder.append(n2);
                stringBuilder.append(") 2 AS myTableIndex, ");
            } else {
                stringBuilder.append("SELECT 2 AS myTableIndex, ");
            }
            this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
            stringBuilder.append(" FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(" WITH (NOLOCK) ");
            stringBuilder.append(string);
            if (n2 > 0 && n == 0 && n3 != -1) {
                stringBuilder.append("\t) tmp\r\n");
                stringBuilder.append(") tmp\r\n");
                stringBuilder.append(string.substring(n3));
            } else if (n2 > 0) {
                stringBuilder.append(" OFFSET ");
                stringBuilder.append(n);
                stringBuilder.append(" ROWS ");
                stringBuilder.append(" FETCH NEXT ");
                stringBuilder.append(n2);
                stringBuilder.append(" ROWS ONLY ");
            } else if (n > 0) {
                this.logger(2, "sqlSelectSuchAsForTransaction() It's not possible to set an offset but not a maxResult");
                return null;
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, stringBuilder.toString());
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectSuchAsForTransaction() start");
            }
            List<YP_Row> list = yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealSelectForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject, stringBuilder.toString());
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectSuchAsForTransaction() end");
            }
            return list;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "sqlSelectSuchAsForTransaction() " + exception);
            }
            return null;
        }
    }

    @Override
    public List<YP_Row> sqlSelectSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        Object object;
        if (UtilsYP.getInstanceRole() == 2 && yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction) {
            return this.sqlSelectSuchAsForSlave((YP_TCD_DAO_SQL_Transaction)yP_TCD_DesignAccesObject, n, n2, yP_ComplexGabaritArray);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
        stringBuilder.append(" WITH (NOLOCK) ");
        ArrayList<YP_PreparedValue> arrayList = new ArrayList<YP_PreparedValue>();
        String string = !this.preparedStatementDeactivated ? this.sqlGetPreparedWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), arrayList, yP_ComplexGabaritArray) : this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
        if (string == null) {
            this.logger(3, "sqlSelectSuchAs() condition empty:  ");
            string = "";
        }
        stringBuilder.append(string);
        if (n2 > 0) {
            if (stringBuilder.indexOf(" ORDER  BY ") == -1) {
                stringBuilder.append(" ORDER  BY ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
            }
            stringBuilder.append(" OFFSET ");
            stringBuilder.append(n);
            stringBuilder.append(" ROWS ");
            stringBuilder.append(" FETCH NEXT ");
            stringBuilder.append(n2);
            stringBuilder.append(" ROWS ONLY ");
        } else if (n > 0) {
            this.logger(2, "sqlSelectSuchAs() It's not possible to set an offset but not a maxResult");
            return null;
        }
        String string2 = stringBuilder.toString();
        if (this.getLogLevel() >= 5) {
            if (arrayList.isEmpty()) {
                this.logger(5, "sqlSelectSuchAs() " + string2);
            } else {
                object = stringBuilder.toString();
                for (YP_PreparedValue yP_PreparedValue : arrayList) {
                    try {
                        object = ((String)object).replaceFirst("\\?", this.sqlValue(yP_PreparedValue.value).replace("$", "\\$"));
                    }
                    catch (Exception exception) {
                        this.logger(2, "sqlSelectSuchAs() " + stringBuilder.toString());
                        this.logger(2, "sqlSelectSuchAs() " + (String)object);
                        this.logger(2, "sqlSelectSuchAs() " + this.sqlValue(yP_PreparedValue.value));
                    }
                }
                this.logger(5, "sqlSelectSuchAs() " + (String)object);
            }
        }
        try {
            object = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, arrayList, string2);
            return object;
        }
        catch (Exception exception) {
            this.logger(3, "sqlSelectSuchAs() No result from database " + exception);
            return null;
        }
    }

    @Override
    public int sqlSelectCount(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            if (string != null) {
                stringBuilder.append("SELECT COUNT(");
                stringBuilder.append(string);
                stringBuilder.append(") AS count FROM ");
            } else {
                stringBuilder.append("SELECT COUNT(*) AS count FROM ");
            }
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            String string2 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
            if (string2 != null && !string2.isEmpty()) {
                stringBuilder.append(" WHERE");
                stringBuilder.append(string2);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectCount() : " + stringBuilder.toString());
            }
            return (int)yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectCount() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int sqlSelectCountSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        block11: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block11;
                this.logger(2, "sqlSelectCountSuchAsForSlave() only for slave...");
                return -1;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "sqlSelectCountSuchAsForSlave() " + exception);
                }
                return -1;
            }
        }
        String string = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName(), yP_ComplexGabaritArray);
        if (string == null) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "sqlSelectCountSuchAsForSlave() condition empty:  ");
            }
            string = "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        String string2 = yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName();
        if (string2 != null) {
            stringBuilder.append("SELECT COALESCE((SELECT COUNT(");
            stringBuilder.append(string2);
            stringBuilder.append(") FROM ");
        } else {
            stringBuilder.append("SELECT COALESCE((SELECT COUNT(*) FROM ");
        }
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string);
        if (string2 != null) {
            stringBuilder.append("),0) + COALESCE((SELECT COUNT(");
            stringBuilder.append(string2);
            stringBuilder.append(") FROM ");
        } else {
            stringBuilder.append("),0) + COALESCE((SELECT COUNT(*) FROM ");
        }
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string);
        stringBuilder.append("),0) AS count");
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectCountSuchAsForSlave() : " + stringBuilder.toString());
        }
        return (int)yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCountQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public int sqlSelectCountSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
            if (string != null) {
                stringBuilder.append("SELECT COUNT(");
                stringBuilder.append(string);
                stringBuilder.append(") AS count FROM ");
            } else {
                stringBuilder.append("SELECT COUNT(*) AS count FROM ");
            }
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(' ');
            String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string2 != null && string2.length() > 0) {
                stringBuilder.append(string2);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectCountSuchAs() : " + stringBuilder.toString());
            }
            return (int)yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectCountSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public YP_Row sqlSelectOne(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, int n) {
        List<YP_Row> list;
        block7: {
            block6: {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT ");
                    this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    String string = this.getContractKeyClause(yP_TCD_DesignAccesObject);
                    if (string != null && !string.isEmpty()) {
                        stringBuilder.append(" WHERE");
                        stringBuilder.append(string);
                    }
                    stringBuilder.append(" ORDER BY ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
                    stringBuilder.append(" OFFSET ");
                    stringBuilder.append(n);
                    stringBuilder.append(" ROWS FETCH NEXT 1 ROWS ONLY ");
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, stringBuilder.toString());
                    }
                    if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null) break block6;
                    this.logger(2, "sqlSelectOne() empty response");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "sqlSelectOne() ...:" + exception);
                    return null;
                }
            }
            if (!list.isEmpty()) break block7;
            this.logger(3, "sqlSelectOne() no row at index:" + n);
            return null;
        }
        return list.get(0);
    }

    @Override
    public YP_Row sqlSelectRowForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, long l) {
        List<YP_Row> list;
        block10: {
            block9: {
                block8: {
                    try {
                        if (UtilsYP.getInstanceRole() == 2) break block8;
                        this.logger(2, "sqlSelectRowForSlave() only for slave...");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "sqlSelectRowForSlave() ...:" + exception);
                        return null;
                    }
                }
                String string = yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT ");
                this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
                stringBuilder.append(" WHERE ");
                stringBuilder.append(string);
                stringBuilder.append('=');
                stringBuilder.append(l);
                String string2 = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction);
                if (string2 != null && !string2.isEmpty()) {
                    stringBuilder.append(" AND");
                    stringBuilder.append(string2);
                }
                stringBuilder.append(" UNION SELECT ");
                this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
                stringBuilder.append(" WHERE ");
                stringBuilder.append(string);
                stringBuilder.append('=');
                stringBuilder.append(l);
                if (string2 != null && !string2.isEmpty()) {
                    stringBuilder.append(" AND");
                    stringBuilder.append(string2);
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, stringBuilder.toString());
                }
                if ((list = yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block9;
                this.logger(2, "sqlSelectRowForSlave() empty response");
                return null;
            }
            if (!list.isEmpty()) break block10;
            this.logger(3, "sqlSelectRowForSlave() no row with pk:" + l);
            return null;
        }
        return list.get(0);
    }

    @Override
    public YP_Row sqlSelectRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, long l) {
        List<YP_Row> list;
        block9: {
            block8: {
                block7: {
                    try {
                        String string = yP_TCD_DesignAccesObject.getPrimaryKeyName();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT ");
                        this.appendColumnList(yP_TCD_DesignAccesObject, stringBuilder);
                        stringBuilder.append(" FROM ");
                        stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                        stringBuilder.append(" WHERE ");
                        stringBuilder.append(string);
                        stringBuilder.append('=');
                        stringBuilder.append(l);
                        String string2 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
                        if (string2 != null && !string2.isEmpty()) {
                            stringBuilder.append(" AND");
                            stringBuilder.append(string2);
                        }
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, stringBuilder.toString());
                        }
                        if ((list = yP_TCD_DesignAccesObject.getDataBaseConnector().dealSelect(yP_TCD_DesignAccesObject, stringBuilder.toString())) != null) break block7;
                        this.logger(2, "sqlSelectRow() empty response");
                        return null;
                    }
                    catch (Exception exception) {
                        this.logger(2, "sqlSelectRow() ... :" + exception);
                        return null;
                    }
                }
                if (!list.isEmpty()) break block8;
                this.logger(3, "sqlSelectRow() empty response");
                return null;
            }
            if (list.size() <= 1) break block9;
            this.logger(2, "sqlSelectRow() too many responses...");
            return null;
        }
        return list.get(0);
    }

    @Override
    public long sqlSelectSumSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        block6: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block6;
                this.logger(2, "sqlSelectSumSuchAsForSlave() only for slave...");
                return -1L;
            }
            catch (Exception exception) {
                this.logger(2, "sqlSelectSumSuchAsForSlave() ...:" + exception);
                return -1L;
            }
        }
        String string2 = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName(), yP_ComplexGabaritArray);
        if (string2 == null) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "sqlSelectSumSuchAsForSlave() condition empty:  ");
            }
            string2 = "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT COALESCE((SELECT SUM( ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append('.');
        stringBuilder.append(string);
        stringBuilder.append(") FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(string2);
        stringBuilder.append("),0) + COALESCE((SELECT SUM( ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append('.');
        stringBuilder.append(string);
        stringBuilder.append(") FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(string2);
        stringBuilder.append("),0) AS count");
        if (this.getLogLevel() >= 5) {
            this.logger(5, "sqlSelectSumSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCountQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public long sqlSelectSumSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT SUM(");
            stringBuilder.append(string);
            stringBuilder.append(") AS count FROM ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(' ');
            String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
            if (string2 != null && string2.length() > 0) {
                stringBuilder.append(string2);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "sqlSelectSumSuchAs() : " + stringBuilder.toString());
            }
            return yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "sqlSelectSumSuchAs() ...:" + exception);
            return -1L;
        }
    }

    @Override
    public List<String> getDistinctStringValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        int n3;
        block7: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block7;
                this.logger(2, "getDistinctStringValueListSuchAsForSlave() only for slave...");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctStringValueListSuchAsForSlave() ...:" + exception);
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        String string2 = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName(), yP_ComplexGabaritArray);
        if (string2 == null) {
            this.logger(3, "getDistinctStringValueListSuchAsForSlave() condition empty:  ");
            string2 = "";
        }
        if ((n3 = string2.indexOf(" ORDER  BY ")) >= 0) {
            stringBuilder.append(string2.substring(0, n3));
        } else {
            stringBuilder.append(string2);
        }
        stringBuilder.append(string2);
        stringBuilder.append(" UNION SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctStringValueListSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealStringListQuery(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString());
    }

    @Override
    public String getDistinctValueListSuchAsRequestSQL(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block6: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT DISTINCT ");
                stringBuilder.append(string);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
                if (string2 != null && string2.length() > 0) {
                    stringBuilder.append(string2);
                }
                if (n2 > 0) {
                    stringBuilder.append(" OFFSET ");
                    stringBuilder.append(n);
                    stringBuilder.append(" ROWS ");
                    stringBuilder.append(" FETCH NEXT ");
                    stringBuilder.append(n2);
                    stringBuilder.append(" ROWS ONLY ");
                    break block6;
                }
                if (n <= 0) break block6;
                this.logger(2, "getDistinctValueListSuchAsRequestSQL() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAsRequestSQL() ...:" + exception);
                return null;
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAsRequestSQL() : " + stringBuilder.toString());
        }
        return stringBuilder.toString();
    }

    @Override
    public List<String> getDistinctStringValueListSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        String string2;
        block3: {
            try {
                string2 = this.getDistinctValueListSuchAsRequestSQL(yP_TCD_DesignAccesObject, string, n, n2, yP_ComplexGabaritArray);
                if (string2 != null && !string2.isEmpty()) break block3;
                this.logger(2, "getDistinctStringValueListSuchAs() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctStringValueListSuchAs() ...:" + exception);
                return null;
            }
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealStringListQuery(yP_TCD_DesignAccesObject, string2);
    }

    @Override
    public List<Object> getDistinctValueListSuchAsForSlave(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        int n3;
        block7: {
            try {
                if (UtilsYP.getInstanceRole() == 2) break block7;
                this.logger(2, "getDistinctValueListSuchAsForSlave() only for slave...");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAsForSlave() ...:" + exception);
                return null;
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullMasterTableName());
        stringBuilder.append(' ');
        String string2 = this.sqlGetWhereForTwo(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName(), yP_ComplexGabaritArray);
        if (string2 == null) {
            this.logger(3, "getDistinctValueListSuchAsForSlave() condition empty:  ");
            string2 = "";
        }
        if ((n3 = string2.indexOf(" ORDER  BY ")) >= 0) {
            stringBuilder.append(string2.substring(0, n3));
        } else {
            stringBuilder.append(string2);
        }
        stringBuilder.append(string2);
        stringBuilder.append(" UNION SELECT DISTINCT ");
        stringBuilder.append(string);
        stringBuilder.append(" FROM ");
        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullSlaveTableName());
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAsForSlave() : " + stringBuilder.toString());
        }
        return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealListQuery(yP_TCD_DAO_SQL_Transaction, string, stringBuilder.toString());
    }

    @Override
    public List<Object> getDistinctValueListSuchAs(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, int n, int n2, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        StringBuilder stringBuilder;
        block6: {
            try {
                stringBuilder = new StringBuilder();
                stringBuilder.append("SELECT DISTINCT ");
                stringBuilder.append(string);
                stringBuilder.append(" FROM ");
                stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                String string2 = this.sqlGetWhere(yP_TCD_DesignAccesObject, yP_TCD_DesignAccesObject.getTableName(), yP_ComplexGabaritArray);
                if (string2 != null && string2.length() > 0) {
                    stringBuilder.append(string2);
                }
                if (n2 > 0) {
                    stringBuilder.append(" OFFSET ");
                    stringBuilder.append(n);
                    stringBuilder.append(" ROWS ");
                    stringBuilder.append(" FETCH NEXT ");
                    stringBuilder.append(n2);
                    stringBuilder.append(" ROWS ONLY ");
                    break block6;
                }
                if (n <= 0) break block6;
                this.logger(2, "getDistinctValueListSuchAs() It's not possible to set an offset but not a maxResult");
                return null;
            }
            catch (Exception exception) {
                this.logger(2, "getDistinctValueListSuchAs() ...:" + exception);
                return null;
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getDistinctValueListSuchAs() : " + stringBuilder.toString());
        }
        return yP_TCD_DesignAccesObject.getDataBaseConnector().dealListQuery(yP_TCD_DesignAccesObject, string, stringBuilder.toString());
    }

    @Override
    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        Field[] fieldArray;
        StringBuilder stringBuilder;
        block12: {
            block11: {
                if (UtilsYP.getInstanceRole() == 1) break block11;
                this.logger(2, "archiveRowsSuchAs() only for master...");
                return -1;
            }
            stringBuilder = new StringBuilder();
            fieldArray = yP_TCD_DAO_SQL_Transaction.getFieldList();
            if (fieldArray.length != 0) break block12;
            return -1;
        }
        try {
            Object object;
            boolean bl = true;
            StringBuilder stringBuilder2 = new StringBuilder();
            Field[] fieldArray2 = fieldArray;
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                object = fieldArray2[n2];
                if (!bl) {
                    stringBuilder2.append(',');
                } else {
                    bl = false;
                }
                stringBuilder2.append('[');
                stringBuilder2.append(((Field)object).getName());
                stringBuilder2.append(']');
                ++n2;
            }
            stringBuilder.append("MERGE INTO ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append("\r\n");
            stringBuilder.append("USING\r\n");
            stringBuilder.append("(\r\n");
            stringBuilder.append("\tSELECT ");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append("\r\n");
            stringBuilder.append("\tFROM ");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getFullTableName());
            stringBuilder.append("\r\n");
            if (string != null && string.length() > 0) {
                stringBuilder.append(string);
            }
            if ((object = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction)) != null && !((String)object).isEmpty()) {
                if (string != null && string.length() > 0) {
                    stringBuilder.append(" AND");
                }
                stringBuilder.append((String)object);
            }
            stringBuilder.append("\r\n) tmp\r\n");
            stringBuilder.append("ON ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
            stringBuilder.append(".");
            stringBuilder.append(yP_TCD_DesignAccesObject.getPrimaryKeyName());
            stringBuilder.append(" = tmp.");
            stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName());
            stringBuilder.append("\r\nWHEN NOT MATCHED\r\nTHEN INSERT(");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(")\r\nVALUES (");
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append(");");
            if (yP_TCD_DAO_SQL_Transaction.getLogLevel() >= 5) {
                this.logger(5, "archiveRowsSuchAs() : " + stringBuilder.toString());
            }
            return yP_TCD_DAO_SQL_Transaction.getDataBaseConnector().dealCreate(stringBuilder.toString(), yP_TCD_DesignAccesObject, yP_TCD_DAO_SQL_Transaction);
        }
        catch (Exception exception) {
            this.logger(2, "archiveRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public int archiveRowsSuchAs(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit ... yP_ComplexGabaritArray) {
        try {
            return this.archiveRowsSuchAs(yP_TCD_DAO_SQL_Transaction, yP_TCD_DesignAccesObject, this.sqlGetWhere(yP_TCD_DAO_SQL_Transaction, yP_TCD_DAO_SQL_Transaction.getTableName(), yP_ComplexGabaritArray));
        }
        catch (Exception exception) {
            this.logger(2, "archiveRowsSuchAs() ...:" + exception);
            return -1;
        }
    }

    @Override
    public List<YP_Row> selectFrom(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction, String string, int n, int n2) {
        List<YP_Row> list;
        block9: {
            StringBuilder stringBuilder;
            block8: {
                try {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT ");
                    this.appendColumnList(yP_TCD_DAO_SQL_Transaction, stringBuilder);
                    stringBuilder.append(" FROM ");
                    stringBuilder.append(string);
                    String string2 = this.getContractKeyClause(yP_TCD_DAO_SQL_Transaction);
                    if (string2 != null && !string2.isEmpty()) {
                        stringBuilder.append(" WHERE");
                        stringBuilder.append(string2);
                    }
                    if (n2 > 0) {
                        stringBuilder.append(" ORDER BY ");
                        stringBuilder.append(yP_TCD_DAO_SQL_Transaction.getPrimaryKeyName());
                        stringBuilder.append(" OFFSET ");
                        stringBuilder.append(n);
                        stringBuilder.append(" ROWS ");
                        stringBuilder.append(" FETCH NEXT ");
                        stringBuilder.append(n2);
                        stringBuilder.append(" ROWS ONLY ");
                        break block8;
                    }
                    if (n <= 0) break block8;
                    this.logger(2, "selectFrom() It's not possible to set an offset but not a maxResult");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(3, "selectFrom() No result from database" + exception);
                    return null;
                }
            }
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "selectFrom() : " + stringBuilder.toString());
            }
            if ((list = yP_TCD_DataBaseConnector.dealSelect(yP_TCD_DAO_SQL_Transaction, stringBuilder.toString())) != null) break block9;
            this.logger(2, "selectFrom() empty response");
            return null;
        }
        if (list.isEmpty()) {
            this.logger(3, "selectFrom() empty response");
            return list;
        }
        return list;
    }

    @Override
    public int deleteFromWhere(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, String string, String string2, long[] lArray) {
        block9: {
            block8: {
                if (lArray != null) break block8;
                this.logger(3, "deleteFromWhere() list == null");
                return -1;
            }
            if (lArray.length != 0) break block9;
            this.logger(3, "deleteFromWhere() empty list");
            return -1;
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DELETE FROM ");
            stringBuilder.append(string);
            stringBuilder.append(" WHERE ");
            int n = 0;
            while (n < lArray.length) {
                if (n != 0) {
                    stringBuilder.append(" OR ");
                }
                stringBuilder.append(string2);
                stringBuilder.append('=');
                stringBuilder.append(lArray[n]);
                ++n;
            }
            String string3 = this.getContractKeyClause(yP_TCD_DesignAccesObject);
            if (string3 != null && !string3.isEmpty()) {
                stringBuilder.append(" AND");
                stringBuilder.append(string3);
            }
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "deleteFromWhere() : " + stringBuilder.toString());
            }
            return yP_TCD_DataBaseConnector.dealUpdate(yP_TCD_DesignAccesObject, stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(3, "deleteFromWhere() ...:" + exception);
            return -1;
        }
    }

    @Override
    public boolean isSlaveTransactionEmpty(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, List<YP_TCD_DAO_SQL_Transaction> list) throws Exception {
        HashSet<String> hashSet;
        boolean bl;
        block11: {
            bl = true;
            hashSet = new HashSet<String>();
            for (YP_TCD_DAO_SQL_Transaction object : list) {
                hashSet.add(object.getSlaveTableName());
            }
            if (hashSet != null && !hashSet.isEmpty()) break block11;
            return false;
        }
        try {
            int n;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT count(*) as count\r\n");
            stringBuilder.append("FROM sys.tables\r\n");
            stringBuilder.append("INNER JOIN sys.schemas\r\n");
            stringBuilder.append("ON sys.tables.schema_id = sys.schemas.schema_id\r\n");
            stringBuilder.append("INNER JOIN sys.partitions\r\n");
            stringBuilder.append("ON  sys.tables.object_id = sys.partitions.object_id\r\n");
            stringBuilder.append("WHERE sys.schemas.name='");
            stringBuilder.append(list.get(0).getSchemaName());
            stringBuilder.append("'\r\n");
            stringBuilder.append("  AND sys.partitions.rows > 0\r\n");
            boolean bl2 = true;
            for (String n2 : hashSet) {
                if (n2.startsWith("TokenTable_slave_")) continue;
                bl2 = false;
                break;
            }
            if (bl2) {
                this.logger(2, "isSlaveTransactionEmpty() need to be tested: ");
                stringBuilder.append(" AND sys.tables.name like 'TokenTable_slave_%'");
            } else {
                stringBuilder.append("  AND sys.tables.name in (");
                for (String n2 : hashSet) {
                    if (!bl) {
                        stringBuilder.append(",'");
                    } else {
                        stringBuilder.append('\'');
                    }
                    stringBuilder.append(n2);
                    stringBuilder.append('\'');
                    bl = false;
                }
                stringBuilder.append(")");
            }
            if (yP_TCD_DataBaseConnector.getLogLevel() >= 5) {
                this.logger(5, "isSlaveTransactionEmpty() : " + stringBuilder);
            }
            return (n = (int)yP_TCD_DataBaseConnector.dealCountQuery(null, stringBuilder.toString())) <= 0;
        }
        catch (Exception exception) {
            this.logger(3, "isSlaveTransactionEmpty() :" + exception);
            throw exception;
        }
    }

    private String getShowCreateTable(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        StringBuilder stringBuilder = new StringBuilder();
        String string = yP_TCD_DesignAccesObject.getDataBaseConnector().getDBC_Path();
        string = string.replace(" ", "");
        String string2 = string.substring(string.indexOf(DATABASENAME_PROPERTY) + DATABASENAME_PROPERTY.length());
        string2 = string2.substring(0, string2.indexOf(59));
        stringBuilder.append("exec showCreateTable '" + string2 + "','");
        stringBuilder.append(yP_TCD_DesignAccesObject.getSchemaName());
        stringBuilder.append("','");
        stringBuilder.append(yP_TCD_DesignAccesObject.getTableName());
        stringBuilder.append("'");
        String string3 = stringBuilder.toString();
        if (this.getLogLevel() >= 5) {
            this.logger(5, "getShowCreateTable() : " + string3);
        }
        return string3;
    }

    @Override
    public String getContractKeyClause(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject.getRowTemplate().contractKey > 0L) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(' ');
            stringBuilder.append('[');
            stringBuilder.append("contractKey");
            stringBuilder.append(']');
            stringBuilder.append(" = ");
            stringBuilder.append(yP_TCD_DesignAccesObject.getRowTemplate().contractKey);
            stringBuilder.append(' ');
            return stringBuilder.toString();
        }
        return "";
    }

    @Override
    public String getContractKeyClauseUsedForGlobalTransaction(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject.getRowTemplate().contractKey > 0L) {
            return "[contractKey] <> 0";
        }
        return "";
    }

    private String getContractKeyClause(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, YP_ComplexGabarit yP_ComplexGabarit) {
        int n = 0;
        while (n < yP_ComplexGabarit.size()) {
            YP_ComplexGabarit.OPERATOR oPERATOR;
            String string = yP_ComplexGabarit.getFieldNameAt(n);
            if (string.contentEquals("contractKey") && (oPERATOR = yP_ComplexGabarit.getOperatorAt(n)) == YP_ComplexGabarit.OPERATOR.DIFFERENT) {
                return "";
            }
            ++n;
        }
        return this.getContractKeyClause(yP_TCD_DesignAccesObject);
    }

    @Override
    public String sqlSchemaName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return String.valueOf('[') + yP_TCD_DesignAccesObject.getSchemaName() + ']';
    }

    @Override
    public String sqlFullTableName(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DesignAccesObject)) + '.' + '[' + yP_TCD_DesignAccesObject.getTableName() + ']';
    }

    @Override
    public String sqlFullSlaveTableName(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DAO_SQL_Transaction)) + '.' + '[' + yP_TCD_DAO_SQL_Transaction.getSlaveTableName() + ']';
    }

    @Override
    public String sqlFullMasterTableName(YP_TCD_DAO_SQL_Transaction yP_TCD_DAO_SQL_Transaction) {
        return String.valueOf(this.sqlSchemaName(yP_TCD_DAO_SQL_Transaction)) + '.' + '[' + yP_TCD_DAO_SQL_Transaction.getMasterTableName() + ']';
    }

    @Override
    public void appendSQLColumnName(StringBuilder stringBuilder, String string, String string2) {
        stringBuilder.append('[');
        stringBuilder.append(string);
        stringBuilder.append(FIELD_MID);
        stringBuilder.append(string2);
        stringBuilder.append(']');
    }

    @Override
    public void appendSQLColumnName(StringBuilder stringBuilder, String string) {
        stringBuilder.append('[');
        stringBuilder.append(string);
        stringBuilder.append(']');
    }
}

