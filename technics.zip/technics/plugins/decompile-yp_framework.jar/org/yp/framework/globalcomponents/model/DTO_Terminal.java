/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;
import org.yp.framework.globalcomponents.model.DTO_Attributaire;
import org.yp.framework.globalcomponents.model.DTO_Autorisations;
import org.yp.framework.globalcomponents.model.DTO_Pdvinfo;
import org.yp.framework.globalcomponents.model.DTO_TypeTerminal;

public class DTO_Terminal {
    @SerializedName(value="adresseIP")
    private String adresseIP = null;
    @SerializedName(value="attributaire")
    private DTO_Attributaire attributaire = null;
    @SerializedName(value="autorisationsDto")
    private DTO_Autorisations autorisationsDto = null;
    @SerializedName(value="idTerminal")
    private Integer idTerminal = null;
    @SerializedName(value="motDePasse")
    private String motDePasse = null;
    @SerializedName(value="pdv")
    private DTO_Pdvinfo pdv = null;
    @SerializedName(value="position")
    private String position = null;
    @SerializedName(value="prepos")
    private String prepos = null;
    @SerializedName(value="statut")
    private String statut = null;
    @SerializedName(value="typeTerminal")
    private DTO_TypeTerminal typeTerminal = null;
    @SerializedName(value="version")
    private String version = null;

    public DTO_Terminal adresseIP(String string) {
        this.adresseIP = string;
        return this;
    }

    public String getAdresseIP() {
        return this.adresseIP;
    }

    public void setAdresseIP(String string) {
        this.adresseIP = string;
    }

    public DTO_Terminal attributaire(DTO_Attributaire dTO_Attributaire) {
        this.attributaire = dTO_Attributaire;
        return this;
    }

    public DTO_Attributaire getAttributaire() {
        return this.attributaire;
    }

    public void setAttributaire(DTO_Attributaire dTO_Attributaire) {
        this.attributaire = dTO_Attributaire;
    }

    public DTO_Terminal autorisationsDto(DTO_Autorisations dTO_Autorisations) {
        this.autorisationsDto = dTO_Autorisations;
        return this;
    }

    public DTO_Autorisations getAutorisationsDto() {
        return this.autorisationsDto;
    }

    public void setAutorisationsDto(DTO_Autorisations dTO_Autorisations) {
        this.autorisationsDto = dTO_Autorisations;
    }

    public DTO_Terminal idTerminal(Integer n) {
        this.idTerminal = n;
        return this;
    }

    public Integer getIdTerminal() {
        return this.idTerminal;
    }

    public void setIdTerminal(Integer n) {
        this.idTerminal = n;
    }

    public DTO_Terminal motDePasse(String string) {
        this.motDePasse = string;
        return this;
    }

    public String getMotDePasse() {
        return this.motDePasse;
    }

    public void setMotDePasse(String string) {
        this.motDePasse = string;
    }

    public DTO_Terminal pdv(DTO_Pdvinfo dTO_Pdvinfo) {
        this.pdv = dTO_Pdvinfo;
        return this;
    }

    public DTO_Pdvinfo getPdv() {
        return this.pdv;
    }

    public void setPdv(DTO_Pdvinfo dTO_Pdvinfo) {
        this.pdv = dTO_Pdvinfo;
    }

    public DTO_Terminal position(String string) {
        this.position = string;
        return this;
    }

    public String getPosition() {
        return this.position;
    }

    public void setPosition(String string) {
        this.position = string;
    }

    public DTO_Terminal prepos(String string) {
        this.prepos = string;
        return this;
    }

    public String getPrepos() {
        return this.prepos;
    }

    public void setPrepos(String string) {
        this.prepos = string;
    }

    public DTO_Terminal statut(String string) {
        this.statut = string;
        return this;
    }

    public String getStatut() {
        return this.statut;
    }

    public void setStatut(String string) {
        this.statut = string;
    }

    public DTO_Terminal typeTerminal(DTO_TypeTerminal dTO_TypeTerminal) {
        this.typeTerminal = dTO_TypeTerminal;
        return this;
    }

    public DTO_TypeTerminal getTypeTerminal() {
        return this.typeTerminal;
    }

    public void setTypeTerminal(DTO_TypeTerminal dTO_TypeTerminal) {
        this.typeTerminal = dTO_TypeTerminal;
    }

    public DTO_Terminal version(String string) {
        this.version = string;
        return this;
    }

    public String getVersion() {
        return this.version;
    }

    public void setVersion(String string) {
        this.version = string;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Terminal dTO_Terminal = (DTO_Terminal)object;
        return Objects.equals(this.adresseIP, dTO_Terminal.adresseIP) && Objects.equals(this.attributaire, dTO_Terminal.attributaire) && Objects.equals(this.autorisationsDto, dTO_Terminal.autorisationsDto) && Objects.equals(this.idTerminal, dTO_Terminal.idTerminal) && Objects.equals(this.motDePasse, dTO_Terminal.motDePasse) && Objects.equals(this.pdv, dTO_Terminal.pdv) && Objects.equals(this.position, dTO_Terminal.position) && Objects.equals(this.prepos, dTO_Terminal.prepos) && Objects.equals(this.statut, dTO_Terminal.statut) && Objects.equals(this.typeTerminal, dTO_Terminal.typeTerminal) && Objects.equals(this.version, dTO_Terminal.version);
    }

    public int hashCode() {
        return Objects.hash(this.adresseIP, this.attributaire, this.autorisationsDto, this.idTerminal, this.motDePasse, this.pdv, this.position, this.prepos, this.statut, this.typeTerminal, this.version);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class TerminalDto {\n");
        stringBuilder.append("    adresseIP: ").append(this.toIndentedString(this.adresseIP)).append("\n");
        stringBuilder.append("    attributaire: ").append(this.toIndentedString(this.attributaire)).append("\n");
        stringBuilder.append("    autorisationsDto: ").append(this.toIndentedString(this.autorisationsDto)).append("\n");
        stringBuilder.append("    idTerminal: ").append(this.toIndentedString(this.idTerminal)).append("\n");
        stringBuilder.append("    motDePasse: ").append(this.toIndentedString(this.motDePasse)).append("\n");
        stringBuilder.append("    pdv: ").append(this.toIndentedString(this.pdv)).append("\n");
        stringBuilder.append("    position: ").append(this.toIndentedString(this.position)).append("\n");
        stringBuilder.append("    prepos: ").append(this.toIndentedString(this.prepos)).append("\n");
        stringBuilder.append("    statut: ").append(this.toIndentedString(this.statut)).append("\n");
        stringBuilder.append("    typeTerminal: ").append(this.toIndentedString(this.typeTerminal)).append("\n");
        stringBuilder.append("    version: ").append(this.toIndentedString(this.version)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

