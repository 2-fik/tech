/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.util.Hashtable;
import javax.naming.directory.InitialDirContext;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.globalcomponents.YPSocketFactory;
import org.yp.framework.globalcomponents.authentifiers.YP_Authentifiers;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ldap.YP_TCD_DCC_LDAP_Extension;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_LDAP
extends YP_GlobalComponent
implements YP_Authentifiers {
    YP_TCD_DCC_LDAP_Extension extensionLDAP;
    YPSocketFactory ypSocketFactory;

    public YP_TCG_LDAP(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        this.ypSocketFactory = new YPSocketFactory(this);
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "initialize() no DCC_Technique...");
            return -1;
        }
        this.extensionLDAP = (YP_TCD_DCC_LDAP_Extension)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtensionLDAP", new Object[0]);
        this.extensionLDAP.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "LDAP";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_Authentifiers.AuthenticationResultEnumeration authenticate(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        YP_Row yP_Row2 = this.extensionLDAP.ldap.getRowFromNaturalJoin(yP_Row);
        if (yP_Row2 == null) {
            this.logger(2, "authenticate() unable to get ldap row for:" + string);
            return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
        }
        try {
            Hashtable<String, String> hashtable = new Hashtable<String, String>();
            hashtable.put("java.naming.factory.initial", yP_Row2.getFieldStringValueByName("contextFactory"));
            hashtable.put("java.naming.provider.url", yP_Row2.getFieldStringValueByName("serverURL"));
            hashtable.put("java.naming.security.authentication", yP_Row2.getFieldStringValueByName("authenficationMode"));
            hashtable.put("java.naming.security.principal", String.format(yP_Row2.getFieldStringValueByName("userDNFormat"), string));
            hashtable.put("java.naming.security.credentials", string2);
            hashtable.put("java.naming.referral", yP_Row2.getFieldStringValueByName("referralMode"));
            hashtable.put("java.naming.ldap.factory.socket", "org.yp.framework.globalcomponents.YPSocketFactory");
            InitialDirContext initialDirContext = new InitialDirContext(hashtable);
            this.logger(4, "authenticate() OK for  :" + string);
            initialDirContext.close();
            return YP_Authentifiers.AuthenticationResultEnumeration.AUTHENTICATED;
        }
        catch (Exception exception) {
            this.logger(2, "authenticate() " + exception);
            return YP_Authentifiers.AuthenticationResultEnumeration.PROCESSING_ERROR;
        }
    }

    @Override
    public Boolean changePassword(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        this.logger(2, "changePassword() not yet done for LDAP!!!");
        return false;
    }

    @Override
    public Boolean setPassword(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2) {
        this.logger(2, "setPassword() not yet done for LDAP!!!");
        return false;
    }

    @Override
    public String createUser(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2) {
        this.logger(2, "createUSer() not yet done for LDAP!!!");
        return null;
    }

    @Override
    public String resetUser(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string) {
        this.logger(2, "resetUser() not yet done for LDAP!!!");
        return null;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        this.logger(2, "dealRequest() request unknown " + string);
        return null;
    }
}

