/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;

public class YP_TCG_View_TerminalAccess
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_TerminalAccess(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_TerminalAccess";
    }

    @Override
    public String getVersion() {
        return "V1.3.9.15";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "createEmptyView() error while retrieving WebTPE DAO");
            return null;
        }
        List<YP_TCD_DCC_Brand> list3 = yP_Transaction.getBrandList();
        if (list3 == null) {
            this.logger(2, "createEmptyView() error while retrieving brandList");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(3, "createEmptyView() no brand");
            return yP_View;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            String string3 = string.contentEquals("merchIdent") ? "merchantIdentifier" : string;
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string3);
            if (field != null) {
                yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.brand;
                    } else {
                        yP_TCD_DesignAccesObject2 = null;
                        if (string.contentEquals("brandLabel") || string.contentEquals("merchantLabel")) {
                            yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                        } else {
                            this.logger(2, "createEmptyView() unknown column:" + string);
                            continue;
                        }
                    }
                }
            }
            if (yP_TCD_DesignAccesObject2 != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        List<YP_Row> list2;
        Object exception;
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        List<YP_Gabarit> list3 = yP_PROT_IHM.getSearchGabarit();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null));
        if (list3 != null && !list3.isEmpty()) {
            for (YP_Gabarit object22 : list3) {
                try {
                    exception = object22.fieldName.contentEquals("merchIdent") ? "merchantIdentifier" : object22.fieldName;
                    if (object22.objectTosearch == null) {
                        yP_ComplexGabarit.set((String)exception, object22.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(object22);
                    if (object22.objectTosearch == null) continue;
                    yP_ComplexGabarit.set((String)exception, object22.operator, object22.objectTosearch);
                }
                catch (Exception exception2) {
                    this.logger(2, "getView() ", exception2);
                }
            }
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        List<YP_TCD_DCC_Business> list4 = yP_Transaction.getApplicationList();
        if (list4 == null) {
            this.logger(2, "getView() error while retrieving application list");
            return null;
        }
        if (list4.isEmpty()) {
            this.logger(3, "getView() no application List");
            return yP_View;
        }
        exception = new HashMap();
        Object object = list4.iterator();
        while (object.hasNext()) {
            YP_TCD_DCC_Business n3 = (YP_TCD_DCC_Business)object.next();
            arrayList.add(n3.getContractIdentifier());
            exception.put(n3.getContractIdentifier(), n3);
        }
        int n3 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
        if (n3 > 1 || !yP_Transaction.getContractIdentifier().contentEquals("KERNEL")) {
            yP_ComplexGabarit.set("yp_MerchantIdentifier", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
        }
        if ((list2 = ((YP_TCD_DesignAccesObject)(object = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null))).getRowListSuchAs(yP_ComplexGabarit)).isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n4 = 0;
        while (n4 < list2.size()) {
            Object object2;
            Cloneable cloneable;
            YP_Row yP_Row = list2.get(n4);
            yP_View.setRowID(n4, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            yP_View.setRowActionable(n4, true);
            if (list2.size() == 1 && (n3 == 1 || n3 == 2)) {
                cloneable = new ArrayList();
                object2 = new YP_TCD_DC_Context.Action();
                ((YP_TCD_DC_Context.Action)object2).applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                ((YP_TCD_DC_Context.Action)object2).formName = "TerminalAccessForm";
                ((YP_TCD_DC_Context.Action)object2).id = "MODIFY_TERMINAL_ACCESS";
                ((YP_TCD_DC_Context.Action)object2).label = this.getLabel("MODIFY_TERMINAL_ACCESS");
                cloneable.add(object2);
                yP_View.setRowActionList(n4, (List<YP_TCD_DC_Context.Action>)((Object)cloneable));
            }
            cloneable = null;
            object2 = null;
            String string = yP_Row.getFieldStringValueByName("yp_MerchantIdentifier");
            YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)exception.get(string);
            if (yP_TCD_DCC_Business != null) {
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = yP_TCD_DCC_Business.getDataContainerMerchant();
                cloneable = yP_TCD_DCC_Merchant.getMerchantRow();
                object2 = yP_TCD_DCC_Merchant.getDataContainerBrand().getBrandRow();
            }
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string2 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                String string3 = string2.contentEquals("merchIdent") ? "merchantIdentifier" : string2;
                Field field = yP_Row.getFieldByName(string3);
                Object object3 = null;
                if (field != null) {
                    object3 = yP_Row;
                } else {
                    field = this.dataContainerTechnique.merchant.getFieldByName(string2);
                    if (field != null) {
                        if (cloneable != null) {
                            object3 = cloneable;
                        } else {
                            yP_View.addFieldValue(n4, string2, "");
                        }
                    } else {
                        field = this.dataContainerTechnique.brand.getFieldByName(string2);
                        if (field != null) {
                            if (object2 != null) {
                                object3 = object2;
                            } else {
                                yP_View.addFieldValue(n4, string2, "");
                            }
                        } else {
                            this.logger(2, "getView() unknown column:" + string2);
                            continue;
                        }
                    }
                }
                if (string2.contentEquals("yp_MerchantIdentifier")) {
                    yP_View.addFieldValue(n4, string2, UtilsYP.cryptInfo(((YP_Row)object3).getFieldStringValue(field)));
                    continue;
                }
                this.addFieldValue(yP_View, field, (YP_Row)object3, string2, n4);
            }
            ++n4;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        YP_TCD_DC_Context yP_TCD_DC_Context = null;
        if (yP_TCD_DC_Context == null) {
            YP_TS_DataContainerManager yP_TS_DataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
            yP_TCD_DC_Context = (YP_TCD_DC_Context)yP_TS_DataContainerManager.dealRequest(this, "getDataContainerBusiness", "YouPay_YouPay_GrappeHandler_1");
            if (yP_TCD_DC_Context == null) {
                return null;
            }
            for (YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject : yP_TCD_DC_Context.getDAOList()) {
                if (!yP_TCD_DesignAccesObject.getTableName().contentEquals("TerminalAccess")) continue;
                return yP_TCD_DesignAccesObject;
            }
        }
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() unknown action" + action.id);
        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                Object object;
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    this.logger(2, "createInView() Key must not be set !");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    this.logger(2, "createInView() not really possible !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                String string2 = null;
                String string3 = null;
                block23: for (String string4 : yP_View.getColumnSet()) {
                    object = yP_View.getFieldValueAt(n, string4);
                    if (object == null) continue;
                    switch (string4) {
                        case "idTerminalAccess": {
                            if (((String)object).isEmpty()) continue block23;
                            this.logger(2, "createInView() Key should be empty :" + string4);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "merchIdent": 
                        case "caisseId": 
                        case "terminalIdentification": {
                            int n2 = this.checkSetSpecificValues(yP_Transaction, yP_Row, string4, (String)object);
                            if (n2 >= 0) continue block23;
                            return n2;
                        }
                        case "forceEmvParameterDownload": 
                        case "forcePosParameterDownload": {
                            yP_Row.set(string4, (String)object);
                            break;
                        }
                        case "brandName": {
                            string2 = object;
                            break;
                        }
                        case "merchantName": {
                            string3 = object;
                            break;
                        }
                        case "brandLabel": 
                        case "merchantLabel": {
                            if (((String)object).isEmpty()) continue block23;
                            this.logger(2, "createInView() field ignored :" + string4);
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string4);
                        }
                    }
                }
                if (string2 == null || string2.isEmpty()) {
                    this.logger(2, "createInView() mandatory value missing:brandName");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string3 == null || string3.isEmpty()) {
                    this.logger(2, "createInView() mandatory value missing:merchantName");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", String.valueOf(string2) + '_' + string3);
                if (yP_TCD_DCC_Merchant == null) {
                    this.logger(2, "createInView() error while retrieving dataContainerMerchant");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                List<YP_TCD_DCC_Business> list2 = yP_Transaction.getApplicationList();
                if (list2 == null) {
                    this.logger(2, "getView() no application List");
                    return -1;
                }
                object = new ArrayList();
                if (list2.size() == 1 && ((YP_TCD_DCC_Business)list2.get(0)).toString().contentEquals("DataContainerGRP") && list2.get(0).getDataContainerMerchant() == yP_TCD_DCC_Merchant) {
                    object.add(list2.get(0));
                } else {
                    list2 = yP_TCD_DCC_Merchant.dataContainerBusinessList;
                    if (list2 == null) {
                        this.logger(2, "createInView() error while retrieving dataContainerBusinessList");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    if (list2.isEmpty()) {
                        this.logger(2, "createInView() dataContainerBusinessList is empty");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list2) {
                        if (!yP_TCD_DCC_Business.toString().contentEquals("DataContainerGRP")) continue;
                        object.add(yP_TCD_DCC_Business);
                    }
                }
                if (object.isEmpty()) {
                    this.logger(2, "createInView() grappeHandlerList is empty");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (object.size() > 1) {
                    this.logger(2, "createInView() too many elements in grappeHandlerList");
                }
                yP_Row.set("merchantToClarify", "");
                yP_Row.set("yp_MerchantIdentifier", ((YP_TCD_DCC_Business)object.get(0)).getContractIdentifier());
                yP_Row.set("caisseCode", "");
                yP_Row.set("caisseLabel", "");
                yP_Row.set("codePiedTicket1", "");
                yP_Row.set("codePiedTicket2", "");
                yP_Row.set("total", "0");
                yP_Row.set("remise", "0");
                yP_Row.set("journal", "0");
                yP_Row.set("annulAutre", "0");
                yP_Row.set("annul", "0");
                yP_Row.set("forcage", "0");
                yP_Row.set("changeDom", "0");
                yP_Row.set("preaut", "0");
                yP_Row.set("refund", "0");
                yP_Row.set("finJour", "0");
                yP_Row.set("duplicata", "0");
                yP_Row.set("typeperiode", "0");
                yP_Row.set("visulasttr", "0");
                yP_Row.set("codelogoclt", "00");
                yP_Row.set("codelogobqe", "1");
                yP_Row.set("poslogoclt", "0");
                yP_Row.set("poslogobqe", "1");
                yP_Row.set("withcaissierinfo", "0");
                yP_Row.set("withfactureinfo", "0");
                yP_Row.set("nbreticketdpl", "2");
                yP_Row.set("nbreticket", "2");
                yP_Row.set("timeattenterep", "60");
                yP_Row.set("forceParameterDownload", "0");
                yP_Row.setIsItAClonedRow(false);
                yP_Row.persist();
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() ", exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    @Override
    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        switch (string) {
            case "merchantName": {
                String string3 = string2;
                if (string3 == null || string3.isEmpty()) {
                    this.logger(2, "checkModification() mandatory value missing:merchantName");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_TCD_DCC_Merchant list2 = null;
                for (YP_TCD_DCC_Merchant list3 : yP_Transaction.getMerchantList()) {
                    if (!list3.getMerchantName().contentEquals(string3)) continue;
                    list2 = list3;
                    break;
                }
                if (list2 == null) {
                    this.logger(2, "checkModification() error while retrieving dataContainerMerchant");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                List<YP_TCD_DCC_Business> list = yP_Transaction.getApplicationList();
                if (list == null) {
                    this.logger(2, "getView() no application List");
                    return -1;
                }
                ArrayList arrayList = new ArrayList();
                if (list.size() == 1 && list.get(0).toString().contentEquals("DataContainerGRP") && list.get(0).getDataContainerMerchant() == list2) {
                    arrayList.add(list.get(0));
                } else {
                    List<YP_TCD_DCC_Business> list3 = list2.dataContainerBusinessList;
                    if (list3 == null) {
                        this.logger(2, "checkModification() error while retrieving dataContainerBusinessList");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    if (list3.isEmpty()) {
                        this.logger(2, "checkModification() dataContainerBusinessList is empty");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list3) {
                        if (!yP_TCD_DCC_Business.toString().contentEquals("DataContainerGRP")) continue;
                        arrayList.add(yP_TCD_DCC_Business);
                    }
                }
                if (arrayList.isEmpty()) {
                    this.logger(2, "createInView() grappeHandlerList is empty");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (arrayList.size() > 1) {
                    this.logger(2, "createInView() too many elements in grappeHandlerList");
                }
                yP_Row.set("yp_MerchantIdentifier", ((YP_TCD_DCC_Business)arrayList.get(0)).getContractIdentifier());
                break;
            }
            case "merchIdent": 
            case "caisseId": 
            case "terminalIdentification": {
                int n = this.checkSetSpecificValues(yP_Transaction, yP_Row, string, string2);
                if (n >= 0) break;
                return n;
            }
        }
        return 1;
    }

    private boolean checkLongValue(String string) {
        try {
            Long.parseLong(string);
            return true;
        }
        catch (NumberFormatException numberFormatException) {
            return false;
        }
    }

    private int checkSetSpecificValues(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        switch (string) {
            case "merchIdent": {
                int n = string2.length();
                if (n < 1 || n > 10) {
                    this.logger(2, "createInView() value is too long :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (!this.checkLongValue(string2)) {
                    this.logger(2, "createInView() value is not a numeric :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                yP_Row.set("merchantIdentifier", string2);
                break;
            }
            case "terminalIdentification": {
                int n = string2.length();
                if (n < 1 || n > 8) {
                    this.logger(2, "createInView() value is too long :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (!this.checkLongValue(string2)) {
                    this.logger(2, "createInView() value is not a numeric :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                yP_Row.set(string, string2);
                break;
            }
            case "caisseId": {
                int n = string2.length();
                if (n < 1 || n > 5) {
                    this.logger(2, "createInView() value is too long :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (!this.checkLongValue(string2)) {
                    this.logger(2, "createInView() value is not a numeric :" + string);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                String string3 = String.format("%05d", Long.parseLong(string2));
                yP_Row.set(string, string3);
                break;
            }
            default: {
                return -1;
            }
        }
        return 1;
    }
}

