/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;

public abstract class YP_TCG_View
extends YP_GlobalComponent {
    public YP_TCG_View(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    public abstract YP_View createEmptyView(YP_TCD_DCC_Interface_View var1, YP_Transaction var2, long var3, List<DAO_ViewColumn> var5);

    public abstract YP_View getView(YP_TCD_DCC_Interface_View var1, YP_Transaction var2, long var3, List<DAO_ViewColumn> var5);

    public abstract int createInView(YP_TCD_DCC_Interface_View var1, YP_Transaction var2, YP_View var3, List<DAO_ViewColumn> var4);

    public abstract int executeAction(YP_TCD_DCC_Interface_View var1, YP_Transaction var2, YP_View var3, YP_Row var4, YP_TCD_DC_Context.Action var5);

    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        yP_Row.setModifierFlag(2);
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int setView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                Object object;
                Object object22;
                String string = yP_View.getRowIDAt(n);
                if (string == null || string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() bad identifier !");
                    }
                    return -1;
                }
                String[] stringArray = string.split("#");
                if (stringArray.length != 3) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() bad identifier !!");
                    }
                    return -1;
                }
                String string2 = stringArray[0];
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string2);
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() bad identifier !!!");
                    }
                    return -1;
                }
                String string3 = stringArray[1];
                long l = Long.parseLong(stringArray[2]);
                if (!yP_TCD_DesignAccesObject.getPrimaryKeyName().contentEquals(string3)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() bad identifier !!!!");
                    }
                    return -1;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit.set(string3, YP_ComplexGabarit.OPERATOR.EQUAL, l);
                List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
                if (list2 == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() null !!!");
                    }
                    return -1;
                }
                if (list2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() empty");
                    }
                    return -1;
                }
                if (list2.size() != 1) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() too many");
                    }
                    return -1;
                }
                YP_Row yP_Row = list2.get(0);
                for (Object object22 : yP_View.getColumnSet()) {
                    String string4;
                    Field field;
                    object = yP_View.getFieldValueAt(n, (String)object22);
                    if (object == null) continue;
                    int n2 = this.checkModification(yP_Transaction, yP_Row, (String)object22, (String)object);
                    if (n2 < 0) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "setView() aborted by view");
                        }
                        return -1;
                    }
                    if (n2 == 0) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "setView() modification not allowed");
                        }
                        return 0;
                    }
                    if (n2 == 2 || (field = yP_Row.getFieldByName((String)object22)) == null || (string4 = yP_Row.getFieldStringValue(field)) != null && ((String)object).contentEquals(string4)) continue;
                    boolean bl = false;
                    for (DAO_ViewColumn dAO_ViewColumn : list) {
                        if (!((String)object22).contentEquals(YP_Row.getStringValue(dAO_ViewColumn.columnName))) continue;
                        if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                            if (((String)object22).contentEquals("idMerchant")) {
                                long l2 = this.getIdMerchant(yP_Transaction, (String)object);
                                yP_Row.setFieldValue(field, l2);
                            } else {
                                yP_Row.setFieldValue(field, (String)object);
                            }
                        } else {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "setView() No rights");
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                            return -1;
                        }
                        bl = true;
                        break;
                    }
                    if (bl) continue;
                    yP_Row.setFieldValue(field, (String)object);
                }
                this.dealRowModificationsBeforePersist(yP_Row);
                if (yP_Row.persist() < 0) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "setView() Not able to save changes...");
                    }
                    return -1;
                }
                this.dealDAOModificationsAfterPersist(yP_TCD_DesignAccesObject);
                object22 = yP_View.getRowActionList(n);
                if (object22 != null && !object22.isEmpty()) {
                    object = object22.iterator();
                    while (object.hasNext()) {
                        YP_TCD_DC_Context.Action action = (YP_TCD_DC_Context.Action)object.next();
                        if (this.executeAction(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_Row, action) >= 0) continue;
                        return -1;
                    }
                }
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setView() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        try {
            List<YP_TCD_DCC_Business> list;
            Object object;
            YP_OnDemandComponent yP_OnDemandComponent;
            String[] stringArray;
            if (string != null && string.contains("|")) {
                stringArray = string.split("\\|");
                if (stringArray == null || stringArray.length != 2) {
                    this.logger(2, "getDAO() not valid :" + string);
                    return null;
                }
                yP_OnDemandComponent = (YP_TCD_DCC_Business)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBusiness", stringArray[0]);
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = ((YP_TCD_DataContainer)yP_OnDemandComponent).getDesignAccesObject_ByName(stringArray[1]);
                if (yP_TCD_DesignAccesObject != null) {
                    return yP_TCD_DesignAccesObject;
                }
            }
            if ((yP_OnDemandComponent = (stringArray = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique()).getDesignAccesObject_ByFullTableName(string)) != null) {
                return yP_OnDemandComponent;
            }
            List<YP_TCD_DCC_Brand> list2 = yP_Transaction.getBrandList();
            if (list2 != null && !list2.isEmpty()) {
                object = list2.iterator();
                while (object.hasNext()) {
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = object.next();
                    yP_OnDemandComponent = yP_TCD_DCC_Brand.getDesignAccesObject_ByFullTableName(string);
                    if (yP_OnDemandComponent == null) continue;
                    return yP_OnDemandComponent;
                }
            }
            if ((list = yP_Transaction.getApplicationList()) == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getDAO() no application List");
                }
                return null;
            }
            if (list.isEmpty()) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getDAO() application List empty");
                }
                return null;
            }
            Iterator<YP_TCD_DCC_Business> iterator = list.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getDAO() not found :" + string);
                }
                return null;
            } while ((yP_OnDemandComponent = ((YP_TCD_DataContainer)(object = iterator.next())).getDesignAccesObject_ByFullTableName(string)) == null);
            return yP_OnDemandComponent;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() bad identifier !!!");
            }
            return null;
        }
    }

    public String getLabel(long l, String string) {
        if (l <= 0L) {
            if (this.getLogLevel() >= 3) {
                this.logger(3, "getLabel() idLabel should be added to column:" + string);
            }
            return this.getLabel(string);
        }
        return this.getLabel(l);
    }

    public int dealEnumColumn(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, long l, String string, Field field) {
        YP_Object yP_Object = this.getPluginByName("Internationalization");
        YP_Object yP_Object2 = this.getPluginByName("Enumeration");
        String string2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserPreferredLanguage();
        Map<String, String> map = yP_View.getEnumMap(string);
        Map<String, Object> map2 = yP_View.getEnumMapInversed(string);
        try {
            StringBuilder stringBuilder = new StringBuilder();
            Class clazz = Boolean.class;
            if (field != null) {
                clazz = field.getType();
            }
            if (clazz == Boolean.class) {
                yP_View.getColumnProperties(string).put("enumList", "0,1");
                map.put("false", "0");
                map2.put("0", false);
                map.put("true", "1");
                map2.put("1", true);
            } else {
                Enum[] enumArray;
                Enum[] enumArray2 = enumArray = (Enum[])clazz.getEnumConstants();
                int n = enumArray.length;
                int n2 = 0;
                while (n2 < n) {
                    String string3;
                    Enum enum_ = enumArray2[n2];
                    try {
                        if (l <= 0L) {
                            string3 = enum_.toString();
                        } else {
                            long l2 = (Long)yP_Object2.dealRequest(this, "getIdLabel", l, enum_.toString());
                            if (l2 <= 0L) {
                                string3 = enum_.toString();
                            } else {
                                string3 = string2 == null || string2.isEmpty() ? enum_.toString() : (String)yP_Object.dealRequest(this, "getTranslatedText", l2, string2);
                                if (string3 == null || string3.isEmpty()) {
                                    yP_Object.dealRequest(this, "createTranslatedText", l2, string2, enum_.toString());
                                    string3 = enum_.toString();
                                }
                                map.put(enum_.toString(), string3);
                                if (map2.put(string3, enum_) != null && this.getLogLevel() >= 2) {
                                    this.logger(2, "createEmptyView() same translation for " + string3 + " " + enum_.toString());
                                }
                            }
                        }
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createEmptyView() " + exception);
                        }
                        string3 = enum_.toString();
                    }
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append(',');
                    }
                    stringBuilder.append(string3);
                    ++n2;
                }
                yP_View.getColumnProperties(string).put("enumList", stringBuilder.toString());
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "dealEnumColumn() ", exception);
            return -1;
        }
    }

    protected long getIdUser(String string) {
        long l;
        YP_Object yP_Object;
        block10: {
            if (string == null || string.isEmpty()) {
                return 0L;
            }
            yP_Object = this.getPluginByName("User");
            if (yP_Object == null) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "getIdUser() no plugin user available");
                }
                return -1L;
            }
            try {
                l = Long.parseLong(string);
                if (l != 0L) break block10;
                return 0L;
            }
            catch (Exception exception) {}
        }
        YP_Row yP_Row = (YP_Row)yP_Object.dealRequest(this, "getUserRowByID", l);
        if (yP_Row != null) {
            return l;
        }
        try {
            YP_Row yP_Row2 = (YP_Row)yP_Object.dealRequest(this, "getUserRowByLogin", string);
            if (yP_Row2 != null) {
                return (Long)yP_Row2.getFieldValueByName("idUser");
            }
        }
        catch (Exception exception) {
            this.logger(2, "getIdUser() " + exception);
        }
        return -1L;
    }

    protected int addFieldValue(YP_View yP_View, Field field, YP_Row yP_Row, String string, int n) {
        if (field == null || yP_Row == null) {
            return -1;
        }
        String string2 = yP_Row.getFieldStringValue(field);
        String string3 = yP_View.getColumnFormat(string);
        if (string3 != null && string3.contentEquals("enum")) {
            yP_View.addFieldValue(n, string, yP_View.getEnumMap(string).get(string2));
        } else {
            yP_View.addFieldValue(n, string, string2);
        }
        return 1;
    }

    /*
     * Unable to fully structure code
     */
    protected long getIdMerchant(YP_Transaction var1_1, String var2_2) {
        block6: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Merchant var5_7 : var1_1.getMerchantList()) {
                    if (var5_7.getIDMerchant() != var3_3) continue;
                    return var3_3;
                }
                break block6;
            }
            catch (Exception v0) {
                ** for (var3_4 : var1_1.getMerchantList())
            }
lbl-1000:
            // 1 sources

            {
                if (!var3_4.getContractIdentifier().contentEquals(var2_2)) continue;
                return var3_4.getIDMerchant();
            }
        }
        var3_5 = var1_1.getContractIdentifier().split("_");
        if (var3_5.length == 2 && var3_5[0].contentEquals(var3_5[1]) && (var4_9 = this.getIdMerchantOld(var1_1, var2_2)) > 0L) {
            this.logger(2, "getIdMerchant() Retreived using old method to keep the compatibility");
            return var4_9;
        }
        return -1L;
    }

    /*
     * Unable to fully structure code
     */
    private long getIdMerchantOld(YP_Transaction var1_1, String var2_2) {
        block5: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Merchant var5_6 : var1_1.getDataContainerTransaction().contextHandler.merchantContainers) {
                    if (var5_6.getIDMerchant() != var3_3) continue;
                    return var3_3;
                }
                break block5;
            }
            catch (Exception v0) {
                ** for (var3_4 : var1_1.getDataContainerTransaction().contextHandler.merchantContainers)
            }
lbl-1000:
            // 1 sources

            {
                if (!var3_4.getContractIdentifier().contentEquals(var2_2)) continue;
                return var3_4.getIDMerchant();
            }
        }
        return -1L;
    }

    protected void dealRowModificationsBeforePersist(YP_Row yP_Row) {
    }

    protected void dealDAOModificationsAfterPersist(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
    }

    protected YP_TCD_DC_Context.Action getConfirmAction(YP_Transaction yP_Transaction, String string) {
        YP_TCD_DC_Context.Action action = this.getAction(yP_Transaction, string);
        action.formName = "StandardConfirmationForm";
        return action;
    }

    protected YP_TCD_DC_Context.Action getAction(YP_Transaction yP_Transaction, String string) {
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.id = string;
        action.label = this.getLabel(string);
        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
        action.formName = "StandardNoConfirmationForm";
        return action;
    }
}

