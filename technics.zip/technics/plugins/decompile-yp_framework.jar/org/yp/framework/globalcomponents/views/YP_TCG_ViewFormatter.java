/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;

public class YP_TCG_ViewFormatter
extends YP_GlobalComponent {
    YP_TCD_DCC_Interface_View extensionViewFormatter;

    public YP_TCG_ViewFormatter(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() no DCC_Technique...");
            }
            return -1;
        }
        this.extensionViewFormatter = (YP_TCD_DCC_Interface_View)((Object)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtensionViewFormatter", new Object[0]));
        this.extensionViewFormatter.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "ViewFormatter";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    private int getView(YP_Transaction yP_Transaction, String string) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol;
        Object object2;
        block29: {
            block28: {
                block27: {
                    List<DAO_ViewColumn> list;
                    long l;
                    YP_TCG_View yP_TCG_View;
                    block26: {
                        int n;
                        block25: {
                            DAO_View dAO_View;
                            block24: {
                                block23: {
                                    block22: {
                                        yP_TCG_View = (YP_TCG_View)this.getPluginByName(string);
                                        if (yP_TCG_View != null) break block22;
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() unknow view :" + string);
                                        }
                                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                                        return -1;
                                    }
                                    dAO_View = this.extensionViewFormatter.getViewRow(string);
                                    if (dAO_View != null) break block23;
                                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                                    return -1;
                                }
                                l = dAO_View.idView;
                                if (l > 0L) break block24;
                                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                                return -1;
                            }
                            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() == 0L) {
                                n = 1;
                                break block25;
                            }
                            n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                            if (dAO_View.readAccessList != null && dAO_View.readAccessList.isSet(n)) break block25;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "getView() don't have the right to read view :" + string);
                            }
                            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(14));
                            return -1;
                        }
                        list = this.extensionViewFormatter.getColumns(l, n);
                        if (list != null) break block26;
                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                        return -1;
                    }
                    if (UtilsYP.getInstanceRole() == 1) {
                        object2 = this.getPluginByName("Internationalization");
                        for (DAO_ViewColumn object3 : list) {
                            long n;
                            YP_Row n2;
                            if (object3.idLabel > 0L || (n2 = (YP_Row)((YP_Object)object2).dealRequest(this, "createNewLabel", YP_Row.getStringValue(object3.columnName))) == null) continue;
                            object3.idLabel = n = n2.getPrimaryKey();
                            object3.setModifierFlag(2);
                            object3.persist();
                        }
                    }
                    if ((object2 = yP_TCG_View.getView(this.extensionViewFormatter, yP_Transaction, l, list)) != null) break block27;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() unable to get view :" + string);
                    }
                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    return -1;
                }
                yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
                if (yP_TCD_PosProtocol != null) break block28;
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block29;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
        try {
            int n;
            YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
            int n2 = yP_PROT_IHM.getStartIndex();
            if (n2 < 0) {
                n2 = 0;
            }
            if ((n = yP_PROT_IHM.getMaxRecords()) < 0) {
                n = string.contentEquals("View_Contract") ? 50000 : (string.contentEquals("View_Context") ? 99999 : 1000);
            }
            boolean bl = false;
            int n3 = ((YP_View)object2).size() - n2;
            if (n3 > n) {
                n3 = n;
                bl = true;
            }
            yP_PROT_IHM.createGetDataResponse(string, n2, n3, bl);
            for (String string2 : ((YP_View)object2).getColumnSet()) {
                yP_PROT_IHM.addColumnToResponse(((YP_View)object2).getColumnRank(string2), string2, ((YP_View)object2).getColumnLabel(string2), ((YP_View)object2).getColumnFormat(string2), ((YP_View)object2).getColumnProperties(string2));
            }
            yP_PROT_IHM.addViewContentToResponse((YP_View)object2, n2, n3);
            if (n2 >= n3 && n != 0) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(1));
            }
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "getView() ", exception);
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int setView(YP_Transaction yP_Transaction, String string) {
        try {
            Object object;
            DAO_View dAO_View = this.extensionViewFormatter.getViewRow(string);
            if (dAO_View == null) {
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            long l = dAO_View.idView;
            if (l <= 0L) {
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
            YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
            if (yP_TCD_PosProtocol == null) {
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setView() bad interface");
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
            YP_TCG_View yP_TCG_View = (YP_TCG_View)this.getPluginByName(string);
            if (yP_TCG_View == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setView() unknow view :" + string);
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            List<DAO_ViewColumn> list = this.extensionViewFormatter.getColumns(l, n);
            if (list == null) {
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            if (UtilsYP.getInstanceRole() == 1) {
                object = this.getPluginByName("Internationalization");
                for (DAO_ViewColumn dAO_ViewColumn : list) {
                    long l2;
                    YP_Row yP_Row;
                    if (dAO_ViewColumn.idLabel > 0L || (yP_Row = (YP_Row)((YP_Object)object).dealRequest(this, "createNewLabel", YP_Row.getStringValue(dAO_ViewColumn.columnName))) == null) continue;
                    dAO_ViewColumn.idLabel = l2 = yP_Row.getPrimaryKey();
                    dAO_ViewColumn.setModifierFlag(2);
                    dAO_ViewColumn.persist();
                }
            }
            if ((object = yP_TCG_View.createEmptyView(this.extensionViewFormatter, yP_Transaction, l, list)) == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setView() unable to get view :" + string);
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            boolean bl = false;
            int n2 = yP_PROT_IHM.updateViewHeaderFromRequest((YP_View)object);
            if (n2 < 0) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setView() unable to update view :" + string);
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (n2 > 0) {
                long l3 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
                List<YP_Row> list2 = this.extensionViewFormatter.getColumnCustomization(l3, list);
                for (DAO_ViewColumn dAO_ViewColumn : list) {
                    DAO_ViewColumnCustomization dAO_ViewColumnCustomization;
                    String string2;
                    String string3 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                    int n3 = ((YP_View)object).getColumnRank(string3);
                    int n4 = 0;
                    Map<String, String> map = ((YP_View)object).getColumnProperties(string3);
                    if (map != null && (string2 = map.get("width")) != null && !string2.isEmpty()) {
                        n4 = (int)Float.parseFloat(string2);
                    }
                    boolean bl2 = false;
                    Iterator iterator = list2.iterator();
                    while (iterator.hasNext()) {
                        dAO_ViewColumnCustomization = (DAO_ViewColumnCustomization)iterator.next();
                        if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                        if (dAO_ViewColumnCustomization.rank != n3) {
                            dAO_ViewColumnCustomization.rank = n3;
                            dAO_ViewColumnCustomization.setModifierFlag(2);
                        }
                        if (dAO_ViewColumnCustomization.width != n4) {
                            dAO_ViewColumnCustomization.width = n4;
                            dAO_ViewColumnCustomization.setModifierFlag(2);
                        }
                        bl2 = true;
                    }
                    if (bl2) continue;
                    dAO_ViewColumnCustomization = this.extensionViewFormatter.createColumnCustomization(l3, dAO_ViewColumn.idViewColumn);
                    dAO_ViewColumnCustomization.rank = n3;
                    dAO_ViewColumnCustomization.width = n4;
                    dAO_ViewColumnCustomization.setIsItAClonedRow(false);
                    list2.add(dAO_ViewColumnCustomization);
                }
                YP_Row.persistList(list2);
                bl = true;
            }
            if ((n2 = yP_PROT_IHM.updateViewContentFromRequest((YP_View)object)) < 0) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "setView() unable to update view :" + string);
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (n2 == 0 && !bl) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "setView() no data, no header ... :" + string);
                }
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return 1;
            }
            if (!(dAO_View.writeAccessList != null && dAO_View.writeAccessList.isSet(n) || yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() == 0L && yP_Transaction.getDataContainerTransaction().accountHandler.getCustomerIdentifier() > 0L)) {
                int n5 = 0;
                while (n5 < ((YP_View)object).size()) {
                    for (String string4 : ((YP_View)object).getColumnSet()) {
                        String string5 = ((YP_View)object).getFieldValueAt(n5, string4);
                        if (string5 == null) continue;
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "setView() don't have the right to set view : " + string);
                        }
                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    ++n5;
                }
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "setView() Probably a header modification or an action");
                }
            }
            if (((YP_View)object).size() != 0) {
                n2 = yP_TCG_View.setView(this.extensionViewFormatter, yP_Transaction, (YP_View)object, list);
            }
            if (n2 == 1 || n2 == 0 && bl) {
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
                return 1;
            }
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "setView() ", exception);
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
    }

    private int createInView(YP_Transaction yP_Transaction, String string) {
        block33: {
            block36: {
                ExtendedResult extendedResult;
                block35: {
                    block34: {
                        int n;
                        YP_View yP_View;
                        List<DAO_ViewColumn> list;
                        YP_TCG_View yP_TCG_View;
                        block32: {
                            block31: {
                                YP_PROT_IHM yP_PROT_IHM;
                                block30: {
                                    long l;
                                    block29: {
                                        int n2;
                                        block28: {
                                            YP_TCD_PosProtocol yP_TCD_PosProtocol;
                                            block27: {
                                                block26: {
                                                    block25: {
                                                        DAO_View dAO_View;
                                                        block24: {
                                                            block23: {
                                                                try {
                                                                    dAO_View = this.extensionViewFormatter.getViewRow(string);
                                                                    if (dAO_View != null) break block23;
                                                                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                                    return -1;
                                                                }
                                                                catch (Exception exception) {
                                                                    if (this.getLogLevel() >= 2) {
                                                                        this.logger(2, "createInView() " + exception);
                                                                    }
                                                                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                                    return -1;
                                                                }
                                                            }
                                                            l = dAO_View.idView;
                                                            if (l > 0L) break block24;
                                                            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                            return -1;
                                                        }
                                                        n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                                                        if (dAO_View.createAccessList != null && dAO_View.createAccessList.isSet(n2)) break block25;
                                                        if (this.getLogLevel() >= 2) {
                                                            this.logger(2, "createInView() don't have the right to create in view :" + string);
                                                        }
                                                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                                        return -1;
                                                    }
                                                    yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
                                                    if (yP_TCD_PosProtocol != null) break block26;
                                                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                    return -1;
                                                }
                                                if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block27;
                                                if (this.getLogLevel() >= 2) {
                                                    this.logger(2, "createInView() bad interface");
                                                }
                                                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                return -1;
                                            }
                                            yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                                            yP_TCG_View = (YP_TCG_View)this.getPluginByName(string);
                                            if (yP_TCG_View != null) break block28;
                                            if (this.getLogLevel() >= 2) {
                                                this.logger(2, "createInView() unknow view :" + string);
                                            }
                                            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                                            return -1;
                                        }
                                        list = this.extensionViewFormatter.getColumns(l, n2);
                                        if (list != null) break block29;
                                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                        return -1;
                                    }
                                    yP_View = yP_TCG_View.createEmptyView(this.extensionViewFormatter, yP_Transaction, l, list);
                                    if (yP_View != null) break block30;
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "createInView() unable to get view :" + string);
                                    }
                                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                                    return -1;
                                }
                                n = yP_PROT_IHM.updateViewContentFromRequest(yP_View);
                                if (n >= 0) break block31;
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() unable to update view :" + string);
                                }
                                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                                return -1;
                            }
                            if (n != 0) break block32;
                            if (this.getLogLevel() >= 3) {
                                this.logger(3, "createInView() no data ... :" + string);
                            }
                            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return 1;
                        }
                        n = yP_TCG_View.createInView(this.extensionViewFormatter, yP_Transaction, yP_View, list);
                        if (n != 1) break block33;
                        extendedResult = YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction());
                        if (!extendedResult.isSet(7)) break block34;
                        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                        return 0;
                    }
                    if (!extendedResult.isSet(4)) break block35;
                    YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                    return 0;
                }
                if (!extendedResult.isSet(102)) break block36;
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                return 0;
            }
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "getView": {
                    if (yP_Object instanceof YP_Transaction && objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.getView((YP_Transaction)yP_Object, (String)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getView");
                    }
                    return null;
                }
                case "setView": {
                    if (yP_Object instanceof YP_Transaction && objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.setView((YP_Transaction)yP_Object, (String)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for setView");
                    }
                    return null;
                }
                case "createInView": {
                    if (yP_Object instanceof YP_Transaction && objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.createInView((YP_Transaction)yP_Object, (String)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for createInView");
                    }
                    return null;
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }
}

