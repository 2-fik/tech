/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.designaccesobjects.brand.DAO_Summary;
import org.yp.designaccesobjects.technic.DAO_Contract;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.sqlformaters.YP_TCG_MYSQL_Formater;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_View_Summary
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;
    YP_TCD_DAO_LOC_Table daoSummaryGlobalForCreateEmpty = null;

    public YP_TCG_View_Summary(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        this.daoSummaryGlobalForCreateEmpty = (YP_TCD_DAO_LOC_Table)this.dataContainerTechnique.newPluginByName("DAO_Table", DAO_Summary.class, 0, 1, null);
        return 1;
    }

    @Override
    public String toString() {
        return "View_Summary";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        List<YP_TCD_DCC_Business> list3 = yP_Transaction.getApplicationList();
        if (list3 == null) {
            this.logger(2, "createEmptyView() error while retrieving applicationList");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(3, "createEmptyView() no application List");
            return yP_View;
        }
        block6: for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
            Field field;
            String string;
            String string2;
            block19: {
                block23: {
                    block22: {
                        block21: {
                            block20: {
                                block18: {
                                    string2 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                                    string = this.getLabel(dAO_ViewColumn.idLabel, string2);
                                    field = this.daoSummaryGlobalForCreateEmpty.getFieldByName(string2);
                                    if (field == null) break block18;
                                    yP_TCD_DesignAccesObject = this.daoSummaryGlobalForCreateEmpty;
                                    break block19;
                                }
                                field = this.dataContainerTechnique.contract.getFieldByName(string2);
                                if (field == null) break block20;
                                yP_TCD_DesignAccesObject = this.dataContainerTechnique.contract;
                                break block19;
                            }
                            field = this.dataContainerTechnique.merchant.getFieldByName(string2);
                            if (field == null) break block21;
                            yP_TCD_DesignAccesObject = this.dataContainerTechnique.merchant;
                            break block19;
                        }
                        field = this.dataContainerTechnique.brand.getFieldByName(string2);
                        if (field == null) break block22;
                        yP_TCD_DesignAccesObject = this.dataContainerTechnique.brand;
                        break block19;
                    }
                    field = this.dataContainerTechnique.application.getFieldByName(string2);
                    if (field == null) break block23;
                    yP_TCD_DesignAccesObject = this.dataContainerTechnique.application;
                    break block19;
                }
                switch (string2) {
                    case "storeLabel": {
                        yP_View.addCustomColumn(string2, string, "string", dAO_ViewColumn.defaultRank);
                        yP_TCD_DesignAccesObject = null;
                        break;
                    }
                    default: {
                        this.logger(2, "createEmptyView() unknown column:" + string2);
                        continue block6;
                    }
                }
            }
            if (yP_TCD_DesignAccesObject != null && yP_View.addColumn(string2, string, yP_TCD_DesignAccesObject, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string2);
            }
            if (yP_View.getColumnFormat(string2).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string2, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string2, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string2).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string2).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string2).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string2).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        List<YP_Row> list22;
        List<YP_Row> list3;
        Object object;
        Object object2;
        String string;
        boolean bl;
        boolean bl2;
        boolean bl3;
        boolean bl4;
        boolean bl5;
        boolean bl6;
        HashMap hashMap;
        YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table;
        HashMap<Long, YP_Row> hashMap2;
        List<YP_TCD_DCC_Business> list4;
        YP_View yP_View;
        block110: {
            Object object3;
            yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
            if (yP_View == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() ");
                }
                return null;
            }
            YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
            if (yP_TCD_PosProtocol == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() No protocol...");
                }
                return null;
            }
            if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() bad interface");
                }
                return null;
            }
            YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
            int n = yP_PROT_IHM.getMaxRecords();
            if (n == 0) {
                return yP_View;
            }
            if (n < 0) {
                n = 1000;
            }
            ++n;
            int n2 = yP_PROT_IHM.getStartIndex();
            if (n2 < 0) {
                n2 = 0;
            }
            if ((list4 = yP_Transaction.getApplicationList()) == null) {
                this.logger(2, "getView() error while retrieving applicationList");
                return null;
            }
            if (list4.isEmpty()) {
                this.logger(3, "getView() no application List");
                return yP_View;
            }
            hashMap2 = new HashMap<Long, YP_Row>();
            for (YP_TCD_DCC_Business yP_OnDemandComponent2 : list4) {
                object3 = (DAO_Contract)yP_OnDemandComponent2.getContractRow();
                if (hashMap2.get(((DAO_Contract)object3).idApplication) != null) continue;
                YP_Row bl62 = this.dataContainerTechnique.application.getRowFromNaturalJoin((YP_Row)object3);
                hashMap2.put(((DAO_Contract)object3).idApplication, bl62);
            }
            yP_TCD_DAO_LOC_Table = (YP_TCD_DAO_LOC_Table)this.dataContainerTechnique.newPluginByName("DAO_Table", DAO_Summary.class, 0, 1, null);
            hashMap = new HashMap();
            object3 = yP_PROT_IHM.getSearchGabarit();
            bl6 = false;
            bl5 = false;
            bl4 = false;
            bl3 = false;
            bl2 = false;
            bl = false;
            string = "";
            if (object3 == null || object3.isEmpty()) break block110;
            Iterator iterator = object3.iterator();
            block20: while (iterator.hasNext()) {
                block109: {
                    object2 = (YP_Gabarit)iterator.next();
                    if (!((YP_Gabarit)object2).fieldName.contentEquals("transactionAppliLocalTime")) break block109;
                    if (((YP_Gabarit)object2).operator == YP_ComplexGabarit.OPERATOR.GREATER) {
                        string = String.valueOf(string) + "                    AND transactionAppliLocalTime > '" + ((YP_Gabarit)object2).objectTosearch + "'\r\n";
                        continue;
                    }
                    if (((YP_Gabarit)object2).operator == YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL) {
                        string = String.valueOf(string) + "                    AND transactionAppliLocalTime >= '" + ((YP_Gabarit)object2).objectTosearch + "'\r\n";
                        continue;
                    }
                    if (((YP_Gabarit)object2).operator != YP_ComplexGabarit.OPERATOR.LESS) {
                        string = String.valueOf(string) + "                    AND transactionAppliLocalTime < '" + ((YP_Gabarit)object2).objectTosearch + "'\r\n";
                        continue;
                    }
                    if (((YP_Gabarit)object2).operator != YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL) {
                        string = String.valueOf(string) + "                    AND transactionAppliLocalTime <= '" + ((YP_Gabarit)object2).objectTosearch + "'\r\n";
                        continue;
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() bad gabarit :" + ((YP_Gabarit)object2).fieldName + " " + (Object)((Object)((YP_Gabarit)object2).operator) + " " + ((YP_Gabarit)object2).objectTosearch);
                    }
                    return null;
                }
                try {
                    if (((YP_Gabarit)object2).operator != YP_ComplexGabarit.OPERATOR.GROUP) {
                        if (this.getLogLevel() < 2) continue;
                        this.logger(2, "getView() bad gabarit :" + ((YP_Gabarit)object2).fieldName + " " + (Object)((Object)((YP_Gabarit)object2).operator) + " " + ((YP_Gabarit)object2).objectTosearch);
                        continue;
                    }
                    switch (((YP_Gabarit)object2).fieldName) {
                        case "date": {
                            bl6 = true;
                            break;
                        }
                        case "contractIdentifier": {
                            bl5 = true;
                            break;
                        }
                        case "terminal": {
                            bl4 = true;
                            break;
                        }
                        case "cashierID": {
                            bl3 = true;
                            break;
                        }
                        case "storeIdentifier": {
                            bl2 = true;
                            break;
                        }
                        case "shiftNumber": {
                            bl = true;
                            break;
                        }
                        default: {
                            if (this.getLogLevel() < 2) continue block20;
                            this.logger(2, "getView() unknown column:" + ((YP_Gabarit)object2).fieldName);
                            break;
                        }
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView()  " + exception);
                }
            }
        }
        object2 = new ArrayList();
        if (bl5) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list4) {
                if (yP_TCD_DCC_Business.transaction == null) continue;
                YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = yP_TCD_DCC_Business.getDataBaseConnector();
                object = new StringBuilder();
                ((StringBuilder)object).append("SELECT \r\n");
                if (bl6) {
                    ((StringBuilder)object).append("        dateTmp AS date\r\n");
                } else {
                    ((StringBuilder)object).append("        '***' AS date\r\n");
                }
                ((StringBuilder)object).append("        ,'" + yP_TCD_DCC_Business.getContractIdentifier() + "' AS contractIdentifier\r\n");
                ((StringBuilder)object).append("        ,transactionCurrencyAlpha\r\n");
                if (bl4) {
                    ((StringBuilder)object).append("        ,terminalTmp AS terminal\r\n");
                } else {
                    ((StringBuilder)object).append("        ,'***' AS terminal\r\n");
                }
                if (bl3) {
                    ((StringBuilder)object).append("        ,cashierIDTmp AS cashierID\r\n");
                } else {
                    ((StringBuilder)object).append("        ,'***' AS cashierID\r\n");
                }
                if (bl2) {
                    ((StringBuilder)object).append("        ,storeIdentifierTmp AS storeIdentifier\r\n");
                } else {
                    ((StringBuilder)object).append("        ,'***' AS storeIdentifier\r\n");
                }
                if (bl) {
                    ((StringBuilder)object).append("        ,shiftNumberTmp AS ShiftNumber\r\n");
                } else {
                    ((StringBuilder)object).append("        ,'***' AS shiftNumber\r\n");
                }
                if (yP_TCD_DataBaseConnector.sql_Formater instanceof YP_TCG_MYSQL_Formater) {
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , 1, 0)) AS nbDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0)) AS totalAmountDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND' , 'REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND' , 'REFUND_QUASI_CASH') , transactionAmount, 0)) AS totalAmountRefund\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('REVERSAL_DEBIT' , 'REVERSAL_QUASI_CASH'), 1, 0)) AS nbReversalDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('REVERSAL_DEBIT' , 'REVERSAL_QUASI_CASH'), transactionAmount, 0)) AS totalAmountReversalDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType = 'INITIAL_RESERVATION', transactionAmount, 0)) AS totalAmountINITIAL_RESERVATION\r\n");
                } else {
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , 1, 0)) AS nbDebit\r\n");
                    ((StringBuilder)object).append("        ,");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0))");
                    ((StringBuilder)object).append(", -1) / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0)) AS Varchar)) AS totalAmountDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND' , 'REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
                    ((StringBuilder)object).append("        ,");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('CREDIT','COMPLEMENTARY_REFUND' , 'REFUND_QUASI_CASH') , transactionAmount, 0))");
                    ((StringBuilder)object).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('CREDIT','COMPLEMENTARY_REFUND' , 'REFUND_QUASI_CASH') , transactionAmount, 0)) AS Varchar)) AS totalAmountRefund\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('REVERSAL_DEBIT' , 'REVERSAL_QUASI_CASH'), 1, 0)) AS nbReversalDebit\r\n");
                    ((StringBuilder)object).append("        ,");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('REVERSAL_DEBIT' , 'REVERSAL_QUASI_CASH') , transactionAmount, 0))");
                    ((StringBuilder)object).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType IN ('REVERSAL_DEBIT' , 'REVERSAL_QUASI_CASH') , transactionAmount, 0)) AS Varchar)) AS totalAmountReversalDebit\r\n");
                    ((StringBuilder)object).append("        ,SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
                    ((StringBuilder)object).append("        ,");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType = 'INITIAL_RESERVATION' , transactionAmount, 0))");
                    ((StringBuilder)object).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)object).append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
                    ((StringBuilder)object).append("(transactionType = 'INITIAL_RESERVATION' , transactionAmount, 0)) AS Varchar)) AS totalAmountINITIAL_RESERVATION\r\n");
                }
                ((StringBuilder)object).append("FROM\r\n");
                ((StringBuilder)object).append("(\r\n");
                this.appendOneContract(true, (StringBuilder)object, yP_TCD_DCC_Business, string);
                ((StringBuilder)object).append(") tmp\r\n");
                ((StringBuilder)object).append("GROUP BY ");
                if (bl6) {
                    ((StringBuilder)object).append("dateTmp,");
                }
                ((StringBuilder)object).append("transactionCurrencyAlpha");
                if (bl4) {
                    ((StringBuilder)object).append(", terminalTmp");
                }
                if (bl3) {
                    ((StringBuilder)object).append(", cashierIDTmp");
                }
                if (bl2) {
                    ((StringBuilder)object).append(", storeIdentifierTmp");
                }
                if (bl) {
                    ((StringBuilder)object).append(", shiftNumberTmp");
                }
                if ((list3 = yP_TCD_DCC_Business.transaction.getDataBaseConnector().dealSelect((YP_TCD_DesignAccesObject)yP_TCD_DCC_Business.transaction, yP_TCD_DAO_LOC_Table, ((StringBuilder)object).toString())) == null) {
                    this.logger(2, "getView() null list");
                    continue;
                }
                if (list3.isEmpty()) {
                    this.logger(4, "getView() nothing found");
                    continue;
                }
                for (YP_Row yP_Row : list3) {
                    object2.add(yP_Row);
                    yP_Row.setPrimaryKey(object2.size());
                    hashMap.put(yP_Row.getPrimaryKey(), yP_TCD_DCC_Business);
                }
            }
        } else {
            HashMap<YP_TCD_DCC_Merchant, ArrayList<YP_TCD_DCC_Business>> hashMap3 = new HashMap<YP_TCD_DCC_Merchant, ArrayList<YP_TCD_DCC_Business>>();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list4) {
                if (yP_TCD_DCC_Business.transaction == null) continue;
                object = (List)hashMap3.get(yP_TCD_DCC_Business.getDataContainerMerchant());
                if (object == null) {
                    object = new ArrayList<YP_TCD_DCC_Business>();
                    hashMap3.put(yP_TCD_DCC_Business.getDataContainerMerchant(), (ArrayList<YP_TCD_DCC_Business>)object);
                }
                object.add(yP_TCD_DCC_Business);
            }
            for (List list5 : hashMap3.values()) {
                object = ((YP_TCD_DCC_Business)list5.get(0)).getDataBaseConnector();
                list3 = new StringBuilder();
                ((StringBuilder)((Object)list3)).append("SELECT \r\n");
                if (bl6) {
                    ((StringBuilder)((Object)list3)).append("        dateTmp AS date\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        '***' AS date\r\n");
                }
                ((StringBuilder)((Object)list3)).append("        ,'***' AS contractIdentifier\r\n");
                ((StringBuilder)((Object)list3)).append("        ,transactionCurrencyAlpha\r\n");
                if (bl4) {
                    ((StringBuilder)((Object)list3)).append("        ,terminalTmp AS terminal\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        ,'***' AS terminal\r\n");
                }
                if (bl3) {
                    ((StringBuilder)((Object)list3)).append("        ,cashierIDTmp AS cashierID\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        ,'***' AS cashierID\r\n");
                }
                if (bl2) {
                    ((StringBuilder)((Object)list3)).append("        ,storeIdentifierTmp AS storeIdentifier\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        ,'***' AS storeIdentifier\r\n");
                }
                if (bl) {
                    ((StringBuilder)((Object)list3)).append("        ,shiftNumberTmp AS shiftNumber\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        ,'***' AS shiftNumber\r\n");
                }
                if (((YP_TCD_DataBaseConnector)object).sql_Formater instanceof YP_TCG_MYSQL_Formater) {
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , 1, 0)) AS nbDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0)) AS totalAmountDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND','REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND','REFUND_QUASI_CASH') , transactionAmount, 0)) AS totalAmountRefund\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('REVERSAL_DEBIT','REVERSAL_QUASI_CASH') , 1, 0)) AS nbReversalDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('REVERSAL_DEBIT','REVERSAL_QUASI_CASH'), transactionAmount, 0)) AS totalAmountReversalDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType = 'INITIAL_RESERVATION', transactionAmount, 0)) AS totalAmountINITIAL_RESERVATION\r\n");
                } else {
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , 1, 0)) AS nbDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('DEBIT' , 'DEBIT_DIFFERED' , 'QUASI_CASH' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0))");
                    ((StringBuilder)((Object)list3)).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('DEBIT' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'ADVICE_DEBIT') , transactionAmount, 0)) AS Varchar)) AS totalAmountDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , transactionAmount, 0))");
                    ((StringBuilder)((Object)list3)).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , transactionAmount, 0)) AS Varchar)) AS totalAmountRefund\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('REVERSAL_DEBIT', 'REVERSAL_QUASI_CASH') , 1, 0)) AS nbReversalDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('REVERSAL_DEBIT','REVERSAL_QUASI_CASH') , transactionAmount, 0))");
                    ((StringBuilder)((Object)list3)).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType IN ('REVERSAL_DEBIT','REVERSAL_QUASI_CASH') , transactionAmount, 0)) AS Varchar)) AS totalAmountReversalDebit\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
                    ((StringBuilder)((Object)list3)).append("        ,");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionCurrencyAlpha = 'EUR', CONCAT(REPLACE(convert(money, SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType = 'INITIAL_RESERVATION' , transactionAmount, 0))");
                    ((StringBuilder)((Object)list3)).append(", -1)  / 100, '.', ','), ' \u20ac'),CAST(SUM(");
                    ((StringBuilder)((Object)list3)).append(((YP_TCD_DataBaseConnector)object).sql_Formater.sqlIF());
                    ((StringBuilder)((Object)list3)).append("(transactionType = 'INITIAL_RESERVATION' , transactionAmount, 0)) AS Varchar)) AS totalAmountINITIAL_RESERVATION\r\n");
                }
                ((StringBuilder)((Object)list3)).append("FROM\r\n");
                ((StringBuilder)((Object)list3)).append("(\r\n");
                boolean bl7 = true;
                for (List<YP_Row> list22 : list5) {
                    this.appendOneContract(bl7, (StringBuilder)((Object)list3), (YP_TCD_DCC_Business)((Object)list22), string);
                    bl7 = false;
                }
                ((StringBuilder)((Object)list3)).append(") tmp\r\n");
                ((StringBuilder)((Object)list3)).append("GROUP BY ");
                if (bl6) {
                    ((StringBuilder)((Object)list3)).append("dateTmp,");
                }
                ((StringBuilder)((Object)list3)).append("transactionCurrencyAlpha");
                if (bl4) {
                    ((StringBuilder)((Object)list3)).append(", terminalTmp");
                }
                if (bl3) {
                    ((StringBuilder)((Object)list3)).append(", cashierIDTmp");
                }
                if (bl2) {
                    ((StringBuilder)((Object)list3)).append(", storeIdentifierTmp");
                }
                if (bl) {
                    ((StringBuilder)((Object)list3)).append(", shiftNumberTmp");
                }
                if ((list22 = ((YP_TCD_DCC_Business)list5.get((int)0)).transaction.getDataBaseConnector().dealSelect((YP_TCD_DesignAccesObject)((YP_TCD_DCC_Business)list5.get((int)0)).transaction, yP_TCD_DAO_LOC_Table, ((StringBuilder)((Object)list3)).toString())) == null) {
                    this.logger(2, "getView() null list");
                    continue;
                }
                if (list22.isEmpty()) {
                    this.logger(4, "getView() nothing found");
                    continue;
                }
                for (YP_Row yP_Row : list22) {
                    object2.add(yP_Row);
                    yP_Row.setPrimaryKey(object2.size());
                    hashMap.put(yP_Row.getPrimaryKey(), (YP_TCD_DCC_Business)list5.get(0));
                }
            }
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DAO_LOC_Table);
        List<YP_Row> list6 = YP_TCD_DesignAccesObject.getRowListSuchAs((List<YP_Row>)object2, yP_ComplexGabarit);
        if (list6.isEmpty()) {
            if (this.getLogLevel() >= 4) {
                this.logger(4, "getView() nothing found");
            }
            return yP_View;
        }
        int n = 0;
        while (n < list6.size()) {
            YP_Row yP_Row;
            object = list6.get(n);
            list3 = (YP_TCD_DCC_Business)hashMap.get(((YP_Row)object).getPrimaryKey());
            yP_Row = (DAO_Contract)((YP_TCD_DCC_Business)((Object)list3)).getContractRow();
            list22 = ((YP_TCD_DCC_Business)((Object)list3)).getDataContainerMerchant();
            YP_Row yP_Row2 = ((YP_TCD_DCC_Merchant)((Object)list22)).getMerchantRow();
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = ((YP_TCD_DCC_Merchant)((Object)list22)).getDataContainerBrand();
            YP_Row yP_Row3 = yP_TCD_DCC_Brand.getBrandRow();
            YP_Row yP_Row4 = (YP_Row)hashMap2.get(((DAO_Contract)yP_Row).idApplication);
            yP_View.setRowID(n, String.valueOf(((YP_Row)object).getFather().getFullTableName()) + "#" + ((YP_Row)object).getPrimaryKeyName() + "#" + ((YP_Row)object).getPrimaryKey());
            yP_View.setRowActionable(n, false);
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string2 = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Cloneable cloneable = null;
                Field field = yP_TCD_DAO_LOC_Table.getFieldByName(string2);
                if (field != null) {
                    cloneable = object;
                } else {
                    field = this.dataContainerTechnique.contract.getFieldByName(string2);
                    if (field != null) {
                        cloneable = yP_Row;
                    } else {
                        field = this.dataContainerTechnique.merchant.getFieldByName(string2);
                        if (field != null) {
                            cloneable = yP_Row2;
                        } else {
                            field = this.dataContainerTechnique.brand.getFieldByName(string2);
                            if (field != null) {
                                cloneable = yP_Row3;
                            } else {
                                field = this.dataContainerTechnique.application.getFieldByName(string2);
                                if (field != null) {
                                    cloneable = yP_Row4;
                                }
                            }
                        }
                    }
                }
                if (field != null && cloneable != null) {
                    if (!(cloneable != yP_Row && cloneable != yP_Row4 || bl5)) {
                        yP_View.addFieldValue(n, string2, "***");
                        continue;
                    }
                    this.addFieldValue(yP_View, field, (YP_Row)cloneable, string2, n);
                    continue;
                }
                if (string2.contentEquals("storeLabel")) {
                    String string3 = ((YP_Row)object).getFieldStringValueByName("storeIdentifier");
                    if (string3 == null || string3.isEmpty() || string3.contentEquals("0")) {
                        yP_View.addFieldValue(n, string2, "");
                        continue;
                    }
                    if (string3.contentEquals("***")) {
                        yP_View.addFieldValue(n, string2, "***");
                        continue;
                    }
                    yP_View.addFieldValue(n, string2, yP_TCD_DCC_Brand.getStoreLabel(((YP_TCD_DCC_Merchant)((Object)list22)).getIDMerchant(), string3));
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string2);
            }
            ++n;
        }
        return yP_View;
    }

    private void appendOneContract(boolean bl, StringBuilder stringBuilder, YP_TCD_DCC_Business yP_TCD_DCC_Business, String string) {
        String string2 = yP_TCD_DCC_Business.transaction.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DCC_Business.transaction);
        if (!bl) {
            stringBuilder.append("          UNION ALL\r\n");
        }
        stringBuilder.append("          SELECT\r\n");
        stringBuilder.append("              ");
        stringBuilder.append(yP_TCD_DCC_Business.getDataBaseConnector().sql_Formater.sqlDate("transactionAppliLocalTime"));
        stringBuilder.append(" AS dateTmp\r\n");
        stringBuilder.append("              ,transactionType\r\n");
        stringBuilder.append("              ,transactionAmount\r\n");
        stringBuilder.append("              ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("              ,nlpa AS terminalTmp\r\n");
        stringBuilder.append("              ,cashierID AS cashierIDTmp\r\n");
        stringBuilder.append("              ,storeIdentifier AS storeIdentifierTmp\r\n");
        stringBuilder.append("              ,shiftNumber AS shiftNumberTmp\r\n");
        stringBuilder.append("              FROM " + yP_TCD_DCC_Business.transaction.getFullTableName() + "\r\n");
        stringBuilder.append("              WHERE transactionStatus ='ACCEPTED'\r\n");
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append("              AND" + string2 + "\r\n");
        }
        stringBuilder.append(string);
        stringBuilder.append("          UNION ALL\r\n");
        stringBuilder.append("          SELECT\r\n");
        stringBuilder.append("              ");
        stringBuilder.append(yP_TCD_DCC_Business.getDataBaseConnector().sql_Formater.sqlDate("transactionAppliLocalTime"));
        stringBuilder.append(" AS dateTmp\r\n");
        stringBuilder.append("              ,transactionType\r\n");
        stringBuilder.append("              ,transactionAmount\r\n");
        stringBuilder.append("              ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("              ,nlpa AS terminalTMP\r\n");
        stringBuilder.append("              ,cashierID AS cashierIDTmp\r\n");
        stringBuilder.append("              ,storeIdentifier AS storeIdentifierTmp\r\n");
        stringBuilder.append("              ,shiftNumber AS shiftNumberTmp\r\n");
        stringBuilder.append("              FROM " + yP_TCD_DCC_Business.transactionArchive.getFullTableName() + "\r\n");
        stringBuilder.append("              WHERE transactionStatus ='ACCEPTED'\r\n");
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append("              AND" + string2 + "\r\n");
        }
        stringBuilder.append(string);
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        this.logger(2, "createInView() Not yet done");
        return 0;
    }
}

