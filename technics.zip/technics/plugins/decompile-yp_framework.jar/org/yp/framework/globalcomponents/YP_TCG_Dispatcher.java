/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.dispatcher.YP_TCD_DCC_Interface_Dispatcher;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_Dispatcher
extends YP_GlobalComponent {
    YP_TCD_DCC_Interface_Dispatcher extensionDispatcher;

    public YP_TCG_Dispatcher(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() no DCC_Technique...");
            }
            return -1;
        }
        this.extensionDispatcher = (YP_TCD_DCC_Interface_Dispatcher)((Object)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtensionSTD_Dispatcher", new Object[0]));
        this.extensionDispatcher.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "Dispatcher_OLD";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "getDispatchRow": {
                    if (yP_Object instanceof YP_Transaction && objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.getDispatchRow((YP_Transaction)yP_Object, (String)objectArray[0]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameters for getDispatchRow");
                    }
                    return null;
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }

    private YP_Row getDispatchRow(YP_Transaction yP_Transaction, String string) {
        return this.extensionDispatcher.getDispatchRow(yP_Transaction, string);
    }
}

