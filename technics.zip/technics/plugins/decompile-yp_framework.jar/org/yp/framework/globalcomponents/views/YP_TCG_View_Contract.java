/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.designaccesobjects.technic.DAO_Contract;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.InitializationStatusEnumeration;

public class YP_TCG_View_Contract
extends YP_TCG_View {
    private YP_TS_DataContainerManager dataContainerManager;
    private YP_TCD_DCC_Technique dataContainerTechnique;
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR;

    public YP_TCG_View_Contract(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Contract";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = this.dataContainerTechnique.contract.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject = this.dataContainerTechnique.contract;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject = this.dataContainerTechnique.brand;
                    } else {
                        field = this.dataContainerTechnique.application.getFieldByName(string);
                        if (field != null) {
                            yP_TCD_DesignAccesObject = this.dataContainerTechnique.application;
                        } else {
                            yP_TCD_DesignAccesObject = null;
                            if (string.contentEquals("contractIdentifier") || string.contentEquals("storeIdentifier") || string.contentEquals("storeLabel") || string.contentEquals("hostMerchantName") || string.contentEquals("hostMerchantContract") || string.contentEquals("hostAcquirerIdentifier")) {
                                yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                            } else {
                                if (this.getLogLevel() < 2) continue;
                                this.logger(2, "createEmptyView() unknown column:" + string);
                                continue;
                            }
                        }
                    }
                }
            }
            if (yP_TCD_DesignAccesObject != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        block91: {
            block90: {
                var6_5 = this.createEmptyView(var1_1, var2_2, var3_3, var5_4);
                if (var6_5 == null) {
                    if (this.getLogLevel() < 2) return null;
                    this.logger(2, "getView() ");
                    return null;
                }
                var7_6 = var2_2.getDataContainerTransaction().getProtocolEFT();
                if (var7_6 == null) {
                    if (this.getLogLevel() < 2) return null;
                    this.logger(2, "getView() No protocol...");
                    return null;
                }
                if (!(var7_6 instanceof YP_PROT_IHM)) {
                    if (this.getLogLevel() < 2) return null;
                    this.logger(2, "getView() bad interface");
                    return null;
                }
                var8_7 = (YP_PROT_IHM)var7_6;
                var9_8 = var8_7.getMaxRecords();
                if (var9_8 == 0) {
                    return var6_5;
                }
                if (var9_8 < 0) {
                    var9_8 = 50000;
                }
                ++var9_8;
                var10_9 = var8_7.getStartIndex();
                if (var10_9 < 0) {
                    var10_9 = 0;
                } else {
                    var9_8 += var10_9;
                }
                var11_10 = 0L;
                var14_11 = var8_7.getSearchGabarit();
                if (var14_11 == null || var14_11.isEmpty()) break block90;
                var13_12 = new YP_ComplexGabarit(this.dataContainerTechnique.contract);
                var15_13 = var14_11.size() - 1;
                if (true) ** GOTO lbl209
            }
            var13_12 = null;
            break block91;
            do {
                block89: {
                    var16_15 = var14_11.get(var15_13);
                    if (var16_15.fieldName.contentEquals("idContract") && var16_15.objectTosearch != null && var16_15.objectTosearch instanceof Long && var16_15.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                        var11_10 = (Long)var16_15.objectTosearch;
                    }
                    try {
                        var17_16 = var16_15.fieldName;
                        tmp = -1;
                        switch (var17_16.hashCode()) {
                            case -1247425541: {
                                if (!var17_16.equals("applicationName")) break;
                                tmp = 1;
                                break;
                            }
                            case -787472718: {
                                if (!var17_16.equals("brandName")) break;
                                tmp = 2;
                                break;
                            }
                            case 620532851: {
                                if (!var17_16.equals("merchantName")) break;
                                tmp = 3;
                                break;
                            }
                        }
                        switch (tmp) {
                            case 2: {
                                switch (YP_TCG_View_Contract.$SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR()[var16_15.operator.ordinal()]) {
                                    case 1: 
                                    case 17: {
                                        break;
                                    }
                                    default: {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() operator not allowed on brandName");
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return null;
                                    }
                                }
                                if (!(var16_15.objectTosearch instanceof String)) {
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "getView() brandValue must be an array");
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return null;
                                }
                                var18_19 = (String)var16_15.objectTosearch;
                                var19_24 = false;
                                for (YP_TCD_DCC_Brand var20_29 : var2_2.getDataContainerTransaction().contextHandler.brandContainers) {
                                    if (!var20_29.getBrandName().contentEquals(var18_19)) continue;
                                    var22_38 = new ArrayList<E>();
                                    var24_51 = var20_29.dataContainerMerchantList.iterator();
                                    while (true) {
                                        if (var24_51.hasNext()) ** GOTO lbl89
                                        var23_42 = null;
                                        if (var16_15.operator != YP_ComplexGabarit.OPERATOR.EQUAL) break;
                                        var23_43 = new YP_Gabarit("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)var22_38.toArray());
                                        ** GOTO lbl94
lbl89:
                                        // 1 sources

                                        var23_41 = var24_51.next();
                                        var22_38.add(var23_41.getIDMerchant());
                                    }
                                    var23_44 = new YP_Gabarit("idMerchant", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, (Object)var22_38.toArray());
lbl94:
                                    // 2 sources

                                    var14_11.remove(var15_13);
                                    var14_11.add((YP_Gabarit)var23_45);
                                    var16_15 = var23_45;
                                    var19_24 = true;
                                    break;
                                }
                                if (var19_24) break;
                                for (YP_Gabarit var20_30 : var14_11) {
                                    if (!var20_30.fieldName.contentEquals("merchantName") && !var20_30.fieldName.contentEquals("idMerchant")) continue;
                                    var19_24 = true;
                                    break;
                                }
                                if (!var19_24) {
                                    var20_31 = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", new Object[]{var18_19});
                                    if (var20_31 != null) {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() No right to access this brand:" + var18_19);
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                        return null;
                                    }
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "getView() Brand does not exist:" + var18_19);
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return null;
                                }
                                break block89;
                            }
                            case 3: {
                                switch (YP_TCG_View_Contract.$SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR()[var16_15.operator.ordinal()]) {
                                    case 1: 
                                    case 17: {
                                        break;
                                    }
                                    default: {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() operator not allowed on merchantName");
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return null;
                                    }
                                }
                                if (!(var16_15.objectTosearch instanceof String)) {
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "getView() merchantValue must be an  array");
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return null;
                                }
                                var20_32 = (String)var16_15.objectTosearch;
                                var21_37 = new ArrayList<E>();
                                var23_46 = var2_2.getDataContainerTransaction().contextHandler.merchantContainers.iterator();
                                while (true) {
                                    if (!var23_46.hasNext()) {
                                        if (!var21_37.isEmpty()) break;
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() merchantValue not found in accesslist");
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                        return null;
                                    }
                                    var22_38 = var23_46.next();
                                    if (!var22_38.getMerchantName().contentEquals(var20_32)) continue;
                                    var21_37.add((YP_Gabarit)Long.valueOf(var22_38.getIDMerchant()));
                                }
                                var22_38 = null;
                                var22_38 = var16_15.operator == YP_ComplexGabarit.OPERATOR.EQUAL ? new YP_Gabarit("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)var21_37.toArray()) : new YP_Gabarit("idMerchant", YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP, (Object)var21_37.toArray());
                                var14_11.remove(var15_13);
                                var14_11.add((YP_Gabarit)var22_38);
                                var16_15 = var22_38;
                                break;
                            }
                            case 1: {
                                switch (YP_TCG_View_Contract.$SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR()[var16_15.operator.ordinal()]) {
                                    case 1: 
                                    case 4: 
                                    case 17: 
                                    case 18: {
                                        break;
                                    }
                                    default: {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "getView() operator not allowed on applicationName");
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return null;
                                    }
                                }
                                if (!(var16_15.objectTosearch instanceof String)) {
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "getView() applicationValue must be an array");
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return null;
                                }
                                var23_47 = (String)var16_15.objectTosearch;
                                var19_24 = false;
                                for (YP_TCD_DCC_Business var24_52 : var2_2.getDataContainerTransaction().contextHandler.businessContainers) {
                                    var26_64 = var24_52.getApplicationPlugin().getApplicationRow();
                                    if (!var26_64.getFieldStringValueByName("applicationName").contentEquals(var23_47)) continue;
                                    var22_38 = new YP_Gabarit("idApplication", var16_15.operator, (Object)var26_64.getPrimaryKey());
                                    var14_11.remove(var15_13);
                                    var14_11.add((YP_Gabarit)var22_38);
                                    var16_15 = var22_38;
                                    var19_24 = true;
                                    break;
                                }
                                if (var19_24) break;
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "getView() applicationValue not found in accesslist");
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                return null;
                            }
                        }
                        if (var16_15.objectTosearch == null) {
                            var13_12.set(var16_15.fieldName, var16_15.operator);
                            break block89;
                        }
                        var6_5.dealEnumColumn((YP_Gabarit)var16_15);
                        if (var16_15.objectTosearch != null) {
                            var13_12.set(var16_15.fieldName, var16_15.operator, var16_15.objectTosearch);
                        }
                    }
                    catch (Exception var17_17) {
                        this.logger(2, "getView() ", var17_17);
                    }
                }
                --var15_13;
lbl209:
                // 2 sources

            } while (var15_13 >= 0);
        }
        var15_14 = new HashMap<Long, Object>();
        var16_15 = new ArrayList<E>();
        if (var11_10 > 0L) {
            var17_16 = (YP_TCD_DCC_Business)this.dataContainerManager.dealRequest(this, "getDataContainerBusiness", new Object[]{var11_10});
            if (var17_16 == null) {
                this.logger(2, "getView() null list");
                return var6_5;
            }
            var16_15.add(var17_16.getContractRow());
            var15_14.put(var11_10, var17_16);
        } else {
            var17_16 = var2_2.getApplicationList();
            if (var17_16 == null) {
                this.logger(2, "getView() no application List");
                return null;
            }
            if (var17_16.isEmpty()) {
                this.logger(3, "getView() application List empty");
                return var6_5;
            }
            for (YP_TCD_DCC_Business var18_21 : var17_16) {
                var20_34 = (DAO_Contract)var18_21.getContractRow();
                var16_15.add((YP_Row)var20_34);
                var15_14.put(var20_34.getPrimaryKey(), var18_21);
            }
            if ((var16_15 = YP_TCD_DesignAccesObject.getRowListSuchAs((List<YP_Row>)var16_15, new YP_ComplexGabarit[]{var13_12})) == null) {
                this.logger(2, "getView() null list");
                return null;
            }
            if (var16_15.isEmpty()) {
                this.logger(4, "getView() nothing found");
                return var6_5;
            }
        }
        var17_18 = 0;
        while (var17_18 < var16_15.size()) {
            if (var10_9 == 0 && var17_18 > var9_8) {
                return var6_5;
            }
            var18_23 = (DAO_Contract)var16_15.get(var17_18);
            var19_27 = (YP_TCD_DCC_Business)var15_14.get(var18_23.getPrimaryKey());
            var20_36 = var19_27.getDataContainerMerchant();
            var21_37 = var20_36.getMerchantRow();
            var22_38 = var20_36.getDataContainerBrand();
            var23_49 = var22_38.getBrandRow();
            var6_5.setRowID(var17_18, String.valueOf(var18_23.getFather().getFullTableName()) + "#" + var18_23.getPrimaryKeyName() + "#" + var18_23.getPrimaryKey());
            var6_5.setRowActionable(var17_18, true);
            if (var16_15.size() == 1) {
                var24_54 = var19_27.getActionList(this.toString(), var18_23);
                var25_62 = var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel();
                if (var25_62 == 1 || var25_62 == 2) {
                    if (var24_54 == null) {
                        var24_55 = new ArrayList<E>();
                    }
                    var26_64 = new YP_TCD_DC_Context.Action();
                    var26_64.applicationIdentifier = var2_2.getDataContainerTransaction().getContractIdentifier();
                    var26_64.formName = "ContractForm";
                    var26_64.id = "MODIFY_CONTRACT";
                    var26_64.label = this.getLabel("MODIFY_CONTRACT");
                    var24_56.add(var26_64);
                    this.addSupressContract(var2_2, var19_27, (List<YP_TCD_DC_Context.Action>)var24_56, var25_62);
                }
                if (!UtilsYP.isSATIMServer() && (var19_27.getContainerBusinessType() & 1) == 0) {
                    if (var24_56 == null) {
                        var24_57 = new ArrayList<E>();
                    }
                    var26_64 = new YP_TCD_DC_Context.Action();
                    var26_64.applicationIdentifier = var19_27.getContractIdentifier();
                    var26_64.formName = "StandardNoConfirmationForm";
                    var26_64.id = "ADDITIONAL_REPORT";
                    var26_64.label = this.getLabel("ADDITIONAL_REPORT");
                    var24_58.add(var26_64);
                }
                if (var24_58 != null) {
                    var6_5.setRowActionList(var17_18, (List<YP_TCD_DC_Context.Action>)var24_58);
                }
            }
            var24_60 = var22_38.getIdStoreListByContract(var18_23.getPrimaryKey());
            for (DAO_ViewColumn var25_63 : var5_4) {
                var27_65 = YP_Row.getStringValue(var25_63.columnName);
                var28_66 = this.dataContainerTechnique.contract.getFieldByName(var27_65);
                var29_67 = null;
                if (var28_66 != null) {
                    var29_67 = var18_23;
                } else {
                    var28_66 = this.dataContainerTechnique.merchant.getFieldByName(var27_65);
                    if (var28_66 != null) {
                        var29_67 = var21_37;
                    } else {
                        var28_66 = this.dataContainerTechnique.brand.getFieldByName(var27_65);
                        if (var28_66 != null) {
                            var29_67 = var23_49;
                        } else {
                            var28_66 = this.dataContainerTechnique.application.getFieldByName(var27_65);
                            if (var28_66 != null) {
                                var29_67 = var19_27.getApplicationPlugin().getApplicationRow();
                            }
                        }
                    }
                }
                if (var28_66 != null && var29_67 != null) {
                    this.addFieldValue(var6_5, var28_66, (YP_Row)var29_67, var27_65, var17_18);
                    continue;
                }
                if (var27_65.contentEquals("contractIdentifier")) {
                    var6_5.addFieldValue(var17_18, var27_65, var19_27.getContractIdentifier());
                    continue;
                }
                if (var27_65.contentEquals("hostMerchantName")) {
                    var30_68 = var19_27.getMerchantName();
                    if (var30_68.indexOf(26) > 0) {
                        var6_5.addFieldValue(var17_18, var27_65, var30_68.replace('\u001a', ' '));
                        continue;
                    }
                    var6_5.addFieldValue(var17_18, var27_65, (String)var30_68);
                    continue;
                }
                if (var27_65.contentEquals("hostMerchantContract")) {
                    var6_5.addFieldValue(var17_18, var27_65, var19_27.getMerchantContract());
                    continue;
                }
                if (var27_65.contentEquals("hostAcquirerIdentifier")) {
                    var30_68 = var19_27.getAcquiringInstitutionIdentificationCode();
                    if (var30_68 == null) {
                        var30_68 = "";
                    } else if (var30_68.length() > 5) {
                        var30_68 = var30_68.substring(var30_68.length() - 5);
                    }
                    var6_5.addFieldValue(var17_18, var27_65, (String)var30_68);
                    continue;
                }
                if (var27_65.contentEquals("storeIdentifier") || var27_65.contentEquals("storeLabel")) {
                    if (var24_60 == null || var24_60.isEmpty()) continue;
                    if (var24_60.size() > 1) {
                        var6_5.addFieldValue(var17_18, var27_65, "########");
                        continue;
                    }
                    var30_68 = var22_38.getStore(var24_60.get(0));
                    if (var27_65.contentEquals("storeIdentifier")) {
                        var6_5.addFieldValue(var17_18, var27_65, var22_38.getStoreIdentifier((YP_Row)var30_68));
                    }
                    if (!var27_65.contentEquals("storeLabel")) continue;
                    var6_5.addFieldValue(var17_18, var27_65, var22_38.getStoreLabel((YP_Row)var30_68));
                    continue;
                }
                if (this.getLogLevel() < 2) continue;
                this.logger(2, "getView() unknown column:" + var27_65);
            }
            ++var17_18;
        }
        return var6_5;
    }

    private void addSupressContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, List<YP_TCD_DC_Context.Action> list, int n) {
        if (n != 1) {
            return;
        }
        if (!this.isRemovableContract(yP_TCD_DCC_Business, n)) {
            return;
        }
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.applicationIdentifier = yP_TCD_DCC_Business.getContractIdentifier();
        action.formName = "StandardConfirmationForm";
        action.id = "REMOVE_CONTRACT";
        action.label = this.getLabel("REMOVE_CONTRACT");
        list.add(action);
    }

    private int removeContract(YP_Transaction yP_Transaction, List<?> list) {
        YP_TCD_DCC_Business yP_TCD_DCC_Business;
        block7: {
            block6: {
                block5: {
                    try {
                        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1) break block5;
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "removeContract() No rights parameters");
                        return -1;
                    }
                    catch (Exception exception) {
                        this.logger(2, "removeContract() unknown column:", exception);
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                        return -1;
                    }
                }
                if (list != null && list.size() <= 1) break block6;
                this.logger(2, "removeContract() bad parameters");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list.get(0);
            if (this.isRemovableContract(yP_TCD_DCC_Business, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) break block7;
            this.logger(2, "removeContract() contract not removable");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            return -1;
        }
        yP_TCD_DCC_Business.setInitializationStatus(InitializationStatusEnumeration.DELETED);
        YP_Row yP_Row = yP_TCD_DCC_Business.getContractRow();
        yP_Row.persist();
        this.getPluginByName("Scheduler").dealRequest(this, "deleteCron", yP_TCD_DCC_Business.getContractIdentifier(), "", "");
        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(8));
        return 1;
    }

    private boolean isRemovableContract(YP_TCD_DCC_Business yP_TCD_DCC_Business, int n) {
        if (n != 1 && n != 2) {
            return false;
        }
        if (yP_TCD_DCC_Business.getInitializationStatus() == InitializationStatusEnumeration.INITIALISED) {
            return false;
        }
        if (yP_TCD_DCC_Business.transaction != null && yP_TCD_DCC_Business.transaction.size() > 0) {
            return false;
        }
        return n == 1 || (yP_TCD_DCC_Business.getContainerBusinessType() & 1) == 0;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.contract;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        List list = (List)this.dataContainerManager.dealRequest(this, "getDataContainerList", yP_Transaction, action.applicationIdentifier, "");
        if (list == null || list.isEmpty()) {
            return -1;
        }
        if (yP_Transaction == null) {
            this.logger(2, "executeAction() YP_Transaction is null");
            return -1;
        }
        switch (action.id) {
            case "REMOVE_CONTRACT": {
                return this.removeContract(yP_Transaction, list);
            }
            case "ADDITIONAL_REPORT": {
                return this.additionalReport(yP_Transaction, list);
            }
            case "Closure": 
            case "Reconciliation": 
            case "RemoteParameterization": 
            case "Deactivation": {
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break;
                this.logger(2, "executeAction() action not allowed");
                YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(102);
                return -1;
            }
        }
        return ((YP_TCD_DCC_Business)list.get(0)).executeAction(yP_Transaction, this.toString(), yP_Row, action);
    }

    @Override
    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        if (!string.contentEquals("activationCode")) {
            return 1;
        }
        if (!string2.contentEquals("0")) {
            return 1;
        }
        long l = yP_Row.getPrimaryKey();
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers) {
            if (yP_TCD_DCC_Business.getIDContract() != l) continue;
            yP_Row.set("initializationStatus", InitializationStatusEnumeration.NOT_INITIALISED);
            YP_Object yP_Object = this.getPluginByName("Scheduler");
            if (yP_Object == null) break;
            try {
                yP_Object.dealRequest(this, "deleteCron", yP_TCD_DCC_Business.getContractIdentifier(), "", "");
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "checkModification() ", exception);
                break;
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                int n2;
                boolean bl;
                Object object;
                Object object2;
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Key must not be set !");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() not really possible !!!");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                String string2 = null;
                String string3 = null;
                String string4 = null;
                String string5 = null;
                boolean bl2 = false;
                block32: for (String string6 : yP_View.getColumnSet()) {
                    object2 = yP_View.getFieldValueAt(n, string6);
                    if (object2 == null) continue;
                    switch (string6) {
                        case "idContract": {
                            if (((String)object2).isEmpty()) continue block32;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() Key should be empty :" + string6);
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "brandName": {
                            string2 = object2;
                            break;
                        }
                        case "merchantName": {
                            string3 = object2;
                            break;
                        }
                        case "applicationName": {
                            string4 = object2;
                            break;
                        }
                        case "storeIdentifier": {
                            string5 = object2;
                            break;
                        }
                        case "contractLabel": {
                            yP_Row.set(string6, (String)object2);
                            break;
                        }
                        case "timeZone": {
                            yP_Row.set(string6, (String)object2);
                            bl2 = true;
                            break;
                        }
                        case "satisfactionIndex": 
                        case "activationCode": 
                        case "connectorType": 
                        case "applicationIndex": 
                        case "initializationStatus": 
                        case "storeLabel": 
                        case "brandLabel": 
                        case "merchantLabel": {
                            if (((String)object2).isEmpty() || this.getLogLevel() < 2) continue block32;
                            this.logger(2, "createInView() field ignored :" + string6);
                            break;
                        }
                        default: {
                            if (this.getLogLevel() < 2) continue block32;
                            this.logger(2, "createInView() unknown field :" + string6);
                        }
                    }
                }
                yP_Row.set("activationCode", "0");
                yP_Row.set("initializationStatus", InitializationStatusEnumeration.EMPTY);
                if (string2 == null || string2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:brandName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string3 == null || string3.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:merchantName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (string3.indexOf(95) != -1) {
                    String[] stringArray = string3.split("_");
                    if (stringArray.length == 2 && stringArray[0].contentEquals(string2)) {
                        string3 = stringArray[1];
                    } else {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() bad value for merchantName:" + string3);
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                        return -1;
                    }
                }
                boolean bl3 = false;
                for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers) {
                    yP_Row.set("connectorType", (Integer)yP_TCD_DCC_Brand.getBrandRow().getFieldValueByName("connectorType"));
                    if (!yP_TCD_DCC_Brand.getContractIdentifier().contentEquals(string2)) continue;
                    object = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", String.valueOf(string2) + '_' + string3);
                    if (object == null) break;
                    bl = true;
                    yP_Row.set("idMerchant", ((YP_TCD_DCC_Merchant)object).getIDMerchant());
                    if (bl2) break;
                    yP_Row.set("timeZone", ((YP_TCD_DCC_Merchant)object).getMerchantRow().getFieldStringValueByName("timeZone"));
                    break;
                }
                if (!bl) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() unable to find merchant in accessList:" + string2 + " " + string3);
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
                if (string4 == null || string4.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing:applicationName");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.application);
                yP_ComplexGabarit.set("applicationName", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
                object2 = this.dataContainerTechnique.application.getRowListSuchAs(yP_ComplexGabarit);
                if (object2 == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() unable to get list for " + string4);
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (object2.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() applicationName not found:" + string4);
                    }
                    return -1;
                }
                if (object2.size() > 1 && this.getLogLevel() >= 2) {
                    this.logger(2, "createInView() too many found for" + string4);
                }
                object = object2.get(0);
                yP_Row.set("idApplication", ((YP_Row)object).getPrimaryKey());
                try {
                    n2 = (Integer)((YP_Row)object).getFieldValueByName("satisfactionIndex");
                    if (n2 <= 0) {
                        n2 = 1;
                    }
                }
                catch (Exception exception) {
                    n2 = 1;
                }
                yP_Row.set("satisfactionIndex", n2);
                int n3 = 1;
                YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit2.set("applicationIndex", YP_ComplexGabarit.OPERATOR.MAX);
                yP_ComplexGabarit2.set("idApplication", YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row.getFieldValueByName("idApplication"));
                yP_ComplexGabarit2.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, (Long)yP_Row.getFieldValueByName("idMerchant"));
                object2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit2);
                if (object2 == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() unable to get list for " + string3);
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                    return -1;
                }
                if (!object2.isEmpty()) {
                    n3 = (Integer)object2.get(0).getFieldValueByName("applicationIndex") + 1;
                }
                yP_Row.set("applicationIndex", n3);
                if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) < 0) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Not able to add row...");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (yP_TCD_DesignAccesObject.persist() < 0) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Not able to save changes...");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_TCD_DCC_Business yP_TCD_DCC_Business = this.dataContainerTechnique.loadContractByPrimaryKey(yP_Row.getPrimaryKey());
                yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers.add(yP_TCD_DCC_Business);
                this.getPluginByName("User").dealRequest(this, "updateUserAccesContext", yP_Transaction.getDataContainerTransaction().userHandler.getUserUID());
                if (string5 != null) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "createInView() A store has been provided.");
                    }
                    if (string5.indexOf(95) != -1) {
                        String[] stringArray = string5.split("_");
                        if (stringArray.length == 3 && stringArray[0].contentEquals(string2) && stringArray[1].contentEquals(string3)) {
                            string5 = stringArray[2];
                        } else if (stringArray.length == 3 && stringArray[0].contentEquals(UtilsYP.cryptInfo(string2)) && stringArray[1].contentEquals(UtilsYP.cryptInfo(string3))) {
                            string5 = stringArray[2];
                        } else {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() bad value for storeIdentifier:" + string5);
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                    }
                    yP_TCD_DCC_Business.getDataContainerBrand().addContractInsideSore(yP_TCD_DCC_Business.getDataContainerMerchant().getIDMerchant(), string5, yP_Row.getPrimaryKey());
                }
                yP_Transaction.setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
                yP_Transaction.getDataContainerTransaction().setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() ", exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    private int additionalReport(YP_Transaction yP_Transaction, List<?> list) {
        block5: {
            block4: {
                try {
                    if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break block4;
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    this.logger(2, "additionalReport() No rights");
                    return -1;
                }
                catch (Exception exception) {
                    this.logger(2, "additionalReport() ", exception);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
            }
            if (list != null && list.size() <= 1) break block5;
            this.logger(2, "additionalReport() bad parameters");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
            return -1;
        }
        YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)list.get(0);
        yP_Transaction.getDataContainerTransaction().setRequestType(YP_TCD_PosProtocol.REQUEST_TYPE.Report);
        yP_Transaction.getDataContainerTransaction().setSubRequestType(YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AdditionalReport);
        YP_Application yP_Application = yP_TCD_DCC_Business.newApplicationPlugin(yP_Transaction);
        yP_Transaction.getDataContainerTransaction().setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
        yP_Application.setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
        yP_Application.initialize();
        yP_Application.dealRequest(yP_Transaction, "dealTransaction", null);
        yP_Application.shutdown();
        return 1;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR() {
        if ($SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR != null) {
            return $SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR;
        }
        int[] nArray = new int[YP_ComplexGabarit.OPERATOR.values().length];
        try {
            nArray[YP_ComplexGabarit.OPERATOR.CONTAIN.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.DIFFERENT.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.DIFFERENT_AFTER_GROUP.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.EQUAL.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.EQUAL_AFTER_GROUP.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.EQUAL_IGNORE_CASE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.GREATER.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.GROUP.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.IN.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.IN_SQL.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.LESS.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.LESS_AFTER_GROUP.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.LESS_OR_EQUAL.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.LIKE.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.MAX.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.MIN.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.ORDER_ASC.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.ORDER_DESC.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_ComplexGabarit.OPERATOR.START_WITH.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$designaccesobjects$YP_ComplexGabarit$OPERATOR = nArray;
        return nArray;
    }
}

