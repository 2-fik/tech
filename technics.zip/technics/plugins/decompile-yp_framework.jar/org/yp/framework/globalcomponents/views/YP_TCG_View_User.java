/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.YP_TCG_Mailer;
import org.yp.framework.globalcomponents.authentifiers.YP_Authentifiers;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.UserStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_User
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;
    public static final String FIRST_NAME_AND_LAST_NAME_PATTERN = "^[0-9a-zA-Z\u00e0\u00e1\u00e2\u00e4\u00e3\u00e5\u0105\u010d\u0107\u0119\u00e8\u00e9\u00ea\u00eb\u0117\u012f\u00ec\u00ed\u00ee\u00ef\u0142\u0144\u00f2\u00f3\u00f4\u00f6\u00f5\u00f8\u00f9\u00fa\u00fb\u00fc\u0173\u016b\u00ff\u00fd\u017c\u017a\u00f1\u00e7\u010d\u0161\u017e\u00c0\u00c1\u00c2\u00c4\u00c3\u00c5\u0104\u0106\u010c\u0116\u0118\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u012e\u0141\u0143\u00d2\u00d3\u00d4\u00d6\u00d5\u00d8\u00d9\u00da\u00db\u00dc\u0172\u016a\u0178\u00dd\u017b\u0179\u00d1\u00df\u00c7\u0152\u00c6\u010c\u0160\u017d\u2202\u00f0 ,.'-]{2,20}$";
    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    public static final String LOGIN_PATTERN = "^[A-Za-z0-9-@_\\.]{1,64}$";
    public static final String PHONE_PATTERN = "^(?:[+][0-9]{2}\\s?[0-9]{3}[-]?[0-9]{3,}|(?:[(][0-9]{3}[)]|[0-9]{3})\\s*[-]?\\s*[0-9]{3}[-][0-9]{4})(?:\\s*x\\s*[0-9]+)?|\\d{10}";
    public static final Map<Long, YP_Row> userFinder = new ConcurrentHashMap<Long, YP_Row>();

    public YP_TCG_View_User(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_User";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "createEmptyView() error while retrieving User DAO");
            return null;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
            } else if (string.contentEquals("password")) {
                yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                yP_TCD_DesignAccesObject2 = null;
            } else if (string.contentEquals("restrictedForMaintenance")) {
                yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                yP_TCD_DesignAccesObject2 = null;
            } else {
                this.logger(2, "createEmptyView() unknown column:" + string);
                continue;
            }
            if (yP_TCD_DesignAccesObject2 != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        void var18_22;
        Object object;
        Object object2;
        Object object3;
        List<Object> list2;
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            this.logger(2, "getView() ");
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            this.logger(2, "getView() No protocol...");
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            this.logger(2, "getView() bad interface");
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        List<YP_Gabarit> list4 = yP_PROT_IHM.getSearchGabarit();
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("User");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("UserParameters");
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        long l2 = 0L;
        if (list4 != null && !list4.isEmpty()) {
            for (YP_Gabarit list32 : list4) {
                try {
                    if (list32.fieldName.contentEquals("pkUser") && list32.objectTosearch != null && list32.objectTosearch instanceof Long && list32.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                        l2 = (Long)list32.objectTosearch;
                    }
                    if (list32.objectTosearch == null) {
                        yP_ComplexGabarit.set(list32.fieldName, list32.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(list32);
                    if (list32.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(list32.fieldName, list32.operator, list32.objectTosearch);
                }
                catch (Exception exception) {
                    this.logger(2, "getView() ", exception);
                }
            }
        }
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.GROUP);
        yP_ComplexGabarit.set("lastGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        if (l2 > 0L) {
            List<YP_Row> list3 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        } else if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 && yP_Transaction.getContractIdentifier().contentEquals("KERNEL")) {
            List<YP_Row> list5 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        } else {
            Object object4;
            Object object5;
            list2 = null;
            object3 = null;
            object2 = new ArrayList();
            List<YP_TCD_DCC_Brand> list6 = yP_Transaction.getBrandList(true);
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list6) {
                object2.add(Long.toString(yP_TCD_DCC_Brand.getIDBrand()));
            }
            if (!yP_Transaction.getContractIdentifier().contains("_")) {
                ArrayList<String> arrayList = new ArrayList<String>();
                for (YP_TCD_DCC_Group yP_TCD_DCC_Group : yP_Transaction.getGroupList()) {
                    arrayList.add(Long.toString(yP_TCD_DCC_Group.getIDGroup()));
                }
                list2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
                ((YP_ComplexGabarit)((Object)list2)).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "groupAccess");
                if (!arrayList.isEmpty()) {
                    ((YP_ComplexGabarit)((Object)list2)).set("value", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
                } else {
                    ((YP_ComplexGabarit)((Object)list2)).set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
                }
                object3 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
                ((YP_ComplexGabarit)object3).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "brandAccess");
                if (!object2.isEmpty()) {
                    ((YP_ComplexGabarit)object3).set("value", YP_ComplexGabarit.OPERATOR.IN, object2);
                } else {
                    ((YP_ComplexGabarit)object3).set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
                }
            }
            ArrayList<String> arrayList = new ArrayList<String>();
            List<YP_TCD_DCC_Merchant> list7 = yP_Transaction.getMerchantList();
            for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : list7) {
                arrayList.add(Long.toString(yP_TCD_DCC_Merchant.getIDMerchant()));
            }
            YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
            yP_ComplexGabarit2.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
            if (!arrayList.isEmpty()) {
                if (arrayList.size() > 1000 && list2 != null) {
                    if (list6.isEmpty()) {
                        yP_ComplexGabarit2.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
                    } else {
                        object5 = new StringBuilder();
                        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list6) {
                            if (((StringBuilder)object5).length() == 0) {
                                ((StringBuilder)object5).append("SELECT idMerchant FROM management.merchant WHERE idBrand IN(");
                            } else {
                                ((StringBuilder)object5).append(',');
                            }
                            ((StringBuilder)object5).append(yP_TCD_DCC_Brand.getIDBrand());
                        }
                        ((StringBuilder)object5).append(')');
                        yP_ComplexGabarit2.set("value", YP_ComplexGabarit.OPERATOR.IN_SQL, ((StringBuilder)object5).toString());
                    }
                } else {
                    yP_ComplexGabarit2.set("value", YP_ComplexGabarit.OPERATOR.IN, (Object)arrayList);
                }
            } else {
                yP_ComplexGabarit2.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
            }
            object5 = new ArrayList();
            if (arrayList.size() < 1000) {
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_Transaction.getApplicationList()) {
                    object5.add(Long.toString(yP_TCD_DCC_Business.getIDContract()));
                }
            }
            YP_ComplexGabarit yP_ComplexGabarit3 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
            yP_ComplexGabarit3.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "contractAccess");
            if (!object5.isEmpty()) {
                yP_ComplexGabarit3.set("value", YP_ComplexGabarit.OPERATOR.IN, object5);
            } else {
                yP_ComplexGabarit3.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
            }
            YP_ComplexGabarit yP_ComplexGabarit4 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
            if (list6.size() == 1) {
                yP_ComplexGabarit4.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "storeAccess");
                if (list7.size() == 1) {
                    yP_ComplexGabarit4.set("value", YP_ComplexGabarit.OPERATOR.START_WITH, String.valueOf(list6.get(0).getBrandName()) + '_' + list7.get(0).getMerchantName() + '_');
                } else {
                    yP_ComplexGabarit4.set("value", YP_ComplexGabarit.OPERATOR.START_WITH, String.valueOf(list6.get(0).getBrandName()) + '_');
                }
            } else {
                object4 = new ArrayList<String>();
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : list7) {
                    for (YP_Row yP_Row : yP_TCD_DCC_Merchant.getDataContainerBrand().getStoreList(yP_TCD_DCC_Merchant.getIDMerchant())) {
                        object4.add(String.valueOf(yP_TCD_DCC_Merchant.getDataContainerBrand().getBrandName()) + '_' + yP_TCD_DCC_Merchant.getMerchantName() + '_' + yP_TCD_DCC_Merchant.getDataContainerBrand().getStoreIdentifier(yP_Row));
                    }
                }
                String string = yP_Transaction.getDataContainerTransaction().contextHandler.getStoreIdentifier();
                if (string != null && !string.isEmpty() && yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers != null && !yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers.isEmpty()) {
                    object = yP_Transaction.getDataContainerTransaction().contextHandler.businessContainers.get(0).getDataContainerMerchant();
                    object4.add(String.valueOf(((YP_TCD_DCC_Merchant)object).getDataContainerBrand().getBrandName()) + '_' + ((YP_TCD_DCC_Merchant)object).getMerchantName() + '_' + string);
                }
                yP_ComplexGabarit4.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "storeAccess");
                if (!object4.isEmpty()) {
                    yP_ComplexGabarit4.set("value", YP_ComplexGabarit.OPERATOR.IN, object4);
                } else {
                    yP_ComplexGabarit4.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, "impossible");
                }
            }
            object4 = list2 != null && object3 != null ? yP_TCD_DesignAccesObject2.getDistinctValueListSuchAsRequest("idUser", new YP_ComplexGabarit[]{list2, object3, yP_ComplexGabarit2, yP_ComplexGabarit3, yP_ComplexGabarit4}) : yP_TCD_DesignAccesObject2.getDistinctValueListSuchAsRequest("idUser", yP_ComplexGabarit2, yP_ComplexGabarit3, yP_ComplexGabarit4);
            object4 = String.valueOf(object4) + " UNION SELECT " + yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
            yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.IN_SQL, (String)object4);
            yP_ComplexGabarit.set("accessLevel", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
            List<YP_Row> list8 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
                YP_ComplexGabarit yP_ComplexGabarit5 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                yP_ComplexGabarit5.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
                object = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3) {
                    ((YP_ComplexGabarit)object).set("accessLevel", YP_ComplexGabarit.OPERATOR.GREATER_OR_EQUAL, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                } else {
                    ((YP_ComplexGabarit)object).set("accessLevel", YP_ComplexGabarit.OPERATOR.GREATER, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                }
                List<YP_Row> list9 = YP_TCD_DesignAccesObject.getRowListSuchAs(list8, new YP_ComplexGabarit[]{yP_ComplexGabarit5, object});
            }
        }
        if (var18_22 == null) {
            this.logger(2, "getView() null list");
            return null;
        }
        if (var18_22.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        list2 = null;
        if (var18_22.size() != 1) {
            object3 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("MgtParameters");
            object2 = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object3);
            ((YP_ComplexGabarit)object2).set("idUser", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0L);
            ((YP_ComplexGabarit)object2).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "restrictionForMaintenance");
            list2 = ((YP_TCD_DesignAccesObject)object3).getDistinctValueListSuchAs("idUser", new YP_ComplexGabarit[]{object2});
        }
        int n3 = 0;
        while (n3 < var18_22.size()) {
            long l3;
            block108: {
                ArrayList<YP_TCD_DC_Context.Action> arrayList;
                block109: {
                    int n4;
                    Object object6;
                    Object object7;
                    UserStatusEnumeration userStatusEnumeration;
                    int n5;
                    int n6;
                    block110: {
                        boolean bl;
                        block111: {
                            object2 = (YP_Row)var18_22.get(n3);
                            yP_View.setRowID(n3, String.valueOf(((YP_Row)object2).getFather().getFullTableName()) + "#" + ((YP_Row)object2).getPrimaryKeyName() + "#" + ((YP_Row)object2).getPrimaryKey());
                            yP_View.setRowActionable(n3, true);
                            l3 = (Long)((YP_Row)object2).getFieldValueByName("idUser");
                            if (var18_22.size() != 1) break block108;
                            arrayList = new ArrayList<YP_TCD_DC_Context.Action>();
                            n6 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                            n5 = (Integer)((YP_Row)object2).getFieldValueByName("accessLevel");
                            userStatusEnumeration = (UserStatusEnumeration)((Object)((YP_Row)object2).getFieldValueByName("userStatus"));
                            if (userStatusEnumeration == null) break block109;
                            if (l3 == yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier()) break block110;
                            if (n6 == 1 || n6 == 2 || n6 == 3 && n5 == 4) {
                                switch (userStatusEnumeration) {
                                    case ACTIVE: {
                                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                                        action.formName = "StandardConfirmationForm";
                                        action.id = "DEACTIVATE_USER";
                                        action.label = this.getLabel("DEACTIVATE_USER");
                                        arrayList.add(action);
                                        break;
                                    }
                                    case BLOCKED: 
                                    case DELETED: {
                                        break;
                                    }
                                    case INACTIVE: {
                                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                                        action.formName = "StandardConfirmationForm";
                                        action.id = "ACTIVATE_USER";
                                        action.label = this.getLabel("ACTIVATE_USER");
                                        arrayList.add(action);
                                        break;
                                    }
                                    case INITIAL: {
                                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                                        action.formName = "StandardConfirmationForm";
                                        action.id = "DEACTIVATE_USER";
                                        action.label = this.getLabel("DEACTIVATE_USER");
                                        arrayList.add(action);
                                        break;
                                    }
                                }
                            }
                            bl = false;
                            if (n6 != 3) break block111;
                            for (YP_Row yP_Row : yP_Transaction.getDataContainerTransaction().userHandler.userParameters) {
                                switch (yP_Row.getFieldStringValueByName("key")) {
                                    case "brandAccess": 
                                    case "groupAccess": {
                                        bl = true;
                                    }
                                }
                            }
                        }
                        if (n6 == 1 || n6 == 2 || n6 == 3 && n5 == 4 || bl && n5 == 3) {
                            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action.formName = "StandardConfirmationForm";
                            action.id = "RESET_USER";
                            action.label = this.getLabel("RESET_USER");
                            arrayList.add(action);
                        }
                        if ((n6 == 1 || n6 == 2 || n6 == 3 && n5 == 4) && userStatusEnumeration != UserStatusEnumeration.DELETED) {
                            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action.formName = "StandardConfirmationForm";
                            action.id = "DELETE_USER";
                            action.label = this.getLabel("DELETE_USER");
                            arrayList.add(action);
                        }
                    }
                    if (yP_TCD_DCC_Interface_View.isWriteAllowed(l, n6) && (n6 == 1 || n6 == 2 || n6 == 3 && n5 == 4 || l3 == yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier()) && userStatusEnumeration != UserStatusEnumeration.DELETED) {
                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                        action.formName = "UserForm";
                        action.id = "MODIFY_USER";
                        action.label = this.getLabel("MODIFY_USER");
                        arrayList.add(action);
                    }
                    if (userStatusEnumeration != UserStatusEnumeration.DELETED) {
                        this.addMailTlcReportAction(yP_Transaction, l3, arrayList, n5);
                        this.addMailGlobalSummaryReportAction(yP_Transaction, l3, arrayList, n5);
                        if (n5 == 2 && l3 != yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier()) {
                            for (DAO_ViewColumn dAO_ViewColumn : list) {
                                List<YP_Row> list10;
                                object = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                                if (!((String)object).contentEquals("restrictedForMaintenance") || dAO_ViewColumn.writeAccessList == null || !dAO_ViewColumn.writeAccessList.isSet(n6) || (list10 = yP_TCD_DCC_Technique.getUserParameters(yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier(), "restrictionForMaintenance")).size() != 0) continue;
                                this.addRestrictionForMaintenanceAction(yP_Transaction, l3, arrayList);
                            }
                        }
                    }
                    if (n6 == 2 && (n5 == 3 || n5 == 4)) {
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("UserParameters");
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject4 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("Merchant");
                        object = new YP_ComplexGabarit(yP_TCD_DesignAccesObject3);
                        ((YP_ComplexGabarit)object).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
                        ((YP_ComplexGabarit)object).set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                        action.formName = "StandardGenericForm";
                        action.id = "ASSIGN_MERCHANTS";
                        action.label = this.getLabel("ASSIGN_MERCHANTS");
                        action.propertiesList = new ArrayList<Property>();
                        object7 = new JSONObject();
                        object7.put("selectedIndex", 0);
                        JSONArray jSONArray = new JSONArray();
                        object6 = new JSONArray();
                        n4 = 0;
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject3.getRowListSuchAs(new YP_ComplexGabarit[]{object})) {
                            YP_ComplexGabarit yP_ComplexGabarit6 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject4);
                            yP_ComplexGabarit6.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                            for (YP_Row yP_Row2 : yP_TCD_DesignAccesObject4.getRowListSuchAs(yP_ComplexGabarit6)) {
                                jSONArray.put(n4, (Object)yP_Row2.getFieldStringValueByName("merchantLabel"));
                                object6.put(n4, (Object)yP_Row2.getFieldStringValueByName("idMerchant"));
                                ++n4;
                            }
                        }
                        object7.put("items", (Object)jSONArray);
                        object7.put("enabled", true);
                        object7.put("label", (Object)this.getLabel("ASSIGNED_MERCHANTS"));
                        Property property = new Property();
                        property.setName("ASSIGNED_MERCHANTS_COMBOBOX_FIELD");
                        String string = object7.toString();
                        property.setValue(string);
                        action.propertiesList.add(property);
                        Property property2 = new Property();
                        property2.setName("idMerchant_TEXT_FIELD");
                        object7 = new JSONObject();
                        object7.put("label", (Object)this.getLabel("merchantName"));
                        object7.put("text", (Object)"");
                        object7.put("enabled", true);
                        String string2 = object7.toString();
                        property2.setValue(string2);
                        action.propertiesList.add(property2);
                        arrayList.add(action);
                        if (object6.length() > 1) {
                            YP_TCD_DC_Context.Action action2 = new YP_TCD_DC_Context.Action();
                            action2.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action2.formName = "StandardGenericForm";
                            action2.id = "DISSOCIATE_MERCHANTS";
                            action2.label = this.getLabel("DISSOCIATE_MERCHANTS");
                            action2.propertiesList = new ArrayList<Property>();
                            object7 = new JSONObject();
                            object7.put("selectedIndex", 0);
                            object7.put("items", (Object)jSONArray);
                            object7.put("enabled", true);
                            object7.put("label", (Object)this.getLabel("DISSOCIATE_MERCHANTS"));
                            String string3 = object7.toString();
                            Property property3 = new Property();
                            property3.setName("ASSIGNED_MERCHANTS_COMBOBOX_FIELD");
                            property3.setValue(string3);
                            action2.propertiesList.add(property3);
                            Property property4 = new Property();
                            property4.setName("IDMERCHANTS");
                            object7 = new JSONObject();
                            object7.put("items", object6);
                            String string4 = object7.toString();
                            property4.setValue(string4);
                            action2.propertiesList.add(property4);
                            arrayList.add(action2);
                        }
                    }
                    if (n6 == 1) {
                        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                        action.formName = "StandardGenericForm";
                        action.id = "ASSIGN_PARAMETERS";
                        action.label = this.getLabel("ASSIGN_PARAMETERS");
                        action.propertiesList = new ArrayList<Property>();
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("selectedIndex", 0);
                        JSONArray jSONArray = new JSONArray();
                        object = new JSONArray();
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject5 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("UserParameters");
                        object6 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("Merchant");
                        object7 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject5);
                        ((YP_ComplexGabarit)object7).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
                        ((YP_ComplexGabarit)object7).set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        n4 = 0;
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject5.getRowListSuchAs(new YP_ComplexGabarit[]{object7})) {
                            YP_ComplexGabarit yP_ComplexGabarit7 = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object6);
                            yP_ComplexGabarit7.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                            for (YP_Row yP_Row3 : ((YP_TCD_DesignAccesObject)object6).getRowListSuchAs(yP_ComplexGabarit7)) {
                                jSONArray.put(n4, (Object)("MERCHANT - " + yP_Row3.getFieldStringValueByName("merchantLabel") + " (" + yP_Row3.getPrimaryKey() + ")"));
                                object.put(n4, (Object)yP_Row3.getFieldStringValueByName("idMerchant"));
                                ++n4;
                            }
                        }
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject6 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("Brand");
                        object7 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject5);
                        ((YP_ComplexGabarit)object7).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "brandAccess");
                        ((YP_ComplexGabarit)object7).set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject5.getRowListSuchAs(new YP_ComplexGabarit[]{object7})) {
                            YP_ComplexGabarit yP_ComplexGabarit8 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject6);
                            yP_ComplexGabarit8.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                            for (YP_Row yP_Row4 : yP_TCD_DesignAccesObject6.getRowListSuchAs(yP_ComplexGabarit8)) {
                                jSONArray.put(n4, (Object)("BRAND - " + yP_Row4.getFieldStringValueByName("brandLabel") + " (" + yP_Row4.getPrimaryKey() + ")"));
                                object.put(n4, (Object)yP_Row4.getFieldStringValueByName("idBrand"));
                                ++n4;
                            }
                        }
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject7 = yP_TCD_DCC_Technique.getDesignAccesObject_ByName("Group");
                        object7 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject5);
                        ((YP_ComplexGabarit)object7).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "groupAccess");
                        ((YP_ComplexGabarit)object7).set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject5.getRowListSuchAs(new YP_ComplexGabarit[]{object7})) {
                            YP_ComplexGabarit yP_ComplexGabarit9 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject7);
                            yP_ComplexGabarit9.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                            for (YP_Row yP_Row5 : yP_TCD_DesignAccesObject7.getRowListSuchAs(yP_ComplexGabarit9)) {
                                jSONArray.put(n4, (Object)("GROUP - " + yP_Row5.getFieldStringValueByName("groupLabel") + " (" + yP_Row5.getPrimaryKey() + ")"));
                                object.put(n4, (Object)yP_Row5.getFieldStringValueByName("idGroup"));
                                ++n4;
                            }
                        }
                        object7 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject5);
                        ((YP_ComplexGabarit)object7).set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "storeAccess");
                        ((YP_ComplexGabarit)object7).set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject5.getRowListSuchAs(new YP_ComplexGabarit[]{object7})) {
                            String[] stringArray = yP_Row.getFieldStringValueByName("value").split("_");
                            if (stringArray == null || stringArray.length != 3) break;
                            String string = stringArray[2];
                            List<YP_TCD_DCC_Brand> list11 = yP_Transaction.getBrandList(true);
                            Iterator iterator = list11.iterator();
                            while (iterator.hasNext()) {
                                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)iterator.next();
                                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                                    for (YP_Row yP_Row6 : yP_TCD_DCC_Brand.getStoreList(yP_TCD_DCC_Merchant.getIDMerchant())) {
                                        if (!yP_Row6.getFieldStringValueByName("storeIdentifier").contentEquals(string)) continue;
                                        jSONArray.put(n4, (Object)("STORE - " + yP_Row6.getFieldStringValueByName("storeLabel") + " (" + yP_Row6.getPrimaryKey() + ")"));
                                        object.put(n4, (Object)yP_Row.getFieldStringValueByName("value"));
                                        ++n4;
                                    }
                                }
                            }
                        }
                        jSONObject.put("items", (Object)jSONArray);
                        jSONObject.put("enabled", true);
                        jSONObject.put("label", (Object)"Param\u00e8tres assign\u00e9s");
                        Property property = new Property();
                        property.setName("ASSIGNED_PARAMETERS_COMBOBOX_FIELD");
                        String string = jSONObject.toString();
                        property.setValue(string);
                        action.propertiesList.add(property);
                        jSONObject = new JSONObject();
                        jSONObject.put("content", (Object)"<hr width='70%'>");
                        Property property5 = new Property();
                        property5.setName("SEPARATORHTML_FIELD");
                        String string5 = jSONObject.toString();
                        property5.setValue(string5);
                        action.propertiesList.add(property5);
                        jSONObject = new JSONObject();
                        jSONObject.put("text", (Object)"Assigner un nouveau param\u00e8tre");
                        jSONObject.put("hAlignment", (Object)"CENTER");
                        Property property6 = new Property();
                        property6.setName("ASSIGNED_PARAMETERS_LABEL_LABEL_FIELD");
                        String string6 = jSONObject.toString();
                        property6.setValue(string6);
                        action.propertiesList.add(property6);
                        jSONObject = new JSONObject();
                        jSONObject.put("selectedIndex", 0);
                        JSONArray jSONArray2 = new JSONArray();
                        jSONArray2.put(0, (Object)"groupAccess");
                        jSONArray2.put(1, (Object)"brandAccess");
                        jSONArray2.put(2, (Object)"storeAccess");
                        jSONArray2.put(3, (Object)"merchantAccess");
                        jSONObject.put("items", (Object)jSONArray2);
                        jSONObject.put("enabled", true);
                        jSONObject.put("label", (Object)"Type d'acc\u00e8s");
                        Property property7 = new Property();
                        property7.setName("parameterType_COMBOBOX_FIELD");
                        String string7 = jSONObject.toString();
                        property7.setValue(string7);
                        action.propertiesList.add(property7);
                        Property property8 = new Property();
                        property8.setName("idParameter_TEXT_FIELD");
                        jSONObject = new JSONObject();
                        jSONObject.put("label", (Object)"ID");
                        jSONObject.put("text", (Object)"");
                        jSONObject.put("enabled", true);
                        String string8 = jSONObject.toString();
                        property8.setValue(string8);
                        action.propertiesList.add(property8);
                        arrayList.add(action);
                        if (object.length() > 0) {
                            YP_TCD_DC_Context.Action action3 = new YP_TCD_DC_Context.Action();
                            action3.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action3.formName = "StandardGenericForm";
                            action3.id = "DISSOCIATE_PARAMETERS";
                            action3.label = this.getLabel("DISSOCIATE_PARAMETERS");
                            action3.propertiesList = new ArrayList<Property>();
                            jSONObject = new JSONObject();
                            jSONObject.put("selectedIndex", 0);
                            jSONObject.put("items", (Object)jSONArray);
                            jSONObject.put("enabled", true);
                            jSONObject.put("label", (Object)"Param\u00e8tre \u00e0 dissocier : ");
                            String string9 = jSONObject.toString();
                            Property property9 = new Property();
                            property9.setName("ASSIGNED_PARAMETERS_COMBOBOX_FIELD");
                            property9.setValue(string9);
                            action3.propertiesList.add(property9);
                            Property property10 = new Property();
                            property10.setName("IDPARAMETERS");
                            jSONObject = new JSONObject();
                            jSONObject.put("items", object);
                            String string10 = jSONObject.toString();
                            property10.setValue(string10);
                            action3.propertiesList.add(property10);
                            arrayList.add(action3);
                        }
                    }
                    if (n6 == 2 || n6 == 1) {
                        Boolean bl = (Boolean)((YP_Row)object2).getFieldValueByName("vadAllowed");
                        Boolean bl2 = (Boolean)((YP_Row)object2).getFieldValueByName("merchantTicketAllowed");
                        object = (Boolean)((YP_Row)object2).getFieldValueByName("cashierCreationAllowed");
                        Boolean bl3 = yP_Transaction.getDataContainerTransaction().userHandler.isVadAllowed();
                        yP_Transaction.getDataContainerTransaction().userHandler.isMerchantTicketAllowed();
                        object6 = yP_Transaction.getDataContainerTransaction().userHandler.isCashierCreationAllowed();
                        if (bl3.booleanValue()) {
                            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action.formName = "StandardConfirmationForm";
                            if (bl != null && bl.booleanValue()) {
                                action.id = "REVOKE_VAD_AUTHORIZATION";
                                action.label = this.getLabel("REVOKE_VAD_AUTHORIZATION");
                            } else {
                                action.id = "GRANT_VAD_AUTHORIZATION";
                                action.label = this.getLabel("GRANT_VAD_AUTHORIZATION");
                            }
                            action.propertiesList = new ArrayList<Property>();
                            arrayList.add(action);
                        }
                        if (n6 == 1) {
                            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action.formName = "StandardConfirmationForm";
                            if (bl2 != null && bl2.booleanValue()) {
                                action.id = "REVOKE_MERCHANT_TICKET_AUTHORIZATION";
                                action.label = this.getLabel("REVOKE_MERCHANT_TICKET_AUTHORIZATION");
                            } else {
                                action.id = "GRANT_MERCHANT_TICKET_AUTHORIZATION";
                                action.label = this.getLabel("GRANT_MERCHANT_TICKET_AUTHORIZATION");
                            }
                            action.propertiesList = new ArrayList<Property>();
                            arrayList.add(action);
                        }
                        if (n6 == 1 || ((Boolean)object6).booleanValue()) {
                            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                            action.formName = "StandardConfirmationForm";
                            if (object != null && ((Boolean)object).booleanValue()) {
                                action.id = "REVOKE_CASHIER_CREATION_AUTHORIZATION";
                                action.label = this.getLabel("REVOKE_CASHIER_CREATION_AUTHORIZATION");
                            } else {
                                action.id = "GRANT_CASHIER_CREATION_AUTHORIZATION";
                                action.label = this.getLabel("GRANT_CASHIER_CREATION_AUTHORIZATION");
                            }
                            action.propertiesList = new ArrayList<Property>();
                            arrayList.add(action);
                        }
                    }
                }
                yP_View.setRowActionList(n3, arrayList);
            }
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
                if (field != null) {
                    this.addFieldValue(yP_View, field, (YP_Row)object2, string, n3);
                    continue;
                }
                if (string.contentEquals("password")) continue;
                if (string.contentEquals("restrictedForMaintenance")) {
                    boolean bl = false;
                    if (list2 != null) {
                        object = list2.iterator();
                        while (object.hasNext()) {
                            long l4 = (Long)object.next();
                            if (l4 != l3) continue;
                            bl = true;
                            break;
                        }
                    }
                    yP_View.addFieldValue(n3, string, bl ? "1" : "0");
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n3;
        }
        return yP_View;
    }

    private List<YP_Row> getAllChildUserRow(YP_ComplexGabarit yP_ComplexGabarit, Long ... longArray) {
        return this.getAllChildUserRow(0, yP_ComplexGabarit, longArray);
    }

    private List<YP_Row> getAllChildUserRow(int n, YP_ComplexGabarit yP_ComplexGabarit, Long ... longArray) {
        if (n++ > 5) {
            return new ArrayList<YP_Row>();
        }
        YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_ComplexGabarit);
        yP_ComplexGabarit2.set("idFather", YP_ComplexGabarit.OPERATOR.IN, longArray);
        List<YP_Row> list = yP_ComplexGabarit.designAccesObject.getRowListSuchAs(yP_ComplexGabarit2);
        if (!list.isEmpty()) {
            Long[] longArray2 = new Long[list.size()];
            int n2 = 0;
            while (n2 < list.size()) {
                YP_Row yP_Row = list.get(n2);
                longArray2[n2] = (Long)yP_Row.getFieldValueByName("idUser");
                ++n2;
            }
            list.addAll(this.getAllChildUserRow(n, yP_ComplexGabarit, longArray2));
        }
        return list;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.getDesignAccesObject_ByName("User");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    @Override
    public int executeAction(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, YP_View var3_3, YP_Row var4_4, YP_TCD_DC_Context.Action var5_5) {
        if (var2_2 == null) {
            return -1;
        }
        var6_6 = var5_5.id;
        tmp = -1;
        switch (var6_6.hashCode()) {
            case -2067062009: {
                if (var6_6.equals("DISSOCIATE_PARAMETERS")) {
                    tmp = 1;
                }
                break;
            }
            case -1483453830: {
                if (var6_6.equals("GRANT_MERCHANT_TICKET_AUTHORIZATION")) {
                    tmp = 2;
                }
                break;
            }
            case -1405632168: {
                if (var6_6.equals("MAIL_GLOBAL_REPORT_OFF")) {
                    tmp = 3;
                }
                break;
            }
            case -1161732901: {
                if (var6_6.equals("RESET_USER")) {
                    tmp = 4;
                }
                break;
            }
            case -837431237: {
                if (var6_6.equals("ASSIGN_MERCHANTS")) {
                    tmp = 5;
                }
                break;
            }
            case -711389376: {
                if (var6_6.equals("MAIL_TLC_REPORT_OFF")) {
                    tmp = 6;
                }
                break;
            }
            case -609974090: {
                if (var6_6.equals("DEACTIVATE_USER")) {
                    tmp = 4;
                }
                break;
            }
            case -284962470: {
                if (var6_6.equals("RESTRICTION_FOR_MAINTENANCE_OFF")) {
                    tmp = 7;
                }
                break;
            }
            case -9192332: {
                if (var6_6.equals("RESTRICTION_FOR_MAINTENANCE_ON")) {
                    tmp = 8;
                }
                break;
            }
            case 439989892: {
                if (var6_6.equals("REVOKE_MERCHANT_TICKET_AUTHORIZATION")) {
                    tmp = 9;
                }
                break;
            }
            case 479524759: {
                if (var6_6.equals("ACTIVATE_USER")) {
                    tmp = 4;
                }
                break;
            }
            case 526742330: {
                if (var6_6.equals("ASSIGN_PARAMETERS")) {
                    tmp = 10;
                }
                break;
            }
            case 669788622: {
                if (var6_6.equals("MAIL_TLC_REPORT_ON")) {
                    tmp = 11;
                }
                break;
            }
            case 1060730335: {
                if (var6_6.equals("DELETE_USER")) {
                    tmp = 4;
                }
                break;
            }
            case 1081398510: {
                if (var6_6.equals("REVOKE_CASHIER_CREATION_AUTHORIZATION")) {
                    tmp = 12;
                }
                break;
            }
            case 1419761936: {
                if (var6_6.equals("GRANT_VAD_AUTHORIZATION")) {
                    tmp = 13;
                }
                break;
            }
            case 1478677686: {
                if (var6_6.equals("MAIL_GLOBAL_REPORT_ON")) {
                    tmp = 14;
                }
                break;
            }
            case 1584185272: {
                if (var6_6.equals("GRANT_CASHIER_CREATION_AUTHORIZATION")) {
                    tmp = 15;
                }
                break;
            }
            case 1981613791: {
                if (var6_6.equals("SEND_MAIL_GLOBAL_REPORT")) {
                    tmp = 16;
                }
                break;
            }
            case 1982530760: {
                if (var6_6.equals("MAIL_GLOBAL_REPORT")) {
                    tmp = 17;
                }
                break;
            }
            case 1988391630: {
                if (var6_6.equals("DISSOCIATE_MERCHANTS")) {
                    tmp = 18;
                }
                break;
            }
            case 2062517936: {
                if (var6_6.equals("MAIL_TLC_REPORT")) {
                    tmp = 19;
                }
                break;
            }
            case 2135917594: {
                if (var6_6.equals("REVOKE_VAD_AUTHORIZATION")) {
                    tmp = 20;
                }
                break;
            }
        }
        switch (tmp) {
            case 4: {
                return this.setUserStatus(var2_2, var4_4, var5_5);
            }
            case 11: {
                return this.activateTLCReport(var2_2, var4_4, var5_5);
            }
            case 6: {
                return this.deactivateTLCReport(var2_2, var4_4, var5_5);
            }
            case 14: {
                return this.activateGlobalReport(var2_2, var4_4, var5_5);
            }
            case 3: {
                return this.deactivateGlobalReport(var2_2, var4_4, var5_5);
            }
            case 16: {
                return this.sendGlobalReport(var2_2, var4_4, var5_5);
            }
            case 8: {
                return this.activateRestrictionForMaintenance(var2_2, var4_4);
            }
            case 7: {
                return this.deactivateRestrictionForMaintenance(var2_2, var4_4);
            }
            case 5: {
                var7_7 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
                var8_11 = 0L;
                var10_16 = null;
                for (Property var11_22 : var5_5.propertiesList) {
                    if (!var11_22.getName().startsWith("idMerchant")) continue;
                    var10_16 = var7_7.getNewRow();
                    var10_16.set("idUser", var4_4.getFieldStringValueByName("idUser"));
                    var10_16.set("key", "merchantAccess");
                    var13_25 = new JSONObject(var11_22.getValue());
                    var10_16.set("value", var13_25.get("text").toString());
                    try {
                        var8_11 = Long.parseLong(var13_25.get("text").toString());
                        break;
                    }
                    catch (Exception var14_29) {
                        this.logger(2, "executeAction() idMerchant", var14_29);
                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                        var2_2.getDataContainerTransaction().userHandler.setUserMessage("merchantAccess already available");
                        return -1;
                    }
                }
                if (var8_11 <= 0L || var10_16 == null) {
                    this.logger(2, "executeAction() bad request");
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                var11_23 = false;
                var12_18 = var2_2.getBrandList(true);
                var14_30 = var12_18.iterator();
                while (var14_30.hasNext()) {
                    var13_25 = (YP_TCD_DCC_Brand)var14_30.next();
                    for (YP_TCD_DCC_Merchant var15_34 : var13_25.dataContainerMerchantList) {
                        if (var15_34.getIDMerchant() != var8_11) continue;
                        var11_23 = true;
                        break;
                    }
                    if (var11_23) break;
                }
                if (!var11_23) {
                    this.logger(3, "executeAction() Not exist or no rights");
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                    var2_2.getDataContainerTransaction().userHandler.setUserMessage("Not exist or no rights");
                    return -1;
                }
                var13_25 = new YP_ComplexGabarit(var7_7);
                var13_25.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, var4_4.getFieldStringValueByName("idUser"));
                var13_25.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
                var13_25.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, String.valueOf(var8_11));
                if (var7_7.getRowListSuchAs(new YP_ComplexGabarit[]{var13_25}).size() > 0) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(1));
                    var2_2.getDataContainerTransaction().userHandler.setUserMessage("merchantAccess already available");
                    this.logger(3, "executeAction() merchantAccess already available");
                    return 1;
                }
                try {
                    var10_16.setIsItAClonedRow(false);
                    var10_16.persist();
                }
                catch (Exception var14_31) {
                    this.logger(2, "executeAction() ", var14_31);
                }
                return 1;
            }
            case 10: {
                var7_8 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
                var8_12 = 0L;
                var10_17 = null;
                var14_32 = null;
                var15_35 = "";
                for (Property var16_38 : var5_5.propertiesList) {
                    if (!var16_38.getName().startsWith("parameterType")) continue;
                    var18_65 = new JSONObject(var16_38.getValue());
                    var19_80 = var18_65.getJSONArray("items");
                    var14_32 = var19_80.getString(var18_65.getInt("selectedIndex"));
                }
                for (Property var16_40 : var5_5.propertiesList) {
                    if (!var16_40.getName().startsWith("idParameter")) continue;
                    var10_17 = var7_8.getNewRow();
                    var10_17.set("idUser", var4_4.getFieldStringValueByName("idUser"));
                    var10_17.set("key", var14_32);
                    var18_66 = new JSONObject(var16_40.getValue());
                    try {
                        var15_35 = var18_66.get("text").toString();
                        var10_17.set("value", var18_66.get("text").toString());
                        break;
                    }
                    catch (Exception var19_81) {
                        this.logger(2, "executeAction() idMerchant", var19_81);
                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                        var2_2.getDataContainerTransaction().userHandler.setUserMessage("merchantAccess already available");
                        return -1;
                    }
                }
                var11_24 = false;
                if (!var14_32.equals("groupAccess")) ** GOTO lbl246
                var16_41 = var2_2.getGroupList();
                for (YP_TCD_DCC_Group var17_56 : var16_41) {
                    if (!String.valueOf(var17_56.getIDGroup()).contentEquals(var15_35)) continue;
                    var11_24 = true;
                    ** GOTO lbl292
                }
                ** GOTO lbl292
lbl246:
                // 1 sources

                if (!var14_32.equals("brandAccess")) ** GOTO lbl253
                var12_19 = var2_2.getBrandList(true);
                for (YP_TCD_DCC_Brand var16_43 : var12_19) {
                    if (!String.valueOf(var16_43.getIDBrand()).contentEquals(var15_35)) continue;
                    var11_24 = true;
                    ** GOTO lbl292
                }
                ** GOTO lbl292
lbl253:
                // 1 sources

                if (!var14_32.equals("merchantAccess")) ** GOTO lbl264
                var12_20 = var2_2.getBrandList(true);
                for (YP_TCD_DCC_Brand var16_45 : var12_20) {
                    for (YP_TCD_DCC_Merchant var18_70 : var16_45.dataContainerMerchantList) {
                        if (!String.valueOf(var18_70.getIDMerchant()).contentEquals(var15_35)) continue;
                        var11_24 = true;
                        break;
                    }
                    if (!var11_24) {
                        continue;
                    }
                    ** GOTO lbl292
                }
                ** GOTO lbl292
lbl264:
                // 1 sources

                if (var14_32.equals("storeAccess")) {
                    var12_21 = var2_2.getBrandList(true);
                    var16_46 = var15_35.split("_");
                    var17_59 = null;
                    var18_71 = null;
                    var19_80 = null;
                    if (var16_46 == null || var16_46.length != 3) {
                        this.logger(3, "executeAction() Not exist or no rights");
                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                        var2_2.getDataContainerTransaction().userHandler.setUserMessage("Not exist or no rights");
                        return -1;
                    }
                    var17_60 = var16_46[0];
                    var18_72 = var16_46[1];
                    var19_80 = var16_46[2];
                    for (YP_TCD_DCC_Brand var20_98 : var12_21) {
                        for (YP_TCD_DCC_Merchant var22_106 : var20_98.dataContainerMerchantList) {
                            for (YP_Row var24_116 : var20_98.getStoreList(var22_106.getIDMerchant())) {
                                if (var17_60.contentEquals(var20_98.getBrandName()) && var18_72.contentEquals(var22_106.getMerchantName()) && var19_80.contentEquals(var24_116.getFieldStringValueByName("storeIdentifier"))) {
                                    var11_24 = true;
                                }
                                if (!var24_116.getFieldStringValueByName("storeIdentifier").contentEquals(var15_35)) continue;
                                var11_24 = true;
                                break;
                            }
                            if (var11_24) break;
                        }
                        if (!var11_24) {
                            continue;
                        }
                        break;
                    }
                }
lbl292:
                // 10 sources

                if (!var11_24) {
                    this.logger(3, "executeAction() Not exist or no rights");
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                    var2_2.getDataContainerTransaction().userHandler.setUserMessage("Not exist or no rights");
                    return -1;
                }
                var13_26 = new YP_ComplexGabarit(var7_8);
                var13_26.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, var4_4.getFieldStringValueByName("idUser"));
                var13_26.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, var14_32);
                var13_26.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, var15_35);
                if (var7_8.getRowListSuchAs(new YP_ComplexGabarit[]{var13_26}).size() > 0) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(1));
                    var2_2.getDataContainerTransaction().userHandler.setUserMessage(String.valueOf(var14_32) + " already available");
                    this.logger(3, "executeAction() " + var14_32 + " already available");
                    return 1;
                }
                try {
                    var10_17.setIsItAClonedRow(false);
                    var10_17.persist();
                }
                catch (Exception var16_48) {
                    this.logger(2, "executeAction() ", var16_48);
                }
                return 1;
            }
            case 1: {
                var15_36 = null;
                var16_49 = false;
                var14_33 = null;
                for (Property var17_61 : var5_5.propertiesList) {
                    if (!var17_61.getName().startsWith("ASSIGNED_PARAMETERS")) continue;
                    var19_82 = new JSONObject(var17_61.getValue());
                    var16_50 = var19_82.getInt("selectedIndex");
                    var20_99 = var19_82.getJSONArray("items").getString(var16_50);
                    var14_33 = var20_99.startsWith("BRAND") != false ? "brandAccess" : (var20_99.startsWith("MERCHANT") != false ? "merchantAccess" : (var20_99.startsWith("GROUP") != false ? "groupAccess" : "storeAccess"));
                    break;
                }
                for (Property var17_63 : var5_5.propertiesList) {
                    if (!var17_63.getName().startsWith("IDPARAMETERS")) continue;
                    var19_82 = new JSONObject(var17_63.getValue());
                    var20_99 = var19_82.getJSONArray("items");
                    var15_36 = var20_99.getString(var16_50);
                    break;
                }
                var7_9 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
                var13_27 = new YP_ComplexGabarit(var7_9);
                var13_27.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, var4_4.getFieldStringValueByName("idUser"));
                var13_27.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, var14_33);
                var13_27.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, String.valueOf(var15_36));
                var17_64 = var7_9.getRowListSuchAs(new YP_ComplexGabarit[]{var13_27});
                if (var17_64 == null || var17_64.size() == 0) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction(), no " + var14_33 + " row found");
                    return -1;
                }
                if (var17_64.size() > 1) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction(), more than one " + var14_33 + " row found");
                    return -1;
                }
                try {
                    var17_64.get(0).delete();
                    return var17_64.get(0).persist();
                }
                catch (Exception var18_75) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction() ", var18_75);
                    return -1;
                }
            }
            case 18: {
                var8_13 = 0L;
                var16_51 = false;
                for (Property var18_76 : var5_5.propertiesList) {
                    if (!var18_76.getName().startsWith("ASSIGNED_MERCHANTS")) continue;
                    var20_100 = new JSONObject(var18_76.getValue());
                    var16_52 = var20_100.getInt("selectedIndex");
                    break;
                }
                for (Property var18_78 : var5_5.propertiesList) {
                    if (!var18_78.getName().startsWith("IDMERCHANTS")) continue;
                    var20_100 = new JSONObject(var18_78.getValue());
                    var21_92 = var20_100.getJSONArray("items");
                    var8_13 = var21_92.getLong(var16_52);
                    break;
                }
                var7_10 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
                var13_28 = new YP_ComplexGabarit(var7_10);
                var13_28.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, var4_4.getFieldStringValueByName("idUser"));
                var13_28.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
                var13_28.set("value", YP_ComplexGabarit.OPERATOR.EQUAL, String.valueOf(var8_13));
                var18_79 = var7_10.getRowListSuchAs(new YP_ComplexGabarit[]{var13_28});
                if (var18_79 == null || var18_79.size() == 0) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction(), no merchantAccess row found");
                    return -1;
                }
                if (var18_79.size() > 1) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction(), more than one merchantAccess row found");
                    return -1;
                }
                try {
                    var18_79.get(0).delete();
                    return var18_79.get(0).persist();
                }
                catch (Exception var19_84) {
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                    this.logger(2, "executeAction() ", var19_84);
                    return -1;
                }
            }
            case 19: {
                try {
                    block91: for (Property var19_85 : var5_5.propertiesList) {
                        if (!var19_85.getName().contains("CHECKBOX_FIELD")) continue;
                        var21_93 = new JSONObject(var19_85.getValue());
                        var22_107 = var21_93.get("checked").toString();
                        var23_114 = var21_93.get("previouslyChecked").toString();
                        if (var22_107 == null || !var22_107.contentEquals("true") && !var22_107.contentEquals("false")) {
                            this.logger(2, "executeAction() invalid checked value for " + var21_93.get("label").toString());
                            YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                            return -1;
                        }
                        var24_117 = Long.parseLong(var4_4.getFieldStringValueByName("idUser"));
                        var8_14 = Long.parseLong(var21_93.get("idMerchant").toString());
                        var26_121 = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                        var27_122 = var26_121.getUserParameters(var24_117, new Object[]{"mailTLCReport", "mailTLCReportOff"});
                        var28_124 = false;
                        for (YP_Row var29_127 : var27_122) {
                            if (!var29_127.getFieldStringValueByName("idMerchant").contentEquals(String.valueOf(var8_14))) continue;
                            var28_124 = true;
                            break;
                        }
                        if (!var28_124) {
                            if (!Boolean.parseBoolean(var22_107)) continue;
                            var29_128 = var26_121.getDesignAccesObject_ByName("MgtParameters");
                            var30_133 = var29_128.getNewRow();
                            var30_133.set("idContract", "0");
                            var30_133.set("idMerchant", var8_14);
                            var30_133.set("idBrand", "0");
                            var30_133.set("idUser", var24_117);
                            var30_133.set("idGroup", "0");
                            var30_133.set("idStore", "0");
                            var30_133.set("key", "mailTLCReport");
                            var30_133.set("value", "");
                            var29_128.addRow(var30_133);
                            var29_128.persist();
                            break;
                        }
                        for (YP_Row var29_129 : var27_122) {
                            if (!var29_129.getFieldStringValueByName("idMerchant").contentEquals(String.valueOf(var8_14))) continue;
                            if (Boolean.parseBoolean(var22_107) == Boolean.parseBoolean(var23_114)) continue block91;
                            if (Boolean.parseBoolean(var22_107)) {
                                var29_129.set("key", "mailTLCReport");
                                if (var29_129.persist() == 1) continue block91;
                                this.logger(2, "activateTLCReport() error during persist for " + var4_4.getFieldStringValueByName("login") + " for merchant " + var8_14);
                                return -1;
                            }
                            var29_129.set("key", "mailTLCReportOff");
                            if (var29_129.persist() == 1) continue block91;
                            this.logger(2, "activateTLCReport() error during persist for " + var4_4.getFieldStringValueByName("login") + " for merchant " + var8_14);
                            return -1;
                        }
                    }
                    return 1;
                }
                catch (Exception var19_86) {
                    this.logger(2, "activateTLCReport() ", var19_86);
                    return -1;
                }
            }
            case 17: {
                try {
                    var19_87 = "";
                    for (Property var20_102 : var5_5.propertiesList) {
                        if (!var20_102.getName().contentEquals("END_DATETIME_TEXT_FIELD")) continue;
                        var22_108 = new JSONObject(var20_102.getValue());
                        var19_87 = var22_108.get("text").toString();
                        if (var19_87 == null || var19_87.length() != 5) {
                            this.logger(3, "activateGlobalReport(): invalid length for " + var22_108.get("label").toString());
                            var2_2.getDataContainerTransaction().userHandler.setUserMessage("Invalid format hh:mm");
                            return -1;
                        }
                        var19_87 = var19_87.replace(":", "");
                    }
                    block95: for (Property var20_102 : var5_5.propertiesList) {
                        if (!var20_102.getName().contains("CHECKBOX_FIELD")) continue;
                        var22_108 = new JSONObject(var20_102.getValue());
                        var23_115 = var22_108.get("checked").toString();
                        var24_118 = var22_108.get("previouslyChecked").toString();
                        if (var23_115 == null || !var23_115.contentEquals("true") && !var23_115.contentEquals("false")) {
                            this.logger(2, "executeAction() invalid checked value for " + var22_108.get("label").toString());
                            YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                            return -1;
                        }
                        var25_120 = Long.parseLong(var4_4.getFieldStringValueByName("idUser"));
                        var8_15 = Long.parseLong(var22_108.get("idMerchant").toString());
                        var27_123 = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                        var28_125 = var27_123.getUserParameters(var25_120, new Object[]{"mailGlobalReport", "mailGlobalReportOff"});
                        var29_130 = false;
                        for (YP_Row var30_136 : var28_125) {
                            if (!var30_136.getFieldStringValueByName("idMerchant").contentEquals(String.valueOf(var8_15))) continue;
                            var29_130 = true;
                            break;
                        }
                        if (!var29_130) {
                            if (!Boolean.parseBoolean(var23_115)) continue;
                            var30_137 = var27_123.getDesignAccesObject_ByName("MgtParameters");
                            var31_139 = var30_137.getNewRow();
                            var31_139.set("idContract", "0");
                            var31_139.set("idMerchant", var8_15);
                            var31_139.set("idBrand", "0");
                            var31_139.set("idUser", var25_120);
                            var31_139.set("idGroup", "0");
                            var31_139.set("idStore", "0");
                            var31_139.set("key", "mailGlobalReport");
                            var31_139.set("value", var19_87);
                            var30_137.addRow(var31_139);
                            var30_137.persist();
                            break;
                        }
                        for (YP_Row var30_138 : var28_125) {
                            if (!var30_138.getFieldStringValueByName("idMerchant").contentEquals(String.valueOf(var8_15))) continue;
                            if (Boolean.parseBoolean(var23_115) == Boolean.parseBoolean(var24_118)) continue block95;
                            if (Boolean.parseBoolean(var23_115)) {
                                var30_138.set("key", "mailGlobalReport");
                                var30_138.set("value", var19_87);
                                if (var30_138.persist() == 1) continue block95;
                                this.logger(2, "activateTLCReport() error during persist for " + var4_4.getFieldStringValueByName("login") + " for merchant " + var8_15);
                                return -1;
                            }
                            var30_138.set("key", "mailGlobalReportOff");
                            var30_138.set("value", "");
                            if (var30_138.persist() == 1) continue block95;
                            this.logger(2, "activateTLCReport() error during persist for " + var4_4.getFieldStringValueByName("login") + " for merchant " + var8_15);
                            return -1;
                        }
                    }
                    return 1;
                }
                catch (Exception var19_88) {
                    this.logger(2, "activateTLCReport() ", var19_88);
                    return -1;
                }
            }
            case 13: {
                var19_89 = var2_2.getDataContainerTransaction().userHandler.isVadAllowed();
                if (var19_89.booleanValue()) {
                    var4_4.set("vadAllowed", true);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var20_103) {
                        this.logger(2, "Grant VAD authorization ", var20_103);
                        return -1;
                    }
                } else {
                    return -1;
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
            case 2: {
                var20_104 = var2_2.getDataContainerTransaction().userHandler.isMerchantTicketAllowed();
                if (var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1) {
                    var4_4.set("merchantTicketAllowed", true);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var21_95) {
                        this.logger(2, "Grant merchant ticket authorization ", var21_95);
                        return -1;
                    }
                } else {
                    return -1;
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
            case 15: {
                var21_96 = var2_2.getDataContainerTransaction().userHandler.isCashierCreationAllowed();
                if (var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || var21_96.booleanValue()) {
                    var4_4.set("cashierCreationAllowed", true);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var22_109) {
                        this.logger(2, "Grant cashier creation authorization ", var22_109);
                        return -1;
                    }
                } else {
                    return -1;
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
            case 20: {
                var19_90 = var2_2.getDataContainerTransaction().userHandler.isVadAllowed();
                if (var19_90.booleanValue()) {
                    var4_4.set("vadAllowed", false);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var22_110) {
                        this.logger(2, "Grant VAD authorization ", var22_110);
                        return -1;
                    }
                } else {
                    return -1;
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
            case 9: {
                var20_105 = var2_2.getDataContainerTransaction().userHandler.isMerchantTicketAllowed();
                if (var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || var20_105.booleanValue()) {
                    var4_4.set("merchantTicketAllowed", false);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var22_111) {
                        this.logger(2, "Grant merchant ticket authorization ", var22_111);
                        return -1;
                    }
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
            case 12: {
                var21_97 = var2_2.getDataContainerTransaction().userHandler.isCashierCreationAllowed();
                if (var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || var21_97.booleanValue()) {
                    var4_4.set("cashierCreationAllowed", false);
                    try {
                        var4_4.persist();
                    }
                    catch (Exception var22_112) {
                        this.logger(2, "Grant cashier creation authorization ", var22_112);
                        return -1;
                    }
                } else {
                    return -1;
                }
                YP_TCD_DCC_Business.getExtendedResult(var2_2.getDataContainerTransaction()).add(8);
                return 1;
            }
        }
        this.logger(2, "executeAction() unknown action" + var5_5.id);
        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                List<YP_Row> list2;
                int n2;
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    this.logger(2, "createInView() Key must not be set !");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    this.logger(2, "createInView() not really possible !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                String string2 = null;
                String string3 = null;
                String string4 = null;
                Boolean bl = null;
                Boolean bl2 = null;
                Boolean bl3 = null;
                block41: for (String string5 : yP_View.getColumnSet()) {
                    String string6 = yP_View.getFieldValueAt(n, string5);
                    if (string6 == null) continue;
                    switch (string5) {
                        case "idUser": 
                        case "pkUser": {
                            if (string6.isEmpty()) continue block41;
                            this.logger(2, "createInView() Key should be empty :" + string5);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "login": {
                            string2 = string6;
                            yP_Row.set(string5, string6);
                            break;
                        }
                        case "preferredLanguage": {
                            string4 = string6;
                            yP_Row.set(string5, string6);
                            break;
                        }
                        case "lastName": 
                        case "authPluginName": 
                        case "mail": 
                        case "firstName": {
                            yP_Row.set(string5, string6);
                            break;
                        }
                        case "accessLevel": {
                            yP_Row.set(string5, Integer.parseInt(string6));
                            break;
                        }
                        case "idLDAP": {
                            yP_Row.set(string5, Long.parseLong(string6));
                            break;
                        }
                        case "idFather": {
                            if (string6.isEmpty()) continue block41;
                            this.logger(2, "createInView() field ignored :" + string5);
                            break;
                        }
                        case "password": {
                            string3 = string6;
                            break;
                        }
                        case "refundAllowed": {
                            bl = Boolean.parseBoolean(string6);
                            break;
                        }
                        case "merchantTicketAllowed": {
                            bl2 = Boolean.parseBoolean(string6);
                            break;
                        }
                        case "cashierCreationAllowed": {
                            bl3 = Boolean.parseBoolean(string6);
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string5);
                            break;
                        }
                        case "userStatus": 
                    }
                }
                if (string2 == null || string2.isEmpty()) {
                    this.logger(2, "createInView() mandatory value missing:login");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                YP_Object yP_Object = this.getPluginByName("User");
                if (yP_Object == null) {
                    this.logger(2, "createInView() no plugin available");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row2 = (YP_Row)yP_Object.dealRequest(this, "getUserRowByLogin", string2);
                if (yP_Row2 != null) {
                    this.logger(2, "createInView() login already exist:" + string2);
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                    return -1;
                }
                int n3 = (Integer)yP_Row.getFieldValueByName("accessLevel");
                if (n3 == 0) {
                    if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1) {
                        n3 = 2;
                    } else if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) {
                        n3 = 3;
                    } else {
                        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 3) {
                            this.logger(2, "createInView() No right to create user " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                            return -1;
                        }
                        n3 = 4;
                    }
                    yP_Row.set("accessLevel", n3);
                }
                switch (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel()) {
                    case 1: {
                        if (n3 == 1 || n3 == 2 || n3 == 3 || n3 == 4) break;
                        this.logger(2, "createInView() No right to create this level " + n3 + " " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    case 2: {
                        if (n3 == 3 || n3 == 4) break;
                        this.logger(2, "createInView() No right to create this level " + n3 + " " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    case 3: {
                        if (n3 == 3 || n3 == 4) break;
                        this.logger(2, "createInView() No right to create this level " + n3 + " " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    case 4: {
                        if (n3 == 4) break;
                        this.logger(2, "createInView() No right to create this level " + n3 + " " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    default: {
                        this.logger(2, "createInView() Unknown level " + yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel());
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                }
                if (string4 == null || string4.isEmpty()) {
                    yP_Row.set("preferredLanguage", yP_Transaction.getDataContainerTransaction().userHandler.getUserPreferredLanguage());
                }
                yP_Row.set("idFather", yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
                yP_Row.setPrimaryKey(yP_TCD_DesignAccesObject.getNextPrimaryKey());
                yP_Row.set("idUser", yP_Row.getPrimaryKey());
                yP_Row.set("lastGMTTime", UtilsYP.getNowSqlTimeStamp());
                if (string3 == null || string3.isEmpty()) {
                    yP_Row.set("userStatus", UserStatusEnumeration.INITIAL);
                } else {
                    yP_Row.set("userStatus", UserStatusEnumeration.ACTIVE);
                }
                if (bl == null) {
                    bl = false;
                } else if (bl.booleanValue() && !yP_Transaction.getDataContainerTransaction().userHandler.isVadAllowed().booleanValue()) {
                    this.logger(2, "createInView() user trying to create user with more vad actions rights...");
                    bl = false;
                }
                yP_Row.set("vadAllowed", bl);
                if (bl2 == null) {
                    bl2 = false;
                } else if (bl2.booleanValue() && !yP_Transaction.getDataContainerTransaction().userHandler.isMerchantTicketAllowed().booleanValue() && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1) {
                    this.logger(2, "createInView() user trying to create user with more merchant ticket rights...");
                    bl2 = false;
                }
                yP_Row.set("merchantTicketAllowed", bl2);
                if (bl3 == null) {
                    bl3 = false;
                } else if (bl3.booleanValue() && !yP_Transaction.getDataContainerTransaction().userHandler.isCashierCreationAllowed().booleanValue() && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1) {
                    this.logger(2, "createInView() user trying to create user with more cashier creation rights...");
                    bl3 = false;
                }
                yP_Row.set("cashierCreationAllowed", bl3);
                Object object = new Random();
                long l = ((Random)object).nextLong();
                if (l < 0L) {
                    l *= -1L;
                }
                yP_Row.set("permanentToken", Long.toHexString(l));
                String string7 = this.createUser(yP_Transaction, yP_Row, string3);
                if (string7 == null) {
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (!string7.isEmpty() && YP_TCG_Mailer.sendTemporaryPasswordByMail(this, yP_Transaction, yP_Row, string7) < 0) {
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) < 0) {
                    this.logger(2, "createInView() Not able to add row...");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (yP_TCD_DesignAccesObject.persist() < 0) {
                    this.logger(2, "createInView() Not able to save changes...");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2 && (n2 = ((Integer)yP_Row.getFieldValueByName("accessLevel")).intValue()) == 2 && (list2 = this.dataContainerTechnique.getUserParameters(yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier(), "restrictionForMaintenance")).size() > 0) {
                    this.activateRestrictionForMaintenance(yP_Transaction, yP_Row);
                }
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() ", exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String createUser(YP_Transaction yP_Transaction, YP_Row yP_Row, String string) {
        try {
            String string2 = null;
            String string3 = yP_Row.getFieldStringValueByName("login");
            String string4 = yP_Row.getFieldStringValueByName("authPluginName");
            if (string4 != null && !string4.isEmpty()) {
                YP_Object yP_Object = this.getPluginByName(string4);
                if (yP_Object != null && yP_Object instanceof YP_Authentifiers) {
                    return ((YP_Authentifiers)((Object)yP_Object)).createUser(yP_Transaction.getDataContainerTransaction(), yP_Row, string3, string);
                }
                this.logger(2, "createUser() pb with authentifier plugin :" + string4);
                return null;
            }
            long l = (Long)yP_Row.getFieldValueByName("idLDAP");
            if (l == 0L) {
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_Transaction, yP_Row);
                if (yP_TCD_DCC_Brand == null) return string2;
                return yP_TCD_DCC_Brand.createUser(yP_Row, string3, string);
            }
            YP_Object yP_Object = this.getPluginByName("LDAP");
            if (yP_Object != null && yP_Object instanceof YP_Authentifiers) {
                return ((YP_Authentifiers)((Object)yP_Object)).createUser(yP_Transaction.getDataContainerTransaction(), yP_Row, string3, string);
            }
            this.logger(2, "createUser() pb with LDAP plugin");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "createUser() ", exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String resetUser(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            String string = null;
            String string2 = yP_Row.getFieldStringValueByName("login");
            String string3 = yP_Row.getFieldStringValueByName("authPluginName");
            if (string3 != null && !string3.isEmpty()) {
                YP_Object yP_Object = this.getPluginByName(string3);
                if (yP_Object != null && yP_Object instanceof YP_Authentifiers) {
                    return ((YP_Authentifiers)((Object)yP_Object)).resetUser(yP_Transaction.getDataContainerTransaction(), yP_Row, string2);
                }
                this.logger(2, "resetUser() pb with authentifier plugin :" + string3);
                return null;
            }
            long l = (Long)yP_Row.getFieldValueByName("idLDAP");
            if (l == 0L) {
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_Transaction, yP_Row);
                if (yP_TCD_DCC_Brand == null) return string;
                return yP_TCD_DCC_Brand.resetUser(yP_Row, string2);
            }
            YP_Object yP_Object = this.getPluginByName("LDAP");
            if (yP_Object != null && yP_Object instanceof YP_Authentifiers) {
                return ((YP_Authentifiers)((Object)yP_Object)).resetUser(yP_Transaction.getDataContainerTransaction(), yP_Row, string2);
            }
            this.logger(2, "resetUser() pb with LDAP plugin");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "resetUser() ", exception);
            return null;
        }
    }

    @Override
    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        int n;
        block19: {
            block18: {
                block17: {
                    block16: {
                        block11: {
                            YP_Object yP_Object;
                            String string3;
                            String string4;
                            block15: {
                                block12: {
                                    block14: {
                                        YP_TCD_DCC_Brand yP_TCD_DCC_Brand;
                                        block13: {
                                            try {
                                                n = this.checkRightsToModifyUser(yP_Transaction.getDataContainerTransaction(), yP_Row);
                                                if (n != 1 || !string.contentEquals("password")) break block11;
                                                yP_Row.set("currentAttempt", 0);
                                                yP_Row.set("userStatus", UserStatusEnumeration.ACTIVE);
                                                string4 = yP_Row.getFieldStringValueByName("login");
                                                string3 = yP_Row.getFieldStringValueByName("authPluginName");
                                                if (string3 != null && !string3.isEmpty()) break block12;
                                                yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_Transaction, yP_Row);
                                                if (yP_TCD_DCC_Brand != null) break block13;
                                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                                return 0;
                                            }
                                            catch (Exception exception) {
                                                this.logger(2, "checkModification() ", exception);
                                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                                return -1;
                                            }
                                        }
                                        if (!yP_TCD_DCC_Brand.setPassword(string4, string2)) break block14;
                                        return 1;
                                    }
                                    this.logger(2, "checkModification() password modification failed");
                                    return 0;
                                }
                                yP_Object = this.getPluginByName(string3);
                                if (yP_Object != null && yP_Object instanceof YP_Authentifiers) break block15;
                                this.logger(2, "checkModification() pb with auth plugin :" + string3);
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                return -1;
                            }
                            Boolean bl = ((YP_Authentifiers)((Object)yP_Object)).setPassword(yP_Transaction.getDataContainerTransaction(), yP_Row, string4, string2);
                            if (bl != null && bl.booleanValue()) break block11;
                            this.logger(2, "checkModification() pb with auth plugin :" + string3);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(3));
                            return -1;
                        }
                        if (!string.contentEquals("mail") || string2.matches(EMAIL_PATTERN)) break block16;
                        this.logger(2, "checkModification() pb with mail value format");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(3));
                        return -1;
                    }
                    if (!string.contentEquals("lastName") || string2.matches(FIRST_NAME_AND_LAST_NAME_PATTERN)) break block17;
                    this.logger(2, "checkModification() pb with lastName value format");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(3));
                    return -1;
                }
                if (!string.contentEquals("firstName") || string2.matches(FIRST_NAME_AND_LAST_NAME_PATTERN)) break block18;
                this.logger(2, "checkModification() pb with firstName value format");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(3));
                return -1;
            }
            if (n != 1 || !string.contentEquals("login") || string2.matches(LOGIN_PATTERN)) break block19;
            this.logger(2, "checkModification() pb with login value format");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(3));
            return -1;
        }
        return n;
    }

    public int checkRightsToModifyUser(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row) {
        block20: {
            YP_Row yP_Row2;
            long l;
            block19: {
                YP_Object yP_Object;
                long l2;
                block18: {
                    block17: {
                        block16: {
                            block15: {
                                block14: {
                                    int n;
                                    int n2;
                                    block13: {
                                        block12: {
                                            try {
                                                n2 = yP_TCD_DC_Transaction.userHandler.getUserAccessLevel();
                                                if (n2 != 1) break block12;
                                                return 1;
                                            }
                                            catch (Exception exception) {
                                                this.logger(2, "checkRightsToModifyUser() ", exception);
                                                YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                                                return -1;
                                            }
                                        }
                                        n = (Integer)yP_Row.getFieldValueByName("accessLevel");
                                        if (n2 != 2) break block13;
                                        if (n == 2 || n == 3 || n == 4) {
                                            return 1;
                                        }
                                        break block14;
                                    }
                                    if (n2 != 3 || n != 3 && n != 4) break block14;
                                    return 1;
                                }
                                long l3 = (Long)yP_Row.getFieldValueByName("idUser");
                                l = yP_TCD_DC_Transaction.userHandler.getUserIdentifier();
                                if (l3 != l) break block15;
                                return 1;
                            }
                            l2 = (Long)yP_Row.getFieldValueByName("idFather");
                            if (l2 != 0L) break block16;
                            return 1;
                        }
                        if (l != l2) break block17;
                        return 1;
                    }
                    yP_Object = this.getPluginByName("User");
                    if (yP_Object != null) break block18;
                    this.logger(3, "checkRightsToModifyUser() no plugin available");
                    YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                    return -1;
                }
                yP_Row2 = (YP_Row)yP_Object.dealRequest(this, "getUserRowByID", l2);
                if (yP_Row2 != null) break block19;
                this.logger(3, "checkRightsToModifyUser() no father !!!");
                YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                return -1;
            }
            long l4 = (Long)yP_Row2.getFieldValueByName("idFather");
            if (l != l4) break block20;
            return 1;
        }
        this.logger(2, "checkRightsToModifyUser() not allowed user");
        YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(102));
        return 0;
    }

    private int setUserStatus(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        block42: {
            String string;
            block41: {
                block40: {
                    boolean bl;
                    block37: {
                        block39: {
                            int n;
                            int n2;
                            block38: {
                                block36: {
                                    n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                                    n = (Integer)yP_Row.getFieldValueByName("accessLevel");
                                    long l = (Long)yP_Row.getFieldValueByName("idUser");
                                    if (l != yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier()) break block36;
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                    this.logger(2, "setUserStatus() Own modifactions are not allowed");
                                    return -1;
                                }
                                if (n2 == 1) break block37;
                                if (n != 1) break block38;
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                this.logger(2, "setUserStatus() Only super admin can change super admin");
                                return -1;
                            }
                            try {
                                if (n2 == 2 && (n == 2 || n == 3 || n == 4)) break block37;
                                if (n2 != 3) break block39;
                                bl = false;
                                for (YP_Row object : yP_Transaction.getDataContainerTransaction().userHandler.userParameters) {
                                    switch (object.getFieldStringValueByName("key")) {
                                        case "brandAccess": 
                                        case "groupAccess": {
                                            bl = true;
                                        }
                                    }
                                }
                                if (!(n == 4 || n == 3 && bl && action.id.contentEquals("RESET_USER"))) {
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                    this.logger(2, "setUserStatus() No rights");
                                    return -1;
                                }
                                break block37;
                            }
                            catch (Exception exception) {
                                this.logger(2, "setUserStatus() ", exception);
                                return -1;
                            }
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "setUserStatus() No rights");
                        return -1;
                    }
                    bl = false;
                    yP_Row.set("currentAttempt", 0);
                    switch (action.id) {
                        case "ACTIVATE_USER": {
                            yP_Row.set("userStatus", UserStatusEnumeration.ACTIVE);
                            break;
                        }
                        case "DEACTIVATE_USER": {
                            yP_Row.set("userStatus", UserStatusEnumeration.INACTIVE);
                            break;
                        }
                        case "RESET_USER": {
                            yP_Row.set("userStatus", UserStatusEnumeration.INITIAL);
                            bl = true;
                            break;
                        }
                        case "DELETE_USER": {
                            yP_Row.set("userStatus", UserStatusEnumeration.DELETED);
                        }
                    }
                    if (bl) break block40;
                    yP_Row.persist();
                    YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
                    return 1;
                }
                string = this.resetUser(yP_Transaction, yP_Row);
                if (string != null) break block41;
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            if (string.isEmpty() || YP_TCG_Mailer.sendTemporaryPasswordByMail(this, yP_Transaction, yP_Row, string) >= 0) break block42;
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
            return -1;
        }
        yP_Row.persist();
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    private void addRestrictionForMaintenanceAction(YP_Transaction yP_Transaction, long l, List<YP_TCD_DC_Context.Action> list) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        List<YP_Row> list2 = yP_TCD_DCC_Technique.getUserParameters(l, "restrictionForMaintenance");
        if (list2.size() > 1) {
            return;
        }
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
        action.formName = "StandardNoConfirmationForm";
        if (list2.isEmpty()) {
            action.id = "RESTRICTION_FOR_MAINTENANCE_ON";
            action.label = this.getLabel("RESTRICTION_FOR_MAINTENANCE_ON");
        } else {
            action.id = "RESTRICTION_FOR_MAINTENANCE_OFF";
            action.label = this.getLabel("RESTRICTION_FOR_MAINTENANCE_OFF");
        }
        list.add(action);
    }

    private void addMailTlcReportAction(YP_Transaction yP_Transaction, long l, List<YP_TCD_DC_Context.Action> list, int n) {
        if (n != 3) {
            return;
        }
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3 && yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() != l) {
            return;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        List<YP_Row> list3 = this.dataContainerTechnique.getUserParameters(l, "mailTLCReport", "mailTLCReportOff");
        if (list2 == null || list2.isEmpty()) {
            return;
        }
        if (list2.size() == 1 && !list3.isEmpty()) {
            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
            action.formName = "StandardNoConfirmationForm";
            YP_Row yP_Row = list3.get(0);
            String string = yP_Row.getFieldStringValueByName("key");
            if (string.contentEquals("mailTLCReport")) {
                action.id = "MAIL_TLC_REPORT_OFF";
                action.label = this.getLabel("MAIL_TLC_REPORT_OFF");
            } else {
                action.id = "MAIL_TLC_REPORT_ON";
                action.label = this.getLabel("MAIL_TLC_REPORT_ON");
            }
            list.add(action);
        } else {
            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
            action.formName = "StandardGenericForm";
            action.id = "MAIL_TLC_REPORT";
            action.label = this.getLabel("MAIL_TLC_REPORT");
            action.propertiesList = new ArrayList<Property>();
            for (YP_Row yP_Row : list2) {
                String string = yP_Row.getFieldStringValueByName("value");
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("Merchant");
                YP_ComplexGabarit yP_ComplexGabarit2 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
                yP_ComplexGabarit2.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                Property property = new Property();
                property.setName(String.valueOf(string) + "_" + "CHECKBOX_FIELD");
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("checked", false);
                jSONObject.put("previouslyChecked", false);
                jSONObject.put("idMerchant", (Object)string);
                YP_Row yP_Row2 = yP_TCD_DesignAccesObject2.getRowListSuchAs(yP_ComplexGabarit2).get(0);
                jSONObject.put("label", (Object)yP_Row2.getFieldStringValueByName("merchantLabel"));
                if (list3 != null && !list3.isEmpty()) {
                    for (YP_Row yP_Row3 : list3) {
                        String string2;
                        if (!yP_Row3.getFieldStringValueByName("idMerchant").contentEquals(string) || !(string2 = yP_Row3.getFieldStringValueByName("key")).contentEquals("mailTLCReport")) continue;
                        jSONObject.put("checked", true);
                        jSONObject.put("previouslyChecked", true);
                    }
                }
                String object2 = jSONObject.toString();
                property.setValue(object2);
                action.propertiesList.add(property);
            }
            list.add(action);
        }
    }

    private int activateTLCReport(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        String string;
        block13: {
            List<YP_Row> list;
            block12: {
                block11: {
                    long l;
                    block10: {
                        block9: {
                            block8: {
                                try {
                                    int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
                                    if (n == 3) break block8;
                                    this.logger(2, "activateTLCReport() Only for LEVEL_MERCHANT");
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                    return -1;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "activateTLCReport() ", exception);
                                    return -1;
                                }
                            }
                            l = (Long)yP_Row.getFieldValueByName("idUser");
                            string = yP_Row.getFieldStringValueByName("login");
                            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 3 || yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() == l) break block9;
                            this.logger(2, "activateTLCReport() Only for himself");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                            return -1;
                        }
                        int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                        if (n == 1 || n == 2) break block10;
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "activateTLCReport() No rights");
                        return -1;
                    }
                    list = this.dataContainerTechnique.getUserParameters(l, "mailTLCReportOff");
                    if (list != null && !list.isEmpty()) break block11;
                    this.logger(2, "activateTLCReport() No row found for " + string);
                    return -1;
                }
                if (list.size() <= 1) break block12;
                this.logger(2, "activateTLCReport() too many rows found for " + string);
                return -1;
            }
            YP_Row yP_Row2 = list.get(0);
            yP_Row2.set("key", "mailTLCReport");
            if (yP_Row2.persist() == 1) break block13;
            this.logger(2, "activateTLCReport() error during persist for " + string);
            return -1;
        }
        this.logger(4, "activateTLCReport() TLC mails have been activated for " + string);
        return 1;
    }

    private int deactivateTLCReport(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        String string;
        block13: {
            List<YP_Row> list;
            block12: {
                block11: {
                    long l;
                    block10: {
                        block9: {
                            block8: {
                                try {
                                    int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
                                    if (n == 3) break block8;
                                    this.logger(2, "deactivateTLCReport() Only for LEVEL_MERCHANT");
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                    return -1;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "deactivateTLCReport() ", exception);
                                    return -1;
                                }
                            }
                            l = (Long)yP_Row.getFieldValueByName("idUser");
                            string = yP_Row.getFieldStringValueByName("login");
                            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 3 || yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() == l) break block9;
                            this.logger(2, "deactivateTLCReport() Only for himself");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                            return -1;
                        }
                        int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                        if (n == 1 || n == 2) break block10;
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "deactivateTLCReport() No rights");
                        return -1;
                    }
                    list = this.dataContainerTechnique.getUserParameters(l, "mailTLCReport");
                    if (list != null && !list.isEmpty()) break block11;
                    this.logger(2, "deactivateTLCReport() No row found for " + string);
                    return -1;
                }
                if (list.size() <= 1) break block12;
                this.logger(2, "deactivateTLCReport() too many rows found for " + string);
                return -1;
            }
            YP_Row yP_Row2 = list.get(0);
            yP_Row2.set("key", "mailTLCReportOff");
            if (yP_Row2.persist() == 1) break block13;
            this.logger(2, "deactivateTLCReport() error during persist for " + string);
            return -1;
        }
        this.logger(4, "deactivateTLCReport() TLC mails have been deactivated for " + string);
        return 1;
    }

    private int activateRestrictionForMaintenance(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
        if (n != 2) {
            this.logger(2, "activateRestrictionForMaintenance() Only for LEVEL_ADMIN");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            return -1;
        }
        int n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
        if (n2 != 1 && n2 != 2) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "activateRestrictionForMaintenance() No rights");
            return -1;
        }
        long l = (Long)yP_Row.getFieldValueByName("idUser");
        String string = yP_Row.getFieldStringValueByName("login");
        if (!this.dataContainerTechnique.setUserParameter(l, "restrictionForMaintenance", "")) {
            this.logger(2, "activateRestrictionForMaintenance() failed to activate for " + string);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
        this.logger(4, "activateRestrictionForMaintenance() Deactivated for " + string);
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    private int deactivateRestrictionForMaintenance(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
        if (n != 2) {
            this.logger(2, "deactivateRestrictionForMaintenance() Only for LEVEL_ADMIN");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            return -1;
        }
        int n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
        if (n2 != 1 && n2 != 2) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "deactivateRestrictionForMaintenance() No rights");
            return -1;
        }
        long l = (Long)yP_Row.getFieldValueByName("idUser");
        String string = yP_Row.getFieldStringValueByName("login");
        if (!this.dataContainerTechnique.deleteUserParameter(l, "restrictionForMaintenance")) {
            this.logger(2, "deactivateRestrictionForMaintenance() failed to deactivate for " + string);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
        this.logger(4, "deactivateRestrictionForMaintenance() deactivated for " + string);
        YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
        return 1;
    }

    private void addActionFormForHourSelection(YP_TCD_DC_Context.Action action) {
        action.formName = "StandardGenericForm";
        action.propertiesList = new ArrayList<Property>();
        Property property = new Property();
        property.setName("USER_MESSAGE");
        property.setValue(this.getLabel("ENTER_HOUR_HHMM"));
        action.propertiesList.add(property);
        Property property2 = new Property();
        property2.setName("END_DATETIME_TEXT_FIELD");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("label", (Object)"Heure (hh:mm) ");
        jSONObject.put("text", (Object)"00:00");
        String string = jSONObject.toString();
        property2.setValue(string);
        action.propertiesList.add(property2);
    }

    private void addMailGlobalSummaryReportAction(YP_Transaction yP_Transaction, long l, List<YP_TCD_DC_Context.Action> list, int n) {
        Object object;
        Object object2;
        Object object3;
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
        Object object4;
        Object object6;
        Object object7;
        if (n != 3) {
            return;
        }
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3 && yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() != l) {
            return;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        List<YP_Row> list2 = yP_TCD_DesignAccesObject2.getRowListSuchAs(yP_ComplexGabarit);
        List<YP_Row> list3 = this.dataContainerTechnique.getUserParameters(l, "mailGlobalReport", "mailGlobalReportOff");
        if (list2 == null || list2.isEmpty()) {
            return;
        }
        if (list2.size() == 1 && list3.size() == 1) {
            if (list3.isEmpty()) {
                YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
                action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                this.addActionFormForHourSelection(action);
                action.id = "MAIL_GLOBAL_REPORT_ON";
                action.label = this.getLabel("MAIL_GLOBAL_REPORT_ON");
                list.add(action);
                return;
            }
            if (list3.size() > 1) {
                this.logger(2, "addGlobalReportMgtParameter() too many GLOBAL REPORT properties for " + l);
                return;
            }
            object7 = new YP_TCD_DC_Context.Action();
            ((YP_TCD_DC_Context.Action)object7).applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
            object6 = list3.get(0);
            String object52 = ((YP_Row)object6).getFieldStringValueByName("key");
            if (object52.contentEquals("mailGlobalReport")) {
                ((YP_TCD_DC_Context.Action)object7).id = "MAIL_GLOBAL_REPORT_OFF";
                ((YP_TCD_DC_Context.Action)object7).label = this.getLabel("MAIL_GLOBAL_REPORT_OFF");
                ((YP_TCD_DC_Context.Action)object7).formName = "StandardNoConfirmationForm";
            } else {
                ((YP_TCD_DC_Context.Action)object7).id = "MAIL_GLOBAL_REPORT_ON";
                ((YP_TCD_DC_Context.Action)object7).label = this.getLabel("MAIL_GLOBAL_REPORT_ON");
                this.addActionFormForHourSelection((YP_TCD_DC_Context.Action)object7);
            }
            list.add((YP_TCD_DC_Context.Action)object7);
        } else {
            object7 = new YP_TCD_DC_Context.Action();
            ((YP_TCD_DC_Context.Action)object7).applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
            ((YP_TCD_DC_Context.Action)object7).formName = "StandardGenericForm";
            ((YP_TCD_DC_Context.Action)object7).id = "MAIL_GLOBAL_REPORT";
            ((YP_TCD_DC_Context.Action)object7).label = this.getLabel("MAIL_GLOBAL_REPORT");
            ((YP_TCD_DC_Context.Action)object7).propertiesList = new ArrayList<Property>();
            object6 = new Property();
            ((Property)object6).setName("USER_MESSAGE");
            ((Property)object6).setValue("S\u00e9lectionnez les commer\u00e7ants souhait\u00e9s et entrez l'heure d'envoi du rapport");
            ((YP_TCD_DC_Context.Action)object7).propertiesList.add((Property)object6);
            for (YP_Row yP_Row : list2) {
                object4 = yP_Row.getFieldStringValueByName("value");
                yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("Merchant");
                object3 = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                ((YP_ComplexGabarit)object3).set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("value"));
                object2 = new Property();
                ((Property)object2).setName(String.valueOf(object4) + "_" + "CHECKBOX_FIELD");
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("checked", false);
                jSONObject.put("previouslyChecked", false);
                jSONObject.put("idMerchant", object4);
                YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getRowListSuchAs(new YP_ComplexGabarit[]{object3}).get(0);
                jSONObject.put("label", (Object)yP_Row2.getFieldStringValueByName("merchantLabel"));
                if (list3 != null && !list3.isEmpty()) {
                    for (YP_Row yP_Row3 : list3) {
                        String string;
                        if (!yP_Row3.getFieldStringValueByName("idMerchant").contentEquals((CharSequence)object4) || !(string = yP_Row3.getFieldStringValueByName("key")).contentEquals("mailGlobalReport")) continue;
                        jSONObject.put("checked", true);
                        jSONObject.put("previouslyChecked", true);
                    }
                }
                String string = jSONObject.toString();
                ((Property)object2).setValue(string);
                ((YP_TCD_DC_Context.Action)object7).propertiesList.add((Property)object2);
            }
            Property property = new Property();
            property.setName("END_DATETIME_TEXT_FIELD");
            object = new JSONObject();
            object.put("label", (Object)"Heure (hh:mm) ");
            object.put("text", (Object)"00:00");
            object4 = object.toString();
            property.setValue((String)object4);
            ((YP_TCD_DC_Context.Action)object7).propertiesList.add(property);
            list.add((YP_TCD_DC_Context.Action)object7);
        }
        object7 = Calendar.getInstance();
        object6 = UtilsYP.getSystemGMTTime();
        YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
        action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
        action.formName = "StandardGenericForm";
        action.id = "SEND_MAIL_GLOBAL_REPORT";
        action.label = this.getLabel("SEND_MAIL_GLOBAL_REPORT");
        action.propertiesList = new ArrayList<Property>();
        object = new Property();
        ((Property)object).setName("USER_MESSAGE");
        ((Property)object).setValue(this.getLabel("ENTER_DATE_DDMMYYYY"));
        action.propertiesList.add((Property)object);
        object4 = new Property();
        ((Property)object4).setName("START_DATETIME_TEXT_FIELD");
        yP_TCD_DesignAccesObject = new JSONObject();
        yP_TCD_DesignAccesObject.put("label", "Date (JJ/MM/AAAA) ");
        ((Calendar)object7).setTime(((Calendar)object6).getTime());
        ((Calendar)object7).add(6, -1);
        object3 = new SimpleDateFormat("dd/MM/yyyy");
        yP_TCD_DesignAccesObject.put("text", ((DateFormat)object3).format(((Calendar)object7).getTime()));
        object2 = yP_TCD_DesignAccesObject.toString();
        ((Property)object4).setValue((String)object2);
        action.propertiesList.add((Property)object4);
        list.add(action);
    }

    private int addGlobalReportMgtParameter(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action, String string, boolean bl) {
        long l = (Long)yP_Row.getFieldValueByName("idUser");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
        YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
        yP_Row2.set("idUser", l);
        if (bl) {
            yP_Row2.set("key", "mailGlobalReport");
        } else {
            yP_Row2.set("key", "mailGlobalReportOff");
        }
        yP_Row2.set("value", string);
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
        if (yP_TCD_DesignAccesObject2 == null) {
            this.logger(2, "addGlobalReportMgtParameter() unable to retieve UserParameters");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject2);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "merchantAccess");
        List<YP_Row> list = yP_TCD_DesignAccesObject2.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(2, "addGlobalReportMgtParameter() ONo merchant rights found for user " + l);
            return -1;
        }
        if (list.size() > 1) {
            this.logger(2, "addGlobalReportMgtParameter() Only the first merchant will be use");
        }
        long l2 = Long.parseLong(list.get(0).getFieldStringValueByName("value"));
        yP_Row2.set("idMerchant", l2);
        boolean bl2 = false;
        List<YP_TCD_DCC_Brand> list2 = yP_Transaction.getBrandList(false);
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list2) {
            for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                if (yP_TCD_DCC_Merchant.getIDMerchant() != l2) continue;
                bl2 = true;
                break;
            }
            if (bl2) break;
        }
        if (!bl2) {
            this.logger(2, "addGlobalReportMgtParameter() Not exist or no rights");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Not exist or no rights");
            return -1;
        }
        yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getFieldStringValueByName("idUser"));
        yP_ComplexGabarit.set("key", YP_ComplexGabarit.OPERATOR.EQUAL, "mailGlobalReport");
        yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, String.valueOf(l2));
        if (yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit).size() > 0) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(1));
            yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("mailGlobalReport already available");
            this.logger(3, "addGlobalReportMgtParameter() mailGlobalReport already available");
            return 1;
        }
        try {
            yP_Row2.setIsItAClonedRow(false);
            yP_Row2.persist();
        }
        catch (Exception exception) {
            this.logger(2, "addGlobalReportMgtParameter() ", exception);
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int activateGlobalReport(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        try {
            String string;
            int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
            if (n != 3) {
                this.logger(2, "activateGlobalReport() Only for LEVEL_MERCHANT");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            long l = (Long)yP_Row.getFieldValueByName("idUser");
            String string2 = yP_Row.getFieldStringValueByName("login");
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3 && yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() != l) {
                this.logger(2, "activateGlobalReport() Only for himself");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            int n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
            if (n2 != 1 && n2 != 2) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "activateGlobalReport() No rights");
                return -1;
            }
            List<YP_Row> list = this.dataContainerTechnique.getUserParameters(l, "mailGlobalReportOff");
            try {
                string = yP_Transaction.getDataContainerTransaction().createScheduledRequest(yP_Transaction.getApplicationList().get(0), "GSR");
                if (string == null) {
                    this.logger(3, "activateGlobalReport() unable to create the request");
                    return -1;
                }
                Calendar calendar = UtilsYP.getSystemGMTTime();
                calendar.add(6, 1);
                calendar.set(11, 6);
                calendar.set(12, 0);
                calendar.set(13, 0);
                calendar.set(14, 0);
                Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
                yP_Transaction.getPluginByName("Scheduler").dealRequest(yP_Transaction.getApplicationList().get(0).getApplicationPlugin(), "updateCronAction", timestamp, "KERNEL", "", "GSR", "HOST", "00000000", "060000", 0, "00000001000000", 180, 1, 1, string);
            }
            catch (Exception exception) {
                this.logger(2, "activateGlobalReport() error update cron");
            }
            string = "0000";
            if (action.propertiesList != null) {
                for (Property property : action.propertiesList) {
                    if (!property.getName().contentEquals("END_DATETIME_TEXT_FIELD")) continue;
                    JSONObject jSONObject = new JSONObject(property.getValue());
                    string = jSONObject.get("text").toString();
                    if (string == null || string.length() != 5) {
                        this.logger(3, "activateGlobalReport(): invalid length for " + jSONObject.get("label").toString());
                        yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Invalid format hh:mm");
                        return -1;
                    }
                    string = string.replace(":", "");
                }
            }
            if (list == null || list.isEmpty()) {
                if (this.addGlobalReportMgtParameter(yP_Transaction, yP_Row, action, string, true) != 1) {
                    this.logger(2, "activateGlobalReport() error adding MgtParameters");
                    return -1;
                }
                return 1;
            }
            if (list.size() > 1) {
                this.logger(2, "activateGlobalReport() too many rows found for " + string2);
                return -1;
            }
            YP_Row yP_Row2 = list.get(0);
            yP_Row2.set("key", "mailGlobalReport");
            yP_Row2.set("value", string);
            if (yP_Row2.persist() != 1) {
                this.logger(2, "activateGlobalReport() error during persist for " + string2);
                return -1;
            }
            this.logger(4, "activateGlobalReport() Global mails have been activated for " + string2);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "activateGlobalReport() ", exception);
            return -1;
        }
    }

    private int deactivateGlobalReport(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        String string;
        block13: {
            List<YP_Row> list;
            block12: {
                block11: {
                    long l;
                    block10: {
                        block9: {
                            block8: {
                                try {
                                    int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
                                    if (n == 3) break block8;
                                    this.logger(2, "deactivateGlobalReport() Only for LEVEL_MERCHANT");
                                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                                    return -1;
                                }
                                catch (Exception exception) {
                                    this.logger(2, "deactivateGlobalReport() ", exception);
                                    return -1;
                                }
                            }
                            l = (Long)yP_Row.getFieldValueByName("idUser");
                            string = yP_Row.getFieldStringValueByName("login");
                            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 3 || yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() == l) break block9;
                            this.logger(2, "deactivateGlobalReport() Only for himself");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                            return -1;
                        }
                        int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                        if (n == 1 || n == 2) break block10;
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "deactivateGlobalReport() No rights");
                        return -1;
                    }
                    list = this.dataContainerTechnique.getUserParameters(l, "mailGlobalReport");
                    if (list != null && !list.isEmpty()) break block11;
                    this.logger(2, "deactivateGlobalReport() No row found for " + string);
                    return -1;
                }
                if (list.size() <= 1) break block12;
                this.logger(2, "deactivateGlobalReport() too many rows found for " + string);
                return -1;
            }
            YP_Row yP_Row2 = list.get(0);
            yP_Row2.set("key", "mailGlobalReportOff");
            if (yP_Row2.persist() == 1) break block13;
            this.logger(2, "deactivateGlobalReport() error during persist for " + string);
            return -1;
        }
        this.logger(4, "deactivateGlobalReport() Global mails have been deactivated for " + string);
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int sendGlobalReport(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        try {
            int n = (Integer)yP_Row.getFieldValueByName("accessLevel");
            if (n != 3) {
                this.logger(2, "sendGlobalReport() Only for LEVEL_MERCHANT");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            long l = (Long)yP_Row.getFieldValueByName("idUser");
            String string = yP_Row.getFieldStringValueByName("login");
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 3 && yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() != l) {
                this.logger(2, "sendGlobalReport() Only for himself");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            List<YP_Row> list = this.dataContainerTechnique.getUserParameters(l, "mailGlobalReport", "mailGlobalReportOff");
            if ((list == null || list.isEmpty()) && this.addGlobalReportMgtParameter(yP_Transaction, yP_Row, action, "0000", false) != 1) {
                this.logger(2, "sendGlobalReport() error adding MgtParameters for " + string);
                return -1;
            }
            if (list.size() > 1) {
                this.logger(2, "sendGlobalReport() too many rows found for " + string);
                return -1;
            }
            String string2 = null;
            if (action.propertiesList != null) {
                for (List<YP_TCD_DCC_Business> list2 : action.propertiesList) {
                    JSONObject jSONObject;
                    if (!((Property)((Object)list2)).getName().contentEquals("START_DATETIME_TEXT_FIELD") || (string2 = (jSONObject = new JSONObject(((Property)((Object)list2)).getValue())).get("text").toString()) != null && string2.length() == 10) continue;
                    this.logger(3, "sendGlobalReport(): invalid length for " + jSONObject.get("label").toString());
                    yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Invalid format jj/mm/aaaa");
                    return -1;
                }
            }
            if (string2 != null) {
                List<YP_TCD_DCC_Business> list2;
                list2 = yP_Transaction.getApplicationList();
                if (list2 == null) {
                    this.logger(2, "sendGlobalReport() no application List");
                    return -1;
                }
                if (list2.isEmpty()) {
                    this.logger(3, "sendGlobalReport() application List empty");
                    return 0;
                }
                list2.get(0).getDataContainerMerchant().doGlobalReport(yP_Transaction, yP_Row.getFieldStringValueByName("mail"), this.getUserParameterValue(list.get(0), string2));
                this.logger(4, "sendGlobalReport() Mail sent for " + string);
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "sendGlobalReport() ", exception);
            return -1;
        }
    }

    public String getUserParameterValue(YP_Row yP_Row, String string) {
        String string2 = yP_Row.getFieldStringValueByName("value");
        StringBuilder stringBuilder = new StringBuilder();
        if (string2 == null) {
            stringBuilder.append("0000;1");
        } else if (string2.length() <= 4) {
            stringBuilder.append(string2);
            stringBuilder.append(";1");
        }
        stringBuilder.append(";");
        stringBuilder.append(string);
        return stringBuilder.toString();
    }
}

