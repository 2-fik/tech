/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_Brand
extends YP_TCG_View {
    private static final String ASSIGN_APPLICATIONS = "assignApplications";
    private static final String CHECKBOX_FIELD = "CHECKBOX_FIELD";
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Brand(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Brand";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = this.dataContainerTechnique.brand.getFieldByName(string);
            if (field == null) {
                if (this.getLogLevel() < 2) continue;
                this.logger(2, "createEmptyView() unknown column:" + string);
                continue;
            }
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.brand;
            if (yP_TCD_DesignAccesObject != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        Object object2;
        YP_ComplexGabarit yP_ComplexGabarit;
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        List<YP_Gabarit> list2 = yP_PROT_IHM.getSearchGabarit();
        if (list2 != null && !list2.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.brand);
            for (YP_Gabarit object22 : list2) {
                try {
                    if (object22.objectTosearch == null) {
                        yP_ComplexGabarit.set(object22.fieldName, object22.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(object22);
                    if (object22.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(object22.fieldName, object22.operator, object22.objectTosearch);
                }
                catch (Exception list3) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + list3);
                }
            }
        } else {
            yP_ComplexGabarit = null;
        }
        List<YP_TCD_DCC_Brand> list3 = yP_Transaction.getBrandList();
        if (list3 == null) {
            this.logger(2, "getView() no application List");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(2, "getView() application List empty");
            return yP_View;
        }
        HashMap hashMap = new HashMap();
        List<YP_Row> list4 = new ArrayList<YP_Row>();
        for (Object object2 : list3) {
            YP_Row n3 = ((YP_TCD_DCC_Brand)object2).getBrandRow();
            list4.add(n3);
            hashMap.put(n3, object2);
        }
        if ((list4 = YP_TCD_DesignAccesObject.getRowListSuchAs(list4, yP_ComplexGabarit)) == null) {
            this.logger(2, "getView() null list");
            return null;
        }
        if (list4.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        object2 = new YP_ComplexGabarit(this.dataContainerTechnique.application);
        ((YP_ComplexGabarit)object2).set("applicationLabel", YP_ComplexGabarit.OPERATOR.ORDER_ASC);
        List<YP_Row> list5 = this.dataContainerTechnique.application.getRowListSuchAs(new YP_ComplexGabarit[]{object2});
        int n3 = 0;
        while (n3 < list4.size()) {
            Object object3;
            YP_Row yP_Row = list4.get(n3);
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)hashMap.get(yP_Row);
            yP_View.setRowID(n3, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            if (!yP_TCD_DCC_Interface_View.isWriteAllowed(l, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.setRowActionable(n3, false);
            } else {
                yP_View.setRowActionable(n3, true);
                if (list4.size() == 1) {
                    Object object4;
                    Iterable<YP_Row> iterable;
                    ArrayList<YP_TCD_DC_Context.Action> arrayList = new ArrayList<YP_TCD_DC_Context.Action>();
                    Object object5 = new YP_TCD_DC_Context.Action();
                    ((YP_TCD_DC_Context.Action)object5).applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                    ((YP_TCD_DC_Context.Action)object5).formName = "BrandForm";
                    ((YP_TCD_DC_Context.Action)object5).id = "MODIFY_BRAND";
                    ((YP_TCD_DC_Context.Action)object5).label = this.getLabel("MODIFY_BRAND");
                    arrayList.add((YP_TCD_DC_Context.Action)object5);
                    int n4 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
                    if (n4 == 1) {
                        object5 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object5).applicationIdentifier = yP_TCD_DCC_Brand.getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object5).formName = "LoadFileForm";
                        ((YP_TCD_DC_Context.Action)object5).id = "LOAD_CONFIG_FILE";
                        ((YP_TCD_DC_Context.Action)object5).label = this.getLabel("LOAD_CONFIG_FILE");
                        arrayList.add((YP_TCD_DC_Context.Action)object5);
                        ((YP_TCD_DC_Context.Action)object5).propertiesList = new ArrayList<Property>();
                        object3 = new Property();
                        ((Property)object3).setName("USER_MESSAGE");
                        ((Property)object3).setValue(yP_TCD_DCC_Brand.getBrandLabel());
                        ((YP_TCD_DC_Context.Action)object5).propertiesList.add((Property)object3);
                        object3 = new Property();
                        ((Property)object3).setName("MANUFACTURERS");
                        iterable = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
                        StringBuilder stringBuilder = new StringBuilder();
                        boolean bl = true;
                        for (String string : ((YP_TCD_DesignAccesObject)iterable).getDistinctStringValueList("terminalManufacturerID")) {
                            if (!bl) {
                                stringBuilder.append(";");
                            }
                            bl = false;
                            stringBuilder.append(string);
                        }
                        ((Property)object3).setValue(stringBuilder.toString());
                        ((YP_TCD_DC_Context.Action)object5).propertiesList.add((Property)object3);
                        Set<Long> set = this.getIdApplicationInsideBrandSet(yP_TCD_DCC_Brand);
                        object5 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object5).applicationIdentifier = yP_TCD_DCC_Brand.getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object5).formName = "StandardGenericForm";
                        ((YP_TCD_DC_Context.Action)object5).id = ASSIGN_APPLICATIONS;
                        ((YP_TCD_DC_Context.Action)object5).label = this.getLabel(ASSIGN_APPLICATIONS);
                        ((YP_TCD_DC_Context.Action)object5).propertiesList = new ArrayList<Property>();
                        Iterator iterator = list5.iterator();
                        while (iterator.hasNext()) {
                            YP_Row yP_Row2 = (YP_Row)iterator.next();
                            long l2 = (Long)yP_Row2.getFieldValueByName("idApplication");
                            String string = yP_Row2.getFieldStringValueByName("applicationLabel");
                            object4 = new Property();
                            ((Property)object4).setName(String.valueOf(l2) + "_" + CHECKBOX_FIELD);
                            YP_Row yP_Row3 = new JSONObject();
                            if (string == null) {
                                string = "";
                            }
                            yP_Row3.put("label", string);
                            if (set.contains(l2)) {
                                yP_Row3.put("checked", true);
                            } else {
                                yP_Row3.put("checked", false);
                            }
                            yP_Row3.put("idApplication", Long.toString(l2));
                            String string2 = yP_Row3.toString();
                            ((Property)object4).setValue(string2);
                            ((YP_TCD_DC_Context.Action)object5).propertiesList.add((Property)object4);
                        }
                        arrayList.add((YP_TCD_DC_Context.Action)object5);
                    }
                    if (n4 == 1 || n4 == 2) {
                        object5 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object5).applicationIdentifier = yP_TCD_DCC_Brand.getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object5).formName = "ParametersEditionForm";
                        ((YP_TCD_DC_Context.Action)object5).id = "PARAMETERS_EDITION";
                        ((YP_TCD_DC_Context.Action)object5).label = this.getLabel("PARAMETERS_EDITION");
                        ((YP_TCD_DC_Context.Action)object5).propertiesList = new ArrayList<Property>();
                        object3 = this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
                        yP_ComplexGabarit = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object3);
                        yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DCC_Brand.getIDBrand());
                        iterable = ((YP_TCD_DesignAccesObject)object3).getRowListSuchAs(yP_ComplexGabarit);
                        for (YP_Row yP_Row4 : iterable) {
                            Property property = new Property();
                            property.setName(yP_Row4.getFieldStringValueByName("key"));
                            property.setValue(yP_Row4.getFieldStringValueByName("value"));
                            ((YP_TCD_DC_Context.Action)object5).propertiesList.add(property);
                        }
                        List<Long> list6 = this.dataContainerTechnique.getGroupIDs(yP_TCD_DCC_Brand.getIDBrand());
                        if (list6 != null) {
                            object4 = list6.iterator();
                            while (object4.hasNext()) {
                                long l3 = (Long)object4.next();
                                yP_ComplexGabarit = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object3);
                                yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                                iterable = ((YP_TCD_DesignAccesObject)object3).getRowListSuchAs(yP_ComplexGabarit);
                                for (YP_Row yP_Row3 : iterable) {
                                    boolean bl = false;
                                    for (Property property : ((YP_TCD_DC_Context.Action)object5).propertiesList) {
                                        if (!property.getName().contentEquals(yP_Row3.getFieldStringValueByName("key")) && !property.getName().contentEquals("parent_" + yP_Row3.getFieldStringValueByName("key"))) continue;
                                        bl = true;
                                    }
                                    if (bl) continue;
                                    Property property = new Property();
                                    property.setName("parent_" + yP_Row3.getFieldStringValueByName("key"));
                                    property.setValue(yP_Row3.getFieldStringValueByName("value"));
                                    ((YP_TCD_DC_Context.Action)object5).propertiesList.add(property);
                                }
                            }
                        }
                        arrayList.add((YP_TCD_DC_Context.Action)object5);
                    }
                    yP_View.setRowActionList(n3, arrayList);
                }
            }
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                object3 = this.dataContainerTechnique.brand.getFieldByName(string);
                if (object3 != null) {
                    this.addFieldValue(yP_View, (Field)object3, yP_Row, string, n3);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n3;
        }
        return yP_View;
    }

    private Set<Long> getIdApplicationInsideBrandSet(YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        HashSet<Long> hashSet = new HashSet<Long>();
        ArrayList<YP_TCD_DCC_Brand> arrayList = new ArrayList<YP_TCD_DCC_Brand>();
        arrayList.add(yP_TCD_DCC_Brand);
        List<YP_Row> list = this.dataContainerTechnique.getApplicationListInsideBrand(yP_TCD_DCC_Brand);
        if (list != null) {
            for (YP_Row yP_Row : list) {
                hashSet.add((Long)yP_Row.getFieldValueByName("idApplication"));
            }
        }
        return hashSet;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.brand;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", action.applicationIdentifier);
        if (yP_TCD_DCC_Brand == null) {
            return -1;
        }
        try {
            switch (action.id) {
                case "assignApplications": {
                    if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1) return 0;
                    if (action.propertiesList == null) return 0;
                    if (action.propertiesList.isEmpty()) return 0;
                    long l = yP_TCD_DCC_Brand.getIDBrand();
                    Set<Long> set = this.getIdApplicationInsideBrandSet(yP_TCD_DCC_Brand);
                    ArrayList<Long> arrayList = new ArrayList<Long>();
                    ArrayList<Long> arrayList2 = new ArrayList<Long>();
                    Iterator<Property> iterator = action.propertiesList.iterator();
                    while (true) {
                        if (!iterator.hasNext()) {
                            if (arrayList.size() <= 0) {
                                if (arrayList2.size() <= 0) return 0;
                            }
                            this.dataContainerTechnique.updateApplicationInsideBrand(l, arrayList, arrayList2, true);
                            return 0;
                        }
                        Property property = iterator.next();
                        if (!property.getName().contains(CHECKBOX_FIELD)) continue;
                        JSONObject jSONObject = new JSONObject(property.getValue());
                        String string = jSONObject.get("checked").toString();
                        if (string == null || !string.contentEquals("true") && !string.contentEquals("false")) {
                            this.logger(2, "executeAction() invalid checked value for " + jSONObject.get("label").toString());
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                            return -1;
                        }
                        long l2 = Long.parseLong(jSONObject.get("idApplication").toString());
                        if (Boolean.parseBoolean(string)) {
                            if (set.contains(l2)) continue;
                            arrayList.add(l2);
                            continue;
                        }
                        if (!set.contains(l2)) continue;
                        arrayList2.add(l2);
                    }
                }
            }
            return yP_TCD_DCC_Brand.executeAction(yP_Transaction, this.toString(), yP_Row, action);
        }
        catch (Exception exception) {
            if (this.getLogLevel() < 2) return -1;
            this.logger(2, "executeAction() " + exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Key must not be set !");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() not really possible !!!");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                String string2 = null;
                String string3 = null;
                int n2 = 0;
                block22: for (String string4 : yP_View.getColumnSet()) {
                    String string5 = yP_View.getFieldValueAt(n, string4);
                    if (string5 == null) continue;
                    switch (string4) {
                        case "idBrand": {
                            if (string5.isEmpty()) continue block22;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() Key should be empty :" + string4);
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "brandName": {
                            string2 = string5;
                            yP_Row.set(string4, string2);
                            break;
                        }
                        case "brandLabel": {
                            string3 = string5;
                            yP_Row.set(string4, string3);
                            break;
                        }
                        case "connectorType": {
                            n2 = Integer.parseInt(string5);
                            yP_Row.set(string4, n2);
                            break;
                        }
                        default: {
                            if (this.getLogLevel() < 2) continue block22;
                            this.logger(2, "createInView() unknown field :" + string4);
                        }
                    }
                }
                if (string3 == null || string3.isEmpty()) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() mandatory value missing brandLabel");
                    }
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                    return -1;
                }
                if (n2 == 0) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "createInView() connectorType has not been sent, we must check if we have to refuse or use the only one");
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SELECT count(DISTINCT connectorType) AS count FROM ");
                    stringBuilder.append(yP_TCD_DesignAccesObject.getFullTableName());
                    long l = yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "createInView() connectorType retrieve:" + l);
                    }
                    if (l != 1L) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() mandatory value missing connectorType");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                        return -1;
                    }
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("SELECT MAX(connectorType) AS count FROM ");
                    stringBuilder2.append(yP_TCD_DesignAccesObject.getFullTableName());
                    n2 = (int)yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder2.toString());
                    yP_Row.set("connectorType", n2);
                }
                try {
                    yP_TCD_DesignAccesObject.lock();
                    if (string2 == null || string2.isEmpty()) {
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "createInView() brandName has not been sent, we must create one");
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("SELECT MAX(CAST(brandName AS Int)) AS count FROM " + yP_TCD_DesignAccesObject.getFullTableName() + "\r\n");
                        stringBuilder.append("WHERE brandName NOT LIKE '%[a-z]%'");
                        long l = yP_TCD_DesignAccesObject.getDataBaseConnector().dealCountQuery(yP_TCD_DesignAccesObject, stringBuilder.toString());
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "createInView() brandName retrieve:" + l);
                        }
                        if (l <= 0L) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() Unable to retrieve biggest brandName");
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(6));
                            return -1;
                        }
                        string2 = String.format("%03d", ++l);
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "createInView() new brandName :" + string2);
                        }
                        yP_Row.set("brandName", string2);
                    } else {
                        if (string2.contains("_")) {
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() brandName must not contains '_'");
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers) {
                            if (!yP_TCD_DCC_Brand.getContractIdentifier().contentEquals(string2)) continue;
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "createInView() Brand name exists already:brandName");
                            }
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                            return -1;
                        }
                    }
                    if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) < 0) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() Not able to add row...");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    if (yP_TCD_DesignAccesObject.persist() < 0) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() Not able to save changes...");
                        }
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                }
                finally {
                    yP_TCD_DesignAccesObject.unlock();
                }
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = this.dataContainerTechnique.loadBrandByPrimaryKey(yP_Row.getPrimaryKey());
                yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers.add(yP_TCD_DCC_Brand);
                this.getPluginByName("User").dealRequest(this, "updateUserAccesContext", yP_Transaction.getDataContainerTransaction().userHandler.getUserUID());
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createInView() " + exception);
            }
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }
}

