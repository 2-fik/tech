/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.util.Calendar;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.YP_TCG_Mailer;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.physicals.YP_TCD_PHYS_HTTPS_Network;
import org.yp.framework.services.YP_TS_CryptoManager;
import org.yp.framework.services.YP_TS_FileContentManager;
import org.yp.utils.ByteBuilder;
import org.yp.utils.UtilsYP;
import org.yp.utils.ZipUtils;

public class YP_TCG_EventLogger
extends YP_GlobalComponent {
    public static LogMethod logMethod = LogMethod.byProcess;
    private static final boolean logWithNanoTimeForDebug = false;
    private final boolean flushMode = false;
    private int nbBackupLogFiles = 20;
    private int nbLogsByFile = 50000;
    private int nbSyslogsByFile = 100000;
    public static boolean activateSQLLogs = false;
    public static boolean activateSlowSQLLogs = true;
    private int nbBackupTrsFiles = 100;
    private int nbTrsByFile = 50000;
    public static final String SLEVEL_DEV = "*DEV*";
    public static final String SLEVEL_DEBUG = "DEBUG";
    public static final String SLEVEL_INFO = "INFO ";
    public static final String SLEVEL_WARN = "WARN ";
    public static final String SLEVEL_ERROR = "ERROR";
    public static final String SLEVEL_FATAL = "FATAL";
    public static final String SLEVEL_UNKNOWN = "?????";
    public static final String SLEVEL_TRS = " TRS ";
    private static final int MAX_LOG_SIZE_ON_CONSOLE = 10000;
    private static final long MAX_GLOBAL_LOG_FILE_SIZE = 2000000000L;
    private int nbGlobalBackupLogFiles = 10;
    private long maxGlobalLogFileSize = 2000000000L;
    private boolean activateGlobalLog = false;
    private boolean tooManyGlobalLog = false;
    private final ReentrantLock globalLogMutex = new ReentrantLock();
    private final StringBuilder messageToSendByMail = new StringBuilder();
    private final ReentrantLock messageToSendByMailMutex = new ReentrantLock();
    public String emailForErrorLogs;
    private long topForNewErrorMail = 0L;
    private static final int MIN_TIME_BETWEEN_ERROR_MAILS_MS = 1800000;
    private static final int MAX_EMAIL_SIZE = 25000;
    private static final String LOG_STARTED = "LOG STARTED";
    private static final String LOG_ENDED = "LOG ENDED";
    private static final String LOG_SIGN_ALGO_NONE = "NONE";
    private static final String LOG_SIGN_ALGO_SHA256_ENCRYPT = "SHA256-ENCRYPT";
    private String logSignKeyLabel = "";
    private String logSignAlgo = "NONE";
    private FileChannelAndName globalFileChannelAndName;
    private final ReentrantLock tokenFileMutex = new ReentrantLock();
    private PrintWriter tokenPrintWriter = null;
    private final ReentrantLock sqlFileMutex = new ReentrantLock();
    private PrintWriter sqlPrintWriter = null;
    private final ReentrantLock sqlSensitiveFileMutex = new ReentrantLock();
    private PrintWriter sqlSensitivePrintWriter = null;
    private final ReentrantLock sqlSlowFileMutex = new ReentrantLock();
    private PrintWriter sqlSlowPrintWriter = null;
    private final Map<String, FileChannelAndName> fileWriterList = new HashMap<String, FileChannelAndName>();
    private static final Calendar myGlobalCalendar = UtilsYP.getCalendar(System.currentTimeMillis());
    private static long lastTimeMillis = 0L;
    private static int lastYear;
    private static int lastMonth;
    private static int lastDay;
    private static int lastHour;
    private static int lastMinute;
    private static int lastSeconde;
    private static int lastMillisecondes;
    private String lastAAAAMMJJ = null;
    private static final ByteBuffer lineSeparatorBuffer;
    private static final ReentrantLock sysLogsMutex;

    static {
        lineSeparatorBuffer = ByteBuffer.wrap(UtilsYP.lineSeparator.getBytes());
        sysLogsMutex = new ReentrantLock();
    }

    public YP_TCG_EventLogger(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        Runtime.getRuntime().addShutdownHook(new Thread(){

            @Override
            public void run() {
                YP_TCG_EventLogger.this.closeAll();
            }
        });
    }

    @Override
    public int initialize() {
        String string;
        block35: {
            super.initialize();
            string = this.getProperty(this.getPropertyFileName(), "logSignKeyLabel");
            if (string != null && !string.isEmpty()) {
                this.logSignKeyLabel = string;
            }
            if ((string = this.getProperty(this.getPropertyFileName(), "logSignAlgo")) == null || string.isEmpty()) break block35;
            switch (this.logSignAlgo) {
                case "NONE": 
                case "SHA256-ENCRYPT": {
                    this.logSignAlgo = string;
                    break;
                }
                default: {
                    System.out.println("YP_TCG_EventLogger unknown algo" + string);
                }
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbBackupLogFiles")) != null) {
            this.nbBackupLogFiles = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbLogsByFile")) != null) {
            this.nbLogsByFile = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbBackupTrsFiles")) != null) {
            this.nbBackupTrsFiles = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbTrsByFile")) != null) {
            this.nbTrsByFile = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "maxGlobalLogFileSize")) != null) {
            this.maxGlobalLogFileSize = Long.parseLong(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbGlobalBackupLogFiles")) != null) {
            this.nbGlobalBackupLogFiles = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "activateGlobalLog")) != null) {
            if (string.contentEquals("1") || string.toLowerCase().contentEquals("true")) {
                this.activateGlobalLog = true;
            } else if (string.contentEquals("0") || string.toLowerCase().contentEquals("false")) {
                this.activateGlobalLog = false;
            } else {
                this.logger(2, "initialize() bad value for activateGlobalLog:" + string);
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "activateSQLLogs")) != null) {
            if (string.contentEquals("1") || string.toLowerCase().contentEquals("true")) {
                activateSQLLogs = true;
            } else if (string.contentEquals("0") || string.toLowerCase().contentEquals("false")) {
                activateSQLLogs = false;
            } else {
                this.logger(2, "initialize() bad value for activateSQLLogs:" + string);
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "activateSlowSQLLogs")) != null) {
            if (string.contentEquals("1") || string.toLowerCase().contentEquals("true")) {
                activateSlowSQLLogs = true;
            } else if (string.contentEquals("0") || string.toLowerCase().contentEquals("false")) {
                activateSlowSQLLogs = false;
            } else {
                this.logger(2, "initialize() bad value for activateSlowSQLLogs:" + string);
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "logMethod")) != null) {
            try {
                logMethod = LogMethod.valueOf(string);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                illegalArgumentException.printStackTrace();
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "emailForErrorLogs")) != null) {
            this.emailForErrorLogs = string;
        }
        return 1;
    }

    @Override
    public String toString() {
        return "EventLogger";
    }

    @Override
    public String getVersion() {
        return "V1.1.0.0";
    }

    public int makeLog(YP_Object yP_Object, int n, String string) {
        block23: {
            if (yP_Object.getLogLevel() >= n) break block23;
            return 0;
        }
        try {
            MessageLogInfoEnumeration messageLogInfoEnumeration;
            switch (n) {
                case 6: {
                    this.dealLog(yP_Object, string, SLEVEL_DEV, WhatForEnumeration.Logs);
                    break;
                }
                case 5: {
                    this.dealLog(yP_Object, string, SLEVEL_DEBUG, WhatForEnumeration.Logs);
                    break;
                }
                case 4: {
                    this.dealLog(yP_Object, string, SLEVEL_INFO, WhatForEnumeration.Logs);
                    break;
                }
                case 3: {
                    this.dealLog(yP_Object, string, SLEVEL_WARN, WhatForEnumeration.Logs);
                    break;
                }
                case 2: {
                    this.dealLog(yP_Object, string, SLEVEL_ERROR, WhatForEnumeration.Logs);
                    break;
                }
                case 1: {
                    this.dealLog(yP_Object, string, SLEVEL_FATAL, WhatForEnumeration.Logs);
                    break;
                }
                case -2: {
                    this.dealToken(string);
                    break;
                }
                case -4: {
                    this.dealSQL(string);
                    break;
                }
                case -5: {
                    this.dealSensitiveSQL(string);
                    break;
                }
                case -6: {
                    this.dealSlowSQL(string);
                    break;
                }
                case -3: {
                    this.dealLog(yP_Object, string, SLEVEL_TRS, WhatForEnumeration.DuplicateTransactions);
                    break;
                }
                case -1: {
                    this.dealLog(yP_Object, string, SLEVEL_TRS, WhatForEnumeration.Transactions);
                    break;
                }
                default: {
                    this.dealLog(yP_Object, string, SLEVEL_UNKNOWN, WhatForEnumeration.Logs);
                }
            }
            if ((n == 2 || n == 1) && (messageLogInfoEnumeration = this.getMessageLogInfo(string)) != MessageLogInfoEnumeration.DO_NOT_LOG) {
                if (n == 2) {
                    this.dealLog(yP_Object, string, SLEVEL_ERROR, WhatForEnumeration.ErrorLogs);
                } else {
                    this.dealLog(yP_Object, string, SLEVEL_FATAL, WhatForEnumeration.ErrorLogs);
                }
                if (UtilsYP.getSilenceMode() == 1) {
                    System.out.println(string);
                }
                if (messageLogInfoEnumeration == MessageLogInfoEnumeration.NONE) {
                    ++n;
                }
            }
        }
        catch (Exception exception) {
            if (string != null) {
                System.out.println(string);
            }
            exception.printStackTrace();
        }
        return 1;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "makeLog": {
                    int n = (Integer)objectArray[0];
                    String string2 = (String)objectArray[1];
                    return this.makeLog(yP_Object, n, string2);
                }
                case "flushLog": {
                    return this.flushLog();
                }
                case "sysLog": {
                    int n = (Integer)objectArray[0];
                    String string3 = (String)objectArray[1];
                    return this.sysLog(yP_Object, n, string3);
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    private int addLogToMail(String string) {
        if (this.emailForErrorLogs == null || this.emailForErrorLogs.isEmpty()) {
            return 0;
        }
        if (this.messageToSendByMail.length() > 25000) {
            return 0;
        }
        try {
            this.messageToSendByMailMutex.lock();
            this.messageToSendByMail.append(string);
            this.messageToSendByMail.append(UtilsYP.lineSeparator);
        }
        finally {
            this.messageToSendByMailMutex.unlock();
        }
        return 1;
    }

    private int dealToken(String string) {
        this.tokenFileMutex.lock();
        try {
            if (this.tokenPrintWriter == null) {
                try {
                    String string2 = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                    new File(String.valueOf(UtilsYP.getTokenPath()) + string2 + "/").mkdirs();
                    this.tokenPrintWriter = new PrintWriter(new FileWriter(String.valueOf(UtilsYP.getTokenPath()) + string2 + "/tokentable_" + UtilsYP.getInstanceNumber() + ".log", true));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.tokenFileMutex.unlock();
                    return -1;
                }
            }
            this.tokenPrintWriter.println(string);
            return 1;
        }
        catch (Exception exception) {
            if (string != null) {
                System.out.println(string);
            }
            exception.printStackTrace();
            return -1;
        }
        finally {
            this.tokenFileMutex.unlock();
        }
    }

    private int dealSQL(String string) {
        if (!activateSQLLogs) {
            return 0;
        }
        if (string == null || string.isEmpty()) {
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder(string);
        stringBuilder.append(UtilsYP.lineSeparator);
        stringBuilder.append("GO");
        this.sqlFileMutex.lock();
        try {
            if (this.sqlPrintWriter == null) {
                try {
                    String string2 = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                    new File(String.valueOf(UtilsYP.getSqlLogsPath()) + string2 + "/").mkdirs();
                    this.sqlPrintWriter = new PrintWriter(new FileWriter(String.valueOf(UtilsYP.getSqlLogsPath()) + string2 + "/sqllogs_" + UtilsYP.getInstanceNumber() + ".log", true));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.sqlFileMutex.unlock();
                    return -1;
                }
            }
            this.sqlPrintWriter.println(stringBuilder.toString());
            return 1;
        }
        catch (Exception exception) {
            if (string != null) {
                System.out.println(string);
            }
            exception.printStackTrace();
            return -1;
        }
        finally {
            this.sqlFileMutex.unlock();
        }
    }

    private int dealSensitiveSQL(String string) {
        if (!activateSQLLogs) {
            return 0;
        }
        if (string == null || string.isEmpty()) {
            return 0;
        }
        StringBuilder stringBuilder = new StringBuilder(string);
        stringBuilder.append(UtilsYP.lineSeparator);
        stringBuilder.append("GO");
        this.sqlSensitiveFileMutex.lock();
        try {
            if (this.sqlSensitivePrintWriter == null) {
                try {
                    String string2 = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                    new File(String.valueOf(UtilsYP.getSqlSensitiveLogsPath()) + string2 + "/").mkdirs();
                    this.sqlSensitivePrintWriter = new PrintWriter(new FileWriter(String.valueOf(UtilsYP.getSqlSensitiveLogsPath()) + string2 + "/sqlsensitivelogs_" + UtilsYP.getInstanceNumber() + ".log", true));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.sqlSensitiveFileMutex.unlock();
                    return -1;
                }
            }
            this.sqlSensitivePrintWriter.println(stringBuilder.toString());
            return 1;
        }
        catch (Exception exception) {
            if (string != null) {
                System.out.println(string);
            }
            exception.printStackTrace();
            return -1;
        }
        finally {
            this.sqlSensitiveFileMutex.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int dealSlowSQL(String string) {
        try {
            if (!activateSlowSQLLogs) {
                return 0;
            }
            if (string == null) return 0;
            if (string.isEmpty()) {
                return 0;
            }
            long l = System.currentTimeMillis();
            if (lastTimeMillis != l) {
                myGlobalCalendar.setTimeInMillis(l);
                lastTimeMillis = l;
                lastYear = myGlobalCalendar.get(1);
                lastMonth = myGlobalCalendar.get(2) + 1;
                lastDay = myGlobalCalendar.get(5);
                lastHour = myGlobalCalendar.get(11);
                lastMinute = myGlobalCalendar.get(12);
                lastSeconde = myGlobalCalendar.get(13);
                lastMillisecondes = myGlobalCalendar.get(14);
            }
            int n = lastYear;
            int n2 = lastMonth;
            int n3 = lastDay;
            int n4 = lastHour;
            int n5 = lastMinute;
            int n6 = lastSeconde;
            int n7 = lastMillisecondes;
            StringBuilder stringBuilder = new StringBuilder();
            this.appendDateTime(stringBuilder, n, n2, n3, n4, n5, n6, n7);
            stringBuilder.append(string.replaceAll("\\n", ""));
            try {
                this.sqlSlowFileMutex.lock();
                if (this.sqlSlowPrintWriter == null) {
                    try {
                        String string2 = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                        new File(String.valueOf(UtilsYP.getSqlSlowLogsPath()) + string2 + "/").mkdirs();
                        this.sqlSlowPrintWriter = new PrintWriter(new FileWriter(String.valueOf(UtilsYP.getSqlSlowLogsPath()) + string2 + "/sqlslowlogs_" + UtilsYP.getInstanceNumber() + ".log", true));
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        this.sqlSlowFileMutex.unlock();
                        return -1;
                    }
                }
                this.sqlSlowPrintWriter.println(stringBuilder.toString());
                return 1;
            }
            finally {
                this.sqlSlowFileMutex.unlock();
            }
        }
        catch (Exception exception) {
            if (string != null) {
                System.out.println(string);
            }
            exception.printStackTrace();
            return -1;
        }
    }

    private FileChannelAndName getFileWriterByName(String string, WhatForEnumeration whatForEnumeration, int n, int n2, int n3, String string2) {
        FileChannelAndName fileChannelAndName = this.fileWriterList.get(string);
        if (fileChannelAndName == null || fileChannelAndName.fileChannel == null) {
            fileChannelAndName = this.addFileChannel(string, whatForEnumeration, n, n2, n3, string2, true);
        }
        if (fileChannelAndName != null) {
            ++fileChannelAndName.nbAcess;
        }
        return fileChannelAndName;
    }

    private FileChannelAndName addFileChannel(String string, WhatForEnumeration whatForEnumeration, int n, int n2, int n3, String string2, boolean bl) {
        FileChannelAndName fileChannelAndName = null;
        try {
            try {
                fileChannelAndName = new FileChannelAndName(string, whatForEnumeration, new FileOutputStream(string, true).getChannel());
                this.lock();
                this.fileWriterList.put(string, fileChannelAndName);
            }
            finally {
                this.unlock();
            }
        }
        catch (Exception exception) {
            if (!bl) {
                return null;
            }
            ByteBuilder byteBuilder = new ByteBuilder();
            byteBuilder.append(YP_TCG_EventLogger.getDirectory(whatForEnumeration));
            byteBuilder.append(n);
            if (n2 < 10) {
                byteBuilder.append('0');
            }
            byteBuilder.append(n2);
            if (n3 < 10) {
                byteBuilder.append('0');
            }
            byteBuilder.append(n3);
            byteBuilder.append('/');
            if (string2 != null && !string2.isEmpty()) {
                byteBuilder.append(string2);
                byteBuilder.append('/');
            }
            new File(byteBuilder.toString()).mkdirs();
            return this.addFileChannel(string, whatForEnumeration, n, n2, n3, string2, false);
        }
        this.appendHeaderLog(fileChannelAndName);
        return fileChannelAndName;
    }

    private static String getDirectory(WhatForEnumeration whatForEnumeration) {
        switch (whatForEnumeration) {
            case ErrorLogs: {
                return UtilsYP.getErrorLogsPath();
            }
            case Syslogs: {
                return UtilsYP.getSysLogsPath();
            }
            case Transactions: 
            case DuplicateTransactions: {
                return UtilsYP.getTrsPath();
            }
            case Logs: {
                return UtilsYP.getLogPath();
            }
        }
        return null;
    }

    private static String getFileName(WhatForEnumeration whatForEnumeration) {
        switch (whatForEnumeration) {
            case ErrorLogs: {
                return "errors_" + UtilsYP.getInstanceNumber() + ".log";
            }
            case Syslogs: {
                return "syslogs_" + UtilsYP.getInstanceNumber() + ".log";
            }
            case Transactions: {
                return "transactions_" + UtilsYP.getInstanceNumber() + ".log";
            }
            case DuplicateTransactions: {
                return "duplicate_transactions_" + UtilsYP.getInstanceNumber() + ".log";
            }
            case Logs: {
                return null;
            }
        }
        return null;
    }

    private static LogMethod getLogMethod(WhatForEnumeration whatForEnumeration) {
        switch (whatForEnumeration) {
            case ErrorLogs: 
            case Transactions: 
            case DuplicateTransactions: 
            case Syslogs: {
                return LogMethod.byNothing;
            }
            case Logs: {
                return logMethod;
            }
        }
        return null;
    }

    private int dealLog(YP_Object yP_Object, String string, String string2, WhatForEnumeration whatForEnumeration) {
        FileChannelAndName fileChannelAndName;
        YP_Process yP_Process;
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        block40: {
            String[] stringArray;
            String string3;
            long l;
            block39: {
                try {
                    long l2 = System.currentTimeMillis();
                    if (lastTimeMillis != l2) {
                        myGlobalCalendar.setTimeInMillis(l2);
                        lastTimeMillis = l2;
                        lastYear = myGlobalCalendar.get(1);
                        lastMonth = myGlobalCalendar.get(2) + 1;
                        lastDay = myGlobalCalendar.get(5);
                        lastHour = myGlobalCalendar.get(11);
                        lastMinute = myGlobalCalendar.get(12);
                        lastSeconde = myGlobalCalendar.get(13);
                        lastMillisecondes = myGlobalCalendar.get(14);
                    }
                    n7 = lastYear;
                    n6 = lastMonth;
                    n5 = lastDay;
                    n4 = lastHour;
                    n3 = lastMinute;
                    n2 = lastSeconde;
                    n = lastMillisecondes;
                    l = Thread.currentThread().getId();
                    yP_Process = yP_Object.getAncestor();
                    if (yP_Process != null) break block39;
                    System.out.println(string);
                    return -1;
                }
                catch (Exception exception) {
                    if (string != null) {
                        System.out.println(string);
                    }
                    exception.printStackTrace();
                    return -1;
                }
            }
            if (l != yP_Process.getThreadID()) {
                yP_Process = this.getProcessPluginByThreadID(l);
            }
            if (yP_Process == null && (yP_Object instanceof YP_TCG_Mailer || yP_Object instanceof YP_TS_FileContentManager || yP_Object instanceof YP_TCD_PHYS_HTTPS_Network)) {
                yP_Process = yP_Object.getAncestor();
            }
            ByteBuilder byteBuilder = new ByteBuilder(128);
            byteBuilder.append(YP_TCG_EventLogger.getDirectory(whatForEnumeration));
            byteBuilder.append(n7);
            if (n6 < 10) {
                byteBuilder.append('0');
            }
            byteBuilder.append(n6);
            if (n5 < 10) {
                byteBuilder.append('0');
            }
            byteBuilder.append(n5);
            byteBuilder.append('/');
            LogMethod logMethod = YP_TCG_EventLogger.getLogMethod(whatForEnumeration);
            if (logMethod == LogMethod.byNothing) {
                string3 = null;
            } else {
                if (yP_Process == null) {
                    string3 = "ORPHANS";
                } else {
                    switch (logMethod) {
                        case byBrand: {
                            stringArray = yP_Process.getContractIdentifier().split("_");
                            string3 = stringArray[0];
                            break;
                        }
                        case byMerchant: {
                            stringArray = yP_Process.getContractIdentifier().split("_");
                            if (stringArray.length > 1) {
                                string3 = String.valueOf(stringArray[0]) + "_" + stringArray[1];
                                break;
                            }
                            string3 = stringArray[0];
                            break;
                        }
                        case byNothing: {
                            string3 = "";
                            break;
                        }
                        case byProcess: {
                            string3 = yP_Process.toString();
                            break;
                        }
                        default: {
                            string3 = yP_Process.getContractIdentifier();
                        }
                    }
                }
                byteBuilder.append(string3);
                byteBuilder.append('/');
            }
            stringArray = YP_TCG_EventLogger.getFileName(whatForEnumeration);
            if (stringArray != null) {
                byteBuilder.append((String)stringArray);
            } else {
                if (yP_Process != null) {
                    byteBuilder.append(yP_Process.getSimpleName());
                } else {
                    byteBuilder.append(Thread.currentThread().getName());
                }
                byteBuilder.append('_');
                byteBuilder.append(UtilsYP.getInstanceNumber());
                byteBuilder.append('_');
                if (yP_Process != null) {
                    int n8 = yP_Process.getRankInFatherChildList();
                    if (n8 < 1000) {
                        byteBuilder.append('0');
                        if (n8 < 100) {
                            byteBuilder.append('0');
                            if (n8 < 10) {
                                byteBuilder.append('0');
                            }
                        }
                    }
                    byteBuilder.append(n8);
                }
                byteBuilder.append(".log");
            }
            fileChannelAndName = this.getFileWriterByName(byteBuilder.toString(), whatForEnumeration, n7, n6, n5, string3);
            if (fileChannelAndName != null) break block40;
            if (string != null) {
                System.out.println(string);
            }
            return -1;
        }
        try {
            Object object;
            fileChannelAndName.lock();
            ByteBuilder byteBuilder = fileChannelAndName.byteBuilderData;
            int n9 = byteBuilder.size();
            this.createLog(yP_Object, string, string2, yP_Process, fileChannelAndName, byteBuilder, n7, n6, n5, n4, n3, n2, n);
            if (UtilsYP.getSilenceMode() == 0 && whatForEnumeration == WhatForEnumeration.Logs) {
                object = byteBuilder.substring(n9);
                if (((String)object).length() > 10000) {
                    object = ((String)object).substring(0, 10000);
                }
                System.out.println((String)object);
            }
            if (whatForEnumeration == WhatForEnumeration.ErrorLogs && (object = this.getMessageLogInfo(string)) != MessageLogInfoEnumeration.DO_NOT_MAIL) {
                this.addLogToMail(byteBuilder.substring(n9));
            }
            if (whatForEnumeration == WhatForEnumeration.Syslogs) {
                this.addLogToSysLog(byteBuilder.substring(n9));
            }
            byteBuilder.append(UtilsYP.lineSeparator);
            if (whatForEnumeration != WhatForEnumeration.Transactions && whatForEnumeration != WhatForEnumeration.DuplicateTransactions && whatForEnumeration != WhatForEnumeration.ErrorLogs && whatForEnumeration != WhatForEnumeration.Syslogs) {
                this.appendToGlobalLog(byteBuilder, n9);
            }
            if (yP_Process == null || whatForEnumeration.equals((Object)WhatForEnumeration.Transactions)) {
                this.flushLog(fileChannelAndName);
            }
        }
        finally {
            fileChannelAndName.unlock();
        }
        {
        }
    }

    private int mailErrorLogs() {
        String string;
        if (this.messageToSendByMail.length() == 0) {
            return 0;
        }
        long l = System.currentTimeMillis();
        if (this.topForNewErrorMail > l) {
            return 0;
        }
        if (this.emailForErrorLogs == null || this.emailForErrorLogs.isEmpty()) {
            return 0;
        }
        this.topForNewErrorMail = l + 1800000L;
        try {
            this.messageToSendByMailMutex.lock();
            string = this.messageToSendByMail.toString();
            this.messageToSendByMail.setLength(0);
        }
        finally {
            this.messageToSendByMailMutex.unlock();
        }
        String string2 = " Errors from ";
        try {
            string2 = String.valueOf(string2) + new File(".").getCanonicalPath();
        }
        catch (IOException iOException) {
            this.logger(2, "mailErrorLogs() pb during retrieving path" + iOException);
        }
        string2 = String.valueOf(string2) + " ";
        string2 = String.valueOf(string2) + UtilsYP.getInstanceNumber();
        try {
            this.getPluginByName("Mailer").dealRequest(this, "sendMail", this.emailForErrorLogs, string2, string);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "mailErrorLogs() pb during mail" + exception);
            return -1;
        }
    }

    private int flushLog() {
        block46: {
            block44: {
                block42: {
                    block40: {
                        this.mailErrorLogs();
                        try {
                            try {
                                this.tokenFileMutex.lock();
                                if (this.tokenPrintWriter != null) {
                                    this.tokenPrintWriter.flush();
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                this.tokenFileMutex.unlock();
                                break block40;
                            }
                        }
                        catch (Throwable throwable) {
                            this.tokenFileMutex.unlock();
                            throw throwable;
                        }
                        this.tokenFileMutex.unlock();
                    }
                    try {
                        try {
                            this.sqlFileMutex.lock();
                            if (this.sqlPrintWriter != null) {
                                this.sqlPrintWriter.flush();
                            }
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            this.sqlFileMutex.unlock();
                            break block42;
                        }
                    }
                    catch (Throwable throwable) {
                        this.sqlFileMutex.unlock();
                        throw throwable;
                    }
                    this.sqlFileMutex.unlock();
                }
                try {
                    try {
                        this.sqlSensitiveFileMutex.lock();
                        if (this.sqlSensitivePrintWriter != null) {
                            this.sqlSensitivePrintWriter.flush();
                        }
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        this.sqlSensitiveFileMutex.unlock();
                        break block44;
                    }
                }
                catch (Throwable throwable) {
                    this.sqlSensitiveFileMutex.unlock();
                    throw throwable;
                }
                this.sqlSensitiveFileMutex.unlock();
            }
            try {
                try {
                    this.sqlSlowFileMutex.lock();
                    if (this.sqlSlowPrintWriter != null) {
                        this.sqlSlowPrintWriter.flush();
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.sqlSlowFileMutex.unlock();
                    break block46;
                }
            }
            catch (Throwable throwable) {
                this.sqlSlowFileMutex.unlock();
                throw throwable;
            }
            this.sqlSlowFileMutex.unlock();
        }
        try {
            this.flushGlobalLog();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
        boolean bl = false;
        if (this.lastAAAAMMJJ == null) {
            this.lastAAAAMMJJ = string;
        } else if (this.lastAAAAMMJJ.compareTo(string) != 0) {
            this.lastAAAAMMJJ = string;
            this.closeToken();
            this.closeSQL();
            this.closeGlobalLog();
            this.tooManyGlobalLog = false;
        } else {
            bl = true;
        }
        try {
            Iterator<Map.Entry<String, FileChannelAndName>> iterator = this.fileWriterList.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, FileChannelAndName> entry = iterator.next();
                FileChannelAndName fileChannelAndName = entry.getValue();
                this.flushLog(fileChannelAndName);
                if (!bl || fileChannelAndName.name.indexOf(string) != -1) continue;
                try {
                    fileChannelAndName.lock();
                    if (fileChannelAndName.byteBuilderData.length() == 0) {
                        this.closeFile(fileChannelAndName);
                        iterator.remove();
                    } else {
                        this.logger(2, "flushLog() Should not be possible !");
                    }
                }
                catch (ConcurrentModificationException concurrentModificationException) {
                    this.logger(3, "flushLog()" + concurrentModificationException);
                    fileChannelAndName.unlock();
                    continue;
                }
                catch (Exception exception) {
                    try {
                        this.logger(2, "flushLog()" + exception);
                        continue;
                    }
                    catch (Throwable throwable) {
                        throw throwable;
                    }
                    finally {
                        fileChannelAndName.unlock();
                    }
                }
                fileChannelAndName.unlock();
            }
            return 1;
        }
        catch (ConcurrentModificationException concurrentModificationException) {
            this.logger(3, "flushLog()" + concurrentModificationException);
            return -1;
        }
        catch (Exception exception) {
            this.logger(2, "flushLog()" + exception);
            return -1;
        }
    }

    private int flushLog(FileChannelAndName fileChannelAndName) {
        if (fileChannelAndName != null) {
            if (fileChannelAndName.byteBuilderData.length() > 0) {
                Object object;
                ByteBuilder byteBuilder;
                block16: {
                    byteBuilder = fileChannelAndName.byteBuilderData;
                    object = new ByteBuilder();
                    fileChannelAndName.lock();
                    if (fileChannelAndName.fileChannel != null && fileChannelAndName.byteBuilderData.length() > 0) break block16;
                    fileChannelAndName.unlock();
                    return 0;
                }
                try {
                    try {
                        fileChannelAndName.byteBuilderData = object;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        fileChannelAndName.unlock();
                    }
                }
                catch (Throwable throwable) {
                    fileChannelAndName.unlock();
                    throw throwable;
                }
                fileChannelAndName.unlock();
                try {
                    boolean bl;
                    object = ByteBuffer.wrap(byteBuilder.data(), 0, byteBuilder.size());
                    fileChannelAndName.fileChannel.write((ByteBuffer)object);
                    fileChannelAndName.sizeWritten += (long)((Buffer)object).position();
                    switch (fileChannelAndName.whatFor) {
                        default: {
                            bl = fileChannelAndName.nbAcess > this.nbLogsByFile;
                            break;
                        }
                        case Syslogs: {
                            bl = fileChannelAndName.nbAcess > this.nbSyslogsByFile;
                            break;
                        }
                        case Transactions: 
                        case DuplicateTransactions: {
                            boolean bl2 = bl = fileChannelAndName.nbAcess > this.nbTrsByFile;
                        }
                    }
                    if (bl) {
                        try {
                            this.closeFile(fileChannelAndName);
                            fileChannelAndName.fileChannel = new FileOutputStream(fileChannelAndName.name, true).getChannel();
                            fileChannelAndName.nbAcess = 0;
                            fileChannelAndName.sizeWritten = 0L;
                        }
                        catch (IOException iOException) {
                            this.logger(2, "flushLog() " + iOException);
                        }
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                return 1;
            }
            return 0;
        }
        return -1;
    }

    public static void logger(YP_Object yP_Object, int n, String string) {
        try {
            yP_Object.getPluginByName("EventLogger").dealRequest(yP_Object, "makeLog", n, string);
        }
        catch (Exception exception) {
            System.out.println(string);
            exception.printStackTrace();
        }
    }

    private void closeToken() {
        try {
            try {
                this.tokenFileMutex.lock();
                if (this.tokenPrintWriter != null) {
                    this.tokenPrintWriter.close();
                    this.tokenPrintWriter = null;
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.tokenFileMutex.unlock();
            }
        }
        finally {
            this.tokenFileMutex.unlock();
        }
    }

    private void closeSQL() {
        try {
            try {
                this.sqlFileMutex.lock();
                if (this.sqlPrintWriter != null) {
                    this.sqlPrintWriter.close();
                    this.sqlPrintWriter = null;
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.sqlFileMutex.unlock();
            }
        }
        finally {
            this.sqlFileMutex.unlock();
        }
    }

    private void closeSensitiveSQL() {
        try {
            try {
                this.sqlSensitiveFileMutex.lock();
                if (this.sqlSensitivePrintWriter != null) {
                    this.sqlSensitivePrintWriter.close();
                    this.sqlSensitivePrintWriter = null;
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.sqlSensitiveFileMutex.unlock();
            }
        }
        finally {
            this.sqlSensitiveFileMutex.unlock();
        }
    }

    private void closeSlowSQL() {
        try {
            try {
                this.sqlSlowFileMutex.lock();
                if (this.sqlSlowPrintWriter != null) {
                    this.sqlSlowPrintWriter.close();
                    this.sqlSlowPrintWriter = null;
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.sqlSlowFileMutex.unlock();
            }
        }
        finally {
            this.sqlSlowFileMutex.unlock();
        }
    }

    private void closeAll() {
        try {
            this.sysLog(3, "Server is stopping");
        }
        catch (Exception exception) {
            System.out.println("Server is stopping : " + exception);
        }
        this.closeToken();
        this.closeSQL();
        this.closeSensitiveSQL();
        this.closeSlowSQL();
        System.out.println("start flushing logs");
        this.closeLogs();
        this.closeGlobalLog();
        System.out.println("Flushing logs done");
    }

    private void closeLogs() {
        try {
            for (FileChannelAndName fileChannelAndName : this.fileWriterList.values()) {
                try {
                    try {
                        fileChannelAndName.lock();
                        if (fileChannelAndName.fileChannel != null) {
                            if (fileChannelAndName.byteBuilderData.length() > 0) {
                                System.out.println("found some unsaved logs");
                                ByteBuffer byteBuffer = ByteBuffer.wrap(fileChannelAndName.byteBuilderData.data(), 0, fileChannelAndName.byteBuilderData.size());
                                fileChannelAndName.fileChannel.write(byteBuffer);
                                fileChannelAndName.sizeWritten += (long)byteBuffer.position();
                            }
                            fileChannelAndName.fileChannel.close();
                            fileChannelAndName.fileChannel = null;
                        }
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        fileChannelAndName.unlock();
                        continue;
                    }
                }
                catch (Throwable throwable) {
                    fileChannelAndName.unlock();
                    throw throwable;
                }
                fileChannelAndName.unlock();
            }
        }
        catch (ConcurrentModificationException concurrentModificationException) {
            this.closeLogs();
            return;
        }
    }

    @Override
    public int shutdown() {
        super.shutdown();
        if (this.tokenPrintWriter != null) {
            this.tokenPrintWriter.close();
            this.tokenPrintWriter = null;
        }
        if (this.sqlPrintWriter != null) {
            this.sqlPrintWriter.close();
            this.sqlPrintWriter = null;
        }
        if (this.sqlSensitivePrintWriter != null) {
            this.sqlSensitivePrintWriter.close();
            this.sqlSensitivePrintWriter = null;
        }
        if (this.sqlSlowPrintWriter != null) {
            this.sqlSlowPrintWriter.close();
            this.sqlSlowPrintWriter = null;
        }
        this.closeAll();
        return 0;
    }

    private MessageLogInfoEnumeration getMessageLogInfo(String string) {
        if (string.contentEquals("Server is starting")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.contentEquals("Server is started")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("openClient() 80.14.248.69:340 java.net.ConnectException: Connection refused: connect")) {
            return MessageLogInfoEnumeration.DO_NOT_LOG;
        }
        if (string.startsWith("openClient() 80.14.248.69:340 java.net.ConnectException: Connection timed out: connect")) {
            return MessageLogInfoEnumeration.DO_NOT_LOG;
        }
        if (string.startsWith("openConnection() impossible  to connect to server: 80.14.248.69 340")) {
            return MessageLogInfoEnumeration.DO_NOT_LOG;
        }
        if (string.startsWith("run() impossible to get the UPDATER connection plugin")) {
            return MessageLogInfoEnumeration.DO_NOT_LOG;
        }
        if (string.startsWith("openClient() create socket failed for 80.14.248.69:340")) {
            return MessageLogInfoEnumeration.DO_NOT_LOG;
        }
        if (string.startsWith("checkAmount() amount too low: ")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("run() Account unknown for")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("run() authentification error for")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("persistTransaction() Duplicate transaction found we don't store this transaction")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("sendMailPrivate() javax.mail.SendFailedException: Invalid Addresses")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("checkTransactionType transaction refund not allowed")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        if (string.startsWith("addTerminalCountryCode() differents country code:")) {
            return MessageLogInfoEnumeration.DO_NOT_MAIL;
        }
        return MessageLogInfoEnumeration.NONE;
    }

    private void createLog(YP_Object yP_Object, String string, String string2, YP_Process yP_Process, FileChannelAndName fileChannelAndName, ByteBuilder byteBuilder, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        String string3;
        YP_TCD_DC_Transaction yP_TCD_DC_Transaction;
        this.appendDateTime(byteBuilder, n, n2, n3, n4, n5, n6, n7);
        byteBuilder.append(';');
        byteBuilder.append(string2);
        byteBuilder.append(';');
        if (yP_Process != null) {
            byteBuilder.append(yP_Process.getSimpleName());
        }
        byteBuilder.append(';');
        byteBuilder.append(UtilsYP.getInstanceNumber());
        byteBuilder.append(';');
        if (yP_Process != null) {
            byteBuilder.append(yP_Process.getRankInFatherChildList());
        }
        byteBuilder.append(';');
        if (yP_Process != null) {
            byteBuilder.append(yP_Process.getContractIdentifier());
        }
        byteBuilder.append(';');
        if (yP_Process != null) {
            byteBuilder.append(yP_Process.getFather().getProcessID());
        }
        byteBuilder.append(';');
        if (yP_Process != null) {
            byteBuilder.append(yP_Process.getProcessID());
        }
        byteBuilder.append(';');
        byteBuilder.append(yP_Object.getSimpleName());
        byteBuilder.append(';');
        byteBuilder.append(yP_Object.getContractIdentifier());
        byteBuilder.append(';');
        byteBuilder.append(yP_Object.getFather().getProcessID());
        byteBuilder.append(';');
        byteBuilder.append(yP_Object.getProcessID());
        byteBuilder.append(';');
        if (yP_Process != null && yP_Process instanceof YP_Transaction && (yP_TCD_DC_Transaction = ((YP_Transaction)yP_Process).getDataContainerTransaction()) != null && (string3 = yP_TCD_DC_Transaction.userHandler.getUserUID()) != null) {
            byteBuilder.append(string3);
        }
        byteBuilder.append(';');
        byteBuilder.append(string);
    }

    private int appendDateTime(ByteBuilder byteBuilder, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        byteBuilder.append('[');
        byteBuilder.append(n);
        byteBuilder.append('/');
        if (n2 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n2);
        byteBuilder.append('/');
        if (n3 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n3);
        byteBuilder.append(' ');
        if (n4 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n4);
        byteBuilder.append(':');
        if (n5 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n5);
        byteBuilder.append(':');
        if (n6 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n6);
        byteBuilder.append('.');
        if (n7 < 100) {
            byteBuilder.append('0');
            if (n7 < 10) {
                byteBuilder.append('0');
            }
        }
        byteBuilder.append(n7);
        byteBuilder.append(']');
        return 1;
    }

    private int appendDateTime(StringBuilder stringBuilder, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        stringBuilder.append('[');
        stringBuilder.append(n);
        stringBuilder.append('/');
        if (n2 < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(n2);
        stringBuilder.append('/');
        if (n3 < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(n3);
        stringBuilder.append(' ');
        if (n4 < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(n4);
        stringBuilder.append(':');
        if (n5 < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(n5);
        stringBuilder.append(':');
        if (n6 < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(n6);
        stringBuilder.append('.');
        if (n7 < 100) {
            stringBuilder.append('0');
            if (n7 < 10) {
                stringBuilder.append('0');
            }
        }
        stringBuilder.append(n7);
        stringBuilder.append(']');
        return 1;
    }

    private int appendHeaderLog(FileChannelAndName fileChannelAndName) {
        block5: {
            block4: {
                try {
                    if (fileChannelAndName != null) break block4;
                    return -1;
                }
                catch (IOException iOException) {
                    iOException.printStackTrace();
                    return -1;
                }
            }
            if (fileChannelAndName.fileChannel.size() <= 0L) break block5;
            return 0;
        }
        ByteBuffer byteBuffer = this.createHeaderLog(fileChannelAndName);
        fileChannelAndName.fileChannel.write(byteBuffer);
        fileChannelAndName.sizeWritten += (long)byteBuffer.position();
        return 1;
    }

    private ByteBuffer createHeaderLog(FileChannelAndName fileChannelAndName) {
        int n = lastYear;
        int n2 = lastMonth;
        int n3 = lastDay;
        int n4 = lastHour;
        int n5 = lastMinute;
        int n6 = lastSeconde;
        int n7 = lastMillisecondes;
        ByteBuilder byteBuilder = new ByteBuilder();
        this.createLog(this, LOG_STARTED, SLEVEL_UNKNOWN, null, fileChannelAndName, byteBuilder, n, n2, n3, n4, n5, n6, n7);
        byteBuilder.append(UtilsYP.lineSeparator);
        return ByteBuffer.wrap(byteBuilder.data(), 0, byteBuilder.size());
    }

    private ByteBuffer createTrailerLog(FileChannelAndName fileChannelAndName, String string) {
        int n = lastYear;
        int n2 = lastMonth;
        int n3 = lastDay;
        int n4 = lastHour;
        int n5 = lastMinute;
        int n6 = lastSeconde;
        int n7 = lastMillisecondes;
        ByteBuilder byteBuilder = new ByteBuilder();
        String string2 = "LOG ENDED;" + this.logSignAlgo + ';' + this.logSignKeyLabel + ';' + string + ';';
        this.createLog(this, string2, SLEVEL_UNKNOWN, null, fileChannelAndName, byteBuilder, n, n2, n3, n4, n5, n6, n7);
        byteBuilder.append(UtilsYP.lineSeparator);
        return ByteBuffer.wrap(byteBuilder.data(), 0, byteBuilder.size());
    }

    private String getSecureCksumSHA256Encrypt(String string) {
        String[] stringArray;
        block3: {
            try {
                String string2 = this.getFileHash256(string);
                YP_TS_CryptoManager yP_TS_CryptoManager = (YP_TS_CryptoManager)this.getPluginByName("CryptoManager");
                stringArray = (String[])yP_TS_CryptoManager.dealRequest(this, "encrypt", this.logSignKeyLabel, string2, null);
                if (stringArray != null) break block3;
                return null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return null;
            }
        }
        return stringArray[0];
    }

    /*
     * Exception decompiling
     */
    private void closeFile(FileChannelAndName var1_1) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Can't sort instructions [@NONE, blocks:[7] lbl22 : CaseStatement: default:\u000a, @NONE, blocks:[7] lbl22 : CaseStatement: default:\u000a]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:8)
         *     at java.base/java.util.TimSort.countRunAndMakeAscending(TimSort.java:360)
         *     at java.base/java.util.TimSort.sort(TimSort.java:220)
         *     at java.base/java.util.Arrays.sort(Arrays.java:1307)
         *     at java.base/java.util.ArrayList.sort(ArrayList.java:1721)
         *     at java.base/java.util.Collections.sort(Collections.java:179)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.buildSwitchCases(SwitchReplacer.java:271)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitch(SwitchReplacer.java:258)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:66)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private String getFileHash256(String string) throws Exception {
        Throwable throwable = null;
        Object var3_4 = null;
        try (FileInputStream fileInputStream = new FileInputStream(string);){
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] byArray = new byte[0x100000];
            int n = 0;
            while ((n = fileInputStream.read(byArray)) != -1) {
                messageDigest.update(byArray, 0, n);
            }
            return UtilsYP.devHexa(messageDigest.digest());
        }
        catch (Throwable throwable2) {
            if (throwable == null) {
                throwable = throwable2;
            } else if (throwable != throwable2) {
                throwable.addSuppressed(throwable2);
            }
            throw throwable;
        }
    }

    private void zipFile(FileChannelAndName fileChannelAndName) throws IOException {
        String string = String.valueOf(fileChannelAndName.name) + ".gzip";
        ZipUtils.gzip(fileChannelAndName.name, string);
        new File(fileChannelAndName.name).delete();
        int n = 0;
        switch (fileChannelAndName.whatFor) {
            case Transactions: 
            case DuplicateTransactions: {
                n = this.nbBackupTrsFiles;
                break;
            }
            case Logs: 
            case ErrorLogs: 
            case Syslogs: {
                n = this.nbBackupLogFiles;
            }
        }
        int n2 = 1;
        while (n2 <= n) {
            String string2 = String.valueOf(fileChannelAndName.name) + String.format(".%03d.gzip", n2);
            File file = new File(string2);
            if (!file.exists() || n2 == n) {
                if (n2 == n) {
                    file.delete();
                }
                File file2 = new File(string);
                file2.renameTo(file);
                break;
            }
            ++n2;
        }
    }

    public int sysLog(YP_Object yP_Object, int n, String string) {
        block11: {
            if (yP_Object.getLogLevel() >= n) break block11;
            return 0;
        }
        try {
            String string2;
            switch (n) {
                case 6: {
                    string2 = SLEVEL_DEV;
                    break;
                }
                case 5: {
                    string2 = SLEVEL_DEBUG;
                    break;
                }
                case 4: {
                    string2 = SLEVEL_INFO;
                    break;
                }
                case 3: {
                    string2 = SLEVEL_WARN;
                    break;
                }
                case 2: {
                    string2 = SLEVEL_ERROR;
                    break;
                }
                case 1: {
                    string2 = SLEVEL_FATAL;
                    break;
                }
                default: {
                    string2 = SLEVEL_UNKNOWN;
                }
            }
            this.dealLog(yP_Object, string, string2, WhatForEnumeration.Syslogs);
        }
        catch (Exception exception) {
            this.logger(n, String.valueOf(string) + " " + exception);
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int addLogToSysLog(String string) {
        try {
            File file;
            Serializable serializable;
            boolean bl;
            block22: {
                sysLogsMutex.lock();
                bl = false;
                try {
                    serializable = null;
                    file = null;
                    try {
                        FileOutputStream fileOutputStream = new FileOutputStream(String.valueOf(YP_TCG_EventLogger.getDirectory(WhatForEnumeration.Syslogs)) + YP_TCG_EventLogger.getFileName(WhatForEnumeration.Syslogs), true);
                        try {
                            try (FileChannel fileChannel = fileOutputStream.getChannel();){
                                if (fileChannel.size() > (long)(this.nbSyslogsByFile * 100)) {
                                    bl = true;
                                }
                                fileChannel.write(ByteBuffer.wrap(string.getBytes()));
                                fileChannel.write(lineSeparatorBuffer);
                                lineSeparatorBuffer.rewind();
                            }
                            if (fileOutputStream == null) break block22;
                        }
                        catch (Throwable throwable) {
                            if (serializable == null) {
                                serializable = throwable;
                            } else if (serializable != throwable) {
                                ((Throwable)serializable).addSuppressed(throwable);
                            }
                            if (fileOutputStream == null) throw serializable;
                            fileOutputStream.close();
                            throw serializable;
                        }
                        fileOutputStream.close();
                    }
                    catch (Throwable throwable) {
                        if (serializable == null) {
                            serializable = throwable;
                            throw serializable;
                        }
                        if (serializable == throwable) throw serializable;
                        ((Throwable)serializable).addSuppressed(throwable);
                        throw serializable;
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
            if (!bl) return 1;
            try {
                serializable = new File(String.valueOf(YP_TCG_EventLogger.getDirectory(WhatForEnumeration.Syslogs)) + YP_TCG_EventLogger.getFileName(WhatForEnumeration.Syslogs) + ".bak");
                if (((File)serializable).exists()) {
                    ((File)serializable).delete();
                }
                file = new File(String.valueOf(YP_TCG_EventLogger.getDirectory(WhatForEnumeration.Syslogs)) + YP_TCG_EventLogger.getFileName(WhatForEnumeration.Syslogs));
                file.renameTo((File)serializable);
                return 1;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return 1;
            }
        }
        finally {
            sysLogsMutex.unlock();
        }
    }

    private void appendToGlobalLog(ByteBuilder byteBuilder, int n) {
        if (!this.activateGlobalLog && !this.tooManyGlobalLog) {
            return;
        }
        this.globalLogMutex.lock();
        try {
            if (this.globalFileChannelAndName == null) {
                StringBuilder stringBuilder = new StringBuilder(256);
                stringBuilder.append(YP_TCG_EventLogger.getDirectory(WhatForEnumeration.Logs));
                String string = UtilsYP.getAAAAMMJJTime(UtilsYP.getCalendar(System.currentTimeMillis()));
                stringBuilder.append(string);
                stringBuilder.append("/global.log");
                String string2 = stringBuilder.toString();
                int n2 = 0;
                while (n2 < this.nbGlobalBackupLogFiles) {
                    try {
                        String string3 = n2 == 0 ? string2 : String.valueOf(string2) + n2;
                        File file = new File(string3);
                        if (!file.exists()) {
                            this.globalFileChannelAndName = new FileChannelAndName(string3, WhatForEnumeration.Logs, new FileOutputStream(string3, true).getChannel());
                        }
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    if (this.globalFileChannelAndName != null) break;
                    ++n2;
                }
                if (this.globalFileChannelAndName == null) {
                    this.tooManyGlobalLog = true;
                    return;
                }
            }
            try {
                if (this.globalFileChannelAndName.sizeWritten < this.maxGlobalLogFileSize + 10000000L) {
                    int n3 = byteBuilder.length() - n;
                    this.globalFileChannelAndName.byteBuilderData.append(byteBuilder.data(), n, n3);
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        finally {
            this.globalLogMutex.unlock();
        }
    }

    private void flushGlobalLog() {
        block18: {
            if (!this.activateGlobalLog) {
                return;
            }
            if (this.globalFileChannelAndName == null) {
                return;
            }
            try {
                ByteBuilder byteBuilder;
                ByteBuilder byteBuilder2;
                block16: {
                    if (this.globalFileChannelAndName.byteBuilderData.length() <= 0) {
                        return;
                    }
                    byteBuilder2 = this.globalFileChannelAndName.byteBuilderData;
                    byteBuilder = new ByteBuilder();
                    this.globalLogMutex.lock();
                    if (this.globalFileChannelAndName.fileChannel != null && this.globalFileChannelAndName.byteBuilderData.length() > 0) break block16;
                    this.globalLogMutex.unlock();
                    return;
                }
                try {
                    try {
                        this.globalFileChannelAndName.byteBuilderData = byteBuilder;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        this.globalLogMutex.unlock();
                    }
                }
                catch (Throwable throwable) {
                    this.globalLogMutex.unlock();
                    throw throwable;
                }
                this.globalLogMutex.unlock();
                ByteBuffer byteBuffer = ByteBuffer.wrap(byteBuilder2.data(), 0, byteBuilder2.size());
                this.globalFileChannelAndName.fileChannel.write(byteBuffer);
                this.globalFileChannelAndName.sizeWritten += (long)byteBuffer.position();
                ++this.globalFileChannelAndName.nbAcess;
                if (this.globalFileChannelAndName.sizeWritten <= this.maxGlobalLogFileSize) break block18;
                try {
                    try {
                        this.globalLogMutex.lock();
                        if (this.globalFileChannelAndName.byteBuilderData.length() > 0) {
                            byteBuffer = ByteBuffer.wrap(this.globalFileChannelAndName.byteBuilderData.data(), 0, this.globalFileChannelAndName.byteBuilderData.size());
                            this.globalFileChannelAndName.fileChannel.write(byteBuffer);
                        }
                        this.globalFileChannelAndName.fileChannel.close();
                        this.globalFileChannelAndName = null;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        this.globalLogMutex.unlock();
                    }
                }
                finally {
                    this.globalLogMutex.unlock();
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

    private void closeGlobalLog() {
        try {
            try {
                this.globalLogMutex.lock();
                this.flushGlobalLog();
                if (this.globalFileChannelAndName != null) {
                    this.globalFileChannelAndName.fileChannel.close();
                    this.globalFileChannelAndName = null;
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.globalLogMutex.unlock();
            }
        }
        finally {
            this.globalLogMutex.unlock();
        }
    }

    class FileChannelAndName {
        final String name;
        final WhatForEnumeration whatFor;
        FileChannel fileChannel;
        int nbAcess;
        ByteBuilder byteBuilderData = new ByteBuilder();
        private final ReentrantLock mutex = new ReentrantLock();
        long previousTimeInNano = System.nanoTime();
        long sizeWritten;

        FileChannelAndName(String string, WhatForEnumeration whatForEnumeration, FileChannel fileChannel) {
            this.name = string;
            this.whatFor = whatForEnumeration;
            this.fileChannel = fileChannel;
            this.nbAcess = 0;
            this.sizeWritten = 0L;
        }

        public void lock() {
            this.mutex.lock();
        }

        public void unlock() {
            this.mutex.unlock();
        }
    }

    public static enum LogMethod {
        byBrand,
        byMerchant,
        byContract,
        byProcess,
        byNothing;

    }

    private static enum MessageLogInfoEnumeration {
        NONE,
        DO_NOT_LOG,
        DO_NOT_MAIL;

    }

    private static enum WhatForEnumeration {
        Logs,
        ErrorLogs,
        Transactions,
        DuplicateTransactions,
        Syslogs;

    }
}

