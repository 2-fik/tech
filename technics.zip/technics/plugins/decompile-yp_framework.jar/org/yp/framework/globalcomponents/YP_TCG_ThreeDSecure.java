/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Interface_3DSecure;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecure;
import org.yp.framework.ondemandcomponents.protocols.threeds.YP_TCD_PROT_ThreeDSecureAutoStateMachine;
import org.yp.utils.UtilsYP;
import org.yp.xml.jaxb.threeds.PARes;
import org.yp.xml.jaxb.threeds.ThreeDSecure;

public class YP_TCG_ThreeDSecure
extends YP_GlobalComponent {
    private YP_GlobalComponent parserXML;
    private ThreeDSecure threeDSecureMessage = null;
    private PARes paRes;

    public YP_TCG_ThreeDSecure(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "ThreeDSecure";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private int is3DSActive(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_TCD_DC_Transaction.getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return -1;
        }
        if (yP_TCD_PosProtocol instanceof YP_PROT_Interface_3DSecure) {
            return ((YP_PROT_Interface_3DSecure)((Object)yP_TCD_PosProtocol)).is3DSActive(yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
        }
        return 0;
    }

    private int is3DSResponse(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_TCD_DC_Transaction.getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return -1;
        }
        if (yP_TCD_PosProtocol instanceof YP_PROT_Interface_3DSecure) {
            return ((YP_PROT_Interface_3DSecure)((Object)yP_TCD_PosProtocol)).is3DSResponse(yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
        }
        return 0;
    }

    private int verifEnrollment(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_TCD_DC_Transaction.getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return -1;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Interface_3DSecure)) {
            return 0;
        }
        YP_PROT_Interface_Prot yP_PROT_Interface_Prot = (YP_PROT_Interface_Prot)((Object)this.newPluginByName("ThreeDSecure_Interface", yP_TCD_DCC_Business, yP_TCD_DC_Transaction, string));
        YP_TCD_PROT_ThreeDSecureAutoStateMachine yP_TCD_PROT_ThreeDSecureAutoStateMachine = (YP_TCD_PROT_ThreeDSecureAutoStateMachine)this.newPluginByName("SM_THREEDSECURE_AUTO", new Object[0]);
        yP_TCD_PROT_ThreeDSecureAutoStateMachine.setParameters(yP_TCD_DCC_Business, yP_TCD_DC_Transaction, YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto, yP_TCD_DCC_Business.getApplicationPlugin().getApplicationProperties(), yP_PROT_Interface_Prot, null, yP_TCD_PosProtocol);
        while (yP_TCD_PROT_ThreeDSecureAutoStateMachine.step() == 1) {
        }
        if (yP_TCD_PROT_ThreeDSecureAutoStateMachine.getErrorStatus() == 0) {
            return 1;
        }
        yP_TCD_PROT_ThreeDSecureAutoStateMachine.shutdown();
        yP_PROT_Interface_Prot.shutdown();
        return -1;
    }

    private String getVeresStatus(String string) {
        if (this.parserXML == null) {
            this.parserXML = (YP_GlobalComponent)this.getPluginByName("ThreeDSecureParser");
        }
        try {
            this.threeDSecureMessage = (ThreeDSecure)this.parserXML.dealRequest(this, "xmlToObject", new Object[]{string.getBytes()});
            String string2 = this.threeDSecureMessage.getMessage().get(0).getVERes().getCH().getEnrolled();
            return string2;
        }
        catch (Exception exception) {
            this.logger(2, "isMessageValid() " + exception);
            return null;
        }
    }

    /*
     * Recovered potentially malformed switches.  Disable with '--allowmalformedswitch false'
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean isMessageValid(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, String string) {
        byte[] byArray;
        if (this.parserXML == null) {
            this.parserXML = (YP_GlobalComponent)this.getPluginByName("ThreeDSecureParser");
        }
        try {
            this.threeDSecureMessage = (ThreeDSecure)this.parserXML.dealRequest(this, "xmlToObject", new Object[]{string.getBytes()});
            this.paRes = this.threeDSecureMessage.getMessage().get(0).getPARes();
        }
        catch (Exception exception) {
            this.logger(2, "isMessageValid() " + exception);
        }
        String string2 = this.paRes.getTX().getStatus();
        if (string2 == null) {
            if (this.getLogLevel() < 2) return false;
            this.logger(2, "isMessageValid() messageToCheck TX.status missing");
            return false;
        }
        switch (string2.toUpperCase()) {
            case "N": 
            case "U": {
                if (this.getLogLevel() < 2) return false;
                this.logger(2, "isMessageValid() messageToCheck user not authenticated by ACS: " + string2.toUpperCase());
                return false;
            }
            default: {
                if (this.getLogLevel() < 2) return false;
                this.logger(2, "isMessageValid() messageToCheck TX.status uncorrect value: " + string2);
                return false;
            }
            case "A": 
            case "Y": 
        }
        yP_TCD_DC_Transaction.setExtensionValue("paresStatus", string2.toUpperCase());
        if (!string2.toUpperCase().contentEquals("A")) {
            if (!string2.toUpperCase().contentEquals("Y")) return true;
        }
        if ((byArray = this.paRes.getTX().getCavv()) == null) {
            if (this.getLogLevel() < 2) return false;
            this.logger(2, "isMessageValid() messageToCheck TX.cavv missing");
            return false;
        }
        yP_TCD_DC_Transaction.setExtensionValue("cavv", UtilsYP.devHexa(byArray));
        String string3 = this.paRes.getTX().getCavvAlgorithm();
        if (string3 == null) {
            if (this.getLogLevel() < 2) return false;
            this.logger(2, "isMessageValid() messageToCheck TX.cavvAlgorithm missing");
            return false;
        }
        switch (string3) {
            default: {
                if (this.getLogLevel() < 2) return false;
                this.logger(2, "isMessageValid() messageToCheck TX.cavvAlgorithm incorrect value: " + this.paRes.getTX().getCavvAlgorithm());
                return false;
            }
            case "0": 
            case "1": 
            case "2": 
            case "3": 
        }
        yP_TCD_DC_Transaction.setExtensionValue("cavvAlgorithm", string3);
        String string4 = this.paRes.getTX().getEci();
        if (string4 == null) {
            if (this.getLogLevel() < 2) return false;
            this.logger(2, "isMessageValid() messageToCheck TX.eci missing");
            return false;
        }
        if (string4.length() == 0) {
            yP_TCD_DC_Transaction.setExtensionValue("eci", "  ");
            return true;
        }
        yP_TCD_DC_Transaction.setExtensionValue("eci", string4);
        return true;
    }

    private int verifResponse(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_TCD_DC_Transaction.getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return -1;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Interface_3DSecure)) {
            return 0;
        }
        YP_TCD_PROT_ThreeDSecure yP_TCD_PROT_ThreeDSecure = (YP_TCD_PROT_ThreeDSecure)this.newPluginByName("THREEDSECURE_PROTOCOL", new Object[0]);
        String string = ((YP_PROT_Interface_3DSecure)((Object)yP_TCD_PosProtocol)).getPaRes();
        if (string == null || string.isEmpty()) {
            return -2;
        }
        if (this.getLogLevel() >= 4) {
            this.logger(4, "verifResponse() paRes received: " + string);
        }
        if (!this.isMessageValid(yP_TCD_DC_Transaction, string)) {
            return 0;
        }
        boolean bl = yP_TCD_PROT_ThreeDSecure.checkSignatureDocument(string.getBytes());
        if (bl) {
            return 1;
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("is3DSActive")) {
                if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof YP_TCD_DCC_Business && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                    return this.is3DSActive((YP_TCD_DCC_Business)objectArray[0], (YP_TCD_DC_Transaction)objectArray[1]);
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "dealRequest() bad parameters for is3DSActive");
                }
                return null;
            }
            if (string.contentEquals("is3DSResponse")) {
                if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof YP_TCD_DCC_Business && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                    return this.is3DSResponse((YP_TCD_DCC_Business)objectArray[0], (YP_TCD_DC_Transaction)objectArray[1]);
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "dealRequest() bad parameters for is3DSResponse");
                }
                return null;
            }
            if (string.contentEquals("verifEnrollment")) {
                if (objectArray != null && objectArray.length == 3 && objectArray[0] instanceof YP_TCD_DCC_Business && objectArray[1] instanceof YP_TCD_DC_Transaction && objectArray[2] instanceof String) {
                    return this.verifEnrollment((YP_TCD_DCC_Business)objectArray[0], (YP_TCD_DC_Transaction)objectArray[1], (String)objectArray[2]);
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "dealRequest() bad parameters for verifEnrollment");
                }
                return null;
            }
            if (!string.contentEquals("verifResponse")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof YP_TCD_DCC_Business && objectArray[1] instanceof YP_TCD_DC_Transaction) {
                return this.verifResponse((YP_TCD_DCC_Business)objectArray[0], (YP_TCD_DC_Transaction)objectArray[1]);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "dealRequest() bad parameters for verifResponse");
            }
            return null;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.logger(2, " dealRequest() bad request  ??? : " + exception);
            return null;
        }
    }
}

