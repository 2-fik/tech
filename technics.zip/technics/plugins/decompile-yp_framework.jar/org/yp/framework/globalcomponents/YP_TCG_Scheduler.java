/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public class YP_TCG_Scheduler
extends YP_GlobalComponent {
    private Timestamp nextScheduleTimestamp = null;
    private boolean registrationNeeded = true;

    public YP_TCG_Scheduler(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "Scheduler";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public YP_Row getCronAction() {
        int n;
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
        if (UtilsYP.getInstanceRole() != 1) {
            return null;
        }
        if (this.registrationNeeded && (yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique()) != null) {
            yP_TCD_DCC_Technique.schedule.registerWatcher(this.getProcessID());
            this.registrationNeeded = false;
        }
        if ((n = this.getNotification()) <= 0 && this.nextScheduleTimestamp != null && this.nextScheduleTimestamp.after(UtilsYP.getSystemGMTTime().getTime())) {
            return null;
        }
        this.nextScheduleTimestamp = null;
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique2 = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique2 == null) {
            this.logger(2, "getCronAction() no DCC_Technique...");
            return null;
        }
        try {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique2.schedule);
            yP_ComplexGabarit.set("scheduleSystemGMTTime", YP_ComplexGabarit.OPERATOR.MIN);
            yP_TCD_DCC_Technique2.schedule.lock();
            List<YP_Row> list = yP_TCD_DCC_Technique2.schedule.getRowListSuchAs(0, 100, yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                return null;
            }
            this.nextScheduleTimestamp = (Timestamp)list.get(0).getFieldValueByName("scheduleSystemGMTTime");
            if (this.nextScheduleTimestamp == null || this.nextScheduleTimestamp.after(UtilsYP.getSystemGMTTime().getTime())) {
                return null;
            }
            if (list == null || list.isEmpty()) {
                return null;
            }
            YP_Row yP_Row = null;
            for (YP_Row yP_Row2 : list) {
                int n2;
                Object object;
                Object object2;
                int n3 = (Integer)yP_Row2.getFieldValueByName("delayInterCallInSec");
                if (n3 == 1) {
                    n3 = 2;
                }
                String string = yP_Row2.getFieldStringValueByName("frequencyInYYMMWWDDHHMMSS");
                long l = 0L;
                try {
                    l = Long.parseLong(string);
                }
                catch (Exception exception) {
                    this.logger(2, "getCronAction() : bad value for frequency " + string + " " + exception);
                }
                if (l == 1L) {
                    string = "00000000000002";
                }
                int n4 = (Integer)yP_Row2.getFieldValueByName("currentTry");
                long l2 = (Long)yP_Row2.getFieldValueByName("lastProcessID");
                if (l2 != 0L && (object2 = this.getProcessPluginByThreadID(l2)) != null) {
                    if (n3 == 0) {
                        this.logger(2, "getCronAction() here a cron shouldn't  have a KO frequence !!!");
                        n3 = 600;
                    }
                    object = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() + (long)(n3 * 1000));
                    yP_Row2.set("scheduleSystemGMTTime", ((Timestamp)object).toString());
                    yP_Row2.persist();
                    continue;
                }
                object2 = yP_Row2.getFieldStringValueByName("applicationIdentifier");
                if (object2 != null && !((String)object2).isEmpty() && (object = (List)this.getPluginByName("ProcessLauncher").dealRequest(this, "getTransactionListByContractIdentifier", object2)) != null && !object.isEmpty()) {
                    Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() + 5000L);
                    yP_Row2.set("scheduleSystemGMTTime", timestamp.toString());
                    yP_Row2.persist();
                    continue;
                }
                object = null;
                if (object2 != null && !((String)object2).isEmpty()) {
                    List list2 = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerList", null, object2, "");
                    if (list2 == null || list2.isEmpty()) {
                        this.logger(2, "getCronAction() this cron will be deleted as it appears there is no more corresponding contract !!! " + (String)object2);
                        yP_Row2.delete();
                        yP_Row2.persist();
                        continue;
                    }
                    if (list2.size() == 1) {
                        object = (YP_TCD_DCC_Business)list2.get(0);
                    }
                }
                if (++n4 > (n2 = ((Integer)yP_Row2.getFieldValueByName("maxTries")).intValue())) {
                    Serializable serializable;
                    Calendar calendar;
                    if (l == 0L) {
                        yP_Row = (YP_Row)yP_Row2.clone();
                        yP_Row2.delete();
                        yP_Row2.persist();
                        break;
                    }
                    String string2 = yP_Row2.getFieldStringValueByName("referenceDate");
                    String string3 = yP_Row2.getFieldStringValueByName("referenceTime");
                    int n5 = (Integer)yP_Row2.getFieldValueByName("aleaInSec");
                    String string4 = UtilsYP.getAAAAMMJJTime(UtilsYP.getSystemGMTTime());
                    Calendar calendar2 = UtilsYP.getSystemGMTTime();
                    Serializable serializable2 = UtilsYP.getCalendarTime(String.valueOf(string4) + string3);
                    if (object != null && ((YP_TCD_DCC_Business)object).timeInterface != null && (calendar = ((YP_TCD_DCC_Business)object).timeInterface.getSystemGMTTime(serializable2.getTimeInMillis())) != null) {
                        this.logger(3, "getCronAction() MAX tries reached we will use the application time " + serializable2 + " vs " + calendar);
                        serializable2 = calendar;
                    }
                    int n6 = Integer.parseInt(string.substring(0, 2));
                    int n7 = Integer.parseInt(string.substring(2, 4));
                    int n8 = Integer.parseInt(string.substring(4, 6));
                    int n9 = Integer.parseInt(string.substring(6, 8));
                    int n10 = Integer.parseInt(string.substring(8, 10));
                    int n11 = Integer.parseInt(string.substring(10, 12));
                    int n12 = Integer.parseInt(string.substring(12, 14));
                    do {
                        if (n6 != 0) {
                            serializable2.add(1, n6);
                            if (n7 != 0) {
                                serializable2.set(2, n7 - 1);
                                if (n8 != 0) {
                                    serializable2.set(4, n8);
                                    serializable2.set(7, n9);
                                } else {
                                    serializable2.set(5, n9);
                                }
                            } else if (n8 != 0) {
                                serializable2.set(3, n8);
                                serializable2.set(7, n9);
                            } else {
                                serializable2.set(6, n9);
                            }
                        } else if (n7 != 0) {
                            serializable2.add(2, n7);
                            if (n8 != 0) {
                                serializable2.set(4, n8);
                                serializable2.set(7, n9);
                            } else {
                                serializable2.set(5, n9);
                            }
                        } else if (n8 != 0) {
                            serializable2.add(3, n8);
                            serializable2.set(7, n9);
                        } else {
                            serializable2.add(6, n9);
                        }
                        serializable2.add(10, n10);
                        serializable2.add(12, n11);
                        serializable2.add(13, n12);
                    } while (serializable2.before(calendar2));
                    if (n5 > 0) {
                        serializable = new Random();
                        long l3 = ((Random)serializable).nextLong() % (long)n5;
                        if (l3 < 0L) {
                            l3 *= -1L;
                        }
                        serializable2.setTimeInMillis(serializable2.getTimeInMillis() + l3);
                    }
                    if (string2.compareTo(string4) > 0 && ((Calendar)(serializable = UtilsYP.getCalendarTime(String.valueOf(string2) + string3))).after(calendar2) && ((Calendar)serializable).before(serializable2)) {
                        serializable2 = serializable;
                    }
                    yP_Row2.set("lastProcessID", 0);
                    yP_Row = (YP_Row)yP_Row2.clone();
                    yP_Row2.set("currentTry", 1);
                    yP_Row2.set("scheduleSystemGMTTime", new Timestamp(serializable2.getTimeInMillis()));
                    yP_Row2.persist();
                    break;
                }
                if (n3 == 0) {
                    this.logger(2, "getCronAction() a cron can't have tries without a delay inter calls !!!");
                    yP_Row2.delete();
                    yP_Row2.persist();
                    continue;
                }
                Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis() + (long)(n3 * 1000));
                yP_Row2.set("lastProcessID", 0);
                yP_Row = (YP_Row)yP_Row2.clone();
                yP_Row2.set("currentTry", n4);
                yP_Row2.set("scheduleSystemGMTTime", timestamp.toString());
                yP_Row2.persist();
                break;
            }
            YP_Row yP_Row3 = yP_Row;
            return yP_Row3;
        }
        catch (Exception exception) {
            this.logger(2, "getCronAction() :" + exception);
            return null;
        }
        finally {
            yP_TCD_DCC_Technique2.schedule.unlock();
        }
    }

    private int updateCronAction(Timestamp timestamp, String string, String string2, String string3, String string4, String string5, String string6, int n, String string7, int n2, int n3, int n4, String string8) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "updateCronAction() no DCC_Technique...");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique.schedule);
        if (string != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        if (string3 != null && !string3.isEmpty()) {
            yP_ComplexGabarit.set("scheduleName", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        if (string4 != null && !string4.isEmpty()) {
            yP_ComplexGabarit.set("scheduleType", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
        }
        try {
            yP_TCD_DCC_Technique.schedule.lock();
            List<YP_Row> list = yP_TCD_DCC_Technique.schedule.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(4, "updateCronAction() Row creation needed...");
                if (timestamp == null || string == null || string2 == null || string3 == null || string4 == null || string5 == null || string6 == null || string7 == null || n2 == -1 || n3 <= 0 || n4 == -1 || string8 == null) {
                    this.logger(2, "updateCronAction() : missing parameters");
                    return -1;
                }
                YP_Row yP_Row = yP_TCD_DCC_Technique.schedule.getNewRow();
                if (timestamp != null) {
                    yP_Row.set("scheduleSystemGMTTime", timestamp);
                }
                if (string != null) {
                    yP_Row.set("applicationIdentifier", string);
                }
                if (string2 != null) {
                    yP_Row.set("pluginName", string2);
                }
                if (string3 != null) {
                    yP_Row.set("scheduleName", string3);
                }
                if (string4 != null) {
                    yP_Row.set("scheduleType", string4);
                }
                if (string5 != null) {
                    yP_Row.set("referenceDate", string5);
                }
                if (string6 != null) {
                    yP_Row.set("referenceTime", string6);
                }
                if (n != -1) {
                    yP_Row.set("aleaInSec", n);
                }
                if (string7 != null) {
                    yP_Row.set("frequencyInYYMMWWDDHHMMSS", string7);
                }
                if (n2 != -1) {
                    yP_Row.set("delayInterCallInSec", n2);
                }
                if (n3 > 0) {
                    yP_Row.set("currentTry", n3);
                }
                if (n4 != -1) {
                    yP_Row.set("maxTries", n4);
                }
                yP_Row.set("lastProcessID", 0);
                if (string8 != null) {
                    yP_Row.set("requestXML", string8.trim());
                }
                yP_TCD_DCC_Technique.schedule.addRow(yP_Row);
                yP_TCD_DCC_Technique.schedule.persist();
                return 1;
            }
            if (list.size() > 1) {
                this.logger(4, "updateCronAction() Too many rows, some will be deleted ...");
                for (YP_Row yP_Row : list) {
                    yP_Row.delete();
                }
            }
            YP_Row yP_Row = list.get(0);
            if (timestamp != null) {
                yP_Row.set("scheduleSystemGMTTime", timestamp);
            }
            if (string != null) {
                yP_Row.set("applicationIdentifier", string);
            }
            if (string2 != null) {
                yP_Row.set("pluginName", string2);
            }
            if (string3 != null) {
                yP_Row.set("scheduleName", string3);
            }
            if (string4 != null) {
                yP_Row.set("scheduleType", string4);
            }
            if (string5 != null) {
                yP_Row.set("referenceDate", string5);
            }
            if (string6 != null) {
                yP_Row.set("referenceTime", string6);
            }
            if (n != -1) {
                yP_Row.set("aleaInSec", n);
            }
            if (string7 != null) {
                yP_Row.set("frequencyInYYMMWWDDHHMMSS", string7);
            }
            if (n2 != -1) {
                yP_Row.set("delayInterCallInSec", n2);
            }
            if (n3 > 0) {
                yP_Row.set("currentTry", n3);
            }
            if (n4 != -1) {
                yP_Row.set("maxTries", n4);
            }
            yP_Row.set("lastProcessID", 0);
            if (string8 != null) {
                yP_Row.set("requestXML", string8.trim());
            }
            yP_Row.setIsItAClonedRow(false);
            yP_Row.persist();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "updateCronAction() :" + exception);
            return -1;
        }
        finally {
            yP_TCD_DCC_Technique.schedule.unlock();
        }
    }

    private int changeCronScheduleTime(String string, long l) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "changeCronScheduleTime() no DCC_Technique...");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique.schedule);
        if (string != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        try {
            yP_TCD_DCC_Technique.schedule.lock();
            List<YP_Row> list = yP_TCD_DCC_Technique.schedule.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(4, "changeCronScheduleTime() nothing to do");
                return 0;
            }
            int n = 0;
            while (n < list.size()) {
                YP_Row yP_Row = list.get(n);
                Timestamp timestamp = (Timestamp)yP_Row.getFieldValueByName("scheduleSystemGMTTime");
                Timestamp timestamp2 = new Timestamp(timestamp.getTime() + l);
                if (this.getLogLevel() >= 4) {
                    this.logger(4, "changeCronScheduleTime() change old timestamp: " + timestamp.toString());
                    this.logger(4, "changeCronScheduleTime() to new timestamp: " + timestamp2.toString());
                }
                yP_Row.set("scheduleSystemGMTTime", timestamp2);
                yP_Row.setIsItAClonedRow(false);
                yP_Row.persist();
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "changeCronScheduleTime() :" + exception);
            return -1;
        }
        finally {
            yP_TCD_DCC_Technique.schedule.unlock();
        }
    }

    private Object createUrgentCron(YP_TCD_DCC_Business yP_TCD_DCC_Business, String string, String string2) {
        return this.updateCronAction(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()), yP_TCD_DCC_Business.getContractIdentifier(), "", string, "ONE_SHOT", "00000000", "000000", 0, "00000000000000", 0, 1, 0, string2);
    }

    private List<YP_Row> getCronList(String string, String string2, String string3) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "getCronList() no DCC_Technique...");
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique.schedule);
        if (string != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        if (string2 != null && !string2.isEmpty()) {
            yP_ComplexGabarit.set("scheduleName", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        }
        if (string3 != null && !string3.isEmpty()) {
            yP_ComplexGabarit.set("scheduleType", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        try {
            yP_TCD_DCC_Technique.schedule.lock();
            List<YP_Row> list = yP_TCD_DCC_Technique.schedule.getRowListSuchAs(yP_ComplexGabarit);
            return list;
        }
        catch (Exception exception) {
            this.logger(2, "getCronList() :" + exception);
            return null;
        }
        finally {
            yP_TCD_DCC_Technique.schedule.unlock();
        }
    }

    private int deleteCron(String string, String string2, String string3) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "deleteCron() no DCC_Technique...");
            return -1;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique.schedule);
        if (string != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("applicationIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        if (string2 != null && !string2.isEmpty()) {
            yP_ComplexGabarit.set("scheduleName", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        }
        if (string3 != null && !string3.isEmpty()) {
            yP_ComplexGabarit.set("scheduleType", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        try {
            yP_TCD_DCC_Technique.schedule.lock();
            int n = yP_TCD_DCC_Technique.schedule.deleteRowsSuchAs(yP_ComplexGabarit);
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "deleteCron() :" + exception);
            return -1;
        }
        finally {
            yP_TCD_DCC_Technique.schedule.unlock();
        }
    }

    private int setCronCurrentThreadID(YP_Object yP_Object, YP_Row yP_Row) {
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "setCronCurrentThreadID() no DCC_Technique...");
            return -1;
        }
        YP_Row yP_Row2 = yP_TCD_DCC_Technique.schedule.getNewRow();
        yP_Row2.set("lastProcessID", yP_Object.getAncestor().getProcessID());
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Technique.schedule);
        yP_ComplexGabarit.set(yP_Row.getPrimaryKeyName(), YP_ComplexGabarit.OPERATOR.EQUAL, yP_Row.getPrimaryKey());
        try {
            yP_TCD_DCC_Technique.schedule.lock();
            int n = yP_TCD_DCC_Technique.schedule.updateRowSuchAs(yP_Row2, yP_ComplexGabarit);
            if (n >= 0 && n == 0) {
                this.logger(3, "setCronCurrentThreadID() cron not found. Maybe a one shot cron...");
                return 0;
            }
            if (n > 1) {
                this.logger(2, "setCronCurrentThreadID() too many cron found...");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "setCronCurrentThreadID() :" + exception);
            return -1;
        }
        finally {
            yP_TCD_DCC_Technique.schedule.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getCronAction")) {
                return this.getCronAction();
            }
            if (string.contentEquals("createUrgentCron")) {
                YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)objectArray[0];
                String string2 = (String)objectArray[1];
                String string3 = (String)objectArray[2];
                return this.createUrgentCron(yP_TCD_DCC_Business, string2, string3);
            }
            if (string.contentEquals("changeCronScheduleTime")) {
                YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)objectArray[0];
                long l = (Long)objectArray[1];
                return this.changeCronScheduleTime(yP_TCD_DCC_Business.getContractIdentifier(), l);
            }
            if (string.contentEquals("getCronList")) {
                String string4 = (String)objectArray[0];
                String string5 = (String)objectArray[1];
                String string6 = (String)objectArray[2];
                return this.getCronList(string4, string5, string6);
            }
            if (string.contentEquals("deleteCron")) {
                String string7 = (String)objectArray[0];
                String string8 = (String)objectArray[1];
                String string9 = (String)objectArray[2];
                return this.deleteCron(string7, string8, string9);
            }
            if (string.contentEquals("setCronCurrentThreadID")) {
                YP_Row yP_Row = (YP_Row)objectArray[0];
                return this.setCronCurrentThreadID(yP_Object, yP_Row);
            }
            if (!string.contentEquals("updateCronAction")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            try {
                Timestamp timestamp = (Timestamp)objectArray[0];
                String string10 = (String)objectArray[1];
                String string11 = (String)objectArray[2];
                String string12 = (String)objectArray[3];
                String string13 = (String)objectArray[4];
                String string14 = (String)objectArray[5];
                String string15 = (String)objectArray[6];
                int n = (Integer)objectArray[7];
                String string16 = (String)objectArray[8];
                int n2 = (Integer)objectArray[9];
                int n3 = (Integer)objectArray[10];
                int n4 = (Integer)objectArray[11];
                String string17 = (String)objectArray[12];
                return this.updateCronAction(timestamp, string10, string11, string12, string13, string14, string15, n, string16, n2, n3, n4, string17);
            }
            catch (Exception exception) {
                this.logger(2, "dealRequest() bad parameter for updateCronAction" + exception);
                return null;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }
}

