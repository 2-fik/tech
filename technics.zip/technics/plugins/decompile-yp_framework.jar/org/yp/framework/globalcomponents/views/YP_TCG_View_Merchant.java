/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.InitializationStatusEnumeration;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_Merchant
extends YP_TCG_View {
    private static final String CLIENT_PROPERTIES_PREFIX = "CLI_";
    private static final String DEFAULT_CARD_INSERTION_TIMEOUT_IN_SEC = "60";
    private static final String DEFAULT_PIN_ENTRY_TIMEOUT_IN_SEC = "60";
    private static final String DEFAULT_AMOUNT_VALIDATION_TIMEOUT_IN_SEC = "60";
    private static final String DEFAULT_TIMEOUT_BETWEEN_TICKETS_IN_SEC = "15";
    private static final String DEFAULT_MERCHANT_AUTHENTICATION_TIMEOUT_IN_SEC = "300";
    private static final String DEFAULT_INFORMATION_MESSAGE_TIMEOUT_IN_SEC = "2";
    private static final int MIN_TIMEOUT_IN_SEC_1 = 5;
    private static final int MIN_TIMEOUT_IN_SEC_2 = 1;
    private static final String TIMERS_MANAGEMENT = "TIMERS_MANAGEMENT";
    private static final String CLI_CIT_TEXT_FIELD = "CLI_CIT_TEXT_FIELD";
    private static final String CLI_PET_TEXT_FIELD = "CLI_PET_TEXT_FIELD";
    private static final String CLI_AVT_TEXT_FIELD = "CLI_AVT_TEXT_FIELD";
    private static final String CLI_TBT_TEXT_FIELD = "CLI_TBT_TEXT_FIELD";
    private static final String CLI_MAT_TEXT_FIELD = "CLI_MAT_TEXT_FIELD";
    private static final String CLI_IMT_TEXT_FIELD = "CLI_IMT_TEXT_FIELD";
    private static final String TIMERS_MANAGEMENT_LABEL = "Gestion des temporisations";
    private static final String CARD_INSERTION_TIMEOUT_LABEL = "Insertion carte (secondes, minimum: 5)";
    private static final String PIN_ENTRY_TIMEOUT_LABEL = "Saisie code pin (secondes, minimum: 5)";
    private static final String AMOUNT_VALIDATION_TIMEOUT_LABEL = "Validation du montant (secondes, minimum: 5)";
    private static final String TIMEOUT_BETWEEN_TICKETS_LABEL = "Impression second ticket (secondes, minimum: 5)";
    private static final String MERCHANT_AUTHENTICATION_TIMEOUT_LABEL = "Mot de passe commer\u00e7ant (secondes, minimum: 5)";
    private static final String INFORMATION_MESSAGE_TIMEOUT_LABEL = "Message d'information (secondes, minimum: 1)";
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_Merchant(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Merchant";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = this.dataContainerTechnique.merchant.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject = this.dataContainerTechnique.merchant;
            } else {
                field = this.dataContainerTechnique.brand.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject = this.dataContainerTechnique.brand;
                } else if (string.contentEquals("merchantIdentifier")) {
                    yP_View.addCustomColumn(string, string2, "string", dAO_ViewColumn.defaultRank);
                    yP_TCD_DesignAccesObject = null;
                } else {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "createEmptyView() unknown column:" + string);
                    continue;
                }
            }
            if (yP_TCD_DesignAccesObject != null && yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * Could not resolve type clashes
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        Object object;
        List<YP_TCD_DCC_Merchant> list22;
        List<YP_Row> list32;
        YP_ComplexGabarit yP_ComplexGabarit;
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        boolean bl = false;
        String string = null;
        List<YP_Gabarit> list4 = yP_PROT_IHM.getSearchGabarit();
        if (list4 != null && !list4.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.merchant);
            for (List<YP_Row> list32 : list4) {
                try {
                    if (((YP_Gabarit)((Object)list32)).objectTosearch == null) {
                        yP_ComplexGabarit.set(((YP_Gabarit)((Object)list32)).fieldName, ((YP_Gabarit)((Object)list32)).operator);
                        continue;
                    }
                    yP_View.dealEnumColumn((YP_Gabarit)((Object)list32));
                    if (((YP_Gabarit)((Object)list32)).objectTosearch == null) continue;
                    if (((YP_Gabarit)((Object)list32)).fieldName.contentEquals("idMerchant") && ((YP_Gabarit)((Object)list32)).objectTosearch != null && ((YP_Gabarit)((Object)list32)).objectTosearch instanceof Long && ((YP_Gabarit)((Object)list32)).operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                        bl = true;
                    }
                    if (((YP_Gabarit)((Object)list32)).fieldName.contentEquals("idMerchant") && ((YP_Gabarit)((Object)list32)).objectTosearch != null && ((YP_Gabarit)((Object)list32)).objectTosearch instanceof String) {
                        string = (String)((YP_Gabarit)((Object)list32)).objectTosearch;
                    }
                    if (((YP_Gabarit)((Object)list32)).fieldName.contentEquals("brandName")) {
                        list22 = (YP_TCD_DCC_Brand)this.dataContainerManager.dealRequest(this, "getDataContainerBrand", ((YP_Gabarit)((Object)list32)).objectTosearch);
                        if (list22 != null) {
                            yP_ComplexGabarit.set("idBrand", ((YP_Gabarit)((Object)list32)).operator, ((YP_TCD_DCC_Brand)((Object)list22)).getBrandRow().getPrimaryKey());
                            continue;
                        }
                        switch (((YP_Gabarit)((Object)list32)).operator) {
                            case DIFFERENT: 
                            case DIFFERENT_AFTER_GROUP: {
                                break;
                            }
                            default: {
                                yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, -1234);
                                break;
                            }
                        }
                        continue;
                    }
                    yP_ComplexGabarit.set(((YP_Gabarit)((Object)list32)).fieldName, ((YP_Gabarit)((Object)list32)).operator, ((YP_Gabarit)((Object)list32)).objectTosearch);
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + exception);
                }
            }
        } else {
            yP_ComplexGabarit = null;
        }
        HashMap hashMap = new HashMap();
        if (bl) {
            list32 = this.dataContainerTechnique.merchant.getRowListSuchAs(yP_ComplexGabarit);
            if (list32 == null) {
                this.logger(2, "getView() null list");
                return yP_View;
            }
            for (List<YP_TCD_DCC_Merchant> list22 : list32) {
                hashMap.put(((YP_Row)((Object)list22)).getPrimaryKey(), (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", ((YP_Row)((Object)list22)).getPrimaryKey()));
            }
        } else if (yP_Transaction.getContractIdentifier().contentEquals("KERNEL") && yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier() <= 0L) {
            list32 = this.dataContainerTechnique.merchant.getRowListSuchAs(yP_ComplexGabarit);
            if (list32 != null && list32.isEmpty() && string != null && string.length() >= 6 && yP_ComplexGabarit != null) {
                yP_ComplexGabarit.reset("idMerchant", YP_ComplexGabarit.OPERATOR.DIFFERENT, "0");
                yP_ComplexGabarit.reset("merchantName", YP_ComplexGabarit.OPERATOR.START_WITH, string);
                list32 = this.dataContainerTechnique.merchant.getRowListSuchAs(yP_ComplexGabarit);
            }
            if (list32 == null) {
                this.logger(2, "getView() null list");
                return yP_View;
            }
            for (List<YP_TCD_DCC_Merchant> list22 : list32) {
                hashMap.put(((YP_Row)((Object)list22)).getPrimaryKey(), (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", ((YP_Row)((Object)list22)).getPrimaryKey()));
            }
        } else {
            list32 = new ArrayList();
            list22 = yP_Transaction.getMerchantList();
            if (list22 == null) {
                this.logger(2, "getView() no application List");
                return null;
            }
            if (list22.isEmpty()) {
                this.logger(3, "getView() application List empty");
                return yP_View;
            }
            for (Object object2 : list22) {
                object = ((YP_TCD_DCC_Merchant)object2).getMerchantRow();
                list32.add((YP_Row)object);
                hashMap.put(((YP_Row)object).getPrimaryKey(), object2);
            }
            if ((list32 = YP_TCD_DesignAccesObject.getRowListSuchAs(list32, yP_ComplexGabarit)) == null) {
                this.logger(2, "getView() null list");
                return null;
            }
            if (list32.isEmpty()) {
                this.logger(4, "getView() nothing found");
                return yP_View;
            }
        }
        int n3 = 0;
        while (n3 < list32.size()) {
            Object object3;
            YP_Row yP_Row;
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
            Object object2;
            block84: {
                Cloneable cloneable;
                block85: {
                    Object object4;
                    Object object5;
                    List<YP_Row> list5;
                    Object object6;
                    Object object7;
                    Object object8;
                    String string2;
                    Object object9;
                    block86: {
                        block83: {
                            if (n2 == 0 && n3 > n) break;
                            object2 = list32.get(n3);
                            yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)hashMap.get(((YP_Row)object2).getPrimaryKey());
                            object = yP_TCD_DCC_Merchant.getDataContainerBrand();
                            yP_Row = ((YP_TCD_DCC_Brand)object).getBrandRow();
                            yP_View.setRowID(n3, String.valueOf(((YP_Row)object2).getFather().getFullTableName()) + "#" + ((YP_Row)object2).getPrimaryKeyName() + "#" + ((YP_Row)object2).getPrimaryKey());
                            if (yP_TCD_DCC_Interface_View.isWriteAllowed(l, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) break block83;
                            yP_View.setRowActionable(n3, false);
                            break block84;
                        }
                        yP_View.setRowActionable(n3, true);
                        if (list32.size() != 1) break block84;
                        cloneable = new ArrayList();
                        object9 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object9).formName = "MerchantForm";
                        ((YP_TCD_DC_Context.Action)object9).id = "MODIFY_MERCHANT";
                        ((YP_TCD_DC_Context.Action)object9).label = this.getLabel("MODIFY_MERCHANT");
                        cloneable.add(object9);
                        if (UtilsYP.isSATIMServer()) break block85;
                        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 || (object3 = this.dataContainerTechnique.getMerchantProperties(yP_TCD_DCC_Merchant, CLIENT_PROPERTIES_PREFIX, null)) == null) break block86;
                        object9 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = yP_TCD_DCC_Merchant.getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object9).formName = "StandardGenericForm";
                        ((YP_TCD_DC_Context.Action)object9).id = TIMERS_MANAGEMENT;
                        ((YP_TCD_DC_Context.Action)object9).label = TIMERS_MANAGEMENT_LABEL;
                        ((YP_TCD_DC_Context.Action)object9).propertiesList = new ArrayList<Property>();
                        Object object10 = "60";
                        Object object11 = "60";
                        string2 = "60";
                        object8 = DEFAULT_TIMEOUT_BETWEEN_TICKETS_IN_SEC;
                        object7 = DEFAULT_MERCHANT_AUTHENTICATION_TIMEOUT_IN_SEC;
                        object6 = DEFAULT_INFORMATION_MESSAGE_TIMEOUT_IN_SEC;
                        list5 = object3.iterator();
                        while (list5.hasNext()) {
                            object5 = (Property)list5.next();
                            switch (((Property)object5).getName()) {
                                case "CLI_CIT": {
                                    object10 = ((Property)object5).getValue();
                                    break;
                                }
                                case "CLI_PET": {
                                    object11 = ((Property)object5).getValue();
                                    break;
                                }
                                case "CLI_AVT": {
                                    string2 = ((Property)object5).getValue();
                                    break;
                                }
                                case "CLI_TBT": {
                                    object8 = ((Property)object5).getValue();
                                    break;
                                }
                                case "CLI_MAT": {
                                    object7 = ((Property)object5).getValue();
                                    break;
                                }
                                case "CLI_IMT": {
                                    object6 = ((Property)object5).getValue();
                                }
                            }
                        }
                        Property property = new Property();
                        property.setName(CLI_CIT_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)CARD_INSERTION_TIMEOUT_LABEL);
                        object4.put("text", object10);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        property = new Property();
                        property.setName(CLI_PET_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)PIN_ENTRY_TIMEOUT_LABEL);
                        object4.put("text", object11);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        property = new Property();
                        property.setName(CLI_AVT_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)AMOUNT_VALIDATION_TIMEOUT_LABEL);
                        object4.put("text", (Object)string2);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        property = new Property();
                        property.setName(CLI_TBT_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)TIMEOUT_BETWEEN_TICKETS_LABEL);
                        object4.put("text", object8);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        property = new Property();
                        property.setName(CLI_MAT_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)MERCHANT_AUTHENTICATION_TIMEOUT_LABEL);
                        object4.put("text", object7);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        property = new Property();
                        property.setName(CLI_IMT_TEXT_FIELD);
                        object4 = new JSONObject();
                        object4.put("label", (Object)INFORMATION_MESSAGE_TIMEOUT_LABEL);
                        object4.put("text", object6);
                        property.setValue(object4.toString());
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add(property);
                        cloneable.add(object9);
                    }
                    if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) {
                        boolean bl2 = false;
                        boolean bl3 = false;
                        for (Object object10 : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                            long l2 = (Long)((YP_TCD_DCC_Business)object10).getApplicationPlugin().getApplicationRow().getFieldValueByName("idApplication");
                            if (l2 == 18L || l2 == 53L) {
                                if (!((YP_TCD_DCC_Business)object10).getActivationCode().contentEquals("1")) continue;
                                bl2 = true;
                                continue;
                            }
                            if (l2 != 33L && l2 != 36L) continue;
                            bl3 = true;
                            break;
                        }
                        if (bl2 && !bl3) {
                            object9 = new YP_TCD_DC_Context.Action();
                            ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = yP_TCD_DCC_Merchant.getContractIdentifier();
                            ((YP_TCD_DC_Context.Action)object9).formName = "StandardConfirmationForm";
                            ((YP_TCD_DC_Context.Action)object9).id = "Migration55";
                            ((YP_TCD_DC_Context.Action)object9).label = "Migration55";
                            cloneable.add(object9);
                        }
                        boolean bl4 = false;
                        boolean bl5 = false;
                        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                            long l3 = (Long)yP_TCD_DCC_Business.getApplicationPlugin().getApplicationRow().getFieldValueByName("idApplication");
                            if (l3 == 67L) {
                                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1")) continue;
                                bl4 = true;
                                continue;
                            }
                            if (l3 != 97L) continue;
                            bl5 = true;
                            break;
                        }
                        if (bl4 && !bl5) {
                            object9 = new YP_TCD_DC_Context.Action();
                            ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = yP_TCD_DCC_Merchant.getContractIdentifier();
                            ((YP_TCD_DC_Context.Action)object9).formName = "StandardConfirmationForm";
                            ((YP_TCD_DC_Context.Action)object9).id = "MigrationNxCB55";
                            ((YP_TCD_DC_Context.Action)object9).label = "Migration55";
                            cloneable.add(object9);
                        }
                        object9 = new YP_TCD_DC_Context.Action();
                        ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = yP_TCD_DCC_Merchant.getContractIdentifier();
                        ((YP_TCD_DC_Context.Action)object9).formName = "StandardGenericForm";
                        ((YP_TCD_DC_Context.Action)object9).id = "ASSIGN_TERMINALS";
                        ((YP_TCD_DC_Context.Action)object9).label = this.getLabel("ASSIGN_TERMINALS");
                        ((YP_TCD_DC_Context.Action)object9).propertiesList = new ArrayList<Property>();
                        string2 = new JSONArray();
                        object8 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
                        for (String string3 : ((YP_TCD_DesignAccesObject)object8).getDistinctStringValueList("terminalManufacturerID")) {
                            string2.put((Object)string3);
                        }
                        object7 = new Property();
                        ((Property)object7).setName("MANUFACTURER_COMBOBOX_FIELD");
                        object6 = new JSONObject();
                        object6.put("selectedIndex", 0);
                        object6.put("label", (Object)"Manufacturer");
                        object6.put("items", (Object)string2);
                        object6.put("enabled", true);
                        object4 = object6.toString();
                        ((Property)object7).setValue((String)object4);
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add((Property)object7);
                        object7 = new Property();
                        ((Property)object7).setName("TERMINAL_SN_TEXT_FIELD");
                        object6 = new JSONObject();
                        object6.put("label", (Object)"S/N");
                        object6.put("text", (Object)"");
                        object6.put("enabled", true);
                        object4 = object6.toString();
                        ((Property)object7).setValue((String)object4);
                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add((Property)object7);
                        cloneable.add(object9);
                        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) {
                            List<Long> list62;
                            object9 = new YP_TCD_DC_Context.Action();
                            ((YP_TCD_DC_Context.Action)object9).applicationIdentifier = ((YP_Object)object).getContractIdentifier();
                            ((YP_TCD_DC_Context.Action)object9).formName = "ParametersEditionForm";
                            ((YP_TCD_DC_Context.Action)object9).id = "PARAMETERS_EDITION";
                            ((YP_TCD_DC_Context.Action)object9).label = this.getLabel("PARAMETERS_EDITION");
                            ((YP_TCD_DC_Context.Action)object9).propertiesList = new ArrayList<Property>();
                            object5 = this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
                            yP_ComplexGabarit = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object5);
                            yP_ComplexGabarit.set("idMerchant", YP_ComplexGabarit.OPERATOR.EQUAL, ((YP_Row)object2).getPrimaryKey());
                            list5 = ((YP_TCD_DesignAccesObject)object5).getRowListSuchAs(yP_ComplexGabarit);
                            for (List<Long> list62 : list5) {
                                object7 = new Property();
                                ((Property)object7).setName(((YP_Row)((Object)list62)).getFieldStringValueByName("key"));
                                ((Property)object7).setValue(((YP_Row)((Object)list62)).getFieldStringValueByName("value"));
                                ((YP_TCD_DC_Context.Action)object9).propertiesList.add((Property)object7);
                            }
                            yP_ComplexGabarit = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object5);
                            yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.EQUAL, yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
                            list5 = ((YP_TCD_DesignAccesObject)object5).getRowListSuchAs(yP_ComplexGabarit);
                            for (List<Long> list62 : list5) {
                                boolean bl6 = false;
                                for (Object object12 : ((YP_TCD_DC_Context.Action)object9).propertiesList) {
                                    if (!((Property)object12).getName().contentEquals(((YP_Row)((Object)list62)).getFieldStringValueByName("key"))) continue;
                                    bl6 = true;
                                }
                                if (bl6) continue;
                                object7 = new Property();
                                ((Property)object7).setName("parent_" + ((YP_Row)((Object)list62)).getFieldStringValueByName("key"));
                                ((Property)object7).setValue(((YP_Row)((Object)list62)).getFieldStringValueByName("value"));
                                ((YP_TCD_DC_Context.Action)object9).propertiesList.add((Property)object7);
                            }
                            list62 = this.dataContainerTechnique.getGroupIDs(yP_TCD_DCC_Merchant.getDataContainerBrand().getIDBrand());
                            if (list62 != null) {
                                Object object12;
                                object12 = list62.iterator();
                                while (object12.hasNext()) {
                                    long l4 = object12.next();
                                    yP_ComplexGabarit = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)object5);
                                    yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, l4);
                                    list5 = ((YP_TCD_DesignAccesObject)object5).getRowListSuchAs(yP_ComplexGabarit);
                                    for (Object object13 : list5) {
                                        boolean bl7 = false;
                                        for (Property property : ((YP_TCD_DC_Context.Action)object9).propertiesList) {
                                            if (!property.getName().contentEquals(((YP_Row)object13).getFieldStringValueByName("key")) && !property.getName().contentEquals("parent_" + ((YP_Row)object13).getFieldStringValueByName("key"))) continue;
                                            bl7 = true;
                                        }
                                        if (bl7) continue;
                                        object7 = new Property();
                                        ((Property)object7).setName("parent_" + ((YP_Row)object13).getFieldStringValueByName("key"));
                                        ((Property)object7).setValue(((YP_Row)object13).getFieldStringValueByName("value"));
                                        ((YP_TCD_DC_Context.Action)object9).propertiesList.add((Property)object7);
                                    }
                                }
                            }
                            cloneable.add(object9);
                        }
                    }
                }
                yP_View.setRowActionList(n3, (List<YP_TCD_DC_Context.Action>)((Object)cloneable));
            }
            for (Cloneable cloneable : list) {
                object3 = YP_Row.getStringValue(((DAO_ViewColumn)cloneable).columnName);
                Field field = this.dataContainerTechnique.merchant.getFieldByName((String)object3);
                Object object14 = null;
                if (field != null) {
                    object14 = object2;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName((String)object3);
                    if (field != null) {
                        object14 = yP_Row;
                    }
                }
                if (field != null && object14 != null) {
                    this.addFieldValue(yP_View, field, (YP_Row)object14, (String)object3, n3);
                    continue;
                }
                if (((String)object3).contentEquals("merchantIdentifier")) {
                    yP_View.addFieldValue(n3, (String)object3, yP_TCD_DCC_Merchant.getContractIdentifier());
                    continue;
                }
                if (this.getLogLevel() < 2) continue;
                this.logger(2, "getView() unknown column:" + (String)object3);
            }
            ++n3;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.merchant;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        block25: {
            try {
                if (yP_Transaction != null) break block25;
                this.logger(2, "executeAction() YP_Transaction is null");
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "executeAction() ", exception);
                return -1;
            }
        }
        switch (action.id) {
            case "TIMERS_MANAGEMENT": {
                return this.timersManagement(yP_Transaction, yP_Row, action);
            }
            case "Migration55": {
                return this.migration55(yP_Transaction, yP_Row);
            }
            case "MigrationNxCB55": {
                return this.migrationNxCB55(yP_Transaction, yP_Row);
            }
            case "ASSIGN_TERMINALS": {
                return this.assignTerminals(yP_Transaction, yP_Row, action);
            }
            case "PARAMETERS_EDITION": {
                return this.parametersEdition(yP_Transaction, yP_Row, action);
            }
            case "UPDATE_TIMEZONE": {
                return this.updateTimeZone(yP_Transaction, yP_Row, action);
            }
        }
        this.logger(2, "executeAction() unknown action " + action.id);
        return -1;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int timersManagement(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "timersManagement() No rights");
            return -1;
        }
        if (action.propertiesList != null && !action.propertiesList.isEmpty()) {
            void var13_16;
            int n = 0;
            String string = "";
            String string2 = "";
            String string3 = "";
            String string4 = "";
            String string5 = "";
            String string6 = "";
            String string7 = "";
            for (Property property : action.propertiesList) {
                switch (property.getName()) {
                    case "CLI_PET_TEXT_FIELD": 
                    case "CLI_CIT_TEXT_FIELD": 
                    case "CLI_IMT_TEXT_FIELD": 
                    case "CLI_AVT_TEXT_FIELD": 
                    case "CLI_MAT_TEXT_FIELD": 
                    case "CLI_TBT_TEXT_FIELD": {
                        JSONObject jSONObject = new JSONObject(property.getValue());
                        try {
                            string = jSONObject.get("text").toString();
                            n = Integer.parseInt(string);
                            if (n < 0) {
                                this.logger(2, "executeAction() TIMERS_MANAGEMENT: invalid value for: " + jSONObject.get("label").toString());
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                return -1;
                            }
                            int n2 = 0;
                            n2 = property.getName().contentEquals(CLI_IMT_TEXT_FIELD) ? 1 : 5;
                            if (n < n2) {
                                this.logger(2, "executeAction() TIMERS_MANAGEMENT: too low value for: " + jSONObject.get("label").toString() + ", minimum expected is: " + n2);
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                                return -1;
                            }
                        }
                        catch (NumberFormatException numberFormatException) {
                            this.logger(2, "executeAction() TIMERS_MANAGEMENT: invalid value for: " + jSONObject.get("label").toString());
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                            return -1;
                        }
                        switch (property.getName()) {
                            case "CLI_CIT_TEXT_FIELD": {
                                string2 = string;
                                break;
                            }
                            case "CLI_PET_TEXT_FIELD": {
                                string3 = string;
                                break;
                            }
                            case "CLI_AVT_TEXT_FIELD": {
                                string4 = string;
                                break;
                            }
                            case "CLI_TBT_TEXT_FIELD": {
                                string5 = string;
                                break;
                            }
                            case "CLI_MAT_TEXT_FIELD": {
                                string6 = string;
                                break;
                            }
                            case "CLI_IMT_TEXT_FIELD": {
                                string7 = string;
                            }
                        }
                        break;
                    }
                }
            }
            String string8 = "";
            Object object = "";
            String string9 = "";
            String string10 = "";
            String string11 = "";
            String string12 = "";
            String string13 = yP_Row.getFieldStringValueByName("merchantName");
            if (string13 == null || string13.isEmpty()) {
                this.logger(2, "executeAction() TIMERS_MANAGEMENT: selectedMerchantName is null or empty");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = null;
            for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant2 : yP_Transaction.getMerchantList()) {
                if (!string13.contentEquals(yP_TCD_DCC_Merchant2.getMerchantName())) continue;
                yP_TCD_DCC_Merchant = yP_TCD_DCC_Merchant2;
                break;
            }
            if (yP_TCD_DCC_Merchant == null) {
                this.logger(2, "executeAction() TIMERS_MANAGEMENT: dataContainerMerchant not found");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            List<Property> list = this.dataContainerTechnique.getMerchantProperties(yP_TCD_DCC_Merchant, CLIENT_PROPERTIES_PREFIX, null);
            if (list != null) {
                for (Property property : list) {
                    switch (property.getName()) {
                        case "CLI_CIT": {
                            String string14 = property.getValue();
                            break;
                        }
                        case "CLI_PET": {
                            object = property.getValue();
                            break;
                        }
                        case "CLI_AVT": {
                            string9 = property.getValue();
                            break;
                        }
                        case "CLI_TBT": {
                            string10 = property.getValue();
                            break;
                        }
                        case "CLI_MAT": {
                            string11 = property.getValue();
                            break;
                        }
                        case "CLI_IMT": {
                            string12 = property.getValue();
                            break;
                        }
                    }
                }
            }
            if (!(string2.contentEquals((CharSequence)var13_16) || var13_16.isEmpty() && string2.contentEquals("60"))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_CIT", string2);
            }
            if (!(string3.contentEquals((CharSequence)object) || ((String)object).isEmpty() && string3.contentEquals("60"))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_PET", string3);
            }
            if (!(string4.contentEquals(string9) || string9.isEmpty() && string4.contentEquals("60"))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_AVT", string4);
            }
            if (!(string5.contentEquals(string10) || string10.isEmpty() && string5.contentEquals(DEFAULT_TIMEOUT_BETWEEN_TICKETS_IN_SEC))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_TBT", string5);
            }
            if (!(string6.contentEquals(string11) || string11.isEmpty() && string6.contentEquals(DEFAULT_MERCHANT_AUTHENTICATION_TIMEOUT_IN_SEC))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_MAT", string6);
            }
            if (!(string7.contentEquals(string12) || string12.isEmpty() && string7.contentEquals(DEFAULT_INFORMATION_MESSAGE_TIMEOUT_IN_SEC))) {
                this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, "CLI_IMT", string7);
            }
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int migration55(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "migration55() No rights");
                return -1;
            }
            if (yP_Transaction.getMerchantList().isEmpty()) {
                this.logger(2, "migration55() no access");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (yP_Transaction.getMerchantList().size() != 1) {
                this.logger(2, "migration55() too many merchants");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = yP_Transaction.getMerchantList().get(0);
            YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business = null;
            YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business2 = null;
            Object object = yP_TCD_DCC_Merchant.dataContainerBusinessList.iterator();
            while (true) {
                if (!object.hasNext()) {
                    if (yP_TCD_DCC_EFT_Business != null) break;
                    this.logger(2, "migration55() No ICC found");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DCC_Business yP_TCD_DCC_Business = object.next();
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1")) continue;
                long l = (Long)yP_TCD_DCC_Business.getApplicationPlugin().getApplicationRow().getFieldValueByName("idApplication");
                if (l == 18L || l == 53L) {
                    if (yP_TCD_DCC_EFT_Business != null) {
                        this.logger(2, "migration55() too many ICC");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                        return -1;
                    }
                    yP_TCD_DCC_EFT_Business = (YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business;
                }
                if (l != 58L) continue;
                if (yP_TCD_DCC_EFT_Business2 != null) {
                    this.logger(2, "migration55() too many NFC");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                yP_TCD_DCC_EFT_Business2 = (YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business;
            }
            if (yP_TCD_DCC_EFT_Business.transaction.size() != 0) {
                yP_TCD_DCC_EFT_Business.executeRequest(yP_Transaction, YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation);
            }
            if (yP_TCD_DCC_EFT_Business.transaction.size() != 0) {
                this.logger(2, "migration55() Still some transaction after reconciliation");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            if (yP_TCD_DCC_EFT_Business2 != null) {
                if (yP_TCD_DCC_EFT_Business2.transaction.size() != 0) {
                    yP_TCD_DCC_EFT_Business2.executeRequest(yP_Transaction, YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation);
                }
                if (yP_TCD_DCC_EFT_Business2.transaction.size() != 0) {
                    this.logger(2, "migration55() Still some transaction after reconciliation");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
            }
            if (this.addContract(yP_Transaction, yP_TCD_DCC_Merchant, yP_Transaction.getDataContainerTransaction(), yP_TCD_DCC_EFT_Business) != 1) {
                this.logger(2, "migration55() Migration55 KO");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            if (yP_TCD_DCC_EFT_Business2 != null && this.addContract(yP_Transaction, yP_TCD_DCC_Merchant, yP_Transaction.getDataContainerTransaction(), yP_TCD_DCC_EFT_Business2) != 1) {
                this.logger(2, "migration55() Migration55 KO");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            YP_Object yP_Object = this.getPluginByName("Scheduler");
            object = yP_TCD_DCC_EFT_Business.getContractRow();
            ((YP_Row)object).set("activationCode", "0");
            ((YP_Row)object).set("initializationStatus", InitializationStatusEnumeration.NOT_INITIALISED);
            ((YP_Row)object).persist();
            yP_Object.dealRequest(this, "deleteCron", yP_TCD_DCC_EFT_Business.getContractIdentifier(), "", "");
            if (yP_TCD_DCC_EFT_Business2 != null) {
                object = yP_TCD_DCC_EFT_Business2.getContractRow();
                ((YP_Row)object).set("activationCode", "0");
                ((YP_Row)object).set("initializationStatus", InitializationStatusEnumeration.NOT_INITIALISED);
                ((YP_Row)object).persist();
                yP_Object.dealRequest(this, "deleteCron", yP_TCD_DCC_EFT_Business2.getContractIdentifier(), "", "");
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "migration55() ", exception);
            return -1;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private int migrationNxCB55(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                this.logger(2, "migrationNxCB55() No rights");
                return -1;
            }
            if (yP_Transaction.getMerchantList().isEmpty()) {
                this.logger(2, "migrationNxCB55() no access");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (yP_Transaction.getMerchantList().size() != 1) {
                this.logger(2, "migrationNxCB55() too many merchants");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = yP_Transaction.getMerchantList().get(0);
            YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business = null;
            Object object = yP_TCD_DCC_Merchant.dataContainerBusinessList.iterator();
            while (true) {
                long l;
                if (!object.hasNext()) {
                    if (yP_TCD_DCC_EFT_Business != null) break;
                    this.logger(2, "migrationNxCB55() No ICC found");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DCC_Business yP_TCD_DCC_Business = object.next();
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (l = ((Long)yP_TCD_DCC_Business.getApplicationPlugin().getApplicationRow().getFieldValueByName("idApplication")).longValue()) != 67L) continue;
                if (yP_TCD_DCC_EFT_Business != null) {
                    this.logger(2, "migrationNxCB55() too many ICC");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                yP_TCD_DCC_EFT_Business = (YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business;
            }
            if (yP_TCD_DCC_EFT_Business.transaction.size() != 0) {
                yP_TCD_DCC_EFT_Business.executeRequest(yP_Transaction, YP_TCD_PosProtocol.REQUEST_TYPE.Reconciliation);
            }
            if (yP_TCD_DCC_EFT_Business.transaction.size() != 0) {
                this.logger(2, "migrationNxCB55() Still some transaction after reconciliation");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                return -1;
            }
            if (this.addContract(yP_Transaction, yP_TCD_DCC_Merchant, yP_Transaction.getDataContainerTransaction(), yP_TCD_DCC_EFT_Business) != 1) {
                this.logger(2, "migrationNxCB55() Migration55 KO");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            YP_Object yP_Object = this.getPluginByName("Scheduler");
            object = yP_TCD_DCC_EFT_Business.getContractRow();
            ((YP_Row)object).set("activationCode", "0");
            ((YP_Row)object).set("initializationStatus", InitializationStatusEnumeration.NOT_INITIALISED);
            ((YP_Row)object).persist();
            yP_Object.dealRequest(this, "deleteCron", yP_TCD_DCC_EFT_Business.getContractIdentifier(), "", "");
            return -1;
        }
        catch (Exception exception) {
            this.logger(2, "migrationNxCB55() ", exception);
        }
        return -1;
    }

    private int assignTerminals(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1 && yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 2) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "assignTerminals() No rights");
            return -1;
        }
        String string = "";
        String string2 = "";
        for (Property property : action.propertiesList) {
            String string3;
            JSONObject jSONObject = new JSONObject(property.getValue());
            if (property.getName().startsWith("MANUFACTURER")) {
                int n = Integer.parseInt(jSONObject.get("selectedIndex").toString());
                JSONArray jSONArray = (JSONArray)jSONObject.get("items");
                string2 = string3 = jSONArray.getString(n);
                continue;
            }
            if (!property.getName().startsWith("TERMINAL_SN")) continue;
            string = string3 = jSONObject.get("text").toString();
        }
        return this.addTerminalRowForMerchant(yP_Transaction, yP_Row, string2, string);
    }

    private int parametersEdition(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() != 1) {
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
            this.logger(2, "parametersEdition() No rights");
            return -1;
        }
        String string = yP_Row.getFieldStringValueByName("merchantName");
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = null;
        for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant2 : yP_Transaction.getMerchantList()) {
            if (!string.contentEquals(yP_TCD_DCC_Merchant2.getMerchantName())) continue;
            yP_TCD_DCC_Merchant = yP_TCD_DCC_Merchant2;
            break;
        }
        if (yP_TCD_DCC_Merchant != null && action.propertiesList != null) {
            boolean bl = false;
            for (Property property : action.propertiesList) {
                String string2 = property.getName();
                String string3 = property.getValue();
                if (string2 == null || string2.isEmpty() || string3 == null) continue;
                if (string3.equals("::TO_DELETE::")) {
                    this.dataContainerTechnique.deleteParameter(yP_TCD_DCC_Merchant, string2);
                } else {
                    this.dataContainerTechnique.setParameter(yP_TCD_DCC_Merchant, string2, string3);
                }
                bl = true;
            }
            if (bl) {
                yP_TCD_DCC_Merchant.setMerchantRow(yP_TCD_DCC_Merchant.getMerchantRow());
            }
        }
        return 0;
    }

    private int updateTimeZone(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
        block11: {
            String string;
            block10: {
                block9: {
                    block8: {
                        if (yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 1 || yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel() == 2) break block8;
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(102));
                        this.logger(2, "updateTimeZone() No rights");
                        return -1;
                    }
                    if (!yP_Transaction.getMerchantList().isEmpty()) break block9;
                    this.logger(2, "updateTimeZone() update timeZone no access");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                string = yP_Row.getFieldStringValueByName("merchantName");
                if (string != null && !string.isEmpty()) break block10;
                this.logger(2, "updateTimeZone() TIMERS_MANAGEMENT: selectedMerchantName is null or empty");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                return -1;
            }
            yP_TCD_DCC_Merchant = null;
            for (YP_TCD_DCC_Merchant yP_TCD_DC_Context : yP_Transaction.getMerchantList()) {
                if (!string.contentEquals(yP_TCD_DC_Context.getMerchantName())) continue;
                yP_TCD_DCC_Merchant = yP_TCD_DC_Context;
                break;
            }
            if (yP_TCD_DCC_Merchant != null) break block11;
            this.logger(2, "updateTimeZone() TIMERS_MANAGEMENT: dataContainerMerchant not found");
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
        try {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                YP_Row yP_Row2 = yP_TCD_DCC_Business.getContractRow();
                if (yP_Row2.getFieldStringValueByName("timeZone") == null || yP_Row2.getFieldStringValueByName("timeZone").isEmpty()) continue;
                yP_Row2.set("timeZone", yP_Row.getFieldStringValueByName("timeZone"));
                yP_Row2.persist();
            }
            return 0;
        }
        catch (Exception exception) {
            this.logger(2, "updateTimeZone() ", exception);
            return -1;
        }
    }

    private int addTerminalRowForMerchant(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        Object object;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = yP_Transaction.getDataContainerTransaction().getDataContainerBrand();
        if (yP_TCD_DCC_Brand == null) {
            this.logger(2, "addTerminalRowForMerchant() no brand selected");
            return -1;
        }
        String string3 = String.valueOf(string) + '_' + string2;
        YP_Object yP_Object = yP_Transaction.getDataContainerTransaction().getPluginByName("Dispatcher");
        if (yP_Object == null) {
            this.logger(2, "addTerminalRowForMerchant() No dispatcher");
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
        try {
            object = (String)yP_Object.dealRequest(yP_Transaction.getDataContainerTransaction(), "getMerchantIdentifier", string3);
            if (object != null) {
                this.logger(2, "addTerminalRowForMerchant(), terminal already declared");
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                return -1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "addTerminalRowForMerchant() ", exception);
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
        object = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Terminal");
        YP_Row yP_Row2 = ((YP_TCD_DesignAccesObject)object).getNewRow();
        Timestamp timestamp = new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_Row2.set("statusModificationGMTTime", timestamp);
        yP_Row2.set("idMerchant", yP_Row.getFieldStringValueByName("idMerchant"));
        yP_Row2.set("terminalSerialNumber", string2);
        yP_Row2.set("terminalManufacturerID", string);
        yP_Row2.set("idUser", yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
        yP_Row2.set("terminalStatus", TerminalStatusEnumeration.A_JOUR);
        yP_Row2.setModifierFlag(3);
        yP_Row2.setIsItAClonedRow(false);
        try {
            yP_Row2.persist();
        }
        catch (Exception exception) {
            this.logger(2, "addTerminalRowForMerchant() ", exception);
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
            return -1;
        }
        return 1;
    }

    @Override
    public int checkModification(YP_Transaction yP_Transaction, YP_Row yP_Row, String string, String string2) {
        yP_Row.set("lastModificationGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
        return 1;
    }

    /*
     * Exception decompiling
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, YP_View var3_3, List<DAO_ViewColumn> var4_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 52[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private int addContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business) {
        YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business2;
        block22: {
            block21: {
                block20: {
                    YP_Row yP_Row;
                    block19: {
                        block18: {
                            int n;
                            YP_Row yP_Row2;
                            block17: {
                                yP_Row = this.dataContainerTechnique.contract.getNewRow();
                                yP_Row2 = yP_TCD_DCC_EFT_Business.getApplicationPlugin().getApplicationRow();
                                long l = yP_Row2.getPrimaryKey();
                                if (l == 18L || l == 53L) {
                                    yP_Row.set("contractLabel", "CB55");
                                    yP_Row.set("idApplication", 33);
                                    break block17;
                                }
                                if (l == 58L) {
                                    yP_Row.set("contractLabel", "CB55 SC");
                                    yP_Row.set("idApplication", 36);
                                    break block17;
                                }
                                if (l == 67L) {
                                    yP_Row.set("contractLabel", "NxCB55");
                                    yP_Row.set("idApplication", 97);
                                    break block17;
                                }
                                this.logger(2, "addContract() unknown application");
                                YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                                return -1;
                            }
                            try {
                                n = (Integer)yP_Row2.getFieldValueByName("satisfactionIndex");
                                if (n <= 0) {
                                    n = 1;
                                }
                            }
                            catch (Exception exception) {
                                n = 1;
                            }
                            yP_Row.set("satisfactionIndex", n);
                            yP_Row.set("activationCode", "0");
                            yP_Row.set("initializationStatus", InitializationStatusEnumeration.EMPTY);
                            yP_Row.set("connectorType", (Integer)yP_TCD_DCC_Merchant.getDataContainerBrand().getBrandRow().getFieldValueByName("connectorType"));
                            yP_Row.set("idMerchant", yP_TCD_DCC_Merchant.getIDMerchant());
                            yP_Row.set("applicationIndex", 1);
                            if (this.dataContainerTechnique.contract.addRow(yP_Row, true) >= 0) break block18;
                            this.logger(2, "addContract() Not able to add row...");
                            YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                            return -1;
                        }
                        if (this.dataContainerTechnique.contract.persist() >= 0) break block19;
                        this.logger(2, "addContract() Not able to save changes...");
                        YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                        return -1;
                    }
                    try {
                        yP_TCD_DCC_EFT_Business2 = (YP_TCD_DCC_EFT_Business)this.dataContainerTechnique.loadContractByPrimaryKey(yP_Row.getPrimaryKey());
                        yP_TCD_DC_Transaction.contextHandler.businessContainers.add(yP_TCD_DCC_EFT_Business2);
                        this.getPluginByName("User").dealRequest(this, "updateUserAccesContext", yP_TCD_DC_Transaction.userHandler.getUserUID());
                        YP_Row yP_Row3 = yP_TCD_DCC_EFT_Business.getInitialisationRow();
                        yP_TCD_DCC_EFT_Business2.initialisationParameters.deleteRows(false);
                        YP_Row yP_Row4 = yP_TCD_DCC_EFT_Business2.initialisationParameters.getNewRow();
                        for (Object object : yP_Row3.getExtensionList()) {
                            Field[] fieldArray = object.getClass().getDeclaredFields();
                            int n = fieldArray.length;
                            int n2 = 0;
                            while (n2 < n) {
                                Field field = fieldArray[n2];
                                String string = field.getName();
                                yP_Row4.set(string, yP_Row3.getFieldValueByName(string));
                                ++n2;
                            }
                        }
                        if (yP_TCD_DCC_EFT_Business2.initialisationParameters.addRow(yP_Row4, true) >= 0) break block20;
                        this.logger(2, "addContract() Not able to add row...");
                        YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                        return -1;
                    }
                    catch (Exception exception) {
                        this.logger(2, "addContract() " + exception);
                        YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                        return -1;
                    }
                }
                if (yP_TCD_DCC_EFT_Business2.initialisationParameters.persist() >= 0) break block21;
                this.logger(2, "addContract() Not able to save changes...");
                YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
                return -1;
            }
            if (yP_TCD_DCC_EFT_Business2.executeRequest(yP_Transaction, YP_TCD_PosProtocol.REQUEST_TYPE.RemoteParameterization) == 1) break block22;
            this.logger(2, "addContract() Migration55 KO");
            YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
            return -1;
        }
        if (yP_TCD_DCC_EFT_Business2.getInitializationStatus() != InitializationStatusEnumeration.INITIALISED || yP_TCD_DCC_EFT_Business2.getActivationCode() != "1") {
            this.logger(2, "addContract() Migration55 KO");
            YP_TCD_DCC_Business.setExtendedResult(yP_TCD_DC_Transaction, new ExtendedResult(4));
            return -1;
        }
        return 1;
    }
}

