/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.authentifiers;

import org.yp.framework.YP_Object;
import org.yp.framework.globalcomponents.authentifiers.YP_TCG_External;

public class YP_TCG_BPCE
extends YP_TCG_External {
    public YP_TCG_BPCE(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String toString() {
        return "BPCE_Authentifier";
    }
}

