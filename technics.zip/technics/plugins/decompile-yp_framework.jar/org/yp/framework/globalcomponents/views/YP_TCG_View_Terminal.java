/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 */
package org.yp.framework.globalcomponents.views;

import com.google.gson.Gson;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.model.DTO_Terminal;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.globalcomponents.views.YP_TCG_View_User;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TCG_View_Terminal
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;
    private static final Gson GSON = new Gson();

    public YP_TCG_View_Terminal(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TCD_DataContainer) {
            this.initialize();
        }
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_Terminal";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.13";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
        if (yP_TCD_DesignAccesObject == null) {
            this.logger(2, "createEmptyView() error while retrieving Terminal DAO");
            return null;
        }
        List<YP_TCD_DCC_Brand> list3 = yP_Transaction.getBrandList();
        if (list3 == null) {
            this.logger(2, "createEmptyView() error while retrieving brandList");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(3, "createEmptyView() no brand");
            return yP_View;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = list3.get(0).getDesignAccesObject_ByName("Store");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject4 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject5 = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        yP_View.addCustomColumn("jsonTerminal", "jsonTerminal", "string", 8);
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject6;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject6 = yP_TCD_DesignAccesObject;
            } else {
                field = this.dataContainerTechnique.merchant.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject6 = this.dataContainerTechnique.merchant;
                } else {
                    field = this.dataContainerTechnique.brand.getFieldByName(string);
                    if (field != null) {
                        yP_TCD_DesignAccesObject6 = this.dataContainerTechnique.brand;
                    } else {
                        field = yP_TCD_DesignAccesObject3.getFieldByName(string);
                        if (field != null) {
                            yP_TCD_DesignAccesObject6 = yP_TCD_DesignAccesObject3;
                        } else {
                            field = yP_TCD_DesignAccesObject4.getFieldByName(string);
                            if (field != null) {
                                yP_TCD_DesignAccesObject6 = yP_TCD_DesignAccesObject4;
                            } else {
                                field = yP_TCD_DesignAccesObject2.getFieldByName(string);
                                if (field != null) {
                                    yP_TCD_DesignAccesObject6 = yP_TCD_DesignAccesObject2;
                                } else {
                                    field = yP_TCD_DesignAccesObject5.getFieldByName(string);
                                    if (field != null) {
                                        yP_TCD_DesignAccesObject6 = yP_TCD_DesignAccesObject5;
                                    } else {
                                        this.logger(2, "createEmptyView() unknown column:" + string);
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject6, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, long var3_3, List<DAO_ViewColumn> var5_4) {
        block83: {
            var6_5 = this.createEmptyView(var1_1, var2_2, var3_3, var5_4);
            if (var6_5 == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() ");
                }
                return null;
            }
            var7_6 = var2_2.getDataContainerTransaction().getProtocolEFT();
            if (var7_6 == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() No protocol...");
                }
                return null;
            }
            if (!(var7_6 instanceof YP_PROT_IHM)) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getView() bad interface");
                }
                return null;
            }
            var8_7 = (YP_PROT_IHM)var7_6;
            var9_8 = var8_7.getMaxRecords();
            if (var9_8 == 0) {
                return var6_5;
            }
            if (var9_8 < 0) {
                var9_8 = 1000;
            }
            ++var9_8;
            var10_9 = var8_7.getStartIndex();
            if (var10_9 < 0) {
                var10_9 = 0;
            } else {
                var9_8 += var10_9;
            }
            var11_10 = var8_7.getSearchGabarit();
            var12_11 = null;
            var13_12 = new YP_ComplexGabarit(this.getDAO(var1_1, var2_2, null));
            var14_13 = false;
            var15_14 = false;
            var16_15 = false;
            var17_16 = false;
            var18_17 = null;
            if (var11_10 == null || var11_10.isEmpty()) break block83;
            block12: for (YP_Gabarit var19_19 : var11_10) {
                try {
                    if (var19_19.fullTableName != null) {
                        var12_11 = this.getDAO(var1_1, var2_2, var19_19.fullTableName);
                    }
                    if (var19_19.fieldName != null && var19_19.fieldName.contentEquals("lastGMTTime") && var19_19.operator == YP_ComplexGabarit.OPERATOR.MAX) {
                        var13_12.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
                        continue;
                    }
                    if (var19_19.fieldName != null && var19_19.fieldName.contentEquals("terminalStatus")) {
                        var14_13 = true;
                        if (var19_19.operator == YP_ComplexGabarit.OPERATOR.IN) {
                            var19_19.operator = YP_ComplexGabarit.OPERATOR.IN_AFTER_GROUP;
                        }
                    }
                    if (var19_19.fieldName != null && var19_19.fieldName.contentEquals("terminalSerialNumber") && var19_19.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                        var15_14 = true;
                    }
                    if (var19_19.fieldName != null && var19_19.fieldName.contentEquals("terminalManufacturerID") && var19_19.operator == YP_ComplexGabarit.OPERATOR.EQUAL) {
                        var16_15 = true;
                    }
                    if (var19_19.objectTosearch == null) {
                        var13_12.set(var19_19.fieldName, var19_19.operator);
                        continue;
                    }
                    var6_5.dealEnumColumn(var19_19);
                    if (var19_19.objectTosearch == null || !(var19_19.objectTosearch instanceof String)) ** GOTO lbl-1000
                    var21_21 = var19_19.fieldName;
                    tmp = -1;
                    switch (var21_21.hashCode()) {
                        case -1193908346: {
                            if (var21_21.equals("idUser")) {
                                tmp = 1;
                            }
                            break;
                        }
                        case 1653644394: {
                            if (var21_21.equals("storeIdentifier")) {
                                tmp = 2;
                            }
                            break;
                        }
                    }
                    switch (tmp) {
                        case 1: {
                            var19_19.objectTosearch = this.getIdUser((String)var19_19.objectTosearch);
                            ** GOTO lbl83
                        }
                        case 2: {
                            var18_17 = var19_19;
                            break;
                        }
lbl83:
                        // 2 sources

                        default: lbl-1000:
                        // 2 sources

                        {
                            if (var19_19.objectTosearch == null) continue block12;
                            var13_12.set(var19_19.fieldName, var19_19.operator, var19_19.objectTosearch);
                            break;
                        }
                    }
                }
                catch (Exception var21_22) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + var21_22);
                }
            }
        }
        if (var13_12.maxFieldName == null && !var15_14 && !var16_15) {
            var13_12.set("terminalManufacturerID", YP_ComplexGabarit.OPERATOR.GROUP);
            var13_12.set("terminalSerialNumber", YP_ComplexGabarit.OPERATOR.GROUP);
            var13_12.set("statusModificationGMTTime", YP_ComplexGabarit.OPERATOR.MAX);
        } else if (var15_14 && var16_15) {
            var17_16 = true;
        }
        var19_20 = var2_2.getDataContainerTransaction().userHandler.getUserAccessLevel();
        var20_18 = var2_2.getMerchantList();
        if (var20_18 == null) {
            this.logger(2, "getView() error while retrieving merchantList");
            return null;
        }
        if (var20_18.isEmpty()) {
            this.logger(3, "getView() no merchant List");
            return var6_5;
        }
        if (var20_18.size() <= 500) {
            var21_21 = new ArrayList<Long>();
            var23_23 = var20_18.iterator();
            while (var23_23.hasNext()) {
                var22_24 = (YP_TCD_DCC_Merchant)var23_23.next();
                var21_21.add((YP_Row)Long.valueOf((Long)var22_24.getMerchantRow().getFieldValueByName("idMerchant")));
            }
            if ((var19_20 == 1 || var19_20 == 2) && var2_2.getContractIdentifier().indexOf(95) == -1) {
                var21_21.add((YP_Row)Long.valueOf(0L));
            }
            var13_12.set("idMerchant", YP_ComplexGabarit.OPERATOR.IN, (Object)var21_21);
        }
        var21_21 = new ArrayList<E>();
        var22_24 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalReference");
        var23_23 = this.dataContainerTechnique.getDesignAccesObject_ByName("TerminalConfig");
        if (var12_11 != null) {
            var21_21 = var12_11.getRowListSuchAs(new YP_ComplexGabarit[]{var13_12});
        } else {
            var21_21 = new ArrayList<E>();
            if (!var17_16) {
                for (YP_TCD_DCC_Brand var24_26 : var2_2.getBrandList()) {
                    if (var18_17 != null) {
                        var13_12.reset("idStore", YP_ComplexGabarit.OPERATOR.IN, this.getIdStoreList(var24_26, var18_17));
                    }
                    if ((var26_29 /* !! */  = var24_26.getTerminalRowList(var13_12)) == null || var26_29 /* !! */ .isEmpty()) continue;
                    var21_21.addAll(var26_29 /* !! */ );
                }
            } else {
                for (YP_TCD_DCC_Brand var24_26 : var2_2.getBrandList()) {
                    if (var18_17 != null) {
                        var13_12.reset("idStore", YP_ComplexGabarit.OPERATOR.IN, this.getIdStoreList(var24_26, var18_17));
                    }
                    if ((var26_29 /* !! */  = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction((YP_TCD_DAO_SQL_Transaction)var24_26.getDesignAccesObject_ByName("Terminal"), var24_26.getDesignAccesObject_ByName("Terminal_archive"), 0, var9_8, new YP_ComplexGabarit[]{var13_12})) == null) {
                        this.logger(2, "getView() unable to retrieve list !!!");
                        return null;
                    }
                    if (var26_29 /* !! */ .isEmpty()) {
                        this.logger(4, "getView() nothing found");
                        continue;
                    }
                    var21_21.addAll((Collection<YP_Row>)var26_29 /* !! */ );
                }
            }
        }
        if (var21_21.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return var6_5;
        }
        if (var13_12.gabaritHasOneMinOrMax && (!var14_13 || var19_20 == 3 || var19_20 == 4)) {
            var24_27 = var21_21.size() - 1;
            while (var24_27 >= 0) {
                var25_25 = var21_21.get(var24_27);
                var26_29 /* !! */  = (TerminalStatusEnumeration)var25_25.getFieldValueByName("terminalStatus");
                if (var26_29 /* !! */  == TerminalStatusEnumeration.DELETED) {
                    var21_21.remove(var24_27);
                }
                --var24_27;
            }
        }
        var21_21 = var13_12.order(var21_21);
        var24_28 = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        var25_25 = this.getPluginByName("User");
        var26_30 = 0;
        while (var26_30 < var21_21.size()) {
            if (var10_9 == 0 && var26_30 > var9_8) break;
            var27_31 = var21_21.get(var26_30);
            var28_32 = null;
            var29_33 = null;
            var30_34 = null;
            var31_35 = null;
            var32_36 = null;
            var33_37 = null;
            var34_38 = (Long)var27_31.getFieldValueByName("idMerchant");
            if (var34_38 > 0L) {
                var36_39 = (YP_TCD_DCC_Merchant)this.dataContainerManager.dealRequest(this, "getDataContainerMerchant", new Object[]{var34_38});
                if (var36_39 != null) {
                    var28_32 = var36_39.getMerchantRow();
                    var37_41 = var36_39.getDataContainerBrand();
                    var29_33 = var37_41.getBrandRow();
                    var30_34 = var37_41.getDesignAccesObject_ByName("Store");
                    var38_42 = (Long)var27_31.getFieldValueByName("idStore");
                    if (var38_42 > 0L) {
                        var31_35 = var37_41.getStore(var38_42);
                    }
                    if ((var40_45 = ((Long)var27_31.getFieldValueByName("idTerminalReference")).longValue()) > 0L) {
                        var32_36 = this.dataContainerTechnique.getTerminalReferenceRow(var40_45);
                    }
                    if ((var42_47 = ((Long)var27_31.getFieldValueByName("idTerminalConfig")).longValue()) > 0L) {
                        var33_37 = this.dataContainerTechnique.getTerminalConfigRow(var42_47);
                    }
                }
            } else if (this.getLogLevel() >= 5) {
                this.logger(5, "getView() idMerchant is not set");
            }
            var36_39 = null;
            var37_40 = (Long)var27_31.getFieldValueByName("idUser");
            if (var37_40 > 0L && (var36_39 = YP_TCG_View_User.userFinder.get(var37_40)) == null && var25_25 != null) {
                try {
                    var36_39 = (YP_Row)var25_25.dealRequest(this, "getUserRowByID", new Object[]{var37_40});
                    YP_TCG_View_User.userFinder.put(var37_40, (YP_Row)var36_39);
                }
                catch (Exception v0) {}
            }
            var6_5.setRowID(var26_30, String.valueOf(var27_31.getFather().getFullTableName()) + "#" + var27_31.getPrimaryKeyName() + "#" + var27_31.getPrimaryKey());
            if (!var17_16 && this.isActionable(var1_1, var2_2, var27_31, var6_5, var3_3)) {
                var6_5.setRowActionable(var26_30, true);
                if (var21_21.size() == 1) {
                    this.addActionList(var2_2, var27_31, var6_5, var26_30);
                }
            } else {
                var6_5.setRowActionable(var26_30, false);
            }
            for (DAO_ViewColumn var39_43 : var5_4) {
                var41_46 = YP_Row.getStringValue(var39_43.columnName);
                var42_48 = var27_31.getFieldByName(var41_46);
                var43_49 = null;
                if (var42_48 != null) {
                    var43_49 = var27_31;
                } else {
                    var42_48 = this.dataContainerTechnique.merchant.getFieldByName(var41_46);
                    if (var42_48 != null) {
                        var43_49 = var28_32;
                    } else {
                        var42_48 = this.dataContainerTechnique.brand.getFieldByName(var41_46);
                        if (var42_48 != null) {
                            var43_49 = var29_33;
                        } else {
                            var42_48 = var22_24.getFieldByName(var41_46);
                            if (var42_48 != null) {
                                if (var32_36 == null) continue;
                                var43_49 = var32_36;
                            } else {
                                var42_48 = var23_23.getFieldByName(var41_46);
                                if (var42_48 != null) {
                                    if (var33_37 == null) continue;
                                    var43_49 = var33_37;
                                } else {
                                    var42_48 = var24_28.getFieldByName(var41_46);
                                    if (var42_48 != null) {
                                        if (var36_39 == null) continue;
                                        var43_49 = var36_39;
                                    } else if (var30_34 != null && (var42_48 = var30_34.getFieldByName(var41_46)) != null) {
                                        if (var31_35 == null) continue;
                                        var43_49 = var31_35;
                                    }
                                }
                            }
                        }
                    }
                }
                if (var42_48 != null && var43_49 != null) {
                    if (("IDSIM".contentEquals(var41_46) || "IMSI".contentEquals(var41_46)) && !(var44_50 = var43_49.getFieldStringValue(var42_48)).isEmpty() && !UtilsYP.isNumeric(var44_50)) {
                        this.logger(3, "getView() bad format found");
                        continue;
                    }
                    if (("biosVersion".contentEquals(var41_46) || "kernelVersion".contentEquals(var41_46) || "level2ICCVersion".contentEquals(var41_46)) && !(var44_50 = var43_49.getFieldStringValue(var42_48)).isEmpty() && var44_50.indexOf(28) >= 0) {
                        var43_49.set(var41_46, "trash");
                    }
                    this.addFieldValue(var6_5, var42_48, (YP_Row)var43_49, var41_46, var26_30);
                    continue;
                }
                if (var42_48 != null || var41_46.contentEquals("storeLabel") || var41_46.contentEquals("storeIdentifier")) continue;
                this.logger(2, "getView() unknown column:" + var41_46);
            }
            ++var26_30;
        }
        return var6_5;
    }

    private List<String> getIdStoreList(YP_TCD_DCC_Brand yP_TCD_DCC_Brand, YP_Gabarit yP_Gabarit) {
        ArrayList<String> arrayList = new ArrayList<String>();
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Store");
        if (yP_TCD_DesignAccesObject != null) {
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set(yP_Gabarit.fieldName, yP_Gabarit.operator, yP_Gabarit.objectTosearch);
            List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list != null) {
                for (YP_Row yP_Row : list) {
                    arrayList.add(yP_Row.getFieldStringValueByName("idStore"));
                }
            }
        }
        return arrayList;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = null;
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Terminal");
            if (yP_TCD_DesignAccesObject2 == null || string != null && !yP_TCD_DesignAccesObject2.getFullTableName().startsWith(string)) continue;
            if (yP_TCD_DesignAccesObject == null) {
                yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
                continue;
            }
            if (yP_TCD_DesignAccesObject2.getExtensionList() == null || yP_TCD_DesignAccesObject2.getExtensionList().isEmpty() || yP_TCD_DesignAccesObject.getExtensionList() != null && yP_TCD_DesignAccesObject.getExtensionList().size() >= yP_TCD_DesignAccesObject2.getExtensionList().size()) continue;
            yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
        }
        if (yP_TCD_DesignAccesObject != null) {
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving Terminal DAO");
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDAOPdv(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = null;
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("PDV");
            if (yP_TCD_DesignAccesObject2 == null || string != null && !yP_TCD_DesignAccesObject2.getFullTableName().startsWith(string)) continue;
            if (yP_TCD_DesignAccesObject == null) {
                yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
                continue;
            }
            if (yP_TCD_DesignAccesObject2.getExtensionList() == null || yP_TCD_DesignAccesObject2.getExtensionList().isEmpty() || yP_TCD_DesignAccesObject.getExtensionList() != null && yP_TCD_DesignAccesObject.getExtensionList().size() >= yP_TCD_DesignAccesObject2.getExtensionList().size()) continue;
            yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
        }
        if (yP_TCD_DesignAccesObject != null) {
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving PDV DAO");
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDAOVille(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = null;
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Ville");
            if (yP_TCD_DesignAccesObject2 == null || string != null && !yP_TCD_DesignAccesObject2.getFullTableName().startsWith(string)) continue;
            if (yP_TCD_DesignAccesObject == null) {
                yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
                continue;
            }
            if (yP_TCD_DesignAccesObject2.getExtensionList() == null || yP_TCD_DesignAccesObject2.getExtensionList().isEmpty() || yP_TCD_DesignAccesObject.getExtensionList() != null && yP_TCD_DesignAccesObject.getExtensionList().size() >= yP_TCD_DesignAccesObject2.getExtensionList().size()) continue;
            yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
        }
        if (yP_TCD_DesignAccesObject != null) {
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving Ville DAO");
        }
        return null;
    }

    public YP_TCD_DesignAccesObject getDAOAgence(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        List<YP_TCD_DCC_Brand> list = yP_Transaction.getBrandList();
        if (list == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() error while retrieving brandList");
            }
            return null;
        }
        if (list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDAO() no brand");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = null;
        for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DCC_Brand.getDesignAccesObject_ByName("Agence");
            if (yP_TCD_DesignAccesObject2 == null || string != null && !yP_TCD_DesignAccesObject2.getFullTableName().startsWith(string)) continue;
            if (yP_TCD_DesignAccesObject == null) {
                yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
                continue;
            }
            if (yP_TCD_DesignAccesObject2.getExtensionList() == null || yP_TCD_DesignAccesObject2.getExtensionList().isEmpty() || yP_TCD_DesignAccesObject.getExtensionList() != null && yP_TCD_DesignAccesObject.getExtensionList().size() >= yP_TCD_DesignAccesObject2.getExtensionList().size()) continue;
            yP_TCD_DesignAccesObject = yP_TCD_DesignAccesObject2;
        }
        if (yP_TCD_DesignAccesObject != null) {
            return yP_TCD_DesignAccesObject;
        }
        if (string != null && !string.isEmpty()) {
            return super.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDAO() error while retrieving Agence DAO");
        }
        return null;
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        switch (action.id) {
            case "ACTIVATE_TERMINAL": {
                return this.activateTerminal(yP_Transaction, yP_Row);
            }
            case "DEACTIVATE_TERMINAL": {
                return this.deactivateTerminal(yP_Transaction, yP_Row);
            }
            case "ACTIVATE_LOG_INFO": {
                return this.activateDebugTerminal(yP_Transaction, yP_Row, 4);
            }
            case "ACTIVATE_DEBUG_TERMINAL": {
                return this.activateDebugTerminal(yP_Transaction, yP_Row, 5);
            }
            case "ACTIVATE_LOG_FILE": {
                return this.activateDebugTerminal(yP_Transaction, yP_Row, 7);
            }
            case "DEACTIVATE_DEBUG_TERMINAL": {
                return this.deactivateDebugTerminal(yP_Transaction, yP_Row);
            }
            case "MAINTENANCE_TERMINAL": {
                return this.maintenanceTerminal(yP_Transaction, yP_Row);
            }
            case "DELETE_TERMINAL": {
                return this.deleteTerminal(yP_Transaction, yP_Row);
            }
        }
        this.logger(2, "executeAction() unknown action" + action.id);
        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
        return -1;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            List<YP_TCD_DCC_Brand> list2 = yP_Transaction.getBrandList();
            if (list2 == null) {
                this.logger(2, "createInView() error while retrieving brandList");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (list2.isEmpty()) {
                this.logger(2, "createInView() no brand");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            if (list2.size() > 1) {
                this.logger(2, "createInView() too many brands");
            }
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = list2.get(0);
            int n = 0;
            while (n < yP_View.size()) {
                void var17_18;
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    this.logger(2, "createInView() Key must not be set !");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    this.logger(2, "createInView() not really possible !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.getDAOPdv(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject2 == null) {
                    this.logger(2, "createInView() not really possible (DAO PDV is null) !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3 = this.getDAOVille(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject3 == null) {
                    this.logger(2, "createInView() not really possible (DAO Ville is null) !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject4 = this.getDAOAgence(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject4 == null) {
                    this.logger(2, "createInView() not really possible (DAO Agence is null) !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                String string2 = null;
                TerminalStatusEnumeration terminalStatusEnumeration = null;
                String string3 = null;
                DTO_Terminal dTO_Terminal = null;
                for (String string4 : yP_View.getColumnSet()) {
                    String string5 = yP_View.getFieldValueAt(n, string4);
                    if (string5 == null) continue;
                    switch (string4) {
                        case "idTerminalCan": {
                            string2 = string5;
                            break;
                        }
                        case "terminalStatus": {
                            terminalStatusEnumeration = TerminalStatusEnumeration.valueOf(string5);
                            break;
                        }
                        case "detailedStatus": {
                            string3 = string5;
                            break;
                        }
                        case "model": {
                            this.logger(2, "createInView() model not handled");
                            break;
                        }
                        case "jsonTerminal": {
                            dTO_Terminal = (DTO_Terminal)GSON.fromJson(string5, DTO_Terminal.class);
                            string2 = String.valueOf(dTO_Terminal.getIdTerminal());
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string4);
                        }
                    }
                }
                YP_Row yP_Row = yP_TCD_DCC_Brand.getTerminalRow(string2, false);
                if (yP_Row == null) {
                    YP_Row yP_Row2 = yP_TCD_DesignAccesObject.getNewRow();
                } else {
                    YP_Row yP_Row3 = yP_Row;
                    yP_Row3.setPrimaryKey(0L);
                    yP_Row3.setModifierFlag(3);
                }
                var17_18.set("idTerminalCan", string2);
                var17_18.set("terminalStatus", terminalStatusEnumeration);
                var17_18.set("idUser", yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
                if (string3 != null) {
                    var17_18.set("detailedStatus", string3);
                }
                var17_18.set("statusModificationGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                var17_18.setIsItAClonedRow(false);
                var17_18.persist();
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.logger(2, "createInView() " + exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    private void addActionList(YP_Transaction yP_Transaction, YP_Row yP_Row, YP_View yP_View, int n) {
        int n2;
        String string;
        ArrayList<YP_TCD_DC_Context.Action> arrayList = new ArrayList<YP_TCD_DC_Context.Action>();
        TerminalStatusEnumeration terminalStatusEnumeration = (TerminalStatusEnumeration)((Object)yP_Row.getFieldValueByName("terminalStatus"));
        Map<String, String> map = yP_View.getColumnProperties("terminalStatus");
        if (map != null && (string = map.get("writeAllowed")) != null && string.contentEquals("1")) {
            switch (terminalStatusEnumeration) {
                case A_JOUR: {
                    arrayList.add(this.getAction(yP_Transaction, "DEACTIVATE_TERMINAL"));
                    if (UtilsYP.isSATIMServer()) break;
                    arrayList.add(this.getAction(yP_Transaction, "MAINTENANCE_TERMINAL"));
                }
            }
            int n3 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
            if ((n3 == 1 || n3 == 2) && terminalStatusEnumeration != TerminalStatusEnumeration.DELETED) {
                arrayList.add(this.getConfirmAction(yP_Transaction, "DELETE_TERMINAL"));
            }
        }
        if ((n2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel()) == 1 || n2 == 2 || n2 == 3) {
            YP_TCD_DC_Context.Action action = new YP_TCD_DC_Context.Action();
            action.id = "TERMINAL_ARCHIVES";
            action.label = this.getLabel("TERMINAL_ARCHIVES");
            action.applicationIdentifier = yP_Transaction.getDataContainerTransaction().getContractIdentifier();
            action.formName = "TERMINAL_ARCHIVES";
            if (arrayList.isEmpty()) {
                ArrayList<Property> arrayList2 = new ArrayList<Property>();
                Property property = new Property();
                property.setName("DefaultAction");
                property.setValue("1");
                arrayList2.add(property);
                action.propertiesList = arrayList2;
            }
            arrayList.add(action);
        }
        if (!arrayList.isEmpty()) {
            yP_View.setRowActionList(n, arrayList);
        }
    }

    private boolean isActionable(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_Row yP_Row, YP_View yP_View, long l) {
        String string;
        int n = yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel();
        if (n == 1 || n == 2 || n == 3) {
            return true;
        }
        if (!yP_TCD_DCC_Interface_View.isWriteAllowed(l, yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
            return false;
        }
        TerminalStatusEnumeration terminalStatusEnumeration = (TerminalStatusEnumeration)((Object)yP_Row.getFieldValueByName("terminalStatus"));
        Map<String, String> map = yP_View.getColumnProperties("terminalStatus");
        if (map != null && (string = map.get("writeAllowed")) != null && string.contentEquals("1")) {
            switch (terminalStatusEnumeration) {
                default: 
            }
        }
        return false;
    }

    private YP_Row findModifiedTerminalMeanwhile(YP_Row yP_Row) {
        try {
            String string = yP_Row.getFieldStringValueByName("terminalManufacturerID");
            String string2 = yP_Row.getFieldStringValueByName("terminalSerialNumber");
            String string3 = String.valueOf(string) + '_' + string2;
            YP_Row yP_Row2 = ((YP_TCD_DCC_Brand)yP_Row.getFather().getDataContainerContext()).getTerminalRow(string3, false);
            if (yP_Row2 != null) {
                return yP_Row2;
            }
        }
        catch (Exception exception) {
            this.logger(2, "findModifiedTerminalMeanwhile() " + exception);
        }
        return yP_Row;
    }

    private int activateTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("terminalStatus", TerminalStatusEnumeration.A_JOUR);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "activateTerminal() " + exception);
            return -1;
        }
    }

    private int deactivateTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("terminalStatus", TerminalStatusEnumeration.NON_MAJ);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deactivateTerminal() " + exception);
            return -1;
        }
    }

    private int maintenanceTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("terminalStatus", TerminalStatusEnumeration.EN_COURS_MAJ);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "maintenanceTerminal() " + exception);
            return -1;
        }
    }

    private int deleteTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("terminalStatus", TerminalStatusEnumeration.DELETED);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deleteTerminal() " + exception);
            return -1;
        }
    }

    private int activateDebugTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row, int n) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("debugLevel", n);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "activateDebugTerminal() " + exception);
            return -1;
        }
    }

    private int deactivateDebugTerminal(YP_Transaction yP_Transaction, YP_Row yP_Row) {
        try {
            yP_Row = (YP_Row)this.findModifiedTerminalMeanwhile(yP_Row).clone();
            yP_Row.set("debugLevel", 0);
            this.dealRowModificationsBeforePersist(yP_Row);
            yP_Row.persist();
            YP_TCD_DCC_Business.getExtendedResult(yP_Transaction.getDataContainerTransaction()).add(8);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "deactivateDebugTerminal() " + exception);
            return -1;
        }
    }

    @Override
    protected void dealRowModificationsBeforePersist(YP_Row yP_Row) {
        if (yP_Row.getModifierFlag() != 0) {
            Object object;
            yP_Row.setIsItAClonedRow(false);
            yP_Row.setPrimaryKey(0L);
            yP_Row.setModifierFlag(3);
            yP_Row.set("statusModificationGMTTime", new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
            YP_Row yP_Row2 = this.findModifiedTerminalMeanwhile(yP_Row);
            if (yP_Row2.getPrimaryKey() != yP_Row.getPrimaryKey()) {
                object = (Timestamp)yP_Row2.getFieldValueByName("lastGMTTime");
                Timestamp timestamp = (Timestamp)yP_Row.getFieldValueByName("lastGMTTime");
                if (((Timestamp)object).getTime() > timestamp.getTime()) {
                    yP_Row.set("lastGMTTime", (Timestamp)object);
                }
                boolean bl = false;
                String string = yP_Row.getFieldStringValueByName("alias");
                String string2 = yP_Row2.getFieldStringValueByName("alias");
                if (string != null && string2 != null && !string.contentEquals(string2)) {
                    bl = true;
                }
                String string3 = yP_Row.getFieldStringValueByName("terminalLanguage");
                String string4 = yP_Row2.getFieldStringValueByName("terminalLanguage");
                if (string3 != null && string4 != null && !string3.contentEquals(string4)) {
                    bl = true;
                }
                String string5 = yP_Row.getFieldStringValueByName("terminalType");
                String string6 = yP_Row2.getFieldStringValueByName("terminalType");
                if (string5 != null && string6 != null && !string5.contentEquals(string6)) {
                    bl = true;
                }
                String string7 = yP_Row.getFieldStringValueByName("nlpa");
                String string8 = yP_Row2.getFieldStringValueByName("nlpa");
                if (string7 != null && string8 != null && !string7.contentEquals(string8)) {
                    bl = true;
                }
                if (bl) {
                    yP_Row.set("updateMode", 1);
                }
            }
            if ((object = this.getProcessPluginByThreadID(Thread.currentThread().getId())) instanceof YP_Transaction) {
                yP_Row.set("idUser", ((YP_Transaction)object).getDataContainerTransaction().userHandler.getUserIdentifier());
            }
        }
    }

    @Override
    protected void dealDAOModificationsAfterPersist(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
    }
}

