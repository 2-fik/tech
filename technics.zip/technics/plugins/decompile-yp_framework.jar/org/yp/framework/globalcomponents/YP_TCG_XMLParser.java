/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.rits.cloning.Cloner
 *  javax.xml.bind.UnmarshalException
 */
package org.yp.framework.globalcomponents;

import com.rits.cloning.Cloner;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.UnmarshalException;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.parsers.YP_TCD_XMLParser_Interface;
import org.yp.utils.PluginList;

public class YP_TCG_XMLParser
extends YP_GlobalComponent {
    private String parserPluginName;
    private boolean replace0xa0 = false;
    private boolean checkIfGet = false;
    private PluginList parserList = null;
    private final Map<String, Object> masterObjectMap = new HashMap<String, Object>();
    private final Cloner cloner = new Cloner();

    public YP_TCG_XMLParser(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "parserPluginName");
        if (string == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() mandatory property parserPluginName missing in :" + this.getPropertyFileName());
            }
            return -1;
        }
        this.parserPluginName = string;
        this.parserList = new PluginList(this, this.parserPluginName);
        string = this.getProperty(this.getPropertyFileName(), "replace0xa0");
        if (string != null) {
            if (string.contentEquals("1") || string.toLowerCase().contentEquals("true")) {
                this.replace0xa0 = true;
            } else if (string.contentEquals("0") || string.toLowerCase().contentEquals("false")) {
                this.replace0xa0 = false;
            } else if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() bad value for replace0xa0:" + string);
            }
        } else {
            this.replace0xa0 = false;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "initialize() no value for replace0xa0 default false");
            }
        }
        string = this.getProperty(this.getPropertyFileName(), "checkIfGet");
        if (string != null) {
            if (string.contentEquals("1") || string.toLowerCase().contentEquals("true")) {
                this.checkIfGet = true;
            } else if (string.contentEquals("0") || string.toLowerCase().contentEquals("false")) {
                this.checkIfGet = true;
            } else if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() bad value for checkIfGet:" + string);
            }
        } else {
            this.checkIfGet = false;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "initialize() no value for checkIfGet default false");
            }
        }
        return 1;
    }

    @Override
    public String toString() {
        return "XMLParser";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public String objectToXML(Object object) {
        try {
            YP_TCD_XMLParser_Interface yP_TCD_XMLParser_Interface = (YP_TCD_XMLParser_Interface)((Object)this.parserList.getPlugin());
            String string = yP_TCD_XMLParser_Interface.objectToXML(object);
            this.parserList.releasePlugin((YP_OnDemandComponent)((Object)yP_TCD_XMLParser_Interface));
            if (this.replace0xa0 && string.indexOf(160) != -1) {
                string = string.replace('\u00a0', ' ');
            }
            return string;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "objectToXML() " + exception);
            }
            return null;
        }
    }

    public Object xmlFileToObject(String string) {
        String string2;
        block5: {
            try {
                string2 = this.getFileContent(string);
                if (string2 != null) break block5;
                this.logger(2, "xmlFileToObject() " + string + " not found");
                return null;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "xmlFileToObject()  " + exception);
                }
                return null;
            }
        }
        Object object = this.masterObjectMap.get(string2);
        if (object == null) {
            YP_TCD_XMLParser_Interface yP_TCD_XMLParser_Interface = (YP_TCD_XMLParser_Interface)((Object)this.parserList.getPlugin());
            object = yP_TCD_XMLParser_Interface.xmlToObject(string2);
            this.parserList.releasePlugin((YP_OnDemandComponent)((Object)yP_TCD_XMLParser_Interface));
            this.masterObjectMap.put(string2, object);
        }
        return this.cloner.deepClone(object);
    }

    public Object xmlToObject(String string) throws UnmarshalException {
        try {
            if (this.checkIfGet && string.startsWith("GET /")) {
                string = string.replace("%3C", "<");
                string = string.replace("%3E", ">");
                string = string.replace("%20", " ");
                string = string.replace("%22", "\"");
                string = string.substring(5);
                string = string.substring(0, string.indexOf("HTTP"));
            }
            YP_TCD_XMLParser_Interface yP_TCD_XMLParser_Interface = (YP_TCD_XMLParser_Interface)((Object)this.parserList.getPlugin());
            Object object = yP_TCD_XMLParser_Interface.xmlToObject(string);
            this.parserList.releasePlugin((YP_OnDemandComponent)((Object)yP_TCD_XMLParser_Interface));
            return object;
        }
        catch (UnmarshalException unmarshalException) {
            this.logger(2, "xmlToObject()  ", (Exception)((Object)unmarshalException));
            throw unmarshalException;
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() ", exception);
            return null;
        }
    }

    public Object xmlToObject(byte[] byArray) {
        try {
            if (this.checkIfGet && byArray != null && byArray.length > 3 && byArray[0] == 71 && byArray[1] == 69 && byArray[2] == 84) {
                return this.xmlToObject(new String(byArray));
            }
            YP_TCD_XMLParser_Interface yP_TCD_XMLParser_Interface = (YP_TCD_XMLParser_Interface)((Object)this.parserList.getPlugin());
            Object object = yP_TCD_XMLParser_Interface.xmlToObject(byArray);
            this.parserList.releasePlugin((YP_OnDemandComponent)((Object)yP_TCD_XMLParser_Interface));
            return object;
        }
        catch (Exception exception) {
            this.logger(2, "xmlToObject() ", exception);
            return null;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        block17: {
            block16: {
                block15: {
                    try {
                        if (!string.contentEquals("xmlFileToObject")) break block15;
                        if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                            return this.xmlFileToObject((String)objectArray[0]);
                        }
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameter for xmlFileToObject ");
                        }
                        return null;
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad request ??? :" + exception);
                        }
                        return null;
                    }
                }
                if (!string.contentEquals("xmlToObject")) break block16;
                if (objectArray != null && objectArray.length == 1) {
                    if (objectArray[0] instanceof String) {
                        return this.xmlToObject((String)objectArray[0]);
                    }
                    if (objectArray[0] instanceof byte[]) {
                        return this.xmlToObject((byte[])objectArray[0]);
                    }
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for xmlToObject ");
                }
                return null;
            }
            if (!string.contentEquals("objectToXML")) break block17;
            if (objectArray != null && objectArray.length == 1) {
                return this.objectToXML(objectArray[0]);
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest() bad parameter ");
            }
            return null;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "dealRequest() request unknown " + string);
        }
        return null;
    }
}

