/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

public class DTO_Autorisations {
    @SerializedName(value="autorisationAlloJeu")
    private Boolean autorisationAlloJeu = null;
    @SerializedName(value="autorisationPayementGrosGain")
    private Boolean autorisationPayementGrosGain = null;
    @SerializedName(value="testproduction")
    private Boolean testproduction = null;

    public DTO_Autorisations autorisationAlloJeu(Boolean bl) {
        this.autorisationAlloJeu = bl;
        return this;
    }

    public Boolean isAutorisationAlloJeu() {
        return this.autorisationAlloJeu;
    }

    public void setAutorisationAlloJeu(Boolean bl) {
        this.autorisationAlloJeu = bl;
    }

    public DTO_Autorisations autorisationPayementGrosGain(Boolean bl) {
        this.autorisationPayementGrosGain = bl;
        return this;
    }

    public Boolean isAutorisationPayementGrosGain() {
        return this.autorisationPayementGrosGain;
    }

    public void setAutorisationPayementGrosGain(Boolean bl) {
        this.autorisationPayementGrosGain = bl;
    }

    public DTO_Autorisations testproduction(Boolean bl) {
        this.testproduction = bl;
        return this;
    }

    public Boolean isTestproduction() {
        return this.testproduction;
    }

    public void setTestproduction(Boolean bl) {
        this.testproduction = bl;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Autorisations dTO_Autorisations = (DTO_Autorisations)object;
        return Objects.equals(this.autorisationAlloJeu, dTO_Autorisations.autorisationAlloJeu) && Objects.equals(this.autorisationPayementGrosGain, dTO_Autorisations.autorisationPayementGrosGain) && Objects.equals(this.testproduction, dTO_Autorisations.testproduction);
    }

    public int hashCode() {
        return Objects.hash(this.autorisationAlloJeu, this.autorisationPayementGrosGain, this.testproduction);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class AutorisationsDto {\n");
        stringBuilder.append("    autorisationAlloJeu: ").append(this.toIndentedString(this.autorisationAlloJeu)).append("\n");
        stringBuilder.append("    autorisationPayementGrosGain: ").append(this.toIndentedString(this.autorisationPayementGrosGain)).append("\n");
        stringBuilder.append("    testproduction: ").append(this.toIndentedString(this.testproduction)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

