/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

public class DTO_Attributaire {
    @SerializedName(value="code")
    private String code = null;
    @SerializedName(value="id")
    private Integer id = null;
    @SerializedName(value="libelle")
    private String libelle = null;
    @SerializedName(value="version")
    private String version = null;

    public DTO_Attributaire code(String string) {
        this.code = string;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String string) {
        this.code = string;
    }

    public DTO_Attributaire id(Integer n) {
        this.id = n;
        return this;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer n) {
        this.id = n;
    }

    public DTO_Attributaire libelle(String string) {
        this.libelle = string;
        return this;
    }

    public String getLibelle() {
        return this.libelle;
    }

    public void setLibelle(String string) {
        this.libelle = string;
    }

    public DTO_Attributaire version(String string) {
        this.version = string;
        return this;
    }

    public String getVersion() {
        return this.version;
    }

    public void setVersion(String string) {
        this.version = string;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        DTO_Attributaire dTO_Attributaire = (DTO_Attributaire)object;
        return Objects.equals(this.code, dTO_Attributaire.code) && Objects.equals(this.id, dTO_Attributaire.id) && Objects.equals(this.libelle, dTO_Attributaire.libelle) && Objects.equals(this.version, dTO_Attributaire.version);
    }

    public int hashCode() {
        return Objects.hash(this.code, this.id, this.libelle, this.version);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("class AttributaireDto {\n");
        stringBuilder.append("    code: ").append(this.toIndentedString(this.code)).append("\n");
        stringBuilder.append("    id: ").append(this.toIndentedString(this.id)).append("\n");
        stringBuilder.append("    libelle: ").append(this.toIndentedString(this.libelle)).append("\n");
        stringBuilder.append("    version: ").append(this.toIndentedString(this.version)).append("\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private String toIndentedString(Object object) {
        if (object == null) {
            return "null";
        }
        return object.toString().replace("\n", "\n    ");
    }
}

