/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.authentifiers;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.globalcomponents.authentifiers.YP_Authentifiers;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.enums.UserStatusEnumeration;

public class YP_TCG_SharedAuthentifier
extends YP_GlobalComponent
implements YP_Authentifiers {
    public YP_TCG_SharedAuthentifier(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "Shared_Authentifier";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public YP_Authentifiers.AuthenticationResultEnumeration authenticate(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        YP_Authentifiers.AuthenticationResultEnumeration authenticationResultEnumeration = null;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_TCD_DC_Transaction.getTransactionProcessFather(), yP_Row);
        if (yP_TCD_DCC_Brand != null) {
            authenticationResultEnumeration = yP_TCD_DCC_Brand.authenticate(yP_TCD_DC_Transaction, yP_Row, string, string2, stringBuilder);
        }
        return authenticationResultEnumeration;
    }

    @Override
    public Boolean changePassword(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2, StringBuilder stringBuilder) {
        Boolean bl = null;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_TCD_DC_Transaction.getTransactionProcessFather(), yP_Row);
        if (yP_TCD_DCC_Brand != null) {
            String string3 = yP_TCD_DCC_Brand.getHashedPassword(string, string2);
            bl = yP_TCD_DCC_Brand.setHashedPassword(string, string3);
        }
        return bl;
    }

    @Override
    public Boolean setPassword(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2) {
        String string3 = string2;
        Boolean bl = null;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_TCD_DC_Transaction.getTransactionProcessFather(), yP_Row);
        if (yP_TCD_DCC_Brand != null) {
            bl = yP_TCD_DCC_Brand.setHashedPassword(string, string3);
        }
        return bl;
    }

    @Override
    public String createUser(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string, String string2) {
        String string3 = string2;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_TCD_DC_Transaction.getTransactionProcessFather(), yP_Row);
        if (yP_TCD_DCC_Brand == null) {
            this.logger(2, "createUser() unable to get Brand");
            return null;
        }
        String string4 = yP_TCD_DCC_Brand.createUser(yP_Row, string, null);
        if (string4 == null) {
            this.logger(2, "createUser() unable to createUser ...");
            return null;
        }
        if (!yP_TCD_DCC_Brand.setHashedPassword(string, string3)) {
            this.logger(2, "createUser() unable to setPassword ...");
            return null;
        }
        this.logger(4, "createUser() user " + string + " created");
        yP_Row.set("userStatus", UserStatusEnumeration.ACTIVE);
        return "";
    }

    @Override
    public String resetUser(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, YP_Row yP_Row, String string) {
        this.logger(2, "resetUser() standard reset done, maybe there is something else to do !!!");
        String string2 = null;
        YP_TCD_DCC_Brand yP_TCD_DCC_Brand = YP_TCD_DCC_Brand.getBrandForUserAction(yP_TCD_DC_Transaction.getTransactionProcessFather(), yP_Row);
        if (yP_TCD_DCC_Brand != null) {
            string2 = yP_TCD_DCC_Brand.resetUser(yP_Row, string);
        }
        return string2;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        this.logger(2, "dealRequest() request unknown " + string);
        return null;
    }
}

