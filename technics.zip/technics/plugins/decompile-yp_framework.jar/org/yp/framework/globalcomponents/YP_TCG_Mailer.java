/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.activation.DataHandler
 *  javax.activation.DataSource
 *  javax.activation.FileDataSource
 *  javax.mail.Address
 *  javax.mail.Authenticator
 *  javax.mail.BodyPart
 *  javax.mail.Message
 *  javax.mail.Multipart
 *  javax.mail.PasswordAuthentication
 *  javax.mail.Session
 *  javax.mail.Transport
 *  javax.mail.internet.InternetAddress
 *  javax.mail.internet.MimeBodyPart
 *  javax.mail.internet.MimeMessage
 *  javax.mail.internet.MimeMultipart
 */
package org.yp.framework.globalcomponents;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.ByteBuilder;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.UserStatusEnumeration;

public class YP_TCG_Mailer
extends YP_GlobalComponent {
    private static final String DEFAULT_MAIL_ALIAS = "Serveur monetique";
    private static final int DEFAULT_MAIL_SMTP_TIMEOUT = 3500;
    private String mailSMTPHost;
    private String mailSMTPSocketFactoryPort;
    private String mailSMTPSocketFactoryClass;
    private String mailSMTPAuth;
    private String mailSMTPPort;
    private int mailSMTPTimeout = 3500;
    private String mailSessionUser;
    private String mailSessionPass;
    private String mailSessionAlias = "Serveur monetique";
    private Session session;
    private Transport transport = null;
    private static final String PROPERTY_MAIL_SMTP_HOST = "mailSMTPHost";
    private static final String PROPERTY_MAIL_SMTP_SOCKET_FATORY_PORT = "mailSMTPSocketFactoryPort";
    private static final String PROPERTY_MAIL_SMTP_SOCKET_FATORY_class = "mailSMTPSocketFactoryClass";
    private static final String PROPERTY_MAIL_SMTP_AUTH = "mailSMTPAuth";
    private static final String PROPERTY_MAIL_SMTP_PORT = "mailSMTPPort";
    private static final String PROPERTY_MAIL_SMTP_TIMEOUT = "mailSMTPTimeout";
    private static final String PROPERTY_MAIL_SESSION_USER = "mailSessionUser";
    private static final String PROPERTY_MAIL_SESSION_PASS = "mailSessionPass";
    private static final String PROPERTY_MAIL_SESSION_ALIAS = "mailSessionAlias";
    private static final String MAIL_IMG_CONTENT_ID = "cid:";
    private static final String MAIL_CREATE_USER_PATTERN_BY_LANGUAGE_ = "mailCreateUserPattern_";
    public static final String TEMPLATE_LOGIN = "[LOGIN]";
    public static final String TEMPLATE_PASSWORD = "[PASSWORD]";
    public static final String TEMPLATE_FIRSTNAME = "[FIRSTNAME]";
    public static final String TEMPLATE_LASTNAME = "[LASTNAME]";
    public static final String TEMPLATE_SUBJECT = "[SUBJECT]";
    public static final String TEMPLATE_IMAGE = "[IMG]";
    public static final String TEMPLATE_TICKET = "[TICKET]";
    public static final String TEMPLATE_FROM = "[FROM]";
    public static final String TEMPLATE_MERCHANT_LABEL = "[MERCHANT_LABEL]";
    public static final String TEMPLATE_CONTRACT_LABEL = "[CONTRACT_LABEL]";
    public static final String TEMPLATE_MERCHANT_TRS_ID = "[MERCHANT_TRS_ID]";
    public static final String TEMPLATE_MERCHANT_PRIVATE_DATA = "[MERCHANT_PRIVATE_DATA]";
    public static final String TEMPLATE_DATE_TIME = "[DATE_TIME]";
    public static final String TEMPLATE_AMOUNT_ALPHA = "[AMOUNT_ALPHA]";
    public static final String TEMPLATE_LINK = "[LINK]";

    public YP_TCG_Mailer(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_HOST);
        if (string != null) {
            this.mailSMTPHost = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_SOCKET_FATORY_PORT)) != null) {
            this.mailSMTPSocketFactoryPort = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_SOCKET_FATORY_class)) != null) {
            this.mailSMTPSocketFactoryClass = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_AUTH)) != null) {
            this.mailSMTPAuth = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_PORT)) != null) {
            this.mailSMTPPort = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SMTP_TIMEOUT)) != null && !string.isEmpty()) {
            try {
                this.mailSMTPTimeout = Integer.parseInt(string);
            }
            catch (Exception exception) {
                this.logger(2, "initialize() Mail timeout " + string + " " + exception);
            }
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SESSION_USER)) != null) {
            this.mailSessionUser = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SESSION_PASS)) != null) {
            this.mailSessionPass = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), PROPERTY_MAIL_SESSION_ALIAS)) != null && !string.isEmpty()) {
            this.mailSessionAlias = string;
        }
        Properties properties = new Properties();
        properties.put("mail.smtp.host", this.mailSMTPHost);
        properties.put("mail.smtp.socketFactory.port", this.mailSMTPSocketFactoryPort);
        properties.put("mail.smtp.socketFactory.class", this.mailSMTPSocketFactoryClass);
        properties.put("mail.smtp.auth", this.mailSMTPAuth);
        properties.put("mail.smtp.port", this.mailSMTPPort);
        this.session = Session.getDefaultInstance((Properties)properties, (Authenticator)new Authenticator(){

            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(YP_TCG_Mailer.this.mailSessionUser, YP_TCG_Mailer.this.mailSessionPass);
            }
        });
        return 1;
    }

    @Override
    public String toString() {
        return "Mailer";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.92";
    }

    private Transport connect(int n, String string, int n2, String string2, String string3) throws Exception {
        ConnectWithTimeout connectWithTimeout = new ConnectWithTimeout(string, n2, string2, string3);
        connectWithTimeout.start();
        try {
            connectWithTimeout.join(n);
        }
        catch (InterruptedException interruptedException) {}
        if (connectWithTimeout.exception != null) {
            throw connectWithTimeout.exception;
        }
        if (!connectWithTimeout.connected) {
            return null;
        }
        return connectWithTimeout.transport;
    }

    private int recreateTransportIfNeeded() {
        if (this.transport != null) {
            return 0;
        }
        try {
            this.lock();
            if (this.transport != null) {
                this.logger(3, "recreateTransportIfNeeded() recreated elsewhere");
                return 0;
            }
            this.transport = this.connect(this.mailSMTPTimeout, this.mailSMTPHost, Integer.parseInt(this.mailSMTPPort), this.mailSessionUser, this.mailSessionPass);
            if (this.transport == null) {
                this.logger(3, "recreateTransportIfNeeded() connect failed");
                return -1;
            }
            this.logger(4, "recreateTransportIfNeeded() new connection done");
            return 1;
        }
        catch (Exception exception) {
            this.logger(3, "recreateTransportIfNeeded() ", exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    private int sendMessage(int n, Transport transport, Message message, InternetAddress[] internetAddressArray, String string, String string2) throws Exception {
        SendMessageWithTimeout sendMessageWithTimeout = new SendMessageWithTimeout(transport, message, internetAddressArray, n);
        sendMessageWithTimeout.start();
        try {
            sendMessageWithTimeout.join(n);
        }
        catch (InterruptedException interruptedException) {}
        if (sendMessageWithTimeout.exception != null) {
            throw sendMessageWithTimeout.exception;
        }
        if (!sendMessageWithTimeout.messageSent) {
            this.logger(2, "sendMessage() not sent. Timeout was " + n + " " + string + " " + string2);
            return -1;
        }
        return 1;
    }

    private int sendMail(String string, String string2, String string3, List<String> list, String string4) {
        int n;
        try {
            n = this.sendMailPrivate(string, string2, string3, list, string4);
            if (n > 0) {
                return n;
            }
        }
        catch (Exception exception) {
            this.logger(2, "sendMail() " + exception);
            n = -1;
        }
        this.createErrorMail(string, string2, string3, list);
        return n;
    }

    private void createErrorMail(String string, String string2, String string3, List<String> list) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TO:");
        if (string != null) {
            stringBuilder.append(string);
        }
        stringBuilder.append(UtilsYP.lineSeparator);
        stringBuilder.append("Subject:");
        if (string2 != null) {
            stringBuilder.append(string2);
        }
        stringBuilder.append(UtilsYP.lineSeparator);
        if (list != null) {
            for (String string4 : list) {
                stringBuilder.append("Attachment:");
                stringBuilder.append(string4);
                stringBuilder.append(UtilsYP.lineSeparator);
            }
        }
        if (string3 != null) {
            stringBuilder.append(string3);
        }
        this.createFile(this.getErrorMailFileName(), stringBuilder);
    }

    private int createFile(String string, StringBuilder stringBuilder) {
        try {
            PrintWriter printWriter = new PrintWriter(new FileWriter(string, true));
            printWriter.print(stringBuilder.toString());
            printWriter.close();
            return 1;
        }
        catch (IOException iOException) {
            this.logger(2, "createFile() " + iOException);
            return -1;
        }
    }

    private String getErrorMailFileName() {
        Calendar calendar = UtilsYP.getCalendar(System.currentTimeMillis());
        int n = calendar.get(1);
        int n2 = calendar.get(2) + 1;
        int n3 = calendar.get(5);
        int n4 = calendar.get(11);
        int n5 = calendar.get(12);
        int n6 = calendar.get(13);
        int n7 = calendar.get(14);
        ByteBuilder byteBuilder = new ByteBuilder(128);
        byteBuilder.append(UtilsYP.getErrorMailsPath());
        byteBuilder.append(n);
        if (n2 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n2);
        if (n3 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n3);
        byteBuilder.append('/');
        new File(byteBuilder.toString()).mkdirs();
        if (n4 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n4);
        byteBuilder.append('h');
        if (n5 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n5);
        byteBuilder.append('m');
        if (n6 < 10) {
            byteBuilder.append('0');
        }
        byteBuilder.append(n6);
        byteBuilder.append('-');
        if (n7 < 100) {
            byteBuilder.append('0');
            if (n7 < 10) {
                byteBuilder.append('0');
            }
        }
        byteBuilder.append(n7);
        byteBuilder.append("ms");
        byteBuilder.append(".mail");
        return byteBuilder.toString();
    }

    private int sendMailPrivate(String string, String string2, String string3, List<String> list, String string4) {
        if (string == null) {
            this.logger(2, "sendMailPrivate() bad parameter to");
            return -1;
        }
        if (string.isEmpty()) {
            this.logger(2, "sendMailPrivate() empty parameter to");
            return 0;
        }
        if (this.getLogLevel() >= 4) {
            this.logger(4, "sendMailPrivate() sending " + string2 + " to " + string);
        }
        if (this.recreateTransportIfNeeded() < 0) {
            this.logger(2, "sendMailPrivate() Unable to create connection while sending " + string2 + " to " + string);
            return -1;
        }
        MimeMessage mimeMessage = null;
        try {
            mimeMessage = new MimeMessage(this.session);
            mimeMessage.setSubject(string2, "UTF-8");
            mimeMessage.setSentDate(new Date());
            mimeMessage.setFrom((Address)new InternetAddress(String.valueOf(string4) + "<" + this.mailSessionUser + ">"));
            MimeMultipart mimeMultipart = new MimeMultipart("related");
            MimeBodyPart mimeBodyPart = new MimeBodyPart();
            if (string3.indexOf("<html>") != -1) {
                mimeBodyPart.setText(string3, "UTF-8", "html");
            } else {
                mimeBodyPart.setText(string3);
            }
            mimeMultipart.addBodyPart((BodyPart)mimeBodyPart);
            if (list != null) {
                for (String string5 : list) {
                    this.addAttachment((Multipart)mimeMultipart, string5);
                }
            }
            mimeMessage.setContent((Multipart)mimeMultipart);
            return this.sendMessage(this.mailSMTPTimeout, this.transport, (Message)mimeMessage, InternetAddress.parse((String)string), string, string2);
        }
        catch (Exception exception) {
            block14: {
                String string6 = exception.getMessage();
                if (string6 != null && string6.contentEquals("Invalid Addresses")) {
                    this.logger(3, "sendMailPrivate() No need to retry invalid adresses!");
                    return -1;
                }
                this.logger(3, "sendMailPrivate() New attempt " + exception);
                this.transport = null;
                try {
                    if (this.recreateTransportIfNeeded() >= 0) break block14;
                    return -1;
                }
                catch (Exception exception2) {
                    this.logger(2, "sendMailPrivate() " + exception2);
                    return -1;
                }
            }
            return this.sendMessage(this.mailSMTPTimeout, this.transport, (Message)mimeMessage, InternetAddress.parse((String)string), string, string2);
        }
    }

    private void addAttachment(Multipart multipart, String string) {
        try {
            if (string.startsWith(MAIL_IMG_CONTENT_ID)) {
                string = string.substring(MAIL_IMG_CONTENT_ID.length());
                MimeBodyPart mimeBodyPart = new MimeBodyPart();
                mimeBodyPart.attachFile(string);
                mimeBodyPart.setContentID("<" + new File(string).getName() + ">");
                mimeBodyPart.setDisposition("inline");
                multipart.addBodyPart((BodyPart)mimeBodyPart);
            } else {
                FileDataSource fileDataSource = new FileDataSource(string);
                MimeBodyPart mimeBodyPart = new MimeBodyPart();
                mimeBodyPart.setDataHandler(new DataHandler((DataSource)fileDataSource));
                mimeBodyPart.setFileName(new File(string).getName());
                multipart.addBodyPart((BodyPart)mimeBodyPart);
            }
        }
        catch (Exception exception) {
            this.logger(2, "addAttachment()  " + exception);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            String string2;
            if (!string.contentEquals("sendMail")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray == null) {
                this.logger(2, "dealRequest() no parameter for sendMail ");
                return null;
            }
            if (objectArray.length < 1 || !(objectArray[0] instanceof String)) {
                this.logger(2, "dealRequest() bad parameter 1 for sendMail");
                return null;
            }
            if (objectArray.length < 2 || !(objectArray[1] instanceof String)) {
                this.logger(2, "dealRequest() bad parameter 2 for sendMail");
                return null;
            }
            if (objectArray.length < 3 || !(objectArray[2] instanceof String)) {
                this.logger(2, "dealRequest() bad parameter 3 for sendMail");
                return null;
            }
            String string3 = (String)objectArray[0];
            String string4 = (String)objectArray[1];
            String string5 = (String)objectArray[2];
            List list = null;
            if (objectArray.length >= 4 && objectArray[3] instanceof List) {
                list = (List)objectArray[3];
            }
            String string6 = this.mailSessionAlias;
            if (objectArray.length >= 5 && objectArray[4] instanceof String && (string2 = (String)objectArray[4]) != null && !string2.isEmpty()) {
                string6 = string2;
            }
            return this.sendMail(string3, string4, string5, list, string6);
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : " + exception);
            return null;
        }
    }

    public static final int sendTemporaryPasswordByMail(YP_Object yP_Object, YP_Transaction yP_Transaction, YP_Row yP_Row, String string) {
        String string2;
        ArrayList<String> arrayList;
        String string3;
        String string4;
        String string5;
        String string6;
        block13: {
            try {
                int n;
                CharSequence charSequence;
                String string7 = yP_Row.getFieldStringValueByName("login");
                string6 = yP_Row.getFieldStringValueByName("mail");
                String string8 = yP_Row.getFieldStringValueByName("preferredLanguage");
                String string9 = yP_Row.getFieldStringValueByName("firstName");
                String string10 = yP_Row.getFieldStringValueByName("lastName");
                string5 = YP_TCG_Mailer.getUserMail(yP_Object, yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier());
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = yP_Transaction.getBrandList().get(0);
                yP_TCD_DCC_Brand.getBrandName();
                String string11 = "";
                List<YP_TCD_DCC_Merchant> list = yP_Transaction.getMerchantList();
                if (list != null && list.size() == 1) {
                    string11 = list.get(0).getMerchantLabel();
                    while (!string11.isEmpty() && !Character.isLetter(string11.charAt(0))) {
                        string11 = string11.substring(1);
                    }
                }
                Set<String> set = yP_TCD_DCC_Brand.getParameters(MAIL_CREATE_USER_PATTERN_BY_LANGUAGE_ + string8);
                string4 = null;
                string3 = "";
                arrayList = new ArrayList<String>();
                if (set == null || set.isEmpty()) {
                    charSequence = new StringBuilder();
                    ((StringBuilder)charSequence).append(TEMPLATE_SUBJECT);
                    ((StringBuilder)charSequence).append("Mot de passe temporaire\n");
                    ((StringBuilder)charSequence).append("Bonjour ");
                    ((StringBuilder)charSequence).append(TEMPLATE_FIRSTNAME);
                    ((StringBuilder)charSequence).append(" ");
                    ((StringBuilder)charSequence).append(TEMPLATE_LASTNAME);
                    ((StringBuilder)charSequence).append(",\n");
                    ((StringBuilder)charSequence).append("\n");
                    ((StringBuilder)charSequence).append("Compte cr\u00e9\u00e9.\n");
                    ((StringBuilder)charSequence).append("Vos param\u00e8tres de connexion sont:\n");
                    ((StringBuilder)charSequence).append("Login : ");
                    ((StringBuilder)charSequence).append(TEMPLATE_LOGIN);
                    ((StringBuilder)charSequence).append("\n");
                    ((StringBuilder)charSequence).append("Mot de passe : ");
                    ((StringBuilder)charSequence).append(TEMPLATE_PASSWORD);
                    ((StringBuilder)charSequence).append("\n");
                    ((StringBuilder)charSequence).append("\n");
                    int n2 = (Integer)yP_Row.getFieldValueByName("accessLevel");
                    if (n2 != 3 && n2 != 4) {
                        ((StringBuilder)charSequence).append("Votre mot de passe devra \u00eatre chang\u00e9 \u00e0 la premi\u00e8re connexion.\n");
                        ((StringBuilder)charSequence).append("\n");
                    }
                    ((StringBuilder)charSequence).append("Bien cordialement,\n");
                    ((StringBuilder)charSequence).append("Votre Service Client Nepting\n");
                    ((StringBuilder)charSequence).append("04.67.66.63.63\n");
                    ((StringBuilder)charSequence).append("support@nepting.com\n");
                    string2 = ((StringBuilder)charSequence).toString();
                } else {
                    if (set.size() > 1) {
                        yP_Object.logger(2, "sendTemporaryPasswordByMail() too many template found");
                    }
                    string2 = yP_Object.getFileContent((String)set.toArray()[0]);
                }
                string2 = string2.replace(TEMPLATE_LOGIN, string7);
                string2 = string2.replace(TEMPLATE_PASSWORD, string);
                string2 = string2.replace(TEMPLATE_FIRSTNAME, string9);
                string2 = string2.replace(TEMPLATE_LASTNAME, string10);
                string2 = string2.replace(TEMPLATE_MERCHANT_LABEL, string11);
                while (string2.charAt(0) == '[') {
                    charSequence = UtilsYP.getFirstLine(string2);
                    string2 = string2.substring(((String)charSequence).length());
                    if (((String)(charSequence = ((String)charSequence).replace("\r", " ").replace("\n", " ").trim())).startsWith(TEMPLATE_SUBJECT)) {
                        string3 = ((String)charSequence).substring(TEMPLATE_SUBJECT.length());
                        yP_Object.logger(4, "sendTemporaryPasswordByMail() mail object changed to " + string3);
                        continue;
                    }
                    if (((String)charSequence).startsWith(TEMPLATE_IMAGE)) {
                        String string12 = ((String)charSequence).substring(TEMPLATE_IMAGE.length());
                        arrayList.add(string12);
                        yP_Object.logger(4, "sendTemporaryPasswordByMail() new attachment " + string12);
                        continue;
                    }
                    if (!((String)charSequence).startsWith(TEMPLATE_FROM)) continue;
                    string4 = ((String)charSequence).substring(TEMPLATE_FROM.length());
                    yP_Object.logger(4, "sendTemporaryPasswordByMail() mail from changed to " + string4);
                }
                if (string6.isEmpty() || (n = ((Integer)yP_Object.getPluginByName("Mailer").dealRequest(yP_Object, "sendMail", string6, string3, string2, arrayList, string4)).intValue()) == 1) break block13;
                yP_Transaction.getDataContainerTransaction().userHandler.setUserMessage("Bad mail");
                return -1;
            }
            catch (Exception exception) {
                yP_Object.logger(2, "sendTemporaryPasswordByMail() ", exception);
                return -1;
            }
        }
        if (!string5.isEmpty() && !string5.contentEquals(string6)) {
            string2 = string2.replace(string, "#############");
            yP_Object.getPluginByName("Mailer").dealRequest(yP_Object, "sendMail", string5, string3, string2, arrayList, string4);
        }
        return 1;
    }

    private static String getUserMail(YP_Object yP_Object, long l) {
        String string;
        block7: {
            YP_Row yP_Row;
            block6: {
                YP_Object yP_Object2 = yP_Object.getPluginByName("User");
                if (yP_Object2 == null) {
                    yP_Object.logger(3, "getUserMail() no plugin available");
                    return null;
                }
                try {
                    yP_Row = (YP_Row)yP_Object2.dealRequest(yP_Object, "getUserRowByID", l);
                    if (yP_Row != null) break block6;
                    yP_Object.logger(2, "getUserMail() user not found :" + l);
                    return null;
                }
                catch (Exception exception) {
                    yP_Object.logger(2, "getUserMail() " + exception);
                    return null;
                }
            }
            string = yP_Row.getFieldStringValueByName("mail");
            if (string != null && !string.isEmpty()) break block7;
            if (UtilsYP.isSATIMServer()) {
                yP_Object.logger(3, "getUserMail() no mail configured for user :" + l);
                break block7;
            }
            yP_Object.logger(2, "getUserMail() no mail configured for user :" + l);
            return null;
        }
        return string;
    }

    public static int mailTLXReport(YP_TCD_DCC_Business yP_TCD_DCC_Business, String string, String string2, Set<String> set, Set<String> set2) {
        return YP_TCG_Mailer.mailTLXReport(yP_TCD_DCC_Business, string, string2, set, set2, null);
    }

    public static int mailTLXReport(YP_TCD_DCC_Business yP_TCD_DCC_Business, String string, String string2, Set<String> set, Set<String> set2, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ArrayList<String> arrayList = new ArrayList<String>();
        String string3 = null;
        String string4 = yP_TCD_DCC_Business.getDataContainerMerchant().getMerchantLabel();
        String string5 = yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel");
        String string6 = "";
        if (yP_TCD_DC_Transaction != null && (string6 = YP_TCD_DCC_Business.getMerchantTransactionIdentifier(yP_TCD_DC_Transaction)) == null) {
            string6 = "";
        }
        String string7 = "";
        if (yP_TCD_DC_Transaction != null && (string7 = YP_TCD_DCC_Business.getMerchantPrivatdeData(yP_TCD_DC_Transaction)) == null) {
            string7 = "";
        }
        while (!string4.isEmpty() && !Character.isLetter(string4.charAt(0))) {
            string4 = string4.substring(1);
        }
        if (set2 != null && !set2.isEmpty()) {
            for (String string8 : set2) {
                String string9 = yP_TCD_DCC_Business.getFileContent(string8);
                if (string9 == null || string9.isEmpty()) {
                    yP_TCD_DCC_Business.logger(2, "mailTLXReport() empty template " + string8);
                    continue;
                }
                string9 = string9.replace(TEMPLATE_MERCHANT_LABEL, string4);
                string9 = string9.replace(TEMPLATE_CONTRACT_LABEL, string5);
                string9 = string9.replace(TEMPLATE_MERCHANT_TRS_ID, string6);
                string9 = string9.replace(TEMPLATE_MERCHANT_PRIVATE_DATA, string7);
                while (string9.charAt(0) == '[') {
                    String string10 = UtilsYP.getFirstLine(string9);
                    string9 = string9.substring(string10.length());
                    if ((string10 = string10.replace("\r", " ").replace("\n", " ").trim()).startsWith(TEMPLATE_SUBJECT)) {
                        string = string10.substring(TEMPLATE_SUBJECT.length());
                        yP_TCD_DCC_Business.logger(4, "mailTLXReport() mail object changed to " + string);
                        continue;
                    }
                    if (string10.startsWith(TEMPLATE_IMAGE)) {
                        String string11 = string10.substring(TEMPLATE_IMAGE.length());
                        arrayList.add(string11);
                        yP_TCD_DCC_Business.logger(4, "mailTLXReport() new attachment " + string11);
                        continue;
                    }
                    if (!string10.startsWith(TEMPLATE_FROM)) continue;
                    string3 = string10.substring(TEMPLATE_FROM.length());
                    yP_TCD_DCC_Business.logger(4, "mailTLXReport() mail from changed to " + string3);
                }
                if (string9.indexOf(TEMPLATE_TICKET) == -1) {
                    yP_TCD_DCC_Business.logger(2, "mailTLXReport() TEMPLATE_TICKET is misssing inside template " + string8);
                    continue;
                }
                string2 = string9.replace(TEMPLATE_TICKET, string2);
            }
        }
        return YP_TCG_Mailer.mailTLXReport(yP_TCD_DCC_Business, string, string2, set, arrayList, string3);
    }

    private static int mailTLXReport(YP_TCD_DCC_Business yP_TCD_DCC_Business, String string, String string2, Set<String> set, List<String> list, String string3) {
        int n = 0;
        if (string2 == null || string2.isEmpty()) {
            return n;
        }
        YP_Object yP_Object = yP_TCD_DCC_Business.getPluginByName("User");
        if (yP_Object == null) {
            yP_TCD_DCC_Business.logger(3, "mailTLXReport() no plugin available");
            return -1;
        }
        try {
            for (String string4 : set) {
                try {
                    String string5 = string4;
                    if (string5.indexOf(64) < 0) {
                        long l = Long.parseLong(string5);
                        YP_Row yP_Row = (YP_Row)yP_Object.dealRequest(yP_TCD_DCC_Business, "getUserRowByID", l);
                        if (yP_Row == null) {
                            yP_TCD_DCC_Business.logger(2, "mailTLXReport() user not found :" + l);
                            continue;
                        }
                        string5 = yP_Row.getFieldStringValueByName("mail");
                        if (string5 == null || string5.isEmpty()) {
                            yP_TCD_DCC_Business.logger(2, "mailTLXReport() no mail configured for user :" + l);
                            continue;
                        }
                        UserStatusEnumeration userStatusEnumeration = (UserStatusEnumeration)((Object)yP_Row.getFieldValueByName("userStatus"));
                        if (userStatusEnumeration == null) {
                            yP_TCD_DCC_Business.logger(2, "mailTLXReport() no userStatus for user :" + l);
                            continue;
                        }
                        if (userStatusEnumeration != UserStatusEnumeration.ACTIVE && userStatusEnumeration != UserStatusEnumeration.INITIAL) {
                            yP_TCD_DCC_Business.logger(3, "mailTLXReport() no mail wanted for user " + l + " with status " + (Object)((Object)userStatusEnumeration));
                            continue;
                        }
                    }
                    yP_TCD_DCC_Business.getPluginByName("Mailer").dealRequest(yP_TCD_DCC_Business, "sendMail", string5, string, string2, list, string3);
                    ++n;
                }
                catch (Exception exception) {
                    yP_TCD_DCC_Business.logger(2, "mailTLXReport() " + exception);
                }
            }
        }
        catch (Exception exception) {
            yP_TCD_DCC_Business.logger(2, "mailTLXReport() " + exception);
        }
        return n;
    }

    final class ConnectWithTimeout
    extends Thread {
        private final String host;
        private final int port;
        private final String user;
        private final String password;
        private volatile Exception exception = null;
        private volatile Transport transport = null;
        private volatile boolean connected = false;

        public ConnectWithTimeout(String string, int n, String string2, String string3) {
            this.host = string;
            this.port = n;
            this.user = string2;
            this.password = string3;
        }

        @Override
        public void run() {
            try {
                this.transport = YP_TCG_Mailer.this.session.getTransport("smtp");
                this.transport.connect(this.host, this.port, this.user, this.password);
                this.connected = true;
            }
            catch (Exception exception) {
                this.exception = exception;
            }
        }
    }

    final class SendMessageWithTimeout
    extends Thread {
        private final Transport transport;
        private final Message message;
        private final InternetAddress[] internetAddressArray;
        private volatile Exception exception = null;
        private volatile boolean messageSent = false;
        private final int timeoutMs;

        public SendMessageWithTimeout(Transport transport, Message message, InternetAddress[] internetAddressArray, int n) {
            this.transport = transport;
            this.message = message;
            this.internetAddressArray = internetAddressArray;
            this.timeoutMs = n;
        }

        @Override
        public void run() {
            block4: {
                long l = System.currentTimeMillis();
                try {
                    this.transport.sendMessage(this.message, (Address[])this.internetAddressArray);
                    this.messageSent = true;
                    if (UtilsYP.isTimeout(l, this.timeoutMs)) {
                        YP_TCG_Mailer.this.logger(2, "SendMessageWithTimeout() OK AFTER " + (System.currentTimeMillis() - l));
                    }
                }
                catch (Exception exception) {
                    this.exception = exception;
                    String string = exception.getMessage();
                    if (string != null && string.contains("421 4.4.2")) {
                        YP_TCG_Mailer.this.logger(3, "SendMessageWithTimeout() Connection dropped for inactivity ? " + exception);
                    }
                    if (!UtilsYP.isTimeout(l, this.timeoutMs)) break block4;
                    YP_TCG_Mailer.this.logger(2, "SendMessageWithTimeout() ", exception);
                }
            }
        }
    }
}

