/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents;

import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.YP_TCD_DCC_Enumeration;
import org.yp.framework.ondemandcomponents.datacontainers.extension.enumeration.YP_TCD_DCC_Interface_Enumeration;
import org.yp.framework.services.YP_TS_DataContainerManager;

public class YP_TCG_Enumeration
extends YP_GlobalComponent {
    YP_TCD_DCC_Interface_Enumeration interfaceEnumeration;
    YP_TCD_DCC_Enumeration extensionEnumeration;

    public YP_TCG_Enumeration(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() no DCC_Technique...");
            }
            return -1;
        }
        this.extensionEnumeration = (YP_TCD_DCC_Enumeration)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtension_Enumeration", new Object[0]);
        this.extensionEnumeration.initialize();
        this.interfaceEnumeration = this.extensionEnumeration;
        return 1;
    }

    @Override
    public String toString() {
        return "Enumeration";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.50";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getIdLabelList")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof Long) {
                    long l = (Long)objectArray[0];
                    return this.interfaceEnumeration.getIdLabelList(l);
                }
                this.logger(2, "dealRequest() bad parameters for getIdLabelList");
                return null;
            }
            if (!string.contentEquals("getIdLabel")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof Enum) {
                Enum enum_ = (Enum)objectArray[0];
                return this.interfaceEnumeration.getIdLabel(enum_);
            }
            if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof Long && objectArray[1] instanceof String) {
                long l = (Long)objectArray[0];
                String string2 = (String)objectArray[1];
                return this.interfaceEnumeration.getIdLabel(l, string2);
            }
            this.logger(2, "dealRequest() bad parameters for getIdLabel");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : ", exception);
            return null;
        }
    }
}

