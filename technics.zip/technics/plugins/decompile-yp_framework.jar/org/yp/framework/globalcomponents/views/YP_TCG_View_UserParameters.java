/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;

public class YP_TCG_View_UserParameters
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_UserParameters(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_UserParameters";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            this.logger(2, "createEmptyView() error while retrieving customizationList");
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject3;
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field != null) {
                yP_TCD_DesignAccesObject3 = yP_TCD_DesignAccesObject;
            } else {
                field = yP_TCD_DesignAccesObject2.getFieldByName(string);
                if (field != null) {
                    yP_TCD_DesignAccesObject3 = yP_TCD_DesignAccesObject2;
                } else {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "createEmptyView() unknown column:" + string);
                    continue;
                }
            }
            if (yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject3, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_ComplexGabarit yP_ComplexGabarit;
        YP_View yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
        if (yP_View == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() ");
            }
            return null;
        }
        YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() No protocol...");
            }
            return null;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getView() bad interface");
            }
            return null;
        }
        YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
        int n = yP_PROT_IHM.getMaxRecords();
        if (n == 0) {
            return yP_View;
        }
        if (n < 0) {
            n = 1000;
        }
        ++n;
        int n2 = yP_PROT_IHM.getStartIndex();
        if (n2 < 0) {
            n2 = 0;
        } else {
            n += n2;
        }
        List<YP_Gabarit> list2 = yP_PROT_IHM.getSearchGabarit();
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = this.dataContainerTechnique.getDesignAccesObject_ByName("User");
        if (list2 != null && !list2.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            for (YP_Gabarit object2 : list2) {
                try {
                    if (object2.objectTosearch == null) {
                        yP_ComplexGabarit.set(object2.fieldName, object2.operator);
                        continue;
                    }
                    yP_View.dealEnumColumn(object2);
                    if (object2.objectTosearch == null) continue;
                    yP_ComplexGabarit.set(object2.fieldName, object2.operator, object2.objectTosearch);
                }
                catch (Exception yP_Row) {
                    if (this.getLogLevel() < 2) continue;
                    this.logger(2, "getView() " + yP_Row);
                }
            }
        } else {
            yP_ComplexGabarit = null;
        }
        List<YP_Row> list3 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list3 == null) {
            this.logger(2, "getView() null list");
            return null;
        }
        if (list3.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n3 = 0;
        while (n3 < list3.size()) {
            YP_Row yP_Row = list3.get(n3);
            yP_View.setRowID(n3, String.valueOf(yP_Row.getFather().getFullTableName()) + "#" + yP_Row.getPrimaryKeyName() + "#" + yP_Row.getPrimaryKey());
            yP_View.setRowActionable(n3, false);
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
                YP_Row yP_Row2 = null;
                if (field != null) {
                    yP_Row2 = yP_Row;
                } else {
                    field = yP_TCD_DesignAccesObject2.getFieldByName(string);
                    if (field != null) {
                        yP_Row2 = yP_TCD_DesignAccesObject2.getRowFromNaturalJoin(yP_Row);
                    }
                }
                if (field != null && yP_Row2 != null) {
                    this.addFieldValue(yP_View, field, yP_Row2, string, n3);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n3;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.getDesignAccesObject_ByName("UserParameters");
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View var1_1, YP_Transaction var2_2, YP_View var3_3, List<DAO_ViewColumn> var4_4) {
        block101: {
            block100: {
                block99: {
                    try {
                        var5_5 = 0;
lbl3:
                        // 2 sources

                        while (true) {
                            if (var5_5 >= var3_3.size()) {
                                return 1;
                            }
                            var6_7 = var3_3.getRowIDAt(var5_5);
                            if (var6_7 != null && !var6_7.isEmpty()) {
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() Key must not be set !");
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                return -1;
                            }
                            var7_8 = this.getDAO(var1_1, var2_2, null);
                            if (var7_8 == null) {
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() not really possible !!!");
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                                return -1;
                            }
                            var8_9 = var7_8.getNewRow();
                            var9_10 = null;
                            var11_13 = var3_3.getColumnSet().iterator();
                            block45: while (true) lbl-1000:
                            // 9 sources

                            {
                                if (!var11_13.hasNext()) {
                                    var10_11 = (Long)var8_9.getFieldValueByName("idUser");
                                    if (var10_11 > 0L || var9_10 != null && !var9_10.isEmpty()) break;
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "createInView() mandatory value missing:idUser, login");
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(6));
                                    return -1;
                                }
                                var10_12 = var11_13.next();
                                var12_14 = var3_3.getFieldValueAt(var5_5, var10_12);
                                if (var12_14 == null) continue;
                                var13_15 = var10_12;
                                tmp = -1;
                                switch (var13_15.hashCode()) {
                                    case -1423911408: {
                                        if (!var13_15.equals("idUserParameters")) break;
                                        tmp = 1;
                                        break;
                                    }
                                    case -1193908346: {
                                        if (!var13_15.equals("idUser")) break;
                                        tmp = 2;
                                        break;
                                    }
                                    case -906277200: {
                                        if (!var13_15.equals("secret")) break;
                                        tmp = 3;
                                        break;
                                    }
                                    case 106079: {
                                        if (!var13_15.equals("key")) break;
                                        tmp = 4;
                                        break;
                                    }
                                    case 103149417: {
                                        if (!var13_15.equals("login")) break;
                                        tmp = 5;
                                        break;
                                    }
                                    case 111972721: {
                                        if (!var13_15.equals("value")) break;
                                        tmp = 4;
                                        break;
                                    }
                                    case 795803756: {
                                        if (!var13_15.equals("modificationAllowed")) break;
                                        tmp = 3;
                                        break;
                                    }
                                }
                                switch (tmp) {
                                    case 1: {
                                        if (var12_14.isEmpty()) continue block45;
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "createInView() Key should be empty :" + var10_12);
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return -1;
                                    }
                                    case 5: {
                                        var9_10 = var12_14;
                                        ** break;
                                    }
                                    case 4: {
                                        var8_9.set(var10_12, (String)var12_14);
                                        ** break;
                                    }
                                    case 3: {
                                        var8_9.set(var10_12, UtilsYP.parseBoolean((String)var12_14));
                                        ** break;
                                    }
                                    case 2: {
                                        var8_9.set(var10_12, Long.parseLong((String)var12_14));
                                        ** break;
                                    }
                                }
                                if (this.getLogLevel() < 2) continue;
                                this.logger(2, "createInView() unknown field :" + var10_12);
                            }
                            var12_14 = this.getPluginByName("User");
                            if (var12_14 == null) {
                                if (this.getLogLevel() >= 3) {
                                    this.logger(3, "createInView() no plugin available");
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                                return -1;
                            }
                            if (var10_11 > 0L) {
                                var13_15 = (YP_Row)var12_14.dealRequest(this, "getUserRowByID", new Object[]{var10_11});
                            } else {
                                var13_15 = (YP_Row)var12_14.dealRequest(this, "getUserRowByLogin", new Object[]{var9_10});
                                if (var13_15 != null) {
                                    var8_9.set("idUser", (Long)var13_15.getFieldValueByName("idUser"));
                                }
                            }
                            if (var13_15 == null) {
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() corresponding user not found :" + var10_11);
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                return -1;
                            }
                            var14_16 = var8_9.getFieldStringValueByName("key");
                            if (var14_16 == null || var14_16.isEmpty()) {
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() mandatory value missing:" + var14_16);
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(6));
                                return -1;
                            }
                            var15_17 = var8_9.getFieldStringValueByName("value");
                            if (var15_17 == null || var15_17.isEmpty()) {
                                if (this.getLogLevel() >= 2) {
                                    this.logger(2, "createInView() mandatory value missing:value");
                                }
                                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(6));
                                return -1;
                            }
                            var16_18 = var14_16;
                            tmp = -1;
                            switch (var16_18.hashCode()) {
                                case -1217664053: {
                                    if (!var16_18.equals("brandAccess")) break;
                                    tmp = 1;
                                    break;
                                }
                                case -1039010484: {
                                    if (!var16_18.equals("merchantAccess")) break;
                                    tmp = 2;
                                    break;
                                }
                                case 227835075: {
                                    if (!var16_18.equals("groupAccess")) break;
                                    tmp = 3;
                                    break;
                                }
                                case 421600534: {
                                    if (!var16_18.equals("contractAccess")) break;
                                    tmp = 4;
                                    break;
                                }
                                case 1935125925: {
                                    if (!var16_18.equals("storeAccess")) break;
                                    tmp = 5;
                                    break;
                                }
                            }
                            switch (tmp) {
                                case 3: {
                                    var17_19 = false;
                                    try {
                                        var18_20 = Long.parseLong(var15_17);
                                        for (YP_TCD_DCC_Group var20_32 : var2_2.getGroupList()) {
                                            if (var20_32.getIDGroup() != var18_20) continue;
                                            var17_19 = true;
                                            break;
                                        }
                                    }
                                    catch (Exception v0) {}
                                    if (!var17_19) {
                                        for (YP_TCD_DCC_Group var18_21 : var2_2.getGroupList()) {
                                            if (!var18_21.getGroupName().contentEquals(var15_17)) continue;
                                            var17_19 = true;
                                            var8_9.set("value", Long.toString(var18_21.getIDGroup()));
                                            break;
                                        }
                                    }
                                    if (var17_19) break;
                                    var18_22 = null;
                                    try {
                                        var19_29 = Long.parseLong(var15_17);
                                        var18_22 = (YP_TCD_DCC_Group)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerGroup", new Object[]{var19_29});
                                    }
                                    catch (Exception v1) {}
                                    if (var18_22 == null) {
                                        var18_22 = (YP_TCD_DCC_Group)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerGroup", new Object[]{var15_17});
                                    }
                                    if (var18_22 != null) {
                                        this.logger(2, "createInView() No right to add this group:" + var15_17);
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                        return -1;
                                    }
                                    this.logger(2, "createInView() Group does not exist:" + var15_17);
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return -1;
                                }
                                case 1: {
                                    var17_19 = false;
                                    try {
                                        var18_20 = Long.parseLong(var15_17);
                                        for (YP_TCD_DCC_Brand var20_33 : var2_2.getDataContainerTransaction().contextHandler.brandContainers) {
                                            if (var20_33.getIDBrand() != var18_20) continue;
                                            var17_19 = true;
                                            break;
                                        }
                                    }
                                    catch (Exception v2) {}
                                    if (!var17_19) {
                                        for (YP_TCD_DCC_Brand var18_23 : var2_2.getDataContainerTransaction().contextHandler.brandContainers) {
                                            if (!var18_23.getContractIdentifier().contentEquals(var15_17)) continue;
                                            var17_19 = true;
                                            var8_9.set("value", Long.toString(var18_23.getIDBrand()));
                                            break;
                                        }
                                    }
                                    if (var17_19) break;
                                    var18_24 = null;
                                    try {
                                        var19_30 = Long.parseLong(var15_17);
                                        var18_24 = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", new Object[]{var19_30});
                                    }
                                    catch (Exception v3) {}
                                    if (var18_24 == null) {
                                        var18_24 = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", new Object[]{var15_17});
                                    }
                                    if (var18_24 != null) {
                                        if (this.getLogLevel() >= 2) {
                                            this.logger(2, "createInView() No right to add this brand:" + var15_17);
                                        }
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                        return -1;
                                    }
                                    if (this.getLogLevel() >= 2) {
                                        this.logger(2, "createInView() Brand does not exist:" + var15_17);
                                    }
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return -1;
                                }
                                case 2: {
                                    var17_19 = false;
                                    try {
                                        var18_20 = Long.parseLong(var15_17);
                                        for (YP_TCD_DCC_Merchant var20_34 : var2_2.getDataContainerTransaction().contextHandler.merchantContainers) {
                                            if (var20_34.getIDMerchant() != var18_20) continue;
                                            var17_19 = true;
                                            break block99;
                                        }
                                        break block99;
                                    }
                                    catch (Exception v4) {
                                        var19_28 = var2_2.getDataContainerTransaction().contextHandler.merchantContainers.iterator();
                                        if (true) ** GOTO lbl305
                                    }
                                }
                                case 5: {
                                    var17_19 = false;
                                    var18_27 = null;
                                    var19_28 = var15_17.split("_");
                                    if (((String[])var19_28).length != 3) {
                                        this.logger(2, "createInView() bad store identifier :" + var15_17);
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return -1;
                                    }
                                    var20_35 = String.valueOf(var19_28[0]) + '_' + (String)var19_28[1];
                                    for (YP_TCD_DCC_Merchant var21_39 : var2_2.getDataContainerTransaction().contextHandler.merchantContainers) {
                                        if (!var21_39.getContractIdentifier().contentEquals(var20_35)) continue;
                                        var18_27 = var21_39;
                                        var23_46 = var21_39.getDataContainerBrand().getStoreList(var21_39.getIDMerchant());
                                        if (var23_46 == null || var23_46.isEmpty()) break;
                                        for (Object var24_48 : var23_46) {
                                            if (!var19_28[2].contentEquals(var21_39.getDataContainerBrand().getStoreIdentifier((YP_Row)var24_48))) continue;
                                            var17_19 = true;
                                            break;
                                        }
                                        break;
                                    }
                                    if (var17_19) break;
                                    if (var18_27 != null) {
                                        this.logger(2, "createInView() Store does not exist:" + var15_17);
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                        return -1;
                                    }
                                    var21_40 = (YP_TCD_DCC_Merchant)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerMerchant", new Object[]{var15_17});
                                    if (var21_40 != null) {
                                        this.logger(2, "createInView() No right on the corresponding merchant:" + var15_17);
                                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                                        return -1;
                                    }
                                    this.logger(2, "createInView() Merchant does not exist:" + var15_17);
                                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                                    return -1;
                                }
                                case 4: {
                                    var17_19 = false;
                                    try {
                                        var21_41 = Long.parseLong(var15_17);
                                        var24_48 = var2_2.getDataContainerTransaction().contextHandler.businessContainers.iterator();
                                        while (var24_48.hasNext()) {
                                            var23_47 = var24_48.next();
                                            if (var23_47.getIDContract() != var21_41) continue;
                                            var17_19 = true;
                                            break block100;
                                        }
                                        break block100;
                                    }
                                    catch (Exception v5) {
                                        var22_44 = var2_2.getDataContainerTransaction().contextHandler.businessContainers.iterator();
                                        if (true) ** GOTO lbl327
                                    }
                                }
                                default: {
                                    if (this.getLogLevel() < 3) break;
                                    this.logger(3, "createInView() unknow properties setted withoud control :" + var14_16);
                                    break;
                                }
                            }
                            break block101;
                            break;
                        }
                    }
                    catch (Exception var5_6) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() " + var5_6);
                        }
                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
                        return -1;
                    }
                    do {
                        if (!(var18_25 = (YP_TCD_DCC_Merchant)var19_28.next()).getContractIdentifier().contentEquals(var15_17)) continue;
                        var17_19 = true;
                        var8_9.set("value", Long.toString(var18_25.getIDMerchant()));
                        break;
lbl305:
                        // 2 sources

                    } while (var19_28.hasNext());
                }
                if (!var17_19) {
                    var18_26 = (YP_TCD_DCC_Merchant)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerMerchant", new Object[]{var15_17});
                    if (var18_26 != null) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "createInView() No right to add this merchant:" + var15_17);
                        }
                        YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                        return -1;
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() Merchant does not exist:" + var15_17);
                    }
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                break block101;
                do {
                    if (!(var21_42 = var22_44.next()).getContractIdentifier().contentEquals(var15_17)) continue;
                    var17_19 = true;
                    var8_9.set("value", Long.toString(var21_42.getIDContract()));
                    break;
lbl327:
                    // 2 sources

                } while (var22_44.hasNext());
            }
            if (!var17_19) {
                var21_43 = (YP_TCD_DCC_Business)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBusiness", new Object[]{var15_17});
                if (var21_43 != null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "createInView() No right to add this contract:" + var15_17);
                    }
                    YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(102));
                    return -1;
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "createInView() Contract does not exist:" + var15_17);
                }
                YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
        }
        if (var7_8.addRow(var8_9, true) < 0) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createInView() Not able to add row...");
            }
            YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
        if (var7_8.persist() < 0) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createInView() Not able to save changes...");
            }
            YP_TCD_DCC_Business.setExtendedResult(var2_2.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
        ++var5_5;
        ** while (true)
    }
}

