/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package org.yp.framework.globalcomponents.model;

import com.google.gson.annotations.SerializedName;

public class DTO_ModePayment {
    @SerializedName(value="idmodepayementPdv")
    private int idmodepayementPdv = 0;
    @SerializedName(value="modepayementPdv")
    private String modepayementPdv = null;
    @SerializedName(value="plafondpostpayePdv")
    private long plafondpostpayePdv = 0L;
    @SerializedName(value="soldeprepaye")
    private long soldeprepaye = 0L;

    public int getIdmodepayementPdv() {
        return this.idmodepayementPdv;
    }

    public void setIdmodepayementPdv(int n) {
        this.idmodepayementPdv = n;
    }

    public String getModepayementPdv() {
        return this.modepayementPdv;
    }

    public void setModepayementPdv(String string) {
        this.modepayementPdv = string;
    }

    public long getPlafondpostpayePdv() {
        return this.plafondpostpayePdv;
    }

    public void setPlafondpostpayePdv(long l) {
        this.plafondpostpayePdv = l;
    }

    public long getSoldeprepaye() {
        return this.soldeprepaye;
    }

    public void setSoldeprepaye(long l) {
        this.soldeprepaye = l;
    }

    public int hashCode() {
        int n = 1;
        n = 31 * n + this.idmodepayementPdv;
        n = 31 * n + (this.modepayementPdv == null ? 0 : this.modepayementPdv.hashCode());
        n = 31 * n + (int)(this.plafondpostpayePdv ^ this.plafondpostpayePdv >>> 32);
        n = 31 * n + (int)(this.soldeprepaye ^ this.soldeprepaye >>> 32);
        return n;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (this.getClass() != object.getClass()) {
            return false;
        }
        DTO_ModePayment dTO_ModePayment = (DTO_ModePayment)object;
        if (this.idmodepayementPdv != dTO_ModePayment.idmodepayementPdv) {
            return false;
        }
        if (this.modepayementPdv == null ? dTO_ModePayment.modepayementPdv != null : !this.modepayementPdv.equals(dTO_ModePayment.modepayementPdv)) {
            return false;
        }
        if (this.plafondpostpayePdv != dTO_ModePayment.plafondpostpayePdv) {
            return false;
        }
        return this.soldeprepaye == dTO_ModePayment.soldeprepaye;
    }
}

