/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.authentifiers;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;

public interface YP_Authentifiers {
    public Boolean changePassword(YP_TCD_DC_Transaction var1, YP_Row var2, String var3, String var4, StringBuilder var5);

    public Boolean setPassword(YP_TCD_DC_Transaction var1, YP_Row var2, String var3, String var4);

    public AuthenticationResultEnumeration authenticate(YP_TCD_DC_Transaction var1, YP_Row var2, String var3, String var4, StringBuilder var5);

    public String createUser(YP_TCD_DC_Transaction var1, YP_Row var2, String var3, String var4);

    public String resetUser(YP_TCD_DC_Transaction var1, YP_Row var2, String var3);

    public static enum AuthenticationResultEnumeration {
        UNKNOWN,
        AUTHENTICATED,
        EXPIRED_PASSWORD,
        INVALID_PASSWORD,
        WRONG_PASSWORD,
        PROCESSING_ERROR;

    }
}

