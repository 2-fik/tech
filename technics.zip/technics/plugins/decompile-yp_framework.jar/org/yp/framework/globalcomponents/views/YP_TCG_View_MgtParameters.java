/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.globalcomponents.views;

import java.lang.reflect.Field;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.YP_View;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.globalcomponents.views.YP_TCG_View;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.YP_TCD_DCC_Interface_View;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumn;
import org.yp.framework.ondemandcomponents.datacontainers.extension.viewformatter.designaccesobjects.DAO_ViewColumnCustomization;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;

public class YP_TCG_View_MgtParameters
extends YP_TCG_View {
    YP_TS_DataContainerManager dataContainerManager;
    YP_TCD_DCC_Technique dataContainerTechnique;

    public YP_TCG_View_MgtParameters(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public final int initialize() {
        super.initialize();
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        return 1;
    }

    @Override
    public String toString() {
        return "View_MgtParameters";
    }

    @Override
    public String getVersion() {
        return "V1.0.1.0";
    }

    @Override
    public YP_View createEmptyView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_View yP_View = new YP_View(this);
        long l2 = yP_Transaction.getDataContainerTransaction().userHandler.getUserIdentifier();
        List<DAO_ViewColumnCustomization> list2 = yP_TCD_DCC_Interface_View.getColumnCustomization(l2, list);
        if (list2 == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while retrieving customizationList");
            }
            return null;
        }
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
        for (DAO_ViewColumn dAO_ViewColumn : list) {
            String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
            String string2 = this.getLabel(dAO_ViewColumn.idLabel, string);
            Field field = yP_TCD_DesignAccesObject.getFieldByName(string);
            if (field == null) {
                if (this.getLogLevel() < 2) continue;
                this.logger(2, "createEmptyView() unknown column:" + string);
                continue;
            }
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject2 = yP_TCD_DesignAccesObject;
            if (yP_View.addColumn(string, string2, yP_TCD_DesignAccesObject2, field, dAO_ViewColumn.defaultRank) < 0 && this.getLogLevel() >= 2) {
                this.logger(2, "createEmptyView() error while adding column:" + string);
            }
            if (yP_View.getColumnFormat(string).contentEquals("enum")) {
                this.dealEnumColumn(yP_TCD_DCC_Interface_View, yP_Transaction, yP_View, yP_TCD_DCC_Interface_View.getIdEnum(dAO_ViewColumn.idViewColumn), string, field);
            }
            if (list2 != null && !list2.isEmpty()) {
                for (DAO_ViewColumnCustomization dAO_ViewColumnCustomization : list2) {
                    if (dAO_ViewColumnCustomization.idViewColumn != dAO_ViewColumn.idViewColumn) continue;
                    yP_View.setColumnRank(string, dAO_ViewColumnCustomization.rank);
                    if (dAO_ViewColumnCustomization.width <= 0) break;
                    yP_View.getColumnProperties(string).put("width", Integer.toString(dAO_ViewColumnCustomization.width));
                    break;
                }
            }
            if (dAO_ViewColumn.writeAccessList != null && dAO_ViewColumn.writeAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("writeAllowed", "1");
            } else {
                yP_View.getColumnProperties(string).put("writeAllowed", "0");
            }
            if (dAO_ViewColumn.searchAccessList != null && dAO_ViewColumn.searchAccessList.isSet(yP_Transaction.getDataContainerTransaction().userHandler.getUserAccessLevel())) {
                yP_View.getColumnProperties(string).put("searchAllowed", "1");
                continue;
            }
            yP_View.getColumnProperties(string).put("searchAllowed", "0");
        }
        return yP_View;
    }

    @Override
    public YP_View getView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, long l, List<DAO_ViewColumn> list) {
        YP_ComplexGabarit yP_ComplexGabarit;
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
        YP_View yP_View;
        block45: {
            block42: {
                yP_View = this.createEmptyView(yP_TCD_DCC_Interface_View, yP_Transaction, l, list);
                if (yP_View == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() ");
                    }
                    return null;
                }
                YP_TCD_PosProtocol yP_TCD_PosProtocol = yP_Transaction.getDataContainerTransaction().getProtocolEFT();
                if (yP_TCD_PosProtocol == null) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() No protocol...");
                    }
                    return null;
                }
                if (!(yP_TCD_PosProtocol instanceof YP_PROT_IHM)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getView() bad interface");
                    }
                    return null;
                }
                YP_PROT_IHM yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                int n = yP_PROT_IHM.getMaxRecords();
                if (n == 0) {
                    return yP_View;
                }
                if (n < 0) {
                    n = 1000;
                }
                ++n;
                int n2 = yP_PROT_IHM.getStartIndex();
                if (n2 < 0) {
                    n2 = 0;
                } else {
                    n += n2;
                }
                List<YP_Gabarit> list2 = yP_PROT_IHM.getSearchGabarit();
                yP_TCD_DesignAccesObject = this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
                if (list2 == null || list2.isEmpty()) break block42;
                yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                for (YP_Gabarit object2 : list2) {
                    try {
                        block43: {
                            if (object2.objectTosearch == null) {
                                yP_ComplexGabarit.set(object2.fieldName, object2.operator);
                                continue;
                            }
                            yP_View.dealEnumColumn(object2);
                            if (object2.objectTosearch == null || !(object2.objectTosearch instanceof String)) break block43;
                            switch (object2.fieldName) {
                                case "idUser": {
                                    object2.objectTosearch = this.getIdUser((String)object2.objectTosearch);
                                    break;
                                }
                                case "idGroup": {
                                    object2.objectTosearch = this.getIdGroup(yP_Transaction, (String)object2.objectTosearch);
                                    break;
                                }
                                case "idBrand": {
                                    object2.objectTosearch = this.getIdBrand(yP_Transaction, (String)object2.objectTosearch);
                                    break;
                                }
                                case "idMerchant": {
                                    object2.objectTosearch = this.getIdMerchant(yP_Transaction, (String)object2.objectTosearch);
                                    break;
                                }
                                case "idContract": {
                                    object2.objectTosearch = this.getIdContract(yP_Transaction, (String)object2.objectTosearch);
                                    break;
                                }
                                case "idStore": {
                                    object2.objectTosearch = this.getIdStore(yP_Transaction, (String)object2.objectTosearch);
                                }
                            }
                        }
                        if (object2.objectTosearch == null) continue;
                        yP_ComplexGabarit.set(object2.fieldName, object2.operator, object2.objectTosearch);
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() < 2) continue;
                        this.logger(2, "getView()  " + exception);
                    }
                }
                break block45;
            }
            yP_ComplexGabarit = null;
        }
        List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list2 == null) {
            this.logger(2, "getView() null list");
            return null;
        }
        if (list2.isEmpty()) {
            this.logger(4, "getView() nothing found");
            return yP_View;
        }
        int n = 0;
        while (n < list2.size()) {
            Object exception = list2.get(n);
            yP_View.setRowID(n, String.valueOf(((YP_Row)exception).getFather().getFullTableName()) + "#" + ((YP_Row)exception).getPrimaryKeyName() + "#" + ((YP_Row)exception).getPrimaryKey());
            yP_View.setRowActionable(n, false);
            for (DAO_ViewColumn dAO_ViewColumn : list) {
                String string = YP_Row.getStringValue(dAO_ViewColumn.columnName);
                Field field = ((YP_Row)exception).getFieldByName(string);
                Object object = null;
                if (field != null) {
                    object = exception;
                }
                if (field != null && object != null) {
                    this.addFieldValue(yP_View, field, (YP_Row)object, string, n);
                    continue;
                }
                this.logger(2, "getView() unknown column:" + string);
            }
            ++n;
        }
        return yP_View;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() Not yet done");
        return null;
    }

    @Override
    public YP_TCD_DesignAccesObject getDAO(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, String string) {
        return this.dataContainerTechnique.getDesignAccesObject_ByName("MgtParameters");
    }

    @Override
    public int executeAction(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, YP_Row yP_Row, YP_TCD_DC_Context.Action action) {
        this.logger(2, "executeAction() Not yet done");
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int createInView(YP_TCD_DCC_Interface_View yP_TCD_DCC_Interface_View, YP_Transaction yP_Transaction, YP_View yP_View, List<DAO_ViewColumn> list) {
        try {
            int n = 0;
            while (n < yP_View.size()) {
                String string = yP_View.getRowIDAt(n);
                if (string != null && !string.isEmpty()) {
                    this.logger(2, "createInView() Key must not be set !");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = this.getDAO(yP_TCD_DCC_Interface_View, yP_Transaction, null);
                if (yP_TCD_DesignAccesObject == null) {
                    this.logger(2, "createInView() not really possible !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                long l = 0L;
                long l2 = 0L;
                long l3 = 0L;
                long l4 = 0L;
                long l5 = 0L;
                long l6 = 0L;
                String string2 = null;
                YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
                block28: for (String string3 : yP_View.getColumnSet()) {
                    String string4 = yP_View.getFieldValueAt(n, string3);
                    if (string4 == null) continue;
                    switch (string3) {
                        case "idMgtParameters": {
                            if (string4.isEmpty()) continue block28;
                            this.logger(2, "createInView() Key should be empty :" + string3);
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                        case "key": {
                            string2 = string4;
                            yP_Row.set(string3, string2);
                            break;
                        }
                        case "value": {
                            yP_Row.set(string3, string4);
                            break;
                        }
                        case "secret": 
                        case "modificationAllowed": {
                            yP_Row.set(string3, UtilsYP.parseBoolean(string4));
                            break;
                        }
                        case "idUser": {
                            l = this.getIdUser(string4);
                            yP_Row.set(string3, l);
                            break;
                        }
                        case "idGroup": {
                            l2 = this.getIdGroup(yP_Transaction, string4);
                            yP_Row.set(string3, l2);
                            break;
                        }
                        case "idBrand": {
                            l3 = this.getIdBrand(yP_Transaction, string4);
                            yP_Row.set(string3, l3);
                            break;
                        }
                        case "idMerchant": {
                            l4 = this.getIdMerchant(yP_Transaction, string4);
                            yP_Row.set(string3, l4);
                            break;
                        }
                        case "idContract": {
                            l5 = this.getIdContract(yP_Transaction, string4);
                            yP_Row.set(string3, l5);
                            break;
                        }
                        case "idStore": {
                            l6 = this.getIdStore(yP_Transaction, string4);
                            yP_Row.set(string3, l6);
                            break;
                        }
                        default: {
                            this.logger(2, "createInView() unknown field :" + string3);
                        }
                    }
                }
                if (string2 == null || l < 0L || l3 < 0L || l4 < 0L || l5 < 0L || l6 < 0L) {
                    this.logger(2, "createInView() Bad request");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return -1;
                }
                if (yP_TCD_DesignAccesObject.addRow(yP_Row, true) < 0) {
                    this.logger(2, "createInView() Not able to add row...");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                if (yP_TCD_DesignAccesObject.persist() < 0) {
                    this.logger(2, "createInView() Not able to save changes...");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
                    return -1;
                }
                this.logger(4, "createInView() row added");
                ++n;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "createInView() " + exception);
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(4));
            return -1;
        }
    }

    /*
     * Unable to fully structure code
     */
    private long getIdGroup(YP_Transaction var1_1, String var2_2) {
        block5: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Group var5_6 : var1_1.getGroupList()) {
                    if (var5_6.getIDGroup() != var3_3) continue;
                    return var3_3;
                }
                break block5;
            }
            catch (Exception v0) {
                ** for (var3_4 : var1_1.getGroupList())
            }
lbl-1000:
            // 1 sources

            {
                if (!var3_4.getGroupName().contentEquals(var2_2)) continue;
                return var3_4.getIDGroup();
            }
        }
        return -1L;
    }

    /*
     * Unable to fully structure code
     */
    private long getIdBrand(YP_Transaction var1_1, String var2_2) {
        block5: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Brand var5_6 : var1_1.getBrandList()) {
                    if (var5_6.getIDBrand() != var3_3) continue;
                    return var3_3;
                }
                break block5;
            }
            catch (Exception v0) {
                ** for (var3_4 : var1_1.getBrandList())
            }
lbl-1000:
            // 1 sources

            {
                if (!var3_4.getContractIdentifier().contentEquals(var2_2)) continue;
                return var3_4.getIDBrand();
            }
        }
        return -1L;
    }

    /*
     * Unable to fully structure code
     */
    private long getIdContract(YP_Transaction var1_1, String var2_2) {
        block5: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Business var5_6 : var1_1.getApplicationList()) {
                    if (var5_6.getIDContract() != var3_3) continue;
                    return var3_3;
                }
                break block5;
            }
            catch (Exception v0) {
                ** for (var3_4 : var1_1.getApplicationList())
            }
lbl-1000:
            // 1 sources

            {
                if (!var3_4.getContractIdentifier().contentEquals(var2_2)) continue;
                return var3_4.getIDContract();
            }
        }
        return -1L;
    }

    /*
     * Unable to fully structure code
     */
    private long getIdStore(YP_Transaction var1_1, String var2_2) {
        block8: {
            if (var2_2 == null || var2_2.isEmpty()) {
                return 0L;
            }
            try {
                var3_3 = Long.parseLong(var2_2);
                for (YP_TCD_DCC_Brand var5_7 : var1_1.getBrandList()) {
                    if (var5_7.getStore(var3_3) == null) continue;
                    return var3_3;
                }
                break block8;
            }
            catch (Exception v0) {
                if (!var2_2.contains("_") || (var3_4 = var2_2.split("_")).length != 3) break block8;
                ** for (var4_9 : var1_1.getBrandList())
            }
lbl-1000:
            // 1 sources

            {
                if (!var4_9.getContractIdentifier().contentEquals(var3_4[0])) continue;
                for (YP_TCD_DCC_Merchant var6_6 : var4_9.dataContainerMerchantList) {
                    if (!var6_6.getMerchantName().contentEquals(var3_4[1])) continue;
                    var8_11 = var4_9.getStoreList(var6_6.getIDMerchant());
                    if (var8_11 != null && !var8_11.isEmpty()) {
                        for (YP_Row var9_13 : var8_11) {
                            if (!var4_9.getStoreIdentifier(var9_13).contentEquals(var3_4[2])) continue;
                            return var9_13.getPrimaryKey();
                        }
                    }
                    this.logger(3, "getIdStore() Merchant found but still a bad store identifier " + var2_2);
                    return -1L;
                }
                this.logger(3, "getIdStore() Brand found but still a bad store identifier " + var2_2);
                return -1L;
            }
        }
        return -1L;
    }
}

