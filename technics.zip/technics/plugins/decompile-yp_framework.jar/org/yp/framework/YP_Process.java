/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.utils.UtilsYP;

public abstract class YP_Process
extends YP_Object
implements Runnable {
    private int watchDogTimoutMS = 120000;
    private long watchDogTimer = 0L;
    private long nextRunningLog = System.currentTimeMillis() + 60000L;
    private final Map<String, YP_Object> cachedPluginList = new HashMap<String, YP_Object>();
    private final ReentrantLock cachedPluginListMutex = new ReentrantLock();

    public YP_Process(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.iAmAlive();
    }

    @Override
    public int shutdown() {
        super.shutdown();
        this.resetCachedPlugin();
        return 1;
    }

    public final void iAmAlive() {
        this.watchDogTimer = System.currentTimeMillis();
        if (this.watchDogTimer > this.nextRunningLog) {
            this.logger(4, "Process is alive...");
            this.nextRunningLog += 60000L;
        }
    }

    public final long getWatchDogTimer() {
        return this.watchDogTimer;
    }

    public int getWatchDogTimoutMS() {
        return this.watchDogTimoutMS;
    }

    public void setWatchDogTimoutMS(int n) {
        this.watchDogTimoutMS = n;
    }

    public final YP_Object getCachedPluginByName(String string) {
        try {
            this.cachedPluginListMutex.lock();
            YP_Object yP_Object = this.cachedPluginList.get(string);
            return yP_Object;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCachedPluginByName() " + string + " " + exception);
            }
        }
        finally {
            this.cachedPluginListMutex.unlock();
        }
        return null;
    }

    public final int resetCachedPlugin() {
        try {
            this.cachedPluginListMutex.lock();
            this.cachedPluginList.clear();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "resetCachedPlugin() " + exception);
            }
        }
        finally {
            this.cachedPluginListMutex.unlock();
        }
        return -1;
    }

    protected final int addCachedPlugin(String string, YP_Object yP_Object) {
        try {
            this.cachedPluginListMutex.lock();
            this.cachedPluginList.put(string, yP_Object);
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addCachedPlugin() " + exception);
            }
        }
        finally {
            this.cachedPluginListMutex.unlock();
        }
        return -1;
    }

    @Override
    public int initialize() {
        String string;
        super.initialize();
        if (this.getPropertyFileName() != null && (string = this.getProperty(this.getPropertyFileName(), "watchDogTimoutMS")) != null) {
            this.setWatchDogTimoutMS(Integer.parseInt(string));
        }
        return 1;
    }

    public final boolean is_YP_Thread_Alive() {
        return System.currentTimeMillis() <= (long)this.getWatchDogTimoutMS() + this.getWatchDogTimer();
    }

    protected static void getAllStackTraces(StringBuilder stringBuilder) {
        try {
            ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
            Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
            Set<Thread> set = map.keySet();
            stringBuilder.append(UtilsYP.lineSeparator);
            for (Thread thread : set) {
                stringBuilder.append("Trace information for the thread ");
                stringBuilder.append(thread);
                stringBuilder.append(" CPU TIME :");
                float f = 0.0f;
                long l = threadMXBean.getThreadCpuTime(thread.getId());
                if (l > 0L) {
                    f = l / 100000L;
                    f /= 1000.0f;
                }
                stringBuilder.append(f);
                stringBuilder.append(UtilsYP.lineSeparator);
                StackTraceElement[] stackTraceElementArray = map.get(thread);
                int n = 0;
                while (n < stackTraceElementArray.length) {
                    stringBuilder.append(stackTraceElementArray[n]);
                    stringBuilder.append(UtilsYP.lineSeparator);
                    ++n;
                }
                stringBuilder.append(UtilsYP.lineSeparator);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}

