/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;

final class YP_Connection {
    public long idConnection;
    public YP_PHYS_Interface plugin;
    public int status;
    public long timestamp;
    public long threadID;

    YP_Connection(YP_PHYS_Interface yP_PHYS_Interface, long l, int n) {
        this.plugin = yP_PHYS_Interface;
        this.idConnection = l;
        this.status = n;
        this.timestamp = System.currentTimeMillis();
    }

    public void setStatus(int n) {
        this.status = n;
    }

    public long getIDConnection() {
        return this.idConnection;
    }

    public int getStatus() {
        return this.status;
    }

    public void setTimestamp(long l) {
        this.timestamp = l;
    }

    public void setPlugin(YP_PHYS_Interface yP_PHYS_Interface) {
        this.plugin = yP_PHYS_Interface;
    }
}

