/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipFile;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.utils.ConfigReader;
import org.yp.utils.UtilsYP;

public class YP_TS_GlobalProcessManager
extends YP_Service {
    private long topForNewStatusMail = 0L;
    private static final int MIN_TIME_BETWEEN_STATUS_MAILS_MS = 300000;
    private int nbErrorStatusLoop = 0;
    private String emailForErrors = null;
    private static YP_TS_GlobalProcessManager globalProcessManager = null;
    private final Map<String, URLClassLoader> classLoaderList = new HashMap<String, URLClassLoader>();

    private YP_TS_GlobalProcessManager() throws Exception {
        super(null, new Object[0]);
        this.setContractIdentifier("KERNEL");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static YP_TS_GlobalProcessManager getInstance() {
        Class<YP_TS_GlobalProcessManager> clazz = YP_TS_GlobalProcessManager.class;
        synchronized (YP_TS_GlobalProcessManager.class) {
            if (globalProcessManager == null) {
                try {
                    globalProcessManager = new YP_TS_GlobalProcessManager();
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
            // ** MonitorExit[var0] (shouldn't be in output)
            return globalProcessManager;
        }
    }

    private YP_Object set_YP_Object(String string) {
        YP_Object yP_Object;
        Constructor<?> constructor;
        try {
            constructor = this.get_YP_Constructor(string);
        }
        catch (Exception exception) {
            this.logger(2, "set_YP_Object() " + string + " ", exception);
            return null;
        }
        try {
            try {
                yP_Object = (YP_Object)constructor.newInstance(this, new Object[0]);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                yP_Object = (YP_Object)constructor.newInstance(this);
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.logger(2, "set_YP_Object() ", illegalArgumentException);
            return null;
        }
        catch (InstantiationException instantiationException) {
            this.logger(2, "set_YP_Object() ", instantiationException);
            return null;
        }
        catch (IllegalAccessException illegalAccessException) {
            this.logger(2, "set_YP_Object() ", illegalAccessException);
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {
            this.logger(2, "set_YP_Object() ", invocationTargetException);
            return null;
        }
        if (string.indexOf(",") != -1) {
            String string2 = string.substring(string.indexOf(",") + 1);
            yP_Object.setPropertyFileName(string2);
        }
        this.addChild(yP_Object, 1);
        return yP_Object;
    }

    private int add_YP_Object(List<Thread> list, String string) {
        Object object;
        YP_Object yP_Object;
        Constructor<?> constructor;
        try {
            constructor = this.get_YP_Constructor(string);
        }
        catch (Exception exception) {
            this.logger(2, "add_YP_Object() " + string + " ", exception);
            return -1;
        }
        if (constructor == null) {
            return -1;
        }
        try {
            try {
                yP_Object = (YP_Object)constructor.newInstance(this, new Object[0]);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                yP_Object = (YP_Object)constructor.newInstance(this);
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.logger(2, "add_YP_Object() ", illegalArgumentException);
            return -2;
        }
        catch (InstantiationException instantiationException) {
            this.logger(2, "add_YP_Object() ", instantiationException);
            return -3;
        }
        catch (IllegalAccessException illegalAccessException) {
            this.logger(2, "add_YP_Object() ", illegalAccessException);
            return -4;
        }
        catch (InvocationTargetException invocationTargetException) {
            this.logger(2, "add_YP_Object() ", invocationTargetException);
            return -5;
        }
        if (string.indexOf(",") != -1) {
            object = string.substring(string.indexOf(",") + 1);
            yP_Object.setPropertyFileName((String)object);
        }
        if (YP_Service.class.isInstance(yP_Object)) {
            String string2 = yP_Object.getPreferredName();
            object = string2 != null & !string2.isEmpty() ? new Thread((Runnable)((YP_Service)yP_Object), string2) : new Thread((Runnable)((YP_Service)yP_Object), yP_Object.toString());
            ((YP_Service)yP_Object).setThreadID(((Thread)object).getId());
            list.add((Thread)object);
        }
        this.addChild(yP_Object, 1);
        return 1;
    }

    public int reInitialize(String string, String string2) {
        YP_Service yP_Service;
        block15: {
            YP_Object yP_Object;
            block14: {
                block13: {
                    block12: {
                        if (string2 != null && !string2.isEmpty()) {
                            yP_Object = this.getChildByPreferredName(string2);
                            break block12;
                        }
                        if (string != null && !string.isEmpty()) {
                            yP_Object = this.getChildByName(string);
                            break block12;
                        }
                        this.logger(2, "reInitialize() no valid parameter");
                        return -1;
                    }
                    if (yP_Object != null) break block13;
                    this.logger(2, "reInitialize() plugin not found " + string + " " + string2);
                    return -1;
                }
                if (YP_Service.class.isInstance(yP_Object)) break block14;
                this.logger(2, "reInitialize() trying to stop a plugin which is not a service " + string + " " + string2);
                return -1;
            }
            try {
                yP_Service = (YP_Service)yP_Object;
                yP_Service.setObjectStatus(2);
                boolean bl = false;
                long l = System.currentTimeMillis();
                do {
                    if (this.getChildProcessByThreadID(yP_Service.getThreadID()) != null) {
                        bl = true;
                        continue;
                    }
                    UtilsYP.sleep(1000);
                } while (!UtilsYP.isTimeout(l, 60000));
                if (bl) break block15;
                this.logger(2, "reInitialize() timeout while waiting for service to stop :" + string + " " + string2);
                return -1;
            }
            catch (Exception exception) {
                this.logger(2, "reInitialize() ", exception);
                return -1;
            }
        }
        String string3 = String.valueOf(yP_Service.getClass().getName()) + "," + yP_Service.getPropertyFileName();
        yP_Service = (YP_Service)this.set_YP_Object(string3);
        if (yP_Service != null) {
            this.logger(4, "reInitialize() Plugin added :" + string3);
        } else {
            this.logger(2, "reInitialize() Plugin not added :" + string3);
        }
        yP_Service.setObjectStatus(1);
        yP_Service.initialize();
        Thread thread = string2 != null & !string2.isEmpty() ? new Thread((Runnable)yP_Service, string2) : new Thread((Runnable)yP_Service, yP_Service.toString());
        yP_Service.setThreadID(thread.getId());
        thread.start();
        return 1;
    }

    public boolean checkIntegrity() {
        return true;
    }

    private boolean checkLicense() {
        MiscUtils.getMotherboardSN();
        return true;
    }

    @Override
    public int initialize() {
        Object object;
        String string;
        Object object2;
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        this.setSupervisor(this);
        this.setFather(this);
        this.setAncestor(this);
        this.setObjectStatus(1);
        this.setThreadID(Thread.currentThread().getId());
        super.initialize();
        this.addChild(this, 1);
        try {
            object2 = new ConfigReader("./technics/properties/dependencies.properties");
            int n = 1;
            do {
                if ((string = ((ConfigReader)object2).getNext("dependency", n)) != null) {
                    try {
                        ClassPathHacker.addFile(string);
                    }
                    catch (Exception exception) {
                        this.logger(2, "initialize() " + string, exception);
                    }
                }
                n = 0;
            } while (string != null);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return -1;
        }
        object2 = new ArrayList();
        try {
            ConfigReader configReader = new ConfigReader(this.getPropertyFileName());
            object = this.getProperty(this.getPropertyFileName(), "emailForErrors");
            if (object != null) {
                this.emailForErrors = object;
            }
            int n = 1;
            do {
                if ((string = configReader.getNext("Plugins", n)) != null) {
                    try {
                        if (this.add_YP_Object((List<Thread>)object2, string) == 1) {
                            if (n == 1) {
                                this.logger(3, "Server is starting");
                            }
                            this.logger(4, "initialize() Plugin added :" + string);
                        } else {
                            this.logger(2, "initialize() Plugin not added :" + string);
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "initialize() " + string, exception);
                    }
                }
                n = 0;
            } while (string != null);
        }
        catch (Exception exception) {
            this.logger(2, "initialize() ", exception);
        }
        int n = 1;
        while (n < this.getChildNB()) {
            object = this.getChildByRank(n);
            if (object != null) {
                ((YP_Object)object).setObjectStatus(1);
                if (YP_Service.class.isInstance(object)) {
                    ((YP_Object)object).initialize();
                } else if (!YP_Transaction.class.isInstance(object)) {
                    if (YP_GlobalComponent.class.isInstance(object)) {
                        ((YP_Object)object).initialize();
                    } else if (!YP_OnDemandComponent.class.isInstance(object)) {
                        this.logger(2, "initialize() unknown plugin type");
                    }
                }
            }
            ++n;
        }
        object = object2.iterator();
        while (object.hasNext()) {
            Thread thread = (Thread)object.next();
            thread.start();
        }
        if (UtilsYP.isMoroccoServer()) {
            this.sysLog(3, "Morocco Server is started");
        } else {
            this.logger(2, "Server is started");
        }
        return 1;
    }

    @Override
    public String toString() {
        return "GlobalProcessManager";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.34";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis() + 86400000L;
        Runtime runtime = Runtime.getRuntime();
        while (true) {
            try {
                while (true) {
                    this.iAmAlive();
                    UtilsYP.sleep(60000);
                    this.iAmAlive();
                    if (System.currentTimeMillis() >= l) {
                        this.clearCachedPlugin();
                        l = System.currentTimeMillis() + 86400000L;
                    }
                    this.checkServiceStatus();
                    String string = "run() freeMemory:" + runtime.freeMemory() + " Max memory:" + runtime.maxMemory() + " Total memory:" + runtime.totalMemory();
                    this.logger(4, string);
                    System.out.println(string);
                }
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
                continue;
            }
            break;
        }
    }

    void checkServiceStatus() {
        Object object;
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = true;
        int n = this.getChildNB();
        int n2 = 0;
        while (n2 < n) {
            YP_Object yP_Object = this.getChildByRank(n2);
            if (YP_Service.class.isInstance(yP_Object)) {
                object = (YP_Service)yP_Object;
                String string = ((YP_Object)object).getPreferredName();
                if (string == null || string.isEmpty()) {
                    string = ((YP_Object)object).getSimpleName();
                }
                stringBuilder.append(string);
                stringBuilder.append(':');
                if (!((YP_Process)object).is_YP_Thread_Alive()) {
                    stringBuilder.append("KO");
                    bl = false;
                } else {
                    stringBuilder.append("OK");
                }
                stringBuilder.append(" last TOP ");
                long l = (System.currentTimeMillis() - ((YP_Process)object).getWatchDogTimer()) / 1000L;
                stringBuilder.append(l);
                stringBuilder.append(" seconds ago");
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            ++n2;
        }
        if (bl) {
            this.nbErrorStatusLoop = 0;
        } else {
            YP_Process.getAllStackTraces(stringBuilder);
            this.logger(2, stringBuilder.toString());
            long l = System.currentTimeMillis();
            if (this.topForNewStatusMail > l) {
                return;
            }
            if (this.emailForErrors == null || this.emailForErrors.isEmpty()) {
                this.logger(3, "checkProcessStatus() no mail defined");
            } else {
                this.topForNewStatusMail = l + 300000L + (long)(this.nbErrorStatusLoop * 60 * 1000);
                ++this.nbErrorStatusLoop;
                try {
                    object = "Service not responding " + this.getSrv() + " " + UtilsYP.getInstanceNumber();
                    this.getPluginByName("Mailer").dealRequest(this, "sendMail", this.emailForErrors, object, stringBuilder.toString());
                }
                catch (Exception exception) {
                    this.logger(2, "checkServiceStatus()", exception);
                }
            }
        }
    }

    public int clearCachedPlugin() {
        try {
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object = this.getChildByRank(n2);
                if (yP_Object != null && yP_Object instanceof YP_Process) {
                    ((YP_Process)yP_Object).resetCachedPlugin();
                }
                ++n2;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(3, "clearCachedPlugin() :", exception);
            return -1;
        }
    }

    private Constructor<?> get_YP_Constructor(String string) throws Exception {
        String string2;
        int n;
        String string3 = null;
        int n2 = string.indexOf("#");
        if (n2 != -1) {
            string3 = string.substring(0, n2);
        }
        if ((n = (string2 = string.substring(n2 + 1)).indexOf(",")) != -1) {
            string2 = string2.substring(0, n);
        }
        if (string3 == null) {
            Class<?> clazz;
            try {
                clazz = Class.forName(string2);
            }
            catch (ClassNotFoundException classNotFoundException) {
                this.logger(2, "get_YP_Constructor() " + string + " not found ", classNotFoundException);
                return null;
            }
            return clazz.getConstructor(YP_Object.class, Object[].class);
        }
        URLClassLoader uRLClassLoader = null;
        try (ZipFile zipFile = null;){
            File file = new File(string3);
            zipFile = new JarFile(string3);
            URL uRL = file.toURI().toURL();
            uRLClassLoader = this.classLoaderList.get(string3);
            if (uRLClassLoader == null) {
                uRLClassLoader = new URLClassLoader(new URL[]{uRL});
                this.classLoaderList.put(string3, uRLClassLoader);
            }
            Enumeration<JarEntry> enumeration = ((JarFile)zipFile).entries();
            while (enumeration.hasMoreElements()) {
                String string4 = ((Object)enumeration.nextElement()).toString();
                if (string4.length() <= 6 || string4.substring(string4.length() - 6).compareTo(".class") != 0) continue;
                string4 = string4.substring(0, string4.length() - 6);
                if ((string4 = string4.replaceAll("/", ".")).compareTo(string2) != 0) continue;
                Class<?> clazz = Class.forName(string4, true, uRLClassLoader);
                Constructor<?> constructor = clazz.getConstructor(YP_Object.class, Object[].class);
                return constructor;
            }
        }
        return null;
    }

    public static void main(String[] stringArray) {
        int n = 0;
        while (n < stringArray.length) {
            if (stringArray[n].startsWith("-i")) {
                UtilsYP.setInstanceNumber(Integer.parseInt(stringArray[n].substring(2)));
            } else if (stringArray[n].startsWith("-p")) {
                UtilsYP.setPath(stringArray[n].substring(2));
            } else if (stringArray[n].startsWith("-r")) {
                UtilsYP.setInstanceRole(Integer.parseInt(stringArray[n].substring(2)));
            } else if (stringArray[n].startsWith("-s")) {
                UtilsYP.setSilenceMode(Integer.parseInt(stringArray[n].substring(2)));
            } else if (stringArray[n].startsWith("-triggerMode")) {
                UtilsYP.setTriggerMode(Integer.parseInt(stringArray[n].substring(12)));
            } else if (stringArray[n].startsWith("-tableStructureMode")) {
                UtilsYP.setTableStructureMode(Integer.parseInt(stringArray[n].substring(19)));
            } else if (stringArray[n].startsWith("-t")) {
                UtilsYP.setTableCreationMode(Integer.parseInt(stringArray[n].substring(2)));
            } else if (stringArray[n].startsWith("-wd")) {
                UtilsYP.setWorkingDirectory(stringArray[n].substring(3));
            } else {
                System.out.println("Unknown param :" + stringArray[n]);
            }
            ++n;
        }
        if (UtilsYP.getInstanceNumber() <= 0) {
            System.out.println("Bad value for instance number");
            return;
        }
        if (UtilsYP.getInstanceRole() != 1 && UtilsYP.getInstanceRole() != 2 && UtilsYP.getInstanceRole() != 3) {
            System.out.println("Bad value for role");
            return;
        }
        YP_TS_GlobalProcessManager yP_TS_GlobalProcessManager = YP_TS_GlobalProcessManager.getInstance();
        yP_TS_GlobalProcessManager.setPropertyFileName(String.valueOf(UtilsYP.getPath()) + "/technics/properties/supervisor.properties");
        if (yP_TS_GlobalProcessManager.initialize() == 1) {
            yP_TS_GlobalProcessManager.run();
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        try {
            if (string.contentEquals("reInitialize") && (objectArray[0] instanceof String || objectArray[1] instanceof String)) {
                return this.reInitialize((String)objectArray[0], (String)objectArray[1]);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :", exception);
            return null;
        }
    }

    private String getSrv() {
        try {
            String[] stringArray;
            String string = new File(".").getCanonicalPath();
            string = string.replace(File.separatorChar, '/');
            String[] stringArray2 = stringArray = string.split("/");
            int n = stringArray.length;
            int n2 = 0;
            while (n2 < n) {
                String string2 = stringArray2[n2];
                if (string2.indexOf("_M_") > 0 || string2.indexOf("_S_") > 0 || string2.indexOf("_T_") > 0) {
                    return string2;
                }
                ++n2;
            }
            return stringArray[stringArray.length - 1];
        }
        catch (Exception exception) {
            this.logger(2, "getSrv() ", exception);
            return "";
        }
    }

    private static class ClassPathHacker {
        private static final Class<?>[] parameters = new Class[]{URL.class};

        private ClassPathHacker() {
        }

        private static void addFile(String string) throws IOException {
            File file = new File(string);
            ClassPathHacker.addFile(file);
        }

        private static void addFile(File file) throws IOException {
            ClassPathHacker.addURL(file.toURL());
        }

        private static void addURL(URL uRL) throws IOException {
            URLClassLoader uRLClassLoader = (URLClassLoader)ClassLoader.getSystemClassLoader();
            Class<URLClassLoader> clazz = URLClassLoader.class;
            try {
                Method method = clazz.getDeclaredMethod("addURL", parameters);
                method.setAccessible(true);
                method.invoke(uRLClassLoader, uRL);
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
                throw new IOException("Error, could not add URL to system classloader");
            }
        }
    }

    static class MiscUtils {
        private MiscUtils() {
        }

        public static String getMotherboardSN() {
            StringBuilder stringBuilder = new StringBuilder();
            try {
                String string;
                Process process = Runtime.getRuntime().exec("wmic baseboard get SerialNumber");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                while ((string = bufferedReader.readLine()) != null) {
                    stringBuilder.append(string);
                }
                bufferedReader.close();
                String string2 = stringBuilder.toString();
                string2 = string2.replace("SerialNumber", "");
                return string2.trim();
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return null;
            }
        }
    }
}

