/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.x25.YP_TCD_DCC_X25_Extension;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.services.YP_Connection;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public class YP_TS_ConnectionManager
extends YP_Service {
    private final Map<Long, YP_PHYS_Interface> socketFactoryList = new HashMap<Long, YP_PHYS_Interface>();
    private final ReentrantLock mutexSocketFactoryList = new ReentrantLock();
    private final List<YP_Connection> connectionList = new ArrayList<YP_Connection>();
    private YP_TCD_DCC_X25_Extension x25Extension;
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    private YP_TCD_DCC_Status dataContainerStatus = null;

    public YP_TS_ConnectionManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        int n = 0;
        while (n < this.getMaxChild()) {
            this.connectionList.add(null);
            ++n;
        }
        if (this.dataContainerTechnique == null) {
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
        this.x25Extension = (YP_TCD_DCC_X25_Extension)this.dataContainerTechnique.newPluginByName("DataContainerExtensionX25", new Object[0]);
        this.x25Extension.initialize();
        this.dataContainerTechnique.connection.registerWatcher(this.getProcessID());
        return 1;
    }

    @Override
    public String toString() {
        return "ConnectionManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private int releaseConnection(YP_PHYS_Interface yP_PHYS_Interface) {
        int n = 0;
        while (n < this.getMaxChild()) {
            YP_Connection yP_Connection = this.connectionList.get(n);
            if (yP_Connection != null && yP_Connection.plugin == yP_PHYS_Interface) {
                yP_Connection.status = 0;
                return 1;
            }
            ++n;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "releaseConnection() Connection not found !!!");
        }
        return 0;
    }

    private int closeConnection(YP_PHYS_Interface yP_PHYS_Interface) {
        int n = 0;
        while (n < this.getMaxChild()) {
            YP_Connection yP_Connection = this.connectionList.get(n);
            if (yP_Connection != null && yP_Connection.plugin == yP_PHYS_Interface) {
                return this.closeConnection(yP_Connection);
            }
            ++n;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "closeConnection()  Connection not found !!!");
        }
        return 0;
    }

    private int closeConnection(YP_Connection yP_Connection) {
        if (yP_Connection == null) {
            return -1;
        }
        if (yP_Connection.plugin != null) {
            yP_Connection.plugin.close();
        }
        yP_Connection.status = 0;
        return 1;
    }

    private int deleteConnection(YP_PHYS_Interface yP_PHYS_Interface) {
        int n = 0;
        while (n < this.getMaxChild()) {
            YP_Connection yP_Connection = this.connectionList.get(n);
            if (yP_Connection != null && yP_Connection.plugin == yP_PHYS_Interface) {
                yP_Connection.plugin.shutdown();
                yP_Connection.plugin = null;
                this.connectionList.set(n, null);
                return 1;
            }
            ++n;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "deleteConnection() Connection not found !!!");
        }
        return 0;
    }

    private YP_Row getConnectionRow(String string, String string2, long l) {
        YP_Row yP_Row = this.dataContainerTechnique.connection.getRowByPrimaryKey(l);
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getConnectionRow() Id not found :" + string + ":" + string2 + " index:" + l);
            }
            return null;
        }
        YP_Row yP_Row2 = (YP_Row)yP_Row.clone();
        ExtendedConnectionParameters extendedConnectionParameters = new ExtendedConnectionParameters();
        extendedConnectionParameters.x25Adress = string2.getBytes();
        yP_Row2.addRowExtension(extendedConnectionParameters);
        return yP_Row2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private YP_Row getConnectionRow(String string, String string2, String string3, String string4) {
        String string5;
        YP_Row yP_Row;
        String string6;
        if (this.dataContainerTechnique == null) {
            this.logger(2, "getConnectionRow() no DCC_Technique...");
            return null;
        }
        if (string == null) {
            this.logger(2, "getConnectionRow() bad parameters");
            return null;
        }
        if (string.contentEquals("UPDATER")) {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.connection);
            yP_ComplexGabarit.set("serviceRequested", YP_ComplexGabarit.OPERATOR.EQUAL, string);
            if (!string2.isEmpty()) {
                yP_ComplexGabarit.set("adresseIP", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
            }
            if (!string3.isEmpty()) {
                yP_ComplexGabarit.set("port", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
            }
            if ((list = this.dataContainerTechnique.connection.getSortedRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) {
                this.logger(3, "getConnectionRow() UPDATER Connection ROW not found");
                return null;
            }
            if (list.size() <= 1) return list.get(0);
            this.logger(3, "getConnectionRow() more than one connection found for :" + string2 + ":" + string3);
            return list.get(0);
        }
        if (string2 == null || string3 == null || string3.isEmpty()) {
            this.logger(2, "getConnectionRow() bad parameters:" + string2 + ":" + string3);
            return null;
        }
        if (string2.indexOf(46) == -1) {
            List<YP_Row> list;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.x25Extension.x25);
            if (!string.isEmpty()) {
                yP_ComplexGabarit.set("serviceRequested", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string);
            }
            yP_ComplexGabarit.set("adresseX25", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string3);
            yP_ComplexGabarit.set("ert", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string4);
            long l = this.getBrandID();
            if (l > 0L) {
                yP_ComplexGabarit.set("idBrand", YP_ComplexGabarit.OPERATOR.IN, 0L, l);
            }
            List<Long> list2 = null;
            if (l > 0L) {
                list2 = this.dataContainerTechnique.getGroupIDs(l);
                if (list2 != null && !list2.isEmpty()) {
                    list2.add(0L);
                    yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.IN, (Object)list2);
                } else {
                    yP_ComplexGabarit.set("idGroup", YP_ComplexGabarit.OPERATOR.EQUAL, 0);
                }
            }
            if ((list = this.x25Extension.x25.getSortedRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) {
                this.logger(2, "getConnectionRow() Connection not found : " + string2 + ":" + string3 + ":" + string + ":" + string4);
                return null;
            }
            YP_Row yP_Row2 = list.get(0);
            if (list.size() > 1) {
                int n = 0;
                for (YP_Row yP_Row3 : list) {
                    long l2;
                    String string7;
                    String string8;
                    int n2 = 0;
                    if (!string.isEmpty() && (string8 = yP_Row3.getFieldStringValueByName("serviceRequested")).contentEquals(string)) {
                        ++n2;
                    }
                    if ((string8 = yP_Row3.getFieldStringValueByName("ert")).contentEquals(string4)) {
                        n2 += 2;
                    }
                    if ((string7 = yP_Row3.getFieldStringValueByName("adresseX25")).contentEquals(string3)) {
                        n2 += 4;
                    }
                    if (list2 != null && !list2.isEmpty() && (l2 = ((Long)yP_Row3.getFieldValueByName("idGroup")).longValue()) > 0L && list2.contains(l2)) {
                        n2 += 8;
                    }
                    if (l > 0L && (l2 = ((Long)yP_Row3.getFieldValueByName("idBrand")).longValue()) == l) {
                        n2 += 16;
                    }
                    if (n2 > n) {
                        n = n2;
                        yP_Row2 = yP_Row3;
                        continue;
                    }
                    if (n2 != n) continue;
                    this.logger(3, "getConnectionRow() two rows with same priorities : " + n2 + ":" + string2 + ":" + string3 + ":" + string + ":" + string4 + ":" + l);
                }
            }
            long l3 = (Long)yP_Row2.getFieldValueByName("idConnection");
            return this.getConnectionRow(string2, string3, l3);
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.connection);
        if (!string.isEmpty()) {
            yP_ComplexGabarit.set("serviceRequested", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string);
        }
        yP_ComplexGabarit.set("adresseIP", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("port", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        yP_ComplexGabarit.set("ert", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string4);
        List<YP_Row> list = this.dataContainerTechnique.connection.getSortedRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            this.logger(2, "getConnectionRow() Connection not found  :" + string2 + ":" + string3 + ":" + string + ":" + string4);
            return null;
        }
        if (list.size() > 1) {
            this.logger(3, "getConnectionRow() more than one connection found for :" + string2 + ":" + string3);
        }
        if ((string6 = (yP_Row = list.get(0)).getFieldStringValueByName("pluginName")) == null || !string6.isEmpty() || (string5 = yP_Row.getFieldStringValueByName("ressource")) == null || string5.isEmpty()) return yP_Row;
        if (UtilsYP.isNumeric(string5)) {
            this.logger(4, "getConnectionRow() " + string2 + ":" + string3 + " will be redirected to " + string5);
            if (!string3.contentEquals(string5)) return this.getConnectionRow(string, "", string5, string4);
            this.logger(2, "getConnectionRow() stopped to avoid endless loop");
            return yP_Row;
        } else if (string5.contains(":")) {
            String[] stringArray = string5.split(":");
            if (stringArray == null || stringArray.length != 2) {
                this.logger(2, "getConnectionRow() no plugin but bad ressource for " + string2 + ":" + string3 + "|" + string5);
                return yP_Row;
            } else {
                this.logger(4, "getConnectionRow() " + string2 + ":" + string3 + " will be redirected to " + stringArray[0] + ":" + stringArray[1]);
                if (!string2.contentEquals(stringArray[0]) || !string3.contentEquals(stringArray[1])) return this.getConnectionRow(string, stringArray[0], stringArray[1], string4);
                this.logger(2, "getConnectionRow() stopped to avoid endless loop");
            }
            return yP_Row;
        } else {
            this.logger(2, "getConnectionRow() no plugin but unknown type of ressource for " + string2 + ":" + string3 + "|" + string5);
        }
        return yP_Row;
    }

    private long getBrandID() {
        try {
            YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", yP_Process.getContractIdentifier());
            return yP_TCD_DCC_Brand.getIDBrand();
        }
        catch (Exception exception) {
            this.logger(2, "getBrandID() " + exception);
            return -1L;
        }
    }

    private YP_Row getConnectionRow(String string, String string2, String string3, int n, String string4, String string5) {
        List<YP_Row> list;
        YP_ComplexGabarit yP_ComplexGabarit;
        block35: {
            if (this.dataContainerTechnique == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getConnectionRow() no DCC_Technique....");
                }
                return null;
            }
            if (string == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getConnectionRow() bad parameters");
                }
                return null;
            }
            if (string4 == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getConnectionRow() bad parameters:" + string3 + ":" + n);
                }
                return null;
            }
            yP_ComplexGabarit = new YP_ComplexGabarit(this.dataContainerTechnique.connection);
            if (!string.isEmpty()) {
                yP_ComplexGabarit.set("serviceRequested", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string);
            }
            yP_ComplexGabarit.set("adresseIP", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
            if (n != -1) {
                yP_ComplexGabarit.set("port", YP_ComplexGabarit.OPERATOR.EQUAL, n);
            }
            if (string2 == null) break block35;
            switch (string2) {
                case "http": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "HTTPConnectionHandler");
                    break;
                }
                case "https": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "HTTPSConnectionHandler");
                    break;
                }
                case "ip": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "NetConnectionHandler");
                    break;
                }
                case "ssl": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "SSLConnectionHandler");
                    break;
                }
                case "ftps": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "FTPSConnectionHandler");
                    break;
                }
                case "sftp": {
                    yP_ComplexGabarit.set("pluginName", YP_ComplexGabarit.OPERATOR.EQUAL, "SFTPConnectionHandler");
                    break;
                }
            }
        }
        if (string4 != null && !string4.isEmpty()) {
            yP_ComplexGabarit.set("ressource", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
        }
        if (string5 != null && !string5.isEmpty()) {
            yP_ComplexGabarit.set("ert", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string5);
        }
        if ((list = this.dataContainerTechnique.connection.getSortedRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getConnectionRow() Connection not found :" + string3 + ":" + n);
            }
            return null;
        }
        if (list.size() > 1 && this.getLogLevel() >= 3) {
            this.logger(3, "getConnectionRow() more than one connection found for :" + string4 + ":" + n);
        }
        return list.get(0);
    }

    private YP_PHYS_Interface openConnection(YP_Row yP_Row) {
        YP_Connection yP_Connection = null;
        YP_PHYS_Interface yP_PHYS_Interface = null;
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "openConnection() no connectionRow...");
            }
            return null;
        }
        long l = yP_Row.getPrimaryKey();
        String string = yP_Row.getFieldStringValueByName("adresseIP");
        String string2 = yP_Row.getFieldStringValueByName("port");
        try {
            this.lock();
            int n = 0;
            while (n < this.getMaxChild()) {
                yP_Connection = this.connectionList.get(n);
                if (yP_Connection != null && yP_Connection.getStatus() == 0 && yP_Connection.getIDConnection() == l) {
                    if (yP_Connection.plugin != null) {
                        yP_Connection.setStatus(1);
                        yP_Connection.setTimestamp(System.currentTimeMillis());
                        break;
                    }
                    this.connectionList.set(n, null);
                }
                ++n;
            }
        }
        finally {
            this.unlock();
        }
        if (yP_Connection == null) {
            int n;
            String string3 = yP_Row.getFieldStringValueByName("pluginName");
            yP_PHYS_Interface = (YP_PHYS_Interface)((Object)this.newPluginByName(string3, new Object[0]));
            if (yP_PHYS_Interface == null) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "openConnection() unable to create plugin " + string3);
                }
                return null;
            }
            this.addChild((YP_Object)((Object)yP_PHYS_Interface));
            try {
                this.lock();
                n = 0;
                while (n < this.getMaxChild()) {
                    if (this.connectionList.get(n) == null) {
                        yP_Connection = new YP_Connection(yP_PHYS_Interface, l, 1);
                        this.connectionList.set(n, yP_Connection);
                        break;
                    }
                    ++n;
                }
            }
            finally {
                this.unlock();
            }
            if (yP_Connection == null) {
                try {
                    try {
                        this.lock();
                        n = 0;
                        while (n < this.getMaxChild()) {
                            YP_Connection yP_Connection2 = this.connectionList.get(n);
                            if (yP_Connection2 != null && yP_Connection2.getStatus() == 0) {
                                if (yP_Connection2.plugin != null) {
                                    yP_Connection2.plugin.shutdown();
                                    yP_Connection2.plugin = null;
                                }
                                yP_Connection = new YP_Connection(yP_PHYS_Interface, l, 1);
                                this.connectionList.set(n, yP_Connection);
                                break;
                            }
                            ++n;
                        }
                    }
                    catch (Exception exception) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "openConnection() " + exception);
                        }
                        this.unlock();
                        return null;
                    }
                }
                finally {
                    this.unlock();
                }
            }
        }
        if (yP_Connection == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "openConnection() no more connection !!!!");
            }
            if (yP_PHYS_Interface != null) {
                yP_PHYS_Interface.shutdown();
            }
            return null;
        }
        long l2 = System.currentTimeMillis();
        int n = yP_Connection.plugin.openClient(yP_Row);
        long l3 = System.currentTimeMillis() - l2;
        int n2 = n != 1 ? this.dataContainerStatus.updateConnectionStatus(false, yP_Row, l3) : this.dataContainerStatus.updateConnectionStatus(true, yP_Row, l3);
        if (n2 != 1 && this.getLogLevel() >= 2) {
            this.logger(2, "openConnection() unable to update status for: " + string + " " + string2);
        }
        if (n == 1) {
            return yP_Connection.plugin;
        }
        this.closeConnection(yP_Connection);
        if (this.getLogLevel() >= 2) {
            this.logger(2, "openConnection() impossible  to connect to server: " + string + " " + string2);
        }
        return null;
    }

    private Object openHandle(String string, String string2, String string3) {
        YP_PHYS_Interface yP_PHYS_Interface;
        YP_Row yP_Row = this.getConnectionRow(string, string2, string3, "");
        if (yP_Row == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "openHandle() unable to find connection row");
            }
            return null;
        }
        long l = yP_Row.getPrimaryKey();
        this.reloadSocketFactoryListIfNeeded();
        this.mutexSocketFactoryList.lock();
        try {
            yP_PHYS_Interface = this.socketFactoryList.get(l);
            if (yP_PHYS_Interface == null) {
                this.reloadSocketFactoryList();
                yP_PHYS_Interface = this.socketFactoryList.get(l);
            }
        }
        finally {
            this.mutexSocketFactoryList.unlock();
        }
        if (yP_PHYS_Interface == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "openHandle() unable to find physical Interface");
            }
            return null;
        }
        long l2 = System.currentTimeMillis();
        Socket socket = yP_PHYS_Interface.createSocket(yP_Row);
        long l3 = System.currentTimeMillis() - l2;
        int n = socket == null ? this.dataContainerStatus.updateConnectionStatus(false, yP_Row, l3) : this.dataContainerStatus.updateConnectionStatus(true, yP_Row, l3);
        if (n != 1 && this.getLogLevel() >= 2) {
            this.logger(2, "openHandle() unable to update status for: " + string2 + " " + string3);
        }
        if (socket != null) {
            return socket;
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "openHandle() impossible  to connect to server: " + string2 + " " + string3);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (this.dataContainerTechnique == null) {
                this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
            }
            if (this.dataContainerStatus == null) {
                this.dataContainerStatus = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
            }
            if (string.contentEquals("releaseConnection")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_PHYS_Interface) {
                    return this.releaseConnection((YP_PHYS_Interface)objectArray[0]);
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for releaseConnection");
                }
                return null;
            }
            if (string.contentEquals("closeConnection")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_PHYS_Interface) {
                    return this.closeConnection((YP_PHYS_Interface)objectArray[0]);
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for closeConnection");
                }
                return null;
            }
            if (string.contentEquals("deleteConnection")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_PHYS_Interface) {
                    return this.deleteConnection((YP_PHYS_Interface)objectArray[0]);
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for deleteConnection");
                }
                return null;
            }
            if (string.contentEquals("getConnectionRow")) {
                if (objectArray == null || objectArray.length != 4 && objectArray.length != 6) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getConnectionRow");
                    }
                    return null;
                }
                if (objectArray.length == 4) {
                    if (objectArray[0] instanceof String && objectArray[1] instanceof String && objectArray[2] instanceof String && objectArray[3] instanceof String) {
                        return this.getConnectionRow((String)objectArray[0], (String)objectArray[1], (String)objectArray[2], (String)objectArray[3]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for getConnectionRow");
                    }
                    return null;
                }
                if (objectArray.length == 6) {
                    if (!(objectArray[0] instanceof String) || objectArray[1] != null && !(objectArray[1] instanceof String) || objectArray[2] != null && !(objectArray[2] instanceof String) || objectArray[3] != null && !(objectArray[3] instanceof Integer) || objectArray[4] != null && !(objectArray[4] instanceof String) || objectArray[5] != null && !(objectArray[5] instanceof String)) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameter for getConnectionRow");
                        }
                        return null;
                    }
                    return this.getConnectionRow((String)objectArray[0], (String)objectArray[1], (String)objectArray[2], (Integer)objectArray[3], (String)objectArray[4], (String)objectArray[5]);
                }
            }
            if (string.contentEquals("openConnection")) {
                if (objectArray == null || objectArray.length != 1) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for openConnection");
                    }
                    return null;
                }
                if (objectArray[0] instanceof YP_Row) {
                    return this.openConnection((YP_Row)objectArray[0]);
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for openConnection");
                }
                return null;
            }
            if (string.contentEquals("openHandle")) {
                if (objectArray == null || objectArray.length != 2) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for openHandle");
                    }
                    return null;
                }
                if (!(objectArray[0] instanceof String)) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter for openHandle");
                    }
                    return null;
                }
                if (objectArray[1] instanceof Integer) {
                    return this.openHandle("", (String)objectArray[0], Integer.toString((Integer)objectArray[1]));
                }
                if (objectArray[1] instanceof Long) {
                    return this.openHandle("", (String)objectArray[0], Long.toString((Long)objectArray[1]));
                }
                if (objectArray[1] instanceof String) {
                    return this.openHandle("", (String)objectArray[0], (String)objectArray[1]);
                }
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "dealRequest() bad parameter for openHandle");
                }
                return null;
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest() request unknown " + string);
            }
            return null;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest()  bad request ??? :" + exception);
            }
            return null;
        }
    }

    @Override
    public void run() {
        if (this.dataContainerTechnique == null) {
            this.dataContainerTechnique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        }
        if (this.dataContainerTechnique == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "run() no DCC_Technique...");
            }
            this.shutdown();
            return;
        }
        if (this.dataContainerStatus == null) {
            this.dataContainerStatus = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
        }
        if (this.dataContainerStatus == null) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "run() no DCC_Status...");
            }
            this.shutdown();
            return;
        }
        do {
            try {
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    private int reloadSocketFactoryListIfNeeded() {
        int n = this.getNotification();
        if (n <= 0) {
            return 0;
        }
        if (this.socketFactoryList.isEmpty()) {
            return this.reloadSocketFactoryList();
        }
        return this.reloadSocketFactoryList();
    }

    private int reloadSocketFactoryList() {
        this.mutexSocketFactoryList.lock();
        try {
            for (Map.Entry<Long, YP_PHYS_Interface> object : this.socketFactoryList.entrySet()) {
                object.getValue().shutdown();
            }
            this.socketFactoryList.clear();
            for (YP_Row yP_Row : this.dataContainerTechnique.connection) {
                String string = yP_Row.getFieldStringValueByName("pluginName");
                if (string == null || string.isEmpty()) continue;
                YP_PHYS_Interface yP_PHYS_Interface = (YP_PHYS_Interface)((Object)this.newPluginByName(string, new Object[0]));
                this.addChild((YP_Object)((Object)yP_PHYS_Interface));
                this.socketFactoryList.put(yP_Row.getPrimaryKey(), yP_PHYS_Interface);
            }
        }
        finally {
            this.mutexSocketFactoryList.unlock();
        }
        return 1;
    }

    @Override
    public int shutdown() {
        try {
            super.shutdown();
            this.socketFactoryList.clear();
            this.connectionList.clear();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "shutdown() " + exception);
            }
            return -1;
        }
    }

    public class ExtendedConnectionParameters {
        public byte[] x25Adress = new byte[64];
    }
}

