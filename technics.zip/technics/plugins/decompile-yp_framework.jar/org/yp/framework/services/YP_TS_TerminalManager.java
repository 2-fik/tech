/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.utils.UtilsYP;

public class YP_TS_TerminalManager
extends YP_Service {
    public YP_TS_TerminalManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "TerminalManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis() + 0x6DDD00L;
        do {
            try {
                if (System.currentTimeMillis() >= l) {
                    this.logger(4, "run() countTerminals to start");
                    this.countTerminals();
                    this.logger(4, "run() countTerminals ended");
                    l = System.currentTimeMillis() + 86400000L;
                }
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    public void archiveTerminals() {
        try {
            List list = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrandList", new Object[0]);
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
                yP_TCD_DCC_Brand.archiveTerminal();
            }
        }
        catch (Exception exception) {
            this.logger(2, "archiveTerminals() ", exception);
            return;
        }
    }

    public void countTerminals() {
        try {
            List list = (List)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrandList", new Object[0]);
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : list) {
                yP_TCD_DCC_Brand.countTerminals();
            }
        }
        catch (Exception exception) {
            this.logger(2, "countTerminals() ", exception);
            return;
        }
    }
}

