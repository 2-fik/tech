/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.sql.Connection;

final class YP_JDBC_Connection {
    protected Connection connection;
    protected ConnectionStatus status;
    protected int idSite;
    protected byte[] user;
    protected int connectorType;
    protected long lastTop;

    YP_JDBC_Connection(Connection connection, ConnectionStatus connectionStatus, int n, byte[] byArray, int n2) {
        this.setConnection(connection);
        this.status = connectionStatus;
        this.idSite = n;
        this.connectorType = n2;
        this.setUser(byArray);
        this.lastTop = System.currentTimeMillis();
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public void setIdSite(int n) {
        this.idSite = n;
    }

    public void setConnectorType(int n) {
        this.connectorType = n;
    }

    public void setUser(byte[] byArray) {
        this.user = byArray;
    }

    static enum ConnectionStatus {
        Inactive,
        Active;

    }
}

