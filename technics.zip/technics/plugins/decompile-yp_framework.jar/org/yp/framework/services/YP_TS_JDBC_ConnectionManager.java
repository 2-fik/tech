/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.services.ConnectionWithTimeout;
import org.yp.framework.services.YP_JDBC_Connection;
import org.yp.utils.UtilsYP;

public class YP_TS_JDBC_ConnectionManager
extends YP_Service {
    private YP_JDBC_Connection[] connectionArray = null;
    private final ReentrantLock mutexConnectionArray = new ReentrantLock();
    private static final int DEFAULT_CONNECTION_TIMEOUT_MS = 8000;
    private int connectionTimeoutMs = 8000;
    private static final long DEFAULT_INACTIVITY_TIMEOUT_MS = 3600000L;
    private long inactivityTimeoutMs = 3600000L;
    private int connectionArrayMaxIndice = -1;
    private int connectionArrayLastFound = 0;

    public YP_TS_JDBC_ConnectionManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "connectionTimeout");
        if (string != null) {
            this.connectionTimeoutMs = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "connectionTimeoutMs")) != null) {
            this.connectionTimeoutMs = Integer.parseInt(string);
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "inactivityTimeoutMs")) != null) {
            this.inactivityTimeoutMs = Long.parseLong(string);
        }
        this.connectionArray = new YP_JDBC_Connection[this.getMaxChild()];
        return 1;
    }

    @Override
    public String toString() {
        return "JDBC_ConnectionManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private int releaseConnection(Connection connection) {
        int n = 0;
        while (n < this.connectionArray.length) {
            YP_JDBC_Connection yP_JDBC_Connection = this.connectionArray[n];
            if (yP_JDBC_Connection != null && yP_JDBC_Connection.connection == connection) {
                yP_JDBC_Connection.status = YP_JDBC_Connection.ConnectionStatus.Inactive;
                return 1;
            }
            ++n;
        }
        this.logger(2, "releaseConnection() Connection not found !!!");
        return 0;
    }

    private int closeConnection(Connection connection) {
        int n = 0;
        while (n < this.connectionArray.length) {
            YP_JDBC_Connection yP_JDBC_Connection = this.connectionArray[n];
            if (yP_JDBC_Connection != null && yP_JDBC_Connection.connection == connection) {
                try {
                    yP_JDBC_Connection.connection.close();
                    yP_JDBC_Connection.connection = null;
                }
                catch (SQLException sQLException) {
                    this.logger(2, "closeConnection() " + sQLException);
                }
                this.connectionArray[n] = null;
                return 1;
            }
            ++n;
        }
        this.logger(2, "closeConnection() Connection not found !!!");
        return 0;
    }

    private Connection findConnection(int n, byte[] byArray, int n2) {
        Connection connection;
        YP_JDBC_Connection yP_JDBC_Connection;
        int n3 = this.connectionArrayLastFound;
        while (n3 <= this.connectionArrayMaxIndice) {
            yP_JDBC_Connection = this.connectionArray[n3];
            if (yP_JDBC_Connection != null && yP_JDBC_Connection.status == YP_JDBC_Connection.ConnectionStatus.Inactive && yP_JDBC_Connection.idSite == n && UtilsYP.strcmp(byArray, yP_JDBC_Connection.user) == 0 && yP_JDBC_Connection.connectorType == n2) {
                connection = yP_JDBC_Connection.connection;
                if (connection == null) {
                    this.connectionArray[n3] = null;
                } else {
                    yP_JDBC_Connection.status = YP_JDBC_Connection.ConnectionStatus.Active;
                    this.connectionArrayLastFound = n3;
                    yP_JDBC_Connection.lastTop = System.currentTimeMillis();
                    return connection;
                }
            }
            ++n3;
        }
        n3 = 0;
        while (n3 < this.connectionArrayLastFound) {
            yP_JDBC_Connection = this.connectionArray[n3];
            if (yP_JDBC_Connection != null && yP_JDBC_Connection.status == YP_JDBC_Connection.ConnectionStatus.Inactive && yP_JDBC_Connection.idSite == n && UtilsYP.strcmp(byArray, yP_JDBC_Connection.user) == 0 && yP_JDBC_Connection.connectorType == n2) {
                connection = yP_JDBC_Connection.connection;
                if (connection == null) {
                    this.connectionArray[n3] = null;
                } else {
                    yP_JDBC_Connection.status = YP_JDBC_Connection.ConnectionStatus.Active;
                    this.connectionArrayLastFound = n3;
                    yP_JDBC_Connection.lastTop = System.currentTimeMillis();
                    return connection;
                }
            }
            ++n3;
        }
        return null;
    }

    private Connection createConnectionAt(int n, YP_JDBC_Connection yP_JDBC_Connection, YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) throws Exception {
        Connection connection = null;
        try {
            connection = ConnectionWithTimeout.openConnection(yP_TCD_DataBaseConnector, this.connectionTimeoutMs);
        }
        catch (Exception exception) {
            this.sysLog(2, "createConnectionAt() " + yP_TCD_DataBaseConnector.getDBC_Path() + " " + exception);
            this.connectionArray[n] = null;
            throw exception;
        }
        if (connection == null) {
            this.connectionArray[n] = null;
            return null;
        }
        yP_JDBC_Connection.setConnection(connection);
        return connection;
    }

    private Connection getConnection(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) throws Exception {
        int n = yP_TCD_DataBaseConnector.getSiteIdentifier();
        byte[] byArray = yP_TCD_DataBaseConnector.getDBC_UserArray();
        int n2 = yP_TCD_DataBaseConnector.getConnectorType();
        while (true) {
            Object object;
            try {
                this.mutexConnectionArray.lock();
                object = this.findConnection(n, byArray, n2);
                if (object != null) {
                    Connection connection = object;
                    return connection;
                }
            }
            finally {
                this.mutexConnectionArray.unlock();
            }
            object = new YP_JDBC_Connection(null, YP_JDBC_Connection.ConnectionStatus.Active, n, byArray, n2);
            int n3 = -1;
            try {
                this.mutexConnectionArray.lock();
                int n4 = 0;
                while (n4 < this.connectionArray.length) {
                    if (this.connectionArray[n4] == null) {
                        this.connectionArray[n4] = object;
                        n3 = n4;
                        if (n3 > this.connectionArrayMaxIndice) {
                            this.connectionArrayMaxIndice = n3;
                        }
                        break;
                    }
                    ++n4;
                }
            }
            finally {
                this.mutexConnectionArray.unlock();
            }
            if (n3 == -1) {
                YP_JDBC_Connection yP_JDBC_Connection;
                block25: {
                    yP_JDBC_Connection = null;
                    try {
                        try {
                            this.mutexConnectionArray.lock();
                            int n5 = 0;
                            while (n5 < this.connectionArray.length) {
                                yP_JDBC_Connection = this.connectionArray[n5];
                                if (yP_JDBC_Connection != null && yP_JDBC_Connection.status == YP_JDBC_Connection.ConnectionStatus.Inactive) {
                                    this.connectionArray[n5] = object;
                                    n3 = n5;
                                    break;
                                }
                                ++n5;
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "getConnection() " + yP_TCD_DataBaseConnector.getDBC_Path() + " " + exception);
                            this.mutexConnectionArray.unlock();
                            break block25;
                        }
                    }
                    catch (Throwable throwable) {
                        this.mutexConnectionArray.unlock();
                        throw throwable;
                    }
                    this.mutexConnectionArray.unlock();
                }
                if (n3 != -1) {
                    try {
                        yP_JDBC_Connection.connection.close();
                    }
                    catch (Exception exception) {
                        this.logger(2, "getConnection() " + yP_TCD_DataBaseConnector.getDBC_Path() + " " + exception);
                    }
                }
            }
            if (n3 != -1) {
                return this.createConnectionAt(n3, (YP_JDBC_Connection)object, yP_TCD_DataBaseConnector);
            }
            this.logger(2, "getConnection() no more connection !!!!");
            UtilsYP.sleep(100);
        }
    }

    private int closeInactiveConnections() {
        try {
            int n = 0;
            long l = System.currentTimeMillis() - this.inactivityTimeoutMs;
            this.mutexConnectionArray.lock();
            int n2 = 0;
            while (n2 < this.connectionArray.length) {
                YP_JDBC_Connection yP_JDBC_Connection = this.connectionArray[n2];
                if (yP_JDBC_Connection != null && yP_JDBC_Connection.status == YP_JDBC_Connection.ConnectionStatus.Inactive && yP_JDBC_Connection.lastTop < l) {
                    this.logger(4, "closeInactiveConnections() Old connection need to be closed");
                    try {
                        if (yP_JDBC_Connection.connection != null) {
                            yP_JDBC_Connection.connection.close();
                            yP_JDBC_Connection.connection = null;
                        }
                    }
                    catch (SQLException sQLException) {
                        this.logger(2, "closeInactiveConnections() " + sQLException);
                    }
                    this.connectionArray[n2] = null;
                    ++n;
                }
                ++n2;
            }
            int n3 = n;
            return n3;
        }
        catch (Exception exception) {
            this.logger(2, "closeInactiveConnections() " + exception);
            return -1;
        }
        finally {
            this.mutexConnectionArray.unlock();
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        block11: {
            block12: {
                block9: {
                    block10: {
                        try {
                            if (!string.contentEquals("releaseConnection")) break block9;
                            if (objectArray != null && objectArray.length >= 1 && objectArray[0] instanceof Connection) break block10;
                            this.logger(2, "dealRequest() bad parameter for releaseConnection");
                            return null;
                        }
                        catch (Exception exception) {
                            this.logger(2, "dealRequest() releaseConnection :" + exception);
                            return null;
                        }
                    }
                    return this.releaseConnection((Connection)objectArray[0]);
                }
                if (string.contentEquals("getConnection")) {
                    return this.getConnection((YP_TCD_DataBaseConnector)yP_Object);
                }
                try {
                    if (!string.contentEquals("closeConnection")) break block11;
                    if (objectArray != null && objectArray.length >= 1 && objectArray[0] instanceof Connection) break block12;
                    this.logger(2, "dealRequest() bad parameter for closeConnection");
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "dealRequest() closeConnection :" + exception);
                    return null;
                }
            }
            return this.closeConnection((Connection)objectArray[0]);
        }
        this.logger(2, "dealRequest() request unknown " + string);
        return null;
    }

    @Override
    public void run() {
        do {
            try {
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
                this.closeInactiveConnections();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    @Override
    public final int getRunningChildNB() {
        try {
            int n = 0;
            int n2 = 0;
            while (n2 < this.connectionArray.length) {
                if (this.connectionArray[n2] != null) {
                    ++n;
                }
                ++n2;
            }
            return n;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getRunningChildNB() " + exception);
            }
            return -1;
        }
    }
}

