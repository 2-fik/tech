/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.utils.UtilsYP;

public class YP_TS_FileContentManager
extends YP_Service {
    private final int deleteIfOlderThanInMS = 86400000;
    private final Map<String, FileContent> fileContentMap = new HashMap<String, FileContent>();
    private final ReentrantLock fileContentListMutex = new ReentrantLock();

    @Override
    public String getFileContent(String string) {
        FileContent fileContent;
        this.fileContentListMutex.lock();
        try {
            try {
                fileContent = this.fileContentMap.get(string);
                if (fileContent == null) {
                    fileContent = new FileContent(string);
                }
            }
            catch (Exception exception) {
                this.logger(2, "getFileContent() " + exception);
                this.fileContentListMutex.unlock();
                return null;
            }
        }
        finally {
            this.fileContentListMutex.unlock();
        }
        fileContent.cptUse.incrementAndGet();
        fileContent.lastTop = System.currentTimeMillis();
        return fileContent.content;
    }

    public YP_TS_FileContentManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setMaxChild(0);
    }

    @Override
    public final String toString() {
        return "FileContentManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        do {
            try {
                block21: {
                    if (System.currentTimeMillis() >= l) {
                        block19: {
                            if (this.getLogLevel() >= 4) {
                                this.logger(4, "run() It's time to clean some unused contents");
                            }
                            long l2 = System.currentTimeMillis() - 86400000L;
                            this.fileContentListMutex.lock();
                            try {
                                try {
                                    Iterator<FileContent> iterator = this.fileContentMap.values().iterator();
                                    while (iterator.hasNext()) {
                                        FileContent fileContent = iterator.next();
                                        if (fileContent.lastTop >= l2) continue;
                                        iterator.remove();
                                    }
                                }
                                catch (Exception exception) {
                                    this.logger(2, "run() " + exception);
                                    this.fileContentListMutex.unlock();
                                    break block19;
                                }
                            }
                            catch (Throwable throwable) {
                                this.fileContentListMutex.unlock();
                                throw throwable;
                            }
                            this.fileContentListMutex.unlock();
                        }
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "run() housekeep done");
                        }
                        l = System.currentTimeMillis() + 86400000L;
                    }
                    this.iAmAlive();
                    UtilsYP.sleep(10000);
                    this.iAmAlive();
                    this.fileContentListMutex.lock();
                    try {
                        try {
                            for (FileContent fileContent : this.fileContentMap.values()) {
                                try {
                                    fileContent.reloadIfNeeded();
                                }
                                catch (Exception exception) {
                                    this.logger(2, "run() " + exception);
                                }
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "run() " + exception);
                            this.fileContentListMutex.unlock();
                            break block21;
                        }
                    }
                    catch (Throwable throwable) {
                        this.fileContentListMutex.unlock();
                        throw throwable;
                    }
                    this.fileContentListMutex.unlock();
                }
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (!string.contentEquals("getFileContent")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                return this.getFileContent((String)objectArray[0]);
            }
            this.logger(2, "dealRequest() bad parameter for getFileContent");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + string + exception);
            return null;
        }
    }

    class FileContent {
        private File file;
        private String content;
        private final AtomicInteger cptUse = new AtomicInteger(0);
        private long lastTop = 0L;
        private long lastModified = 0L;

        public FileContent(String string) {
            try {
                this.file = new File(string);
                this.reloadIfNeeded();
                YP_TS_FileContentManager.this.fileContentMap.put(string, this);
            }
            catch (Exception exception) {
                YP_TS_FileContentManager.this.logger(2, "FileContent() " + exception);
                this.content = null;
            }
        }

        private void reloadIfNeeded() throws Exception {
            long l = this.lastModified;
            this.lastModified = this.file.lastModified();
            if (this.lastModified != l) {
                FileInputStream fileInputStream = new FileInputStream(this.file);
                byte[] byArray = new byte[fileInputStream.available()];
                fileInputStream.read(byArray);
                fileInputStream.close();
                this.content = new String(byArray);
            }
        }
    }
}

