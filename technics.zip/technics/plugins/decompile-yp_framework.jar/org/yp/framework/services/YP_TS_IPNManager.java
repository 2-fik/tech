/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.utils.UtilsYP;

public class YP_TS_IPNManager
extends YP_Service {
    private int frequencyInMS = 0;
    private long maxChildAllowedTimeInMS = 0L;

    public YP_TS_IPNManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "frequencyInMS");
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() mandatory parameter frequencyInMS missing");
            }
            return -1;
        }
        try {
            this.frequencyInMS = Integer.parseInt(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() bad parameter frequencyInMS " + string);
            }
            return -1;
        }
        string = this.getProperty(this.getPropertyFileName(), "maxChildAllowedTimeInMS");
        if (string == null || string.isEmpty()) {
            string = "10000";
            if (this.getLogLevel() >= 2) {
                this.logger(3, "initialize() mandatory parameter maxChildAllowedTimeInMS missing, use default: " + string);
            }
        }
        try {
            this.maxChildAllowedTimeInMS = Long.parseLong(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() bad parameter maxChildAllowedTimeInMS " + string);
            }
            return -1;
        }
        return 1;
    }

    @Override
    public String toString() {
        return "IPNManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        try {
            do {
                try {
                    if (System.currentTimeMillis() >= l) {
                        this.logger(4, "run()  It's time to do the task");
                        int n = this.getChildNB();
                        int n2 = 0;
                        while (n2 < n) {
                            YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)this.getChildByRank(n2);
                            if (yP_TCD_DCC_Business != null) {
                                this.iAmAlive();
                                yP_TCD_DCC_Business.dealRequest(this, "dealTransactionsUpload", this.maxChildAllowedTimeInMS);
                            }
                            ++n2;
                        }
                        l = System.currentTimeMillis() + (long)this.frequencyInMS;
                    }
                    this.iAmAlive();
                    UtilsYP.sleep(this.frequencyInMS);
                    this.iAmAlive();
                }
                catch (Exception exception) {
                    this.logger(2, "run()", exception);
                    UtilsYP.sleep(10000);
                }
            } while (this.getObjectStatus() == 1);
            this.logger(3, "run() Stopped...");
            this.shutdown();
        }
        catch (Exception exception) {
            this.logger(2, "run()", exception);
            return;
        }
    }

    private int registerIPN(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        int n = this.addChild(yP_TCD_DCC_Business);
        this.logger(4, "registerIPN() Add IPN: " + yP_TCD_DCC_Business.getContractIdentifier());
        return n;
    }

    private int unregisterIPN(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        this.logger(4, "unregisterIPN() Remove IPN: " + yP_TCD_DCC_Business.getContractIdentifier());
        return this.removeChildByID(yP_TCD_DCC_Business.getProcessID());
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "registerIPN": {
                    YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)yP_Object;
                    return this.registerIPN(yP_TCD_DCC_Business);
                }
                case "unregisterIPN": {
                    YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)yP_Object;
                    return this.unregisterIPN(yP_TCD_DCC_Business);
                }
                case "getDataContainerIpn": {
                    int n = this.getChildNB();
                    int n2 = 0;
                    while (n2 < n) {
                        YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)this.getChildByRank(n2);
                        if (yP_TCD_DCC_Business != null && (Long)yP_TCD_DCC_Business.getApplicationPlugin().getApplicationRow().getFieldValueByName("idApplication") == 118L) {
                            return yP_TCD_DCC_Business;
                        }
                        ++n2;
                    }
                    return null;
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :", exception);
            return null;
        }
        this.logger(2, "dealRequest() request unknown " + string);
        return null;
    }
}

