/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.globalcomponents.YP_TCG_XMLParser;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_CipherSym_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_DigestAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_MacAlgo_Interface;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_Module;
import org.yp.framework.ondemandcomponents.crypto.YP_TCD_CRYPTO_RandomNumberGenerator_Interface;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.extension.crypto.YP_TCD_DCC_Crypto_Extension;
import org.yp.framework.ondemandcomponents.datacontainers.extension.crypto.designaccesobjects.DAO_CryptoKey;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.KeyStatusEnumeration;
import org.yp.xml.jaxb.ypproperties.Properties;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_TS_CryptoManager
extends YP_Service {
    public static final int DATA_MODE = 1;
    public static final int TOKEN_MODE = 2;
    public static final int PIN_MODE = 3;
    private YP_TCD_DCC_Crypto_Extension extensionCrypto;
    private final Map<String, YP_TCD_CRYPTO_Module> cipherSymHashMap = new HashMap<String, YP_TCD_CRYPTO_Module>();
    private final List<YP_TCD_CRYPTO_Module> cipherSymList = new ArrayList<YP_TCD_CRYPTO_Module>();
    private final Map<String, List<YP_TCD_CRYPTO_Module>> fastCipherSymFinder = new HashMap<String, List<YP_TCD_CRYPTO_Module>>();
    private final List<YP_TCD_CRYPTO_DigestAlgo_Interface> digestList = new ArrayList<YP_TCD_CRYPTO_DigestAlgo_Interface>();
    private final List<YP_TCD_CRYPTO_RandomNumberGenerator_Interface> randomList = new ArrayList<YP_TCD_CRYPTO_RandomNumberGenerator_Interface>();
    private final Map<String, YP_TCD_CRYPTO_Module> macHashMap = new HashMap<String, YP_TCD_CRYPTO_Module>();
    private final Map<String, List<CryptoData>> fastMacFinder = new HashMap<String, List<CryptoData>>();
    private static final int MAX_CRYPTED_VALUE_IN_CACHE = 1000;
    private final Map<String, Object> cryptedValueCacheMap = new LinkedHashMap<String, Object>(){
        private static final long serialVersionUID = 4448979906417129996L;

        @Override
        protected boolean removeEldestEntry(Map.Entry entry) {
            return this.size() > 1000;
        }
    };
    public static final String DEFAULT_TOKEN_KEY = "K1";
    private String tokenKeyLabel = "K1";

    public YP_TS_CryptoManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "initialize() no DCC_Technique...");
            return -1;
        }
        this.extensionCrypto = (YP_TCD_DCC_Crypto_Extension)yP_TCD_DCC_Technique.newPluginByName("DataContainerExtensionCrypto", new Object[0]);
        this.extensionCrypto.initialize();
        this.refreshContext();
        this.extensionCrypto.cryptoKey.registerWatcher(this.getProcessID());
        this.extensionCrypto.cryptoModule.registerWatcher(this.getProcessID());
        return 1;
    }

    private int refreshContextIfNeeded() {
        int n = this.getNotification();
        if (n <= 0) {
            return 0;
        }
        return this.refreshContext();
    }

    private int refreshContext() {
        try {
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object = this.getChildByRank(n2);
                if (yP_Object != null) {
                    yP_Object.shutdown();
                }
                ++n2;
            }
        }
        catch (Exception exception) {
            this.logger(2, "refreshContext() ", exception);
        }
        String string = this.getProperty(this.getPropertyFileName(), "tokenKeyLabel");
        if (string != null && !string.isEmpty()) {
            this.tokenKeyLabel = string;
        }
        this.cipherSymHashMap.clear();
        this.cipherSymList.clear();
        this.fastCipherSymFinder.clear();
        this.digestList.clear();
        this.randomList.clear();
        this.macHashMap.clear();
        this.fastMacFinder.clear();
        Object object2 = this.extensionCrypto.cryptoKey.iterator();
        while (object2.hasNext()) {
            object2.next();
        }
        for (Object object2 : this.extensionCrypto.cryptoModule) {
            YP_TCD_CRYPTO_Module yP_TCD_CRYPTO_Module;
            int n = (Integer)((YP_Row)object2).getFieldValueByName("instanceNumber");
            if (n != 0 && n != UtilsYP.getInstanceNumber()) {
                this.logger(4, "initialize() crypto module ignored (not for this instance)");
                continue;
            }
            String string2 = ((YP_Row)object2).getFieldStringValueByName("cryptoModule_Plugin");
            if (string2 == null || string2.isEmpty()) {
                this.logger(2, "initialize() cant find valid crypto Module name:");
                continue;
            }
            YP_Object yP_Object = this.newPluginByName(string2, object2);
            if (yP_Object == null) {
                this.logger(2, "initialize() cant find crypto Module :" + string2);
                continue;
            }
            if (!(yP_Object instanceof YP_TCD_CRYPTO_Module)) {
                this.logger(2, "initialize() not a crypto Module :" + string2);
                continue;
            }
            int n3 = yP_Object.initialize();
            if (n3 <= 0) {
                this.logger(2, "initialize() failed to initialise " + yP_Object.toString());
                this.addChild(yP_Object, -1);
            } else {
                this.addChild(yP_Object, 1);
            }
            if (yP_Object instanceof YP_TCD_CRYPTO_CipherSym_Interface) {
                yP_TCD_CRYPTO_Module = this.cipherSymHashMap.put(((YP_TCD_CRYPTO_Module)yP_Object).getCryptoModuleName(), (YP_TCD_CRYPTO_Module)yP_Object);
                if (yP_TCD_CRYPTO_Module != null) {
                    this.logger(2, "initialize() Same name used two times :" + ((YP_TCD_CRYPTO_Module)yP_Object).getCryptoModuleName());
                } else {
                    this.cipherSymList.add((YP_TCD_CRYPTO_Module)yP_Object);
                }
            }
            if (yP_Object instanceof YP_TCD_CRYPTO_MacAlgo_Interface && (yP_TCD_CRYPTO_Module = this.macHashMap.put(((YP_TCD_CRYPTO_Module)yP_Object).getCryptoModuleName(), (YP_TCD_CRYPTO_Module)yP_Object)) != null) {
                this.logger(2, "initialize() Same name used two times :" + ((YP_TCD_CRYPTO_Module)yP_Object).getCryptoModuleName());
            }
            if (yP_Object instanceof YP_TCD_CRYPTO_DigestAlgo_Interface) {
                this.digestList.add((YP_TCD_CRYPTO_DigestAlgo_Interface)((Object)yP_Object));
            }
            if (!(yP_Object instanceof YP_TCD_CRYPTO_RandomNumberGenerator_Interface)) continue;
            this.randomList.add((YP_TCD_CRYPTO_RandomNumberGenerator_Interface)((Object)yP_Object));
        }
        return 1;
    }

    @Override
    public String toString() {
        return "CryptoManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private List<CryptoData> orderEligibleCrypto(Set<CryptoData> set) {
        ArrayList<CryptoData> arrayList = new ArrayList<CryptoData>();
        for (CryptoData cryptoData : set) {
            int n = cryptoData.cryptoModule.getPriority();
            int n2 = cryptoData.cryptoModule.getSecurityLevel();
            int n3 = 0;
            for (CryptoData cryptoData2 : arrayList) {
                int n4;
                int n5 = cryptoData2.cryptoModule.getPriority();
                if (n5 < n || n5 == n && (n4 = cryptoData2.cryptoModule.getSecurityLevel()) < n2) break;
                ++n3;
            }
            arrayList.add(n3, cryptoData);
        }
        return arrayList;
    }

    private List<CryptoData> getEligibleCrypto(String string, Map<String, List<CryptoData>> map, Map<String, YP_TCD_CRYPTO_Module> map2) throws Exception {
        List<CryptoData> list = map.get(string);
        if (list == null) {
            List<YP_Row> list2 = this.getCryptoKeyList(string);
            if (list2 == null || list2.isEmpty()) {
                if (string.length() == 20 && (list2 = this.getCryptoKeyList(DUKPT.getBDKAlias(string))) != null) {
                    list2.isEmpty();
                }
                if (list2 == null || list2.isEmpty()) {
                    this.logger(2, "getEligibleCrypto() key not found:" + string);
                    throw new Exception("getEligibleCrypto() key not found:" + string);
                }
            }
            HashSet<CryptoData> hashSet = new HashSet<CryptoData>();
            for (YP_Row yP_Row : list2) {
                String string2 = yP_Row.getFieldStringValueByName("idSM");
                YP_TCD_CRYPTO_Module yP_TCD_CRYPTO_Module = map2.get(string2);
                if (yP_TCD_CRYPTO_Module == null) {
                    this.logger(2, "getEligibleCrypto() plugin not found :" + string2);
                    continue;
                }
                String string3 = yP_Row.getFieldStringValueByName("algorithm");
                String string4 = yP_Row.getFieldStringValueByName("properties");
                String string5 = yP_Row.getFieldStringValueByName("idSM");
                CryptoData cryptoData = this.getCryptoData(yP_TCD_CRYPTO_Module, string, string3, string4, string5);
                hashSet.add(cryptoData);
            }
            list = this.orderEligibleCrypto(hashSet);
            map.put(string, list);
        }
        return list;
    }

    private Set<RandomData> getListOfRandom(String string, boolean bl) {
        HashSet<RandomData> hashSet = new HashSet<RandomData>();
        for (YP_TCD_CRYPTO_RandomNumberGenerator_Interface yP_TCD_CRYPTO_RandomNumberGenerator_Interface : this.randomList) {
            int n = yP_TCD_CRYPTO_RandomNumberGenerator_Interface.isRandomSupported(string);
            if (n <= 0) continue;
            RandomData randomData = new RandomData();
            randomData.randomAlgo = string;
            randomData.randomDataInterface = yP_TCD_CRYPTO_RandomNumberGenerator_Interface;
            randomData.securityLevel = ((YP_TCD_CRYPTO_Module)((Object)yP_TCD_CRYPTO_RandomNumberGenerator_Interface)).getSecurityLevel();
            randomData.efficiency = n;
            hashSet.add(randomData);
        }
        return hashSet;
    }

    private RandomData getEligibleRandom(Set<RandomData> set) {
        if (set == null || set.isEmpty()) {
            return null;
        }
        RandomData randomData = null;
        for (RandomData randomData2 : set) {
            if (randomData == null) {
                randomData = randomData2;
                continue;
            }
            if (randomData2.efficiency <= randomData.efficiency) continue;
            randomData = randomData2;
        }
        return randomData;
    }

    private byte[] getRandom(int n, String string, int n2) {
        boolean bl = true;
        boolean bl2 = true;
        do {
            RandomData randomData;
            if (bl) {
                bl = false;
            } else {
                bl2 = false;
            }
            Set<RandomData> set = this.getListOfRandom(string, bl2);
            int n3 = set.size();
            if (n3 <= 0) {
                this.logger(2, "getRandom() failed: no provider available for this operation ");
                return null;
            }
            do {
                if ((randomData = this.getEligibleRandom(set)) == null) continue;
                try {
                    return randomData.randomDataInterface.generateRandomBytes(n, string, null, n2);
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(((YP_Object)((Object)randomData.randomDataInterface)).getRankInFatherChildList(), 0);
                    this.logger(2, "getRandom()  ", exception);
                    boolean bl3 = set.remove(randomData);
                    if (bl3) continue;
                    this.logger(1, "getRandom()  Impossible to remove inactive digest let's stop");
                    return null;
                }
            } while (randomData != null);
        } while (bl2);
        this.logger(2, "getRandom() failed");
        return null;
    }

    private Set<DigestData> getListOfDigest(String string, boolean bl) {
        HashSet<DigestData> hashSet = new HashSet<DigestData>();
        for (YP_TCD_CRYPTO_DigestAlgo_Interface yP_TCD_CRYPTO_DigestAlgo_Interface : this.digestList) {
            int n = yP_TCD_CRYPTO_DigestAlgo_Interface.isDigestSupported(string);
            if (n <= 0) continue;
            DigestData digestData = new DigestData();
            digestData.digestAlgo = string;
            digestData.digestInterface = yP_TCD_CRYPTO_DigestAlgo_Interface;
            digestData.securityLevel = ((YP_TCD_CRYPTO_Module)((Object)yP_TCD_CRYPTO_DigestAlgo_Interface)).getSecurityLevel();
            digestData.efficiency = n;
            hashSet.add(digestData);
        }
        return hashSet;
    }

    private DigestData getEligibleDigest(Set<DigestData> set) {
        if (set == null || set.isEmpty()) {
            return null;
        }
        DigestData digestData = null;
        for (DigestData digestData2 : set) {
            if (digestData == null) {
                digestData = digestData2;
                continue;
            }
            if (digestData2.securityLevel <= digestData.securityLevel) continue;
            digestData = digestData2;
        }
        return digestData;
    }

    private String digestMessage(String string, Object object) {
        boolean bl = true;
        boolean bl2 = true;
        do {
            DigestData digestData;
            if (bl) {
                bl = false;
            } else {
                bl2 = false;
            }
            Set<DigestData> set = this.getListOfDigest(string, bl2);
            int n = set.size();
            if (n <= 0) {
                this.logger(2, "digestMessage() failed: no provider available for this operation ");
                return null;
            }
            do {
                if ((digestData = this.getEligibleDigest(set)) == null) continue;
                try {
                    String string2 = object instanceof byte[] ? digestData.digestInterface.digest(string, (byte[])object) : digestData.digestInterface.digest(string, (String)object);
                    if (string2 != null) {
                        return string2;
                    }
                    this.setChildStatusByRank(((YP_Object)((Object)digestData.digestInterface)).getRankInFatherChildList(), 0);
                    this.logger(3, "digestMessage() failed for " + digestData.digestInterface.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(((YP_Object)((Object)digestData.digestInterface)).getRankInFatherChildList(), 0);
                    this.logger(2, "digestMessage()  ", exception);
                }
                boolean bl3 = set.remove(digestData);
                if (bl3) continue;
                this.logger(1, "digestMessage()  Impossible to remove inactive digest let's stop");
                return null;
            } while (digestData != null);
        } while (bl2);
        this.logger(2, "digestMessage() failed");
        return null;
    }

    private boolean isRequestorAllowedToUseKey(YP_Row yP_Row) {
        String string = yP_Row.getFieldStringValueByName("ownerProcess");
        String string2 = String.valueOf(yP_Row.getFieldStringValueByName("ownerBrandName")) + yP_Row.getFieldStringValueByName("ownerMerchantId") + yP_Row.getFieldStringValueByName("ownerApplicationId");
        String string3 = yP_Row.getFieldStringValueByName("ownerPreferredName");
        YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
        String string4 = yP_Process.toString();
        String string5 = yP_Process.getContractIdentifier();
        String string6 = yP_Process.getPreferredName();
        if (!(string == null || string.isEmpty() || string.trim().isEmpty() || string.contains(string4))) {
            return false;
        }
        if (string3 != null && !string3.isEmpty() && !string3.trim().isEmpty()) {
            if (string6 == null || string6.isEmpty() || string6.trim().isEmpty()) {
                return false;
            }
            if (!string3.contains(string6)) {
                return false;
            }
        }
        if (string2 != null && !string2.isEmpty() && !string2.trim().contentEquals("00")) {
            if (string5 == null || string5.isEmpty() || string5.trim().isEmpty()) {
                return false;
            }
            if (!string2.contains(string5)) {
                return false;
            }
        }
        return true;
    }

    private boolean canCipher(YP_Row yP_Row) {
        KeyStatusEnumeration keyStatusEnumeration = (KeyStatusEnumeration)((Object)yP_Row.getFieldValueByName("keyStatus"));
        if (keyStatusEnumeration.compareTo(KeyStatusEnumeration.ACTIVE) != 0) {
            return false;
        }
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        Timestamp timestamp2 = (Timestamp)yP_Row.getFieldValueByName("effectiveDate");
        Timestamp timestamp3 = (Timestamp)yP_Row.getFieldValueByName("expirationDate");
        if (timestamp.before(timestamp2)) {
            this.logger(2, "key not yet valid");
            return false;
        }
        if (timestamp.after(timestamp3)) {
            this.logger(2, "key out of date");
            return false;
        }
        return true;
    }

    private boolean canUnCipher(YP_Row yP_Row) {
        KeyStatusEnumeration keyStatusEnumeration = (KeyStatusEnumeration)((Object)yP_Row.getFieldValueByName("keyStatus"));
        if (keyStatusEnumeration.compareTo(KeyStatusEnumeration.ACTIVE) != 0 && keyStatusEnumeration.compareTo(KeyStatusEnumeration.SUSPENDED) != 0) {
            return false;
        }
        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        Timestamp timestamp2 = (Timestamp)yP_Row.getFieldValueByName("effectiveDate");
        Timestamp timestamp3 = (Timestamp)yP_Row.getFieldValueByName("expirationDate");
        if (timestamp.before(timestamp2)) {
            this.logger(2, "key not yet valid");
            return false;
        }
        if (timestamp.after(timestamp3)) {
            this.logger(2, "key out of date");
            return false;
        }
        return true;
    }

    private List<YP_Row> getCryptoKeyList(String string) {
        YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
        String string2 = yP_Process.toString();
        String string3 = yP_Process.getPreferredName();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.extensionCrypto.cryptoKey);
        if (string != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("keyLabel", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        if (string2 != null && !string2.isEmpty() && !string2.trim().isEmpty()) {
            yP_ComplexGabarit.set("ownerProcess", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string2);
        }
        if (string3 != null && !string3.isEmpty() && !string3.trim().isEmpty()) {
            yP_ComplexGabarit.set("ownerPreferredName", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string3);
        }
        return this.extensionCrypto.cryptoKey.getRowListSuchAs(yP_ComplexGabarit);
    }

    private List<CryptoData> getListOfCrypto(List<YP_Row> list, boolean bl, boolean bl2) {
        ArrayList<CryptoData> arrayList = new ArrayList<CryptoData>();
        for (YP_Row yP_Row : list) {
            String string = yP_Row.getFieldStringValueByName("keyLabel");
            String string2 = yP_Row.getFieldStringValueByName("algorithm");
            String string3 = yP_Row.getFieldStringValueByName("idSM");
            String string4 = yP_Row.getFieldStringValueByName("properties");
            YP_TCD_CRYPTO_Module yP_TCD_CRYPTO_Module = this.cipherSymHashMap.get(string3);
            if (yP_TCD_CRYPTO_Module == null) {
                this.logger(3, "getListOfCrypto() plugin not found :" + string3);
                continue;
            }
            if (bl && this.getChildStatusByRank(yP_TCD_CRYPTO_Module.getRankInFatherChildList()) != 1) {
                this.logger(3, "getListOfCrypto() plugin ignored :" + string3);
                continue;
            }
            if (bl2) {
                if (!this.canCipher(yP_Row)) {
                    if (this.getLogLevel() < 5) continue;
                    this.logger(5, "getListOfCrypto() unusable key for ciphering " + string);
                    continue;
                }
            } else if (!this.canUnCipher(yP_Row)) {
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "getListOfCrypto() unusable key for unciphering " + string);
                continue;
            }
            if (!this.isRequestorAllowedToUseKey(yP_Row)) {
                if (this.getLogLevel() < 5) continue;
                this.logger(5, "getListOfCrypto() requestor not allowed to use key " + string);
                continue;
            }
            int n = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)yP_TCD_CRYPTO_Module)).isCipherSymSupported(string2);
            if (n <= 0) continue;
            CryptoData cryptoData = this.getCryptoData(yP_TCD_CRYPTO_Module, string, string2, string4, string3);
            arrayList.add(cryptoData);
        }
        Collections.shuffle(arrayList);
        return arrayList;
    }

    private CryptoData getCryptoData(YP_TCD_CRYPTO_Module yP_TCD_CRYPTO_Module, String string, String string2, String string3, String string4) {
        CryptoData cryptoData = new CryptoData();
        cryptoData.cryptoAlgo = string2;
        cryptoData.cryptoModule = yP_TCD_CRYPTO_Module;
        cryptoData.securityLevel = yP_TCD_CRYPTO_Module.getSecurityLevel();
        cryptoData.priority = yP_TCD_CRYPTO_Module.getPriority();
        cryptoData.keyLabel = string;
        cryptoData.idSM = string4;
        if (string3 != null && !string3.isEmpty() && !string3.trim().isEmpty()) {
            try {
                YP_TCG_XMLParser yP_TCG_XMLParser = (YP_TCG_XMLParser)this.getPluginByName("YPPropertiesParser");
                Properties properties = (Properties)yP_TCG_XMLParser.xmlToObject(string3);
                cryptoData.keyproperties = properties.getProperty();
            }
            catch (Exception exception) {
                this.logger(2, "getCryptoData() bad properties ??? " + string3 + " ", exception);
            }
        }
        return cryptoData;
    }

    private String[] encryptToken(String string) {
        return (String[])this.encryptTokenOrData(2, this.tokenKeyLabel, string, null, null);
    }

    private String[] encrypt(String string, String string2, String string3) {
        return (String[])this.encryptTokenOrData(1, string, string2, null, string3);
    }

    private byte[][] encrypt(String string, byte[] byArray, String string2) {
        return (byte[][])this.encryptTokenOrData(1, string, null, byArray, string2);
    }

    private Object[] encryptTokenOrData(int n, String string, String string2, byte[] byArray, String string3) {
        String string4 = null;
        List<YP_Row> list = this.getCryptoKeyList(string);
        if (list == null || list.size() <= 0) {
            if (string.length() == 20 && (list = this.getCryptoKeyList(DUKPT.getBDKAlias(string))) != null && !list.isEmpty()) {
                string4 = string3;
                string3 = string;
            }
            if (list == null || list.size() <= 0) {
                this.sysLog(2, "encryptTokenOrData() failed key not found:" + string);
                return null;
            }
        }
        if (list.isEmpty()) {
            this.sysLog(2, "encryptTokenOrData() failed: no matching key found");
            return null;
        }
        return this.encryptTokenOrData(list, n, string2, byArray, string3, string4);
    }

    private Object[] encryptTokenOrData(List<YP_Row> list, int n, String string, byte[] byArray, String string2, String string3) {
        boolean bl = true;
        if (list.size() == 1) {
            bl = false;
        }
        List<CryptoData> list2 = this.getListOfCrypto(list, bl, true);
        if (bl && list2.isEmpty()) {
            bl = false;
            list2 = this.getListOfCrypto(list, bl, false);
        }
        if (list2.isEmpty()) {
            this.logger(2, "encryptTokenOrData() failed: no provider available for this operation ");
            return null;
        }
        boolean bl2 = true;
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl = false;
                list2 = this.getListOfCrypto(list, bl, true);
            }
            CryptoData cryptoData = this.getEligibleCrypto(list2);
            while (cryptoData != null) {
                block25: {
                    block26: {
                        Object[] objectArray;
                        block27: {
                            block24: {
                                if (string == null) break block24;
                                if (n == 2) {
                                    objectArray = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).encryptToken(cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string);
                                    if (objectArray != null) {
                                        return objectArray;
                                    }
                                    break block25;
                                }
                                if (n == 1) {
                                    if (string3 != null && !string3.isEmpty()) {
                                        string2 = String.valueOf(string2) + "|" + string3;
                                    }
                                    if ((objectArray = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).encrypt(string, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string2)) != null) {
                                        return objectArray;
                                    }
                                    break block25;
                                }
                                this.logger(2, "encryptTokenOrData() String not done for " + n);
                                return null;
                            }
                            if (byArray == null) break block26;
                            if (n != 2) break block27;
                            this.logger(2, "encryptTokenOrData() only base64 allowed");
                            return null;
                        }
                        if (n == 1) {
                            if (string3 != null && !string3.isEmpty()) {
                                string2 = String.valueOf(string2) + "|" + string3;
                            }
                            if ((objectArray = (Object[])((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).encrypt(byArray, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string2)) != null) {
                                return objectArray;
                            }
                            break block25;
                        }
                        if (n == 3) {
                            objectArray = (Object[])((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).encryptPIN(byArray, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string2);
                            if (objectArray != null) {
                                return objectArray;
                            }
                            break block25;
                        }
                        this.logger(2, "encryptTokenOrData() byte[] not done for " + n);
                        return null;
                    }
                    this.logger(2, "encryptTokenOrData() bad parameters");
                    return null;
                }
                try {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "encryptTokenOrData() failed for " + cryptoData.cryptoModule.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "encryptTokenOrData() ", exception);
                }
                boolean bl3 = list2.remove(cryptoData);
                if (!bl3) {
                    this.logger(1, "encryptTokenOrData()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list2);
            }
        } while (bl);
        this.logger(2, "encryptTokenOrData failed to encrypt");
        return null;
    }

    private String macComputeHPS(String string, byte[] byArray, int n, int n2) {
        List<YP_Row> list = this.getCryptoKeyList(string);
        if (list == null) {
            this.logger(2, "macComputeHPS() context error for " + string);
            return null;
        }
        if (list.isEmpty()) {
            this.logger(2, "macComputeHPS() failed: no matching key found for " + string);
            return null;
        }
        boolean bl = true;
        if (list.size() == 1) {
            bl = false;
        }
        List<CryptoData> list2 = this.getListOfCrypto(list, bl, true);
        if (bl && list2.isEmpty()) {
            bl = false;
            list2 = this.getListOfCrypto(list, bl, false);
        }
        if (list2.isEmpty()) {
            this.logger(2, "macComputeHPS() failed: no provider available for this operation for " + string);
            return null;
        }
        boolean bl2 = true;
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl = false;
                list2 = this.getListOfCrypto(list, bl, true);
            }
            CryptoData cryptoData = this.getEligibleCrypto(list2);
            while (cryptoData != null) {
                boolean bl3;
                try {
                    bl3 = false;
                    int n3 = 0;
                    byte[] byArray2 = new byte[8];
                    byte[] byArray3 = new byte[8];
                    do {
                        int n4 = 0;
                        while (n4 < 8) {
                            byArray2[n4] = n3 * 8 + n4 < n2 ? (byte)(byArray3[n4] ^ byArray[n + n3 * 8 + n4]) : byArray3[n4];
                            ++n4;
                        }
                        byte[][] byArray4 = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).encrypt(byArray2, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, null);
                        if (byArray4 == null) {
                            this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                            this.logger(3, "macComputeHPS() failed for " + cryptoData.cryptoModule.toString());
                            bl3 = true;
                            break;
                        }
                        byArray3 = byArray4[0];
                    } while (++n3 * 8 < n2);
                    if (!bl3) {
                        return UtilsYP.devHexa(byArray3, 0, 4);
                    }
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "macComputeHPS()  ", exception);
                }
                bl3 = list2.remove(cryptoData);
                if (!bl3) {
                    this.logger(1, "macComputeHPS()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list2);
            }
        } while (bl);
        this.logger(2, "macComputeHPS failed to encrypt with " + string);
        return null;
    }

    private Object decryptTokenOrData(int n, String string, String string2, byte[] byArray, String string3, String string4) {
        int n2;
        List<YP_Row> list = this.getCryptoKeyList(string);
        if (list == null || list.size() <= 0) {
            if (string.length() == 20 && (list = this.getCryptoKeyList(DUKPT.getBDKAlias(string))) != null && !list.isEmpty()) {
                if (string3 != null && !string3.isEmpty()) {
                    this.logger(2, "decryptTokenOrData parameter should be empty as it is needed to store the KSN...");
                }
                string3 = string;
            }
            if (list == null || list.size() <= 0) {
                this.sysLog(2, "decryptTokenOrData() failed key not found:" + string);
                return null;
            }
        }
        if (list.isEmpty()) {
            this.sysLog(2, "decryptTokenOrData() failed: no matching key found");
            return null;
        }
        boolean bl = true;
        List<CryptoData> list2 = this.getListOfCrypto(list, bl, false);
        if (list2.isEmpty()) {
            bl = false;
            list2 = this.getListOfCrypto(list, bl, false);
        }
        if ((n2 = list2.size()) <= 0) {
            this.logger(2, "decryptTokenOrData() failed: no provider available for this operation");
            return null;
        }
        boolean bl2 = true;
        boolean bl3 = true;
        if (list.size() == 1) {
            bl3 = false;
        }
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl3 = false;
            }
            CryptoData cryptoData = this.getEligibleCrypto(list2);
            while (cryptoData != null) {
                block28: {
                    block29: {
                        Object object;
                        block30: {
                            block27: {
                                if (string2 == null) break block27;
                                if (n == 2) {
                                    object = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).decryptToken(cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string2);
                                    if (object != null) {
                                        return object;
                                    }
                                    break block28;
                                }
                                if (n == 1) {
                                    object = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).decrypt(string2, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string3, string4);
                                    if (object != null) {
                                        return object;
                                    }
                                    break block28;
                                }
                                this.logger(2, "decryptTokenOrData() String not done for " + n);
                                return null;
                            }
                            if (byArray == null) break block29;
                            if (n != 2) break block30;
                            this.logger(2, "decryptTokenOrData() only base64 allowed");
                            return null;
                        }
                        if (n == 1) {
                            object = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).decrypt(byArray, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string3, string4);
                            if (object != null) {
                                return object;
                            }
                            break block28;
                        }
                        if (n == 3) {
                            object = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).decryptPIN(byArray, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string3);
                            if (object != null) {
                                return object;
                            }
                            break block28;
                        }
                        this.logger(2, "decryptTokenOrData() byte[] not done for " + n);
                        return null;
                    }
                    this.logger(3, "decryptTokenOrData() bad parameters");
                    return null;
                }
                try {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(3, "decryptTokenOrData() failed for " + cryptoData.cryptoModule.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "decryptTokenOrData() ", exception);
                }
                boolean bl4 = list2.remove(cryptoData);
                if (!bl4) {
                    this.logger(1, "decryptTokenOrData()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list2);
            }
        } while (bl3);
        this.logger(2, "decryptTokenOrData() failed");
        return null;
    }

    private Object translatePin(String string, String string2, String string3, String string4, byte[] byArray, String string5, String string6, String string7) {
        int n;
        List<CryptoData> list;
        List<YP_Row> list2 = this.getCryptoKeyList(string3);
        if (list2 == null || list2.size() <= 0) {
            if (string3.length() == 20 && (list2 = this.getCryptoKeyList(DUKPT.getBDKAlias(string3))) != null && !list2.isEmpty()) {
                if (string6 != null && !string6.isEmpty()) {
                    this.logger(2, "translatePin parameter should be empty as it is needed to store the KSN...");
                }
                string6 = string3;
            }
            if (list2 == null || list2.size() <= 0) {
                this.sysLog(2, "translatePin() failed key not found:" + string3);
                return null;
            }
        }
        if (list2.isEmpty()) {
            this.sysLog(2, "translatePin() failed: no matching sourceKey found");
            return null;
        }
        List<YP_Row> list3 = this.getCryptoKeyList(string4);
        if (list3 == null || list3.size() <= 0) {
            this.sysLog(2, "translatePin() failed destinationKey not found:" + string4);
            return null;
        }
        if (list3.isEmpty()) {
            this.sysLog(2, "translatePin() failed: no matching destinationKey found");
            return null;
        }
        boolean bl = true;
        bl = true;
        List<CryptoData> list4 = this.getListOfCrypto(list2, bl, true);
        if (list4.isEmpty()) {
            bl = false;
            list4 = this.getListOfCrypto(list2, bl, true);
        }
        if ((list = this.getListOfCrypto(list3, bl, true)).isEmpty()) {
            bl = false;
            list = this.getListOfCrypto(list3, bl, true);
        }
        if ((n = list.size()) <= 0) {
            this.logger(2, "translatePin() failed: no provider available for this operation");
            return null;
        }
        boolean bl2 = true;
        boolean bl3 = true;
        if (list3.size() == 1) {
            bl3 = false;
        }
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl3 = false;
            }
            CryptoData cryptoData = this.getEligibleCrypto(list);
            String string8 = cryptoData.idSM;
            CryptoData cryptoData2 = this.getEligibleCrypto(list4, string8);
            if (cryptoData2 == null) {
                cryptoData = null;
            }
            while (cryptoData != null) {
                block22: {
                    if (byArray != null) {
                        byte[] byArray2 = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).translatePIN(byArray, string, string5, cryptoData2.keyLabel, cryptoData2.keyproperties, cryptoData2.cryptoAlgo, string6, string2, cryptoData.keyLabel, cryptoData.keyproperties, cryptoData.cryptoAlgo, string7);
                        if (byArray2 != null) {
                            return byArray2;
                        }
                        break block22;
                    }
                    this.logger(3, "translatePin() bad parameters");
                    return null;
                }
                try {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(3, "translatePin() failed for " + cryptoData.cryptoModule.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "translatePin() ", exception);
                }
                boolean bl4 = list.remove(cryptoData);
                if (!bl4) {
                    this.logger(1, "translatePin()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list);
                string8 = cryptoData.idSM;
                cryptoData2 = this.getEligibleCrypto(list4, string8);
                if (cryptoData2 != null) continue;
                cryptoData = null;
            }
        } while (bl3);
        this.logger(2, "translatePin() failed maybe destination and origin crypto not managed by same cryptomodule");
        return null;
    }

    private byte[][] encryptPIN(String string, byte[] byArray) {
        return (byte[][])this.encryptTokenOrData(3, string, null, byArray, null);
    }

    private byte[] decryptPIN(String string, byte[] byArray) {
        return (byte[])this.decryptTokenOrData(3, string, null, byArray, null, null);
    }

    private Object decryptToken(String string, String string2) {
        return this.decryptTokenOrData(2, string, string2, null, null, null);
    }

    private Object decrypt(String string, String string2, String string3, String string4) {
        return this.decryptTokenOrData(1, string, string2, null, string3, string4);
    }

    private Object decrypt(String string, byte[] byArray, String string2, String string3) {
        String string4 = UtilsYP.devHexa(byArray);
        Object object = this.cryptedValueCacheMap.get(string4);
        if (object == null) {
            object = this.decryptTokenOrData(1, string, null, byArray, string2, string3);
            this.cryptedValueCacheMap.put(string4, object);
        }
        return object;
    }

    private CryptoData getEligibleCrypto(List<CryptoData> list) {
        return this.getEligibleCrypto(list, null);
    }

    private CryptoData getEligibleCrypto(List<CryptoData> list, String string) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        CryptoData cryptoData = null;
        for (CryptoData cryptoData2 : list) {
            if (string != null && !string.isEmpty() && (cryptoData2.idSM == null || !cryptoData2.idSM.contentEquals(string))) continue;
            if (cryptoData == null) {
                cryptoData = cryptoData2;
                continue;
            }
            if (cryptoData2.priority > cryptoData.priority) {
                cryptoData = cryptoData2;
                continue;
            }
            if (cryptoData2.priority != cryptoData.priority || cryptoData2.securityLevel <= cryptoData.securityLevel) continue;
            cryptoData = cryptoData2;
        }
        return cryptoData;
    }

    private int addKey(String string, byte[] byArray, String string2) {
        boolean bl;
        block10: {
            try {
                boolean bl2 = false;
                bl = false;
                for (YP_TCD_CRYPTO_Module yP_TCD_CRYPTO_Module : this.cipherSymList) {
                    if (yP_TCD_CRYPTO_Module.isCryptoSupported("cipherSym", string2) <= 0) continue;
                    bl = true;
                    int n = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)yP_TCD_CRYPTO_Module)).addKey(string, null, byArray, string2);
                    switch (n) {
                        case 1: {
                            DAO_CryptoKey dAO_CryptoKey = (DAO_CryptoKey)this.extensionCrypto.cryptoKey.getNewRow();
                            dAO_CryptoKey.set("keyLabel", string);
                            dAO_CryptoKey.set("idSM", yP_TCD_CRYPTO_Module.getCryptoModuleName());
                            dAO_CryptoKey.set("algorithm", string2);
                            dAO_CryptoKey.set("algorithm", string2);
                            dAO_CryptoKey.set("keyStatus", KeyStatusEnumeration.ACTIVE);
                            dAO_CryptoKey.set("effectiveDate", UtilsYP.getNowSqlTimeStamp());
                            dAO_CryptoKey.set("expirationDate", new Timestamp(System.currentTimeMillis() + 315360000000L));
                            this.extensionCrypto.cryptoKey.addRow(dAO_CryptoKey);
                            this.extensionCrypto.cryptoKey.persist();
                            bl2 = true;
                            break;
                        }
                        case 0: {
                            break;
                        }
                        case -1: {
                            break;
                        }
                    }
                }
                if (!bl2) break block10;
                return 1;
            }
            catch (Exception exception) {
                this.logger(2, "addKey() ", exception);
                return -1;
            }
        }
        if (!bl) {
            this.logger(2, "addKey() key " + string + " not added, maybe no cryptomodule to handle " + string2 + " algo");
            return -1;
        }
        return 0;
    }

    private byte[] exportKey(String string, String string2) {
        int n;
        List<CryptoData> list;
        List<YP_Row> list2 = this.getCryptoKeyList(string);
        if (!(list2 != null && list2.size() > 0 || list2 != null && list2.size() > 0)) {
            this.sysLog(2, "exportKey() failed key not found:" + string);
            return null;
        }
        if (list2.isEmpty()) {
            this.sysLog(2, "exportKey() failed: no matching sourceKey found");
            return null;
        }
        List<YP_Row> list3 = this.getCryptoKeyList(string2);
        if (list3 == null || list3.size() <= 0) {
            this.sysLog(2, "exportKey() failed exportKey not found:" + string2);
            return null;
        }
        if (list3.isEmpty()) {
            this.sysLog(2, "exportKey() failed: no matching exportKey found");
            return null;
        }
        boolean bl = true;
        bl = true;
        List<CryptoData> list4 = this.getListOfCrypto(list2, bl, true);
        if (list4.isEmpty()) {
            bl = false;
            list4 = this.getListOfCrypto(list2, bl, true);
        }
        if ((list = this.getListOfCrypto(list3, bl, true)).isEmpty()) {
            bl = false;
            list = this.getListOfCrypto(list3, bl, true);
        }
        if ((n = list.size()) <= 0) {
            this.logger(2, "exportKey() failed: no provider available for this operation");
            return null;
        }
        boolean bl2 = true;
        boolean bl3 = true;
        if (list3.size() == 1) {
            bl3 = false;
        }
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl3 = false;
            }
            CryptoData cryptoData = this.getEligibleCrypto(list);
            String string3 = cryptoData.idSM;
            CryptoData cryptoData2 = this.getEligibleCrypto(list4, string3);
            if (cryptoData2 == null) {
                cryptoData = null;
            }
            while (cryptoData != null) {
                try {
                    byte[] byArray = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).exportKey(cryptoData2.keyLabel, cryptoData2.keyproperties, cryptoData.keyLabel, cryptoData.keyproperties);
                    if (byArray != null) {
                        return byArray;
                    }
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(3, "translatePin() failed for " + cryptoData.cryptoModule.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "exportKey() ", exception);
                }
                boolean bl4 = list.remove(cryptoData);
                if (!bl4) {
                    this.logger(1, "exportKey()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list);
                string3 = cryptoData.idSM;
                cryptoData2 = this.getEligibleCrypto(list4, string3);
                if (cryptoData2 != null) continue;
                cryptoData = null;
            }
        } while (bl3);
        this.logger(2, "exportKey() failed");
        return null;
    }

    private byte[] importKey(String string, String string2) {
        int n;
        List<YP_Row> list = this.getCryptoKeyList(string2);
        if (list == null || list.size() <= 0) {
            this.sysLog(2, "importKey() failed exportKey not found:" + string2);
            return null;
        }
        if (list.isEmpty()) {
            this.sysLog(2, "importKey() failed: no matching exportKey found");
            return null;
        }
        boolean bl = true;
        bl = true;
        List<CryptoData> list2 = this.getListOfCrypto(list, bl, true);
        if (list2.isEmpty()) {
            bl = false;
            list2 = this.getListOfCrypto(list, bl, true);
        }
        if ((n = list2.size()) <= 0) {
            this.logger(2, "importKey() failed: no provider available for this operation");
            return null;
        }
        boolean bl2 = true;
        boolean bl3 = true;
        if (list.size() == 1) {
            bl3 = false;
        }
        do {
            if (bl2) {
                bl2 = false;
            } else {
                bl3 = false;
            }
            CryptoData cryptoData = this.getEligibleCrypto(list2);
            while (cryptoData != null) {
                try {
                    byte[] byArray = ((YP_TCD_CRYPTO_CipherSym_Interface)((Object)cryptoData.cryptoModule)).importKey(string, cryptoData.keyLabel, cryptoData.keyproperties);
                    if (byArray != null) {
                        return byArray;
                    }
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(3, "translatePin() failed for " + cryptoData.cryptoModule.toString());
                }
                catch (Exception exception) {
                    this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                    this.logger(2, "importKey() ", exception);
                }
                boolean bl4 = list2.remove(cryptoData);
                if (!bl4) {
                    this.logger(1, "importKey()  Impossible to remove inactive crypto let's stop");
                    return null;
                }
                cryptoData = this.getEligibleCrypto(list2);
            }
        } while (bl3);
        this.logger(2, "importKey() failed");
        return null;
    }

    private List<CryptoData> getEligibleCryptoMac(String string) throws Exception {
        return this.getEligibleCrypto(string, this.fastMacFinder, this.macHashMap);
    }

    private String computeMAC(String string, byte[] byArray, Object ... objectArray) throws Exception {
        List<CryptoData> list = this.getEligibleCryptoMac(string);
        for (CryptoData cryptoData : list) {
            try {
                if (this.getChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList()) != 1) continue;
                return ((YP_TCD_CRYPTO_MacAlgo_Interface)((Object)cryptoData.cryptoModule)).computeMAC(string, cryptoData.keyproperties, byArray, objectArray);
            }
            catch (Exception exception) {
                this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                this.logger(2, "computeMAC() ", exception);
            }
        }
        for (CryptoData cryptoData : list) {
            try {
                if (this.getChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList()) == 1) continue;
                return ((YP_TCD_CRYPTO_MacAlgo_Interface)((Object)cryptoData.cryptoModule)).computeMAC(string, cryptoData.keyproperties, byArray, objectArray);
            }
            catch (Exception exception) {
                this.logger(2, "computeMAC() ", exception);
            }
        }
        this.logger(2, "computeMAC failed to mac...");
        return null;
    }

    private boolean verifyMAC(String string, byte[] byArray, String string2, Object ... objectArray) throws Exception {
        List<CryptoData> list = this.getEligibleCryptoMac(string);
        for (CryptoData cryptoData : list) {
            try {
                if (this.getChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList()) != 1) continue;
                return ((YP_TCD_CRYPTO_MacAlgo_Interface)((Object)cryptoData.cryptoModule)).verifyMAC(string, cryptoData.keyproperties, byArray, string2, objectArray);
            }
            catch (Exception exception) {
                this.setChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList(), 0);
                this.logger(2, "verifyMAC() ", exception);
            }
        }
        for (CryptoData cryptoData : list) {
            try {
                if (this.getChildStatusByRank(cryptoData.cryptoModule.getRankInFatherChildList()) == 1) continue;
                return ((YP_TCD_CRYPTO_MacAlgo_Interface)((Object)cryptoData.cryptoModule)).verifyMAC(string, cryptoData.keyproperties, byArray, string2, objectArray);
            }
            catch (Exception exception) {
                this.logger(2, "verifyMAC() ", exception);
            }
        }
        this.logger(2, "verifyMAC failed to mac...");
        throw new Exception("verifyMAC failed to mac...");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            switch (string) {
                case "random": {
                    return this.getRandom(0, "SHA1PRNG", 2);
                }
                case "sha256Hash": {
                    if (objectArray != null && objectArray.length == 1) {
                        if (objectArray[0] instanceof String) {
                            String string2 = (String)objectArray[0];
                            return this.digestMessage("SHA-256", string2);
                        }
                        if (objectArray[0] instanceof byte[]) {
                            byte[] byArray = (byte[])objectArray[0];
                            return this.digestMessage("SHA-256", byArray);
                        }
                    }
                    this.logger(2, "dealRequest() bad parameters for sha256Hash");
                    return null;
                }
                case "sha1Hash": {
                    if (objectArray != null && objectArray.length == 1) {
                        if (objectArray[0] instanceof String) {
                            String string3 = (String)objectArray[0];
                            return this.digestMessage("SHA-1", string3);
                        }
                        if (objectArray[0] instanceof byte[]) {
                            byte[] byArray = (byte[])objectArray[0];
                            return this.digestMessage("SHA-1", byArray);
                        }
                    }
                    this.logger(2, "dealRequest() bad parameters for sha1Hash");
                    return null;
                }
                case "encrypt": {
                    if (objectArray == null || objectArray.length != 3) {
                        this.logger(2, "dealRequest() bad parameters for encrypt. 3 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for encrypt. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[2] != null && !(objectArray[2] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 3 for encrypt. algo parameter must be a string or null");
                        return null;
                    }
                    if (objectArray[1] == null) {
                        this.logger(2, "dealRequest() bad parameter 2 for encrypt. value to encrypt must not be null");
                        return null;
                    }
                    if (objectArray[1] instanceof String) {
                        return this.encrypt((String)objectArray[0], (String)objectArray[1], (String)objectArray[2]);
                    }
                    if (objectArray[1] instanceof byte[]) {
                        return this.encrypt((String)objectArray[0], (byte[])objectArray[1], (String)objectArray[2]);
                    }
                    this.logger(2, "dealRequest() bad parameter 2 for encrypt. value to encrypt must be a string or byte[]");
                    return null;
                }
                case "decrypt": {
                    if (objectArray == null || objectArray.length < 3) {
                        this.logger(2, "dealRequest() bad parameters for decrypt. at least 3 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for decrypt. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[2] != null && !(objectArray[2] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 3 for decrypt. algo parameter must be a string or null");
                        return null;
                    }
                    if (objectArray[1] == null) {
                        this.logger(2, "dealRequest() bad parameter 2 for decrypt. value to decrypt must not be null");
                        return null;
                    }
                    if (objectArray.length > 3 && objectArray[3] != null && !(objectArray[3] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 4 for decrypt. ivForDukpt must be a string or null");
                        return null;
                    }
                    String string4 = null;
                    if (objectArray.length > 3) {
                        string4 = (String)objectArray[3];
                    }
                    if (objectArray[1] instanceof String) {
                        return this.decrypt((String)objectArray[0], (String)objectArray[1], (String)objectArray[2], string4);
                    }
                    if (objectArray[1] instanceof byte[]) {
                        return this.decrypt((String)objectArray[0], (byte[])objectArray[1], (String)objectArray[2], string4);
                    }
                    this.logger(2, "dealRequest()  bad parameter 2 for decrypt. value to decrypt must be a string or byte[]");
                    return null;
                }
                case "encryptPIN": {
                    if (objectArray == null || objectArray.length != 2) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameters for encryptPIN. 2 parameters required");
                        }
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        if (this.getLogLevel() >= 2) {
                            this.logger(2, "dealRequest() bad parameter 1 for encryptPIN. key label must be a string not null");
                        }
                        return null;
                    }
                    if (objectArray[1] != null && objectArray[1] instanceof byte[]) {
                        return this.encryptPIN((String)objectArray[0], (byte[])objectArray[1]);
                    }
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "dealRequest() bad parameter 2 for encryptPIN. value to encrypt must be a byte[] not null");
                    }
                    return null;
                }
                case "decryptPIN": {
                    if (objectArray == null || objectArray.length != 2) {
                        this.logger(2, "dealRequest() bad parameters for decryptPIN. 2 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for decryptPIN. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] != null && objectArray[1] instanceof byte[]) {
                        return this.decryptPIN((String)objectArray[0], (byte[])objectArray[1]);
                    }
                    this.logger(2, "dealRequest() bad parameter 2 for decryptPIN. value to decrypt must be a b yte[] not null");
                    return null;
                }
                case "translatePIN": {
                    if (objectArray == null || objectArray.length < 8) {
                        this.logger(2, "dealRequest() bad parameters for translatePIN. 8 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for translatePIN. Source pin block format must be a string not null");
                        return null;
                    }
                    if (objectArray[1] == null || !(objectArray[1] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 2 for translatePIN. Destination pin block format must be a string not null");
                        return null;
                    }
                    if (objectArray[2] == null || !(objectArray[2] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 3 for translatePIN. Source key label must be a string not null");
                        return null;
                    }
                    if (objectArray[3] == null || !(objectArray[3] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 4 for translatePIN. Destination key label must be a string not null");
                        return null;
                    }
                    if (objectArray[4] == null || !(objectArray[4] instanceof byte[])) {
                        this.logger(2, "dealRequest() bad parameter 5 for translatePIN. PIN block must be a byte[] not null");
                        return null;
                    }
                    if (objectArray[5] != null && !(objectArray[5] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 7 for translatePIN. PAN must be a string not null");
                        return null;
                    }
                    if (objectArray[6] != null && !(objectArray[6] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 8 for translatePIN. Source parameter must be a string");
                        return null;
                    }
                    if (objectArray[7] != null && !(objectArray[7] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 9 for translatePIN. Destination parameter must be a string");
                        return null;
                    }
                    return this.translatePin((String)objectArray[0], (String)objectArray[1], (String)objectArray[2], (String)objectArray[3], (byte[])objectArray[4], (String)objectArray[5], (String)objectArray[6], (String)objectArray[7]);
                }
                case "encryptToken": {
                    if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof String) {
                        return this.encryptToken((String)objectArray[0]);
                    }
                    this.logger(2, "dealRequest() bad parameters for encryptToken");
                    return null;
                }
                case "decryptToken": {
                    if (objectArray != null && objectArray.length == 2 && objectArray[0] instanceof String && objectArray[1] instanceof String) {
                        return this.decryptToken((String)objectArray[0], (String)objectArray[1]);
                    }
                    this.logger(2, "dealRequest() bad parameters for decryptToken");
                    return null;
                }
                case "addKey": {
                    if (objectArray != null && objectArray.length == 3 && objectArray[0] instanceof String && objectArray[1] instanceof byte[] && objectArray[2] instanceof String) {
                        return this.addKey((String)objectArray[0], (byte[])objectArray[1], (String)objectArray[2]);
                    }
                    this.logger(2, "dealRequest() bad parameters for addKey");
                    return null;
                }
                case "macComputeHPS": {
                    if (objectArray == null || objectArray.length != 4) {
                        this.logger(2, "dealRequest() bad parameters for encrypt. 4 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for encrypt. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] == null || !(objectArray[1] instanceof byte[])) {
                        this.logger(2, "dealRequest() bad parameter 2 for encrypt. value to encrypt must be a byte[] not null");
                        return null;
                    }
                    if (objectArray[2] == null || !(objectArray[2] instanceof Integer)) {
                        this.logger(2, "dealRequest() bad parameter 3 for encrypt. start index must be an int not null");
                        return null;
                    }
                    if (objectArray[3] != null && objectArray[3] instanceof Integer) {
                        return this.macComputeHPS((String)objectArray[0], (byte[])objectArray[1], (Integer)objectArray[2], (Integer)objectArray[3]);
                    }
                    this.logger(2, "dealRequest() bad parameter 4 for encrypt. data size must be an int not null");
                    return null;
                }
                case "computeMAC": {
                    if (objectArray == null || objectArray.length < 2) {
                        this.logger(2, "dealRequest() bad parameters for computeMAC. at least 2 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for computeMAC. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] != null && objectArray[1] instanceof byte[]) {
                        return this.computeMAC((String)objectArray[0], (byte[])objectArray[1], objectArray);
                    }
                    this.logger(2, "dealRequest() bad parameter 2 for computeMAC. value to encrypt must not be null");
                    return null;
                }
                case "verifyMAC": {
                    if (objectArray == null || objectArray.length < 3) {
                        this.logger(2, "dealRequest() bad parameters for verifyMAC. at least 3 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for verifyMAC. key label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] == null || !(objectArray[1] instanceof byte[])) {
                        this.logger(2, "dealRequest() bad parameter 2 for verifyMAC. value to verify must not be null");
                        return null;
                    }
                    if (objectArray[2] != null && objectArray[2] instanceof String) {
                        return this.verifyMAC((String)objectArray[0], (byte[])objectArray[1], (String)objectArray[2], objectArray);
                    }
                    this.logger(2, "dealRequest() bad parameter 3 for verifyMAC. MAC must be a string not null");
                    return null;
                }
                case "exportKey": {
                    if (objectArray == null || objectArray.length != 2) {
                        this.logger(2, "dealRequest() bad parameters for exportKey. 2 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for exportKey. exportKey label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] != null && objectArray[1] instanceof String) {
                        return this.exportKey((String)objectArray[0], (String)objectArray[1]);
                    }
                    this.logger(2, "dealRequest() bad parameter 2 for exportKey. wrapping key must be a string not be null");
                    return null;
                }
                case "importKey": {
                    if (objectArray == null || objectArray.length != 2) {
                        this.logger(2, "dealRequest() bad parameters for importKey. 2 parameters required");
                        return null;
                    }
                    if (objectArray[0] == null || !(objectArray[0] instanceof String)) {
                        this.logger(2, "dealRequest() bad parameter 1 for exportKey. importKey label must be a string not null");
                        return null;
                    }
                    if (objectArray[1] != null && objectArray[1] instanceof String) {
                        return this.importKey((String)objectArray[0], (String)objectArray[1]);
                    }
                    this.logger(2, "dealRequest() bad parameter 2 for importKey. wrapping key must be a string not be null");
                    return null;
                }
                case "getTokenKeyLabel": {
                    return this.tokenKeyLabel;
                }
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? : ", exception);
            return null;
        }
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        do {
            try {
                this.refreshContextIfNeeded();
                if (System.currentTimeMillis() >= l) {
                    int n = 0;
                    while (n < this.getChildNB()) {
                        try {
                            if (this.getChildStatusByRank(n) == 0) {
                                this.setChildStatusByRank(n, 1);
                            }
                        }
                        catch (Exception exception) {
                            this.logger(2, "run() ", exception);
                        }
                        ++n;
                    }
                    l = System.currentTimeMillis() + 900000L;
                }
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    class CryptoData {
        public YP_TCD_CRYPTO_Module cryptoModule;
        public String keyLabel;
        public String idSM;
        public String cryptoAlgo;
        public int securityLevel;
        public int priority;
        public List<Property> keyproperties;

        CryptoData() {
        }
    }

    class DigestData {
        public YP_TCD_CRYPTO_DigestAlgo_Interface digestInterface;
        public String digestAlgo;
        public int securityLevel;
        public int efficiency;

        DigestData() {
        }
    }

    class RandomData {
        public YP_TCD_CRYPTO_RandomNumberGenerator_Interface randomDataInterface;
        public String randomAlgo;
        public int handle;
        public int securityLevel;
        public int efficiency;

        RandomData() {
        }
    }
}

