/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public class YP_TS_StatusManager
extends YP_Service {
    public YP_TS_StatusManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setMaxChild(10000);
    }

    @Override
    public final String toString() {
        return "StatusManager";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.34";
    }

    @Override
    public void run() {
        do {
            try {
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
                YP_TCD_DCC_Status yP_TCD_DCC_Status = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerStatus();
                yP_TCD_DCC_Status.updateServiceStatus();
                yP_TCD_DCC_Status.updatePluginStatus();
                yP_TCD_DCC_Status.flushTables();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }
}

