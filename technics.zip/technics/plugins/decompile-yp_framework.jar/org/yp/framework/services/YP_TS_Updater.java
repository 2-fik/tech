/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;

public class YP_TS_Updater
extends YP_Service {
    private Path updateFile;
    private Path saveDir;
    private YP_TS_DataContainerManager dataContainerManager;
    private YP_TCD_DCC_Technique dataContainerTechnique;
    private static final String UPDATE_DIR = "technics/updater/";
    private static final String HISTO_DIR = "technics/updater/histo/";
    private static final String UPDATE_FILE = "update.sql";
    private static final String NEPTING_COMMAND_RELOAD = "#RELOAD";

    public YP_TS_Updater(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        this.dataContainerManager = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
        this.dataContainerTechnique = this.dataContainerManager.getDataContainerTechnique();
        String string = String.valueOf(UtilsYP.getPath()) + UPDATE_DIR;
        String string2 = String.valueOf(UtilsYP.getPath()) + HISTO_DIR;
        try {
            new File(string).mkdirs();
            new File(string2).mkdirs();
        }
        catch (Exception exception) {
            this.logger(2, "initialize() " + exception);
        }
        this.updateFile = Paths.get(String.valueOf(string) + UPDATE_FILE, new String[0]);
        this.saveDir = Paths.get(string2, new String[0]);
        return super.initialize();
    }

    @Override
    public String toString() {
        return "Updater";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        try {
            do {
                try {
                    this.databaseUpdateFromScript();
                    if (System.currentTimeMillis() >= l) {
                        l = System.currentTimeMillis() + 86400000L;
                        this.logger(4, "run()  It's time to check for an update");
                        try {
                            Object object;
                            Object object2;
                            Object object3;
                            YP_TCD_DCC_Status yP_TCD_DCC_Status = this.dataContainerManager.getDataContainerStatus();
                            StringBuilder stringBuilder = new StringBuilder();
                            List<YP_Row> list = yP_TCD_DCC_Status.getPluginStatusList();
                            if (list != null) {
                                for (YP_Row yP_Row : list) {
                                    stringBuilder.append(yP_Row.serialize());
                                    stringBuilder.append(UtilsYP.lineSeparator);
                                }
                            }
                            StringBuilder object42 = new StringBuilder();
                            List<YP_Row> list2 = yP_TCD_DCC_Status.getServiceStatusList();
                            if (list != null) {
                                object3 = list2.iterator();
                                while (object3.hasNext()) {
                                    object2 = (YP_Row)object3.next();
                                    object42.append(((YP_Row)object2).serialize());
                                    object42.append(UtilsYP.lineSeparator);
                                }
                            }
                            object2 = this.dataContainerTechnique.application.getRowList();
                            object3 = new StringBuilder();
                            Object object4 = object2.iterator();
                            while (object4.hasNext()) {
                                object = object4.next();
                                ((StringBuilder)object3).append(((YP_Row)object).serialize());
                                ((StringBuilder)object3).append(UtilsYP.lineSeparator);
                            }
                            try {
                                object = (YP_Service)this.getPluginByName("ConnectionManager");
                                object4 = (YP_Row)((YP_Object)object).dealRequest(this, "getConnectionRow", "UPDATER", "", "", "");
                                if (object4 == null) {
                                    this.logger(3, "run() unable to find connection row");
                                    continue;
                                }
                                YP_PHYS_Interface yP_PHYS_Interface = (YP_PHYS_Interface)((YP_Object)object).dealRequest(this, "openConnection", object4);
                                if (yP_PHYS_Interface == null) {
                                    this.logger(2, "run() impossible to get the UPDATER connection plugin");
                                    continue;
                                }
                                yP_PHYS_Interface.send(stringBuilder.toString().getBytes(), stringBuilder.length());
                                yP_PHYS_Interface.send(object42.toString().getBytes(), object42.length());
                                yP_PHYS_Interface.send(((StringBuilder)object3).toString().getBytes(), ((StringBuilder)object3).length());
                                yP_PHYS_Interface.close();
                                yP_PHYS_Interface.shutdown();
                            }
                            catch (Exception exception) {
                                this.logger(2, "run() impossible to get the update connection");
                            }
                        }
                        catch (Exception exception) {
                            this.logger(4, "run()  during update" + exception);
                        }
                    }
                    this.iAmAlive();
                    UtilsYP.sleep(60000);
                    this.iAmAlive();
                }
                catch (Exception exception) {
                    this.logger(2, "run()", exception);
                    UtilsYP.sleep(10000);
                }
            } while (this.getObjectStatus() == 1);
            this.logger(3, "run() Stopped...");
            this.shutdown();
        }
        catch (Exception exception) {
            this.logger(2, "run()" + exception);
            return;
        }
    }

    /*
     * Exception decompiling
     */
    private void databaseUpdateFromScript() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [8[DOLOOP]], but top level block is 3[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public final int reInit(String string, String string2) {
        try {
            YP_Object yP_Object = this.getPluginByName("GlobalProcessManager");
            if (yP_Object != null) {
                ((Integer)yP_Object.dealRequest(this, "reInitialize", string, string2)).intValue();
            }
            return 1;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("reload")) {
                return this.reInit((String)objectArray[0], (String)objectArray[1]);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :" + exception);
            return null;
        }
    }
}

