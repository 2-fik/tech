/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.utils.UtilsYP;

public class YP_TS_UserManager
extends YP_Service {
    public YP_TS_UserManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        return super.initialize();
    }

    @Override
    public String toString() {
        return "UserManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = 0L;
        do {
            try {
                this.getPluginByName("User").dealRequest(this, "flushUser", new Object[0]);
            }
            catch (Exception exception) {
                this.logger(2, "run() during flushUser" + exception);
            }
            try {
                if (System.currentTimeMillis() >= l) {
                    try {
                        this.getPluginByName("User").dealRequest(this, "archiveUser", new Object[0]);
                    }
                    catch (Exception exception) {
                        this.logger(4, "run()  during archiveUser" + exception);
                    }
                    l = System.currentTimeMillis() + 86400000L;
                }
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }
}

