/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.util.ArrayList;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.utils.UtilsYP;

public class YP_TS_ComponentManager
extends YP_Service {
    public YP_TS_ComponentManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setMaxChild(10000);
        this.setMaxChildUnlimited(true);
    }

    @Override
    public final String toString() {
        return "ComponentManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        do {
            try {
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
                if (System.currentTimeMillis() < l) continue;
                this.killOrphansProcesses();
                l = System.currentTimeMillis() + 86400000L;
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    public int killOrphansProcesses() {
        try {
            YP_Object yP_Object;
            ArrayList<YP_Service> arrayList = new ArrayList<YP_Service>();
            int n = this.getSupervisor().getChildNB();
            int n2 = 0;
            while (n2 < n) {
                yP_Object = this.getSupervisor().getChildByRank(n2);
                if (YP_Service.class.isInstance(yP_Object)) {
                    arrayList.add((YP_Service)yP_Object);
                }
                ++n2;
            }
            n = this.getChildNB();
            n2 = 0;
            while (n2 < n) {
                yP_Object = this.getChildByRank(n2);
                if (yP_Object != null) {
                    boolean bl = false;
                    for (YP_Service yP_Service : arrayList) {
                        if (yP_Service.getChildByProcessID(yP_Object.getAncestor().getProcessID()) == null) continue;
                        bl = true;
                        break;
                    }
                    if (!bl) {
                        this.logger(2, "killOrphansProcesses() process found:" + yP_Object.getAncestor().getProcessID() + " " + yP_Object.getFather().getProcessID() + " " + yP_Object.getProcessID() + " " + yP_Object.toString());
                        this.shutdownChildListByID(yP_Object.getProcessID());
                    }
                }
                ++n2;
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(3, "killOrphansProcesses() :" + exception);
            return -1;
        }
    }

    public int unregisterComponent(YP_Object yP_Object) {
        if (yP_Object.getRankInComponentManager() != -1) {
            return this.removeChildByRank(yP_Object.getRankInComponentManager());
        }
        yP_Object.logger(2, "unregisterComponent() No rank !!!");
        return this.removeChildByID(yP_Object.getProcessID());
    }

    public int registerComponent(YP_Object yP_Object) {
        int n = this.addChild(yP_Object, 1);
        if (n < 0) {
            yP_Object.logger(2, "registerComponent() No more space available...");
            return 0;
        }
        yP_Object.setRankInComponentManager(n);
        return 1;
    }

    public int unregisterComponentChilds(YP_Object yP_Object) {
        return this.shutdownChildListByID(yP_Object.getProcessID());
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("unregisterComponent")) {
                return this.unregisterComponent(yP_Object);
            }
            if (string.contentEquals("registerComponent")) {
                return this.registerComponent(yP_Object);
            }
            if (string.contentEquals("unregisterComponentChilds")) {
                return this.unregisterComponentChilds(yP_Object);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }
}

