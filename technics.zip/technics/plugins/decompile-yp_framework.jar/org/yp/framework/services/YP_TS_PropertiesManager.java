/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.locks.ReentrantLock;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.utils.UtilsYP;

public class YP_TS_PropertiesManager
extends YP_Service {
    private final int deleteIfOlderThanInMS = 432000000;
    private final Map<String, PropertiesDetails> propertiestMap = new HashMap<String, PropertiesDetails>();
    private final ReentrantLock propertiesListMutex = new ReentrantLock();

    public YP_TS_PropertiesManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setMaxChild(0);
        Runtime.getRuntime().addShutdownHook(new Thread(){

            @Override
            public void run() {
                YP_TS_PropertiesManager.this.flushProperties();
            }
        });
    }

    @Override
    public final String toString() {
        return "PropertiesManager";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        do {
            block15: {
                this.propertiesListMutex.lock();
                try {
                    try {
                        this.flushProperties();
                    }
                    catch (Exception exception) {
                        this.logger(2, "run() ", exception);
                        this.propertiesListMutex.unlock();
                        break block15;
                    }
                }
                catch (Throwable throwable) {
                    this.propertiesListMutex.unlock();
                    throw throwable;
                }
                this.propertiesListMutex.unlock();
            }
            try {
                if (System.currentTimeMillis() >= l) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "run() It's time to clean ");
                    }
                    if (System.currentTimeMillis() > l) {
                        this.propertiesListMutex.lock();
                        try {
                            this.propertiestMap.clear();
                        }
                        finally {
                            this.propertiesListMutex.unlock();
                        }
                    }
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "run() housekeep done");
                    }
                    l = System.currentTimeMillis() + 432000000L;
                }
                this.iAmAlive();
                UtilsYP.sleep(5000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    private int flushProperties() {
        for (Map.Entry<String, PropertiesDetails> entry : this.propertiestMap.entrySet()) {
            if (entry.getValue().nbmodifications <= 0) continue;
            this.saveProperties(entry.getValue().properties, entry.getKey(), null);
            entry.getValue().nbmodifications = 0;
        }
        return 1;
    }

    private int saveProperties(Properties properties, String string, String string2) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(string);
            properties.store(fileOutputStream, string2);
            ((OutputStream)fileOutputStream).close();
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "saveProperties() " + exception);
            }
            return -1;
        }
    }

    private Properties loadProperties(String string) {
        try {
            Properties properties = new Properties();
            if (string.endsWith(".properties")) {
                properties.load(new FileInputStream(string));
            } else {
                properties.load(new FileInputStream(String.valueOf(string) + ".properties"));
            }
            return properties;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "loadProperties() " + exception);
            }
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String getProperty(YP_Object yP_Object, String string, String string2) {
        try {
            String string3;
            if (string == null) {
                if (this.getLogLevel() < 5) return null;
                this.logger(5, "getProperty() Plugins without properties :" + yP_Object.getSimpleName());
                return null;
            }
            PropertiesDetails propertiesDetails = this.propertiestMap.get(string);
            try {
                this.propertiesListMutex.lock();
                if (propertiesDetails == null && (propertiesDetails = this.propertiestMap.get(string)) == null) {
                    Properties properties = this.loadProperties(string);
                    if (properties == null) {
                        this.logger(2, "getProperty() load :" + string);
                        return null;
                    }
                    propertiesDetails = new PropertiesDetails();
                    propertiesDetails.nbmodifications = 0;
                    propertiesDetails.properties = properties;
                    this.propertiestMap.put(string, propertiesDetails);
                }
                string3 = propertiesDetails.properties.getProperty(string2);
            }
            finally {
                this.propertiesListMutex.unlock();
            }
            if (string3 != null) return string3.trim();
            if (string2 != null) {
                if (string2.contentEquals("logLevel")) return null;
                if (string2.contentEquals("preferredName")) {
                    return null;
                }
            }
            this.logger(3, "getProperty() Value not found :" + string2);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "getProperty() " + exception);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int setProperty(YP_Object yP_Object, String string, String string2, String string3) {
        try {
            if (string == null) {
                if (this.getLogLevel() < 5) return -1;
                this.logger(5, "setProperty() Plugins without properties :" + yP_Object.getSimpleName());
                return -1;
            }
            PropertiesDetails propertiesDetails = this.propertiestMap.get(string);
            try {
                this.propertiesListMutex.lock();
                if (propertiesDetails == null && (propertiesDetails = this.propertiestMap.get(string)) == null) {
                    Properties properties = this.loadProperties(string);
                    if (properties == null) {
                        block12: {
                            try {
                                File file = new File(string.substring(0, string.lastIndexOf(47)));
                                file.mkdirs();
                                file = new File(string);
                                file.createNewFile();
                                properties = this.loadProperties(string);
                            }
                            catch (Exception exception) {
                                if (this.getLogLevel() < 2) break block12;
                                this.logger(2, "setProperty() " + exception);
                            }
                        }
                        if (properties == null) {
                            this.logger(2, "setProperty() load :" + string);
                            return -1;
                        }
                    }
                    propertiesDetails = new PropertiesDetails();
                    propertiesDetails.nbmodifications = 0;
                    propertiesDetails.properties = properties;
                    this.propertiestMap.put(string, propertiesDetails);
                }
                propertiesDetails.properties.setProperty(string2, string3);
                ++propertiesDetails.nbmodifications;
                if (this.getLogLevel() < 5) return 1;
                this.logger(5, "setProperty()  Saved " + string2 + ":" + string3 + " in " + string);
                return 1;
            }
            finally {
                this.propertiesListMutex.unlock();
            }
        }
        catch (Exception exception) {
            this.logger(2, "setProperty() " + exception);
            return -1;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getProperty")) {
                String string2 = (String)objectArray[0];
                String string3 = (String)objectArray[1];
                return this.getProperty(yP_Object, string2, string3);
            }
            if (string.contentEquals("setProperty")) {
                String string4 = (String)objectArray[0];
                String string5 = (String)objectArray[1];
                String string6 = (String)objectArray[2];
                return this.setProperty(yP_Object, string4, string5, string6);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :" + exception);
            return null;
        }
    }

    class PropertiesDetails {
        Properties properties;
        int nbmodifications = 0;

        PropertiesDetails() {
        }
    }
}

