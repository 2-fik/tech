/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Group;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Status;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEvents;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEventsAPP;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEventsMGT;
import org.yp.framework.ondemandcomponents.datacontainers.databaseevents.YP_TCD_DCC_DataBaseEventsSlaveTRS;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.Bitmap;
import org.yp.utils.ExtendedResult;
import org.yp.utils.UtilsYP;

public class YP_TS_DataContainerManager
extends YP_Service {
    private YP_TCD_DCC_Technique dataContainerTechnique = null;
    private YP_TCD_DCC_Status dataContainerStatus = null;
    YP_TCD_DCC_DataBaseEventsMGT dataContainerEventsMGT = null;
    List<YP_TCD_DCC_DataBaseEventsAPP> dataContainerEventsAppList = new ArrayList<YP_TCD_DCC_DataBaseEventsAPP>();
    List<YP_TCD_DCC_DataBaseEventsSlaveTRS> dataContainerEventsSlaveTRSList = new ArrayList<YP_TCD_DCC_DataBaseEventsSlaveTRS>();
    private YP_Service componentManager;
    private final Map<String, YP_TCD_DCC_Group> groupList = new ConcurrentHashMap<String, YP_TCD_DCC_Group>();
    private final Map<Long, YP_TCD_DCC_Group> groupListByID = new ConcurrentHashMap<Long, YP_TCD_DCC_Group>();
    private final Map<String, YP_TCD_DCC_Brand> brandList = new ConcurrentHashMap<String, YP_TCD_DCC_Brand>();
    private final Map<Long, YP_TCD_DCC_Brand> brandListByID = new ConcurrentHashMap<Long, YP_TCD_DCC_Brand>();
    private final Map<String, YP_TCD_DCC_Merchant> merchantList = new ConcurrentHashMap<String, YP_TCD_DCC_Merchant>();
    private final Map<Long, YP_TCD_DCC_Merchant> merchantListByID = new ConcurrentHashMap<Long, YP_TCD_DCC_Merchant>();
    private final Map<String, YP_TCD_DCC_Business> contractList = new ConcurrentHashMap<String, YP_TCD_DCC_Business>();
    private final Map<Long, YP_TCD_DCC_Business> contractListByID = new ConcurrentHashMap<Long, YP_TCD_DCC_Business>();
    private static final char FIELD_START = '[';
    private static final char FIELD_END = ']';

    public YP_TS_DataContainerManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        Runtime.getRuntime().addShutdownHook(new Thread(){

            @Override
            public void run() {
                YP_TS_DataContainerManager.this.flushPendingTransactions();
                YP_TS_DataContainerManager.this.flushAllCachedTablesOnShutdown();
            }
        });
    }

    @Override
    public String toString() {
        return "DataContainerManager";
    }

    @Override
    public String getVersion() {
        return "V1.2.1.0";
    }

    @Override
    public int initialize() {
        String string;
        block22: {
            block21: {
                block20: {
                    block19: {
                        block18: {
                            block17: {
                                block16: {
                                    block15: {
                                        super.initialize();
                                        this.componentManager = (YP_Service)this.getPluginByName("ComponentManager");
                                        string = this.getProperty(this.getPropertyFileName(), "dataContainerStatusName");
                                        if (string != null) break block15;
                                        this.logger(2, "initialize() Unable to get dataContainerStatusName from properties file");
                                        return -1;
                                    }
                                    this.dataContainerStatus = (YP_TCD_DCC_Status)this.newPluginByName(string, new Object[0]);
                                    if (this.dataContainerStatus != null) break block16;
                                    this.logger(2, "initialize() Unable to find " + string);
                                    return -1;
                                }
                                string = this.getProperty(this.getPropertyFileName(), "dataContainerStatusProperties");
                                if (string != null) break block17;
                                this.logger(2, "initialize() Unable to get dataContainerStatusProperties from properties file");
                                return -1;
                            }
                            this.dataContainerStatus.setPropertyFileName(string);
                            string = this.getProperty(this.getPropertyFileName(), "dataContainerEventsMGTName");
                            if (string == null) {
                                this.logger(2, "initialize() Unable to get dataContainerEventsMGTName from properties file");
                                string = "DataBaseEventsMGT";
                            }
                            this.dataContainerEventsMGT = (YP_TCD_DCC_DataBaseEventsMGT)this.newPluginByName(string, new Object[0]);
                            if (this.dataContainerEventsMGT != null) break block18;
                            this.logger(2, "initialize() Unable to find " + string);
                            return -1;
                        }
                        string = this.getProperty(this.getPropertyFileName(), "dataContainerEventsMGTProperties");
                        if (string != null) break block19;
                        this.logger(2, "initialize() Unable to get dataContainerEventsMGTProperties from properties file");
                        return -1;
                    }
                    this.dataContainerEventsMGT.setPropertyFileName(string);
                    string = this.getProperty(this.getPropertyFileName(), "dataContainerTechniqueName");
                    if (string != null) break block20;
                    this.logger(2, "initialize() Unable to get dataContainerTechniqueName from properties file");
                    return -1;
                }
                this.dataContainerTechnique = (YP_TCD_DCC_Technique)this.newPluginByName(string, new Object[0]);
                if (this.dataContainerTechnique != null) break block21;
                this.logger(2, "initialize() Unable to find " + string);
                return -1;
            }
            string = this.getProperty(this.getPropertyFileName(), "dataContainerTechniqueProperties");
            if (string != null) break block22;
            this.logger(2, "initialize() Unable to get dataContainerTechniqueProperties from properties file");
            return -1;
        }
        try {
            YP_TCD_DCC_DataBaseEvents yP_TCD_DCC_DataBaseEvents;
            this.dataContainerTechnique.setPropertyFileName(string);
            this.dataContainerStatus.initialize();
            this.dataContainerTechnique.initialize();
            this.dataContainerEventsMGT.initialize();
            List<YP_TCD_DataBaseConnector> list = this.dataContainerTechnique.getDataBaseConnectorListForEvent();
            string = this.getProperty(this.getPropertyFileName(), "dataContainerEventsAPPName");
            if (string == null) {
                string = "DataBaseEventsAPP";
            }
            for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : list) {
                if (yP_TCD_DataBaseConnector.getSiteIdentifier() != UtilsYP.getInstanceNumber() || (yP_TCD_DCC_DataBaseEvents = (YP_TCD_DCC_DataBaseEventsAPP)this.newPluginByName(string, new Object[0])) == null) continue;
                yP_TCD_DCC_DataBaseEvents.setDataBaseConnector(yP_TCD_DataBaseConnector);
                yP_TCD_DCC_DataBaseEvents.getDataBaseConnector().initialize();
                ((YP_TCD_DCC_DataBaseEventsAPP)yP_TCD_DCC_DataBaseEvents).initialize();
                this.dataContainerEventsAppList.add((YP_TCD_DCC_DataBaseEventsAPP)yP_TCD_DCC_DataBaseEvents);
            }
            if (UtilsYP.getInstanceRole() == 1 && (string = this.getProperty(this.getPropertyFileName(), "dataContainerEventsSlaveName")) != null) {
                for (YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector : list) {
                    if (yP_TCD_DataBaseConnector.getSiteIdentifier() == UtilsYP.getInstanceNumber() || (yP_TCD_DCC_DataBaseEvents = (YP_TCD_DCC_DataBaseEventsSlaveTRS)this.newPluginByName(string, new Object[0])) == null) continue;
                    yP_TCD_DCC_DataBaseEvents.setDataBaseConnector(yP_TCD_DataBaseConnector);
                    yP_TCD_DCC_DataBaseEvents.getDataBaseConnector().initialize();
                    ((YP_TCD_DCC_DataBaseEventsSlaveTRS)yP_TCD_DCC_DataBaseEvents).initialize();
                    this.dataContainerEventsSlaveTRSList.add((YP_TCD_DCC_DataBaseEventsSlaveTRS)yP_TCD_DCC_DataBaseEvents);
                }
            }
            this.getDataContainerTechnique().loadMasterApplications();
            this.getDataContainerTechnique().loadGroups();
            this.getDataContainerTechnique().loadBrands();
            this.getDataContainerTechnique().loadMerchants();
            return this.getDataContainerTechnique().loadContracts();
        }
        catch (Exception exception) {
            this.logger(2, "initialize() ", exception);
            return -1;
        }
    }

    private void logInitialisationParameters() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(UtilsYP.lineSeparator);
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : this.contractList.values()) {
                YP_Row yP_Row = yP_TCD_DCC_Business.getInitialisationRow();
                if (yP_Row == null) continue;
                stringBuilder.append(yP_Row.getFather().getFullTableName());
                stringBuilder.append(',');
                stringBuilder.append(yP_Row.serialize());
            }
            this.logger(3, "logInitialisationParameters() " + stringBuilder.toString());
        }
        catch (ConcurrentModificationException concurrentModificationException) {
            this.logger(2, "logInitialisationParameters() Won't be done today as changes just have been done... :", concurrentModificationException);
        }
        catch (Exception exception) {
            this.logger(2, "logInitialisationParameters() ", exception);
        }
    }

    private int dealNotifications() {
        try {
            int n = 0;
            int n2 = this.getChildNB();
            int n3 = 0;
            while (n3 < n2) {
                YP_Object yP_Object = this.getChildByRank(n3);
                if (yP_Object instanceof YP_TCD_DataContainer) {
                    int n4;
                    while ((n4 = ((YP_TCD_DataContainer)yP_Object).getNotification()) > 0) {
                        ++n;
                        YP_Object yP_Object2 = this.componentManager.getChildByProcessID(n4);
                        if (yP_Object2 == null || !(yP_Object2 instanceof YP_TCD_DesignAccesObject)) continue;
                        ((YP_TCD_DataContainer)yP_Object).onChange((YP_TCD_DesignAccesObject)yP_Object2);
                    }
                }
                ++n3;
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "dealNotifications() ", exception);
            return -1;
        }
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis() + 3600000L;
        boolean bl = false;
        do {
            block17: {
                this.iAmAlive();
                if (!bl) {
                    UtilsYP.sleep(30000);
                    this.iAmAlive();
                }
                bl = false;
                try {
                    try {
                        if (System.currentTimeMillis() >= l) {
                            if (UtilsYP.getTableStructureMode() == 1) {
                                this.logInitialisationParametersWithApplicationStructure();
                            } else {
                                this.logInitialisationParameters();
                            }
                            l = System.currentTimeMillis() + 86400000L;
                        }
                        this.dealNotifications();
                        this.lock();
                        this.flushPendingTransactions();
                        int n = this.flushAllCachedTables();
                        if (n > 0) {
                            this.logger(4, "run() Nb trs flushed :" + Integer.toString(n));
                        }
                        if (this.dataContainerEventsMGT.isThereManagementChanges()) {
                            this.dataContainerEventsMGT.reLoadManagement();
                            bl = true;
                        }
                        int n2 = 0;
                        while (n2 < this.dataContainerEventsAppList.size()) {
                            if (this.dataContainerEventsAppList.get(n2).isThereApplicationChanges() && !this.dataContainerEventsMGT.isThereManagementChanges()) {
                                if (this.getLogLevel() >= 5) {
                                    this.logger(5, " something found");
                                }
                                this.dataContainerEventsAppList.get(n2).reLoadContracts();
                                bl = true;
                            }
                            ++n2;
                        }
                        n2 = 0;
                        while (n2 < this.dataContainerEventsSlaveTRSList.size()) {
                            if (this.dataContainerEventsSlaveTRSList.get(n2).isThereSlaveTransaction()) {
                                this.dataContainerEventsSlaveTRSList.get(n2).updateTransactions();
                                bl = true;
                            }
                            ++n2;
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "run()", exception);
                        UtilsYP.sleep(10000);
                        this.unlock();
                        break block17;
                    }
                }
                catch (Throwable throwable) {
                    this.unlock();
                    throw throwable;
                }
                this.unlock();
            }
            this.iAmAlive();
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    private void flushAllCachedTablesOnShutdown() {
        System.out.println("start flushing tables");
        this.flushAllCachedTables();
        System.out.println("flushing tables done");
    }

    public int flushAllCachedTables() {
        int n = 0;
        int n2 = this.getChildNB();
        int n3 = 0;
        while (n3 < n2) {
            YP_Object yP_Object = this.getChildByRank(n3);
            if (yP_Object instanceof YP_TCD_DataContainer) {
                this.iAmAlive();
                n += ((YP_TCD_DataContainer)yP_Object).flushCachedTables();
            }
            ++n3;
        }
        return n;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private List<YP_TCD_DCC_Business> getDataContainerList(YP_Transaction var1_1, String var2_2, String var3_3) {
        block29: {
            var4_4 = new ArrayList<YP_TCD_DCC_Business>();
            if (var2_2.endsWith("_")) {
                this.logger(2, "getDataContainerList() Bad identifier:" + var2_2);
            }
            var5_5 = var2_2.split("_");
            try {
                block31: {
                    block33: {
                        block32: {
                            block30: {
                                if (var5_5.length != 1) break block30;
                                if (var3_3 != null && !var3_3.isEmpty()) {
                                    this.logger(2, "getDataContainerList() storeId with a brand !!! contractIdentifier & storeIdentifier" + var2_2 + " " + var3_3);
                                }
                                if (var5_5[0].contentEquals("KERNEL")) {
                                    var4_4.addAll(this.contractList.values());
                                    return var4_4;
                                }
                                if (!var5_5[0].startsWith("GROUP")) break block29;
                                var6_6 = var5_5[0].substring("GROUP".length());
                                var6_6 = UtilsYP.decryptInfo((String)var6_6);
                                if (var1_1.getDataContainerTransaction().contextHandler.groupContainers == null) break block29;
                                var8_12 = var1_1.getDataContainerTransaction().contextHandler.groupContainers.iterator();
                                if (true) ** GOTO lbl151
                            }
                            if (var3_3 == null || var3_3.isEmpty()) break block31;
                            var6_7 = this.brandList.get(var5_5[0]);
                            if (var6_7 == null) {
                                this.logger(2, "getDataContainerList() unable to retrieve brand :" + var2_2);
                                if (var1_1 == null) return var4_4;
                                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                                return var4_4;
                            }
                            var7_18 = String.valueOf(var5_5[0]) + '_' + var5_5[1];
                            var8_13 = this.merchantList.get(var7_18);
                            if (var8_13 == null) {
                                this.logger(2, "getDataContainerList() unable to retrieve brand :" + var2_2);
                                if (var1_1 == null) return var4_4;
                                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                                return var4_4;
                            }
                            var9_21 = var6_7.getIdContractList(var8_13.getMerchantRow().getPrimaryKey(), var3_3);
                            if (var9_21 == null) {
                                this.logger(2, "getDataContainerList() unable to retrieve contract list :" + var2_2 + " " + var3_3);
                                if (var1_1 == null) return var4_4;
                                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(80));
                                return var4_4;
                            }
                            if (var9_21.isEmpty()) {
                                this.logger(2, "getDataContainerList() no contract list :" + var7_18 + " " + var2_2);
                                if (var1_1 == null) return var4_4;
                                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(81));
                                return var4_4;
                            }
                            if (var5_5.length != 4) break block32;
                            var10_23 = this.contractList.get(var2_2);
                            if (var10_23 == null) {
                                this.logger(2, "getDataContainerList() unknown contract :" + var2_2);
                                if (var1_1 == null) return var4_4;
                                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                                return var4_4;
                            }
                            var13_34 = var9_21.iterator();
                            if (true) ** GOTO lbl172
                        }
                        if (var5_5.length != 3) break block33;
                        var10_24 = new HashSet<Long>();
                        var2_2 = var2_2.concat("_");
                        var12_31 = var8_13.dataContainerBusinessList.iterator();
                        if (true) ** GOTO lbl178
                    }
                    var12_32 = var9_21.iterator();
                    if (true) ** GOTO lbl189
                }
                if (var5_5.length == 2) {
                    var6_8 = this.merchantList.get(var2_2);
                    if (var6_8 != null) {
                        var4_4.addAll(var6_8.dataContainerBusinessList);
                        return var4_4;
                    }
                    this.logger(2, "getDataContainerList() unknown merchant :" + var2_2);
                    if (var1_1 == null) return var4_4;
                    YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                    return var4_4;
                }
                if (var5_5.length == 4) {
                    var6_9 = this.contractList.get(var2_2);
                    if (var6_9 != null) {
                        var4_4.add(var6_9);
                        return var4_4;
                    }
                    this.logger(2, "getDataContainerList() unknown contract :" + var2_2);
                    if (var1_1 == null) return var4_4;
                    YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                    return var4_4;
                }
                if (var5_5.length != 3) {
                    this.logger(2, "getDataContainerList() Bad identifiers:" + var2_2 + " " + var3_3);
                    if (var1_1 == null) return var4_4;
                    YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                    return var4_4;
                }
                var6_10 = this.merchantList.get(String.valueOf(var5_5[0]) + '_' + var5_5[1]);
                if (var6_10 == null) {
                    this.logger(2, "getDataContainerList() unknown merchant :" + var2_2);
                    if (var1_1 == null) return var4_4;
                    YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
                    return var4_4;
                }
                var2_2 = var2_2.concat("_");
                var8_14 = var6_10.dataContainerBusinessList.iterator();
                while (true) {
                    if (!var8_14.hasNext()) {
                        return var4_4;
                    }
                    var7_19 = var8_14.next();
                    if (!var7_19.getContractIdentifier().startsWith(var2_2)) continue;
                    var4_4.add(var7_19);
                }
            }
            catch (Exception var6_11) {
                this.logger(2, "getDataContainerList() ", var6_11);
                if (var1_1 == null) return null;
                YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(4));
                return null;
            }
            do {
                if (!var6_6.contentEquals((var7_15 = (YP_TCD_DCC_Group)var8_12.next()).getGroupName())) continue;
                if (var1_1.getDataContainerTransaction().userHandler.getUserIdentifier() <= 0L) {
                    this.logger(2, "getDataContainerList() sur un groupe sans user ???");
                    return null;
                }
                var9_20 = (YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager");
                var10_22 = var9_20.getDataContainerTechnique();
                var11_26 = var10_22.getIdBrandListByGroup(var7_15.getIDGroup());
                if (var11_26 == null || var11_26.isEmpty()) {
                    this.logger(2, "getMerchantList() Nothing for group " + var7_15.getGroupName());
                    continue;
                }
                for (YP_TCD_DCC_Brand var12_30 : var1_1.getDataContainerTransaction().contextHandler.brandContainers) {
                    for (YP_TCD_DCC_Merchant var14_37 : var12_30.dataContainerMerchantList) {
                        var4_4.addAll(var14_37.dataContainerBusinessList);
                    }
                }
lbl151:
                // 4 sources

            } while (var8_12.hasNext());
        }
        if (var4_4.isEmpty() == false) return var4_4;
        var6_6 = this.brandList.get(var2_2);
        if (var6_6 == null) {
            this.logger(2, "getDataContainerList() unknown brand :" + var2_2);
            if (var1_1 == null) return var4_4;
            YP_TCD_DCC_Business.setGlobalResult(var1_1.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(var1_1.getDataContainerTransaction(), new ExtendedResult(7));
            return var4_4;
        }
        for (YP_TCD_DCC_Merchant var7_17 : var6_6.dataContainerMerchantList) {
            var4_4.addAll(var7_17.dataContainerBusinessList);
        }
        return var4_4;
        do {
            if ((var11_27 = var13_34.next().longValue()) != var10_23.getIDContract()) continue;
            var4_4.add(var10_23);
            return var4_4;
lbl172:
            // 2 sources

        } while (var13_34.hasNext());
        return var4_4;
        do {
            if (!(var11_28 = var12_31.next()).getContractIdentifier().startsWith(var2_2)) continue;
            var10_24.add(var11_28.getIDContract());
lbl178:
            // 3 sources

        } while (var12_31.hasNext());
        for (long var11_29 : var9_21) {
            if (!var10_24.contains(var11_29) || (var14_38 = this.contractListByID.get(var11_29)) == null) continue;
            var4_4.add(var14_38);
        }
        return var4_4;
        do {
            if ((var13_36 = this.contractListByID.get(var10_25 = var12_32.next().longValue())) == null) continue;
            var4_4.add(var13_36);
lbl189:
            // 3 sources

        } while (var12_32.hasNext());
        return var4_4;
    }

    private YP_TCD_DataContainer getDataContainer(String string) {
        String[] stringArray = string.split("_");
        if (stringArray.length == 1) {
            return this.brandList.get(string);
        }
        if (stringArray.length == 2) {
            return this.merchantList.get(string);
        }
        if (stringArray.length == 4) {
            return this.contractList.get(string);
        }
        if (this.getLogLevel() >= 2) {
            this.logger(2, "getDataContainer() Bad identifier:" + string);
        }
        return null;
    }

    private YP_TCD_DCC_Group getDataContainerGroup(String string) {
        try {
            return this.groupList.get(string);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerGroup() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Group getDataContainerGroup(long l) {
        try {
            return this.groupListByID.get(l);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerGroup() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Brand getDataContainerBrand(String string) {
        try {
            if (string.indexOf("_") == -1) {
                return this.brandList.get(string);
            }
            String[] stringArray = string.split("_");
            return this.brandList.get(stringArray[0]);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerBrand() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Brand getDataContainerBrand(long l) {
        try {
            return this.brandListByID.get(l);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerBrand() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Business getDataContainerBusiness(long l) {
        try {
            return this.contractListByID.get(l);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerBusiness() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Business getDataContainerBusiness(String string) {
        try {
            return this.contractList.get(string);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerBusiness() ", exception);
            return null;
        }
    }

    private YP_TCD_DCC_Merchant getDataContainerMerchant(String string) {
        int n;
        block10: {
            block9: {
                try {
                    n = 0;
                    int n2 = 0;
                    while (n2 < string.length()) {
                        if (string.charAt(n2) == '_') {
                            ++n;
                        }
                        ++n2;
                    }
                    if (n != 0) break block9;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "getDataContainerMerchant() Bad identifier:" + string);
                    }
                    return null;
                }
                catch (Exception exception) {
                    this.logger(2, "getDataContainerMerchant() ", exception);
                    return null;
                }
            }
            if (n <= 3) break block10;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getDataContainerMerchant() Bad identifier:" + string);
            }
            return null;
        }
        if (n == 1) {
            return this.merchantList.get(string);
        }
        String[] stringArray = string.split("_");
        return this.merchantList.get(String.valueOf(stringArray[0]) + '_' + stringArray[1]);
    }

    private YP_TCD_DCC_Merchant getDataContainerMerchant(long l) {
        try {
            return this.merchantListByID.get(l);
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerMerchant() ", exception);
            return null;
        }
    }

    private int synchronizeSlaveTransactions(YP_TCD_DC_Context yP_TCD_DC_Context) {
        int n = 0;
        int n2 = 0;
        while (n2 < this.dataContainerEventsSlaveTRSList.size()) {
            int n3 = this.dataContainerEventsSlaveTRSList.get(n2).updateTransactions(yP_TCD_DC_Context);
            if (n3 == 1) {
                n = 1;
            }
            if (n3 < 0) {
                this.logger(2, "synchronizeSlaveTransactions() ");
            }
            ++n2;
        }
        try {
            if (yP_TCD_DC_Context.getContractIdentifier().indexOf("Token") == -1) {
                YP_Service yP_Service = (YP_Service)this.getPluginByName("TokenManager");
                yP_Service.dealRequest(this, "synchronize", new Object[0]);
            }
        }
        catch (Exception exception) {
            this.logger(2, "synchronizeSlaveTransactions() synchronize token", exception);
            return -1;
        }
        return n;
    }

    private int addOneGroup(YP_TCD_DCC_Group yP_TCD_DCC_Group) {
        this.groupList.put(yP_TCD_DCC_Group.getGroupName(), yP_TCD_DCC_Group);
        this.groupListByID.put(yP_TCD_DCC_Group.getIDGroup(), yP_TCD_DCC_Group);
        return this.addChild(yP_TCD_DCC_Group);
    }

    private int addOneBrand(YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        this.brandList.put(yP_TCD_DCC_Brand.getContractIdentifier(), yP_TCD_DCC_Brand);
        this.brandListByID.put(yP_TCD_DCC_Brand.getIDBrand(), yP_TCD_DCC_Brand);
        return this.addChild(yP_TCD_DCC_Brand);
    }

    private int addOneMerchant(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant) {
        this.merchantList.put(yP_TCD_DCC_Merchant.getContractIdentifier(), yP_TCD_DCC_Merchant);
        this.merchantListByID.put(yP_TCD_DCC_Merchant.getIDMerchant(), yP_TCD_DCC_Merchant);
        return this.addChild(yP_TCD_DCC_Merchant);
    }

    private int addOneContract(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        this.contractList.put(yP_TCD_DCC_Business.getContractIdentifier(), yP_TCD_DCC_Business);
        this.contractListByID.put(yP_TCD_DCC_Business.getIDContract(), yP_TCD_DCC_Business);
        return this.addChild(yP_TCD_DCC_Business);
    }

    private int removeOneContract(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        this.contractList.remove(yP_TCD_DCC_Business.getContractIdentifier());
        this.contractListByID.remove(yP_TCD_DCC_Business.getIDContract());
        return this.removeChildByID(yP_TCD_DCC_Business.getProcessID());
    }

    public int reload(YP_Object yP_Object) {
        try {
            this.lock();
            int n = 0;
            while (n < this.dataContainerEventsAppList.size()) {
                this.dataContainerEventsAppList.get(n).reLoadContracts();
                ++n;
            }
            this.dataContainerEventsMGT.reLoadManagement();
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "reload() ", exception);
            return -1;
        }
        finally {
            this.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getDataContainerList")) {
                if (objectArray == null || objectArray.length != 3 || !(objectArray[1] instanceof String)) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainerList");
                    return null;
                }
                if (objectArray[0] != null && !(objectArray[0] instanceof YP_Transaction)) {
                    this.logger(2, "dealRequest() bad parameter 3 for getDataContainerList");
                    return null;
                }
                YP_Transaction yP_Transaction = (YP_Transaction)objectArray[0];
                String string2 = (String)objectArray[1];
                if (objectArray[2] != null && !(objectArray[2] instanceof String)) {
                    this.logger(2, "dealRequest() bad parameter 3 for getDataContainerList");
                    return null;
                }
                String string3 = (String)objectArray[2];
                return this.getDataContainerList(yP_Transaction, string2, string3);
            }
            if (string.contentEquals("getDataContainer")) {
                if (objectArray == null || objectArray.length != 1) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainer");
                    return null;
                }
                if (objectArray[0] instanceof String) {
                    String string4 = (String)objectArray[0];
                    return this.getDataContainer(string4);
                }
                this.logger(2, "dealRequest() bad parameter 1 for getDataContainer");
                return null;
            }
            if (string.contentEquals("getDataContainerGroup")) {
                if (objectArray == null || objectArray.length != 1) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainerGroup");
                    return null;
                }
                if (objectArray[0] instanceof String) {
                    String string5 = (String)objectArray[0];
                    return this.getDataContainerGroup(string5);
                }
                if (objectArray[0] instanceof Long) {
                    Long l = (Long)objectArray[0];
                    return this.getDataContainerGroup(l);
                }
                this.logger(2, "dealRequest() bad parameter 1 for getDataContainerGroup");
                return null;
            }
            if (string.contentEquals("getDataContainerBrand")) {
                if (objectArray == null || objectArray.length != 1) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainerBrand");
                    return null;
                }
                if (objectArray[0] instanceof String) {
                    String string6 = (String)objectArray[0];
                    return this.getDataContainerBrand(string6);
                }
                if (objectArray[0] instanceof Long) {
                    Long l = (Long)objectArray[0];
                    return this.getDataContainerBrand(l);
                }
                this.logger(2, "dealRequest() bad parameter 1 for getDataContainerBrand");
                return null;
            }
            if (string.contentEquals("getDataContainerBusiness")) {
                if (objectArray == null || objectArray.length != 1) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainerBusiness");
                    return null;
                }
                if (objectArray[0] instanceof String) {
                    String string7 = (String)objectArray[0];
                    return this.getDataContainerBusiness(string7);
                }
                if (objectArray[0] instanceof Long) {
                    Long l = (Long)objectArray[0];
                    return this.getDataContainerBusiness(l);
                }
                this.logger(2, "dealRequest() bad parameter 1 for getDataContainerBusiness");
                return null;
            }
            if (string.contentEquals("getDataContainerBrandList")) {
                return new ArrayList<YP_TCD_DCC_Brand>(this.brandList.values());
            }
            if (string.contentEquals("getDataContainerGroupList")) {
                return new ArrayList<YP_TCD_DCC_Group>(this.groupList.values());
            }
            if (string.contentEquals("getDataContainerMerchant")) {
                if (objectArray == null || objectArray.length != 1) {
                    this.logger(2, "dealRequest() bad parameters for getDataContainerMerchant");
                    return null;
                }
                if (objectArray[0] instanceof String) {
                    String string8 = (String)objectArray[0];
                    return this.getDataContainerMerchant(string8);
                }
                if (objectArray[0] instanceof Long) {
                    Long l = (Long)objectArray[0];
                    return this.getDataContainerMerchant(l);
                }
                this.logger(2, "dealRequest() bad parameter 1 for getDataContainerMerchant");
                return null;
            }
            if (string.contentEquals("synchronizeSlaveTransactions")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DC_Context) {
                    YP_TCD_DC_Context yP_TCD_DC_Context = (YP_TCD_DC_Context)objectArray[0];
                    return this.synchronizeSlaveTransactions(yP_TCD_DC_Context);
                }
                this.logger(2, "dealRequest() bad parameters for synchronizeSlaveTransactions");
                return null;
            }
            if (string.contentEquals("reload")) {
                if (objectArray != null && objectArray.length == 0) {
                    return this.reload(yP_Object);
                }
                this.logger(2, "dealRequest() bad parameters for reload");
                return null;
            }
            if (string.contentEquals("addOneGroup")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Group) {
                    YP_TCD_DCC_Group yP_TCD_DCC_Group = (YP_TCD_DCC_Group)objectArray[0];
                    return this.addOneGroup(yP_TCD_DCC_Group);
                }
                this.logger(2, "dealRequest() bad parameters for addOneGroup");
                return null;
            }
            if (string.contentEquals("addOneBrand")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Brand) {
                    YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)objectArray[0];
                    return this.addOneBrand(yP_TCD_DCC_Brand);
                }
                this.logger(2, "dealRequest() bad parameters for addOneBrand");
                return null;
            }
            if (string.contentEquals("addOneMerchant")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Merchant) {
                    YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)objectArray[0];
                    return this.addOneMerchant(yP_TCD_DCC_Merchant);
                }
                this.logger(2, "dealRequest() bad parameters for addOneMerchant");
                return null;
            }
            if (string.contentEquals("addOneContract")) {
                if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Business) {
                    YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)objectArray[0];
                    return this.addOneContract(yP_TCD_DCC_Business);
                }
                this.logger(2, "dealRequest() bad parameters for addOneContract");
                return null;
            }
            if (!string.contentEquals("removeOneContract")) {
                this.logger(2, "dealRequest() request unknown " + string);
                return null;
            }
            if (objectArray != null && objectArray.length == 1 && objectArray[0] instanceof YP_TCD_DCC_Business) {
                YP_TCD_DCC_Business yP_TCD_DCC_Business = (YP_TCD_DCC_Business)objectArray[0];
                return this.removeOneContract(yP_TCD_DCC_Business);
            }
            this.logger(2, "dealRequest() bad parameters for removeOneContract");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :", exception);
            return null;
        }
    }

    public void setDataContainerTechnique(YP_TCD_DCC_Technique yP_TCD_DCC_Technique) {
        this.dataContainerTechnique = yP_TCD_DCC_Technique;
    }

    public YP_TCD_DCC_Technique getDataContainerTechnique() {
        return this.dataContainerTechnique;
    }

    public YP_TCD_DCC_Status getDataContainerStatus() {
        return this.dataContainerStatus;
    }

    private void logInitialisationParametersWithApplicationStructure() {
        if (UtilsYP.getTableStructureMode() != 1) {
            return;
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(UtilsYP.lineSeparator);
            HashMap<String, YP_TCD_DCC_Business> hashMap = new HashMap<String, YP_TCD_DCC_Business>();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : this.contractList.values()) {
                if (yP_TCD_DCC_Business.initialisationParameters == null) continue;
                stringBuilder.append(yP_TCD_DCC_Business.getContractIdentifier());
                stringBuilder.append(',');
                stringBuilder.append(yP_TCD_DCC_Business.getIDContract());
                stringBuilder.append(UtilsYP.lineSeparator);
                hashMap.put(yP_TCD_DCC_Business.initialisationParameters.getFullTableName(), yP_TCD_DCC_Business);
            }
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : hashMap.values()) {
                this.iAmAlive();
                this.dealOneDesignAccesObject(stringBuilder, yP_TCD_DCC_Business.initialisationParameters);
            }
            this.logger(3, "logInitialisationParametersWithApplicationStructure() " + stringBuilder.toString());
        }
        catch (Exception exception) {
            this.logger(2, "logInitialisationParametersWithApplicationStructure() ", exception);
        }
    }

    private void dealOneDesignAccesObject(StringBuilder stringBuilder, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            Field[] fieldArray = yP_TCD_DesignAccesObject.getFieldList();
            String string = yP_TCD_DesignAccesObject.getFullTableName();
            DumpObject dumpObject = new DumpObject(yP_TCD_DesignAccesObject);
            int n = 0;
            while (dumpObject.getRowPack() == 1) {
                stringBuilder.append(' ');
                stringBuilder.append(++n);
                stringBuilder.append("'\r\nGO\r\nINSERT INTO ");
                stringBuilder.append(string);
                stringBuilder.append('(');
                boolean bl = true;
                Object object = fieldArray;
                int n2 = fieldArray.length;
                int n3 = 0;
                while (n3 < n2) {
                    Field field = object[n3];
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(',');
                    }
                    YP_TS_DataContainerManager.appendSQLColumnName(stringBuilder, field.getName());
                    ++n3;
                }
                stringBuilder.append(") VALUES ");
                int n4 = dumpObject.rowList.size();
                n3 = 0;
                while (n3 < n4) {
                    if (n3 != 0) {
                        stringBuilder.append(',');
                    }
                    stringBuilder.append("\t\r\n");
                    YP_Row yP_Row = dumpObject.rowList.get(n3);
                    stringBuilder.append('(');
                    bl = true;
                    Field[] fieldArray2 = fieldArray;
                    int n5 = fieldArray.length;
                    int n6 = 0;
                    while (n6 < n5) {
                        object = fieldArray2[n6];
                        if (bl) {
                            bl = false;
                        } else {
                            stringBuilder.append(',');
                        }
                        this.appendSQLValue(stringBuilder, yP_Row.getFieldValue((Field)object));
                        ++n6;
                    }
                    stringBuilder.append(')');
                    ++n3;
                }
                stringBuilder.append("\r\n");
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealOneDesignAccesObject() ", exception);
        }
    }

    private int appendSQLValue(StringBuilder stringBuilder, Object object) {
        String string = YP_Row.getStringValue(object);
        if (string == null) {
            stringBuilder.append("null");
            return 1;
        }
        string = string.trim();
        if (object instanceof Integer) {
            stringBuilder.append(string);
        } else if (object instanceof Long) {
            stringBuilder.append(string);
        } else if (object instanceof byte[] || object instanceof String || object instanceof Enum) {
            stringBuilder.append('\'');
            if (string.indexOf("'") != -1) {
                string = string.replace("'", "''");
            }
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Timestamp) {
            stringBuilder.append('\'');
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Date) {
            stringBuilder.append('\'');
            stringBuilder.append(string);
            stringBuilder.append('\'');
        } else if (object instanceof Float) {
            stringBuilder.append(string);
        } else if (object instanceof Boolean) {
            if (((Boolean)object).booleanValue()) {
                stringBuilder.append("1");
            } else if (!((Boolean)object).booleanValue()) {
                stringBuilder.append("0");
            }
        } else if (object instanceof Bitmap) {
            stringBuilder.append(string);
        } else if (object == null) {
            stringBuilder.append("null");
        } else {
            this.logger(2, "appendSQLValue() : unknown type ");
            return -1;
        }
        return 1;
    }

    private static void appendSQLColumnName(StringBuilder stringBuilder, String string) {
        stringBuilder.append('[');
        stringBuilder.append(string);
        stringBuilder.append(']');
    }

    private void flushPendingTransactions() {
        try {
            long l = System.currentTimeMillis();
            for (Map.Entry<String, YP_TCD_DCC_Merchant> entry : this.merchantList.entrySet()) {
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = entry.getValue();
                yP_TCD_DCC_Merchant.flushPendingTransactions(l);
            }
        }
        catch (Exception exception) {
            this.logger(2, "flushPendingTransactions()", exception);
        }
    }

    class DumpObject {
        YP_TCD_DesignAccesObject designAccessObject;
        int rowIndex = 0;
        List<YP_Row> rowList;
        private static final int NB_ROW_AT_ONE_TIME = 500;
        private final YP_ComplexGabarit complexGabarit;

        DumpObject(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
            this.designAccessObject = yP_TCD_DesignAccesObject;
            this.complexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            if (yP_TCD_DesignAccesObject.getFather() instanceof YP_TCD_DCC_EFT_Business) {
                this.complexGabarit.set("contractKey", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0L);
            }
        }

        private int getRowPack() {
            this.rowList = this.designAccessObject.getDataBaseConnector().sql_Formater.sqlSelectSuchAs(this.designAccessObject, this.rowIndex, 500, this.complexGabarit);
            if (this.rowList == null) {
                YP_TS_DataContainerManager.this.logger(2, "getRowPack()  null ...");
                return -1;
            }
            this.rowIndex += 500;
            if (this.rowList.isEmpty()) {
                if (YP_TS_DataContainerManager.this.getLogLevel() >= 6) {
                    YP_TS_DataContainerManager.this.logger(6, "getRowPack() No more rows");
                }
                return 0;
            }
            return 1;
        }
    }
}

