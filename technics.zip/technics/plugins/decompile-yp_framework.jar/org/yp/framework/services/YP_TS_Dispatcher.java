/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.sql.Timestamp;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;

public class YP_TS_Dispatcher
extends YP_Service {
    private final Map<String, String> dispatchList = new HashMap<String, String>();
    private final Map<String, Timestamp> lastReloadByBrandName = new HashMap<String, Timestamp>();
    private final Set<YP_TCD_DesignAccesObject> terminalListToReload = new HashSet<YP_TCD_DesignAccesObject>();
    private boolean dispatcherReady = false;
    public static final String DEFAULT_MERCHANT = "defaultMerchant";

    public YP_TS_Dispatcher(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public String toString() {
        return "Dispatcher";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        do {
            try {
                if (System.currentTimeMillis() >= l) {
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "run() It's time to reload the DispatchList");
                    }
                    this.reloadDispatchList();
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "run() dispatchList reloaded");
                    }
                    l = System.currentTimeMillis() + 86400000L;
                }
                this.iAmAlive();
                if (this.terminalListToReload.size() == 0) {
                    UtilsYP.sleep(10000);
                } else {
                    Iterator<YP_TCD_DesignAccesObject> iterator = this.terminalListToReload.iterator();
                    if (iterator.hasNext()) {
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = iterator.next();
                        if (yP_TCD_DesignAccesObject == null) {
                            iterator.remove();
                            UtilsYP.sleep(1000);
                        } else {
                            this.terminalListToReload.remove(yP_TCD_DesignAccesObject);
                            this.reloadOneTerminalList(yP_TCD_DesignAccesObject);
                        }
                    } else {
                        UtilsYP.sleep(8000);
                    }
                }
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run() ", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    private int reloadDispatchList() {
        try {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reloadDispatchList() start");
            }
            this.dispatcherReady = false;
            this.dispatchList.clear();
            this.lastReloadByBrandName.clear();
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)this.getChildByRank(n2);
                if (yP_TCD_DesignAccesObject != null) {
                    this.reloadOneTerminalList(yP_TCD_DesignAccesObject);
                }
                this.iAmAlive();
                ++n2;
            }
            this.dispatcherReady = true;
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reloadDispatchList() end ");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "reloadDispatchList() ", exception);
            return -1;
        }
    }

    private int addOneTerminalList(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        return this.addChild(yP_TCD_DesignAccesObject);
    }

    private int addTerminalListToReload(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            this.terminalListToReload.add(yP_TCD_DesignAccesObject);
            return 1;
        }
        catch (ConcurrentModificationException concurrentModificationException) {
            this.logger(3, "addTerminalListToReload() ignored ", concurrentModificationException);
        }
        catch (Exception exception) {
            this.logger(3, "addTerminalListToReload() ignored ", exception);
        }
        return 1;
    }

    private int reloadOneTerminalList(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        YP_TCD_DC_Context yP_TCD_DC_Context;
        block19: {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reloadOneTerminalList() start");
            }
            if ((yP_TCD_DC_Context = yP_TCD_DesignAccesObject.getDataContainerContext()) instanceof YP_TCD_DCC_Brand) break block19;
            this.logger(2, "reloadOneTerminalList() terminal data container is not a brand");
            return -1;
        }
        try {
            YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)yP_TCD_DC_Context;
            List<YP_Row> list = yP_TCD_DCC_Brand.getTerminalRowList(this.lastReloadByBrandName.get(yP_TCD_DCC_Brand.getBrandName()));
            if (list == null) {
                yP_TCD_DCC_Brand.logger(2, "reloadOneTerminalList() null list");
            } else if (list.isEmpty()) {
                yP_TCD_DCC_Brand.logger(4, "reloadOneTerminalList() nothing found");
            } else {
                Object object = null;
                for (YP_Row yP_Row : list) {
                    Object object2;
                    long l = (Long)yP_Row.getFieldValueByName("idMerchant");
                    if (l == 0L) {
                        yP_TCD_DCC_Brand.logger(4, "reloadOneTerminalList() terminal ignored:" + yP_Row.getFieldStringValueByName("idTerminalCan"));
                    } else {
                        object2 = (YP_TCD_DCC_Merchant)((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).dealRequest(this, "getDataContainerMerchant", l);
                        if (object2 == null) continue;
                        String string = ((YP_Object)object2).getContractIdentifier();
                        String string2 = this.getTerminalIdentifier(string, yP_Row);
                        if (string2 != null && !string2.isEmpty()) {
                            YP_TCD_DCC_Brand yP_TCD_DCC_Brand2 = ((YP_TCD_DCC_Merchant)object2).getDataContainerBrand();
                            if (yP_TCD_DCC_Brand2 == null || yP_TCD_DCC_Brand2 != yP_TCD_DCC_Brand) {
                                this.logger(2, "reloadOneTerminalList() idMerchant unauthorized here " + l);
                            } else {
                                String string3;
                                TerminalStatusEnumeration terminalStatusEnumeration = (TerminalStatusEnumeration)((Object)yP_Row.getFieldValueByName("terminalStatus"));
                                if (terminalStatusEnumeration == TerminalStatusEnumeration.DELETED) {
                                    string3 = this.dispatchList.remove(string2);
                                    if (string3 != null && !string3.contentEquals(string)) {
                                        this.dispatchList.put(string2, string3);
                                        this.logger(3, "reloadOneTerminalList() let's keep this one " + string2 + " " + string3);
                                    }
                                } else {
                                    YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant;
                                    string3 = this.dispatchList.put(string2, string);
                                    if (string3 != null && !string3.contentEquals(string) && !string.startsWith((yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).dealRequest(this, "getDataContainerMerchant", string3)).getDataContainerBrand().getBrandName())) {
                                        this.logger(3, "reloadOneTerminalList() differents merchantIdentifier for one terminalIdentifier " + string + " " + string3 + " " + string2);
                                    }
                                }
                            }
                        }
                    }
                    object2 = (Timestamp)yP_Row.getFieldValueByName("statusModificationGMTTime");
                    if (object != null && !((Timestamp)object2).after((Timestamp)object)) continue;
                    object = object2;
                }
                this.lastReloadByBrandName.put(yP_TCD_DCC_Brand.getBrandName(), (Timestamp)object);
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "reloadOneTerminalList() finished");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "reloadOneTerminalList()  ", exception);
            return -1;
        }
    }

    private String getTerminalIdentifier(String string, YP_Row yP_Row) {
        String string2 = yP_Row.getFieldStringValueByName("terminalManufacturerID");
        String string3 = yP_Row.getFieldStringValueByName("terminalSerialNumber");
        if (string3 == null || string3.isEmpty() || string2 == null || string2.isEmpty()) {
            this.logger(2, "getTerminalIdentifier() bad terminalManufacturerID/terminalSerialNumber :" + string + " " + string2 + "/" + string3);
            return null;
        }
        String string4 = String.valueOf(string2) + '_' + string3;
        return string4;
    }

    private String getMerchantIdentifier(String string) {
        Object object;
        List<YP_Row> list;
        if (!this.dispatcherReady) {
            this.logger(2, "getMerchantIdentifier() global DispatchList not ready");
            return null;
        }
        String string2 = this.dispatchList.get(string);
        if ((string2 == null || string2.isEmpty()) && (list = ((YP_TCD_DCC_Technique)(object = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique())).getUserParameters(0L, DEFAULT_MERCHANT)) != null && !list.isEmpty()) {
            string2 = list.get(0).getFieldStringValueByName("value");
        }
        if (string2 == null || string2.isEmpty()) {
            try {
                object = new File(".").getCanonicalPath();
                if (object != null && ((String)object).contains("127_M_CERTIFICAT")) {
                    return string;
                }
            }
            catch (Exception exception) {}
            this.logger(2, "getMerchantIdentifier() not found:" + string);
            return null;
        }
        return string2;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("getMerchantIdentifier")) {
                String string2 = (String)objectArray[0];
                return this.getMerchantIdentifier(string2);
            }
            if (string.contentEquals("reloadOneTerminalList")) {
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)objectArray[0];
                return this.reloadOneTerminalList(yP_TCD_DesignAccesObject);
            }
            if (string.contentEquals("addTerminalListToReload")) {
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)objectArray[0];
                return this.addTerminalListToReload(yP_TCD_DesignAccesObject);
            }
            if (string.contentEquals("addOneTerminalList")) {
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = (YP_TCD_DesignAccesObject)objectArray[0];
                return this.addOneTerminalList(yP_TCD_DesignAccesObject);
            }
            if (this.getLogLevel() >= 2) {
                this.logger(2, "dealRequest() request unknown " + string);
            }
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ???  :", exception);
            return null;
        }
    }
}

