/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.utils.UtilsYP;

public class YP_TS_ProcessLauncher
extends YP_Service {
    private long topForNewStatusMail = 0L;
    private static final int MIN_TIME_BETWEEN_STATUS_MAILS_MS = 300000;
    private int nbErrorStatusLoop = 0;
    private String emailForErrors = null;

    public YP_TS_ProcessLauncher(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "emailForErrors");
        if (string != null) {
            this.emailForErrors = string;
        }
        return 1;
    }

    @Override
    public String toString() {
        return "ProcessLauncher";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.34";
    }

    @Override
    public void run() {
        do {
            try {
                this.iAmAlive();
                UtilsYP.sleep(60000);
                this.iAmAlive();
                this.checkProcessStatus();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    void checkProcessStatus() {
        Object object;
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = true;
        int n = this.getChildNB();
        int n2 = 0;
        while (n2 < n) {
            YP_Object yP_Object = this.getChildByRank(n2);
            if (YP_Transaction.class.isInstance(yP_Object)) {
                object = (YP_Transaction)yP_Object;
                String string = ((YP_Object)object).getPreferredName();
                if (string == null || string.isEmpty()) {
                    string = ((YP_Object)object).getSimpleName();
                }
                stringBuilder.append(string);
                stringBuilder.append(',');
                stringBuilder.append(((YP_Object)object).getContractIdentifier());
                stringBuilder.append(':');
                if (!((YP_Process)object).is_YP_Thread_Alive()) {
                    stringBuilder.append("KO");
                    bl = false;
                } else {
                    stringBuilder.append("OK");
                }
                stringBuilder.append(" last TOP ");
                long l = (System.currentTimeMillis() - ((YP_Process)object).getWatchDogTimer()) / 1000L;
                stringBuilder.append(l);
                stringBuilder.append(" seconds ago");
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            ++n2;
        }
        if (bl) {
            this.nbErrorStatusLoop = 0;
        } else {
            YP_Process.getAllStackTraces(stringBuilder);
            this.logger(2, stringBuilder.toString());
            if (this.emailForErrors == null || this.emailForErrors.isEmpty()) {
                this.logger(3, "checkProcessStatus() no mail defined");
            } else {
                long l = System.currentTimeMillis();
                if (this.topForNewStatusMail > l) {
                    return;
                }
                this.topForNewStatusMail = l + 300000L + (long)(this.nbErrorStatusLoop * 60 * 1000);
                ++this.nbErrorStatusLoop;
                try {
                    object = "Process not responding " + this.getSrv() + " " + UtilsYP.getInstanceNumber();
                    this.getPluginByName("Mailer").dealRequest(this, "sendMail", this.emailForErrors, object, stringBuilder.toString());
                }
                catch (Exception exception) {
                    this.logger(2, "checkProcessStatus()", exception);
                }
            }
        }
    }

    public boolean startTransaction(String string, YP_Object yP_Object, String string2) {
        YP_Transaction yP_Transaction;
        try {
            yP_Transaction = (YP_Transaction)this.newPluginByName(string, yP_Object, string2);
            if (yP_Transaction == null) {
                this.logger(2, "dealRequest() " + string);
                return false;
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() ", exception);
            return false;
        }
        Thread thread = new Thread(yP_Transaction);
        yP_Transaction.setThreadID(thread.getId());
        int n = this.addChild(yP_Transaction, 1);
        if (n < 0) {
            this.logger(2, "No more space available...");
            return false;
        }
        thread.setName(String.valueOf(yP_Transaction.toString()) + "_" + n);
        thread.start();
        return true;
    }

    public final List<YP_Transaction> getTransactionListByContractIdentifier(String string) {
        ArrayList<YP_Transaction> arrayList = new ArrayList<YP_Transaction>();
        try {
            int n = this.getChildNB();
            int n2 = 0;
            while (n2 < n) {
                YP_Object yP_Object = this.getChildByRank(n2);
                if (yP_Object != null && yP_Object instanceof YP_Transaction && yP_Object.getContractIdentifier().contentEquals(string)) {
                    arrayList.add((YP_Transaction)yP_Object);
                }
                ++n2;
            }
            return arrayList;
        }
        catch (Exception exception) {
            this.logger(2, "getTransactionListByContractIdentifier() ", exception);
            return null;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("startTransaction")) {
                if (objectArray == null || objectArray.length != 3 || !(objectArray[0] instanceof String) || !(objectArray[1] instanceof YP_Object) || objectArray[2] != null && !(objectArray[2] instanceof String)) {
                    this.logger(2, "dealRequest() bad parameters for startTransaction");
                    return false;
                }
                String string2 = (String)objectArray[0];
                YP_Object yP_Object2 = (YP_Object)objectArray[1];
                String string3 = (String)objectArray[2];
                return this.startTransaction(string2, yP_Object2, string3);
            }
            if (string.contentEquals("getTransactionListByContractIdentifier")) {
                if (objectArray == null || objectArray.length != 1 || !(objectArray[0] instanceof String)) {
                    this.logger(2, "dealRequest() bad parameters for getTransactionListByContractIdentifier");
                    return false;
                }
                String string4 = (String)objectArray[0];
                return this.getTransactionListByContractIdentifier(string4);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :", exception);
            return null;
        }
    }

    private String getSrv() {
        try {
            String[] stringArray;
            String string = new File(".").getCanonicalPath();
            string = string.replace(File.separatorChar, '/');
            String[] stringArray2 = stringArray = string.split("/");
            int n = stringArray.length;
            int n2 = 0;
            while (n2 < n) {
                String string2 = stringArray2[n2];
                if (string2.indexOf("_M_") > 0 || string2.indexOf("_S_") > 0 || string2.indexOf("_T_") > 0) {
                    return string2;
                }
                ++n2;
            }
            return stringArray[stringArray.length - 1];
        }
        catch (Exception exception) {
            this.logger(2, "getSrv() ", exception);
            return "";
        }
    }
}

