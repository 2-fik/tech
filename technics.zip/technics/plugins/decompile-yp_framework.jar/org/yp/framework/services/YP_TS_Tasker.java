/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.util.ArrayList;
import java.util.List;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_TCD_DataContainer;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.utils.UtilsYP;

public class YP_TS_Tasker
extends YP_Service {
    private String taskName = null;
    private int frequencyInMS = 0;
    private String dataContainerName = null;
    private String[] splittedContract = null;

    public YP_TS_Tasker(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        this.setMaxChild(0);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "taskName");
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() mandatory parameter taskName missing");
            }
            return -1;
        }
        this.taskName = string;
        string = this.getProperty(this.getPropertyFileName(), "frequencyInMS");
        if (string == null || string.isEmpty()) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() mandatory parameter frequencyInMS missing");
            }
            return -1;
        }
        try {
            this.frequencyInMS = Integer.parseInt(string);
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialize() bad parameter frequencyInMS " + string);
            }
            return -1;
        }
        string = this.getProperty(this.getPropertyFileName(), "dataContainerName");
        if (string == null || string.isEmpty()) {
            this.logger(2, "initialize() mandatory parameter dataContainerName missing");
            return -1;
        }
        this.dataContainerName = string;
        this.splittedContract = this.dataContainerName.split("_");
        return 1;
    }

    private List<YP_TCD_DataContainer> getDataContainerList() {
        ArrayList<YP_TCD_DataContainer> arrayList;
        block14: {
            arrayList = null;
            boolean bl = false;
            int n = 0;
            while (n < this.splittedContract.length) {
                if ("*".contentEquals(this.splittedContract[n])) {
                    bl = true;
                    break;
                }
                ++n;
            }
            if (bl) break block14;
            return null;
        }
        try {
            ArrayList<YP_TCD_DCC_Brand> arrayList2;
            arrayList = new ArrayList<YP_TCD_DataContainer>();
            if ("*".contentEquals(this.splittedContract[0])) {
                arrayList2 = (ArrayList<YP_TCD_DCC_Brand>)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrandList", new Object[0]);
                if (arrayList2 == null) {
                    this.logger(2, "getDataContainerList() unable to get dataContainerBrandList");
                    return arrayList;
                }
            } else {
                YP_TCD_DCC_Brand yP_TCD_DCC_Brand = (YP_TCD_DCC_Brand)this.getPluginByName("DataContainerManager").dealRequest(this, "getDataContainerBrand", this.splittedContract[0]);
                if (yP_TCD_DCC_Brand == null) {
                    this.logger(2, "getDataContainerList() dataContainerBrandnot found for " + this.splittedContract[0]);
                    return arrayList;
                }
                arrayList2 = new ArrayList<YP_TCD_DCC_Brand>();
                arrayList2.add(yP_TCD_DCC_Brand);
            }
            for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : arrayList2) {
                for (YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant : yP_TCD_DCC_Brand.dataContainerMerchantList) {
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : yP_TCD_DCC_Merchant.dataContainerBusinessList) {
                        String[] stringArray = yP_TCD_DCC_Business.getContractIdentifier().split("_");
                        if (stringArray.length != this.splittedContract.length) continue;
                        boolean bl = true;
                        int n = 0;
                        while (n < this.splittedContract.length) {
                            if (!this.splittedContract[n].contentEquals("*") && !this.splittedContract[n].contentEquals(stringArray[n])) {
                                bl = false;
                                break;
                            }
                            ++n;
                        }
                        if (!bl) continue;
                        arrayList.add(yP_TCD_DCC_Business);
                    }
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainerList() " + exception);
        }
        return arrayList;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private YP_TCD_DataContainer getDataContainer() {
        try {
            String string;
            switch (this.splittedContract.length) {
                case 1: {
                    string = "getDataContainerBrand";
                    break;
                }
                case 2: {
                    string = "getDataContainerMerchant";
                    break;
                }
                case 3: 
                case 4: {
                    string = "getDataContainerBusiness";
                    break;
                }
                default: {
                    this.logger(2, "getDataContainer() bad parameter dataContainerName " + this.dataContainerName);
                    return null;
                }
            }
            YP_TCD_DataContainer yP_TCD_DataContainer = (YP_TCD_DataContainer)this.getPluginByName("DataContainerManager").dealRequest(this, string, this.dataContainerName);
            if (yP_TCD_DataContainer == null) {
                this.logger(2, "getDataContainer() no application for " + this.dataContainerName);
            }
            return yP_TCD_DataContainer;
        }
        catch (Exception exception) {
            this.logger(2, "getDataContainer()" + exception);
            return null;
        }
    }

    @Override
    public String toString() {
        return "Tasker";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        long l = System.currentTimeMillis();
        try {
            do {
                try {
                    if (System.currentTimeMillis() >= l) {
                        this.logger(4, "run()  It's time to do the task");
                        List<YP_TCD_DataContainer> list = this.getDataContainerList();
                        if (list != null) {
                            try {
                                for (YP_TCD_DataContainer yP_TCD_DataContainer : list) {
                                    yP_TCD_DataContainer.dealRequest(this, this.taskName, new Object[0]);
                                }
                            }
                            catch (Exception exception) {
                                this.logger(2, "run() during task" + exception);
                            }
                        } else {
                            YP_TCD_DataContainer yP_TCD_DataContainer;
                            yP_TCD_DataContainer = this.getDataContainer();
                            if (yP_TCD_DataContainer != null) {
                                try {
                                    yP_TCD_DataContainer.dealRequest(this, this.taskName, new Object[0]);
                                }
                                catch (Exception exception) {
                                    this.logger(2, "run() during task" + exception);
                                }
                            }
                        }
                        l = System.currentTimeMillis() + (long)this.frequencyInMS;
                    }
                    this.iAmAlive();
                    UtilsYP.sleep(this.frequencyInMS);
                    this.iAmAlive();
                }
                catch (Exception exception) {
                    this.logger(2, "run()", exception);
                    UtilsYP.sleep(10000);
                }
            } while (this.getObjectStatus() == 1);
            this.logger(3, "run() Stopped...");
            this.shutdown();
        }
        catch (Exception exception) {
            this.logger(2, "run()" + exception);
            return;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        try {
            List<YP_TCD_DataContainer> list = this.getDataContainerList();
            if (list != null) {
                Object object = null;
                for (YP_TCD_DataContainer yP_TCD_DataContainer : list) {
                    object = yP_TCD_DataContainer.dealRequest(yP_Object, string, objectArray);
                }
                return object;
            }
            YP_TCD_DataContainer yP_TCD_DataContainer = this.getDataContainer();
            if (yP_TCD_DataContainer != null) {
                return yP_TCD_DataContainer.dealRequest(yP_Object, string, objectArray);
            }
            this.logger(2, "dealRequest() no dataContainer");
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest()" + exception);
            return null;
        }
    }
}

