/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import java.io.File;
import java.util.Calendar;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.utils.UtilsYP;

public class YP_TS_LogManager
extends YP_Service {
    private int nbDaysOfLogs = 60;
    private int nbDaysOfTrs = 400;

    public YP_TS_LogManager(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "nbDaysOfLogs");
        if (string != null) {
            this.setNbDaysOfLogs(Integer.parseInt(string));
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "nbDaysOfTrs")) != null) {
            this.setNbDaysOfTrs(Integer.parseInt(string));
        }
        return 1;
    }

    @Override
    public String toString() {
        return "EventLoggerManager";
    }

    @Override
    public String getVersion() {
        return "V1.1.0.0";
    }

    private void deleteOldDirectory(String string, String string2) {
        block9: {
            File file = new File(string);
            File[] fileArray = file.listFiles();
            if (fileArray == null) {
                try {
                    file.mkdirs();
                    if (this.getLogLevel() >= 4) {
                        this.logger(4, "deleteOldDirectory() " + string + " created !!! ");
                    }
                }
                catch (Exception exception) {
                    if (this.getLogLevel() < 2) break block9;
                    this.logger(2, "deleteOldDirectory() " + string + " " + exception);
                }
            } else {
                int n = 0;
                while (n < fileArray.length) {
                    if (fileArray[n].isDirectory() && fileArray[n].getName().compareTo(string2) < 0) {
                        if (this.getLogLevel() >= 4) {
                            this.logger(4, "deleteOldDirectory() time to delete " + fileArray[n].getName());
                        }
                        if (!UtilsYP.deleteDirectory(fileArray[n]) && this.getLogLevel() >= 2) {
                            this.logger(2, "deleteOldDirectory() Unable to remove " + fileArray[n]);
                        }
                    }
                    ++n;
                }
            }
        }
    }

    @Override
    public void run() {
        int n = 0;
        do {
            try {
                this.getPluginByName("EventLogger").dealRequest(this, "flushLog", new Object[0]);
            }
            catch (Exception exception) {
                this.logger(2, "run() " + exception);
            }
            try {
                Calendar calendar = UtilsYP.getCalendar(System.currentTimeMillis());
                if (n != calendar.get(5)) {
                    n = calendar.get(5);
                    calendar.add(5, -this.getNbDaysOfLogs());
                    String string = String.format("%04d%02d%02d", calendar.get(1), calendar.get(2) + 1, calendar.get(5));
                    this.deleteOldDirectory(UtilsYP.getLogPath(), string);
                    this.deleteOldDirectory(UtilsYP.getErrorLogsPath(), string);
                    calendar.add(5, this.getNbDaysOfLogs() - this.getNbDaysOfTrs());
                    string = String.format("%04d%02d%02d", calendar.get(1), calendar.get(2) + 1, calendar.get(5));
                    this.deleteOldDirectory(UtilsYP.getTrsPath(), string);
                }
                this.iAmAlive();
                UtilsYP.sleep(5000);
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    public void setNbDaysOfLogs(int n) {
        this.nbDaysOfLogs = n;
    }

    public int getNbDaysOfLogs() {
        return this.nbDaysOfLogs;
    }

    public void setNbDaysOfTrs(int n) {
        this.nbDaysOfTrs = n;
    }

    public int getNbDaysOfTrs() {
        return this.nbDaysOfTrs;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }
}

