/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.services;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Service;
import org.yp.framework.ondemandcomponents.YP_TCD_ConnectionHandler;
import org.yp.framework.ondemandcomponents.physicals.YP_PHYS_Interface;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Com;
import org.yp.utils.UtilsYP;

public class YP_TS_Listener
extends YP_Service {
    private YP_TCD_ConnectionHandler connectionHandlerServer;
    private long shutdownTimeoutMS = 120000L;
    private String transactionHandlerName = null;
    private String dataContainerTransactionName = null;
    private String physicalInterfaceName = null;
    private String physicalInterfaceProperties = null;
    private String communicationInterfaceName = null;
    private String communicationInterfaceProperties = null;

    public YP_TS_Listener(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public int initialize() {
        super.initialize();
        String string = this.getProperty(this.getPropertyFileName(), "transactionHandlerName");
        if (string != null) {
            this.transactionHandlerName = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "dataContainerTransactionName")) != null) {
            this.dataContainerTransactionName = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "physicalInterfaceName")) != null) {
            this.physicalInterfaceName = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "physicalInterfaceProperties")) != null) {
            this.physicalInterfaceProperties = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "communicationInterfaceName")) != null) {
            this.communicationInterfaceName = string;
        }
        if ((string = this.getProperty(this.getPropertyFileName(), "communicationInterfaceProperties")) != null) {
            this.communicationInterfaceProperties = string;
        }
        this.connectionHandlerServer = (YP_TCD_ConnectionHandler)this.newPluginByName("ConnectionHandler", new Object[0]);
        if (this.connectionHandlerServer == null) {
            this.logger(2, "initialize() No connectionHandler for server");
            return -1;
        }
        YP_PHYS_Interface yP_PHYS_Interface = (YP_PHYS_Interface)((Object)this.connectionHandlerServer.newPluginByName(this.physicalInterfaceName, new Object[0]));
        if (yP_PHYS_Interface == null) {
            this.logger(2, "initialize() Unable to get physicalInterface " + this.physicalInterfaceName);
            return -1;
        }
        ((YP_Object)((Object)yP_PHYS_Interface)).setPropertyFileName(this.physicalInterfaceProperties);
        ((YP_Object)((Object)yP_PHYS_Interface)).initialize();
        this.connectionHandlerServer.setPhysicalInterface(yP_PHYS_Interface);
        if (this.communicationInterfaceName != null) {
            YP_PROT_Interface_Com yP_PROT_Interface_Com = (YP_PROT_Interface_Com)((Object)this.connectionHandlerServer.newPluginByName(this.communicationInterfaceName, yP_PHYS_Interface));
            if (yP_PROT_Interface_Com == null) {
                this.logger(2, "initialize() Unable to get protocolInterface " + this.communicationInterfaceName);
                return -1;
            }
            ((YP_Object)((Object)yP_PROT_Interface_Com)).setPropertyFileName(this.communicationInterfaceProperties);
            ((YP_Object)((Object)yP_PROT_Interface_Com)).initialize();
            this.connectionHandlerServer.setCommunicationInterface(yP_PROT_Interface_Com);
        }
        if (this.addChild(this.connectionHandlerServer, 1) < 0) {
            this.logger(2, "No more space available...");
            return 0;
        }
        return 1;
    }

    public boolean startTransaction(String string, YP_TCD_ConnectionHandler yP_TCD_ConnectionHandler, String string2) {
        try {
            return (Boolean)this.getPluginByName("ProcessLauncher").dealRequest(this, "startTransaction", string, yP_TCD_ConnectionHandler, string2);
        }
        catch (Exception exception) {
            this.logger(2, "startTransaction() error " + exception);
            return false;
        }
    }

    @Override
    public String toString() {
        return "Listener";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public void run() {
        int n;
        if (this.getLogLevel() >= 5) {
            this.logger(5, "run() New listener...");
        }
        int n2 = 0;
        do {
            try {
                this.iAmAlive();
                if (n2 != 1) {
                    n2 = this.connectionHandlerServer.getPhysicalInterface().openServer();
                }
                if (n2 != 1) {
                    this.logger(2, "run() the listener is not ready...");
                    UtilsYP.sleep(1000);
                } else {
                    if (this.getRunningChildNB() >= this.getMaxChild()) {
                        this.logger(2, "run() too many child ...");
                        UtilsYP.sleep(2000);
                        continue;
                    }
                    Object object = this.connectionHandlerServer.getPhysicalInterface().waitConnection();
                    if (object != null) {
                        this.logger(4, "run() New connection ...");
                        YP_TCD_ConnectionHandler yP_TCD_ConnectionHandler = (YP_TCD_ConnectionHandler)this.newPluginByName("ConnectionHandler", new Object[0]);
                        if (yP_TCD_ConnectionHandler == null) {
                            this.logger(2, "run() No connectionHandler for client");
                            continue;
                        }
                        YP_PHYS_Interface yP_PHYS_Interface = (YP_PHYS_Interface)((Object)yP_TCD_ConnectionHandler.newPluginByName(this.physicalInterfaceName, object));
                        if (yP_PHYS_Interface == null) {
                            this.logger(2, "run() Unable to get physicalInterface " + this.physicalInterfaceName);
                        } else {
                            ((YP_Object)((Object)yP_PHYS_Interface)).setPropertyFileName(this.physicalInterfaceProperties);
                            ((YP_Object)((Object)yP_PHYS_Interface)).initialize();
                            yP_TCD_ConnectionHandler.setPhysicalInterface(yP_PHYS_Interface);
                        }
                        YP_PROT_Interface_Com yP_PROT_Interface_Com = null;
                        if (this.communicationInterfaceName != null) {
                            yP_PROT_Interface_Com = (YP_PROT_Interface_Com)((Object)yP_TCD_ConnectionHandler.newPluginByName(this.communicationInterfaceName, yP_PHYS_Interface));
                            if (yP_PROT_Interface_Com == null) {
                                this.logger(2, "run() Unable to get protocolInterface " + this.communicationInterfaceName);
                            } else {
                                ((YP_Object)((Object)yP_PROT_Interface_Com)).setPropertyFileName(this.communicationInterfaceProperties);
                                ((YP_Object)((Object)yP_PROT_Interface_Com)).initialize();
                                yP_TCD_ConnectionHandler.setCommunicationInterface(yP_PROT_Interface_Com);
                            }
                        }
                        yP_TCD_ConnectionHandler.initialize();
                        n = this.addChild(yP_TCD_ConnectionHandler, 1);
                        if (n < 0) {
                            this.logger(3, "run() No more space available...");
                            this.connectionHandlerServer.getPhysicalInterface().closeHandle(object);
                            continue;
                        }
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "run() Connection on rank :" + n);
                        }
                        if (!this.startTransaction(this.transactionHandlerName, yP_TCD_ConnectionHandler, this.dataContainerTransactionName)) {
                            this.logger(2, "run() Unable to start transaction");
                            yP_TCD_ConnectionHandler.shutdown();
                            continue;
                        }
                        this.logger(4, "run() Process started on rank :" + n);
                    }
                }
                this.iAmAlive();
            }
            catch (Exception exception) {
                this.logger(2, "run()", exception);
                UtilsYP.sleep(10000);
            }
        } while (this.getObjectStatus() == 1);
        if (this.getObjectStatus() == 2) {
            boolean bl;
            this.setObjectStatus(3);
            long l = System.currentTimeMillis();
            block3: do {
                bl = true;
                n = 1;
                while (n < this.getChildNB()) {
                    YP_Object yP_Object = this.getChildByRank(n);
                    if (yP_Object != null && yP_Object.getObjectStatus() != 6) {
                        bl = false;
                        UtilsYP.sleep(100);
                        continue block3;
                    }
                    ++n;
                }
            } while (!bl && !UtilsYP.isTimeout(l, this.shutdownTimeoutMS));
            if (!bl) {
                this.logger(2, "dealRequest() still some childs but we have to stop...");
            }
        }
        this.logger(3, "run() Stopped...");
        this.shutdown();
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) throws Exception {
        this.logger(2, "dealRequest() has not been redefined");
        return null;
    }

    public void stopListenning(long l) {
        try {
            this.shutdownTimeoutMS = l;
            this.setObjectStatus(2);
            this.connectionHandlerServer.getPhysicalInterface().close();
        }
        catch (Exception exception) {
            this.logger(2, "stopListenning() " + exception);
        }
    }
}

