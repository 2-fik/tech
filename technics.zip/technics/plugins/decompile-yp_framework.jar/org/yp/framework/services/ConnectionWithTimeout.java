/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mysql.jdbc.jdbc2.optional.MysqlDataSource
 *  org.drizzle.jdbc.DrizzleDataSource
 *  org.mariadb.jdbc.MySQLDataSource
 */
package org.yp.framework.services;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import org.drizzle.jdbc.DrizzleDataSource;
import org.mariadb.jdbc.MySQLDataSource;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;

final class ConnectionWithTimeout
extends Thread {
    private volatile Connection connection = null;
    private volatile Exception exception = null;
    private final YP_TCD_DataBaseConnector dataBaseConnector;

    public ConnectionWithTimeout(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector) {
        this.dataBaseConnector = yP_TCD_DataBaseConnector;
    }

    @Override
    public void run() {
        try {
            if (this.dataBaseConnector.sql_Formater.toString().contains("MYSQL")) {
                int n = this.dataBaseConnector.getDBC_Path().indexOf(":drizzle://");
                if (n >= 0) {
                    String string = this.dataBaseConnector.getDBC_Path().substring(n + 11);
                    String string2 = string.substring(0, string.indexOf(58));
                    String string3 = string.substring(string.indexOf(58) + 1);
                    if (string3.endsWith("/")) {
                        string3 = string3.substring(0, string3.length() - 1);
                    }
                    DrizzleDataSource drizzleDataSource = new DrizzleDataSource(string2, Integer.parseInt(string3), this.dataBaseConnector.getDataBaseName());
                    this.connection = drizzleDataSource.getConnection(this.dataBaseConnector.getDBC_User(), this.dataBaseConnector.getDBC_Password());
                } else {
                    int n2 = this.dataBaseConnector.getDBC_Path().indexOf(":mariaDB://");
                    if (n2 >= 0) {
                        MySQLDataSource mySQLDataSource = new MySQLDataSource();
                        mySQLDataSource.setURL(String.valueOf(this.dataBaseConnector.getDBC_Path().replace(":mariaDB://", "://")) + this.dataBaseConnector.getDataBaseName());
                        String string = this.dataBaseConnector.getDBC_Properties();
                        if (string != null && !this.dataBaseConnector.getDBC_Properties().isEmpty()) {
                            mySQLDataSource.setProperties(string);
                        }
                        mySQLDataSource.setUser(this.dataBaseConnector.getDBC_User());
                        mySQLDataSource.setPassword(this.dataBaseConnector.getDBC_Password());
                        this.connection = mySQLDataSource.getConnection();
                    } else {
                        MysqlDataSource mysqlDataSource = new MysqlDataSource();
                        mysqlDataSource.setZeroDateTimeBehavior("round");
                        mysqlDataSource.setURL(String.valueOf(this.dataBaseConnector.getDBC_Path()) + this.dataBaseConnector.getDataBaseName());
                        this.connection = mysqlDataSource.getConnection(this.dataBaseConnector.getDBC_User(), this.dataBaseConnector.getDBC_Password());
                    }
                }
            } else if (this.dataBaseConnector.sql_Formater.toString().contains("POSTGRES")) {
                this.connection = DriverManager.getConnection(String.valueOf(this.dataBaseConnector.getDBC_Path()) + "?user=" + this.dataBaseConnector.getDBC_User() + "&password=" + this.dataBaseConnector.getDBC_Password());
            } else if (this.dataBaseConnector.sql_Formater.toString().contains("ORACLE")) {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                this.connection = DriverManager.getConnection(this.dataBaseConnector.getDBC_Path(), this.dataBaseConnector.getDBC_User(), this.dataBaseConnector.getDBC_Password());
            } else if (this.dataBaseConnector.sql_Formater.toString().contains("SQLSERVER")) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                this.connection = DriverManager.getConnection(this.dataBaseConnector.getDBC_Path(), this.dataBaseConnector.getDBC_User(), this.dataBaseConnector.getDBC_Password());
                this.connection.setHoldability(2);
            }
            if (this.connection == null) {
                System.out.println(String.valueOf(this.dataBaseConnector.getDBC_Path()) + this.dataBaseConnector.getDataBaseName() + this.dataBaseConnector.getDBC_User() + this.dataBaseConnector.getDBC_Password());
            }
        }
        catch (Exception exception) {
            this.exception = exception;
            System.out.println(String.valueOf(this.dataBaseConnector.getDBC_Path()) + this.dataBaseConnector.getDataBaseName() + this.dataBaseConnector.getDBC_User() + this.dataBaseConnector.getDBC_Password() + exception);
        }
    }

    public static Connection openConnection(YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector, int n) throws Exception {
        ConnectionWithTimeout connectionWithTimeout = new ConnectionWithTimeout(yP_TCD_DataBaseConnector);
        connectionWithTimeout.start();
        try {
            connectionWithTimeout.join(n);
        }
        catch (InterruptedException interruptedException) {}
        if (connectionWithTimeout.exception != null) {
            throw connectionWithTimeout.exception;
        }
        return connectionWithTimeout.connection;
    }
}

