/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;

public abstract class YP_Component
extends YP_Object {
    public YP_Component(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    protected void processIsAlive() {
        YP_Process yP_Process = this.getProcessPluginByThreadID(Thread.currentThread().getId());
        if (yP_Process != null) {
            yP_Process.iAmAlive();
        }
    }
}

