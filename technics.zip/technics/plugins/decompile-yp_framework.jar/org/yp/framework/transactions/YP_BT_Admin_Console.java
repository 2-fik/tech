/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;

public class YP_BT_Admin_Console
extends YP_Transaction {
    public YP_BT_Admin_Console(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String toString() {
        return "AdminConsole";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public void stop() {
        if (this.getDataContainerTransaction() != null) {
            String string = this.getDataContainerTransaction().getEFTResponse(this);
            if (string != null && this.getClientConnectionHandler() != null) {
                this.getClientConnectionHandler().getPhysicalInterface().send(string.getBytes(), string.length());
            }
            this.getDataContainerTransaction().shutdown();
            this.setDataContainerTransaction(null);
        }
        if (this.getClientConnectionHandler() != null) {
            this.getClientConnectionHandler().shutdown();
            this.setClientConnectionHandler(null);
        }
        this.shutdown();
    }

    @Override
    public void run() {
        try {
            byte[] byArray = new byte[6000];
            int n = this.getClientConnectionHandler().getPhysicalInterface().recv(byArray, 0, 6000, 1000);
            if (n > 0) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "Run(): something received");
                }
            } else {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "Run(): nothing received");
                }
                return;
            }
            int n2 = this.getDataContainerTransaction().load(byArray, n);
            if (n2 != 1) {
                this.logger(3, "run() failed to load message !!!");
                return;
            }
            switch (this.getDataContainerTransaction().getRequestType()) {
                case System: {
                    this.doSystemRequest();
                    return;
                }
            }
            this.logger(2, "run() Unknown request");
            return;
        }
        catch (Exception exception) {
            this.logger(2, "run() " + exception);
            return;
        }
        finally {
            this.stop();
        }
    }

    public int reload() {
        try {
            this.logger(5, "reload property file");
            int n = (Integer)this.getPluginByName("Updater").dealRequest(this, "reload", this.getDataContainerTransaction().get("name"), this.getDataContainerTransaction().get("preferredName"));
            if (n == 1) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            } else if (n == 0) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            } else {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            }
            this.logger(5, "reload Database");
            n = (Integer)this.getPluginByName("DataContainerManager").dealRequest(this, "reload", new Object[0]);
            if (n == 1) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            } else if (n == 0) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            } else {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "reload() " + exception);
            return -1;
        }
    }

    public int doSystemRequest() {
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getDataContainerTransaction().getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.logger(2, "doSystemRequest() no sub request");
            return -1;
        }
        switch (sUB_REQUEST_TYPE) {
            case Reload: {
                return this.reload();
            }
        }
        this.logger(2, "doSystemRequest() unknowm sub request " + (Object)((Object)sUB_REQUEST_TYPE));
        return -1;
    }
}

