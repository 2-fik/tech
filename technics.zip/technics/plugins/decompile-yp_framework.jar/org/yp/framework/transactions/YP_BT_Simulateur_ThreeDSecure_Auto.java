/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachine;

public class YP_BT_Simulateur_ThreeDSecure_Auto
extends YP_Transaction {
    public YP_BT_Simulateur_ThreeDSecure_Auto(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String toString() {
        return "Simulateur_ThreeDSecure_Auto";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    public void stop() {
        if (this.getDataContainerTransaction() != null) {
            this.getDataContainerTransaction().shutdown();
            this.setDataContainerTransaction(null);
        }
        if (this.getClientConnectionHandler() != null) {
            this.getClientConnectionHandler().shutdown();
            this.setClientConnectionHandler(null);
        }
        this.shutdown();
    }

    @Override
    public void run() {
        try {
            YP_PROT_Interface_StateMachine yP_PROT_Interface_StateMachine = (YP_PROT_Interface_StateMachine)((Object)this.newPluginByName("SM_THREEDSECURE_HOST_AUTO", new Object[0]));
            yP_PROT_Interface_StateMachine.setParameters(null, null, null, null, null, (YP_Object)((Object)this.getClientConnectionHandler().getPhysicalInterface()), new Object[0]);
            while (yP_PROT_Interface_StateMachine.step() == 1) {
            }
            yP_PROT_Interface_StateMachine.shutdown();
            return;
        }
        catch (Exception exception) {
            this.logger(2, "run() " + exception);
        }
        finally {
            this.stop();
        }
    }
}

