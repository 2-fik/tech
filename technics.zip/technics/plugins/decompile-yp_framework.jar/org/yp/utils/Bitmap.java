/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

public final class Bitmap {
    private long bitmap;

    public Bitmap(long l) {
        this.bitmap = l;
    }

    public Bitmap() {
        this.bitmap = 0L;
    }

    public void reset() {
        this.bitmap = 0L;
    }

    public Bitmap set(int n) throws IndexOutOfBoundsException {
        if (n < 1 || n > 63) {
            throw new IndexOutOfBoundsException();
        }
        long l = 1L << n - 1;
        this.bitmap |= l;
        return this;
    }

    public Bitmap unSet(int n) throws IndexOutOfBoundsException {
        if (n < 1 || n > 63) {
            throw new IndexOutOfBoundsException();
        }
        long l = 1L << n - 1;
        this.bitmap &= l ^ 0xFFFFFFFFFFFFFFFFL;
        return this;
    }

    public boolean isSet(int n) throws IndexOutOfBoundsException {
        if (n < 0 || n > 63) {
            throw new IndexOutOfBoundsException(Integer.toString(n));
        }
        if (n == 0) {
            return false;
        }
        long l = 1L << n - 1;
        return (this.bitmap & l) != 0L;
    }

    public boolean isSet(Bitmap bitmap) {
        return (this.bitmap & bitmap.bitmap) == bitmap.bitmap;
    }

    public long getBitmap() {
        return this.bitmap;
    }

    public int add(Bitmap bitmap) {
        int n = 0;
        int n2 = 1;
        while (n2 < 64) {
            if (bitmap.isSet(n2) && !this.isSet(n2)) {
                this.set(n2);
                ++n;
            }
            ++n2;
        }
        return n;
    }
}

