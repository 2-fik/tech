/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum ModePaiementEnumeration {
    AUTOMATIQUE("AUTOMATIQUE"),
    MANUEL("MANUEL");

    private String modePaiement;

    private ModePaiementEnumeration(String string2) {
        this.modePaiement = string2;
    }

    public String getModePaiement() {
        return this.modePaiement;
    }

    public static boolean contains(String string) {
        ModePaiementEnumeration[] modePaiementEnumerationArray = ModePaiementEnumeration.values();
        int n = modePaiementEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            ModePaiementEnumeration modePaiementEnumeration = modePaiementEnumerationArray[n2];
            if (modePaiementEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

