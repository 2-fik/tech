/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum IdentificationLevelEnumeration {
    UNKNOWN,
    ERROR,
    IMPOSSIBLE,
    ACCOUNT_UNKNOWN,
    EXPIRED_SESSION,
    FAILED,
    BLOCKED,
    NONE,
    PASSWORD,
    TOKEN,
    EMPTY_ACCESS,
    EXPIRED_PASSWORD,
    PERMANENT_TOKEN;

}

