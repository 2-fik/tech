/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum PINHandlingEnumeration {
    UNKNOWN,
    NONE,
    NO_RESTRICTION,
    SERVICE_CODE_DRIVEN,
    PIN_ONLINE_IF_PINPAD,
    PIN_ONLINE_REQUIRED;

}

