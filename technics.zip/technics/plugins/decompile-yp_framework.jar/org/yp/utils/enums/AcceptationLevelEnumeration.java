/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum AcceptationLevelEnumeration {
    UNKNOWN,
    ACCEPTED,
    WATCHED,
    REFUSED,
    FORBIDDEN,
    REJECTED;

}

