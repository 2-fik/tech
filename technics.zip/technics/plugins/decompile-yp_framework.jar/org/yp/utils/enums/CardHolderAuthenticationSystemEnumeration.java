/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum CardHolderAuthenticationSystemEnumeration {
    UNKNOWN,
    NO_AUTHENTICATION,
    ICC,
    TERMINAL,
    AUTHORIZED_AGENT,
    MERCHANT,
    ICC_AND_MERCHANT,
    SERVER,
    MERCHANT_AND_AUTHORIZED_AGENT;

}

