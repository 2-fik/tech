/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum SecurityDataUsedEnumeration {
    UNKNOWN,
    NONE,
    PRIVATE,
    PIN,
    PRIVATE_AND_PIN,
    MAC,
    PRIVATE_AND_MAC,
    PIN_AND_MAC,
    PRIVATE_AND_PIN_AND_MAC;

}

