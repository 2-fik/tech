/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum InitializationStatusEnumeration {
    UNKNOWN,
    INITIALISED,
    PARTIAL,
    ERROR,
    EMPTY,
    NOT_INITIALISED,
    DELETED;

}

