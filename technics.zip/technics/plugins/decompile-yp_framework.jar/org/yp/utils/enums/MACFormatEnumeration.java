/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum MACFormatEnumeration {
    UNKNOWN,
    NO_MAC,
    MAC_ISO9807;

}

