/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum ModeTraitementEnumeration {
    AUTOMATIQUE("AUTOMATIQUE"),
    MANUEL("MANUEL");

    private String modePaiement;

    private ModeTraitementEnumeration(String string2) {
        this.modePaiement = string2;
    }

    public String getModePaiement() {
        return this.modePaiement;
    }

    public static boolean contains(String string) {
        ModeTraitementEnumeration[] modeTraitementEnumerationArray = ModeTraitementEnumeration.values();
        int n = modeTraitementEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            ModeTraitementEnumeration modeTraitementEnumeration = modeTraitementEnumerationArray[n2];
            if (modeTraitementEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

