/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum CanalTypeEnumeration {
    TERMINAL("TERMINAL"),
    PEL("PEL"),
    PILOTAGE("PILOTAGE");

    private String canalType;

    private CanalTypeEnumeration(String string2) {
        this.canalType = string2;
    }

    public String getCanalType() {
        return this.canalType;
    }

    public static boolean contains(String string) {
        CanalTypeEnumeration[] canalTypeEnumerationArray = CanalTypeEnumeration.values();
        int n = canalTypeEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            CanalTypeEnumeration canalTypeEnumeration = canalTypeEnumerationArray[n2];
            if (canalTypeEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

