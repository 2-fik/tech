/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum KeyStatusEnumeration {
    UNKNOWN,
    ACTIVE,
    SUSPENDED,
    FORBIDDEN;

}

