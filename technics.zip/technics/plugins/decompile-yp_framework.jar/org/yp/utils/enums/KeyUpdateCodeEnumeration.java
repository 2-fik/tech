/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum KeyUpdateCodeEnumeration {
    UNKNOWN,
    ADD_KEY,
    UPDATE_KEY,
    DELETE_KEY;

}

