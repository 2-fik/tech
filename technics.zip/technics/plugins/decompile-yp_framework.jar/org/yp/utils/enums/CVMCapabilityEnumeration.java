/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum CVMCapabilityEnumeration {
    UNKNOWN(0),
    PLAIN_TEXT_PIN(128),
    ONLINE_PIN(64),
    SIGNATURE(32),
    ENCIPHERED_PIN(16),
    NO_CVM(8);

    public final int cvmCapability;

    private CVMCapabilityEnumeration(int n2) {
        this.cvmCapability = n2;
    }

    public int getValue() {
        return this.cvmCapability;
    }
}

