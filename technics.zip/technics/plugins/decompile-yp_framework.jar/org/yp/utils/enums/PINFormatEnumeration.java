/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum PINFormatEnumeration {
    UNKNOWN,
    NO_PIN,
    ISO01,
    ISO03;

}

