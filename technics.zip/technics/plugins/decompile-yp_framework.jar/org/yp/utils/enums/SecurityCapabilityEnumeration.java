/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum SecurityCapabilityEnumeration {
    UNKNOWN(0),
    SDA(128),
    DDA(64),
    CARD_CAPTURE(32),
    CDA(8);

    public final int securityCapability;

    private SecurityCapabilityEnumeration(int n2) {
        this.securityCapability = n2;
    }

    public int getValue() {
        return this.securityCapability;
    }
}

