/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum PINCheckEnumeration {
    UNKNOWN,
    PIN_NOT_CONTROLED,
    PIN_CONTROLED_OK,
    PIN_CONTROLED_FAILED,
    PIN_CONTROLED_BLOCKED,
    PIN_ALREADY_BLOCKED;

}

