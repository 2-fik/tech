/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum EtatMessageEnumeration {
    ACTIVE,
    INACTIVE;

}

