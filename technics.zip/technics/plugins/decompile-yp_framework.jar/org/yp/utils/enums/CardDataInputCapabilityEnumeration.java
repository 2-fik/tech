/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum CardDataInputCapabilityEnumeration {
    UNKNOWN(0),
    MANUAL(128),
    MAGSTRIPE(64),
    ICC(32);

    public final int cardDataInputCapability;

    private CardDataInputCapabilityEnumeration(int n2) {
        this.cardDataInputCapability = n2;
    }

    public int getValue() {
        return this.cardDataInputCapability;
    }
}

