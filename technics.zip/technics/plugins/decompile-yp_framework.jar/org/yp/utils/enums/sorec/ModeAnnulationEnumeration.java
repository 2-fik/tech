/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum ModeAnnulationEnumeration {
    AUTOMATIQUE("AUTOMATIQUE"),
    MANUEL("MANUEL");

    private String modeAnnulation;

    private ModeAnnulationEnumeration(String string2) {
        this.modeAnnulation = string2;
    }

    public String getModeAnnulation() {
        return this.modeAnnulation;
    }

    public static boolean contains(String string) {
        ModeAnnulationEnumeration[] modeAnnulationEnumerationArray = ModeAnnulationEnumeration.values();
        int n = modeAnnulationEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            ModeAnnulationEnumeration modeAnnulationEnumeration = modeAnnulationEnumerationArray[n2];
            if (modeAnnulationEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

