/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum ReconciliationStatusEnumeration {
    UNKNOWN,
    SUCCESSFUL,
    PARTIALLY,
    ERROR;

}

