/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum ParticipantStatusEnumeration {
    PAR("PAR"),
    NPA("NPA");


    private ParticipantStatusEnumeration(String string2) {
    }

    public static boolean contains(String string) {
        ParticipantStatusEnumeration[] participantStatusEnumerationArray = ParticipantStatusEnumeration.values();
        int n = participantStatusEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            ParticipantStatusEnumeration participantStatusEnumeration = participantStatusEnumerationArray[n2];
            if (participantStatusEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

