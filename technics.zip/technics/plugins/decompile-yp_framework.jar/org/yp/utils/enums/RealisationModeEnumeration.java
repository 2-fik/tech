/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum RealisationModeEnumeration {
    OkOffline(0),
    OkOnline(1),
    OkReferral(2),
    OkForcedAfterAuthorization(3),
    OkForcedBeforeAuthorization(4),
    KoOffline(10),
    KoOnline(11),
    RefusedOffline(12),
    RefusedOnline(13),
    RefusedAfterReferral(14),
    UserAbort(15),
    ForbiddenOffline(16),
    ForbiddenOnline(17),
    KoForcedAfterAuthorization(18),
    KoForcedBeforeAuthorization(19),
    Unknown(99);

    private int realisationMode;

    private RealisationModeEnumeration(int n2) {
        this.realisationMode = n2;
    }

    public int getValue() {
        return this.realisationMode;
    }
}

