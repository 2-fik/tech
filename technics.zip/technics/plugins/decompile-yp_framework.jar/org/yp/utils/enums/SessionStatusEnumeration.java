/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum SessionStatusEnumeration {
    UNKNOWN,
    TO_UPLOAD,
    UPLOADED,
    ERROR;

}

