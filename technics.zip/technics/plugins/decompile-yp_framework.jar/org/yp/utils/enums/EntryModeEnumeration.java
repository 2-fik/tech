/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum EntryModeEnumeration {
    UNKNOWN(0),
    ENTRY_MODE_MANUAL(1),
    ENTRY_MODE_KEYED(2),
    ENTRY_MODE_FILE(3),
    ENTRY_MODE_SCANNED(4),
    ENTRY_MODE_MAGSTRIPE(5),
    ENTRY_MODE_MAGSTRIPE_FALLBACK(6),
    ENTRY_MODE_ICC(7),
    ENTRY_MODE_SYNC_ICC(8),
    ENTRY_MODE_NFC(9),
    ENTRY_MODE_TAPPED(10),
    ENTRY_MODE_EMV_CONTACTLESS(11),
    ENTRY_MODE_MOBILE(12),
    ENTRY_MODE_RFID(13),
    ENTRY_MODE_CMC7(14),
    ENTRY_MODE_CMC7_KEYED(15);

    public final int entryMode;

    private EntryModeEnumeration(int n2) {
        this.entryMode = n2;
    }

    public int getValue() {
        return this.entryMode;
    }
}

