/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum CardHolderAuthenticationEnumeration {
    UNKNOWN(0),
    NO_AUTHENTICATION(1),
    OFFLINE_PIN(2),
    ONLINE_PIN(3),
    SIGNATURE(4),
    ELECTRONIC_SIGNATURE(5),
    OTHER_METHOD(6),
    CHECK_ADDRESS(7),
    OFFLINE_PIN_AND_SIGNATURE(8),
    ONLINE_PIN_AND_SIGNATURE(9),
    THREEDSECURE(10);

    public final int cardHolderAuthentication;

    private CardHolderAuthenticationEnumeration(int n2) {
        this.cardHolderAuthentication = n2;
    }

    public int getValue() {
        return this.cardHolderAuthentication;
    }
}

