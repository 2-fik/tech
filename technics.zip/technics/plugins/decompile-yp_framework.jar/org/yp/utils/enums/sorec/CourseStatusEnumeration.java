/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

public enum CourseStatusEnumeration {
    ENV("ENV"),
    ARR("ARR"),
    PDE("PDE"),
    DEP("DEP"),
    DEI("DEI"),
    APR("APR"),
    ADE("ADE"),
    DDX("DDX"),
    CHA("CHA"),
    ANN("ANN");


    private CourseStatusEnumeration(String string2) {
    }

    public static boolean contains(String string) {
        CourseStatusEnumeration[] courseStatusEnumerationArray = CourseStatusEnumeration.values();
        int n = courseStatusEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            CourseStatusEnumeration courseStatusEnumeration = courseStatusEnumerationArray[n2];
            if (courseStatusEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

