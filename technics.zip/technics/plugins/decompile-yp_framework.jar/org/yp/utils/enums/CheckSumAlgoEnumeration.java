/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum CheckSumAlgoEnumeration {
    UNKNOWN,
    CRC16,
    CRC32,
    MD5,
    SHA1,
    SHA256,
    SHA512;

}

