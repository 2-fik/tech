/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum ClientCapabilityEnumeration {
    UNKNOWN(0),
    MENU_CAPABLE(1),
    KEY_ENTRY_CAPABLE(2),
    DISPLAY_TEXT_CAPABLE(3),
    DCC_CAPABLE(4);

    private int clientType;

    private ClientCapabilityEnumeration(int n2) {
        this.clientType = n2;
    }

    public int getValue() {
        return this.clientType;
    }
}

