/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums.sorec;

import org.yp.utils.enums.sorec.PDVStatusEnumeration;

public enum FinEtapeActionEnumeration {
    LANCER("LANCER"),
    RELANCER("RELANCER");

    private String result;

    private FinEtapeActionEnumeration(String string2) {
        this.result = string2;
    }

    public String getResult() {
        return this.result;
    }

    public static boolean contains(String string) {
        PDVStatusEnumeration[] pDVStatusEnumerationArray = PDVStatusEnumeration.values();
        int n = pDVStatusEnumerationArray.length;
        int n2 = 0;
        while (n2 < n) {
            PDVStatusEnumeration pDVStatusEnumeration = pDVStatusEnumerationArray[n2];
            if (pDVStatusEnumeration.name().equals(string)) {
                return true;
            }
            ++n2;
        }
        return false;
    }
}

