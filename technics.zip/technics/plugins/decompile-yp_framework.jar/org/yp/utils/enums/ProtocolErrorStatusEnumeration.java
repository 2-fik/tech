/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils.enums;

public enum ProtocolErrorStatusEnumeration {
    NONE,
    PREPARE_REQUEST_ERROR,
    CONNECTION_ERROR,
    FORMAT_DATA_ERROR,
    PARSE_DATA_ERROR,
    NOTHING_RECEIVED,
    PROTOCOL_ERROR,
    APPLICATION_ERROR;

}

