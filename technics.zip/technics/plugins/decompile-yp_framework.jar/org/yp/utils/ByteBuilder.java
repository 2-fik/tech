/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import java.util.Arrays;
import org.yp.utils.UtilsYP;

public final class ByteBuilder {
    byte[] data;
    private int size;
    static final byte[] digits = new byte[]{48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122};
    static final byte[] digitTens = new byte[]{48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 52, 52, 52, 52, 52, 52, 52, 52, 52, 52, 53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 54, 54, 54, 54, 54, 54, 54, 54, 54, 54, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57};
    static final byte[] digitOnes = new byte[]{48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57};
    static final int[] sizeTable = new int[]{9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, Integer.MAX_VALUE};

    public ByteBuilder() {
        this(256);
    }

    public ByteBuilder(int n) {
        this.data = new byte[n];
        this.size = 0;
    }

    public final boolean equals(Object object) {
        if (!(object instanceof ByteBuilder)) {
            return false;
        }
        return Arrays.equals(this.data, ((ByteBuilder)object).data);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.data);
    }

    private void testAddition(int n) {
        if (this.size + n >= this.data.length) {
            int n2 = 2;
            while (true) {
                if (this.size + n < this.data.length * n2) {
                    this.data = Arrays.copyOf(this.data, this.data.length * n2);
                    return;
                }
                n2 *= 2;
            }
        }
    }

    public final byte[] data() {
        return this.data;
    }

    public final byte[] dataCopy() {
        return Arrays.copyOfRange(this.data, 0, this.size);
    }

    public final int size() {
        return this.size;
    }

    public final int length() {
        return this.size;
    }

    public final String toString() {
        return new String(this.data, 0, this.size);
    }

    public final String toHexString() {
        return UtilsYP.devHexa(this.data, 0, this.size);
    }

    public final String substring(int n) {
        return new String(this.data, n, this.size - n);
    }

    public final ByteBuilder append(byte by) {
        this.testAddition(1);
        this.data[this.size++] = by;
        return this;
    }

    public final ByteBuilder append(byte[] byArray) {
        return this.append(byArray, 0, byArray.length);
    }

    public final ByteBuilder append(byte[] byArray, int n, int n2) {
        if (n + n2 > byArray.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        this.testAddition(n2);
        int n3 = 0;
        while (n3 < n2) {
            this.data[this.size + n3] = byArray[n3 + n];
            ++n3;
        }
        this.size += n2;
        return this;
    }

    public final ByteBuilder append(char c) {
        this.testAddition(1);
        this.data[this.size++] = (byte)c;
        return this;
    }

    public final ByteBuilder append(char[] cArray) {
        return this.append(cArray, 0, cArray.length);
    }

    public final ByteBuilder append(char[] cArray, int n, int n2) {
        if (n + n2 > cArray.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        this.testAddition(n2);
        int n3 = 0;
        while (n3 < n2) {
            this.data[this.size + n3] = (byte)cArray[n3 + n];
            ++n3;
        }
        this.size += n2;
        return this;
    }

    private static int stringSize(int n) {
        int n2 = 0;
        while (n > sizeTable[n2]) {
            ++n2;
        }
        return n2 + 1;
    }

    public final ByteBuilder append(int n) {
        int n2;
        int n3;
        this.testAddition(11);
        int n4 = 0;
        this.size += n < 0 ? ByteBuilder.stringSize(-n) + 1 : ByteBuilder.stringSize(n);
        int n5 = 0;
        if (n < 0) {
            n5 = 45;
            n = -n;
        }
        while (n >= 65536) {
            n3 = n / 100;
            n2 = n - ((n3 << 6) + (n3 << 5) + (n3 << 2));
            n = n3;
            this.data[this.size - ++n4] = digitOnes[n2];
            this.data[this.size - ++n4] = digitTens[n2];
        }
        do {
            n3 = n * 52429 >>> 19;
            n2 = n - ((n3 << 3) + (n3 << 1));
            this.data[this.size - ++n4] = digits[n2];
        } while ((n = n3) != 0);
        if (n5 != 0) {
            this.data[this.size - ++n4] = n5;
        }
        return this;
    }

    public final ByteBuilder append(String string) {
        int n = string.length();
        this.testAddition(n);
        int n2 = 0;
        while (n2 < n) {
            this.data[this.size + n2] = (byte)string.charAt(n2);
            ++n2;
        }
        this.size += n;
        return this;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }
}

