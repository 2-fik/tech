/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Collections;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.yp.utils.UtilsYP;

public class CryptoUtils {
    private static final String keyStorePassword = "slpc1515";
    private static final String keyPassword = "slpc1515";
    private static final String keyName = "ecommercekey";
    private static final String KEYSTORE_TYPE = "JCEKS";
    private static final String ALGO_NAME = "DESede";
    private static final char[] eCommerceExtraRandomTable = new char[]{'s', 'K', 'h', 'w', '4', 'r', 'X', 'R', 'O', '7', 'm', '5', 'i', 'I', 'U', 'W', 'Y', 'v', 'e', 'c', 'A', 't', '9', 'S', 'q', '3', 'k', 'o', 'x', 'F', 'H', 'd', '2', '8', 'y', 'D', 'g', 'T', '0', 'b', 'M', 'P', 'B', 'C', '6', '1', 'z', 'f', 'u', 'Z', 'E', 'G', 'a', 'N', 'Q', 'n', 'J', 'l', 'V', 'L', 'j', 'p'};
    public static final String HMAC_SHA1 = "HmacSHA1";
    public static final String HMAC_SHA256 = "HmacSHA256";
    public static final String HMAC_SHA512 = "HmacSHA512";
    public static final String HMAC_MD5 = "HmacMD5";
    private static final byte[] key = new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32};

    private static Key getKey(String string, String string2) {
        FileInputStream fileInputStream;
        if (string2 == null || string2.isEmpty()) {
            System.out.println("getKey() bap parameter");
            return null;
        }
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
        try {
            fileInputStream = new FileInputStream(string);
        }
        catch (FileNotFoundException fileNotFoundException) {
            try {
                fileInputStream = new FileInputStream(String.valueOf(UtilsYP.getPath()) + string);
            }
            catch (FileNotFoundException fileNotFoundException2) {
                System.out.println("getKey() keystore not found : " + string);
                return null;
            }
        }
        try {
            keyStore.load(fileInputStream, "slpc1515".toCharArray());
            fileInputStream.close();
            if (keyStore.containsAlias(string2)) {
                return keyStore.getKey(string2, "slpc1515".toCharArray());
            }
            System.out.println("getKey() key not found : " + string2);
            for (String string3 : Collections.list(keyStore.aliases())) {
                System.out.println("getKey() Key found inside keystore " + string3);
            }
        }
        catch (Exception exception) {
            System.out.println("getKey()  " + string2 + " " + exception);
        }
        return null;
    }

    private static Cipher getCipher(String string, String string2, int n) {
        try {
            Key key = CryptoUtils.getKey(string, string2);
            if (key != null) {
                Cipher cipher = Cipher.getInstance(ALGO_NAME);
                cipher.init(n, key);
                return cipher;
            }
        }
        catch (Exception exception) {
            System.out.println("getCipher()  " + string2 + " " + exception);
        }
        return null;
    }

    public static byte[] getEMerchantKey(String string, String string2) {
        Cipher cipher;
        block3: {
            try {
                cipher = CryptoUtils.getCipher(string, keyName, 1);
                if (cipher != null) break block3;
                return null;
            }
            catch (Exception exception) {
                System.out.println("getEMerchantKey()  " + string2 + " " + exception);
                return null;
            }
        }
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        String string3 = "_01";
        byte[] byArray = messageDigest.digest((String.valueOf(string2) + string3).getBytes());
        byte[] byArray2 = cipher.doFinal(byArray);
        byte[] byArray3 = new byte[24];
        System.arraycopy(byArray2, 0, byArray3, 0, 16);
        System.arraycopy(byArray2, 0, byArray3, 16, 8);
        return byArray3;
    }

    private static int getECommerceExtraRandomTableIndex(char c) {
        int n = 0;
        while (n < eCommerceExtraRandomTable.length) {
            if (eCommerceExtraRandomTable[n] == c) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    public static String getSecuredCVV(String string) throws Exception {
        if (string == null || string.isEmpty()) {
            throw new Exception("storeSecuredCVV() no cvv");
        }
        if (string.length() != 3) {
            throw new Exception("storeSecuredCVV() bad cvv length");
        }
        try {
            int n = Integer.parseInt(string);
            n *= 23;
            n = n / 1000 * 10000 + n % 1000;
            Random random = new Random();
            int n2 = random.nextInt(10);
            int n3 = (n += n2 * 1000) % 62;
            int n4 = n / 62 % 62;
            int n5 = n / 3844 % 62;
            return "" + eCommerceExtraRandomTable[n3] + eCommerceExtraRandomTable[n4] + eCommerceExtraRandomTable[n5];
        }
        catch (Exception exception) {
            throw new Exception("storeSecuredCVV() " + exception.getMessage());
        }
    }

    public static String decryptCVV(String string) throws Exception {
        if (string == null || string.isEmpty()) {
            throw new Exception("decryptCVV() no cvv");
        }
        if (string.length() != 3) {
            throw new Exception("decryptCVV() bad cvv length");
        }
        try {
            int n = CryptoUtils.getECommerceExtraRandomTableIndex(string.charAt(0));
            int n2 = CryptoUtils.getECommerceExtraRandomTableIndex(string.charAt(1));
            int n3 = CryptoUtils.getECommerceExtraRandomTableIndex(string.charAt(2));
            int n4 = n3 * 3844 + n2 * 62 + n;
            n4 = n4 % 1000 + n4 / 10000 * 1000;
            return String.format("%03d", n4 /= 23);
        }
        catch (Exception exception) {
            throw new Exception("decryptCVV() " + exception.getMessage());
        }
    }

    public static byte[] getNepSign(Boolean bl, String string, StringBuilder stringBuilder) throws Exception {
        Object object;
        Object object2;
        if (bl != null && bl.booleanValue()) {
            stringBuilder.append("01234567890");
        } else {
            object2 = String.valueOf(UtilsYP.getPath()) + "\\keystore\\secret\\ecommerce.keystore";
            object = UtilsYP.devHexa(CryptoUtils.getEMerchantKey((String)object2, string));
            stringBuilder.append((String)object);
        }
        object2 = MessageDigest.getInstance("SHA-256");
        ((MessageDigest)object2).update(stringBuilder.toString().getBytes("UTF-8"));
        object = ((MessageDigest)object2).digest();
        return object;
    }

    public static boolean checkMACSign(String string, String string2) {
        try {
            byte[] byArray = CryptoUtils.macSign(CryptoUtils.getSha256(string));
            String string3 = UtilsYP.devHexa(byArray).toUpperCase();
            if (string3.contentEquals(string2)) {
                return true;
            }
        }
        catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException | SignatureException exception) {}
        return false;
    }

    public static byte[] macSign(String string) throws SignatureException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, HMAC_SHA512);
        Mac mac = Mac.getInstance(HMAC_SHA512);
        mac.init(secretKeySpec);
        return mac.doFinal(string.getBytes());
    }

    public static String getSha256(String string) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] byArray = messageDigest.digest(string.getBytes(StandardCharsets.UTF_8));
            return CryptoUtils.bytesToHex(byArray);
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            noSuchAlgorithmException.printStackTrace();
            return null;
        }
    }

    private static String bytesToHex(byte[] byArray) {
        StringBuffer stringBuffer = new StringBuffer();
        int n = 0;
        while (n < byArray.length) {
            String string = Integer.toHexString(0xFF & byArray[n]);
            if (string.length() == 1) {
                stringBuffer.append('0');
            }
            stringBuffer.append(string);
            ++n;
        }
        return stringBuffer.toString();
    }
}

