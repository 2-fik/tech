/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import java.util.ArrayList;
import java.util.List;

public class CSVBuilder {
    private List<String> fields = new ArrayList<String>();
    private StringBuilder content = new StringBuilder();
    private String fieldSeparator = ";";
    private String lineSeparator = "\r\n";
    private boolean useQuotes = true;

    public List<String> getFields() {
        return this.fields;
    }

    public StringBuilder getContent() {
        return this.content;
    }

    public String getFieldSeparator() {
        return this.fieldSeparator;
    }

    public void setFieldSeparator(String string) {
        this.fieldSeparator = string;
    }

    public String getLineSeparator() {
        return this.lineSeparator;
    }

    public void setLineSeparator(String string) {
        this.lineSeparator = string;
    }

    public boolean isUseQuotes() {
        return this.useQuotes;
    }

    public void setUseQuotes(boolean bl) {
        this.useQuotes = bl;
    }

    private void appendFieldWithoutSeparator(StringBuilder stringBuilder, String string) {
        String string2 = string;
        if (string2 == null) {
            string2 = "";
        }
        if (this.useQuotes || string2.contains(this.fieldSeparator)) {
            string2 = string2.replaceAll("\"", "\"\"");
            stringBuilder.append("\"" + string2 + "\"");
        } else {
            stringBuilder.append(string2);
        }
    }

    private void appendFieldWithSeparator(StringBuilder stringBuilder, String string) {
        this.appendFieldWithoutSeparator(stringBuilder, string);
        stringBuilder.append(this.fieldSeparator);
    }

    private void appendFieldWithEndOfLine(StringBuilder stringBuilder, String string) {
        this.appendFieldWithoutSeparator(stringBuilder, string);
        stringBuilder.append(this.lineSeparator);
    }

    public void addField(String string) {
        this.fields.add(string);
    }

    public void buildLine() {
        if (this.content != null) {
            int n = 0;
            while (n < this.fields.size()) {
                if (n != this.fields.size() - 1) {
                    this.appendFieldWithSeparator(this.content, this.fields.get(n));
                } else {
                    this.appendFieldWithEndOfLine(this.content, this.fields.get(n));
                }
                ++n;
            }
            this.fields.clear();
        }
    }
}

