/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public final class CTCL {
    @Deprecated
    public static final String convertExtendedTVRToRTT(String string, ExtendedTVR extendedTVR, TransactionTypeEnumeration transactionTypeEnumeration, int n, boolean bl) {
        return CTCL.convertExtendedTVRToRTT(string, extendedTVR, transactionTypeEnumeration, n, bl, null);
    }

    static byte[] getCTQ(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("cardTransactionQualifier"));
            if (string != null && !string.isEmpty()) {
                return UtilsYP.redHexa(string);
            }
            return null;
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(3, "getCTQ() problem: ", exception);
            return null;
        }
    }

    static byte[] getTVR(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("tvr"));
            if (string != null && !string.isEmpty()) {
                return UtilsYP.redHexa(string);
            }
            return null;
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(3, "getTVR() problem: ", exception);
            return null;
        }
    }

    static int getKernelID(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            String string = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("kernelID"));
            if (string != null && !string.isEmpty()) {
                return Integer.parseInt(string);
            }
            return 3;
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(2, "getKernelID() ", exception);
            return -1;
        }
    }

    public static final String convertExtendedTVRToRTT(String string, ExtendedTVR extendedTVR, TransactionTypeEnumeration transactionTypeEnumeration, int n, boolean bl, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (extendedTVR == null) {
            return null;
        }
        byte[] byArray = new byte[5];
        byte[] byArray2 = string == null || string.length() < 10 ? byArray : UtilsYP.redHexa(string);
        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
            byArray2[1] = (byte)(byArray2[1] | 0x40);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.EXPIRATION_DATE_MISSING)) {
            if (n != 3) {
                byArray2[1] = (byte)(byArray2[1] | 0x40);
            } else if (yP_TCD_DC_Transaction != null) {
                String string2 = "";
                try {
                    string2 = YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("cryptoInformationData"));
                    if ((UtilsYP.redHexa(string2)[0] & 0x40) == 64) {
                        byArray2[1] = (byte)(byArray2[1] | 0x40);
                    }
                }
                catch (Exception exception) {
                    yP_TCD_DC_Transaction.logger(2, "convertExtendedTVRToRTT() cryptoInformationData " + exception);
                }
            }
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED)) {
            byArray2[0] = n == 2 ? (byte)(byArray2[0] | 4) : (byte)(byArray2[0] | 8);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
            byArray2[0] = (byte)(byArray2[0] | 0x10);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
            byArray2[0] = (byte)(byArray2[0] | 0x10);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_WATCHED)) {
            if (!bl) {
                byArray2[0] = (byte)(byArray2[0] | 0x10);
            } else {
                byArray2[3] = (byte)(byArray2[3] | 0x80);
            }
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.AMOUNT_ABOVE_FLOOR_LIMIT) || extendedTVR.isSet(ExtendedTVREnumeration.CUMULATED_AMOUNT_ABOVE_FLOOR_LIMIT) || extendedTVR.isSet(ExtendedTVREnumeration.FOREIGN_CURRENCY)) {
            byArray2[3] = (byte)(byArray2[3] | 0x80);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_WATCHED)) {
            if (transactionTypeEnumeration != null) {
                if (transactionTypeEnumeration != TransactionTypeEnumeration.REVERSAL_DEBIT && transactionTypeEnumeration != TransactionTypeEnumeration.CREDIT) {
                    byArray2[3] = (byte)(byArray2[3] | 0x80);
                }
            } else {
                byArray2[3] = (byte)(byArray2[3] | 0x80);
            }
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_UNKNOWN)) {
            if (transactionTypeEnumeration != null) {
                if (transactionTypeEnumeration == TransactionTypeEnumeration.CREDIT) {
                    if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                        if (!bl) {
                            byArray2[3] = (byte)(byArray2[3] | 0x80);
                        } else {
                            byArray2[1] = (byte)(byArray2[1] | 0x10);
                        }
                    }
                } else if (transactionTypeEnumeration != TransactionTypeEnumeration.REVERSAL_DEBIT) {
                    byArray2[3] = (byte)(byArray2[3] | 0x80);
                }
            } else {
                byArray2[3] = (byte)(byArray2[3] | 0x80);
            }
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED) || extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
            byArray2[0] = (byte)(byArray2[0] | 0x10);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.ALEA_CALL)) {
            byArray2[3] = (byte)(byArray2[3] | 0x10);
        }
        if (n != 3 && extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
            byArray2[1] = (byte)(byArray2[1] | 0x20);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
            byArray2[1] = (byte)(byArray2[1] | 0x10);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.FORCED_ONLINE_MERCHANT)) {
            byArray2[3] = (byte)(byArray2[3] | 8);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHENTICATION_FAILED)) {
            byArray2[2] = (byte)(byArray2[2] | 0x80);
        }
        if (extendedTVR.isSet(ExtendedTVREnumeration.UNRECOGNISED_CVM)) {
            byArray2[2] = (byte)(byArray2[2] | 0x40);
        }
        return UtilsYP.devHexa(byArray2);
    }

    @Deprecated
    public static final String convertExtendedTVRToRTT(String string, ExtendedTVR extendedTVR, TransactionTypeEnumeration transactionTypeEnumeration, int n) {
        return CTCL.convertExtendedTVRToRTT(string, extendedTVR, transactionTypeEnumeration, n, false);
    }

    public static final void convertTvrToExtendedTVR(String string, ExtendedTVR extendedTVR) {
        if (extendedTVR == null) {
            return;
        }
        if (string == null || string.length() < 10) {
            return;
        }
        byte[] byArray = UtilsYP.redHexa(string);
        if ((byArray[0] & 4) == 4) {
            extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
        }
        if ((byArray[0] & 0x20) == 32) {
            extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
        }
        byte cfr_ignored_0 = byArray[1];
        if ((byArray[1] & 0x40) == 64) {
            extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
        }
        if ((byArray[1] & 0x20) == 32) {
            extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
        }
        if ((byArray[1] & 0x10) == 16) {
            extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
        }
        byte cfr_ignored_1 = byArray[1];
    }

    private static String getNonAchievedReasonCodeForRefund(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR, int n) {
        StringBuilder stringBuilder;
        block13: {
            stringBuilder = new StringBuilder();
            try {
                if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                    stringBuilder.append("57 ");
                }
                extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    stringBuilder.append("62 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    stringBuilder.append("62 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    if (n == 3) {
                        stringBuilder.append("65 ");
                    } else {
                        stringBuilder.append("55 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    stringBuilder.append("54 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    stringBuilder.append("50 ");
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block13;
                return "73 ";
            }
            catch (Exception exception) {
                return "73 ";
            }
        }
        stringBuilder.append("73 ");
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForReversal(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR, int n) {
        StringBuilder stringBuilder;
        block12: {
            stringBuilder = new StringBuilder();
            try {
                if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                    stringBuilder.append("57 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                    stringBuilder.append("67 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    if (n == 3) {
                        stringBuilder.append("65 ");
                    } else {
                        stringBuilder.append("55 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    stringBuilder.append("54 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    stringBuilder.append("50 ");
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block12;
                return "72 ";
            }
            catch (Exception exception) {
                return "72 ";
            }
        }
        stringBuilder.append("72 ");
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR, byte[] byArray, int n) {
        StringBuilder stringBuilder;
        block30: {
            stringBuilder = new StringBuilder();
            try {
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    stringBuilder.append("70 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                    stringBuilder.append("69 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    stringBuilder.append("85 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED)) {
                    if (n == 3) {
                        byte[] byArray2 = CTCL.getCTQ(yP_TCD_DC_Transaction);
                        if (byArray2 != null && (byArray2[0] & 0x20) == 0 && (byArray2[0] & 0x10) == 16) {
                            stringBuilder.append("66 ");
                        } else {
                            stringBuilder.append("61 ");
                        }
                    } else {
                        stringBuilder.append("61 ");
                    }
                }
                if (YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction) == EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS && byArray != null && (byArray[0] & 0x80) == 128) {
                    stringBuilder.append("53 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CVM_ERROR)) {
                    stringBuilder.append("60 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CVM_MISSING)) {
                    stringBuilder.append("59 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    stringBuilder.append("62 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    stringBuilder.append("62 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_WATCHED)) {
                    stringBuilder.append("62 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    stringBuilder.append("63 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    stringBuilder.append("50 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.INVALID_CERTIFICATE)) {
                    stringBuilder.append("64 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                    stringBuilder.append("57 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    if (n == 3) {
                        stringBuilder.append("65 ");
                    } else {
                        stringBuilder.append("55 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    stringBuilder.append("54 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    stringBuilder.append("88 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.GOODS_NOT_DELIVERED)) {
                    stringBuilder.append("30 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REAL_CARD_NOT_ALLOWED)) {
                    stringBuilder.append("30 ");
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block30;
                if (extendedTVR.isSet(ExtendedTVREnumeration.PHONE_AUTHENTICATION)) {
                    return "87 ";
                }
                return "87 ";
            }
            catch (Exception exception) {
                return "87 ";
            }
        }
        return stringBuilder.toString();
    }

    private static ExtendedTVR getMessageCodeToDisplayForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        ExtendedTVR extendedTVR = new ExtendedTVR();
        try {
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
                return extendedTVR;
            }
            if (byArray != null && (byArray[0] & 0x80) == 128) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                extendedTVR.add(ExtendedTVREnumeration.MERCHANT_ABORT);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                return extendedTVR;
            }
        }
        catch (Exception exception) {
            return null;
        }
        return null;
    }

    private static ExtendedTVR getMessageCodeToDisplayForReversal(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ExtendedTVR extendedTVR = new ExtendedTVR();
        try {
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                extendedTVR.add(ExtendedTVREnumeration.MERCHANT_ABORT);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
        }
        catch (Exception exception) {
            return null;
        }
        return null;
    }

    private static ExtendedTVR getMessageCodeToDisplayForRefund(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ExtendedTVR extendedTVR = new ExtendedTVR();
        try {
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
        }
        catch (Exception exception) {
            return null;
        }
        return null;
    }

    @Deprecated
    public static ExtendedTVR getMessageCodeToDisplay(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return CTCL.getMessageCodeToDisplayForRefund(yP_TCD_DC_Transaction);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return CTCL.getMessageCodeToDisplayForReversal(yP_TCD_DC_Transaction);
            }
        }
        return CTCL.getMessageCodeToDisplayForDebit(yP_TCD_DC_Transaction, null);
    }

    public static ExtendedTVR getMessageCodeToDisplay(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration, byte[] byArray) {
        block60: {
            try {
                String string = CTCL.getNonAchievedReasonCode(yP_TCD_DC_Transaction, transactionTypeEnumeration, yP_TCD_DC_Transaction.getExtendedTVR(), byArray, CTCL.getKernelID(yP_TCD_DC_Transaction));
                if (string == null || string.length() < 2) break block60;
                ExtendedTVR extendedTVR = new ExtendedTVR(true);
                switch (string.substring(0, 2)) {
                    case "50": 
                    case "51": 
                    case "53": 
                    case "58": 
                    case "59": 
                    case "60": 
                    case "86": {
                        extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                        return extendedTVR;
                    }
                    case "54": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                        return extendedTVR;
                    }
                    case "55": 
                    case "65": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                        return extendedTVR;
                    }
                    case "57": {
                        extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                        return extendedTVR;
                    }
                    case "61": 
                    case "66": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
                        return extendedTVR;
                    }
                    case "64": {
                        extendedTVR.add(ExtendedTVREnumeration.INVALID_CERTIFICATE);
                        return extendedTVR;
                    }
                    case "62": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                        return extendedTVR;
                    }
                    case "63": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                        return extendedTVR;
                    }
                    case "67": {
                        extendedTVR.add(ExtendedTVREnumeration.MERCHANT_ABORT);
                        return extendedTVR;
                    }
                    case "69": 
                    case "70": {
                        extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_REFUSED);
                        return extendedTVR;
                    }
                    case "85": {
                        extendedTVR.add(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED);
                        return extendedTVR;
                    }
                    case "87": {
                        extendedTVR.add(ExtendedTVREnumeration.PHONE_AUTHENTICATION);
                        return extendedTVR;
                    }
                }
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "getMessageCodeToDisplay() ", exception);
            }
        }
        return null;
    }

    @Deprecated
    public static String getNonAchievedReasonCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration, ExtendedTVR extendedTVR) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForRefund(yP_TCD_DC_Transaction, extendedTVR, 2);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForReversal(yP_TCD_DC_Transaction, extendedTVR, 2);
            }
        }
        return CTCL.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR, null, 2);
    }

    @Deprecated
    public static String getNonAchievedReasonCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration, ExtendedTVR extendedTVR, byte[] byArray) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForRefund(yP_TCD_DC_Transaction, extendedTVR, 2);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForReversal(yP_TCD_DC_Transaction, extendedTVR, 2);
            }
        }
        return CTCL.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR, byArray, 2);
    }

    public static String getNonAchievedReasonCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration, ExtendedTVR extendedTVR, byte[] byArray, int n) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForRefund(yP_TCD_DC_Transaction, extendedTVR, n);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return CTCL.getNonAchievedReasonCodeForReversal(yP_TCD_DC_Transaction, extendedTVR, n);
            }
        }
        return CTCL.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR, byArray, n);
    }
}

