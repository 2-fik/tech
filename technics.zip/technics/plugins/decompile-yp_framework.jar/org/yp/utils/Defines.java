/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

public abstract class Defines {
    public static final int ILEVEL_FILE = 7;
    public static final int ILEVEL_DEV = 6;
    public static final int ILEVEL_DEBUG = 5;
    public static final int ILEVEL_INFO = 4;
    public static final int ILEVEL_WARN = 3;
    public static final int ILEVEL_ERROR = 2;
    public static final int ILEVEL_FATAL = 1;
    public static final int ILEVEL_NOTHING = 0;
    public static final int ILEVEL_TRS = -1;
    public static final int ILEVEL_TOKEN = -2;
    public static final int ILEVEL_DUPLICATE_TRS = -3;
    public static final int ILEVEL_SQL = -4;
    public static final int ILEVEL_SQL_SENSITIVE = -5;
    public static final int ILEVEL_SQL_SLOW_QUERY = -6;
    public static final String SKERNEL_IDENTIFIER = "KERNEL";
    public static final String SGROUP_IDENTIFIER = "GROUP";
    public static final int UPDATE_NEEDED = 1;
    public static final int FORCE_UPDATE = 2;
    public static final String MGT_PARAM_MANUAL_REFUND_MERCHANT = "manualRefundMerchant";
}

