/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public final class EMV60 {
    public static final String MISSING_EMV_DATA = "01 ";
    public static final String CARD_COUNTER_READING_ERROR = "02 ";
    public static final String MANDATORY_DATA_MISSING = "03 ";
    public static final String REDUNDANT_DATA = "04 ";
    public static final String DATA_FORMAT_ERROR = "05 ";
    public static final String CARD_AUTHENTICATION_ERROR = "06 ";
    public static final String USER_ABORTED = "07 ";
    public static final String PIN_ERROR = "08 ";
    public static final String AAC_FIRST_GAC = "11 ";
    public static final String AAC_SECOND_GAC = "12 ";
    public static final String UNKNOWN_BIN_TRANSACTION_NOT_FOUND = "13 ";
    public static final String MERCHANT_ABORT_REVERSAL = "14 ";
    public static final String INVALID_CARD_STRUCTURE = "15 ";
    public static final String CARD_EXPIRED = "17 ";
    public static final String CARD_FORBIDDEN = "18 ";
    public static final String CARD_REFUSED = "19 ";
    public static final String BIN_REFUSED_OR_FORBIDDEN = "20 ";
    public static final String AUTHORIZATION_REFUSED = "21 ";
    public static final String AUTHORIZATION_FORBIDDEN = "22 ";
    public static final String TRANSACTION_NOT_FOUND = "24 ";
    public static final String TRANSACTION_NOT_ALLOWED = "25 ";
    public static final String PARTIAL_AUTHORIZATION_REFUSED = "27 ";
    public static final String DELIVERY_PROBLEM = "30 ";
    public static final String CARD_REMOVED = "32 ";
    public static final String MERCHANT_ABORT = "33 ";
    public static final String CHIP_MUST_BE_USED = "34 ";
    public static final String AUTHORIZATION_PIN_ONLINE_ERROR = "76 ";
    public static final String PIN_ONLINE_ERROR = "77 ";
    public static final String ISSUER_NOT_REACHABLE = "80 ";
    public static final String INVALID_RESPONSE_STRUCTURE = "83 ";
    public static final String TIME_OUT = "87 ";
    public static final String AUTHORIZATION_INCIDENT = "88 ";

    public static void setARQCResponse(byte[] byArray, byte[] byArray2, byte[] byArray3, byte[] byArray4, ExtendedTVR extendedTVR) {
        if (byArray == null || byArray.length != 1) {
            return;
        }
        if (byArray2 == null || byArray2.length != 5) {
            return;
        }
        if (byArray3 == null || byArray3.length != 5) {
            return;
        }
        if (byArray4 == null || byArray4.length != 5) {
            return;
        }
        if (extendedTVR == null) {
            return;
        }
        if ((byArray[0] & 0x80) != 128) {
            return;
        }
        int n = 0;
        while (n < 5) {
            if ((byArray4[n] & byArray3[n]) != 0) {
                return;
            }
            if ((byArray4[n] & byArray2[n]) != 0) {
                return;
            }
            ++n;
        }
        extendedTVR.add(ExtendedTVREnumeration.ARQC_RESPONSE);
    }

    private static String getNonAchievedReasonCodeForRefund(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                EMV60.appendMotif(stringBuilder, MANDATORY_DATA_MISSING);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                EMV60.appendMotif(stringBuilder, DATA_FORMAT_ERROR);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                EMV60.appendMotif(stringBuilder, REDUNDANT_DATA);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                EMV60.appendMotif(stringBuilder, CARD_EXPIRED);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                EMV60.appendMotif(stringBuilder, AUTHORIZATION_FORBIDDEN);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                EMV60.appendMotif(stringBuilder, AUTHORIZATION_REFUSED);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                if (yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("91") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("96") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("97") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("98")) {
                    EMV60.appendMotif(stringBuilder, ISSUER_NOT_REACHABLE);
                } else if (extendedTVR.isSet(ExtendedTVREnumeration.MESSAGE_RECEIVED_INVALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_RESPONSE_STRUCTURE);
                } else {
                    EMV60.appendMotif(stringBuilder, AUTHORIZATION_INCIDENT);
                }
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                EMV60.appendMotif(stringBuilder, TRANSACTION_NOT_ALLOWED);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                EMV60.appendMotif(stringBuilder, UNKNOWN_BIN_TRANSACTION_NOT_FOUND);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                EMV60.appendMotif(stringBuilder, MERCHANT_ABORT);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                EMV60.appendMotif(stringBuilder, CARD_REMOVED);
            }
        }
        catch (Exception exception) {
            return TRANSACTION_NOT_ALLOWED;
        }
        EMV60.appendMotif(stringBuilder, TRANSACTION_NOT_ALLOWED);
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForReversal(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                EMV60.appendMotif(stringBuilder, MANDATORY_DATA_MISSING);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                EMV60.appendMotif(stringBuilder, MISSING_EMV_DATA);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                EMV60.appendMotif(stringBuilder, REDUNDANT_DATA);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                EMV60.appendMotif(stringBuilder, CARD_EXPIRED);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                EMV60.appendMotif(stringBuilder, TRANSACTION_NOT_ALLOWED);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND) || extendedTVR.isSet(ExtendedTVREnumeration.ALREADY_VOIDED)) {
                EMV60.appendMotif(stringBuilder, TRANSACTION_NOT_FOUND);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                EMV60.appendMotif(stringBuilder, MERCHANT_ABORT);
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                EMV60.appendMotif(stringBuilder, CARD_REMOVED);
            }
        }
        catch (Exception exception) {
            return TRANSACTION_NOT_ALLOWED;
        }
        return stringBuilder.toString();
    }

    private static void appendMotif(StringBuilder stringBuilder, String string) {
        if (!stringBuilder.toString().contains(string)) {
            stringBuilder.append(string);
        }
    }

    private static String getNonAchievedReasonCodeForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR, byte[] byArray, byte[] byArray2, byte[] byArray3) {
        StringBuilder stringBuilder;
        block114: {
            stringBuilder = new StringBuilder();
            boolean bl = false;
            byte[] byArray4 = new byte[5];
            if (byArray == null || byArray.length < 5) {
                byArray = byArray4;
            }
            if (byArray2 == null || byArray2.length < 5) {
                byArray2 = byArray4;
            }
            if (byArray3 == null || byArray3.length < 5) {
                byArray3 = byArray4;
            }
            try {
                if ((byArray[0] & 0x40) == 64) {
                    if (bl) {
                        if ((byArray3[0] & 0x40) == 64) {
                            EMV60.appendMotif(stringBuilder, CARD_AUTHENTICATION_ERROR);
                        }
                    } else if ((byArray2[0] & 0x40) == 64) {
                        EMV60.appendMotif(stringBuilder, CARD_AUTHENTICATION_ERROR);
                    }
                }
                if ((byArray[0] & 8) == 8) {
                    if (bl) {
                        if ((byArray3[0] & 8) == 8) {
                            EMV60.appendMotif(stringBuilder, CARD_AUTHENTICATION_ERROR);
                        }
                    } else if ((byArray2[0] & 8) == 8) {
                        EMV60.appendMotif(stringBuilder, CARD_AUTHENTICATION_ERROR);
                    }
                }
                if ((byArray[0] & 4) == 4) {
                    EMV60.appendMotif(stringBuilder, CARD_AUTHENTICATION_ERROR);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED) && extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                    EMV60.appendMotif(stringBuilder, CARD_REMOVED);
                }
                if ((byArray[2] & 0x10) == 16) {
                    if (bl) {
                        if ((byArray3[2] & 0x10) == 16) {
                            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                                EMV60.appendMotif(stringBuilder, CARD_REMOVED);
                            } else {
                                EMV60.appendMotif(stringBuilder, TIME_OUT);
                            }
                        }
                    } else if ((byArray2[2] & 0x10) == 16) {
                        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            EMV60.appendMotif(stringBuilder, CARD_REMOVED);
                        } else {
                            EMV60.appendMotif(stringBuilder, TIME_OUT);
                        }
                    }
                }
                if ((byArray[2] & 8) == 8) {
                    if (bl) {
                        if ((byArray3[2] & 8) == 8) {
                            EMV60.appendMotif(stringBuilder, TIME_OUT);
                        }
                    } else if ((byArray2[2] & 8) == 8) {
                        EMV60.appendMotif(stringBuilder, TIME_OUT);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED) || (byArray[2] & 4) == 4) {
                    if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR)) {
                        EMV60.appendMotif(stringBuilder, PIN_ONLINE_ERROR);
                    }
                } else if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR)) {
                    EMV60.appendMotif(stringBuilder, PIN_ERROR);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                    EMV60.appendMotif(stringBuilder, TIME_OUT);
                }
                if ((byArray[2] & 0x80) == 128) {
                    if (bl) {
                        if ((byArray3[2] & 0x80) == 128 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED) || (byArray[2] & 4) == 4) {
                                if (!extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR) && !extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                                    extendedTVR.isSet(ExtendedTVREnumeration.PIN_TIME_OUT);
                                }
                            } else {
                                EMV60.appendMotif(stringBuilder, PIN_ERROR);
                            }
                        }
                    } else if ((byArray2[2] & 0x80) == 128 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                        if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED) || (byArray[2] & 4) == 4) {
                            if (!extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR) && !extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                                extendedTVR.isSet(ExtendedTVREnumeration.PIN_TIME_OUT);
                            }
                        } else {
                            EMV60.appendMotif(stringBuilder, PIN_ERROR);
                        }
                    }
                }
                if ((byArray[2] & 0x20) == 32) {
                    if (bl) {
                        if ((byArray3[2] & 0x20) == 32 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            EMV60.appendMotif(stringBuilder, PIN_ERROR);
                        }
                    } else if ((byArray2[2] & 0x20) == 32 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                        EMV60.appendMotif(stringBuilder, PIN_ERROR);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_TIME_OUT)) {
                    EMV60.appendMotif(stringBuilder, TIME_OUT);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV60.appendMotif(stringBuilder, CARD_FORBIDDEN);
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV60.appendMotif(stringBuilder, CARD_FORBIDDEN);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV60.appendMotif(stringBuilder, CARD_REFUSED);
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV60.appendMotif(stringBuilder, CARD_REFUSED);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_WATCHED)) {
                    if (bl) {
                        if ((byArray3[3] & 0x80) == 128) {
                            EMV60.appendMotif(stringBuilder, CARD_REFUSED);
                        }
                    } else if ((byArray2[3] & 0x80) == 128) {
                        EMV60.appendMotif(stringBuilder, CARD_REFUSED);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.EXPIRATION_DATE_MISSING)) {
                    EMV60.appendMotif(stringBuilder, MANDATORY_DATA_MISSING);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    EMV60.appendMotif(stringBuilder, MANDATORY_DATA_MISSING);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                    EMV60.appendMotif(stringBuilder, MISSING_EMV_DATA);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                    EMV60.appendMotif(stringBuilder, REDUNDANT_DATA);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    if (bl) {
                        if ((byArray3[1] & 0x40) == 64) {
                            EMV60.appendMotif(stringBuilder, CARD_EXPIRED);
                        }
                    } else if ((byArray2[1] & 0x40) == 64) {
                        EMV60.appendMotif(stringBuilder, CARD_EXPIRED);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    if (bl) {
                        if ((byArray3[1] & 0x20) == 32) {
                            EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                        }
                    } else if ((byArray2[1] & 0x20) == 32) {
                        EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.LUHN_KEY_INVALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PAN_LENGTH_INVALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.DATA_FORMAT_ERROR)) {
                    EMV60.appendMotif(stringBuilder, DATA_FORMAT_ERROR);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    EMV60.appendMotif(stringBuilder, AUTHORIZATION_FORBIDDEN);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                    if (yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("55") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("75")) {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_PIN_ONLINE_ERROR);
                    } else if (!extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_REFUSED);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    if (yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("91") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("96") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("97") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("98")) {
                        EMV60.appendMotif(stringBuilder, ISSUER_NOT_REACHABLE);
                    } else if (extendedTVR.isSet(ExtendedTVREnumeration.MESSAGE_RECEIVED_INVALID)) {
                        EMV60.appendMotif(stringBuilder, INVALID_RESPONSE_STRUCTURE);
                    } else {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_INCIDENT);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT) && !extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, MERCHANT_ABORT);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.USER_ABORT)) {
                    EMV60.appendMotif(stringBuilder, USER_ABORTED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, PARTIAL_AUTHORIZATION_REFUSED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AAC_FIRST_GAC)) {
                    EMV60.appendMotif(stringBuilder, AAC_FIRST_GAC);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AAC_SECOND_GAC)) {
                    EMV60.appendMotif(stringBuilder, AAC_SECOND_GAC);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                    EMV60.appendMotif(stringBuilder, CARD_REMOVED);
                }
                if ((YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.CLOSING_PAYMENT || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.ADVICE_DEBIT) && YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction) == 0L) {
                    EMV60.appendMotif(stringBuilder, DELIVERY_PROBLEM);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REAL_CARD_NOT_ALLOWED)) {
                    EMV60.appendMotif(stringBuilder, DELIVERY_PROBLEM);
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block114;
                return MISSING_EMV_DATA;
            }
            catch (Exception exception) {
                return MISSING_EMV_DATA;
            }
        }
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder;
        block31: {
            stringBuilder = new StringBuilder();
            try {
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    EMV60.appendMotif(stringBuilder, CARD_FORBIDDEN);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, CARD_REFUSED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, BIN_REFUSED_OR_FORBIDDEN);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                    EMV60.appendMotif(stringBuilder, TIME_OUT);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    EMV60.appendMotif(stringBuilder, MANDATORY_DATA_MISSING);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                    EMV60.appendMotif(stringBuilder, REDUNDANT_DATA);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.LUHN_KEY_INVALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PAN_LENGTH_INVALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    EMV60.appendMotif(stringBuilder, INVALID_CARD_STRUCTURE);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    EMV60.appendMotif(stringBuilder, CARD_EXPIRED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    EMV60.appendMotif(stringBuilder, AUTHORIZATION_FORBIDDEN);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                    if (yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("55") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("75")) {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_PIN_ONLINE_ERROR);
                    } else if (!extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_REFUSED);
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    if (yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("91") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("96") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("97") || yP_TCD_DC_Transaction.getAuthorisationResponseCode().contentEquals("98")) {
                        EMV60.appendMotif(stringBuilder, ISSUER_NOT_REACHABLE);
                    } else if (extendedTVR.isSet(ExtendedTVREnumeration.MESSAGE_RECEIVED_INVALID)) {
                        EMV60.appendMotif(stringBuilder, INVALID_RESPONSE_STRUCTURE);
                    } else {
                        EMV60.appendMotif(stringBuilder, AUTHORIZATION_INCIDENT);
                    }
                }
                if ((extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT) || extendedTVR.isSet(ExtendedTVREnumeration.REFERRAL_REFUSED)) && !extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, MERCHANT_ABORT);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.USER_ABORT)) {
                    EMV60.appendMotif(stringBuilder, USER_ABORTED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV60.appendMotif(stringBuilder, PARTIAL_AUTHORIZATION_REFUSED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                    EMV60.appendMotif(stringBuilder, CARD_REMOVED);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CHIP_MUST_BE_USED) || extendedTVR.isSet(ExtendedTVREnumeration.UNKNOWN_SERVICE_CODE)) {
                    EMV60.appendMotif(stringBuilder, CHIP_MUST_BE_USED);
                }
                if ((YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.CLOSING_PAYMENT || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.ADVICE_DEBIT) && YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction) == 0L) {
                    EMV60.appendMotif(stringBuilder, DELIVERY_PROBLEM);
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ONLINE_REQUIRED) && extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR)) {
                    EMV60.appendMotif(stringBuilder, PIN_ONLINE_ERROR);
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block31;
                return INVALID_CARD_STRUCTURE;
            }
            catch (Exception exception) {
                return INVALID_CARD_STRUCTURE;
            }
        }
        return stringBuilder.toString();
    }

    public static ExtendedTVR getMessageCodeToDisplay(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TransactionTypeEnumeration transactionTypeEnumeration) {
        block63: {
            try {
                String string = null;
                EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
                switch (entryModeEnumeration) {
                    case ENTRY_MODE_ICC: {
                        if (YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.CREDIT) {
                            string = EMV60.getNonAchievedReasonCode(yP_TCD_DC_Transaction, YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction), transactionTypeEnumeration, yP_TCD_DC_Transaction.getExtendedTVR(), null, null, null);
                            break;
                        }
                        try {
                            byte[] byArray = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalActionCodeDenial")));
                            byte[] byArray2 = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("terminalActionCodeDefault")));
                            byte[] byArray3 = UtilsYP.redHexa(YP_Row.getStringValue(yP_TCD_DC_Transaction.getExtensionValue("tvr")));
                            string = EMV60.getNonAchievedReasonCode(yP_TCD_DC_Transaction, YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction), transactionTypeEnumeration, yP_TCD_DC_Transaction.getExtendedTVR(), byArray3, byArray, byArray2);
                        }
                        catch (Exception exception) {
                            string = EMV60.getNonAchievedReasonCode(yP_TCD_DC_Transaction, YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction), transactionTypeEnumeration, yP_TCD_DC_Transaction.getExtendedTVR(), null, null, null);
                        }
                        break;
                    }
                    default: {
                        string = EMV60.getNonAchievedReasonCode(yP_TCD_DC_Transaction, YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction), transactionTypeEnumeration, yP_TCD_DC_Transaction.getExtendedTVR(), null, null, null);
                    }
                }
                if (string == null || string.length() < 2) break block63;
                ExtendedTVR extendedTVR = new ExtendedTVR(true);
                switch (string.substring(0, 3)) {
                    case "01 ": 
                    case "02 ": 
                    case "03 ": 
                    case "05 ": 
                    case "06 ": 
                    case "15 ": {
                        if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                            extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                        } else {
                            extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                        }
                        return extendedTVR;
                    }
                    case "04 ": {
                        extendedTVR.add(ExtendedTVREnumeration.REDUNDANT_DATA);
                        return extendedTVR;
                    }
                    case "07 ": {
                        extendedTVR.add(ExtendedTVREnumeration.PIN_ABORTED);
                        return extendedTVR;
                    }
                    case "17 ": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                        return extendedTVR;
                    }
                    case "19 ": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                        return extendedTVR;
                    }
                    case "18 ": {
                        extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                        return extendedTVR;
                    }
                    case "20 ": {
                        if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                            extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                        } else {
                            extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                        }
                        return extendedTVR;
                    }
                    case "21 ": 
                    case "80 ": 
                    case "83 ": {
                        extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_REFUSED);
                        return extendedTVR;
                    }
                    case "22 ": {
                        extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN);
                        return extendedTVR;
                    }
                    case "24 ": {
                        extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                        return extendedTVR;
                    }
                    case "27 ": {
                        extendedTVR.add(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED);
                        return extendedTVR;
                    }
                }
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "getMessageCodeToDisplay() ", exception);
            }
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static ExtendedTVR getMessageCodeToDisplay(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ExtendedTVR extendedTVR = new ExtendedTVR();
        try {
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                switch (YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction)) {
                    case REVERSAL_DEBIT: 
                    case CREDIT: 
                    case REVERSAL_QUASI_CASH: 
                    case REFUND_QUASI_CASH: {
                        return null;
                    }
                }
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED) || yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MESSAGE_RECEIVED_INVALID)) {
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
                if (entryModeEnumeration != EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE && entryModeEnumeration != EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE_FALLBACK) {
                    extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                    return extendedTVR;
                }
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                extendedTVR.add(ExtendedTVREnumeration.MERCHANT_ABORT);
                return extendedTVR;
            }
            if (!yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) return null;
            extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
            return extendedTVR;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static String getNonAchievedReasonCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, EntryModeEnumeration entryModeEnumeration, TransactionTypeEnumeration transactionTypeEnumeration, ExtendedTVR extendedTVR, byte[] byArray, byte[] byArray2, byte[] byArray3) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return EMV60.getNonAchievedReasonCodeForRefund(yP_TCD_DC_Transaction, extendedTVR);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return EMV60.getNonAchievedReasonCodeForReversal(yP_TCD_DC_Transaction, extendedTVR);
            }
        }
        if (entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC) {
            return EMV60.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR, byArray, byArray2, byArray3);
        }
        return EMV60.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR);
    }
}

