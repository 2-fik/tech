/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.yp.utils.NameValue;

public class ConfigReader {
    List<NameValue> list = new ArrayList<NameValue>();
    int currentPos = 0;

    public ConfigReader(String string) {
        try {
            String string2;
            FileInputStream fileInputStream = new FileInputStream(string);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            while ((string2 = bufferedReader.readLine()) != null) {
                String[] stringArray;
                if ((string2 = string2.trim()).length() <= 0 || (stringArray = string2.split("=")).length != 2) continue;
                this.list.add(new NameValue(stringArray[0], stringArray[1]));
            }
            fileInputStream.close();
        }
        catch (Exception exception) {}
    }

    public String getNext(String string, int n) {
        if (n == 1) {
            this.currentPos = 0;
        }
        while (this.list.size() > this.currentPos) {
            if (string.compareTo(this.list.get(this.currentPos).getName()) == 0) {
                return this.list.get(this.currentPos++).getValue();
            }
            ++this.currentPos;
        }
        return null;
    }

    public static String get(String string, String string2) throws Exception {
        Properties properties = new Properties();
        FileInputStream fileInputStream = new FileInputStream(string);
        properties.load(fileInputStream);
        fileInputStream.close();
        return properties.getProperty(string2);
    }
}

