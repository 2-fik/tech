/*
 * Decompiled with CFR 0.152.
 */
package org.yp.utils;

import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public final class EMV {
    public static final int TAG_42 = 66;
    public static final int TAG_4F = 79;
    public static final int TAG_50 = 80;
    public static final int TAG_56 = 86;
    public static final int TAG_57 = 87;
    public static final int TAG_5A = 90;
    public static final int TAG_61 = 97;
    public static final int TAG_6F = 111;
    public static final int TAG_70 = 112;
    public static final int TAG_71 = 113;
    public static final int TAG_72 = 114;
    public static final int TAG_73 = 115;
    public static final int TAG_77 = 119;
    public static final int TAG_80 = 128;
    public static final int TAG_81 = 129;
    public static final int TAG_82 = 130;
    public static final int TAG_83 = 131;
    public static final int TAG_84 = 132;
    public static final int TAG_86 = 134;
    public static final int TAG_87 = 135;
    public static final int TAG_88 = 136;
    public static final int TAG_89 = 137;
    public static final int TAG_8A = 138;
    public static final int TAG_8C = 140;
    public static final int TAG_8D = 141;
    public static final int TAG_8E = 142;
    public static final int TAG_8F = 143;
    public static final int TAG_90 = 144;
    public static final int TAG_91 = 145;
    public static final int TAG_92 = 146;
    public static final int TAG_93 = 147;
    public static final int TAG_94 = 148;
    public static final int TAG_95 = 149;
    public static final int TAG_97 = 151;
    public static final int TAG_98 = 152;
    public static final int TAG_99 = 153;
    public static final int TAG_9A = 154;
    public static final int TAG_9B = 155;
    public static final int TAG_9C = 156;
    public static final int TAG_9D = 157;
    public static final int TAG_A5 = 165;
    public static final int TAG_5F20 = 24352;
    public static final int TAG_5F24 = 24356;
    public static final int TAG_5F25 = 24357;
    public static final int TAG_5F28 = 24360;
    public static final int TAG_5F2A = 24362;
    public static final int TAG_5F2D = 24365;
    public static final int TAG_5F30 = 24368;
    public static final int TAG_5F34 = 24372;
    public static final int TAG_5F36 = 24374;
    public static final int TAG_5F50 = 24400;
    public static final int TAG_5F53 = 24403;
    public static final int TAG_5F54 = 24404;
    public static final int TAG_5F55 = 24405;
    public static final int TAG_5F56 = 24406;
    public static final int TAG_5F57 = 24407;
    public static final int TAG_9F01 = 40705;
    public static final int TAG_9F02 = 40706;
    public static final int TAG_9F03 = 40707;
    public static final int TAG_9F04 = 40708;
    public static final int TAG_9F05 = 40709;
    public static final int TAG_9F06 = 40710;
    public static final int TAG_9F07 = 40711;
    public static final int TAG_9F08 = 40712;
    public static final int TAG_9F09 = 40713;
    public static final int TAG_9F0B = 40715;
    public static final int TAG_9F0D = 40717;
    public static final int TAG_9F0E = 40718;
    public static final int TAG_9F0F = 40719;
    public static final int TAG_9F10 = 40720;
    public static final int TAG_9F11 = 40721;
    public static final int TAG_9F12 = 40722;
    public static final int TAG_9F13 = 40723;
    public static final int TAG_9F14 = 40724;
    public static final int TAG_9F15 = 40725;
    public static final int TAG_9F16 = 40726;
    public static final int TAG_9F17 = 40727;
    public static final int TAG_9F18 = 40728;
    public static final int TAG_9F1A = 40730;
    public static final int TAG_9F1B = 40731;
    public static final int TAG_9F1C = 40732;
    public static final int TAG_9F1D = 40733;
    public static final int TAG_9F1E = 40734;
    public static final int TAG_9F1F = 40735;
    public static final int TAG_9F20 = 40736;
    public static final int TAG_9F21 = 40737;
    public static final int TAG_9F22 = 40738;
    public static final int TAG_9F23 = 40739;
    public static final int TAG_9F26 = 40742;
    public static final int TAG_9F27 = 40743;
    public static final int TAG_9F2A = 40746;
    public static final int TAG_9F2D = 40749;
    public static final int TAG_9F2E = 40750;
    public static final int TAG_9F2F = 40751;
    public static final int TAG_9F32 = 40754;
    public static final int TAG_9F33 = 40755;
    public static final int TAG_9F34 = 40756;
    public static final int TAG_9F35 = 40757;
    public static final int TAG_9F36 = 40758;
    public static final int TAG_9F37 = 40759;
    public static final int TAG_9F38 = 40760;
    public static final int TAG_9F39 = 40761;
    public static final int TAG_9F3A = 40762;
    public static final int TAG_9F3B = 40763;
    public static final int TAG_9F3C = 40764;
    public static final int TAG_9F3D = 40765;
    public static final int TAG_9F40 = 40768;
    public static final int TAG_9F41 = 40769;
    public static final int TAG_9F42 = 40770;
    public static final int TAG_9F43 = 40771;
    public static final int TAG_9F44 = 40772;
    public static final int TAG_9F45 = 40773;
    public static final int TAG_9F46 = 40774;
    public static final int TAG_9F47 = 40775;
    public static final int TAG_9F48 = 40776;
    public static final int TAG_9F49 = 40777;
    public static final int TAG_9F4A = 40778;
    public static final int TAG_9F4B = 40779;
    public static final int TAG_9F4C = 40780;
    public static final int TAG_9F4D = 40781;
    public static final int TAG_9F4E = 40782;
    public static final int TAG_9F4F = 40783;
    public static final int TAG_9F53 = 40787;
    public static final int TAG_9F50 = 40784;
    public static final int TAG_9F5A = 40794;
    public static final int TAG_9F5D = 40797;
    public static final int TAG_9F66 = 40806;
    public static final int TAG_9F69 = 40809;
    public static final int TAG_9F6A = 40810;
    public static final int TAG_9F6B = 40811;
    public static final int TAG_9F6C = 40812;
    public static final int TAG_9F6D = 40813;
    public static final int TAG_9F6E = 40814;
    public static final int TAG_9F7C = 40828;
    public static final int TAG_BF0C = 48908;
    public static final int TAG_DF8115 = 14647573;
    public static final int TAG_DF8117 = 14647575;
    public static final int TAG_DF8118 = 14647576;
    public static final int TAG_DF8119 = 14647577;
    public static final int TAG_DF811B = 14647579;
    public static final int TAG_DF811D = 14647581;
    public static final int TAG_DF811E = 14647582;
    public static final int TAG_DF811F = 14647583;
    public static final int TAG_DF8120 = 14647584;
    public static final int TAG_DF8121 = 14647585;
    public static final int TAG_DF8122 = 14647586;
    public static final int TAG_DF8123 = 14647587;
    public static final int TAG_DF8124 = 14647588;
    public static final int TAG_DF8125 = 14647589;
    public static final int TAG_DF8126 = 14647590;
    public static final int TAG_DF812C = 14647596;
    public static final String STD_NDOL_COMPLETION = "57505A717282898A8E8F91959A9B9C5F245F255F2A5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F339F349F359F369F379F399F415F28";
    public static final String RID_CB = "A000000042";
    public static final String AID_NAME_CB = "CB";
    public static final String RID_VISA = "A000000003";
    public static final String AID_VISA = "A0000000031010";
    public static final String AID_ELECTRON = "A0000000032010";
    public static final String AID_NAME_VISA = "VISA";
    public static final String AID_NAME_ELECTRON = "ELECTRON";
    public static final String AID_ORANGE_CASH = "A000000003101045047701";
    public static final String AID_NAME_ORANGE_CASH = "ORANGE CASH";
    public static final String AID_NAME_APPLE_PAY = "APPLE PAY";
    public static final String AID_NAME_VPAY = "VPAY";
    public static final String RID_MASTERCARD = "A000000004";
    public static final String AID_MASTERCARD = "A0000000041010";
    public static final String AID_MAESTRO = "A0000000043060";
    public static final String AID_NAME_MASTERCARD = "MASTERCARD";
    public static final String AID_NAME_MAESTRO = "MAESTRO";
    public static final String RID_AMEX = "A000000025";
    public static final String AID_AMEX = "A00000002501";
    public static final String AID_NAME_AMEX = "AMEX";
    public static final String RID_MOVEUP = "A000000180";
    public static final String AID_NAME_MOVEUP = "MOVE UP";
    public static final String RID_JCB = "A000000065";
    public static final String AID_JCB = "A0000000651010";
    public static final String AID_NAME_JCB = "JCB";
    public static final String RID_DFS = "A000000152";
    public static final String RID_DFS_LEGACY = "A000000324";
    public static final String AID_NAME_DFS = "DISCOVER";
    public static final String RID_UPI = "A000000333";
    public static final String AID_NAME_UPI = "UNION PAY";
    public static final String CONECS_ACQUIRER_CODE = "10000";
    public static final String RID_CONECS = "D250000012";
    public static final String AID_SODEXO = "D25000001210";
    public static final String AID_NATIXIS_INTERTITRES = "D25000001220";
    public static final String AID_EDENRED = "D25000001230";
    public static final String AID_CHEQUE_DEJEUNER = "D25000001240";
    public static final String AID_NAME_CONECS = "CONECS";
    public static final String AID_NAME_SODEXO = "SODEXO";
    public static final String AID_NAME_NATIXIS_INTERTITRES = "NATIXIS INTERTITRES";
    public static final String AID_NAME_EDENRED = "EDENRED";
    public static final String AID_NAME_CHEQUE_DEJEUNER = "CHEQUE DEJEUNER";
    public static final String AID_NAME_CADHOC = "CADHOC";
    public static final String AID_NAME_KADEOS = "KADEOS";
    public static final String AID_NAME_CHEQUE = "CHEQUE";
    public static final String AID_NAME_MONEO_RESTO = "MONEO RESTO";
    public static final String AID_NAME_MONETICO_RESTO = "MONETICO RESTO";
    public static final String AID_NAME_DIGIBON = "DIGIBON";
    public static final String AID_NAME_SWILE = "SWILE";
    public static final String AID_NAME_FRANFINANCE = "FRANFINANCE";
    public static final String AID_NAME_ILLICADO = "ILLICADO";
    public static final String AID_NAME_ACCORD = "ACCORD";
    public static final String RID_CIB = "A000000280";
    public static final String AID_NAME_CIB = "CIB";
    public static final String AID_NAME_UNKNOWN = "UNKNOWN";

    public static final String getAIDName(String string) {
        return EMV.getAIDName(string, null);
    }

    public static final boolean isItAConecsCard(String string) {
        if (string == null || string.isEmpty()) {
            return false;
        }
        switch (string) {
            case "SODEXO": 
            case "EDENRED": 
            case "CHEQUE DEJEUNER": 
            case "NATIXIS INTERTITRES": 
            case "CONECS": {
                return true;
            }
        }
        return false;
    }

    public static final String getAIDName(String string, String string2) {
        String string3 = string.startsWith(RID_CB) ? AID_NAME_CB : (string.startsWith(RID_VISA) ? (string.contentEquals(AID_VISA) ? AID_NAME_VISA : (string.contentEquals(AID_ELECTRON) ? AID_NAME_ELECTRON : (string.contentEquals(AID_ORANGE_CASH) ? AID_NAME_ORANGE_CASH : AID_NAME_VISA))) : (string.startsWith(RID_MASTERCARD) ? (string.contentEquals(AID_MASTERCARD) ? AID_NAME_MASTERCARD : (string.contentEquals(AID_MAESTRO) ? AID_NAME_MAESTRO : AID_NAME_MASTERCARD)) : (string.startsWith(RID_AMEX) ? (string.contentEquals(AID_AMEX) ? AID_NAME_AMEX : AID_NAME_AMEX) : (string.startsWith(RID_JCB) ? (string.contentEquals(AID_JCB) ? AID_NAME_JCB : AID_NAME_JCB) : (string.startsWith(RID_CONECS) ? (string.startsWith(AID_SODEXO) ? AID_NAME_SODEXO : (string.startsWith(AID_NATIXIS_INTERTITRES) ? AID_NAME_NATIXIS_INTERTITRES : (string.startsWith(AID_EDENRED) ? AID_NAME_EDENRED : (string.startsWith(AID_CHEQUE_DEJEUNER) ? AID_NAME_CHEQUE_DEJEUNER : AID_NAME_CONECS)))) : (string.startsWith(RID_CIB) ? AID_NAME_CIB : (string.startsWith(RID_DFS) || string.startsWith(RID_DFS_LEGACY) ? AID_NAME_DFS : (string.startsWith(RID_UPI) ? AID_NAME_UPI : (string.startsWith(RID_MOVEUP) ? AID_NAME_MOVEUP : AID_NAME_UNKNOWN)))))))));
        if (string2 != null) {
            if (string2.startsWith("450477")) {
                string3 = AID_NAME_ORANGE_CASH;
            } else if (string2.startsWith("48384500") || string2.startsWith("48384501") || string2.startsWith("48384502") || string2.startsWith("507596")) {
                string3 = AID_NAME_NATIXIS_INTERTITRES;
            } else if (string2.startsWith("483846") || string2.startsWith("50759700") || string2.startsWith("50759701")) {
                string3 = AID_NAME_SODEXO;
            } else if (string2.startsWith("516130") || string2.startsWith("517912")) {
                string3 = AID_NAME_CADHOC;
            } else if (string2.startsWith("507598") || string2.startsWith("5314220") || string2.startsWith("5314227") || string2.startsWith("5314228") || string2.startsWith("5314229")) {
                string3 = AID_NAME_EDENRED;
            } else if (string2.startsWith("532041") || string2.startsWith("519303") || string2.startsWith("507599")) {
                string3 = AID_NAME_CHEQUE_DEJEUNER;
            } else if (string2.startsWith("549298")) {
                string3 = AID_NAME_KADEOS;
            } else if (string2.startsWith("529234")) {
                string3 = AID_NAME_MONEO_RESTO;
            } else if (string2.startsWith("533527")) {
                string3 = AID_NAME_MONETICO_RESTO;
            } else if (string2.startsWith("534578")) {
                string3 = AID_NAME_SWILE;
            } else if (!(string2.startsWith("441708") || string2.startsWith("481142") || string2.startsWith("481144") || string2.startsWith("559529") || !string2.startsWith("538774"))) {
                string3 = AID_NAME_DIGIBON;
            }
        }
        return string3;
    }

    public static final String getAIDNameByPAN(String string) {
        if (string == null || string.isEmpty()) {
            return AID_NAME_UNKNOWN;
        }
        if (string.charAt(0) == '3' && (string.startsWith("300") || string.startsWith("301") || string.startsWith("302") || string.startsWith("303") || string.startsWith("304") || string.startsWith("305") || string.startsWith("3095") || string.startsWith("36") || string.startsWith("38") || string.startsWith("39"))) {
            return AID_NAME_DFS;
        }
        if (string.charAt(0) == '4') {
            if (string.startsWith("450477")) {
                return AID_NAME_ORANGE_CASH;
            }
            if (string.startsWith("48384500") || string.startsWith("48384501") || string.startsWith("48384502")) {
                return AID_NAME_NATIXIS_INTERTITRES;
            }
            if (string.startsWith("483846")) {
                return AID_NAME_SODEXO;
            }
            return AID_NAME_VISA;
        }
        if (string.charAt(0) == '5') {
            if (string.startsWith("50759")) {
                if (string.startsWith("507596")) {
                    return AID_NAME_NATIXIS_INTERTITRES;
                }
                if (string.startsWith("50759700") || string.startsWith("50759701")) {
                    return AID_NAME_SODEXO;
                }
                if (string.startsWith("507598")) {
                    return AID_NAME_EDENRED;
                }
                if (string.startsWith("507599")) {
                    return AID_NAME_CHEQUE_DEJEUNER;
                }
                return AID_NAME_CONECS;
            }
            if (string.startsWith("516130") || string.startsWith("517912")) {
                return AID_NAME_CADHOC;
            }
            if (string.startsWith("5314220") || string.startsWith("5314227") || string.startsWith("5314228") || string.startsWith("5314229")) {
                return AID_NAME_EDENRED;
            }
            if (string.startsWith("532041") || string.startsWith("519303")) {
                return AID_NAME_CHEQUE_DEJEUNER;
            }
            if (string.startsWith("549298")) {
                return AID_NAME_KADEOS;
            }
            if (string.startsWith("529234")) {
                return AID_NAME_MONEO_RESTO;
            }
            if (string.startsWith("533527")) {
                return AID_NAME_MONETICO_RESTO;
            }
            if (string.startsWith("534578")) {
                return AID_NAME_SWILE;
            }
            if (string.startsWith("538774")) {
                return AID_NAME_DIGIBON;
            }
            if (string.startsWith("503206")) {
                return AID_NAME_FRANFINANCE;
            }
            if (string.startsWith("503202")) {
                return AID_NAME_ACCORD;
            }
            return AID_NAME_MASTERCARD;
        }
        if (string.charAt(0) == '6') {
            if (string.startsWith("62")) {
                return AID_NAME_UPI;
            }
            if (string.startsWith("64") || string.startsWith("65") || string.startsWith("6011")) {
                return AID_NAME_DFS;
            }
        }
        if (string.charAt(0) == '2' && string.length() >= 6) {
            try {
                int n = Integer.parseInt(string.substring(0, 6));
                if (n >= 222100 && n <= 272099) {
                    return AID_NAME_MASTERCARD;
                }
            }
            catch (Exception exception) {}
        }
        if (string.startsWith("34") || string.startsWith("37")) {
            return AID_NAME_AMEX;
        }
        if (string.startsWith("35")) {
            return AID_NAME_JCB;
        }
        if (string.startsWith("925000410") || string.startsWith("925000478")) {
            return AID_NAME_ILLICADO;
        }
        return AID_NAME_UNKNOWN;
    }

    public static void setARQCResponse(byte[] byArray, byte[] byArray2, byte[] byArray3, byte[] byArray4, ExtendedTVR extendedTVR) {
        if (byArray == null || byArray.length != 1) {
            return;
        }
        if (byArray2 == null || byArray2.length != 5) {
            return;
        }
        if (byArray3 == null || byArray3.length != 5) {
            return;
        }
        if (byArray4 == null || byArray4.length != 5) {
            return;
        }
        if (extendedTVR == null) {
            return;
        }
        if ((byArray[0] & 0x80) != 128) {
            return;
        }
        int n = 0;
        while (n < 5) {
            if ((byArray4[n] & byArray3[n]) != 0) {
                return;
            }
            if ((byArray4[n] & byArray2[n]) != 0) {
                return;
            }
            ++n;
        }
        extendedTVR.add(ExtendedTVREnumeration.ARQC_RESPONSE);
    }

    private static String getNonAchievedReasonCodeForRefund(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                EMV.appendMotif(stringBuilder, "63 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                EMV.appendMotif(stringBuilder, "63 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                EMV.appendMotif(stringBuilder, "03 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                EMV.appendMotif(stringBuilder, "05 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                EMV.appendMotif(stringBuilder, "04 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                EMV.appendMotif(stringBuilder, "55 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EMV.appendMotif(stringBuilder, "54 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                EMV.appendMotif(stringBuilder, "22 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                EMV.appendMotif(stringBuilder, "21 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                EMV.appendMotif(stringBuilder, "88 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.REFERRAL_REFUSED)) {
                EMV.appendMotif(stringBuilder, "69 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                EMV.appendMotif(stringBuilder, "57 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                EMV.appendMotif(stringBuilder, "13 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                EMV.appendMotif(stringBuilder, "32 ");
            }
        }
        catch (Exception exception) {
            return "25 ";
        }
        EMV.appendMotif(stringBuilder, "25 ");
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForReversal(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                EMV.appendMotif(stringBuilder, "63 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                EMV.appendMotif(stringBuilder, "63 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                EMV.appendMotif(stringBuilder, "03 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                EMV.appendMotif(stringBuilder, "01 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                EMV.appendMotif(stringBuilder, "04 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                EMV.appendMotif(stringBuilder, "55 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EMV.appendMotif(stringBuilder, "54 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                EMV.appendMotif(stringBuilder, "57 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND) || extendedTVR.isSet(ExtendedTVREnumeration.ALREADY_VOIDED)) {
                EMV.appendMotif(stringBuilder, "24 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                EMV.appendMotif(stringBuilder, "14 ");
            }
            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                EMV.appendMotif(stringBuilder, "32 ");
            }
        }
        catch (Exception exception) {
            return "72 ";
        }
        return stringBuilder.toString();
    }

    private static void appendMotif(StringBuilder stringBuilder, String string) {
        if (!stringBuilder.toString().contains(string)) {
            stringBuilder.append(string);
        }
    }

    private static String getNonAchievedReasonCodeForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR, byte[] byArray, byte[] byArray2, byte[] byArray3) {
        StringBuilder stringBuilder;
        block100: {
            stringBuilder = new StringBuilder();
            boolean bl = false;
            byte[] byArray4 = new byte[5];
            if (byArray == null || byArray.length < 5) {
                byArray = byArray4;
            }
            if (byArray2 == null || byArray2.length < 5) {
                byArray2 = byArray4;
            }
            if (byArray3 == null || byArray3.length < 5) {
                byArray3 = byArray4;
            }
            try {
                if ((byArray[0] & 0x40) == 64) {
                    if (bl) {
                        if ((byArray3[0] & 0x40) == 64) {
                            EMV.appendMotif(stringBuilder, "06 ");
                        }
                    } else if ((byArray2[0] & 0x40) == 64) {
                        EMV.appendMotif(stringBuilder, "06 ");
                    }
                }
                if ((byArray[0] & 8) == 8) {
                    if (bl) {
                        if ((byArray3[0] & 8) == 8) {
                            EMV.appendMotif(stringBuilder, "06 ");
                        }
                    } else if ((byArray2[0] & 8) == 8) {
                        EMV.appendMotif(stringBuilder, "06 ");
                    }
                }
                if ((byArray[0] & 4) == 4) {
                    EMV.appendMotif(stringBuilder, "06 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED) && extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                    EMV.appendMotif(stringBuilder, "32 ");
                }
                if ((byArray[2] & 0x10) == 16) {
                    if (bl) {
                        if ((byArray3[2] & 0x10) == 16) {
                            if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                                EMV.appendMotif(stringBuilder, "32 ");
                            } else {
                                EMV.appendMotif(stringBuilder, "87 ");
                            }
                        }
                    } else if ((byArray2[2] & 0x10) == 16) {
                        if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            EMV.appendMotif(stringBuilder, "32 ");
                        } else {
                            EMV.appendMotif(stringBuilder, "87 ");
                        }
                    }
                }
                if ((byArray[2] & 8) == 8) {
                    if (bl) {
                        if ((byArray3[2] & 8) == 8) {
                            EMV.appendMotif(stringBuilder, "87 ");
                        }
                    } else if ((byArray2[2] & 8) == 8) {
                        EMV.appendMotif(stringBuilder, "87 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ERROR)) {
                    EMV.appendMotif(stringBuilder, "08 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_ABORTED)) {
                    EMV.appendMotif(stringBuilder, "07 ");
                }
                if ((byArray[2] & 0x80) == 128) {
                    if (bl) {
                        if ((byArray3[2] & 0x80) == 128 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            EMV.appendMotif(stringBuilder, "08 ");
                        }
                    } else if ((byArray2[2] & 0x80) == 128 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                        EMV.appendMotif(stringBuilder, "08 ");
                    }
                }
                if ((byArray[2] & 0x20) == 32) {
                    if (bl) {
                        if ((byArray3[2] & 0x20) == 32 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                            EMV.appendMotif(stringBuilder, "08 ");
                        }
                    } else if ((byArray2[2] & 0x20) == 32 && !extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                        EMV.appendMotif(stringBuilder, "08 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PIN_TIME_OUT)) {
                    EMV.appendMotif(stringBuilder, "87 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV.appendMotif(stringBuilder, "19 ");
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV.appendMotif(stringBuilder, "19 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV.appendMotif(stringBuilder, "20 ");
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV.appendMotif(stringBuilder, "20 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV.appendMotif(stringBuilder, "19 ");
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV.appendMotif(stringBuilder, "19 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    if (bl) {
                        if ((byArray3[0] & 0x10) == 16) {
                            EMV.appendMotif(stringBuilder, "20 ");
                        }
                    } else if ((byArray2[0] & 0x10) == 16) {
                        EMV.appendMotif(stringBuilder, "20 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_WATCHED)) {
                    if (bl) {
                        if ((byArray3[3] & 0x80) == 128) {
                            EMV.appendMotif(stringBuilder, "18 ");
                        }
                    } else if ((byArray2[3] & 0x80) == 128) {
                        EMV.appendMotif(stringBuilder, "18 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.EXPIRATION_DATE_MISSING)) {
                    EMV.appendMotif(stringBuilder, "03 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    EMV.appendMotif(stringBuilder, "03 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MISSING_EMV_DATA)) {
                    EMV.appendMotif(stringBuilder, "01 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                    EMV.appendMotif(stringBuilder, "04 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    if (bl) {
                        if ((byArray3[1] & 0x40) == 64) {
                            EMV.appendMotif(stringBuilder, "17 ");
                        }
                    } else if ((byArray2[1] & 0x40) == 64) {
                        EMV.appendMotif(stringBuilder, "17 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    if (bl) {
                        if ((byArray3[1] & 0x20) == 32) {
                            EMV.appendMotif(stringBuilder, "11 ");
                        }
                    } else if ((byArray2[1] & 0x20) == 32) {
                        EMV.appendMotif(stringBuilder, "11 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.LUHN_KEY_INVALID)) {
                    EMV.appendMotif(stringBuilder, "15 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PAN_LENGTH_INVALID)) {
                    EMV.appendMotif(stringBuilder, "15 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.DATA_FORMAT_ERROR)) {
                    EMV.appendMotif(stringBuilder, "05 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    EMV.appendMotif(stringBuilder, "22 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                    EMV.appendMotif(stringBuilder, "21 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    EMV.appendMotif(stringBuilder, "88 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REFERRAL_REFUSED)) {
                    EMV.appendMotif(stringBuilder, "69 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.USER_ABORT)) {
                    if ((byArray[2] & 0x80) == 128) {
                        EMV.appendMotif(stringBuilder, "07 ");
                    } else {
                        EMV.appendMotif(stringBuilder, "87 ");
                    }
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV.appendMotif(stringBuilder, "27 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AAC_FIRST_GAC)) {
                    EMV.appendMotif(stringBuilder, "11 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AAC_SECOND_GAC)) {
                    EMV.appendMotif(stringBuilder, "12 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                    EMV.appendMotif(stringBuilder, "32 ");
                }
                if ((YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.CLOSING_PAYMENT || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.ADVICE_DEBIT) && YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction) == 0L) {
                    EMV.appendMotif(stringBuilder, "30 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REAL_CARD_NOT_ALLOWED)) {
                    EMV.appendMotif(stringBuilder, "30 ");
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block100;
                return "01 ";
            }
            catch (Exception exception) {
                return "01 ";
            }
        }
        return stringBuilder.toString();
    }

    private static String getNonAchievedReasonCodeForDebit(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, ExtendedTVR extendedTVR) {
        StringBuilder stringBuilder;
        block20: {
            stringBuilder = new StringBuilder();
            try {
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                    EMV.appendMotif(stringBuilder, "19 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                    EMV.appendMotif(stringBuilder, "19 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                    EMV.appendMotif(stringBuilder, "20 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                    EMV.appendMotif(stringBuilder, "20 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                    EMV.appendMotif(stringBuilder, "03 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.REDUNDANT_DATA)) {
                    EMV.appendMotif(stringBuilder, "04 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.LUHN_KEY_INVALID)) {
                    EMV.appendMotif(stringBuilder, "15 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PAN_LENGTH_INVALID)) {
                    EMV.appendMotif(stringBuilder, "15 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                    EMV.appendMotif(stringBuilder, "15 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                    EMV.appendMotif(stringBuilder, "17 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                    EMV.appendMotif(stringBuilder, "22 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_BEFORE_CALL) && !extendedTVR.isSet(ExtendedTVREnumeration.FORCED_AFTER_CALL)) {
                    EMV.appendMotif(stringBuilder, "21 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.AUTHORIZATION_INCIDENT)) {
                    EMV.appendMotif(stringBuilder, "88 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.USER_ABORT)) {
                    EMV.appendMotif(stringBuilder, "87 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.PARTIAL_AUTHORIZATION_REFUSED)) {
                    EMV.appendMotif(stringBuilder, "27 ");
                }
                if (extendedTVR.isSet(ExtendedTVREnumeration.CARD_REMOVED)) {
                    EMV.appendMotif(stringBuilder, "32 ");
                }
                if ((YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.CLOSING_PAYMENT || YP_TCD_DCC_Business.getTransactionType(yP_TCD_DC_Transaction) == TransactionTypeEnumeration.ADVICE_DEBIT) && YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction) == 0L) {
                    EMV.appendMotif(stringBuilder, "30 ");
                }
                if (stringBuilder != null && stringBuilder.length() != 0) break block20;
                return "15 ";
            }
            catch (Exception exception) {
                return "15 ";
            }
        }
        return stringBuilder.toString();
    }

    public static ExtendedTVR getMessageCodeToDisplay(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        ExtendedTVR extendedTVR = new ExtendedTVR();
        try {
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.AUTHORIZATION_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.AUTHORIZATION_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_ALLOWED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_FORBIDDEN);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_FORBIDDEN)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.BIN_REFUSED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_REFUSED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_EXPIRED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_EXPIRED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_NOT_YET_VALID)) {
                EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
                if (entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE || entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE_FALLBACK) {
                    extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                } else {
                    extendedTVR.add(ExtendedTVREnumeration.CARD_NOT_YET_VALID);
                }
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED)) {
                extendedTVR.add(ExtendedTVREnumeration.CARD_AUTHENTICATION_FAILED);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MANDATORY_DATA_MISSING)) {
                extendedTVR.add(ExtendedTVREnumeration.MANDATORY_DATA_MISSING);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.MERCHANT_ABORT)) {
                extendedTVR.add(ExtendedTVREnumeration.MERCHANT_ABORT);
                return extendedTVR;
            }
            if (yP_TCD_DC_Transaction.getExtendedTVR().isSet(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND)) {
                extendedTVR.add(ExtendedTVREnumeration.TRANSACTION_NOT_FOUND);
                return extendedTVR;
            }
        }
        catch (Exception exception) {
            return null;
        }
        return null;
    }

    public static String getNonAchievedReasonCode(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, EntryModeEnumeration entryModeEnumeration, TransactionTypeEnumeration transactionTypeEnumeration, ExtendedTVR extendedTVR, byte[] byArray, byte[] byArray2, byte[] byArray3) {
        switch (transactionTypeEnumeration) {
            case CREDIT: 
            case REFUND_QUASI_CASH: {
                return EMV.getNonAchievedReasonCodeForRefund(yP_TCD_DC_Transaction, extendedTVR);
            }
            case REVERSAL_DEBIT: 
            case REVERSAL_QUASI_CASH: {
                return EMV.getNonAchievedReasonCodeForReversal(yP_TCD_DC_Transaction, extendedTVR);
            }
        }
        if (entryModeEnumeration == EntryModeEnumeration.ENTRY_MODE_ICC) {
            return EMV.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR, byArray, byArray2, byArray3);
        }
        return EMV.getNonAchievedReasonCodeForDebit(yP_TCD_DC_Transaction, extendedTVR);
    }
}

