/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.transaction;

public class DAO_TRS_EXT_Emv {
    public byte[] aid = new byte[32];
    public byte[] cryptoInformationData = new byte[2];
    public byte[] appCryptogram = new byte[16];
    public byte[] unpredictableNumber = new byte[8];
    public byte[] appInterchangeProfile = new byte[4];
    public byte[] appTransactionCounter = new byte[4];
    public byte[] issuerAppData = new byte[64];
    public byte[] cvmResult = new byte[6];
    public byte[] appUsageControl = new byte[4];
    public byte[] terminalCapabilities = new byte[6];
    public byte[] tvr = new byte[10];
    public byte[] issuerActionCodeDefault = new byte[10];
    public byte[] issuerActionCodeDenial = new byte[10];
    public byte[] issuerActionCodeOnline = new byte[10];
    public byte[] terminalActionCodeDefault = new byte[10];
    public byte[] terminalActionCodeDenial = new byte[10];
    public byte[] terminalActionCodeOnline = new byte[10];
    public byte[] transactionStatusInformation = new byte[4];
    public byte[] issuerScriptResults = new byte[320];
    public byte[] cvmList = new byte[504];
    public byte[] issuerAuthenticationData = new byte[32];
    public byte[] applicationLabel = new byte[16];
    public byte[] applicationPreferredName = new byte[16];
    public byte[] applicationVersionNumberIcc = new byte[4];
    public byte[] applicationVersionNumber = new byte[4];
    public byte[] terminalType = new byte[2];
    public byte[] transactionSequenceCounter = new byte[8];
    public byte[] emvAuthorizedAmount = new byte[12];
    public byte[] issuerResponseCode = new byte[2];
    public int issuerCountryCode = 0;
}

