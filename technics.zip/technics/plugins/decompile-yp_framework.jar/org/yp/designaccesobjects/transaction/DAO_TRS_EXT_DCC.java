/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.transaction;

public class DAO_TRS_EXT_DCC {
    public Boolean dccIndicator;
    public byte[] dccAuthorisationApprovalCode = new byte[6];
    public int dccSTAN = 0;
    public byte[] dccInvertedRateValue = new byte[9];
    public byte[] dccMarkUp = new byte[4];
    public byte[] dccChangeRate = new byte[9];
    public byte[] dccChangeRateFraction = new byte[1];
    public byte[] dccInvertedRateMinorUnit = new byte[1];
    public byte[] dccInvertedRateDisplayUnit = new byte[1];
    public byte[] dccMarkUpPercentageValue = new byte[8];
    public byte[] dccMarkUpPercentageDicimalPoint = new byte[1];
    public byte[] dccBaseCurrencyAlphabeticCode = new byte[3];
    public long dccReferenceConvertedAmount = 0L;
    public byte[] dccReferenceAuthorisationApprovalCode = new byte[6];
}

