/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.transaction;

public class DAO_TRS_EXT_Ctcl {
    public byte[] customerExclusiveData = new byte[64];
    public byte[] formFactor = new byte[70];
    public byte[] terminalTransactionQualifiers = new byte[8];
    public byte[] kernelID = new byte[2];
    public byte[] nonAchievedReason = new byte[6];
    public byte[] errorIndicator = new byte[6];
    public byte[] availableOfflineSpendingAmount = new byte[12];
    public byte[] cardTransactionQualifier = new byte[4];
    public byte[] cardAuthenticationRelatedData = new byte[16];
    public byte[] applicationProgramID = new byte[32];
    public byte[] posCardholderInteractionInformation = new byte[6];
    public byte[] mobileSupportIndicator = new byte[2];
    public byte[] rtt = new byte[10];
    public byte[] referenceRtt = new byte[10];
    public byte[] referenceFormFactor = new byte[70];
}

