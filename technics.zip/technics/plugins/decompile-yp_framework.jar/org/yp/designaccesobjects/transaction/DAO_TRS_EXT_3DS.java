/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.transaction;

public class DAO_TRS_EXT_3DS {
    public byte[] eCommerceExtra = new byte[3];
    public byte[] vadsTransactionIdentifier = new byte[40];
    public byte[] cavv = new byte[40];
    public byte[] eCommerceSecurityType = new byte[2];
    public byte[] eCommerceCryptogramInfo = new byte[1];
    public byte[] issuerAuthenticationMethod = new byte[2];
    public byte[] cavvAlgorithm = new byte[1];
    public byte[] veresEnrolled = new byte[1];
    public byte[] paresStatus = new byte[1];
    public byte[] eci = new byte[2];
    public byte[] modifiedSecureMode = new byte[2];
    public byte[] veresEnrolled1 = new byte[1];
    public byte[] veresEnrolled2 = new byte[1];
    public byte[] veresEnrolled3 = new byte[1];
    public byte[] merchantUrl = new byte[300];
    public byte[] walletProgramData = new byte[3];
    public byte[] additionalAuthenticationMethod = new byte[2];
    public byte[] additionalAuthenticationReasonCode = new byte[2];
    public byte[] additionalWalletCaptureData = new byte[12];
    public byte[] additionalWalletData = new byte[12];
    public byte[] authentication3DSType = new byte[2];
    public byte[] authenticationAskedByMerchant = new byte[2];
    public byte[] transactionStatusReason = new byte[2];
    public byte[] challengeCancelationIndicator = new byte[2];
    public byte[] threeDSScore = new byte[5];
    public byte[] uniqueAgentID = new byte[10];
    public byte[] serviceRisk = new byte[2];
    public byte[] serviceRiskData = new byte[50];
    public byte[] directoryScheme = new byte[50];
    public byte[] threeDSVersion = new byte[5];
    public byte[] productCode = new byte[1];
    public Boolean isEnrolment;
    public byte[] enrolment3DSInformation = new byte[4];
}

