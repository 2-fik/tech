/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_KRN_AcquirerRisks
extends YP_Row {
    @PrimaryKey
    public long idKRN_AcquirerRisks = 0L;
    public int currencyNumericalCode = 0;
    public long minimumAmount = 0L;
    public long maximumAmount = 0L;
    public long doubleAuthentificationAmount = 0L;
    public long commercialServiceAmount = 0L;
    public long authorizationAmount = 0L;
    public long foreignMaximumAmount = 0L;
}

