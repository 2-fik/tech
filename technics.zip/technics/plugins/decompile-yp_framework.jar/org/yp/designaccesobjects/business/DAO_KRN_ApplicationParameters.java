/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.Bitmap;
import org.yp.utils.enums.PANLengthTypeEnumeration;

public class DAO_KRN_ApplicationParameters
extends YP_Row {
    @PrimaryKey
    public long idKRN_ApplicationParameters = 0L;
    public byte[] processorIdentifier = new byte[20];
    public byte[] applicationContract = new byte[20];
    public byte[] applicationName = new byte[20];
    public PANLengthTypeEnumeration lengthType;
    public int lengthMin = 0;
    public int lengthMax = 0;
    public int interCharacterTimeout = 0;
    public byte[] ticketPaymentInformationHeader = new byte[100];
    public byte[] ticketPaymentInformationFooter = new byte[100];
    public byte[] ticketPaymentInformationFooterSup = new byte[100];
    public byte[] ticketReportHeader = new byte[100];
    public byte[] ticketReportFooter = new byte[100];
    public Bitmap trsTypeAllowed;
    public byte[] endUserLangageList = new byte[20];
    public Boolean isForcedAllowed;
    public Boolean isAutoCall;
    public byte[] externalReference = new byte[30];
}

