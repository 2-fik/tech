/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_KRN_InitialisationParameters
extends YP_Row {
    @PrimaryKey
    public long idKRN_InitialisationParameters = 0L;
}

