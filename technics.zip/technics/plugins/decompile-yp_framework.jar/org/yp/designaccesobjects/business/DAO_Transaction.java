/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import java.sql.Date;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.sorec.SorecRequestEnumeration;

public class DAO_Transaction
extends YP_Row {
    @PrimaryKey
    public long idTransaction = 0L;
    public SorecRequestEnumeration sorecRequest;
    public byte[] fileContent = new byte[8000];
    public int taskerNumber = 0;
    @Index(tableType=65535)
    public Date dateReunion = new Date(0L);
    public byte[] numeroReunion = new byte[25];
    public byte[] numeroCourse = new byte[25];
    @Index(tableType=65535)
    public Date dateSessionVoucher = new Date(0L);
    public long systemGMTTimeMS = 0L;
}

