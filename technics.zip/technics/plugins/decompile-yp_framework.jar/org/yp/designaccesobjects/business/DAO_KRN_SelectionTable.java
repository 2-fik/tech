/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_KRN_SelectionTable
extends YP_Row {
    @PrimaryKey
    public long idKRN_SelectionTable = 0L;
    @Index
    public byte[] start = new byte[50];
    public byte[] end = new byte[50];
    public int level = 0;
    public int treatmentCode = 0;
    public byte[] meanOfPaymentType = new byte[20];
    public byte[] externalReference = new byte[30];

    @Override
    public Object getFieldValueByName(String string) {
        try {
            switch (string) {
                case "idKRN_SelectionTable": {
                    return this.idKRN_SelectionTable;
                }
                case "start": {
                    return this.start;
                }
                case "end": {
                    return this.end;
                }
                case "level": {
                    return this.level;
                }
                case "treatmentCode": {
                    return this.treatmentCode;
                }
                case "meanOfPaymentType": {
                    return this.meanOfPaymentType;
                }
                case "externalReference": {
                    return this.externalReference;
                }
            }
            return super.getFieldValueByName(string);
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldValueByName() " + exception);
            }
            return null;
        }
    }
}

