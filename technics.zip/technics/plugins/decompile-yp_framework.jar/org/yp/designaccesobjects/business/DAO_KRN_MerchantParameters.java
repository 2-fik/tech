/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_KRN_MerchantParameters
extends YP_Row {
    @PrimaryKey
    public long idKRN_MerchantParameters = 0L;
    public byte[] merchantContract = new byte[20];
    public byte[] acquiringInstitutionIdentificationCode = new byte[11];
    public byte[] merchantName = new byte[60];
    public byte[] merchantAddress = new byte[60];
    public byte[] merchantCity = new byte[60];
    public byte[] merchantZipCode = new byte[10];
    public byte[] merchantState = new byte[30];
    public byte[] merchantCountry = new byte[30];
    public byte[] merchantCategoryCode = new byte[4];
    public byte[] commercialRegisterNumber = new byte[14];
    public byte[] countryCode = new byte[3];
    public byte[] terminalIdentification = new byte[20];
    public byte[] merchantType = new byte[8];
    public byte[] externalReference = new byte[30];
}

