/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.business;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.TableStatusEnumeration;

public class DAO_TableList
extends YP_Row {
    @PrimaryKey
    public long idTableList = 0L;
    @Index
    public byte[] tableName = new byte[64];
    public Timestamp tableSystemGMTTime = new Timestamp(0L);
    public byte[] tableVersion = new byte[32];
    public byte[] tableCksum = new byte[32];
    public int tableAckMessage = 0;
    public TableStatusEnumeration tableStatus;
    public int tableNumber = 0;

    @Override
    public Object getFieldValueByName(String string) {
        try {
            switch (string) {
                case "idTableList": {
                    return this.idTableList;
                }
                case "tableName": {
                    return this.tableName;
                }
                case "tableSystemGMTTime": {
                    return this.tableSystemGMTTime;
                }
                case "tableVersion": {
                    return this.tableVersion;
                }
                case "tableCksum": {
                    return this.tableCksum;
                }
                case "tableAckMessage": {
                    return this.tableAckMessage;
                }
                case "TableStatusEnumeration": {
                    return this.tableStatus;
                }
                case "tableNumber": {
                    return this.tableNumber;
                }
            }
            return super.getFieldValueByName(string);
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldValueByName() " + exception);
            }
            return null;
        }
    }
}

