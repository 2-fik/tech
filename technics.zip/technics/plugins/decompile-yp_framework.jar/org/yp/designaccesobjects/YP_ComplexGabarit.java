/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.utils.Bitmap;
import org.yp.utils.UtilsYP;

public final class YP_ComplexGabarit {
    public final YP_TCD_DesignAccesObject designAccesObject;
    private final List<YP_Gabarit> rowGabaritList = new ArrayList<YP_Gabarit>();
    public boolean gabaritHasOneMinOrMax = false;
    public String minFieldName = null;
    public String maxFieldName = null;
    public boolean isOrdered = false;
    public List<String> groupFieldNameList = null;
    public List<Field> groupFieldList = null;

    public YP_ComplexGabarit(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        this.designAccesObject = yP_TCD_DesignAccesObject;
    }

    public YP_ComplexGabarit(YP_ComplexGabarit yP_ComplexGabarit) {
        this.designAccesObject = yP_ComplexGabarit.designAccesObject;
        this.rowGabaritList.addAll(yP_ComplexGabarit.rowGabaritList);
        this.gabaritHasOneMinOrMax = yP_ComplexGabarit.gabaritHasOneMinOrMax;
        this.minFieldName = yP_ComplexGabarit.minFieldName;
        this.maxFieldName = yP_ComplexGabarit.maxFieldName;
        this.isOrdered = yP_ComplexGabarit.isOrdered;
        if (yP_ComplexGabarit.groupFieldNameList != null) {
            this.groupFieldNameList = new ArrayList<String>();
            this.groupFieldNameList.addAll(yP_ComplexGabarit.groupFieldNameList);
        }
        if (yP_ComplexGabarit.groupFieldList != null) {
            this.groupFieldList = new ArrayList<Field>();
            this.groupFieldList.addAll(yP_ComplexGabarit.groupFieldList);
        }
    }

    public final int size() {
        return this.rowGabaritList.size();
    }

    public final OPERATOR getOperatorAt(int n) {
        return this.rowGabaritList.get((int)n).operator;
    }

    public final Object getObjectAt(int n) {
        return this.rowGabaritList.get((int)n).objectTosearch;
    }

    public final String getFieldNameAt(int n) {
        return this.rowGabaritList.get((int)n).field.getName();
    }

    public final int set(String string, OPERATOR oPERATOR) {
        Field field = this.designAccesObject.getFieldByName(string);
        if (field == null) {
            this.designAccesObject.logger(2, "set() can't find " + string);
            return -1;
        }
        switch (oPERATOR) {
            case MIN: {
                if (this.gabaritHasOneMinOrMax) {
                    this.designAccesObject.logger(2, "set() only one min or max field allowed ");
                    return -1;
                }
                this.minFieldName = string;
                this.gabaritHasOneMinOrMax = true;
                break;
            }
            case MAX: {
                if (this.gabaritHasOneMinOrMax) {
                    this.designAccesObject.logger(2, "set() only one min or max field allowed ");
                    return -1;
                }
                this.maxFieldName = string;
                this.gabaritHasOneMinOrMax = true;
                break;
            }
            case GROUP: {
                if (this.groupFieldNameList == null) {
                    this.groupFieldNameList = new ArrayList<String>();
                }
                if (this.groupFieldList == null) {
                    this.groupFieldList = new ArrayList<Field>();
                }
                this.groupFieldNameList.add(string);
                this.groupFieldList.add(field);
                break;
            }
            case ORDER_ASC: {
                this.isOrdered = true;
                break;
            }
            case ORDER_DESC: {
                this.isOrdered = true;
                break;
            }
            default: {
                this.designAccesObject.logger(2, "set() only MIN , MAX & ORDERS have no value");
                return -1;
            }
        }
        this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR));
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int set(String string, OPERATOR oPERATOR, String string2) {
        try {
            Field field = this.designAccesObject.getFieldByName(string);
            if (field != null) {
                return this.set(field, oPERATOR, string2);
            }
            if (string != null) {
                switch (string) {
                    case "paresStatus": {
                        return -1;
                    }
                }
            }
            this.designAccesObject.logger(2, "set() field not found:" + string);
            return -1;
        }
        catch (Exception exception) {
            this.designAccesObject.logger(2, "set() ", exception);
            return -1;
        }
    }

    public final int set(Field field, OPERATOR oPERATOR, String string) {
        block11: {
            try {
                if (field != null) break block11;
                this.designAccesObject.logger(2, "set() field is null !!");
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (oPERATOR == OPERATOR.IN_SQL) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)string));
        } else if (field.getType() == byte[].class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)YP_Row.getXMLBytes(string)));
        } else if (field.getType().isEnum()) {
            if (string.isEmpty()) {
                this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, null));
            } else {
                this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, Enum.valueOf(field.getType(), string)));
            }
        } else {
            this.designAccesObject.logger(3, "set() probably the wrong type used for " + field.getName());
            YP_Row yP_Row = this.designAccesObject.getNewRow();
            yP_Row.setFieldValue(field, string);
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, yP_Row.getFieldValue(field)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Enum enum_) {
        Field field;
        block4: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block4;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (!field.getType().isEnum()) {
            this.designAccesObject.logger(2, "set() field is not an enum:" + string);
            return -1;
        }
        this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)enum_));
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, int n) {
        Field field;
        block13: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block13;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Integer.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)n));
        } else if (field.getType() == Long.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)n));
        } else if (field.getType() == Float.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Float.valueOf(n)));
        } else if (field.getType() == Bitmap.class) {
            Bitmap bitmap = new Bitmap();
            bitmap.set(n);
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bitmap));
        } else if (field.getType() == byte[].class) {
            this.designAccesObject.logger(3, "set() assigning byte[] for value " + n);
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Integer.toString(n).getBytes()));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Integer.toString(n)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Object ... objectArray) {
        Field field;
        block11: {
            block10: {
                block9: {
                    block8: {
                        block7: {
                            try {
                                field = this.designAccesObject.getFieldByName(string);
                                if (field != null) break block7;
                                this.designAccesObject.logger(2, "set() field not found:" + string);
                                return -1;
                            }
                            catch (Exception exception) {
                                this.designAccesObject.logger(2, "set() ", exception);
                                return -1;
                            }
                        }
                        if (objectArray != null) break block8;
                        this.designAccesObject.logger(2, "set() null");
                        return -1;
                    }
                    if (objectArray.length != 0) break block9;
                    this.designAccesObject.logger(2, "set() length==0");
                    return -1;
                }
                if (objectArray[0] != null) break block10;
                this.designAccesObject.logger(2, "set() first is null");
                return -1;
            }
            if (oPERATOR == OPERATOR.IN || oPERATOR == OPERATOR.IN_AFTER_GROUP) break block11;
            this.designAccesObject.logger(2, "set() only for IN operator");
            return -1;
        }
        this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)objectArray));
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, List<Object> list) {
        Field field;
        block9: {
            block8: {
                block7: {
                    block6: {
                        try {
                            field = this.designAccesObject.getFieldByName(string);
                            if (field != null) break block6;
                            this.designAccesObject.logger(2, "set() field not found:" + string);
                            return -1;
                        }
                        catch (Exception exception) {
                            this.designAccesObject.logger(2, "set() ", exception);
                            return -1;
                        }
                    }
                    if (list != null) break block7;
                    this.designAccesObject.logger(2, "set() null");
                    return -1;
                }
                if (!list.isEmpty()) break block8;
                this.designAccesObject.logger(2, "set() length==0");
                return -1;
            }
            if (oPERATOR == OPERATOR.IN || oPERATOR == OPERATOR.IN_AFTER_GROUP) break block9;
            this.designAccesObject.logger(2, "set() only for IN operator");
            return -1;
        }
        this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)list.toArray()));
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, long l) {
        Field field;
        block11: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block11;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Long.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)l));
        } else if (field.getType() == Integer.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)((int)l)));
        } else if (field.getType() == Float.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Float.valueOf(l)));
        } else if (field.getType() == Bitmap.class) {
            Bitmap bitmap = new Bitmap();
            bitmap.set((int)l);
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bitmap));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Long.toString(l)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, float f) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Float.TYPE) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Float.valueOf(f)));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Float.toString(f)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, boolean bl) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Boolean.class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bl));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Boolean.toString(bl)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Boolean bl) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Boolean.class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bl));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)Boolean.toString(bl)));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Timestamp timestamp) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Timestamp.class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)timestamp));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)timestamp.toString()));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Date date) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Date.class) {
            Date date2 = new Date(date.getTime() / 86400000L * 86400000L);
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)date2));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)date.toString()));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, byte[] byArray) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == byte[].class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)byArray));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)byArray.toString()));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Bitmap bitmap) {
        Field field;
        block5: {
            try {
                field = this.designAccesObject.getFieldByName(string);
                if (field != null) break block5;
                this.designAccesObject.logger(2, "set() field not found:" + string);
                return -1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "set() ", exception);
                return -1;
            }
        }
        if (field.getType() == Bitmap.class) {
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bitmap));
        } else {
            this.designAccesObject.logger(2, "set() bad type for value ???");
            this.rowGabaritList.add(new YP_Gabarit(field, oPERATOR, (Object)bitmap.toString()));
        }
        return 1;
    }

    public final int set(String string, OPERATOR oPERATOR, Object object) {
        try {
            if (object instanceof String) {
                return this.set(string, oPERATOR, (String)object);
            }
            if (object instanceof byte[]) {
                return this.set(string, oPERATOR, (byte[])object);
            }
            if (object instanceof Long) {
                long l = (Long)object;
                return this.set(string, oPERATOR, l);
            }
            if (object instanceof Integer) {
                int n = (Integer)object;
                return this.set(string, oPERATOR, n);
            }
            if (object instanceof Timestamp) {
                return this.set(string, oPERATOR, (Timestamp)object);
            }
            if (object instanceof Date) {
                return this.set(string, oPERATOR, (Date)object);
            }
            if (object instanceof Float) {
                Float f = (Float)object;
                return this.set(string, oPERATOR, (Object)f);
            }
            if (object instanceof Boolean) {
                return this.set(string, oPERATOR, (Boolean)object);
            }
            if (object instanceof Enum) {
                return this.set(string, oPERATOR, (Enum)object);
            }
            if (object instanceof Object[]) {
                return this.set(string, oPERATOR, (Object[])object);
            }
            if (object instanceof List) {
                return this.set(string, oPERATOR, (List)object);
            }
            if (object instanceof Bitmap) {
                return this.set(string, oPERATOR, (Bitmap)object);
            }
            if (object instanceof Double) {
                return this.set(string, oPERATOR, ((Double)object).floatValue());
            }
            this.designAccesObject.logger(2, "set() unknown type");
            return -1;
        }
        catch (Exception exception) {
            this.designAccesObject.logger(2, "set() ", exception);
            return -1;
        }
    }

    public final int reset(String string, OPERATOR oPERATOR, Object object) {
        block5: {
            try {
                int n = this.rowGabaritList.size() - 1;
                while (n >= 0) {
                    YP_Gabarit yP_Gabarit = this.rowGabaritList.get(n);
                    if (yP_Gabarit != null && yP_Gabarit.fieldName != null && yP_Gabarit.fieldName.contentEquals(string)) {
                        this.rowGabaritList.remove(n);
                    }
                    --n;
                }
                if (oPERATOR != null || object != null) break block5;
                return 1;
            }
            catch (Exception exception) {
                this.designAccesObject.logger(2, "reset()  ", exception);
                return -1;
            }
        }
        return this.set(string, oPERATOR, object);
    }

    public final boolean match(YP_Row yP_Row) {
        return this.match(yP_Row, 1);
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public final boolean match(YP_Row yP_Row, int n) {
        try {
            int n2 = this.rowGabaritList.size();
            int n3 = 0;
            while (n3 < n2) {
                YP_Gabarit yP_Gabarit = this.rowGabaritList.get(n3);
                switch (yP_Gabarit.operator) {
                    case GREATER_OR_EQUAL: {
                        Object object3;
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            object3 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Integer)object3 >= (Integer)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            object3 = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Long)object3 >= (Long)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Timestamp) {
                            object3 = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Timestamp)object3).compareTo((Timestamp)yP_Gabarit.objectTosearch) >= 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Date) {
                            object3 = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((java.util.Date)object3).compareTo((Date)yP_Gabarit.objectTosearch) >= 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Float) {
                            object3 = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Float)object3).floatValue() >= ((Float)yP_Gabarit.objectTosearch).floatValue()) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Boolean) {
                            this.designAccesObject.logger(2, "match() operator >= not possible for Boolean");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Enum) {
                            this.designAccesObject.logger(2, "match() operator >= not possible for Enum");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (YP_ComplexGabarit.byteArrayCompare((byte[])yP_Row.getFieldValue(yP_Gabarit.field), (byte[])yP_Gabarit.objectTosearch, true) >= 0) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() unknown operator for >=");
                        return false;
                    }
                    case GREATER: {
                        Object object3;
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            object3 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Integer)object3 > (Integer)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            object3 = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Long)object3 > (Long)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Timestamp) {
                            object3 = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Timestamp)object3).compareTo((Timestamp)yP_Gabarit.objectTosearch) > 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Date) {
                            object3 = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((java.util.Date)object3).compareTo((Date)yP_Gabarit.objectTosearch) > 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Float) {
                            object3 = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Float)object3).floatValue() > ((Float)yP_Gabarit.objectTosearch).floatValue()) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Boolean) {
                            this.designAccesObject.logger(2, "match() operator > not possible for Boolean");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Enum) {
                            this.designAccesObject.logger(2, "match() operator > not possible for Enum");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (YP_ComplexGabarit.byteArrayCompare((byte[])yP_Row.getFieldValue(yP_Gabarit.field), (byte[])yP_Gabarit.objectTosearch, true) > 0) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() unknown operator for >");
                        return false;
                    }
                    case LESS_OR_EQUAL: {
                        Object object3;
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            object3 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Integer)object3 <= (Integer)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            object3 = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Long)object3 <= (Long)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Timestamp) {
                            object3 = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Timestamp)object3).compareTo((Timestamp)yP_Gabarit.objectTosearch) <= 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Date) {
                            object3 = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((java.util.Date)object3).compareTo((Date)yP_Gabarit.objectTosearch) <= 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Float) {
                            object3 = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Float)object3).floatValue() <= ((Float)yP_Gabarit.objectTosearch).floatValue()) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Boolean) {
                            this.designAccesObject.logger(2, "match() operator <= not possible for Boolean");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Enum) {
                            this.designAccesObject.logger(2, "match() operator <= not possible for Enum");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (YP_ComplexGabarit.byteArrayCompare((byte[])yP_Row.getFieldValue(yP_Gabarit.field), (byte[])yP_Gabarit.objectTosearch, true) <= 0) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator <= not done for String");
                        return false;
                    }
                    case LESS_AFTER_GROUP: {
                        if (n != 2) break;
                    }
                    case LESS: {
                        Object object3;
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            object3 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Integer)object3 < (Integer)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            object3 = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            if ((Long)object3 < (Long)yP_Gabarit.objectTosearch) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Timestamp) {
                            object3 = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Timestamp)object3).compareTo((Timestamp)yP_Gabarit.objectTosearch) < 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Date) {
                            object3 = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((java.util.Date)object3).compareTo((Date)yP_Gabarit.objectTosearch) < 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Float) {
                            object3 = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Float)object3).floatValue() < ((Float)yP_Gabarit.objectTosearch).floatValue()) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Boolean) {
                            this.designAccesObject.logger(2, "match() operator < not possible for Boolean");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Enum) {
                            this.designAccesObject.logger(2, "match() operator < not possible for Enum");
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (YP_ComplexGabarit.byteArrayCompare((byte[])yP_Row.getFieldValue(yP_Gabarit.field), (byte[])yP_Gabarit.objectTosearch, true) < 0) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator < not done for String");
                        return false;
                    }
                    case EQUAL_AFTER_GROUP: {
                        if (n != 2) break;
                    }
                    case EQUAL: {
                        Object object3;
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            object3 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Integer)object3).equals(yP_Gabarit.objectTosearch)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            object3 = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Long)object3).equals(yP_Gabarit.objectTosearch)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Timestamp) {
                            object3 = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Timestamp)object3).compareTo((Timestamp)yP_Gabarit.objectTosearch) == 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Date) {
                            object3 = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((java.util.Date)object3).compareTo((Date)yP_Gabarit.objectTosearch) == 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Float) {
                            object3 = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (((Float)object3).equals(yP_Gabarit.objectTosearch)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Boolean) {
                            object3 = (Boolean)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (object3 == null) {
                                return false;
                            }
                            if (((Boolean)object3).equals(yP_Gabarit.objectTosearch)) break;
                            return false;
                        }
                        if (!(yP_Gabarit.objectTosearch instanceof Enum ? (object3 = (Enum)yP_Row.getFieldValue(yP_Gabarit.field)) == null || !((Enum)object3).equals(yP_Gabarit.objectTosearch) : (yP_Gabarit.objectTosearch instanceof Bitmap ? (object3 = (Bitmap)yP_Row.getFieldValue(yP_Gabarit.field)) == null || ((Bitmap)object3).getBitmap() != ((Bitmap)yP_Gabarit.objectTosearch).getBitmap() : !UtilsYP.isEquals(yP_Gabarit.objectTosearch, yP_Row.getFieldValue(yP_Gabarit.field), false, false)))) break;
                        return false;
                    }
                    case EQUAL_IGNORE_CASE: {
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (UtilsYP.isEquals((byte[])yP_Gabarit.objectTosearch, (byte[])yP_Row.getFieldValue(yP_Gabarit.field), false, false, true)) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator equalsIgnoreCase only possible for string");
                        return false;
                    }
                    case LIKE: {
                        this.designAccesObject.logger(3, "match() operator like only possible for SQL table");
                        return true;
                    }
                    case IN_AFTER_GROUP: {
                        if (n != 2) break;
                    }
                    case IN: {
                        Object object;
                        int n4;
                        int n5;
                        Object object2;
                        Object object3 = (Object[])yP_Gabarit.objectTosearch;
                        if (object3[0] instanceof Integer) {
                            Integer n6 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (n6.equals(object)) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Long) {
                            Long l = (Long)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (l.equals(object)) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Timestamp) {
                            Timestamp timestamp = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (timestamp.compareTo((Timestamp)object) == 0) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Date) {
                            Date date = (Date)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (date.compareTo((Date)object) == 0) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Float) {
                            Float f = (Float)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (f.equals(object)) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Boolean) {
                            Boolean bl = (Boolean)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (bl == null) {
                                return false;
                            }
                            boolean bl2 = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (bl.equals(object)) {
                                    bl2 = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl2) break;
                            return false;
                        }
                        if (object3[0] instanceof Enum) {
                            Enum enum_ = (Enum)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (enum_ == null) {
                                    if (object == null) {
                                        bl = true;
                                        break;
                                    }
                                } else if (enum_.equals(object)) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        if (object3[0] instanceof Bitmap) {
                            Bitmap bitmap = (Bitmap)yP_Row.getFieldValue(yP_Gabarit.field);
                            boolean bl = false;
                            object2 = object3;
                            n5 = ((Object)object2).length;
                            n4 = 0;
                            while (n4 < n5) {
                                object = object2[n4];
                                if (bitmap == null) {
                                    if (object == null) {
                                        bl = true;
                                        break;
                                    }
                                } else if (bitmap.getBitmap() == ((Bitmap)object).getBitmap()) {
                                    bl = true;
                                    break;
                                }
                                ++n4;
                            }
                            if (bl) break;
                            return false;
                        }
                        boolean bl = false;
                        Object object4 = yP_Row.getFieldValue(yP_Gabarit.field);
                        object2 = object3;
                        n5 = ((Object)object2).length;
                        n4 = 0;
                        while (n4 < n5) {
                            object = object2[n4];
                            if (UtilsYP.isEquals(object, object4, false, false)) {
                                bl = true;
                                break;
                            }
                            ++n4;
                        }
                        if (bl) break;
                        return false;
                    }
                    case DIFFERENT_AFTER_GROUP: {
                        if (n != 2) break;
                    }
                    case DIFFERENT: {
                        Bitmap bitmap;
                        Enum enum_;
                        Boolean bl;
                        Float f;
                        Date date;
                        Timestamp timestamp;
                        Long l;
                        Integer n7;
                        if (!(yP_Gabarit.objectTosearch instanceof Integer ? (n7 = (Integer)yP_Row.getFieldValue(yP_Gabarit.field)).equals(yP_Gabarit.objectTosearch) : (yP_Gabarit.objectTosearch instanceof Long ? (l = (Long)yP_Row.getFieldValue(yP_Gabarit.field)).equals(yP_Gabarit.objectTosearch) : (yP_Gabarit.objectTosearch instanceof Timestamp ? (timestamp = (Timestamp)yP_Row.getFieldValue(yP_Gabarit.field)).compareTo((Timestamp)yP_Gabarit.objectTosearch) == 0 : (yP_Gabarit.objectTosearch instanceof Date ? (date = (Date)yP_Row.getFieldValue(yP_Gabarit.field)).compareTo((Date)yP_Gabarit.objectTosearch) == 0 : (yP_Gabarit.objectTosearch instanceof Float ? (f = (Float)yP_Row.getFieldValue(yP_Gabarit.field)).equals(yP_Gabarit.objectTosearch) : (yP_Gabarit.objectTosearch instanceof Boolean ? ((bl = (Boolean)yP_Row.getFieldValue(yP_Gabarit.field)) == null ? yP_Gabarit.objectTosearch == null : bl.equals(yP_Gabarit.objectTosearch)) : (yP_Gabarit.objectTosearch instanceof Enum ? ((enum_ = (Enum)yP_Row.getFieldValue(yP_Gabarit.field)) == null ? yP_Gabarit.objectTosearch == null : enum_.equals(yP_Gabarit.objectTosearch)) : (yP_Gabarit.objectTosearch instanceof Bitmap ? ((bitmap = (Bitmap)yP_Row.getFieldValue(yP_Gabarit.field)) == null ? yP_Gabarit.objectTosearch == null : bitmap.getBitmap() == ((Bitmap)yP_Gabarit.objectTosearch).getBitmap()) : UtilsYP.isEquals(yP_Gabarit.objectTosearch, yP_Row.getFieldValue(yP_Gabarit.field), false, false)))))))))) break;
                        return false;
                    }
                    case CONTAIN: {
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            byte[] byArray = (byte[])yP_Row.getFieldValue(yP_Gabarit.field);
                            if (UtilsYP.indexOf(byArray, 0, byArray.length, (byte[])yP_Gabarit.objectTosearch) >= 0) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Bitmap) {
                            Bitmap bitmap = (Bitmap)yP_Row.getFieldValue(yP_Gabarit.field);
                            if (bitmap != null && bitmap.isSet((Bitmap)yP_Gabarit.objectTosearch)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (string.contains(Integer.toString((Integer)yP_Gabarit.objectTosearch))) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (string.contains(Long.toString((Long)yP_Gabarit.objectTosearch))) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator contain only possible for string, bitmap, int and long");
                        return false;
                    }
                    case MATCH_BEGINNING: {
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (UtilsYP.isEquals(yP_Gabarit.objectTosearch, yP_Row.getFieldValue(yP_Gabarit.field), false, true)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (UtilsYP.isEquals(Integer.toString((Integer)yP_Gabarit.objectTosearch), string, false, true)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (UtilsYP.isEquals(Long.toString((Long)yP_Gabarit.objectTosearch), string, false, true)) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator match beggining only possible for string, int and long");
                        return false;
                    }
                    case START_WITH: {
                        if (yP_Gabarit.objectTosearch instanceof byte[]) {
                            if (UtilsYP.isEquals(yP_Gabarit.objectTosearch, yP_Row.getFieldValue(yP_Gabarit.field), true, false)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Integer) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (UtilsYP.isEquals(Integer.toString((Integer)yP_Gabarit.objectTosearch), string, true, false)) break;
                            return false;
                        }
                        if (yP_Gabarit.objectTosearch instanceof Long) {
                            String string = yP_Row.getFieldStringValue(yP_Gabarit.field);
                            if (UtilsYP.isEquals(Long.toString((Long)yP_Gabarit.objectTosearch), string, true, false)) break;
                            return false;
                        }
                        this.designAccesObject.logger(2, "match() operator start with only possible for string, int and long");
                        return false;
                    }
                    case MIN: 
                    case MAX: {
                        break;
                    }
                    case ORDER_DESC: 
                    case ORDER_ASC: {
                        break;
                    }
                    case GROUP: {
                        break;
                    }
                    default: {
                        this.designAccesObject.logger(2, "match() unknown operator");
                        return false;
                    }
                }
                ++n3;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.designAccesObject.logger(2, "match() ", exception);
            return false;
        }
        return true;
    }

    protected static int byteArrayCompare(byte[] byArray, byte[] byArray2, boolean bl) {
        if (byArray == null) {
            if (byArray2 != null) {
                return -1;
            }
            return 0;
        }
        if (byArray2 == null) {
            return 1;
        }
        int n = byArray.length;
        int n2 = byArray2.length;
        if (bl) {
            while (n > 0) {
                if (byArray[n - 1] != 32 && byArray[n - 1] != 0) break;
                --n;
            }
            while (n2 > 0) {
                if (byArray2[n2 - 1] != 32 && byArray2[n2 - 1] != 0) break;
                --n2;
            }
        }
        int n3 = n < n2 ? n : n2;
        int n4 = 0;
        while (n4 < n3) {
            if (byArray[n4] < byArray2[n4]) {
                return -1;
            }
            if (byArray[n4] > byArray2[n4]) {
                return 1;
            }
            ++n4;
        }
        if (n > n2) {
            return 1;
        }
        if (n < n2) {
            return -1;
        }
        return 0;
    }

    public static int compare(Object object, Object object2) {
        if (object instanceof Integer) {
            if ((Integer)object > (Integer)object2) {
                return 1;
            }
            if (((Integer)object).intValue() == ((Integer)object2).intValue()) {
                return 0;
            }
            return -1;
        }
        if (object instanceof Long) {
            if ((Long)object > (Long)object2) {
                return 1;
            }
            if (((Long)object).longValue() == ((Long)object2).longValue()) {
                return 0;
            }
            return -1;
        }
        if (object instanceof Timestamp) {
            return ((Timestamp)object).compareTo((Timestamp)object2);
        }
        if (object instanceof Date) {
            return ((Date)object).compareTo((Date)object2);
        }
        if (object instanceof Float) {
            if (((Float)object).floatValue() > ((Float)object2).floatValue()) {
                return 1;
            }
            if (((Float)object).floatValue() == ((Float)object2).floatValue()) {
                return 0;
            }
            return -1;
        }
        if (object instanceof Boolean) {
            return ((Boolean)object).compareTo((Boolean)object2);
        }
        if (object instanceof byte[]) {
            return YP_ComplexGabarit.byteArrayCompare((byte[])object, (byte[])object2, true);
        }
        if (object instanceof Enum) {
            return ((Enum)object).compareTo((Enum)object2);
        }
        throw new IllegalArgumentException("...");
    }

    public List<YP_Row> order(List<YP_Row> list) {
        if (!this.isOrdered) {
            return list;
        }
        if (list.size() < 2) {
            return list;
        }
        int n = this.rowGabaritList.size();
        RowComparator rowComparator = null;
        int n2 = 0;
        while (n2 < n) {
            YP_Gabarit yP_Gabarit = this.rowGabaritList.get(n2);
            if (yP_Gabarit.operator == OPERATOR.ORDER_ASC) {
                if (rowComparator == null) {
                    rowComparator = new RowComparator(yP_Gabarit.field, 1, list.get(0));
                } else {
                    rowComparator.add(new RowComparator(yP_Gabarit.field, 1, list.get(0)));
                }
            }
            if (yP_Gabarit.operator == OPERATOR.ORDER_DESC) {
                if (rowComparator == null) {
                    rowComparator = new RowComparator(yP_Gabarit.field, -1, list.get(0));
                } else {
                    rowComparator.add(new RowComparator(yP_Gabarit.field, -1, list.get(0)));
                }
            }
            ++n2;
        }
        Collections.sort(list, rowComparator);
        return list;
    }

    public static enum OPERATOR {
        EQUAL,
        EQUAL_IGNORE_CASE,
        IN,
        DIFFERENT,
        LESS,
        GREATER,
        CONTAIN,
        MIN,
        MAX,
        GREATER_OR_EQUAL,
        LESS_OR_EQUAL,
        MATCH_BEGINNING,
        START_WITH,
        ORDER_DESC,
        ORDER_ASC,
        GROUP,
        EQUAL_AFTER_GROUP,
        DIFFERENT_AFTER_GROUP,
        IN_AFTER_GROUP,
        LIKE,
        IN_SQL,
        LESS_AFTER_GROUP;

    }

    class RowComparator
    implements Comparator<YP_Row> {
        public final Field fieldToCompare;
        private final int objectType;
        public final int sens;
        RowComparator subComparator = null;

        public RowComparator(Field field, int n, YP_Row yP_Row) {
            this.fieldToCompare = field;
            this.sens = n;
            Object object = null;
            try {
                object = field.get(yP_Row);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            this.objectType = object instanceof Integer ? 1 : (object instanceof Long ? 2 : (object instanceof Timestamp ? 3 : (object instanceof Date ? 4 : (object instanceof Float ? 5 : (object instanceof byte[] ? 6 : (object instanceof Enum ? 7 : (object instanceof Boolean ? 8 : 0)))))));
        }

        public int add(RowComparator rowComparator) {
            if (this.subComparator == null) {
                this.subComparator = rowComparator;
            } else {
                this.subComparator.add(rowComparator);
            }
            return 1;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public int compare(YP_Row yP_Row, YP_Row yP_Row2) {
            try {
                switch (this.objectType) {
                    case 1: {
                        Integer n = (Integer)this.fieldToCompare.get(yP_Row);
                        Integer n2 = (Integer)this.fieldToCompare.get(yP_Row2);
                        if (n > n2) {
                            return 1 * this.sens;
                        }
                        if (n.intValue() != n2.intValue()) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 2: {
                        Long l = (Long)this.fieldToCompare.get(yP_Row);
                        Long l2 = (Long)this.fieldToCompare.get(yP_Row2);
                        if (l > l2) {
                            return 1 * this.sens;
                        }
                        if (l.longValue() != l2.longValue()) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 3: {
                        Timestamp timestamp = (Timestamp)this.fieldToCompare.get(yP_Row);
                        Timestamp timestamp2 = (Timestamp)this.fieldToCompare.get(yP_Row2);
                        int n = timestamp.compareTo(timestamp2);
                        if (n > 0) {
                            return 1 * this.sens;
                        }
                        if (n != 0) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 4: {
                        Date date = (Date)this.fieldToCompare.get(yP_Row);
                        Date date2 = (Date)this.fieldToCompare.get(yP_Row2);
                        int n = date.compareTo(date2);
                        if (n > 0) {
                            return 1 * this.sens;
                        }
                        if (n != 0) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 5: {
                        Float f = (Float)this.fieldToCompare.get(yP_Row);
                        Float f2 = (Float)this.fieldToCompare.get(yP_Row2);
                        if (f.floatValue() > f2.floatValue()) {
                            return 1 * this.sens;
                        }
                        if (f.floatValue() != f2.floatValue()) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 6: {
                        byte[] byArray = (byte[])this.fieldToCompare.get(yP_Row);
                        byte[] byArray2 = (byte[])this.fieldToCompare.get(yP_Row2);
                        int n = YP_ComplexGabarit.byteArrayCompare(byArray, byArray2, true);
                        if (n > 0) {
                            return 1 * this.sens;
                        }
                        if (n != 0) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 7: {
                        Enum enum_ = (Enum)this.fieldToCompare.get(yP_Row);
                        Enum enum_2 = (Enum)this.fieldToCompare.get(yP_Row2);
                        int n = enum_.compareTo(enum_2);
                        if (n > 0) {
                            return 1 * this.sens;
                        }
                        if (n != 0) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                    case 8: {
                        Boolean bl = (Boolean)this.fieldToCompare.get(yP_Row);
                        Boolean bl2 = (Boolean)this.fieldToCompare.get(yP_Row2);
                        int n = bl.compareTo(bl2);
                        if (n > 0) {
                            return 1 * this.sens;
                        }
                        if (n != 0) return -1 * this.sens;
                        if (this.subComparator == null) return 0;
                        return this.subComparator.compare(yP_Row, yP_Row2);
                    }
                }
                return 1;
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            return 1;
        }
    }
}

