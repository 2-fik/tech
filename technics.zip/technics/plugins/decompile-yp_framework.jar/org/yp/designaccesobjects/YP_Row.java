/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.utils.Bitmap;
import org.yp.utils.ByteBuilder;
import org.yp.utils.ConfigReader;
import org.yp.utils.UtilsYP;

public abstract class YP_Row
implements Cloneable {
    public static final int ZERO_INT_VALUE_FOR_UPDATE = -2147483647;
    public static final long ZERO_LONG_VALUE_FOR_UPDATE = -9223372036854775807L;
    public static final int FOR_NOTHING = 0;
    public static final int FOR_DELETE = 1;
    public static final int FOR_UPDATE = 2;
    public static final int FOR_CREATE = 3;
    private int modifierFlag = 3;
    private boolean clonedRow = false;
    protected YP_TCD_DesignAccesObject designAccesObjectFather;
    private List<Object> extensionList = null;
    @Index
    public long contractKey = 0L;

    public final int initializeFromPropertyFile(String string) {
        Field[] fieldArray;
        if (string == null) {
            return 0;
        }
        Field[] fieldArray2 = fieldArray = this.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block17: {
                Field field = fieldArray2[n2];
                try {
                    String string2 = ConfigReader.get(string, field.getName());
                    if (string2 == null) break block17;
                    Object object = this.getFieldValue(field);
                    if (object instanceof byte[]) {
                        this.setFieldValue(field, string2.getBytes());
                        break block17;
                    }
                    if (object instanceof Integer) {
                        this.setFieldValue(field, this.getInt(string2));
                        break block17;
                    }
                    if (object instanceof Long) {
                        this.setFieldValue(field, this.getLong(string2));
                        break block17;
                    }
                    if (object instanceof Bitmap) {
                        this.setFieldValue(field, this.getLong(string2));
                        break block17;
                    }
                    if (object instanceof Timestamp) {
                        this.setFieldValue(field, string2.getBytes());
                        break block17;
                    }
                    if (object instanceof Date) {
                        this.setFieldValue(field, string2.getBytes());
                        break block17;
                    }
                    if (object instanceof Float) {
                        this.setFieldValue(field, Float.parseFloat(string2));
                        break block17;
                    }
                    if (object instanceof Boolean) {
                        this.setFieldValue(field, UtilsYP.parseBoolean(string2));
                        break block17;
                    }
                    if (object instanceof Enum) {
                        if (string2.isEmpty()) {
                            this.setFieldValue(field, (Enum)null);
                        } else {
                            this.setFieldValue(field, (Enum)Enum.valueOf(field.getType(), string2));
                        }
                        break block17;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "initializeFromPropertyFile() : unknown type");
                    }
                    return -1;
                }
                catch (Exception exception) {
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "initializeFromPropertyFile() :" + exception);
                    }
                    return -1;
                }
            }
            ++n2;
        }
        return 1;
    }

    public final Field[] getFieldList() {
        if (this.designAccesObjectFather != null) {
            return this.designAccesObjectFather.getFieldList();
        }
        return this.__getFieldList();
    }

    public Object getFieldValueByName(String string) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldValueByName() unknown field " + string);
                }
                return null;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldValueByName()  " + exception);
                }
                return null;
            }
        }
        return this.getFieldValue(field);
    }

    public final String getFieldStringValueByName(String string) {
        Object object = this.getFieldValueByName(string);
        if (object == null) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldStringValueByName() " + string + " not found");
            }
            return null;
        }
        return YP_Row.getStringValue(object);
    }

    public final String getFieldStringValue(Field field) {
        Object object = this.getFieldValue(field);
        if (object == null) {
            Class<?> clazz = field.getType();
            if (clazz != Boolean.class && !clazz.isEnum() && clazz != Bitmap.class && this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldStringValue() " + field.getName() + " not found");
            }
            return null;
        }
        return YP_Row.getStringValue(object);
    }

    public static String getStringValue(Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof byte[]) {
            return YP_Row.getStringValue((byte[])object);
        }
        if (object instanceof Bitmap) {
            return Long.toString(((Bitmap)object).getBitmap());
        }
        if (object instanceof Timestamp) {
            String string = object.toString();
            if (string.length() == 23) {
                return string;
            }
            if (string.length() == 22) {
                return String.valueOf(string) + '0';
            }
            if (string.length() == 21) {
                return String.valueOf(string) + "00";
            }
            return string;
        }
        if (object instanceof String && UtilsYP.isFullOf((String)object, '\u0000')) {
            return "";
        }
        return object.toString();
    }

    public static String getStringValue(byte[] byArray) {
        block3: {
            try {
                if (byArray.length != 0 && byArray[0] != 0) break block3;
                return "";
            }
            catch (Exception exception) {
                return null;
            }
        }
        return new String(byArray);
    }

    public int updateRow(YP_Row yP_Row) {
        Field[] fieldArray;
        Field[] fieldArray2 = fieldArray = yP_Row.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block20: {
                Field field = fieldArray2[n2];
                try {
                    Object object = yP_Row.getFieldValue(field);
                    if (object == null) break block20;
                    if (object instanceof Integer) {
                        if ((Integer)object != 0) {
                            this.setFieldValue(field, object);
                        }
                        break block20;
                    }
                    if (object instanceof Long) {
                        if ((Long)object != 0L) {
                            this.setFieldValue(field, object);
                        }
                        break block20;
                    }
                    if (object instanceof byte[]) {
                        if (((byte[])object).length != 0 && ((byte[])object)[0] != 0) {
                            this.setFieldValue(field, (byte[])object);
                        }
                        break block20;
                    }
                    if (object instanceof Timestamp) {
                        if (((Timestamp)object).getTime() != 0L) {
                            this.setFieldValue(field, (Timestamp)object);
                        }
                        break block20;
                    }
                    if (object instanceof Date) {
                        if (((Date)object).getTime() != 0L) {
                            this.setFieldValue(field, (Date)object);
                        }
                        break block20;
                    }
                    if (object instanceof Float) {
                        if (((Float)object).floatValue() != 0.0f) {
                            this.setFieldValue(field, object);
                        }
                        break block20;
                    }
                    if (object instanceof Boolean) {
                        this.setFieldValue(field, object);
                        break block20;
                    }
                    if (object instanceof Enum) {
                        this.setFieldValue(field, object);
                        break block20;
                    }
                    if (object instanceof Bitmap) {
                        this.setFieldValue(field, object);
                        break block20;
                    }
                    if (yP_Row.designAccesObjectFather != null) {
                        yP_Row.designAccesObjectFather.logger(2, "updateRow() unknown type");
                    }
                    return -1;
                }
                catch (Exception exception) {
                    if (yP_Row.designAccesObjectFather != null) {
                        yP_Row.designAccesObjectFather.logger(2, "updateRow() " + exception);
                    }
                    return -1;
                }
            }
            ++n2;
        }
        return 1;
    }

    public static int updateRowList(List<YP_Row> list, YP_Row yP_Row) {
        Field[] fieldArray;
        Field[] fieldArray2 = fieldArray = yP_Row.getFieldList();
        int n = fieldArray.length;
        int n2 = 0;
        while (n2 < n) {
            block29: {
                Field field = fieldArray2[n2];
                try {
                    Object object = yP_Row.getFieldValue(field);
                    if (object == null) break block29;
                    if (object instanceof Integer) {
                        if ((Integer)object != 0) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof Long) {
                        if ((Long)object != 0L) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof byte[]) {
                        if (((byte[])object).length != 0 && ((byte[])object)[0] != 0) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, (byte[])object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof Timestamp) {
                        if (((Timestamp)object).getTime() != 0L) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, (Timestamp)object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof Date) {
                        if (((Date)object).getTime() != 0L) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, (Date)object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof Float) {
                        if (((Float)object).floatValue() != 0.0f) {
                            for (YP_Row yP_Row2 : list) {
                                yP_Row2.setFieldValue(field, object);
                            }
                        }
                        break block29;
                    }
                    if (object instanceof Boolean) {
                        for (YP_Row yP_Row2 : list) {
                            yP_Row2.setFieldValue(field, object);
                        }
                        break block29;
                    }
                    if (object instanceof Enum) {
                        for (YP_Row yP_Row2 : list) {
                            yP_Row2.setFieldValue(field, object);
                        }
                        break block29;
                    }
                    if (object instanceof Bitmap) {
                        for (YP_Row yP_Row2 : list) {
                            yP_Row2.setFieldValue(field, object);
                        }
                        break block29;
                    }
                    if (yP_Row.designAccesObjectFather != null) {
                        yP_Row.designAccesObjectFather.logger(2, "updateRowList() unknown type");
                    }
                    return -1;
                }
                catch (Exception exception) {
                    if (yP_Row.designAccesObjectFather != null) {
                        yP_Row.designAccesObjectFather.logger(2, "updateRowList()" + exception);
                    }
                    return -1;
                }
            }
            ++n2;
        }
        return 1;
    }

    public final long getPrimaryKey() {
        Field field;
        block9: {
            try {
                field = this.getPrimaryKeyField();
                if (field != null) break block9;
                if (this.designAccesObjectFather != null && !this.designAccesObjectFather.getSchemaName().contentEquals("events")) {
                    this.designAccesObjectFather.logger(2, "getPrimaryKey() Maybe a row without Primary Key ");
                }
                return -1L;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(3, "getPrimaryKey() Maybe a row without Primary Key:" + exception);
                }
                return -1L;
            }
        }
        Object object = this.getFieldValue(field);
        if (object instanceof Long) {
            return (Long)object;
        }
        if (object instanceof Integer) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getPrimaryKey() @primaryKey must be used only with long..." + field.getName());
            }
            return ((Integer)object).intValue();
        }
        if (this.designAccesObjectFather != null) {
            this.designAccesObjectFather.logger(2, "getPrimaryKey() bad type ???");
        }
        return (Long)object;
    }

    public String getPrimaryKeyName() {
        try {
            String string;
            if (this.designAccesObjectFather != null && (string = this.designAccesObjectFather.getPrimaryKeyName()) != null) {
                return string;
            }
            return this.__getPrimaryKeyName();
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(3, "getPrimaryKeyName() " + exception);
            }
            return null;
        }
    }

    public String __getPrimaryKeyName() {
        try {
            Field[] fieldArray;
            Field[] fieldArray2 = fieldArray = this.getFieldList();
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray2[n2];
                if (field.getAnnotation(PrimaryKey.class) != null) {
                    return field.getName();
                }
                ++n2;
            }
            return null;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(3, "__getPrimaryKeyName() " + exception);
            }
            return null;
        }
    }

    public List<String> getIndexesKeysNames() {
        ArrayList<String> arrayList = null;
        try {
            Field[] fieldArray;
            Field[] fieldArray2 = fieldArray = this.getFieldList();
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray2[n2];
                Index index = field.getAnnotation(Index.class);
                ForeignKey foreignKey = field.getAnnotation(ForeignKey.class);
                if (!(index == null && foreignKey == null || index != null && index.tableType() != 65535 && this.designAccesObjectFather != null && (this.designAccesObjectFather.getTableType() & index.tableType()) == 0)) {
                    if (arrayList == null) {
                        arrayList = new ArrayList<String>();
                    }
                    arrayList.add(field.getName());
                }
                ++n2;
            }
            return arrayList;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(3, "getIndexesKeysNames() " + exception);
            }
            return null;
        }
    }

    public final int setPrimaryKey(long l) {
        block11: {
            Field field;
            block10: {
                try {
                    field = this.getPrimaryKeyField();
                    if (field != null) break block10;
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setPrimaryKey() Maybe a row without Primary Key ");
                    }
                    return -1;
                }
                catch (Exception exception) {
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setPrimaryKey() Maybe a row without Primary Key:" + exception);
                    }
                    return -1;
                }
            }
            Object object = this.getFieldValue(field);
            if (object instanceof Long) {
                this.setFieldValue(field, l);
                break block11;
            }
            if (object instanceof Integer) {
                this.setFieldValue(field, (int)l);
                break block11;
            }
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "setPrimaryKey() bad type");
            }
            return -1;
        }
        this.setModifierFlag(2);
        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
        }
        return 1;
    }

    public int set(String string, String string2) {
        Field field;
        block7: {
            if (string2 == null || string2.compareTo("null") == 0) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(3, "set() bad value for " + string + " " + string2);
                }
                return -1;
            }
            try {
                field = this.getFieldByName(string);
                if (field != null) break block7;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + string2 + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, string2);
    }

    public int set(String string, int n) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + n + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, n);
    }

    public int set(String string, long l) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + l + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, l);
    }

    public int set(String string, float f) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + f + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, f);
    }

    public int set(String string, boolean bl) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + bl + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, bl);
    }

    public int set(String string, Boolean bl) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + bl + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, bl);
    }

    public int set(String string, Object object) {
        try {
            if (object instanceof String) {
                return this.set(string, (String)object);
            }
            if (object instanceof byte[]) {
                return this.set(string, (byte[])object);
            }
            if (object instanceof Long) {
                long l = (Long)object;
                return this.set(string, l);
            }
            if (object instanceof Integer) {
                int n = (Integer)object;
                return this.set(string, n);
            }
            if (object instanceof Timestamp) {
                return this.set(string, (Timestamp)object);
            }
            if (object instanceof Date) {
                return this.set(string, (Date)object);
            }
            if (object instanceof Float) {
                Float f = (Float)object;
                return this.set(string, f);
            }
            if (object instanceof Boolean) {
                Boolean bl = (Boolean)object;
                return this.set(string, bl);
            }
            if (object instanceof Enum) {
                return this.set(string, (Enum)object);
            }
            if (object instanceof Bitmap) {
                return this.set(string, (Bitmap)object);
            }
            if (object instanceof Double) {
                return this.set(string, ((Double)object).floatValue());
            }
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "set() : unknown type");
            }
            return -1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "set() : " + string + ":" + object + " " + exception);
            }
            return -1;
        }
    }

    public int set(String string, Timestamp timestamp) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + timestamp + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, timestamp);
    }

    public int set(String string, Date date) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + date + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, date);
    }

    public int set(String string, byte[] byArray) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + byArray + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, byArray);
    }

    public int set(String string, Enum enum_) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + enum_ + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, enum_);
    }

    public int set(String string, Bitmap bitmap) {
        Field field;
        block5: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block5;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "set() : " + string + ":" + bitmap + " " + exception);
                }
                return -1;
            }
        }
        return this.setFieldValue(field, bitmap);
    }

    /*
     * Unable to fully structure code
     */
    public int persist() throws Exception {
        block30: {
            block29: {
                if (this.designAccesObjectFather == null) {
                    return -1;
                }
                if (!(this.designAccesObjectFather instanceof YP_TCD_DAO_LOC_Table)) {
                    this.designAccesObjectFather instanceof YP_TCD_DAO_SQL_Transaction;
                }
                if (this.isItAClonedRow()) {
                    if (this.designAccesObjectFather.getLogLevel() >= 2) {
                        this.designAccesObjectFather.logger(2, "persist() : can't persist a cloned Object");
                    }
                    return -2;
                }
                var1_1 = this.designAccesObjectFather.getDataContainerContext();
                switch (this.getModifierFlag()) {
                    case 3: {
                        if (var1_1 == null) ** GOTO lbl26
                        try {
                            if (var1_1.onSaveBefore(this.designAccesObjectFather, null, this) < 0) {
                                if (this.designAccesObjectFather.getLogLevel() >= 2) {
                                    this.designAccesObjectFather.logger(2, "persist() create have been cancelled");
                                }
                                return -1;
                            }
                        }
                        catch (Exception var2_2) {
                            if (this.designAccesObjectFather.getLogLevel() < 2) ** GOTO lbl26
                            this.designAccesObjectFather.logger(2, "persist() onSaveBefore" + var2_2);
                        }
lbl26:
                        // 4 sources

                        this.designAccesObjectFather.createRow(this);
                        break;
                    }
                    case 1: {
                        if (var1_1 == null) ** GOTO lbl41
                        try {
                            if (var1_1.onSaveBefore(this.designAccesObjectFather, null, this) < 0) {
                                if (this.designAccesObjectFather.getLogLevel() >= 2) {
                                    this.designAccesObjectFather.logger(2, "persist() delete have been cancelled");
                                }
                                return -1;
                            }
                        }
                        catch (Exception var2_3) {
                            if (this.designAccesObjectFather.getLogLevel() < 2) ** GOTO lbl41
                            this.designAccesObjectFather.logger(2, "persist() onSaveBefore" + var2_3);
                        }
lbl41:
                        // 4 sources

                        this.designAccesObjectFather.deleteRow(this);
                        break;
                    }
                    case 2: {
                        if (var1_1 == null) ** GOTO lbl56
                        try {
                            if (var1_1.onSaveBefore(this.designAccesObjectFather, null, this) < 0) {
                                if (this.designAccesObjectFather.getLogLevel() >= 2) {
                                    this.designAccesObjectFather.logger(2, "persist() update have been cancelled");
                                }
                                return -1;
                            }
                        }
                        catch (Exception var2_4) {
                            if (this.designAccesObjectFather.getLogLevel() < 2) ** GOTO lbl56
                            this.designAccesObjectFather.logger(2, "persist() onSaveBefore" + var2_4);
                        }
lbl56:
                        // 4 sources

                        this.designAccesObjectFather.updateRow(this);
                        break;
                    }
                    case 0: {
                        return 0;
                    }
                    default: {
                        if (this.designAccesObjectFather.getLogLevel() >= 2) {
                            this.designAccesObjectFather.logger(2, "persist() : unknown modifier:" + this.modifierFlag);
                        }
                        return -1;
                    }
                }
                this.designAccesObjectFather.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                if (var1_1 != null) {
                    try {
                        var1_1.updateTableStatus(this.designAccesObjectFather);
                        var1_1.onSaveAfter(this.designAccesObjectFather, null, this);
                    }
                    catch (Exception var2_6) {
                        if (this.designAccesObjectFather.getLogLevel() < 2) break block29;
                        this.designAccesObjectFather.logger(2, "persist() onSaveAfter" + var2_6);
                    }
                }
            }
            this.setModifierFlag(0);
            if (var1_1 != null) {
                try {
                    var1_1.onChange(this.designAccesObjectFather);
                }
                catch (Exception var2_7) {
                    if (this.designAccesObjectFather.getLogLevel() < 2) break block30;
                    this.designAccesObjectFather.logger(2, "persist() onChange" + var2_7);
                }
            }
        }
        this.designAccesObjectFather.notifyWatcher();
        return 1;
    }

    @Deprecated
    public int silentPersist() throws Exception {
        if (this.designAccesObjectFather == null) {
            return -1;
        }
        if (this.designAccesObjectFather instanceof YP_TCD_DAO_LOC_Table) {
            if (this.designAccesObjectFather.getLogLevel() >= 3) {
                this.designAccesObjectFather.logger(3, "silentPersist() : Most of time it's better to use persist on the table instead of on the row !!!");
            }
        } else {
            boolean cfr_ignored_0 = this.designAccesObjectFather instanceof YP_TCD_DAO_SQL_Transaction;
        }
        if (this.isItAClonedRow()) {
            if (this.designAccesObjectFather.getLogLevel() >= 2) {
                this.designAccesObjectFather.logger(2, "silentPersist() : can't persist a cloned Object");
            }
            return -2;
        }
        switch (this.getModifierFlag()) {
            case 3: {
                this.designAccesObjectFather.createRow(this);
                break;
            }
            case 1: {
                this.designAccesObjectFather.deleteRow(this);
                break;
            }
            case 2: {
                this.designAccesObjectFather.updateRow(this);
                break;
            }
            case 0: {
                return 0;
            }
            default: {
                if (this.designAccesObjectFather.getLogLevel() >= 2) {
                    this.designAccesObjectFather.logger(2, "silentPersist() : unknown modifier:" + this.modifierFlag);
                }
                return -1;
            }
        }
        this.setModifierFlag(0);
        return 1;
    }

    public static int persistList(List<YP_Row> list) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
        block22: {
            YP_TCD_DC_Context yP_TCD_DC_Context;
            ArrayList<YP_Row> arrayList;
            block21: {
                block20: {
                    if (list == null || list.isEmpty()) {
                        return 0;
                    }
                    yP_TCD_DesignAccesObject = list.get((int)0).designAccesObjectFather;
                    if (yP_TCD_DesignAccesObject == null) {
                        return -1;
                    }
                    if (yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_LOC_Table) {
                        if (yP_TCD_DesignAccesObject.getLogLevel() >= 3) {
                            yP_TCD_DesignAccesObject.logger(3, "persistList() : Most of time it's better to use persist on the table instead of on the row !!!");
                        }
                    } else {
                        boolean cfr_ignored_0 = yP_TCD_DesignAccesObject instanceof YP_TCD_DAO_SQL_Transaction;
                    }
                    arrayList = new ArrayList<YP_Row>();
                    for (YP_Row yP_Row : list) {
                        if (yP_Row.isItAClonedRow()) {
                            if (yP_TCD_DesignAccesObject.getLogLevel() >= 2) {
                                yP_TCD_DesignAccesObject.logger(2, "persistList() : can't persist a cloned Object");
                            }
                            return -2;
                        }
                        if (yP_Row.getModifierFlag() == 1) {
                            if (yP_TCD_DesignAccesObject.getLogLevel() >= 2) {
                                yP_TCD_DesignAccesObject.logger(2, "persistList() : persistList is not possible for delete (for the moment)");
                            }
                            return -2;
                        }
                        if (yP_Row.getModifierFlag() == 0) continue;
                        arrayList.add(yP_Row);
                    }
                    yP_TCD_DC_Context = yP_TCD_DesignAccesObject.getDataContainerContext();
                    if (yP_TCD_DC_Context != null) {
                        try {
                            yP_TCD_DC_Context.onSaveBefore(yP_TCD_DesignAccesObject, arrayList, null);
                        }
                        catch (Exception exception) {
                            if (yP_TCD_DesignAccesObject.getLogLevel() < 2) break block20;
                            yP_TCD_DesignAccesObject.logger(2, "persistList() onSaveBefore" + exception);
                        }
                    }
                }
                yP_TCD_DesignAccesObject.getDataBaseConnector().sql_Formater.sqlUpdateRowList(yP_TCD_DesignAccesObject, arrayList);
                yP_TCD_DesignAccesObject.setTableSystemGMTTime(new Timestamp(UtilsYP.getSystemGMTTime().getTimeInMillis()));
                if (yP_TCD_DC_Context != null) {
                    try {
                        yP_TCD_DC_Context.updateTableStatus(yP_TCD_DesignAccesObject);
                        yP_TCD_DC_Context.onSaveAfter(yP_TCD_DesignAccesObject, arrayList, null);
                    }
                    catch (Exception exception) {
                        if (yP_TCD_DesignAccesObject.getLogLevel() < 2) break block21;
                        yP_TCD_DesignAccesObject.logger(2, "persistList() onSaveAfter" + exception);
                    }
                }
            }
            for (YP_Row yP_Row : arrayList) {
                yP_Row.setModifierFlag(0);
            }
            if (yP_TCD_DC_Context != null) {
                try {
                    yP_TCD_DC_Context.onChange(yP_TCD_DesignAccesObject);
                }
                catch (Exception exception) {
                    if (yP_TCD_DesignAccesObject.getLogLevel() < 2) break block22;
                    yP_TCD_DesignAccesObject.logger(2, "persistList() onChange" + exception);
                }
            }
        }
        yP_TCD_DesignAccesObject.notifyWatcher();
        return 1;
    }

    public final int setModifierFlag(int n) {
        if (n == 2 && this.modifierFlag == 3) {
            return 0;
        }
        this.modifierFlag = n;
        return 1;
    }

    public final int setModifierFlag(int n, boolean bl) {
        if (n == 2 && this.modifierFlag == 3 && !bl) {
            return 0;
        }
        this.modifierFlag = n;
        return 1;
    }

    public final int getModifierFlag() {
        return this.modifierFlag;
    }

    public final int delete() {
        if (this.isItAClonedRow()) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(3, "delete() : can't delete() a cloned Object");
            }
            return 0;
        }
        this.setModifierFlag(1);
        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
        }
        return 1;
    }

    public final Object clone() {
        YP_Row yP_Row;
        block4: {
            try {
                yP_Row = (YP_Row)super.clone();
                if (this.copy(yP_Row) >= 0) break block4;
                return null;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "clone() : " + exception);
                }
                return null;
            }
        }
        yP_Row.setIsItAClonedRow(true);
        return yP_Row;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int copy(YP_Row yP_Row) {
        try {
            Object object2;
            if (this.extensionList != null) {
                yP_Row.extensionList = new ArrayList<Object>();
                for (Object object2 : this.extensionList) {
                    yP_Row.addRowExtension(object2.getClass().newInstance());
                }
            }
            object2 = this.getFieldList();
            Field[] fieldArray = object2;
            int n = ((Field[])object2).length;
            int n2 = 0;
            while (true) {
                if (n2 >= n) {
                    return 1;
                }
                Field field = fieldArray[n2];
                Object object3 = this.getFieldValue(field);
                if (object3 instanceof byte[]) {
                    yP_Row.setFieldValue(field, (byte[])((byte[])object3).clone());
                } else if (object3 instanceof Timestamp) {
                    yP_Row.setFieldValue(field, ((Timestamp)object3).clone());
                } else if (object3 instanceof Date) {
                    yP_Row.setFieldValue(field, ((Date)object3).clone());
                } else if (object3 instanceof Bitmap) {
                    yP_Row.setFieldValue(field, new Bitmap(((Bitmap)object3).getBitmap()));
                } else if (object3 instanceof Integer) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 instanceof Long) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 instanceof Float) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 instanceof Boolean) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 instanceof Enum) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 == null && field.getType().isEnum()) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 == null && field.getType() == Boolean.class) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 == null && field.getType() == Bitmap.class) {
                    yP_Row.setFieldValue(field, object3);
                } else if (object3 == null && field.getType() == Date.class) {
                    java.util.Date date = new java.util.Date();
                    yP_Row.setFieldValue(field, new Date(date.getTime()));
                } else {
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "copy() bad type: " + field.getName());
                    }
                    return -1;
                }
                ++n2;
            }
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "copy() : ", exception);
            }
            return -1;
        }
    }

    public final void setFather(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        this.designAccesObjectFather = yP_TCD_DesignAccesObject;
        if (UtilsYP.getTableStructureMode() == 1 && this.contractKey == 0L && yP_TCD_DesignAccesObject.getDataContainerContext() instanceof YP_TCD_DCC_EFT_Business) {
            this.contractKey = ((YP_TCD_DCC_EFT_Business)yP_TCD_DesignAccesObject.getDataContainerContext()).getIDContract();
        }
    }

    public final YP_TCD_DesignAccesObject getFather() {
        return this.designAccesObjectFather;
    }

    public final String serialize() {
        try {
            return this.serialize(this.getFieldList());
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "serialize() " + exception);
            }
            return null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int serialize(StringBuilder var1_1, Field[] var2_2) {
        try {
            var6_3 = var2_2;
            var5_4 = var2_2.length;
            var4_5 = 0;
            while (true) {
                if (var4_5 >= var5_4) {
                    var1_1.append('\n');
                    return 1;
                }
                var3_6 = var6_3[var4_5];
                var7_8 = this.getFieldValue(var3_6);
                if (var7_8 instanceof byte[]) {
                    try {
                        if ((byte[])var7_8 == null || ((byte[])var7_8).length == 0 || ((byte[])var7_8)[0] == 0) ** GOTO lbl75
                        var8_9 = new String((byte[])var7_8, 0, ((byte[])var7_8).length, "UTF-8");
                        if (var8_9.indexOf(44) >= 0) {
                            var8_9 = var8_9.replace(",", "&#44;");
                        }
                        var1_1.append(var8_9);
                    }
                    catch (Exception v0) {
                        return -1;
                    }
                } else if (var7_8 instanceof Integer) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Long) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Timestamp) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Date) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Float) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Boolean) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Enum) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Bitmap) {
                    var1_1.append(Long.toString(((Bitmap)var7_8).getBitmap()));
                } else if (var7_8 instanceof Double) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 == null && var3_6.getType() == Boolean.class) {
                    var1_1.append("null");
                } else if (var7_8 == null && var3_6.getType() == Bitmap.class) {
                    var1_1.append("null");
                } else if (var7_8 == null && var3_6.getType().isEnum()) {
                    var1_1.append("null");
                } else {
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "serialize() bad type: " + var3_6.getName() + ":" + var7_8);
                    }
                    return -1;
                }
lbl75:
                // 14 sources

                var1_1.append(',');
                ++var4_5;
            }
        }
        catch (Exception var3_7) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "serialize() " + var3_7);
            }
            return -1;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int serialize(ByteBuilder var1_1, Field[] var2_2) {
        try {
            var6_3 = var2_2;
            var5_4 = var2_2.length;
            var4_5 = 0;
            while (true) {
                if (var4_5 >= var5_4) {
                    var1_1.append('\n');
                    return 1;
                }
                var3_6 = var6_3[var4_5];
                var7_8 = this.getFieldValue(var3_6);
                if (var7_8 instanceof byte[]) {
                    try {
                        if ((byte[])var7_8 == null || ((byte[])var7_8).length == 0 || ((byte[])var7_8)[0] == 0) ** GOTO lbl75
                        var8_9 = new String((byte[])var7_8, 0, ((byte[])var7_8).length, "UTF-8");
                        if (var8_9.indexOf(44) >= 0) {
                            var8_9 = var8_9.replace(",", "&#44;");
                        }
                        var1_1.append(var8_9);
                    }
                    catch (Exception v0) {
                        return -1;
                    }
                } else if (var7_8 instanceof Integer) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Long) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Timestamp) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Date) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Float) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Boolean) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Enum) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 instanceof Bitmap) {
                    var1_1.append(Long.toString(((Bitmap)var7_8).getBitmap()));
                } else if (var7_8 instanceof Double) {
                    var1_1.append(var7_8.toString());
                } else if (var7_8 == null && var3_6.getType() == Boolean.class) {
                    var1_1.append("null");
                } else if (var7_8 == null && var3_6.getType() == Bitmap.class) {
                    var1_1.append("null");
                } else if (var7_8 == null && var3_6.getType().isEnum()) {
                    var1_1.append("null");
                } else {
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "serialize() bad type: " + var3_6.getName() + ":" + var7_8);
                    }
                    return -1;
                }
lbl75:
                // 14 sources

                var1_1.append(',');
                ++var4_5;
            }
        }
        catch (Exception var3_7) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "serialize() " + var3_7);
            }
            return -1;
        }
    }

    public final String serialize(Field[] fieldArray) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            int n = this.serialize(stringBuilder, fieldArray);
            if (n == 1) {
                return stringBuilder.toString();
            }
            return null;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "serialize() " + exception);
            }
            return null;
        }
    }

    public final int deserialize(String string) {
        String[] stringArray;
        int n;
        Field[] fieldArray;
        block5: {
            fieldArray = this.getFieldList();
            n = fieldArray.length;
            stringArray = string.split(",");
            if (n == stringArray.length || n == stringArray.length - 1 && stringArray[n].contentEquals("\n")) break block5;
            return -1;
        }
        try {
            int n2 = 0;
            while (n2 < n) {
                this.setFieldValue(fieldArray[n2], stringArray[n2]);
                ++n2;
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "deserialize() " + exception);
            }
            return -1;
        }
    }

    public final void setIsItAClonedRow(boolean bl) {
        this.clonedRow = bl;
    }

    public final boolean isItAClonedRow() {
        return this.clonedRow;
    }

    public final String getTableName() {
        String string = "";
        if (this.designAccesObjectFather != null && (this.designAccesObjectFather.getTableType() & 8) != 0) {
            string = String.valueOf(string) + "_archive";
        }
        if (this.designAccesObjectFather != null && this.designAccesObjectFather instanceof YP_TCD_DAO_SQL_Transaction) {
            string = UtilsYP.getInstanceRole() == 1 || UtilsYP.getInstanceRole() == 3 ? String.valueOf(string) + this.designAccesObjectFather.getMasterExtension() : String.valueOf(string) + this.designAccesObjectFather.getSlaveExtension();
        }
        if (this.designAccesObjectFather != null && (this.designAccesObjectFather.getTableType() & 0x10) != 0) {
            string = String.valueOf(string) + "_" + this.designAccesObjectFather.getTableVersion();
        }
        return this.getTableName(string);
    }

    private final String getTableName(String string) {
        String string2 = this.toString();
        int n = 0;
        int n2 = 0;
        while (n2 < string2.length()) {
            if (string2.charAt(n2) == '_') {
                ++n;
            }
            ++n2;
        }
        if (n > 0) {
            string2 = string2.startsWith("DAO_KRN_") || string2.startsWith("DAO_STD_") ? string2.substring(8) : string2.substring(string2.indexOf(95) + 1);
        }
        if (string != null) {
            string2 = String.valueOf(string2) + string;
        }
        return string2;
    }

    public final String getSlaveTableName() {
        if (this.designAccesObjectFather != null && this.designAccesObjectFather instanceof YP_TCD_DAO_SQL_Transaction) {
            String string = this.designAccesObjectFather.getSlaveExtension();
            if (this.designAccesObjectFather != null && (this.designAccesObjectFather.getTableType() & 0x10) != 0) {
                string = String.valueOf(string) + "_" + this.designAccesObjectFather.getTableVersion();
            }
            return this.getTableName(string);
        }
        return null;
    }

    public final String getMasterTableName() {
        if (this.designAccesObjectFather != null && this.designAccesObjectFather instanceof YP_TCD_DAO_SQL_Transaction) {
            String string = this.designAccesObjectFather.getMasterExtension();
            if (this.designAccesObjectFather != null && (this.designAccesObjectFather.getTableType() & 0x10) != 0) {
                string = String.valueOf(string) + "_" + this.designAccesObjectFather.getTableVersion();
            }
            return this.getTableName(string);
        }
        return null;
    }

    public final String toString() {
        return this.getClass().getSimpleName();
    }

    public int getFieldLength(String string) {
        Field field;
        block7: {
            try {
                field = this.getFieldByName(string);
                if (field != null) break block7;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldLength() unknown field " + string);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldLength() : " + string + ":" + exception);
                }
                return -1;
            }
        }
        Object object = this.getFieldValue(field);
        if (object instanceof byte[]) {
            return ((byte[])object).length;
        }
        if (this.designAccesObjectFather != null) {
            this.designAccesObjectFather.logger(2, "getFieldLength() bad type: " + string + ":" + object);
        }
        return -1;
    }

    public int getFieldLength(Field field) {
        block7: {
            try {
                if (field != null) break block7;
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldLength() null field ");
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getFieldLength() : " + field.getName() + ":" + exception);
                }
                return -1;
            }
        }
        Object object = this.getFieldValue(field);
        if (object instanceof byte[]) {
            return ((byte[])object).length;
        }
        if (this.designAccesObjectFather != null) {
            this.designAccesObjectFather.logger(2, "getFieldLength() bad type: " + field.getName() + ":" + object);
        }
        return -1;
    }

    public Field getPrimaryKeyField() {
        Field field;
        block5: {
            try {
                field = this.designAccesObjectFather != null ? this.designAccesObjectFather.getPrimaryKeyField() : this.getFieldByName(this.getPrimaryKeyName());
                if (field != null) break block5;
                if (this.designAccesObjectFather != null && !this.designAccesObjectFather.getSchemaName().contentEquals("events")) {
                    this.designAccesObjectFather.logger(2, "getPrimaryKeyField() Maybe a row without Primary Key ");
                }
                return null;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "getPrimaryKeyField() :" + exception);
                }
                return null;
            }
        }
        return field;
    }

    public int getColumnIndex(String string) {
        return this.getColumnIndex(this.getFieldByName(string));
    }

    public int getColumnIndex(Field field) {
        if (field == null) {
            return -1;
        }
        Field[] fieldArray = this.getFieldList();
        int n = 0;
        while (n < fieldArray.length) {
            if (field == fieldArray[n]) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean equals(Object object) {
        try {
            Field[] fieldArray;
            if (!(object instanceof YP_Row)) {
                return false;
            }
            YP_Row yP_Row = (YP_Row)object;
            if (this.getClass() != yP_Row.getClass()) {
                return false;
            }
            Field[] fieldArray2 = fieldArray = this.getFieldList();
            int n = fieldArray.length;
            int n2 = 0;
            while (true) {
                if (n2 >= n) {
                    return true;
                }
                Field field = fieldArray2[n2];
                Object object2 = this.getFieldValue(field);
                Object object3 = yP_Row.getFieldValue(field);
                if (object2 != null || object3 != null) {
                    if (object2 == null && object3 != null || object2 != null && object3 == null) {
                        if (this.designAccesObjectFather != null && this.designAccesObjectFather.getLogLevel() >= 5) {
                            this.designAccesObjectFather.logger(5, "equals() not as one is null");
                        }
                        return false;
                    }
                    if (!(object2.equals(object3) || object2 instanceof byte[] && (((byte[])object2 == null || ((byte[])object2).length == 0 || ((byte[])object2)[0] == 0) && ((byte[])object3 == null || ((byte[])object3).length == 0 || ((byte[])object3)[0] == 0) || object2 != null && object3 != null && Arrays.equals((byte[])object2, (byte[])object3)))) {
                        if (this.designAccesObjectFather != null && this.designAccesObjectFather.getLogLevel() >= 5) {
                            this.designAccesObjectFather.logger(5, "equals() not...");
                        }
                        return false;
                    }
                }
                ++n2;
            }
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "equals() " + exception);
            }
            return false;
        }
    }

    public int hashCode() {
        return this.serialize().hashCode();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int addRowExtension(Object object) {
        try {
            if (this.extensionList == null) {
                this.extensionList = new ArrayList<Object>();
            } else {
                for (Object object2 : this.extensionList) {
                    if (object2.getClass() != object.getClass()) continue;
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(4, "addRowExtension() already added :" + object.toString());
                    }
                    return 0;
                }
            }
            this.extensionList.add(object);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "addRowExtension() " + exception);
            }
            return -1;
        }
    }

    public final Field[] __getFieldList() {
        Field[] fieldArray;
        block10: {
            fieldArray = this.getClass().getDeclaredFields();
            if (this.extensionList != null) {
                for (Object object : this.extensionList) {
                    Field[] fieldArray2 = fieldArray;
                    Field[] fieldArray3 = object.getClass().getDeclaredFields();
                    fieldArray = new Field[fieldArray2.length + fieldArray3.length];
                    System.arraycopy(fieldArray2, 0, fieldArray, 0, fieldArray2.length);
                    System.arraycopy(fieldArray3, 0, fieldArray, fieldArray2.length, fieldArray3.length);
                }
            }
            if (this.contractKey != 0L) {
                try {
                    Object object;
                    object = this.getClass().getField("contractKey");
                    Field[] fieldArray4 = new Field[fieldArray.length + 1];
                    System.arraycopy(fieldArray, 0, fieldArray4, 1, fieldArray.length);
                    fieldArray4[0] = object;
                    fieldArray = fieldArray4;
                }
                catch (Exception exception) {
                    if (this.designAccesObjectFather == null) break block10;
                    this.designAccesObjectFather.logger(2, "__getFieldList() : " + exception);
                }
            }
        }
        int n = 0;
        int n2 = 0;
        while (n2 < fieldArray.length) {
            if (!fieldArray[n2].toString().startsWith("private")) {
                ++n;
            }
            ++n2;
        }
        if (fieldArray.length == n) {
            return fieldArray;
        }
        Field[] fieldArray5 = new Field[n];
        int n3 = 0;
        int n4 = 0;
        while (n4 < fieldArray.length) {
            if (!fieldArray[n4].toString().startsWith("private")) {
                fieldArray5[n3++] = fieldArray[n4];
            }
            ++n4;
        }
        return fieldArray5;
    }

    public Field getFieldByName(String string) {
        try {
            if (this.designAccesObjectFather != null) {
                return this.designAccesObjectFather.getFieldByName(string);
            }
            Field[] fieldArray = this.getFieldList();
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray[n2];
                if (field.getName().contentEquals(string)) {
                    return field;
                }
                ++n2;
            }
            return null;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldByName() : " + string + ":" + exception);
            }
            return null;
        }
    }

    public Object getFieldValue(Field field) {
        try {
            if (this.extensionList == null) {
                return field.get(this);
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                return field.get(this);
            }
            for (Object object : this.extensionList) {
                if (clazz != object.getClass()) continue;
                return field.get(object);
            }
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldValue() not found " + field.getName());
            }
            return null;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "getFieldValue()  " + exception);
            }
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    public final int setFieldValue(Field var1_1, String var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CATCHBLOCK]], but top level block is 2[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, int n) {
        block30: {
            try {
                if (field.getType() == Integer.TYPE) {
                    if (this.extensionList == null) {
                        if (field.getInt(this) == n) {
                            return 0;
                        }
                        field.setInt(this, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        if (field.getInt(this) == n) {
                            return 0;
                        }
                        field.setInt(this, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        if (field.getInt(object) == n) {
                            return 0;
                        }
                        field.setInt(object, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block30;
                }
                if (field.getType() == Long.TYPE) {
                    if (this.extensionList == null) {
                        if (field.getLong(this) == (long)n) {
                            return 0;
                        }
                        field.setLong(this, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        if (field.getLong(this) == (long)n) {
                            return 0;
                        }
                        field.setLong(this, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        if (field.getLong(object) == (long)n) {
                            return 0;
                        }
                        field.setLong(object, n);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block30;
                }
                if (field.getType() == Float.TYPE) {
                    return this.setFieldValue(field, (float)n);
                }
                if (field.getType() == Bitmap.class) {
                    return this.setFieldValue(field, new Bitmap(n));
                }
                if (field.getType() == byte[].class) {
                    return this.setFieldValue(field, Integer.toString(n));
                }
                if (field.getType() == Boolean.class) {
                    if (n == 0) {
                        return this.setFieldValue(field, false);
                    }
                    return this.setFieldValue(field, true);
                }
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + n);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather == null) break block30;
                this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + n + " " + exception);
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, long l) {
        block30: {
            try {
                if (field.getType() == Long.TYPE) {
                    if (this.extensionList == null) {
                        if (field.getLong(this) == l) {
                            return 0;
                        }
                        field.setLong(this, l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        if (field.getLong(this) == l) {
                            return 0;
                        }
                        field.setLong(this, l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        if (field.getLong(object) == l) {
                            return 0;
                        }
                        field.setLong(object, l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block30;
                }
                if (field.getType() == Integer.TYPE) {
                    if (this.extensionList == null) {
                        if ((long)field.getInt(this) == l) {
                            return 0;
                        }
                        field.setInt(this, (int)l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        if ((long)field.getInt(this) == l) {
                            return 0;
                        }
                        field.setInt(this, (int)l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        if ((long)field.getInt(object) == l) {
                            return 0;
                        }
                        field.setInt(object, (int)l);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block30;
                }
                if (field.getType() == Float.TYPE) {
                    return this.setFieldValue(field, (float)l);
                }
                if (field.getType() == Bitmap.class) {
                    return this.setFieldValue(field, new Bitmap(l));
                }
                if (field.getType() == byte[].class) {
                    return this.setFieldValue(field, Long.toString(l));
                }
                if (field.getType() == Boolean.class) {
                    if (l == 0L) {
                        return this.setFieldValue(field, false);
                    }
                    return this.setFieldValue(field, true);
                }
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + l);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather == null) break block30;
                this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + l + " " + exception);
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, float f) {
        try {
            Object object;
            if (field.getType() != Float.TYPE) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + f);
                return -1;
            }
            if (this.extensionList == null) {
                if (field.getFloat(this) == f) {
                    return 0;
                }
                field.setFloat(this, f);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                if (field.getFloat(this) == f) {
                    return 0;
                }
                field.setFloat(this, f);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            if (field.getFloat(object) == f) {
                return 0;
            }
            field.setFloat(object, f);
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + f + " " + exception);
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, boolean bl) {
        try {
            Object object;
            if (field.getType() != Boolean.class && field.getType() != Boolean.TYPE) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + bl);
                return -1;
            }
            if (this.extensionList == null) {
                Object object2 = field.get(this);
                if (object2 != null && (Boolean)object2 == bl) {
                    return 0;
                }
                field.set(this, new Boolean(bl));
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                Object object3 = field.get(this);
                if (object3 != null && (Boolean)object3 == bl) {
                    return 0;
                }
                field.set(this, new Boolean(bl));
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            Object object4 = field.get(object);
            if (object4 != null && (Boolean)object4 == bl) {
                return 0;
            }
            field.set(object, new Boolean(bl));
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + bl + " " + exception);
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, Boolean bl) {
        try {
            Object object;
            if (field.getType() != Boolean.class && field.getType() != Boolean.TYPE) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + bl);
                return -1;
            }
            if (this.extensionList == null) {
                Object object2 = field.get(this);
                if (object2 == bl) {
                    return 0;
                }
                if (bl == null) {
                    field.set(this, null);
                } else {
                    field.set(this, new Boolean(bl));
                }
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                Object object3 = field.get(this);
                if (object3 == bl) {
                    return 0;
                }
                if (bl == null) {
                    field.set(this, null);
                } else {
                    field.set(this, new Boolean(bl));
                }
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            Object object4 = field.get(object);
            if (object4 == bl) {
                return 0;
            }
            if (bl == null) {
                field.set(object, null);
            } else {
                field.set(object, new Boolean(bl));
            }
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue()  : " + field.getName() + ":" + bl + " " + exception);
        }
        return -1;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, Timestamp timestamp) {
        block18: {
            try {
                if (field.getType() == Timestamp.class) {
                    if (this.extensionList == null) {
                        Object object = field.get(this);
                        if (object == null && timestamp == null) {
                            return 0;
                        }
                        if (object != null && timestamp != null && ((Timestamp)object).compareTo(timestamp) == 0) {
                            return 0;
                        }
                        field.set(this, timestamp);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        Object object = field.get(this);
                        if (object == null && timestamp == null) {
                            return 0;
                        }
                        if (object != null && timestamp != null && ((Timestamp)object).compareTo(timestamp) == 0) {
                            return 0;
                        }
                        field.set(this, timestamp);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        Object object2 = field.get(object);
                        if (object2 == null && timestamp == null) {
                            return 0;
                        }
                        if (object2 != null && timestamp != null && ((Timestamp)object2).compareTo(timestamp) == 0) {
                            return 0;
                        }
                        field.set(object, timestamp);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block18;
                }
                if (field.getType() == Date.class) {
                    return this.setFieldValue(field, new Date(timestamp.getTime()));
                }
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + timestamp);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather == null) break block18;
                this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + timestamp + " " + exception);
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, Date date) {
        block18: {
            try {
                if (field.getType() == Date.class) {
                    Date date2 = date != null ? new Date(date.getTime() / 86400000L * 86400000L) : null;
                    if (this.extensionList == null) {
                        Object object = field.get(this);
                        if (object == null && date2 == null) {
                            return 0;
                        }
                        if (object != null && date2 != null && ((Date)object).compareTo(date2) == 0) {
                            return 0;
                        }
                        field.set(this, date2);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    Class<?> clazz = field.getDeclaringClass();
                    if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                        Object object = field.get(this);
                        if (object == null && date2 == null) {
                            return 0;
                        }
                        if (object != null && date2 != null && ((Date)object).compareTo(date2) == 0) {
                            return 0;
                        }
                        field.set(this, date2);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    for (Object object : this.extensionList) {
                        if (clazz != object.getClass()) continue;
                        Object object2 = field.get(object);
                        if (object2 == null && date2 == null) {
                            return 0;
                        }
                        if (object2 != null && date2 != null && ((Date)object2).compareTo(date2) == 0) {
                            return 0;
                        }
                        field.set(object, date2);
                        this.setModifierFlag(2);
                        if (this.designAccesObjectFather != null && !this.designAccesObjectFather.isItAModifiedDAO() && !this.isItAClonedRow()) {
                            this.designAccesObjectFather.setIsItAModifiedDAO(true);
                        }
                        return 1;
                    }
                    if (this.designAccesObjectFather != null) {
                        this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                    }
                    break block18;
                }
                if (field.getType() == byte[].class) {
                    this.setFieldValue(field, date.toString());
                    break block18;
                }
                if (this.designAccesObjectFather != null) {
                    this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + date);
                }
                return -1;
            }
            catch (Exception exception) {
                if (this.designAccesObjectFather == null) break block18;
                this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + date + " " + exception);
            }
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, byte[] byArray) {
        try {
            Object object;
            int n;
            if (field.getType() != byte[].class) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + new String(byArray));
                return -1;
            }
            if (this.designAccesObjectFather != null && (n = this.designAccesObjectFather.getFieldLength(field)) > 0 && byArray != null && n < byArray.length) {
                if (this.designAccesObjectFather.getLogLevel() >= 2) {
                    this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + new String(byArray) + " too long -> data will be truncated");
                }
                byArray = Arrays.copyOf(byArray, this.designAccesObjectFather.getFieldLength(field));
            }
            if (this.extensionList == null) {
                Object object2 = field.get(this);
                if (object2 == null && byArray == null) {
                    return 0;
                }
                if (object2 != null && byArray != null && YP_ComplexGabarit.byteArrayCompare((byte[])object2, byArray, true) == 0) {
                    return 0;
                }
                field.set(this, byArray);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                Object object3 = field.get(this);
                if (object3 == null && byArray == null) {
                    return 0;
                }
                if (object3 != null && byArray != null && YP_ComplexGabarit.byteArrayCompare((byte[])object3, byArray, true) == 0) {
                    return 0;
                }
                field.set(this, byArray);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            Object object4 = field.get(object);
            if (object4 == null && byArray == null) {
                return 0;
            }
            if (object4 != null && byArray != null && YP_ComplexGabarit.byteArrayCompare((byte[])object4, byArray, true) == 0) {
                return 0;
            }
            field.set(object, byArray);
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + byArray + " " + exception);
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int setFieldValue(Field field, Enum enum_) {
        try {
            Object object;
            if (!field.getType().isEnum()) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + enum_);
                return -1;
            }
            if (this.extensionList == null) {
                Object object2 = field.get(this);
                if (object2 == null && enum_ == null) {
                    return 0;
                }
                if (object2 != null && enum_ != null && ((Enum)object2).compareTo(enum_) == 0) {
                    return 0;
                }
                field.set(this, enum_);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                Object object3 = field.get(this);
                if (object3 == null && enum_ == null) {
                    return 0;
                }
                if (object3 != null && enum_ != null && ((Enum)object3).compareTo(enum_) == 0) {
                    return 0;
                }
                field.set(this, enum_);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            Object object4 = field.get(object);
            if (object4 == null && enum_ == null) {
                return 0;
            }
            if (object4 != null && enum_ != null && ((Enum)object4).compareTo(enum_) == 0) {
                return 0;
            }
            field.set(object, enum_);
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + enum_ + " " + exception);
        }
        return -1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int setFieldValue(Field field, Bitmap bitmap) {
        try {
            Object object;
            if (field.getType() != Bitmap.class) {
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() bad type: " + field.getName() + ":" + bitmap);
                return -1;
            }
            if (this.extensionList == null) {
                Object object2 = field.get(this);
                if (object2 == null && bitmap == null) {
                    return 0;
                }
                if (object2 != null && bitmap != null && bitmap.getBitmap() == ((Bitmap)object2).getBitmap()) {
                    return 0;
                }
                field.set(this, bitmap);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Class<?> clazz = field.getDeclaringClass();
            if (clazz == this.getClass() || clazz == this.getClass().getSuperclass()) {
                Object object3 = field.get(this);
                if (object3 == null && bitmap == null) {
                    return 0;
                }
                if (object3 != null && bitmap != null && bitmap.getBitmap() == ((Bitmap)object3).getBitmap()) {
                    return 0;
                }
                field.set(this, bitmap);
                this.setModifierFlag(2);
                if (this.designAccesObjectFather == null) return 1;
                if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
                if (this.isItAClonedRow()) return 1;
                this.designAccesObjectFather.setIsItAModifiedDAO(true);
                return 1;
            }
            Iterator<Object> iterator = this.extensionList.iterator();
            do {
                if (iterator.hasNext()) continue;
                if (this.designAccesObjectFather == null) return -1;
                this.designAccesObjectFather.logger(2, "setFieldValue() not found " + field.getName());
                return -1;
            } while (clazz != (object = iterator.next()).getClass());
            Object object4 = field.get(object);
            if (object4 == null && bitmap == null) {
                return 0;
            }
            if (object4 != null && bitmap != null && bitmap.getBitmap() == ((Bitmap)object4).getBitmap()) {
                return 0;
            }
            field.set(object, bitmap);
            this.setModifierFlag(2);
            if (this.designAccesObjectFather == null) return 1;
            if (this.designAccesObjectFather.isItAModifiedDAO()) return 1;
            if (this.isItAClonedRow()) return 1;
            this.designAccesObjectFather.setIsItAModifiedDAO(true);
            return 1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather == null) return -1;
            this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + bitmap + " " + exception);
        }
        return -1;
    }

    public final int setFieldValue(Field field, Object object) {
        try {
            if (object instanceof String) {
                return this.setFieldValue(field, (String)object);
            }
            if (object instanceof byte[]) {
                return this.setFieldValue(field, (byte[])object);
            }
            if (object instanceof Long) {
                long l = (Long)object;
                return this.setFieldValue(field, l);
            }
            if (object instanceof Integer) {
                int n = (Integer)object;
                return this.setFieldValue(field, n);
            }
            if (object instanceof Timestamp) {
                return this.setFieldValue(field, (Timestamp)object);
            }
            if (object instanceof Date) {
                return this.setFieldValue(field, (Date)object);
            }
            if (object instanceof Float) {
                float f = ((Float)object).floatValue();
                return this.setFieldValue(field, f);
            }
            if (object instanceof Boolean) {
                return this.setFieldValue(field, (boolean)((Boolean)object));
            }
            if (object instanceof Bitmap) {
                return this.setFieldValue(field, (Bitmap)object);
            }
            if (object instanceof Double) {
                float f = ((Double)object).floatValue();
                return this.setFieldValue(field, f);
            }
            if (object instanceof Enum) {
                return this.setFieldValue(field, (Enum)object);
            }
            if (object == null && field.getType().isEnum()) {
                return this.setFieldValue(field, (Enum)object);
            }
            if (object == null && field.getType() == Boolean.class) {
                return this.setFieldValue(field, (Boolean)object);
            }
            if (object == null && field.getType() == Bitmap.class) {
                return this.setFieldValue(field, (Bitmap)object);
            }
            if (object == null && field.getType() == Date.class) {
                java.util.Date date = new java.util.Date();
                return this.setFieldValue(field, new Date(date.getTime()));
            }
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "setFieldValue() : unknown type for " + field.getName());
            }
            return -1;
        }
        catch (Exception exception) {
            if (this.designAccesObjectFather != null) {
                this.designAccesObjectFather.logger(2, "setFieldValue() : " + field.getName() + ":" + object + " " + exception);
            }
            return -1;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static byte[] getXMLBytes(String var0) {
        if (var0 == null) {
            return null;
        }
        if (var0.contains("&lt;") || var0.contains("&gt;") || var0.contains("&quot;") || var0.contains("&#039;") || var0.contains("&amp;")) {
            var0 = var0.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#039;", "'").replace("&amp;", "&");
        }
        try {
            return var0.getBytes("UTF-8");
        }
        catch (UnsupportedEncodingException v0) {
            var1_1 = var0.length();
            var2_2 = new byte[var1_1];
            var3_3 = 0;
            ** while (var3_3 < var1_1)
        }
lbl-1000:
        // 1 sources

        {
            var2_2[var3_3] = (byte)var0.charAt(var3_3);
            ++var3_3;
            continue;
        }
lbl15:
        // 1 sources

        return var2_2;
    }

    protected long getLong(String string) {
        int n = string.length();
        long l = 0L;
        boolean bl = false;
        int n2 = 0;
        if (string.charAt(0) == '-') {
            bl = true;
            ++n2;
        }
        while (n2 < n) {
            l *= 10L;
            l += (long)((byte)(string.charAt(n2) - 48));
            ++n2;
        }
        if (bl) {
            return -l;
        }
        return l;
    }

    protected int getInt(String string) {
        int n = string.length();
        int n2 = 0;
        boolean bl = false;
        int n3 = 0;
        if (string.charAt(0) == '-') {
            bl = true;
            ++n3;
        }
        while (n3 < n) {
            n2 *= 10;
            n2 += (byte)(string.charAt(n3) - 48);
            ++n3;
        }
        if (bl) {
            return -n2;
        }
        return n2;
    }

    public List<Object> getExtensionList() {
        return this.extensionList;
    }

    @Deprecated
    public String getExtensionValue(String string) {
        List<Object> list = this.getExtensionList();
        if (list == null) {
            return null;
        }
        string = "." + string;
        for (Object object : list) {
            Field[] fieldArray = object.getClass().getDeclaredFields();
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray[n2];
                if (field.toString().endsWith(string)) {
                    try {
                        return new String((byte[])field.get(object));
                    }
                    catch (Exception exception) {
                        this.designAccesObjectFather.logger(2, "getExtensionValue() " + exception);
                    }
                }
                ++n2;
            }
        }
        return null;
    }

    public String getExtensionValueAsString(String string) {
        List<Object> list = this.getExtensionList();
        if (list == null) {
            return null;
        }
        string = "." + string;
        for (Object object : list) {
            Field[] fieldArray = object.getClass().getDeclaredFields();
            int n = fieldArray.length;
            int n2 = 0;
            while (n2 < n) {
                Field field = fieldArray[n2];
                if (field.toString().endsWith(string)) {
                    try {
                        return YP_Row.getStringValue(new String((byte[])field.get(object)));
                    }
                    catch (Exception exception) {
                        this.designAccesObjectFather.logger(2, "getExtensionValue() " + exception);
                    }
                }
                ++n2;
            }
        }
        return null;
    }
}

