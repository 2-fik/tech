/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.yp.designaccesobjects.YP_Gabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.utils.Bitmap;

public class YP_View {
    private final YP_Object father;
    private final List<String> rowID = new ArrayList<String>();
    private final List<Boolean> rowActionable = new ArrayList<Boolean>();
    private final List<List<YP_TCD_DC_Context.Action>> rowActionList = new ArrayList<List<YP_TCD_DC_Context.Action>>();
    private final Map<String, Column> columnList = new HashMap<String, Column>();

    public YP_View(YP_Object yP_Object) {
        this.father = yP_Object;
    }

    public int addColumn(String string, String string2, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, Field field, int n) {
        try {
            Column column = new Column(n, string2);
            YP_Row yP_Row = yP_TCD_DesignAccesObject.getNewRow();
            Object object = yP_Row.getFieldValue(field);
            if (object instanceof Timestamp) {
                column.setFormat("timestamp");
            } else if (object instanceof Date) {
                column.setFormat("date");
            } else if (object instanceof Integer) {
                column.setFormat("decimal");
            } else if (object instanceof Long) {
                column.setFormat("decimal");
            } else if (object instanceof byte[]) {
                column.setFormat("string");
                int n2 = ((byte[])object).length;
                column.getProperties().put("size", Integer.toString(n2));
            } else if (object instanceof Float) {
                column.setFormat("float");
            } else if (object instanceof Boolean) {
                column.setFormat("enum");
            } else if (object instanceof Enum) {
                column.setFormat("enum");
            } else if (object == null) {
                Class<?> clazz = field.getType();
                if (clazz == Boolean.class) {
                    column.setFormat("enum");
                } else if (clazz == Bitmap.class) {
                    column.setFormat("bitmap");
                } else if (clazz.isEnum()) {
                    column.setFormat("enum");
                } else {
                    column.setFormat("unknown");
                }
            } else {
                column.setFormat("unknown");
            }
            this.columnList.put(string, column);
            return 1;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    public int addCustomColumn(String string, String string2, String string3, int n) {
        try {
            Column column = new Column(n, string2);
            column.setFormat(string3);
            this.columnList.put(string, column);
            return 1;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    public int addCustomColumn(String string, String string2, String string3, int n, boolean bl) {
        try {
            Column column = new Column(n, string2);
            column.setFormat(string3);
            column.setOnlyIfNotNull(bl);
            this.columnList.put(string, column);
            return 1;
        }
        catch (Exception exception) {
            return -1;
        }
    }

    public String getColumnFormat(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        return column.format;
    }

    public int addFieldValue(int n, String string, String string2) {
        Column column = this.columnList.get(string);
        if (column == null) {
            if (this.father != null) {
                this.father.logger(2, "addFieldValue() unknown column:" + string);
            }
            return -1;
        }
        column.add(n, string2);
        return 1;
    }

    public boolean isColumnOnlyIfNotNull(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return false;
        }
        return column.onlyIfNotNull;
    }

    public int size() {
        return this.rowID.size();
    }

    public Set<String> getColumnSet() {
        return this.columnList.keySet();
    }

    /*
     * Unable to fully structure code
     */
    public void setRowID(int var1_1, String var2_2) {
        block1: {
            if (var1_1 != this.rowID.size()) ** GOTO lbl7
            this.rowID.add(var2_2);
            break block1;
lbl-1000:
            // 1 sources

            {
                this.rowID.add(null);
lbl7:
                // 2 sources

                ** while (var1_1 >= this.rowID.size())
            }
lbl8:
            // 1 sources

            this.rowID.set(var1_1, var2_2);
        }
    }

    public String getRowIDAt(int n) {
        return this.rowID.get(n);
    }

    /*
     * Unable to fully structure code
     */
    public void setRowActionable(int var1_1, boolean var2_2) {
        block1: {
            if (var1_1 != this.rowActionable.size()) ** GOTO lbl7
            this.rowActionable.add(var2_2);
            break block1;
lbl-1000:
            // 1 sources

            {
                this.rowActionable.add(null);
lbl7:
                // 2 sources

                ** while (var1_1 >= this.rowActionable.size())
            }
lbl8:
            // 1 sources

            this.rowActionable.set(var1_1, var2_2);
        }
    }

    public boolean isRowActionableAt(int n) {
        if (n >= this.rowActionable.size()) {
            return false;
        }
        return this.rowActionable.get(n);
    }

    /*
     * Unable to fully structure code
     */
    public void setRowActionList(int var1_1, List<YP_TCD_DC_Context.Action> var2_2) {
        block1: {
            if (var1_1 != this.rowActionList.size()) ** GOTO lbl7
            this.rowActionList.add(var2_2);
            break block1;
lbl-1000:
            // 1 sources

            {
                this.rowActionList.add(null);
lbl7:
                // 2 sources

                ** while (var1_1 >= this.rowActionList.size())
            }
lbl8:
            // 1 sources

            this.rowActionList.set(var1_1, var2_2);
        }
    }

    public List<YP_TCD_DC_Context.Action> getRowActionList(int n) {
        if (n >= this.rowActionList.size()) {
            return null;
        }
        return this.rowActionList.get(n);
    }

    public String getFieldValueAt(int n, String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        if (column.valueList.size() <= n) {
            return null;
        }
        return (String)column.valueList.get(n);
    }

    public String getColumnLabel(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        return column.getLabel();
    }

    public int getColumnRank(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return -1;
        }
        return column.rank;
    }

    public int setColumnRank(String string, int n) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return -1;
        }
        column.rank = n;
        return 1;
    }

    public Map<String, String> getColumnProperties(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        return column.properties;
    }

    public int setColumnProperties(String string, Map<String, String> map) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return -1;
        }
        column.properties = map;
        return 1;
    }

    public Map<String, String> getEnumMap(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        return column.enumMap;
    }

    public Map<String, Object> getEnumMapInversed(String string) {
        Column column = this.columnList.get(string);
        if (column == null) {
            return null;
        }
        return column.enumMapInversed;
    }

    public void dealEnumColumn(YP_Gabarit yP_Gabarit) {
        String string = this.getColumnFormat(yP_Gabarit.fieldName);
        if (string != null && string.contentEquals("enum")) {
            if (yP_Gabarit.objectTosearch instanceof Object[]) {
                Object[] objectArray = new Object[((Object[])yP_Gabarit.objectTosearch).length];
                int n = 0;
                while (n < ((Object[])yP_Gabarit.objectTosearch).length) {
                    Object object = this.getEnumMapInversed(yP_Gabarit.fieldName).get(((Object[])yP_Gabarit.objectTosearch)[n]);
                    if (object == null) {
                        Map<String, String> map = this.getEnumMap(yP_Gabarit.fieldName);
                        if (map != null && map.get(((Object[])yP_Gabarit.objectTosearch)[n]) != null) {
                            object = ((Object[])yP_Gabarit.objectTosearch)[n];
                        } else {
                            this.father.logger(2, "dealEnumColumn() unknown enum value" + ((Object[])yP_Gabarit.objectTosearch)[n]);
                            yP_Gabarit.objectTosearch = null;
                            break;
                        }
                    }
                    objectArray[n] = object;
                    ++n;
                }
                yP_Gabarit.objectTosearch = objectArray;
            } else {
                Object object = this.getEnumMapInversed(yP_Gabarit.fieldName).get(yP_Gabarit.objectTosearch);
                if (object != null) {
                    yP_Gabarit.objectTosearch = object;
                } else {
                    Map<String, String> map = this.getEnumMap(yP_Gabarit.fieldName);
                    if (map == null || map.get(yP_Gabarit.objectTosearch) == null) {
                        this.father.logger(2, "dealEnumColumn() unknown enum value" + yP_Gabarit.objectTosearch);
                        return;
                    }
                }
            }
        }
    }

    class Column {
        private boolean onlyIfNotNull = false;
        private String format;
        private int rank = -1;
        private Map<String, String> properties = new HashMap<String, String>();
        private Map<String, String> enumMap = new HashMap<String, String>();
        private Map<String, Object> enumMapInversed = new HashMap<String, Object>();
        private final List<String> valueList = new ArrayList<String>();
        private final String label;

        Column(int n, String string) throws Exception {
            this.rank = n;
            this.label = string;
        }

        public void setOnlyIfNotNull(boolean bl) {
            this.onlyIfNotNull = bl;
        }

        /*
         * Unable to fully structure code
         */
        public void add(int var1_1, String var2_2) {
            block1: {
                if (var1_1 != this.valueList.size()) ** GOTO lbl7
                this.valueList.add(var2_2);
                break block1;
lbl-1000:
                // 1 sources

                {
                    this.valueList.add(null);
lbl7:
                    // 2 sources

                    ** while (var1_1 >= this.valueList.size())
                }
lbl8:
                // 1 sources

                this.valueList.set(var1_1, var2_2);
            }
        }

        public String getLabel() {
            return this.label;
        }

        public Map<String, String> getProperties() {
            return this.properties;
        }

        public void setFormat(String string) {
            this.format = string;
        }
    }
}

