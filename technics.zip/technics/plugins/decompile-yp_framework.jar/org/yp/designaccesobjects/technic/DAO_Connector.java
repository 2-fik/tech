/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Connector
extends YP_Row {
    @PrimaryKey
    public long idConnector = 0L;
    public int connectorType = 0;
    public Boolean checkForEvent;
    public int siteIdentifier = 0;
    public byte[] DBC_Path = new byte[120];
    public byte[] DBC_Properties = new byte[256];
    public byte[] DBC_User = new byte[120];
    public byte[] DBC_Password = new byte[64];
    public byte[] connector_Plugin = new byte[120];
    public byte[] sql_Plugin = new byte[120];
}

