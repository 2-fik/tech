/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_TerminalConfig;

public final class DAO_TerminalReference
extends YP_Row {
    @PrimaryKey
    public long idTerminalReference = 0L;
    public byte[] terminalManufacturerID = new byte[32];
    public byte[] model = new byte[32];
    public byte[] appCBTerminalVersion = new byte[12];
    public int modelNumber = 0;
    public byte[] alias = new byte[50];
    public byte[] iccReaderHardwareVersion = new byte[4];
    public byte[] iccReaderSoftwareVersion = new byte[4];
    public byte[] iccReaderSpecificationVersion = new byte[4];
    public int nbOfISOReader = 0;
    public int nbOfICCReader = 0;
    public int nbOfContactlessReader = 0;
    public int nbOfSAMReader = 0;
    public int isCaptureCardCapability = 0;
    public Boolean mposDevice;
    @ForeignKey(name=DAO_TerminalConfig.class, column="idTerminalConfig")
    public long idDefaultConfig = 0L;
    @ForeignKey(name=DAO_TerminalConfig.class, column="idTerminalConfig")
    public long idDefaultConfigForTest = 0L;
    public byte[] pciPtsVersion = new byte[4];
    public Boolean unattendedDevice;
}

