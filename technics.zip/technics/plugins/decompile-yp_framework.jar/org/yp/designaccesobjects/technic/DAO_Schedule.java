/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Schedule
extends YP_Row {
    @PrimaryKey
    public long idSchedule = 0L;
    @Index
    public Timestamp scheduleSystemGMTTime = new Timestamp(0L);
    public byte[] applicationIdentifier = new byte[120];
    public byte[] pluginName = new byte[120];
    public byte[] scheduleName = new byte[20];
    public byte[] scheduleType = new byte[20];
    public byte[] referenceDate = new byte[8];
    public byte[] referenceTime = new byte[14];
    public int aleaInSec = 0;
    public byte[] frequencyInYYMMWWDDHHMMSS = new byte[14];
    public int delayInterCallInSec = 0;
    public int currentTry = 0;
    public int maxTries = 0;
    public long lastProcessID = 0L;
    public byte[] requestXML = new byte[2000];
}

