/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Application
extends YP_Row {
    @PrimaryKey
    public long idApplication = 0L;
    @Index
    public byte[] application_Plugin = new byte[120];
    public byte[] applicationName = new byte[32];
    public byte[] applicationLabel = new byte[120];
    public int satisfactionIndex = 0;
    public Boolean isObsolete;
    public long idBrand = 0L;
    public long idMerchant = 0L;
    public byte[] providerAID = new byte[32];
    public byte[] applicationEnvironmentType = new byte[2];
    public byte[] manufacturerAID = new byte[12];
    public byte[] applicationProperties = new byte[1024];
    public byte[] pluginsRestriction = new byte[1024];
}

