/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_TerminalUpdate
extends YP_Row {
    @PrimaryKey
    public long idTerminalUpdate = 0L;
    public byte[] updateName = new byte[32];
    public byte[] fromVersion = new byte[32];
    public byte[] updateURL = new byte[128];
    public Boolean isMandatory;
}

