/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Group;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.designaccesobjects.technic.DAO_TerminalConfig;
import org.yp.utils.enums.TerminalConfigStatusEnumeration;

public final class DAO_TerminalConfigStatus
extends YP_Row {
    @PrimaryKey
    public long idTerminalConfigStatus = 0L;
    @ForeignKey(name=DAO_TerminalConfig.class)
    public long idTerminalConfig = 0L;
    public TerminalConfigStatusEnumeration status;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
}

