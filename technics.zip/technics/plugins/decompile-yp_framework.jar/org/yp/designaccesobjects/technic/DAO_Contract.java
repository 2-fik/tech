/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Application;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.utils.enums.InitializationStatusEnumeration;

public class DAO_Contract
extends YP_Row {
    @PrimaryKey
    public long idContract = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Application.class)
    public long idApplication = 0L;
    public int applicationIndex = 0;
    public int satisfactionIndex = 0;
    public int connectorType = 0;
    public byte[] activationCode = new byte[1];
    public InitializationStatusEnumeration initializationStatus;
    public byte[] contractLabel = new byte[50];
    public byte[] timeZone = new byte[50];
    public byte[] detailedStatus = new byte[40];
}

