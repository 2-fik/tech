/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Acquirer
extends YP_Row {
    @PrimaryKey
    public long idAcquirer = 0L;
    public byte[] acquirerID = new byte[11];
    public byte[] acquirerShortName = new byte[16];
    public byte[] acquirerName = new byte[48];
    public byte[] bin3DMastercard = new byte[6];
    public byte[] bin3DVisa = new byte[6];
}

