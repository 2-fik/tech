/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.event;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Identity;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ManagementEvent
extends YP_Row {
    @PrimaryKey
    @Identity
    public long idManagementEvent = 0L;
    public byte[] DB_Name = new byte[120];
    public byte[] DB_Table = new byte[120];
    @Index
    public Timestamp timestamp = new Timestamp(0L);
    public byte[] user = new byte[120];
    public long primaryKeyValue = 0L;
    public byte[] changeType = new byte[120];
}

