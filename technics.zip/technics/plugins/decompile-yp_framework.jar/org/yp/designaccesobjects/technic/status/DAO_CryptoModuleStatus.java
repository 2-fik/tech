/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.crypto.designaccesobjects.DAO_CryptoModule;

public class DAO_CryptoModuleStatus
extends YP_Row {
    @PrimaryKey
    public long idCryptoModuleStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @ForeignKey(name=DAO_CryptoModule.class)
    public long idCryptoModule = 0L;
    public byte[] algoName = new byte[20];
    public Timestamp lastOKSystemLocalTime = new Timestamp(0L);
    public int nbOK = 0;
    public int minConnectionTimeOK = 0;
    public int maxConnectionTimeOK = 0;
    public int averageConnectionTimeOK = 0;
    public int minProcessingTimeOK = 0;
    public int maxProcessingTimeOK = 0;
    public int averageProcessingTimeOK = 0;
    public Timestamp lastKOSystemLocalTime = new Timestamp(0L);
    public int nbKO = 0;
    public int minConnectionTimeKO = 0;
    public int maxConnectionTimeKO = 0;
    public int averageConnectionTimeKO = 0;
    public int minProcessingTimeKO = 0;
    public int maxProcessingTimeKO = 0;
    public int averageProcessingTimeKO = 0;
    public long sumConnectionTimeOK = 0L;
    public long sumProcessingTimeOK = 0L;
    public long sumConnectionTimeKO = 0L;
    public long sumProcessingTimeKO = 0L;
}

