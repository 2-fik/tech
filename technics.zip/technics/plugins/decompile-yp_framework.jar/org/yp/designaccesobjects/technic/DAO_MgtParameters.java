/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Contract;
import org.yp.designaccesobjects.technic.DAO_Group;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;

public class DAO_MgtParameters
extends YP_Row {
    @PrimaryKey
    public long idMgtParameters = 0L;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Contract.class)
    public long idContract = 0L;
    @ForeignKey(name=DAO_User.class)
    public long idUser = 0L;
    public Boolean modificationAllowed;
    public Boolean secret;
    public byte[] key = new byte[32];
    public byte[] value = new byte[256];
    @ForeignKey(name=DAO_Store.class)
    public long idStore = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
}

