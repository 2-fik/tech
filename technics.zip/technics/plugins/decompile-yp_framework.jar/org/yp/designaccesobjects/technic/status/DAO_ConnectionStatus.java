/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Connection;

public class DAO_ConnectionStatus
extends YP_Row {
    @PrimaryKey
    public long idConnectionStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @ForeignKey(name=DAO_Connection.class)
    public long idConnection = 0L;
    public Timestamp lastOKSystemLocalTime = new Timestamp(0L);
    public int nbOK = 0;
    public int minTimeOK = 0;
    public int maxTimeOK = 0;
    public int averageTimeOK = 0;
    public Timestamp lastKOSystemLocalTime = new Timestamp(0L);
    public int nbKO = 0;
    public int minTimeKO = 0;
    public int maxTimeKO = 0;
    public int averageTimeKO = 0;
    public int nbConnectBroken = 0;
    public int nbConnectTimeout = 0;
    public int nbConnectProtocol = 0;
    public int nbReceiveBroken = 0;
    public int nbReceiveTimeout = 0;
}

