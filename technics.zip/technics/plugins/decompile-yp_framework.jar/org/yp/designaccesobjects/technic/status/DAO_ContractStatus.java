/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Contract;

public class DAO_ContractStatus
extends YP_Row {
    @PrimaryKey
    public long idContractStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @ForeignKey(name=DAO_Contract.class)
    public long idContract = 0L;
    public int nbTransaction = 0;
    public int nbAuthorisation = 0;
    public float avgTransactionTime = 0.0f;
    public float avgAuthorisationTime = 0.0f;
}

