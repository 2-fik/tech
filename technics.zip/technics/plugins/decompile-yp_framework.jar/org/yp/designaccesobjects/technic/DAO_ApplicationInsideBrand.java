/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Application;
import org.yp.designaccesobjects.technic.DAO_Brand;

public class DAO_ApplicationInsideBrand
extends YP_Row {
    @PrimaryKey
    public long idApplicationInsideBrand = 0L;
    @ForeignKey(name=DAO_Application.class)
    public long idApplication = 0L;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
}

