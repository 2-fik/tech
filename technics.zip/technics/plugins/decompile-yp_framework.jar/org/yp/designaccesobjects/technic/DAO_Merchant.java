/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;

public class DAO_Merchant
extends YP_Row {
    @PrimaryKey
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    public byte[] merchantName = new byte[32];
    public byte[] merchantLabel = new byte[120];
    public byte[] address = new byte[120];
    public byte[] mailAddress = new byte[250];
    public float latitude = 0.0f;
    public float longitude = 0.0f;
    public int terminalCountInfo = 0;
    public int terminalCountCalculated = 0;
    public Timestamp creationGMTTime = new Timestamp(0L);
    public Timestamp lastModificationGMTTime = new Timestamp(0L);
    public byte[] detailedStatus = new byte[64];
    public byte[] timeZone = new byte[50];
    public byte[] merchantURL = new byte[250];
}

