/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ServiceStatus
extends YP_Row {
    @PrimaryKey
    public long idServiceStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @Index
    public byte[] serviceName = new byte[120];
    public byte[] preferredName = new byte[120];
    public int instanceID = 0;
    public int status = 0;
    public int currentChildNB = 0;
    public int peakChildNB = 0;
    public int maximumChildNB = 0;
    public Timestamp lastTop = new Timestamp(0L);
    public int peakChildDayNB = 0;
}

