/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Connection
extends YP_Row {
    @PrimaryKey
    public long idConnection = 0L;
    public byte[] description = new byte[120];
    public byte[] serviceRequested = new byte[15];
    public byte[] adresseIP = new byte[64];
    public byte[] port = new byte[32];
    public byte[] ert = new byte[2];
    public byte[] ressource = new byte[200];
    public byte[] pluginName = new byte[120];
    public byte[] firstLevelPlugin = new byte[120];
    public byte[] secondLevelPlugin = new byte[120];
    public int connectionTimeoutMS = 0;
    public int tnrMS = 0;
    public int tsiMS = 0;
    public int tmaMS = 0;
    public int lengthLengthPrefix = 0;
    public int isAscii = 0;
    public byte[] protocolIdentifier = new byte[8];
    public int tlcAckWindow;
    public int tlpAckWindow;
    public int tailleMaxMessage;
    public byte[] trustStorePath = new byte[120];
    public byte[] trustStorePasswd = new byte[32];
    public byte[] keyStorePath = new byte[120];
    public byte[] keyStorePasswd = new byte[32];
    public byte[] keyAlias = new byte[32];
    public byte[] enabledCipherSuites = new byte[512];
    public byte[] enabledProtocols = new byte[128];
    public byte[] authentificationNeeded = new byte[1];
    public byte[] sessionTimeOut = new byte[7];
    public byte[] proxyType = new byte[8];
    public byte[] proxyHost = new byte[32];
    public int proxyPort = 0;
}

