/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;

public class DAO_UserStatus
extends YP_Row {
    @PrimaryKey
    public long idUserStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @ForeignKey(name=DAO_User.class)
    public long idUser = 0L;
    public Timestamp lastPasswordConnection = new Timestamp(0L);
    public int nbPasswordConnection = 0;
    public Timestamp lastTokenConnection = new Timestamp(0L);
    public int nbTokenConnection = 0;
    public Timestamp lastFailedConnection = new Timestamp(0L);
    public int nbFailedConnection = 0;
    public Timestamp lastPermanentTokenConnection = new Timestamp(0L);
    public int nbPermanentTokenConnection = 0;
}

