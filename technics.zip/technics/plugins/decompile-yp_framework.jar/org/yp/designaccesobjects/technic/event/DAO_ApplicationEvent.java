/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.event;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ApplicationEvent
extends YP_Row {
    @Index
    public byte[] DB_Name = new byte[120];
    @Index
    public byte[] DB_Table = new byte[120];
}

