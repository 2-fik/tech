/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Group;

public class DAO_BrandInsideGroup
extends YP_Row {
    @PrimaryKey
    public long idBrandInsideStore = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
}

