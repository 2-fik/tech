/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Brand
extends YP_Row {
    @PrimaryKey
    public long idBrand = 0L;
    public byte[] brandName = new byte[32];
    public byte[] brandLabel = new byte[120];
    public int connectorType = 0;
}

