/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_PluginStatus
extends YP_Row {
    @PrimaryKey
    public long idPluginStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    @Index
    public byte[] pluginName = new byte[120];
    public byte[] preferredName = new byte[120];
    public byte[] propertiesFileName = new byte[120];
    public byte[] version = new byte[32];
    public int instanceID = 0;
    public int status = 0;
    public int cptCreation = 0;
    public int cptCurrent = 0;
    public int cptMax = 0;
    public Timestamp lastCreation = new Timestamp(0L);
}

