/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Group
extends YP_Row {
    @PrimaryKey
    public long idGroup = 0L;
    public byte[] groupName = new byte[32];
    public byte[] groupLabel = new byte[120];
}

