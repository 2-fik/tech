/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Group;
import org.yp.designaccesobjects.technic.DAO_Merchant;

public final class DAO_Image
extends YP_Row {
    @PrimaryKey
    public long idImage = 0L;
    public byte[] model = new byte[30];
    public byte[] version = new byte[30];
    public byte[] url = new byte[128];
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
}

