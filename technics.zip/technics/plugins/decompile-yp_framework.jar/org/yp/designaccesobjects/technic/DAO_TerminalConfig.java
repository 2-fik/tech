/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Brand;
import org.yp.designaccesobjects.technic.DAO_Group;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.designaccesobjects.technic.DAO_TerminalReference;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;

public final class DAO_TerminalConfig
extends YP_Row {
    @PrimaryKey
    public long idTerminalConfig = 0L;
    public byte[] configName = new byte[30];
    @ForeignKey(name=DAO_TerminalReference.class)
    public long idTerminalReference = 0L;
    public int updateMode = 0;
    public byte[] screenSaverName = new byte[32];
    public byte[] screenSaverURL = new byte[128];
    public byte[] biosVersion = new byte[32];
    public byte[] biosURL = new byte[128];
    public byte[] kernelVersion = new byte[16];
    public byte[] kernelURL = new byte[128];
    public byte[] level2ICCVersion = new byte[16];
    public byte[] level2ICCURL = new byte[128];
    public byte[] level2CTLVersion = new byte[12];
    public byte[] level2CTLURL = new byte[128];
    public byte[] appHandlerTerminalVersion = new byte[12];
    public byte[] appHandlerTerminalURL = new byte[128];
    public byte[] appCBTerminalVersion = new byte[12];
    public byte[] appCBTerminalURL = new byte[128];
    public byte[] pinpadScreenSaverName = new byte[32];
    public byte[] pinpadScreenSaverURL = new byte[128];
    public Boolean testVersion;
    @ForeignKey(name=DAO_Brand.class)
    public long idBrand = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_User.class)
    public long idUser = 0L;
    @ForeignKey(name=DAO_Group.class)
    public long idGroup = 0L;
    public byte[] pinpadVersion = new byte[32];
    public byte[] pinpadURL = new byte[128];
}

