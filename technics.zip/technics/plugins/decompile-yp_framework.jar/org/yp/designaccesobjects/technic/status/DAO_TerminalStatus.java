/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.technic.status;

import java.sql.Date;
import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.designaccesobjects.technic.DAO_TerminalConfig;
import org.yp.designaccesobjects.technic.DAO_TerminalReference;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;

public class DAO_TerminalStatus
extends YP_Row {
    @PrimaryKey
    public long idTerminalStatus = 0L;
    public int instanceNumber = 0;
    @Index
    public Date date = new Date(0L);
    public TerminalStatusEnumeration terminalStatus;
    public byte[] terminalManufacturerID = new byte[16];
    @Index
    public byte[] terminalSerialNumber = new byte[32];
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Store.class)
    public long idStore = 0L;
    @Index
    public int nlpa = 0;
    @ForeignKey(name=DAO_TerminalReference.class)
    public long idTerminalReference = 0L;
    @ForeignKey(name=DAO_TerminalConfig.class)
    public long idTerminalConfig = 0L;
    public byte[] alias = new byte[50];
    public Timestamp firstGMTTime = new Timestamp(0L);
    public Timestamp lastGMTTime = new Timestamp(0L);
    public byte[] biosManufacturerID = new byte[16];
    public byte[] biosVersion = new byte[32];
    public byte[] biosCKSUM = new byte[4];
    public byte[] kernelManufacturerID = new byte[16];
    public byte[] kernelVersion = new byte[16];
    public byte[] kernelCKSUM = new byte[4];
    public byte[] level2ICCManufacturerID = new byte[16];
    public byte[] level2ICCVersion = new byte[16];
    public byte[] level2ICCCKSUM = new byte[4];
    public byte[] level2CTLManufacturerID = new byte[16];
    public byte[] level2CTLVersion = new byte[12];
    public byte[] level2CTLCKSUM = new byte[4];
    public byte[] appHandlerManufacturerID = new byte[16];
    public byte[] appHandlerTerminalVersion = new byte[12];
    public byte[] appHandlerTerminalCKSUM = new byte[4];
    public byte[] appCBManufacturerID = new byte[16];
    public byte[] appCBTerminalVersion = new byte[12];
    public byte[] appCBTerminalCKSUM = new byte[4];
    public byte[] screenSaverName = new byte[32];
    public int flashCapacity = 0;
    public int flashRemainingCapacity = 0;
    public int ramCapacity = 0;
    public int ramRemainingCapacity = 0;
    public byte[] autoLoginHHMMSS = new byte[6];
    public int updateMode = 0;
}

