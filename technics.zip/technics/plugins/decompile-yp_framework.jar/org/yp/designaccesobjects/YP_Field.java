/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sun.reflect.FieldAccessor
 *  sun.reflect.ReflectionFactory$GetReflectionFactoryAction
 */
package org.yp.designaccesobjects;

import java.lang.reflect.Field;
import java.security.AccessController;
import sun.reflect.FieldAccessor;
import sun.reflect.ReflectionFactory;

public class YP_Field {
    static final ReflectionFactory reflectionFactory = (ReflectionFactory)AccessController.doPrivileged(new ReflectionFactory.GetReflectionFactoryAction());
    public final FieldAccessor fieldAccessor;
    public final Field field;

    public YP_Field(Field field) {
        this.field = field;
        this.fieldAccessor = reflectionFactory.newFieldAccessor(field, false);
    }
}

