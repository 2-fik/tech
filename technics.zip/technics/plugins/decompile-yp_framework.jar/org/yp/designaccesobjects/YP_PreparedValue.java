/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

public class YP_PreparedValue {
    public Object value;
    public int type;

    public YP_PreparedValue(Object object, int n) {
        this.value = object;
        this.type = n;
    }
}

