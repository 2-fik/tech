/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.eft;

public class DAO_EFT_Reservation {
    public byte[] numDossier = new byte[50];
}

