/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.yp.designaccesobjects.YP_Row;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.FIELD})
public @interface ForeignKey {
    public Class<? extends YP_Row> name();

    public String column() default "";
}

