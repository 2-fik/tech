/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.lang.reflect.Field;
import org.yp.designaccesobjects.YP_ComplexGabarit;

public final class YP_Gabarit {
    public YP_ComplexGabarit.OPERATOR operator;
    public YP_ComplexGabarit.OPERATOR savedOperator = null;
    public Object objectTosearch;
    public final Field field;
    public final String fieldName;
    public String fullTableName = null;

    public YP_Gabarit(Field field, YP_ComplexGabarit.OPERATOR oPERATOR, Object object) {
        Object[] objectArray;
        this.objectTosearch = oPERATOR == YP_ComplexGabarit.OPERATOR.IN && !(object instanceof Object[]) ? (objectArray = new Object[]{object}) : object;
        this.field = field;
        this.fieldName = field != null ? field.getName() : null;
        this.operator = oPERATOR;
    }

    public YP_Gabarit(Field field, YP_ComplexGabarit.OPERATOR oPERATOR) {
        this(field, oPERATOR, null);
    }

    public YP_Gabarit(String string, YP_ComplexGabarit.OPERATOR oPERATOR, Object object) {
        Object[] objectArray;
        this.objectTosearch = oPERATOR == YP_ComplexGabarit.OPERATOR.IN && !(object instanceof Object[]) ? (objectArray = new Object[]{object}) : object;
        this.fieldName = string;
        this.field = null;
        this.operator = oPERATOR;
    }

    public YP_Gabarit(String string, YP_ComplexGabarit.OPERATOR oPERATOR) {
        this(string, oPERATOR, null);
    }
}

