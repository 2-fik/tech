/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects;

import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Messager;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.lang.model.element.Element;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;
import org.yp.designaccesobjects.PrimaryKey;

@SupportedAnnotationTypes(value={"*"})
public class AnnotationProcessor
extends AbstractProcessor {
    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        Messager messager = this.processingEnv.getMessager();
        for (TypeElement typeElement : set) {
            messager.printMessage(Diagnostic.Kind.NOTE, "Traitement annotation " + typeElement.getQualifiedName());
            for (Element element : roundEnvironment.getElementsAnnotatedWith(typeElement)) {
                messager.printMessage(Diagnostic.Kind.NOTE, "  Traitement element " + element.getSimpleName());
                PrimaryKey primaryKey = element.getAnnotation(PrimaryKey.class);
                if (primaryKey == null) continue;
                messager.printMessage(Diagnostic.Kind.NOTE, "  asqdqsd");
            }
        }
        return true;
    }
}

