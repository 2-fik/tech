/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_PDV;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;
import org.yp.utils.enums.sorec.TerminalTypeEnumeration;

@TableExtensionName(masterExtension="")
public final class DAO_Terminal
extends YP_Row {
    @PrimaryKey
    public long idTerminal = 0L;
    public long idTerminalCan = 0L;
    @ForeignKey(name=DAO_PDV.class)
    public long idPdv = 0L;
    public TerminalStatusEnumeration terminalStatus;
    public TerminalTypeEnumeration terminalType;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @ForeignKey(name=DAO_Store.class)
    public long idStore = 0L;
    public Timestamp firstGMTTime = new Timestamp(0L);
    @Index
    public Timestamp lastGMTTime = new Timestamp(0L);
    public byte[] detailedStatus = new byte[40];
    @Index
    public Timestamp statusModificationGMTTime = new Timestamp(0L);
    public Timestamp lastCoteGMTTime = new Timestamp(0L);
    public Timestamp lastRapportGMTTime = new Timestamp(0L);
    public Timestamp lastCommunicationGMTTime = new Timestamp(0L);
    public long idUser = 0L;
    public byte[] terminalIP = new byte[15];
    public byte[] authorizationAlloJeu = new byte[1];
    public byte[] authorizationPaymentGrosGain = new byte[1];
    public byte[] authoriszationTestProduction = new byte[1];
    public byte[] position = new byte[25];
    public Timestamp updateDate = new Timestamp(0L);
    public long authorizedVersion;
    public byte[] prepos = new byte[25];
    public byte[] codeAttributaire = new byte[25];
}

