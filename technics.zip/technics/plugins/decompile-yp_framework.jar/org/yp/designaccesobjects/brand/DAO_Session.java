/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.ReconciliationStatusEnumeration;
import org.yp.utils.enums.SessionStatusEnumeration;

public class DAO_Session
extends YP_Row {
    @PrimaryKey
    public long idSession = 0L;
    @Index
    public byte[] applicationIdentifier = new byte[120];
    @Index
    public int sessionNumber = 0;
    @Index
    public byte[] processorIdentifier = new byte[20];
    public SessionStatusEnumeration status;
    public ReconciliationStatusEnumeration reconciliationStatus;
    public byte[] applicationName = new byte[120];
    @Index
    public long sessionSystemGMTTimeMS = 0L;
    public Timestamp sessionAppliLocalTime = new Timestamp(0L);
    public Timestamp firstTransactionAppliLocalTime = new Timestamp(0L);
    public Timestamp lastTransactionAppliLocalTime = new Timestamp(0L);
    public int lastAckMessage = 0;
    public boolean isAutomatic;
    public long idUser = 0L;
    public byte[] ticketHeader = new byte[50];
    public byte[] ticketFooter = new byte[50];
    public byte[] merchantContract = new byte[20];
    public byte[] acquiringInstitutionIdentificationCode = new byte[11];
    public byte[] commercialRegisterNumber = new byte[14];
    public byte[] merchantCategoryCode = new byte[4];
    public byte[] applicationEnvironmentType = new byte[2];
    public byte[] siteType = new byte[8];
    public byte[] terminalIdentification = new byte[20];
    public byte[] providerAID = new byte[32];
    public byte[] sequenceNumber = new byte[6];
    public byte[] currencyAlphabeticalCode = new byte[3];
    public int currencyNumericalCode = 0;
    public int currencyFraction = 0;
    public int nbTRS = 0;
    public int nbDebit = 0;
    public long totalAmountDebit = 0L;
    public int nbDebitDiffered = 0;
    public long totalAmountDebitDiffered = 0L;
    public int nbDebitOnline = 0;
    public long totalAmountDebitOnline = 0L;
    public int nbDebitDifferedOnline = 0;
    public long totalAmountDebitDifferedOnline = 0L;
    public int nbDebitOffline = 0;
    public long totalAmountDebitOffline = 0L;
    public int nbDebitDifferedOffline = 0;
    public long totalAmountDebitDifferedOffline = 0L;
    public int nbRefund = 0;
    public long totalAmountRefund = 0L;
    public int nbReversalDebit = 0;
    public long totalAmountReversalDebit = 0L;
    public int nbReversalDebitOnline = 0;
    public long totalAmountReversalDebitOnline = 0L;
    public int nbReversalDebitOffline = 0;
    public long totalAmountReversalDebitOffline = 0L;
    public int nbReversalRefund = 0;
    public long totalAmountReversalRefund = 0L;
    public int nbDebitAbandonned = 0;
    public int nbCASH_ADVANCE = 0;
    public long totalAmountCASH_ADVANCE = 0L;
    public int nbQUASI_CASH = 0;
    public long totalAmountQUASI_CASH = 0L;
    public int nbINITIAL_RESERVATION = 0;
    public long totalAmountINITIAL_RESERVATION = 0L;
    public int nbADDITIONAL_RESERVATION = 0;
    public long totalAmountADDITIONAL_RESERVATION = 0L;
    public int nbONE_TIME_RESERVATION = 0;
    public long totalAmountONE_TIME_RESERVATION = 0L;
    public int nbCLOSING_PAYMENT = 0;
    public long totalAmountCLOSING_PAYMENT = 0L;
    public int nbVOID_CLOSING_PAYMENT = 0;
    public int nbCOMPLEMENTARY_PAYMENT = 0;
    public long totalAmountCOMPLEMENTARY_PAYMENT = 0L;
    public byte[] printResponse = new byte[256];
    public int nbCOMPLEMENTARY_REFUND = 0;
    public long totalAmountCOMPLEMENTARY_REFUND = 0L;
    public byte[] nlsa = new byte[10];
    public byte[] idsa = new byte[10];
    public byte[] manufacturerAID = new byte[20];
    public byte[] cardAcceptorIdentificationCode = new byte[20];
    public byte[] countryCode = new byte[3];
    public long fileSequenceNumber = 0L;
    @Index
    public long idContract = 0L;
}

