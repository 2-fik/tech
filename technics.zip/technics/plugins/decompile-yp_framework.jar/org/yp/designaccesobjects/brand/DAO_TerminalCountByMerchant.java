/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public final class DAO_TerminalCountByMerchant
extends YP_Row {
    public long idMerchant = 0L;
    public int nbTerminals;
}

