/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ReceptionTicketPayable_GetPari
extends YP_Row {
    @PrimaryKey
    public long idPari = 0L;
    public byte[] numTicket = new byte[8];
}

