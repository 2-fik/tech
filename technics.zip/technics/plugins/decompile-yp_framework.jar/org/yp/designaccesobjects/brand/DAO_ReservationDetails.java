/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.ReservationStatusEnumeration;

public final class DAO_ReservationDetails
extends YP_Row {
    @PrimaryKey
    public long idReservationDetails = 0L;
    @Index(tableType=65535)
    public byte[] reservationReference = new byte[12];
    public ReservationStatusEnumeration status;
    @Index(tableType=65535)
    public Timestamp appliLocalTime = new Timestamp(0L);
    public byte[] contractIdentifier = new byte[120];
    public byte[] merchantName = new byte[40];
    public byte[] applicationName = new byte[40];
    public int applicationInstance = 0;
    public long idTransaction = 0L;
    @Index(tableType=65535)
    public byte[] merchantTransactionIdentifier = new byte[20];
}

