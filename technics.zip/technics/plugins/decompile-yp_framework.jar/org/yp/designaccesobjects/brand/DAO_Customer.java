/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_Customer
extends YP_Row {
    @PrimaryKey
    public long idCustomer = 0L;
    public int status = 0;
    @Index
    public byte[] merchantIdentifier = new byte[50];
    public byte[] name = new byte[50];
    public byte[] mailAddress = new byte[250];
    public byte[] ipAddress = new byte[32];
}

