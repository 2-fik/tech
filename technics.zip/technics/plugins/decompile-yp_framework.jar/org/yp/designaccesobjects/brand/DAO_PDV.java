/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Agence;
import org.yp.designaccesobjects.brand.DAO_Ville;
import org.yp.utils.enums.sorec.PDVStatusEnumeration;
import org.yp.utils.enums.sorec.PDVTypeEnumeration;

@TableExtensionName(masterExtension="")
public final class DAO_PDV
extends YP_Row {
    @PrimaryKey
    public long idPdv = 0L;
    public byte[] referencePDV = new byte[50];
    public PDVStatusEnumeration pdvStatus;
    public byte[] designation = new byte[40];
    public int numeroPDV = 0;
    public byte[] codePDV = new byte[255];
    @ForeignKey(name=DAO_Agence.class)
    public long idAgence = 0L;
    @ForeignKey(name=DAO_Ville.class)
    public long idVille = 0L;
    @Index
    public Timestamp statusModificationGMTTime = new Timestamp(0L);
    public PDVTypeEnumeration modePaymentPdv;
    public long soldePdv = 0L;
    public long plafondPdv = 0L;
    public long cumulPDV = 0L;
    public long typePdvId = 0L;
}

