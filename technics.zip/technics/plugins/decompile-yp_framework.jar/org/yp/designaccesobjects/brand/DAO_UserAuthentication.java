/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_UserAuthentication
extends YP_Row {
    @PrimaryKey
    public long idUserAuthentication = 0L;
    @Index
    public byte[] login = new byte[64];
    public byte[] hashedPassword = new byte[250];
    public byte[] hashedPassword1 = new byte[250];
    public byte[] hashedPassword2 = new byte[250];
    public byte[] hashedPassword3 = new byte[250];
    public Timestamp startValidityGMTTime = new Timestamp(0L);
    public Timestamp endValidityGMTTime = new Timestamp(0L);
}

