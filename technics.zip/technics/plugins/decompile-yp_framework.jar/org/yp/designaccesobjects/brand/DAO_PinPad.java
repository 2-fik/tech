/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_PinPad
extends YP_Row {
    @PrimaryKey
    public long idPinPad = 0L;
    public byte[] pinPadID = new byte[50];
    public byte[] biosPinPadVersion = new byte[20];
}

