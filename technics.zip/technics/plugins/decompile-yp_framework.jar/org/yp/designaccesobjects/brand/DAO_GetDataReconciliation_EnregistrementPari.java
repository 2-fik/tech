/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public class DAO_GetDataReconciliation_EnregistrementPari
extends YP_Row {
    public long nbTickets;
    public long nbFormulations = 0L;
    public long enjeux = 0L;
}

