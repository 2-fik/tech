/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Store;
import org.yp.designaccesobjects.technic.DAO_Contract;

public final class DAO_ContractInsideStore
extends YP_Row {
    @PrimaryKey
    public long idContractInsideStore = 0L;
    @ForeignKey(name=DAO_Store.class)
    public long idStore = 0L;
    @ForeignKey(name=DAO_Contract.class)
    public long idContract = 0L;
}

