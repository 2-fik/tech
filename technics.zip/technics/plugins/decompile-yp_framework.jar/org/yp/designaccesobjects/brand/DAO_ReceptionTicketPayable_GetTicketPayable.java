/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.sorec.TicketStatusEnumeration;

public class DAO_ReceptionTicketPayable_GetTicketPayable
extends YP_Row {
    @PrimaryKey
    public long idTicketPayable = 0L;
    public byte[] numero = new byte[8];
    public TicketStatusEnumeration ticketStatus;
}

