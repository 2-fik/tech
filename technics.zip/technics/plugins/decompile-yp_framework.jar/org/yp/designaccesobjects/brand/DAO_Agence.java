/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.TableExtensionName;
import org.yp.designaccesobjects.YP_Row;

@TableExtensionName(masterExtension="")
public final class DAO_Agence
extends YP_Row {
    @PrimaryKey
    public long idAgence = 0L;
    public byte[] adresse = new byte[50];
    public byte[] code = new byte[10];
    public byte[] designation = new byte[50];
    public long id = 0L;
    public byte[] numero = new byte[20];
}

