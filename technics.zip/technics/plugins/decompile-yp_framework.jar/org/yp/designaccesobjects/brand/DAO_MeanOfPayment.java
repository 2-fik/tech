/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public final class DAO_MeanOfPayment
extends YP_Row {
    @PrimaryKey
    public long idMeanOfPayment = 0L;
    public int status = 0;
    @Index
    public long idToken = 0L;
    @Index
    public long idCustomer = 0L;
    public Timestamp firstSystemGMTTime = new Timestamp(0L);
    public Timestamp lastSystemGMTTime = new Timestamp(0L);
    public int nbTransaction = 0;
    public byte[] alias = new byte[50];
    public byte[] holderName = new byte[50];
    public Timestamp effectiveDate = new Timestamp(0L);
    public Timestamp expirationDate = new Timestamp(0L);
    public byte[] meanOfPaymentType = new byte[20];
    public byte[] sbanCountryCode = new byte[2];
    public byte[] sbanKey = new byte[2];
    public byte[] sbanBIC = new byte[11];
    public byte[] cardType = new byte[20];
    public byte[] cardSequenceNumber = new byte[3];
    public byte[] cardCVV = new byte[4];
    public Timestamp creationSystemGMTTime = new Timestamp(0L);
    public byte[] networkData = new byte[50];
    public Timestamp last3DSVerificationTime = new Timestamp(0L);
    public int nbDebit = 0;
    public long amountDebit = 0L;
    public int nbInitialReservation = 0;
    public long amountInitialReservation = 0L;
    public int nbClosingPayment = 0;
    public long amountClosingPayment = 0L;
    public int nbEmptyClosingPayment = 0;
    public int nbOther = 0;
    public int nbRefused = 0;
    public int nbAuthRefused = 0;
}

