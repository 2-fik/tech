/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Merchant;

public final class DAO_PointOfSale
extends YP_Row {
    @PrimaryKey
    public long idPointOfSale = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    @Index
    public int nlpa = 0;
    public byte[] alias = new byte[50];
    public Timestamp firstGMTTime = new Timestamp(0L);
    public Timestamp lastGMTTime = new Timestamp(0L);
    public int rotationNumber = 0;
}

