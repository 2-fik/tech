/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public class DAO_GetEtatCaisse
extends YP_Row {
    public int countPari;
    public byte[] totalPari = new byte[100];
    public int countAnnulation;
    public byte[] totalAnnulation = new byte[100];
    public int countAnnulationSysteme;
    public byte[] totalAnnulationSysteme = new byte[100];
    public int countAnnulationMachine;
    public byte[] totalAnnulationMachine = new byte[100];
    public int countPaiement;
    public byte[] totalPaiement = new byte[100];
    public int countVoucherDemande;
    public byte[] totalVoucherDemande = new byte[100];
    public int countVoucherPaiement;
    public byte[] totalVoucherPaiement = new byte[100];
    public int countAlimentation;
    public byte[] totalAlimentation = new byte[100];
}

