/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_ProprietaryParameter
extends YP_Row {
    @PrimaryKey
    public long idProprietaryParameter = 0L;
    @Index
    public byte[] merchantName = new byte[40];
    public byte[] applicationName = new byte[40];
    public int applicationInstance = 0;
    public byte[] parameter = new byte[32];
    public byte[] value = new byte[128];
}

