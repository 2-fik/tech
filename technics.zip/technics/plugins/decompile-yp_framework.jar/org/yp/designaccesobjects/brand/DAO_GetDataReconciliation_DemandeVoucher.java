/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public class DAO_GetDataReconciliation_DemandeVoucher
extends YP_Row {
    public long dVoucher;
    public float totalMontant = 0.0f;
}

