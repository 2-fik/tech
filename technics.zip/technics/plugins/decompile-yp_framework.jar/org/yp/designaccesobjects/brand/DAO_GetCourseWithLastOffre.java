/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.sorec.CourseStatusEnumeration;

public class DAO_GetCourseWithLastOffre
extends YP_Row {
    @PrimaryKey
    public long idCourse;
    public CourseStatusEnumeration statutCourse;
}

