/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public class DAO_Reporting_Count
extends YP_Row {
    public int totalCount = 0;
}

