/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;
import org.yp.utils.enums.sorec.ParticipantStatusEnumeration;

public class DAO_GetDataReconciliation_Participant
extends YP_Row {
    public ParticipantStatusEnumeration statutParticipant;
    public long nbParticipants = 0L;
}

