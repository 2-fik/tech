/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import java.sql.Timestamp;
import org.yp.designaccesobjects.ForeignKey;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.technic.DAO_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.extension.user.designaccesobjects.DAO_User;
import org.yp.utils.enums.StoreStatusEnumeration;

public final class DAO_Store
extends YP_Row {
    @PrimaryKey
    public long idStore = 0L;
    @ForeignKey(name=DAO_Merchant.class)
    public long idMerchant = 0L;
    public byte[] storeIdentifier = new byte[8];
    public byte[] storeLabel = new byte[32];
    public byte[] facilitatorID = new byte[11];
    public byte[] facilitatorAlias = new byte[10];
    public byte[] isoID = new byte[11];
    public byte[] subMerchantID = new byte[15];
    public byte[] storeTitle = new byte[50];
    public byte[] storeCity = new byte[50];
    public byte[] storeZIPCode = new byte[10];
    public byte[] storeAddress = new byte[50];
    public byte[] storeCategoryCode = new byte[4];
    public byte[] storeSiret = new byte[14];
    public StoreStatusEnumeration storeStatus;
    public Timestamp creationGMTTime = new Timestamp(0L);
    public Timestamp lastModificationGMTTime = new Timestamp(0L);
    public byte[] detailedStatus = new byte[64];
    @ForeignKey(name=DAO_User.class)
    public long idUser = 0L;
    public byte[] storeCountryCodeNum = new byte[3];
    public byte[] storeCountryCodeAlpha = new byte[3];
}

