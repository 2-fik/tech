/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.Index;
import org.yp.designaccesobjects.PrimaryKey;
import org.yp.designaccesobjects.YP_Row;

public class DAO_Summary
extends YP_Row {
    @PrimaryKey
    public long idSummary = 0L;
    @Index
    public byte[] contractIdentifier = new byte[120];
    public byte[] date = new byte[10];
    public byte[] transactionCurrencyAlpha = new byte[3];
    public byte[] terminal = new byte[32];
    public byte[] cashierID = new byte[32];
    public byte[] storeIdentifier = new byte[8];
    public byte[] shiftNumber = new byte[12];
    public int nbDebit = 0;
    public byte[] totalAmountDebit = new byte[32];
    public int nbRefund = 0;
    public byte[] totalAmountRefund = new byte[32];
    public int nbReversalDebit = 0;
    public byte[] totalAmountReversalDebit = new byte[32];
    public int nbINITIAL_RESERVATION = 0;
    public byte[] totalAmountINITIAL_RESERVATION = new byte[32];
}

