/*
 * Decompiled with CFR 0.152.
 */
package org.yp.designaccesobjects.brand;

import org.yp.designaccesobjects.YP_Row;

public class DAO_GetDataReconciliation_PaiementPari
extends YP_Row {
    public long nbrTicket;
    public long nbrFormulation = 0L;
    public float totalGain = 0.0f;
}

