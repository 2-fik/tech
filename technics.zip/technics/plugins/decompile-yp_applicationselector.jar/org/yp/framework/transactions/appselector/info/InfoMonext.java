/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector.info;

import java.util.List;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_Prot;
import org.yp.framework.ondemandcomponents.protocols.YP_PROT_Interface_StateMachineExtended;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class InfoMonext {
    public static boolean isMONEXTBrand(YP_Transaction yP_Transaction, YP_TCD_DCC_Brand yP_TCD_DCC_Brand) {
        try {
            String[] stringArray;
            String string = yP_TCD_DCC_Brand.getParameter("CBCollector", true);
            if (string != null && (stringArray = string.split(":"))[0].contentEquals("MONEXT_PMU") && stringArray[1].contentEquals("1")) {
                return true;
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "isMONEXTBrand() : ", exception);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static int updatePrecisions(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, int[] nArray, int n) {
        if (yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM && yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC && (yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction || YP_TCD_DCC_Business.getPaymentTechnology(yP_Transaction.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_MAGSTRIPE)) {
            if (yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.TerminalRiskManagement) return -1;
            if (YP_TCD_DCC_Business.getPaymentTechnology(yP_Transaction.getDataContainerTransaction()) != EntryModeEnumeration.ENTRY_MODE_ICC) {
                return -1;
            }
        }
        int n2 = 0;
        while (n2 < nArray.length) {
            if (nArray[n2] == n) {
                YP_TCD_DCC_Business yP_TCD_DCC_Business = list.get(n2);
                int n3 = yP_Transaction.getDataContainerTransaction().getCurrentTry();
                yP_Transaction.getDataContainerTransaction().setCurrentTry(1);
                boolean bl = false;
                YP_PROT_Interface_StateMachineExtended yP_PROT_Interface_StateMachineExtended = (YP_PROT_Interface_StateMachineExtended)((Object)yP_TCD_DCC_Business.newPluginByName("PLUGIN_INFO", new Object[0]));
                if (yP_PROT_Interface_StateMachineExtended != null) {
                    if (yP_PROT_Interface_StateMachineExtended.setParameters(list.get(n2), yP_Transaction.getDataContainerTransaction(), YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto, yP_TCD_DCC_Business.getApplicationPlugin().getApplicationProperties(), null, null, new Object[0]) > 0) {
                        while (yP_PROT_Interface_StateMachineExtended.step() == 1) {
                        }
                    }
                    if (yP_PROT_Interface_StateMachineExtended.getErrorCode() != 0) {
                        bl = true;
                    }
                    yP_PROT_Interface_StateMachineExtended.shutdown();
                }
                if (bl) {
                    bl = false;
                    yP_Transaction.getDataContainerTransaction().setCurrentTry(2);
                    yP_PROT_Interface_StateMachineExtended = (YP_PROT_Interface_StateMachineExtended)((Object)yP_TCD_DCC_Business.newPluginByName("PLUGIN_INFO", new Object[0]));
                    if (yP_PROT_Interface_StateMachineExtended != null) {
                        if (yP_PROT_Interface_StateMachineExtended.setParameters(list.get(n2), yP_Transaction.getDataContainerTransaction(), YP_PROT_Interface_Prot.SERVICEDEMANDE.ServiceAuto, yP_TCD_DCC_Business.getApplicationPlugin().getApplicationProperties(), null, null, new Object[0]) > 0) {
                            while (yP_PROT_Interface_StateMachineExtended.step() == 1) {
                            }
                        }
                        yP_PROT_Interface_StateMachineExtended.shutdown();
                    }
                }
                yP_Transaction.getDataContainerTransaction().setCurrentTry(n3);
                try {
                    String string = (String)yP_Transaction.getDataContainerTransaction().getTemporaryValue("merchantContractFromMonext");
                    if (string == null) return -2;
                    if (string.isEmpty()) {
                        return -2;
                    }
                    int n4 = 0;
                    while (true) {
                        YP_TCD_DCC_Business yP_TCD_DCC_Business2;
                        String string2;
                        if (n4 >= nArray.length) {
                            return -3;
                        }
                        if (nArray[n4] == n && (string2 = (yP_TCD_DCC_Business2 = list.get(n4)).getMerchantContract()).contentEquals(string)) {
                            nArray[n4] = n + 1;
                            return 1;
                        }
                        ++n4;
                    }
                }
                catch (Exception exception) {
                    yP_Transaction.logger(2, "updatePrecisions()", exception);
                    return -3;
                }
            }
            ++n2;
        }
        return -3;
    }
}

