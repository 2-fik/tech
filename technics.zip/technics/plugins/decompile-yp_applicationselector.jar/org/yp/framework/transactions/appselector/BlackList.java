/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.ExtendedTVREnumeration;

public abstract class BlackList {
    private static YP_Service blackListManager;

    public static void dealBlackListUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile) {
        try {
            if (yP_Transaction.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.PARAMETERIZATION_NEEDED)) {
                yP_Transaction.logger(3, "dealBlackListUpdate() Not checked when a soft update is required");
                return;
            }
            if (blackListManager == null) {
                blackListManager = (YP_Service)yP_Transaction.getPluginByName("BlackListManager");
            }
            if (blackListManager == null) {
                yP_Transaction.logger(2, "dealBlackListUpdate() service not found");
                return;
            }
            long l = UtilsYP.getSystemGMTTime(yP_Transaction.getStartTime()).getTimeInMillis();
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            AtomicLong atomicLong = parameterFile.headerParameterFile.checksum == null ? new AtomicLong(0L) : new AtomicLong(Long.parseLong(parameterFile.headerParameterFile.checksum));
            TLVHandler tLVHandler = new TLVHandler();
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = new StringBuilder();
            Integer n = (Integer)blackListManager.dealRequest(yP_Transaction, "getBlackList", atomicLong, l, stringBuilder, stringBuilder2);
            if (n == null || n <= 0) {
                return;
            }
            tLVHandler.add(-538738354, stringBuilder.toString());
            if (atomicLong.get() != 0L) {
                tLVHandler.add(-538738353, stringBuilder2.toString());
            }
            parameterFile2.appTagsList.add(tLVHandler.toString());
            list2.add(parameterFile2);
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealBlackListUpdate() getBlackList() ", exception);
            return;
        }
    }
}

