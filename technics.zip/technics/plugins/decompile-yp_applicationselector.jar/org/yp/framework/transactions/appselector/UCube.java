/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.transactions.appselector.YP_BT_WEB_Mobile;
import org.yp.utils.ByteBuilder;
import org.yp.utils.ExtendedResult;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class UCube {
    private static final String UCUBE_SEQ_NEMBER = "ucubeSequenceumber";
    public static final String DEFAULT_PIN_ENTRY_TIMEOUT_IN_SEC = "60";
    public static final String PART_MATCH = "0";
    public static final String FULL_MATCH = "1";
    private static final String defaultAdditionalTerminalCapabilities = "600080A001";
    private static final byte[] terminalCapabilitiesMCMagstripe;
    private static final byte[] terminalCapabilitiesMC;
    private static final byte[] terminalCapabilitiesNoCVMMC;
    private static final byte[] terminalCapabilitiesVISA;
    private static final byte[] terminalCapabilitiesNoCVMVISA;
    private static final byte[] defaultTerminalCapabilities;
    private static final byte[] defaultTerminalCapabilitiesNoCVM;
    private static final String defaultVISATTQ = "32204000";
    private static final String defaultVISARefundTTQ = "22800000";
    private static final String defaultUDOL = "9F6A04";
    static final String Kernel3DefaultReaderContactlessTransactionLimit = "0000030000";
    static final String Kernel3DefaultReaderContactlessCVMLimit = "0000005001";
    static final String Kernel3DefaultReaderContactlessFloorLimit = "0000003000";

    static {
        byte[] byArray = new byte[3];
        byArray[0] = 96;
        byArray[1] = 32;
        terminalCapabilitiesMCMagstripe = byArray;
        terminalCapabilitiesMC = new byte[]{96, 32, 8};
        terminalCapabilitiesNoCVMMC = new byte[]{96, 8, 8};
        terminalCapabilitiesVISA = new byte[]{96, 32, 64};
        terminalCapabilitiesNoCVMVISA = new byte[]{96, 40, 64};
        defaultTerminalCapabilities = new byte[]{96, 32, 72};
        defaultTerminalCapabilitiesNoCVM = new byte[]{96, 40, 72};
    }

    /*
     * WARNING - void declaration
     */
    public static void dealCTCL_Parameters_Update(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, TLVHandler tLVHandler, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        block20: {
            l += 7L;
            try {
                void var12_22;
                void var9_14;
                Object object;
                Object object2;
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) break block20;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                ConfigObject configObject = new ConfigObject();
                block12: for (YP_TCD_DCC_Business object42 : list) {
                    if (!object42.getActivationCode().contentEquals(FULL_MATCH) || (object2 = (YP_TCD_DCB_Interface_CTCL)object42.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !object2.isActive()) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object42.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        UCube.deallOneCTCLContract(yP_Transaction, object42, (YP_TCD_DCB_Interface_CTCL)object2, configObject);
                        continue block12;
                    }
                }
                Object var9_12 = null;
                try {
                    object = tLVHandler.getTLV(14672737);
                    if (object != null) {
                        String string = UtilsYP.devHexa(((TLV)object).value);
                    }
                }
                catch (Exception exception) {
                    yP_Transaction.logger(2, "extractKSN() " + exception);
                }
                if (var9_14 == null) {
                    yP_Transaction.logger(2, "dealICC_Parameters_Update() ksn is mandatory !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return;
                }
                object = new Random();
                object2 = (Integer)yP_Transaction.getDataContainerTransaction().getTemporaryValue(UCUBE_SEQ_NEMBER);
                if (object2 == null) {
                    object2 = new Integer(1);
                    yP_Transaction.getDataContainerTransaction().setTemporaryValue(UCUBE_SEQ_NEMBER, object2);
                }
                Object var12_17 = null;
                try {
                    FileInputStream fileInputStream = new FileInputStream("business/updates/" + list.get(0).getDataContainerMerchant().getContractIdentifier() + "/emv_nfc_ucube.bin");
                }
                catch (FileNotFoundException fileNotFoundException) {
                    try {
                        FileInputStream fileInputStream = new FileInputStream("business/updates/" + list.get(0).getDataContainerBrand().getContractIdentifier() + "/emv_nfc_ucube.bin");
                    }
                    catch (FileNotFoundException fileNotFoundException2) {
                        try {
                            FileInputStream fileInputStream = new FileInputStream("business/updates/emv_nfc_ucube.bin");
                        }
                        catch (FileNotFoundException fileNotFoundException3) {
                            try {
                                FileInputStream fileInputStream = new FileInputStream("emv_nfc_ucube.bin");
                            }
                            catch (FileNotFoundException fileNotFoundException4) {
                                yP_Transaction.logger(2, "UCube.dealCTCL_Parameters_Update() no parameters");
                            }
                        }
                    }
                }
                int n = var12_22.available();
                byte[] byArray = new byte[n];
                var12_22.read(byArray);
                CharSequence charSequence = new StringBuilder();
                ((StringBuilder)charSequence).append(String.format("%02X", (byte)((Random)object).nextInt(255)));
                ((StringBuilder)charSequence).append("0001");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("00000000000000000000000000000000");
                ((StringBuilder)charSequence).append("05");
                ((StringBuilder)charSequence).append("01000000");
                ((StringBuilder)charSequence).append(UtilsYP.getAAMMJJTime(UtilsYP.getSystemGMTTime()));
                ((StringBuilder)charSequence).append("01");
                ((StringBuilder)charSequence).append("00");
                ((StringBuilder)charSequence).append("00");
                ((StringBuilder)charSequence).append(String.format("%02X", n % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 256 % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 65536 % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 0x1000000 % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 256 % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 65536 % 256));
                ((StringBuilder)charSequence).append(String.format("%02X", n / 0x1000000 % 256));
                ((StringBuilder)charSequence).append("00");
                ((StringBuilder)charSequence).append("0000");
                String string = ((StringBuilder)charSequence).toString();
                CharSequence charSequence2 = UCube.createMessage("5160", string, (String)var9_14, (Integer)object2);
                object2 = ((Integer)object2 + 1) % 256;
                parameterFile2.appTagsList.add((String)charSequence2);
                var12_22.close();
                charSequence = UtilsYP.devHexa(byArray);
                int n2 = 0;
                while (n2 < ((String)charSequence).length()) {
                    String string2;
                    charSequence2 = new StringBuilder();
                    ((StringBuilder)charSequence2).append(String.format("%02X", (byte)((Random)object).nextInt(255)));
                    if (n2 + 4048 >= ((String)charSequence).length()) {
                        ((StringBuilder)charSequence2).append("01");
                        string2 = ((String)charSequence).substring(n2);
                    } else {
                        ((StringBuilder)charSequence2).append("00");
                        string2 = ((String)charSequence).substring(n2, n2 + 4048);
                    }
                    n2 += 4048;
                    ((StringBuilder)charSequence2).append(String.format("%02X", string2.length() / 2 / 256));
                    ((StringBuilder)charSequence2).append(String.format("%02X", string2.length() / 2 % 256));
                    ((StringBuilder)charSequence2).append(string2);
                    String string3 = ((StringBuilder)charSequence2).toString();
                    String string4 = UCube.createMessage("5161", string3, (String)var9_14, (Integer)object2);
                    object2 = ((Integer)object2 + 1) % 256;
                    parameterFile2.appTagsList.add(string4);
                }
                yP_Transaction.getDataContainerTransaction().setTemporaryValue(UCUBE_SEQ_NEMBER, object2);
                list2.add(parameterFile2);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                yP_Transaction.logger(2, "dealCTCL_Parameters_Update() " + exception);
            }
        }
    }

    private static String createMessage(String string, String string2, String string3, Integer n) {
        byte[] byArray = UtilsYP.redHexa(string2);
        byte[] byArray2 = DUKPT.padMod78164(byArray);
        String string4 = DUKPT.encryptDataUCube(string3, "0123456789ABCDEFFEDCBA9876543210", byArray2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%02X", (string4.length() + 9) / 2 / 256));
        stringBuilder.append(String.format("%02X", (string4.length() + 9) / 2 % 256));
        stringBuilder.append(String.format("%02X", n));
        stringBuilder.append(string);
        stringBuilder.append(string4);
        byte[] byArray3 = UtilsYP.redHexa(stringBuilder.toString());
        String string5 = DUKPT.macRequestData(string3, byArray3, DUKPT.PaddingType.ISO78164Padding);
        stringBuilder.append(string5.subSequence(0, 8));
        byte[] byArray4 = UtilsYP.redHexa(stringBuilder.toString());
        int n2 = UtilsYP.crc16(byArray4, byArray4.length, 0);
        stringBuilder.insert(0, "02");
        stringBuilder.append(String.format("%04X", n2));
        stringBuilder.append("03");
        return stringBuilder.toString();
    }

    private static String getTerminalType(YP_Transaction yP_Transaction) {
        YP_Row yP_Row = yP_Transaction.getDataContainerTransaction().getTerminalRow();
        if (yP_Row == null) {
            return "22";
        }
        String string = yP_Row.getFieldStringValueByName("terminalType");
        if (string == null || string.isEmpty()) {
            return "22";
        }
        return string;
    }

    private static void deallOneCTCLContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, ConfigObject configObject) {
        Object object;
        int n = YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(yP_TCD_DCC_Business);
        List<YP_Row> list = yP_TCD_DCB_Interface_CTCL.getAIDKIDList(Integer.toString(n));
        block41: for (YP_Row yP_Row : list) {
            object = "";
            String string = "";
            try {
                TLVHandler tLVHandler;
                Object object2;
                CtlsCombination ctlsCombination;
                int n2;
                block78: {
                    block76: {
                        String string2;
                        List<YP_Row> list2;
                        object = yP_Row.getFieldStringValueByName("applicationIdentifier");
                        n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
                        switch (n2) {
                            case 2: 
                            case 3: 
                            case 4: {
                                break;
                            }
                            default: {
                                yP_Transaction.logger(3, "deallOneCTCLContract() kernel not yet handled " + n2);
                                continue block41;
                            }
                        }
                        string = yP_Row.getFieldStringValueByName("transactionType");
                        if (yP_Transaction.getLogLevel() == 6) {
                            yP_Transaction.logger(6, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + n2 + " " + string);
                        }
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getAIDTable();
                        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        if (((String)object).length() < 10) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid length invalid: " + ((String)object).length());
                            continue;
                        }
                        String string3 = ((String)object).substring(0, 10);
                        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                        String string4 = null;
                        if (((String)object).length() > 10) {
                            string4 = ((String)object).substring(10);
                            yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.START_WITH, string4);
                        }
                        if (((list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit)) == null || list2.isEmpty()) && ((list2 = UCube.getPartialAIDRow(yP_TCD_DesignAccesObject, (String)object)) == null || list2.isEmpty())) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid not found for " + (String)object);
                            continue;
                        }
                        ctlsCombination = new CtlsCombination();
                        ctlsCombination.kernelId = n2;
                        ctlsCombination.aid = object;
                        String string5 = yP_TCD_DCC_Business.getCountryCode();
                        while (string5.length() < 4) {
                            string5 = String.valueOf('0') + string5;
                        }
                        ctlsCombination.countryCode = string5;
                        ctlsCombination.terminalType = UCube.getTerminalType(yP_Transaction);
                        String string6 = yP_Row.getFieldStringValueByName("signatureHandled");
                        if (ctlsCombination.terminalType.contentEquals("25")) {
                            string6 = "false";
                        }
                        String string7 = yP_Row.getFieldStringValueByName("pinOnlineHandled");
                        String string8 = yP_Row.getFieldStringValueByName("noCVMHandled");
                        String string9 = yP_Row.getFieldStringValueByName("onDeviceCVMHandled");
                        if (string.contentEquals("20")) {
                            string9 = "true";
                        }
                        byte[] byArray = UtilsYP.redHexa(defaultVISATTQ);
                        byte[] byArray2 = UtilsYP.redHexa(defaultVISARefundTTQ);
                        if (string6 != null && string6.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 2);
                            byArray2[0] = (byte)(byArray2[0] | 2);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFD);
                            byArray2[0] = (byte)(byArray2[0] & 0xFD);
                        }
                        if (string7 != null && string7.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 4);
                            byArray2[0] = (byte)(byArray2[0] | 4);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFB);
                            byArray2[0] = (byte)(byArray2[0] & 0xFB);
                        }
                        if (string9 != null && string9.contentEquals("true")) {
                            byArray[2] = (byte)(byArray[2] | 0x40);
                            byArray2[2] = (byte)(byArray2[2] | 0x40);
                        } else {
                            byArray[2] = (byte)(byArray[2] & 0xBF);
                            byArray2[2] = (byte)(byArray2[2] & 0xBF);
                        }
                        switch (string) {
                            case "0": 
                            case "00": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray);
                                break;
                            }
                            case "20": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray2);
                            }
                        }
                        ctlsCombination.appSelectionIndicator = 0;
                        ctlsCombination.maxNumberTornTrs = 2;
                        ctlsCombination.zeroAmountAllowedFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport")) ? 1 : 0;
                        ctlsCombination.extendedSelectionSupportFlag = 0;
                        ctlsCombination.readerContactlessFloorLimit = UCube.getPaddedAmount(yP_Row, "readerContactlessFloorLimit");
                        ctlsCombination.terminalFloorLimit = UCube.getPaddedAmount(yP_Row, "terminalFloorLimit");
                        ctlsCombination.readerContactlessTransactionLimitNoOnDevice = UCube.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitNoOnDevice");
                        ctlsCombination.readerContactlessTransactionLimitOnDevice = UCube.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitOnDevice");
                        ctlsCombination.readerCVMRequiredLimit = UCube.getPaddedAmount(yP_Row, "readerCVMRequiredLimit");
                        int n3 = ctlsCombination.statusCheckSupportFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("statusCheckSupport")) ? 1 : 0;
                        if (yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) {
                            ctlsCombination.endUserSupportedLanguage = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getEndUserLangageList(yP_Transaction.getDataContainerTransaction());
                        }
                        try {
                            int n4;
                            ctlsCombination.priority = n4 = ((Integer)list2.get(0).getFieldValueByName("priority")).intValue();
                        }
                        catch (Exception exception) {
                            yP_Transaction.logger(2, "deallOneCTCLContract(): While processing priority: " + (String)object, exception);
                        }
                        ctlsCombination.currencyCode = Integer.parseInt(yP_Row.getFieldStringValueByName("numericalCurrencyCode"));
                        switch (string) {
                            case "0": 
                            case "00": {
                                ctlsCombination.trsType = 0;
                                break;
                            }
                            case "20": {
                                ctlsCombination.trsType = 20;
                                break;
                            }
                            default: {
                                yP_Transaction.logger(2, "deallOneCTCLContract(): row ignored : " + (String)object + " " + n2 + " " + string);
                                continue block41;
                            }
                        }
                        configObject.ctlsCombinationList.add(ctlsCombination);
                        ctlsCombination.additionnalTerminalCapabilities = defaultAdditionalTerminalCapabilities;
                        ctlsCombination.merchantNameLocation = yP_TCD_DCC_Business.getMerchantName();
                        ctlsCombination.acquirerId = yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode();
                        if (ctlsCombination.acquirerId.length() % 2 == 1) {
                            ctlsCombination.acquirerId = PART_MATCH + ctlsCombination.acquirerId;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        int n5 = 0;
                        while (n5 < list2.size()) {
                            int n6 = (Integer)list2.get(n5).getFieldValueByName("terminalApplicationVersionNumber");
                            stringBuilder.append(String.format("%4s", Integer.toHexString(n6)).replace(' ', '0'));
                            ++n5;
                        }
                        ctlsCombination.appVersionNumber = stringBuilder.toString();
                        byte[] byArray3 = new byte[defaultTerminalCapabilities.length];
                        switch (n2) {
                            case 2: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMMC);
                                System.arraycopy(terminalCapabilitiesMC, 0, byArray3, 0, terminalCapabilitiesMC.length);
                                break;
                            }
                            case 3: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMVISA);
                                System.arraycopy(terminalCapabilitiesVISA, 0, byArray3, 0, terminalCapabilitiesVISA.length);
                                break;
                            }
                            default: {
                                string2 = UtilsYP.devHexa(defaultTerminalCapabilitiesNoCVM);
                                System.arraycopy(defaultTerminalCapabilities, 0, byArray3, 0, defaultTerminalCapabilities.length);
                            }
                        }
                        byArray3[1] = string6 != null && string6.contentEquals("true") ? (byte)(byArray3[1] | 0x20) : (byte)(byArray3[1] & 0xDF);
                        byArray3[1] = string7 != null && string7.contentEquals("true") ? (byte)(byArray3[1] | 0x40) : (byte)(byArray3[1] & 0xBF);
                        byArray3[1] = string8 != null && string8.contentEquals("true") ? (byte)(byArray3[1] | 8) : (byte)(byArray3[1] & 0xF7);
                        ctlsCombination.terminalCapabilities = UtilsYP.devHexa(byArray3);
                        ctlsCombination.cardDataInputCapability = UtilsYP.devHexa(byArray3).substring(0, 2);
                        ctlsCombination.chipCapabilityCVMReq = UtilsYP.devHexa(byArray3).substring(2, 4);
                        ctlsCombination.chipCapabilityNoCVM = string2.substring(2, 4);
                        ctlsCombination.securityCapability = UtilsYP.devHexa(byArray3).substring(4, 6);
                        ctlsCombination.terminalIdentification = yP_TCD_DCC_Business.getTerminalIdentification();
                        if (n2 != 2) break block76;
                        object2 = new byte[1];
                        if (UtilsYP.isTrue(string9)) {
                            object2[0] = (byte)(object2[0] | 0x20);
                        }
                        switch (object) {
                            case "A0000000043060": 
                            case "A0000000422010": 
                            case "A0000000425010": {
                                object2[0] = (byte)(object2[0] | 0x80);
                                if (UCube.getTerminalType(yP_Transaction).contentEquals("25")) {
                                    ctlsCombination.terminalRiskMgmtData = "0C00800000000000";
                                    break;
                                }
                                ctlsCombination.terminalRiskMgmtData = "2C00800000000000";
                                break;
                            }
                            default: {
                                ctlsCombination.terminalRiskMgmtData = UCube.getTerminalType(yP_Transaction).contentEquals("25") ? "0C00000000000000" : "2C00000000000000";
                            }
                        }
                        ctlsCombination.kernelConfiguration = UtilsYP.devHexa((byte[])object2);
                        break block78;
                    }
                    ctlsCombination.terminalRiskMgmtData = "0000000000000000";
                    ctlsCombination.kernelConfiguration = "00";
                }
                if (n2 == 4) {
                    ctlsCombination.expressPayTerminalCapabilities = "C0";
                    ctlsCombination.expressPayTerminalTransactionCapabilities = "D8A00000";
                }
                ctlsCombination.magCapabilityNoCVM = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsCombination.magCapabilityCVMReq = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsCombination.merchantCategoryCode = String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode()));
                ctlsCombination.merchantIdentifier = yP_TCD_DCC_Business.getCommercialRegisterNumber();
                while (ctlsCombination.merchantIdentifier.length() < 15) {
                    ctlsCombination.merchantIdentifier = String.valueOf(ctlsCombination.merchantIdentifier) + " ";
                }
                ctlsCombination.tacOnline = yP_Row.getFieldStringValueByName("tacOnline");
                ctlsCombination.tacDefault = yP_Row.getFieldStringValueByName("tacDefault");
                ctlsCombination.tacDenial = yP_Row.getFieldStringValueByName("tacDenial");
                ctlsCombination.tranCategoryCode = 0;
                object2 = yP_TCD_DCB_Interface_CTCL.getAIDParameters((String)object);
                if (object2 == null) continue;
                Object object3 = ((YP_Row)object2).getFieldStringValueByName("specificData");
                if (object3 != null && !((String)object3).isEmpty() && (tLVHandler = new TLVHandler((String)object3)) != null) {
                    for (TLV tLV : tLVHandler) {
                        switch (tLV.tag) {
                            case 40787: {
                                ctlsCombination.tranCategoryCode = Integer.parseInt(UtilsYP.devHexa(tLV.value), 16);
                                break;
                            }
                            case 57103: {
                                break;
                            }
                        }
                    }
                }
                ctlsCombination.defaultDDOL = ((YP_Row)object2).getFieldStringValueByName("defaultDDOL");
                ctlsCombination.defaultTDOL = ((YP_Row)object2).getFieldStringValueByName("defaultTDOL");
                ctlsCombination.defaultUDOL = defaultUDOL;
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + string, exception);
            }
        }
        for (YP_Row yP_Row : yP_TCD_DCB_Interface_CTCL.getDRLTable()) {
            object = UCube.fillInLimitSet(yP_TCD_DCC_Business, yP_Row);
            if (object == null) continue;
            configObject.ctlsLimitSetList.add((LimitSet)object);
        }
    }

    private static String getForbiddenProducts(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list) {
        TLVHandler tLVHandler = new TLVHandler();
        try {
            HashMap hashMap = new HashMap();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                YP_TCD_DCB_Interface_ProductList yP_TCD_DCB_Interface_ProductList;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_ProductList = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_ProductList.getProductListTable();
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string;
                    String string2;
                    String string3 = yP_Row.getFieldStringValueByName("emvApplicationAID");
                    if (string3 == null || string3.isEmpty()) {
                        yP_Transaction.logger(4, "getForbiddenProducts() maybe a product indexed by BIN");
                        continue;
                    }
                    ArrayList<String> arrayList = (ArrayList<String>)hashMap.get(string3);
                    if (arrayList == null) {
                        arrayList = new ArrayList<String>();
                        hashMap.put(string3, arrayList);
                    }
                    if ((string2 = yP_Row.getFieldStringValueByName("electronicProductIdentification")) == null || string2.isEmpty()) {
                        string2 = "0001";
                    }
                    if ((string = yP_Row.getFieldStringValueByName("codeProduit")) == null || string.isEmpty()) {
                        yP_Transaction.logger(3, "getForbiddenProducts() product code missing!!!");
                        continue;
                    }
                    if (arrayList.contains(string)) continue;
                    arrayList.add(string);
                    TLVHandler tLVHandler2 = new TLVHandler();
                    tLVHandler2.add(-538738400, string3);
                    tLVHandler2.add(-538738370, string2);
                    tLVHandler2.add(-538738369, string);
                    tLVHandler.add(-2064064, tLVHandler2);
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "getForbiddenProducts() ", exception);
        }
        return tLVHandler.toString();
    }

    private static LimitSet fillInLimitSet(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_Row yP_Row) {
        LimitSet limitSet = new LimitSet();
        String string = yP_Row.getFieldStringValueByName("statusCheckSupport");
        limitSet.statusCheckSupportFlag = string != null && string.contentEquals(PART_MATCH) ? 1 : 0;
        String string2 = yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport");
        limitSet.zeroAmountAllowedFlag = string2 != null && string2.contentEquals(PART_MATCH) ? 1 : 0;
        limitSet.readerCVMRequiredLimit = UCube.getPaddedAmount(yP_Row, "CVMRequiredLimit");
        limitSet.readerCVMRequiredLimit.contentEquals("999999999999");
        limitSet.readerCtlsTermFloorLimit = UCube.getPaddedAmount(yP_Row, "ctlFloorLimit");
        limitSet.readerCtlsTermFloorLimit.contentEquals("999999999999");
        limitSet.readerCtlsFloorLimit = UCube.getPaddedAmount(yP_Row, "ctlFloorLimit");
        limitSet.appProgramId = yP_Row.getFieldStringValueByName("applicationPgmId");
        limitSet.readerCtlsTranLimit = UCube.getPaddedAmount(yP_Row, "ctlTransactionLimit");
        limitSet.kernelId = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
        limitSet.currencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
        while (limitSet.currencyCode.length() < 4) {
            limitSet.currencyCode = PART_MATCH + limitSet.currencyCode;
        }
        limitSet.currencyExponent = yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface != null ? String.format("%02d", ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyFraction(Integer.parseInt(limitSet.currencyCode))) : "02";
        limitSet.appSelectionIndicator = 0;
        return limitSet;
    }

    private static List<YP_Row> getPartialAIDRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        String string2 = string.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("partialSelectionAllowed", YP_ComplexGabarit.OPERATOR.EQUAL, true);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() == 0) {
            return null;
        }
        for (YP_Row yP_Row : list) {
            String string3 = yP_Row.getFieldStringValueByName("pix");
            if (!string.startsWith(String.valueOf(string2) + string3)) continue;
            arrayList.add(yP_Row);
        }
        return arrayList;
    }

    private static String getPaddedAmount(YP_Row yP_Row, String string) {
        StringBuilder stringBuilder = new StringBuilder(yP_Row.getFieldStringValueByName(string));
        while (stringBuilder.length() < 12) {
            stringBuilder.insert(0, PART_MATCH);
        }
        return stringBuilder.toString();
    }

    /*
     * WARNING - void declaration
     */
    public static void dealICC_Parameters_Update(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, TLVHandler tLVHandler, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        block14: {
            l += 2L;
            try {
                void var16_37;
                void var14_22;
                Object object3;
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) break block14;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                HashSet<String> hashSet = new HashSet<String>();
                ArrayList<String> arrayList = new ArrayList<String>();
                HashSet<String> hashSet2 = new HashSet<String>();
                ArrayList<String> arrayList2 = new ArrayList<String>();
                String string = "";
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(FULL_MATCH) || (object3 = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        Object object2;
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                        UCube.addICCAIDs(yP_Transaction, yP_TCD_DCC_Business, hashSet2, arrayList2, object3);
                        UCube.addICCKeys(yP_Transaction, hashSet, arrayList, object3.getKeysTable());
                        if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) || (object2 = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getEndUserLangageList(yP_Transaction.getDataContainerTransaction())) == null || ((String)object2).isEmpty()) continue;
                        string = String.valueOf(string) + (String)object2;
                    }
                }
                ArrayList<String> arrayList3 = new ArrayList<String>();
                arrayList3.add("A1000000");
                arrayList3.add("A2000000");
                arrayList3.add("A3000000");
                arrayList3.add("A4000000");
                for (String string2 : arrayList2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("0100");
                    stringBuilder.append(String.format("%02X", string2.length() / 2 % 256));
                    stringBuilder.append(String.format("%02X", string2.length() / 2 / 256));
                    stringBuilder.append(string2);
                    arrayList3.add(stringBuilder.toString());
                }
                for (String string3 : arrayList) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("0200");
                    stringBuilder.append(String.format("%02X", string3.length() / 2 % 256));
                    stringBuilder.append(String.format("%02X", string3.length() / 2 / 256));
                    stringBuilder.append(string3);
                    arrayList3.add(stringBuilder.toString());
                }
                if (!arrayList2.isEmpty()) {
                    List<String> list3 = UCube.getPinEntryPINPrompts(list.get(0).getDataContainerMerchant(), string);
                    for (Object object3 : list3) {
                        Object object4 = new StringBuilder();
                        ((StringBuilder)object4).append("0400");
                        ((StringBuilder)object4).append(String.format("%02X", ((String)object3).length() / 2 % 256));
                        ((StringBuilder)object4).append(String.format("%02X", ((String)object3).length() / 2 / 256));
                        ((StringBuilder)object4).append((String)object3);
                        arrayList3.add(((StringBuilder)object4).toString());
                    }
                }
                Object var14_20 = null;
                try {
                    object3 = tLVHandler.getTLV(14672737);
                    if (object3 != null) {
                        String string4 = UtilsYP.devHexa(((TLV)object3).value);
                    }
                }
                catch (Exception exception) {
                    yP_Transaction.logger(2, "extractKSN() " + exception);
                }
                if (var14_22 == null) {
                    yP_Transaction.logger(2, "dealICC_Parameters_Update() ksn is mandatory !!!");
                    YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                    return;
                }
                object3 = new Random();
                Integer n = (Integer)yP_Transaction.getDataContainerTransaction().getTemporaryValue(UCUBE_SEQ_NEMBER);
                if (n == null) {
                    Integer n2 = new Integer(1);
                    yP_Transaction.getDataContainerTransaction().setTemporaryValue(UCUBE_SEQ_NEMBER, n2);
                }
                for (Object object4 : arrayList3) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(String.format("%02X", (((String)object4).length() + 10) / 2 / 256));
                    stringBuilder.append(String.format("%02X", (((String)object4).length() + 10) / 2 % 256));
                    stringBuilder.append(String.format("%02X", var16_37));
                    Integer n3 = (var16_37.intValue() + 1) % 256;
                    stringBuilder.append("5501");
                    stringBuilder.append(String.format("%02X", (byte)((Random)object3).nextInt(255)));
                    stringBuilder.append((String)object4);
                    byte[] byArray = UtilsYP.redHexa(stringBuilder.toString());
                    String string5 = DUKPT.macRequestData((String)var14_22, byArray, DUKPT.PaddingType.ISO78164Padding);
                    stringBuilder.append(string5.subSequence(0, 8));
                    byte[] byArray2 = UtilsYP.redHexa(stringBuilder.toString());
                    int n4 = UtilsYP.crc16(byArray2, byArray2.length, 0);
                    stringBuilder.insert(0, "02");
                    stringBuilder.append(String.format("%04X", n4));
                    stringBuilder.append("03");
                    parameterFile2.appTagsList.add(stringBuilder.toString());
                }
                yP_Transaction.getDataContainerTransaction().setTemporaryValue(UCUBE_SEQ_NEMBER, var16_37);
                list2.add(parameterFile2);
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "dealICC_Parameters_Update()  ", exception);
            }
        }
    }

    private static void addICCAIDs(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, Set<String> set, List<String> list, YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV) {
        if (yP_TCD_DCB_Interface_EMV == null) {
            yP_Transaction.logger(2, "addICCAIDs() keyTable is null");
            return;
        }
        for (YP_Row yP_Row : yP_TCD_DCB_Interface_EMV.getAIDTable()) {
            String string;
            String string2;
            String string3;
            String string4;
            String string5 = yP_Row.getFieldStringValueByName("rid");
            String string6 = yP_Row.getFieldStringValueByName("pix");
            String string7 = String.valueOf(string5) + string6;
            if (set.contains(string7)) continue;
            set.add(string7);
            YP_Row yP_Row2 = yP_TCD_DCB_Interface_EMV.getAIDParameters(string7);
            if (yP_Row2 == null) {
                yP_Transaction.logger(2, "dealEMV_ICC_AIDUpdate() Parameters not found for aid" + string7);
                continue;
            }
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(132, string7);
            Boolean bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed");
            if (bl.booleanValue()) {
                tLVHandler.add(220, "01");
            } else {
                tLVHandler.add(220, "00");
            }
            int n = (Integer)yP_Row.getFieldValueByName("terminalApplicationVersionNumber");
            String string8 = String.format("%4s", Integer.toHexString(n)).replace(' ', '0');
            tLVHandler.add(40713, string8);
            String string9 = yP_TCD_DCC_Business.getMerchantCategoryCode();
            if (string9 != null && !string9.isEmpty()) {
                tLVHandler.add(40725, string9);
            }
            String string10 = yP_TCD_DCC_Business.getCommercialRegisterNumber();
            while (string10.length() < 15) {
                string10 = String.valueOf(string10) + " ";
            }
            tLVHandler.addASCII(40726, string10);
            tLVHandler.addASCII(40782, yP_TCD_DCC_Business.getMerchantName());
            tLVHandler.add(40757, UCube.getTerminalType(yP_Transaction));
            tLVHandler.add(40755, "E0B8C8");
            tLVHandler.add(40768, "6000F0A001");
            String string11 = yP_TCD_DCC_Business.getCountryCode();
            while (string11.length() < 4) {
                string11 = String.valueOf('0') + string11;
            }
            tLVHandler.add(40730, string11);
            long l = 0L;
            int n2 = (Integer)yP_Row2.getFieldValueByName("currencyNumericalCode");
            if (n2 != 0 && yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) {
                int n3 = YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction());
                YP_TCD_DCC_Business.setTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction(), n2);
                l = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).callParametersInterface.getMaxThresholdCall(yP_Transaction.getDataContainerTransaction());
                YP_TCD_DCC_Business.setTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction(), n3);
                if (l < 0L) {
                    l = 0L;
                }
            }
            tLVHandler.add(40731, String.format("%8s", Long.toHexString(l)).replace(' ', '0'));
            String string12 = yP_Row2.getFieldStringValueByName("defaultDDOL");
            if (string12 != null && !string12.isEmpty()) {
                tLVHandler.add(214, string12);
            }
            if ((string4 = yP_Row2.getFieldStringValueByName("defaultTDOL")) != null && !string4.isEmpty()) {
                tLVHandler.add(215, string4);
            }
            if ((string3 = yP_Row2.getFieldStringValueByName("tacDefault")) != null && !string3.isEmpty()) {
                tLVHandler.add(216, string3);
            }
            if ((string2 = yP_Row2.getFieldStringValueByName("tacDenial")) != null && !string2.isEmpty()) {
                tLVHandler.add(217, string2);
            }
            if ((string = yP_Row2.getFieldStringValueByName("tacOnline")) != null && !string.isEmpty()) {
                tLVHandler.add(218, string);
            }
            list.add(tLVHandler.toString());
        }
    }

    private static void addICCKeys(YP_Transaction yP_Transaction, Set<String> set, List<String> list, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        if (yP_TCD_DesignAccesObject == null) {
            yP_Transaction.logger(2, "addICCKeys() keyTable is null");
            return;
        }
        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
            String string;
            StringBuilder stringBuilder = new StringBuilder();
            String string2 = yP_Row.getFieldStringValueByName("rid");
            stringBuilder.append(string2);
            String string3 = String.format("%02X", (int)((Integer)yP_Row.getFieldValueByName("index")));
            stringBuilder.append(string3);
            int n = (Integer)yP_Row.getFieldValueByName("exponent");
            if (n == 3) {
                stringBuilder.append("01");
                stringBuilder.append("030000");
                string = "03";
            } else if (n == 65537) {
                stringBuilder.append("03");
                stringBuilder.append("010001");
                string = "010001";
            } else {
                yP_Transaction.logger(2, "addICCKeys() unknon exponent " + n);
                continue;
            }
            String string4 = stringBuilder.toString();
            if (set.contains(string4)) continue;
            set.add(string4);
            String string5 = yP_Row.getFieldStringValueByName("keyValue");
            String string6 = String.format("%02X", string5.length() / 2);
            stringBuilder.append(string6);
            stringBuilder.append(string5);
            try {
                String string7 = String.valueOf(string2) + string3 + string5 + string;
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                String string8 = UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string7)));
                while (string8.length() < 40) {
                    string8 = String.valueOf('0') + string8;
                }
                stringBuilder.append(string8);
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                yP_Transaction.logger(2, "addICCKeys() ", noSuchAlgorithmException);
                return;
            }
            list.add(stringBuilder.toString());
        }
    }

    private static List<String> getPinEntryPINPrompts(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, String string) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (string.contains("fr")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "fr"));
        }
        if (string.contains("en")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "en"));
        }
        if (string.contains("de")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "de"));
        }
        if (string.contains("es")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "es"));
        }
        if (string.contains("it")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "it"));
        }
        if (string.contains("nl")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "nl"));
        }
        if (string.contains("pl")) {
            arrayList.add(UCube.getPinEntryPINPromptsSTD(yP_TCD_DCC_Merchant, "pl"));
        }
        return arrayList;
    }

    private static String getPinEntryPINPromptsSTD(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant, String string) {
        TLVHandler tLVHandler = new TLVHandler();
        tLVHandler.addASCII(57143, string);
        tLVHandler.add(57136, 4L);
        tLVHandler.add(57137, 4L);
        String string2 = yP_TCD_DCC_Merchant.getParameter("CLI_PET", true);
        if (string2 == null || string2.isEmpty()) {
            string2 = DEFAULT_PIN_ENTRY_TIMEOUT_IN_SEC;
        }
        String string3 = String.format("%04X", Integer.parseInt(string2));
        tLVHandler.add(57138, string3);
        tLVHandler.add(57139, string3);
        tLVHandler.add(57140, string3);
        tLVHandler.add(57141, 1L);
        tLVHandler.add(57142, 6L);
        switch (string) {
            case "fr": {
                UCube.addText(tLVHandler, 57144, "SAISIR CODE\n");
                UCube.addText(tLVHandler, 57145, "CODE FAUX\n");
                UCube.addText(tLVHandler, 57146, "DERNIER ESSAI\n");
                UCube.addText(tLVHandler, 57147, "CARTE BLOQUEE\n");
                UCube.addText(tLVHandler, 57148, "CODE BON\n");
                UCube.addText(tLVHandler, 57149, "CODE FAUX\n");
                break;
            }
            case "en": {
                UCube.addText(tLVHandler, 57144, "Enter PIN\n");
                UCube.addText(tLVHandler, 57145, "INCORRECT PIN\n");
                UCube.addText(tLVHandler, 57146, "LAST PIN TRY\n");
                UCube.addText(tLVHandler, 57147, "CARD BLOCKED\n");
                UCube.addText(tLVHandler, 57148, "PIN OK\n");
                UCube.addText(tLVHandler, 57149, "INCORRECT PIN\n");
                break;
            }
            case "de": {
                UCube.addText(tLVHandler, 57144, "GEHEIMZAHL\n");
                UCube.addText(tLVHandler, 57145, "GEHEIMZAHL\nFALSCH\n");
                UCube.addText(tLVHandler, 57146, "LETZTE EINGABE\n");
                UCube.addText(tLVHandler, 57147, "KARTE NICHT\nZUGELASSEN\n");
                UCube.addText(tLVHandler, 57148, "GEHEIMZAHL\nKORREKT\n");
                UCube.addText(tLVHandler, 57149, "GEHEIMZAHL\nFALSCH\n");
                break;
            }
            case "es": {
                UCube.addText(tLVHandler, 57144, "INTRODUZCA PIN\n");
                UCube.addText(tLVHandler, 57145, "ERROR DE PIN\n");
                UCube.addText(tLVHandler, 57146, "ULTIMO INTENTO\n");
                UCube.addText(tLVHandler, 57147, "TARJETA\\nBLOQUEADA\n");
                UCube.addText(tLVHandler, 57148, "PIN CORRECTO\n");
                UCube.addText(tLVHandler, 57149, "ERROR DE PIN\n");
                break;
            }
            case "it": {
                UCube.addText(tLVHandler, 57144, "CODICE SEGRETO\n");
                UCube.addText(tLVHandler, 57145, "CODICE ERRAT\n");
                UCube.addText(tLVHandler, 57146, "ULTIMA PROVA\n");
                UCube.addText(tLVHandler, 57147, "CARTA BLOCCATA\n");
                UCube.addText(tLVHandler, 57148, "CODICE VALIDO\n");
                UCube.addText(tLVHandler, 57149, "CODICE ERRAT\n");
                break;
            }
            case "nl": {
                UCube.addText(tLVHandler, 57144, "VOER PINCODE IN\n");
                UCube.addText(tLVHandler, 57145, "PIN CODE KO\n");
                UCube.addText(tLVHandler, 57146, "ULTIMA PROVA\n");
                UCube.addText(tLVHandler, 57147, "GEBLOKKEERDE\nKAART\n");
                UCube.addText(tLVHandler, 57148, "JUISTE CODE\n");
                UCube.addText(tLVHandler, 57149, "PIN CODE KO\n");
                break;
            }
            case "pl": {
                UCube.addText(tLVHandler, 57144, "PODAJ PIN\n");
                UCube.addText(tLVHandler, 57145, "ZLY PIN\n");
                UCube.addText(tLVHandler, 57146, "OSTATNIA PROBA\n");
                UCube.addText(tLVHandler, 57147, "ZABLOKOWANA\nKARTA\n");
                UCube.addText(tLVHandler, 57148, "PIN ZGODNY\n");
                UCube.addText(tLVHandler, 57149, "ZLY PIN\n");
            }
        }
        return tLVHandler.toString();
    }

    private static void addText(TLVHandler tLVHandler, int n, String string) {
        ByteBuilder byteBuilder = new ByteBuilder();
        byteBuilder.append((byte)1);
        byteBuilder.append((byte)(string.length() + 1));
        byteBuilder.append(string.getBytes(StandardCharsets.ISO_8859_1));
        byteBuilder.append((byte)0);
        byteBuilder.append((byte)0);
        byteBuilder.append((byte)0);
        tLVHandler.add(n, byteBuilder.toHexString());
    }

    private static void generateNFCKeys(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list) throws NoSuchAlgorithmException, IOException {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
            YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
            if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
            for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getKeysTable();
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string;
                    String string2 = yP_Row.getFieldStringValueByName("rid");
                    int n2 = (Integer)yP_Row.getFieldValueByName("index");
                    int n3 = (Integer)yP_Row.getFieldValueByName("exponent");
                    String string3 = yP_Row.getFieldStringValueByName("keyValue");
                    if (string3.length() % 2 == 1) {
                        yP_Transaction.logger(2, "generateNFCKeys() bad key value ignored");
                        continue;
                    }
                    String string4 = Integer.toHexString(n2);
                    if (string4.length() % 2 == 1) {
                        string4 = String.valueOf('0') + string4;
                    }
                    if ((string = Integer.toHexString(n3)).length() % 2 == 1) {
                        string = String.valueOf('0') + string;
                    }
                    String string5 = String.valueOf(string2) + string4 + string3 + string;
                    MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                    String string6 = UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string5)));
                    String string7 = String.valueOf(string2) + "_" + string4;
                    while (string.length() < 6 && string.length() != 2) {
                        string = String.valueOf('0') + string;
                    }
                    String string8 = UCube.buildOneKey(string2, string4, string3, string.toUpperCase(), string6);
                    boolean bl = false;
                    String string9 = (String)hashMap.get(string7);
                    if (string9 != null) {
                        if (!string9.contentEquals(string8)) {
                            yP_Transaction.logger(3, "generateNFCKeys() Same key differents values " + string9 + " vs " + string8);
                        }
                        bl = true;
                    }
                    if (bl) continue;
                    hashMap.put(string7, string8.toString());
                    if (n == 0) {
                        stringBuilder.append("settings:\r\n\r\n");
                        stringBuilder.append("  ca_key:\r\n\r\n");
                    }
                    stringBuilder.append("    ca_key");
                    stringBuilder.append(n++);
                    stringBuilder.append(":\r\n");
                    stringBuilder.append(string8);
                }
            }
            FileOutputStream object2 = new FileOutputStream("ucube_nfc_key.yaml");
            object2.write(stringBuilder.toString().getBytes());
            object2.close();
        }
    }

    private static String buildOneKey(String string, String string2, String string3, String string4, String string5) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("      tag_CA00:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_CA01:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_CA02:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string3);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_CA03:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string4);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_CA04:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string5);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("\r\n");
        return stringBuilder.toString();
    }

    private static void generateYAMLForKernel2(ConfigObject configObject, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        Collections.sort(configObject.ctlsCombinationList);
        int n = 0;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  application:\r\n\r\n");
        String string = "";
        String string2 = "";
        String string3 = "";
        String string4 = "";
        String string5 = "012C";
        int n2 = 0;
        for (CtlsCombination object : configObject.ctlsCombinationList) {
            if (object.kernelId != 2 || object.aid.startsWith("A000000042") || object.trsType != 0) continue;
            ++n2;
            stringBuilder.append("    application");
            stringBuilder.append(n++);
            stringBuilder.append(":\r\n");
            stringBuilder.append("      tag_94:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 252\r\n");
            stringBuilder.append("      tag_9C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.trsType));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_5F24:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string2);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 3\r\n");
            stringBuilder.append("      tag_5F2A:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%04d", object.currencyCode));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F01:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.acquirerId);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 6\r\n");
            stringBuilder.append("      tag_9F06:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.aid);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 16\r\n");
            stringBuilder.append("      tag_9F09:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.appVersionNumber.substring(object.appVersionNumber.length() - 4));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F1B:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalFloorLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F1D:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalRiskMgmtData);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 8\r\n");
            stringBuilder.append("      tag_9F35:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalType);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F40:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.additionnalTerminalCapabilities);
            stringBuilder.append("\"\r\n");
            if (object.tranCategoryCode > 0) {
                stringBuilder.append("      tag_9F53:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.tranCategoryCode);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("      tag_9F65:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string3);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 2\r\n");
            stringBuilder.append("      tag_9F66:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.ttq);
            stringBuilder.append("\"\r\n");
            if (object.expressPayTerminalCapabilities != null) {
                stringBuilder.append("      tag_9F6D:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.expressPayTerminalCapabilities);
                stringBuilder.append("\"\r\n");
            }
            if (object.expressPayTerminalTransactionCapabilities != null) {
                stringBuilder.append("      tag_9F6E:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.expressPayTerminalTransactionCapabilities);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("      tag_9F7E:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string4);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 1\r\n");
            stringBuilder.append("      tag_DF810C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.kernelId));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8118:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.chipCapabilityCVMReq);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8119:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.chipCapabilityNoCVM);
            stringBuilder.append("\"\r\n");
            String cfr_ignored_0 = object.defaultUDOL;
            stringBuilder.append("      tag_DF811B:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.kernelConfiguration);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string5);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811D:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.maxNumberTornTrs));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811E:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.magCapabilityCVMReq);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811F:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.securityCapability);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8120:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacDefault);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8121:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacDenial);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8122:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacOnline);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8123:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessFloorLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8124:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessTransactionLimitNoOnDevice);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8125:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessTransactionLimitOnDevice);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8126:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerCVMRequiredLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF812C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.magCapabilityNoCVM);
            stringBuilder.append("\"\r\n");
            if (object.defaultDDOL != null) {
                stringBuilder.append("      tag_DFDF18:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.defaultDDOL);
                stringBuilder.append("\"\r\n");
            }
            if (object.defaultTDOL != null) {
                stringBuilder.append("      tag_DFDF19:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.defaultTDOL);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("\r\n");
        }
        stringBuilder.insert(0, UCube.createFirstPartForKernel2(yP_TCD_DCC_Business, n2));
        try {
            FileOutputStream iOException = new FileOutputStream("ucube_nfc_mastercard_param.yaml");
            iOException.write(stringBuilder.toString().getBytes());
            iOException.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private static String createFirstPartForKernel2(YP_TCD_DCC_Business yP_TCD_DCC_Business, int n) {
        String string = "02";
        String string2 = "";
        String string3 = String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode()));
        String string4 = "";
        String string5 = "0250";
        String string6 = "";
        String string7 = "3132333435363738";
        String string8 = "";
        String string9 = "0001";
        String string10 = "416C63696E656F204B65726E656C";
        String string11 = "602048";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("settings:\r\n\r\n");
        stringBuilder.append("  terminal:\r\n\r\n");
        stringBuilder.append("    terminal0:\r\n");
        stringBuilder.append("      tag_5F36:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_5F57:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 1\r\n");
        stringBuilder.append("      tag_9F15:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string3);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F16:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string4);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 15\r\n");
        stringBuilder.append("      tag_9F1A:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string5);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F1C:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string6);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 8\r\n");
        stringBuilder.append("      tag_9F1E:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string7);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F33:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string11);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 3\r\n");
        stringBuilder.append("      tag_9F4E:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string8);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 256\r\n");
        stringBuilder.append("      tag_9F6D:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string9);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F7C:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string10);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 20\r\n");
        stringBuilder.append("      tag_D000:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(String.format("%02X", n));
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF8117:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF811A:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(defaultUDOL);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF02:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("9F029F039F265F2482505A5F349F129F369F079F099F279F34849F1E9F109F119F249F339F1A9F3595579F535F2A9A9C9F37");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 128\r\n");
        stringBuilder.append("      tag_DFDF03:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("509F12849F119F6D9F24569F6B");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 128\r\n");
        stringBuilder.append("      tag_DFDF14:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00003A98");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF15:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00000001");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF45:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("5056575A5F245F255F285F305F345F2D6F7077808284878C8E8F9092949F059F079F089F0D9F0E9F0F9F109F119F129F179F1F9F209F249F269F279F329F369F389F3B9F429F449F469F479F489F4A9F4B9F4C9F4D9F509F519F549F5B9F5D9F5E9F5F9F609F619F629F639F649F659F669F679F699F6B9F6E9F6F9F709F719F729F739F749F759F769F779F789F799F7D9F7FA5BF0CDF4BDF8101DF8102DF8302DF8303DF8304DF8305");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 256\r\n");
        stringBuilder.append("\r\n");
        return stringBuilder.toString();
    }

    private static void generateYAMLForKernel3(ConfigObject configObject, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        Collections.sort(configObject.ctlsCombinationList);
        int n = 0;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  application:\r\n\r\n");
        String string = "";
        String string2 = "";
        String string3 = "";
        String string4 = "";
        String string5 = "012C";
        int n2 = 0;
        for (CtlsCombination object : configObject.ctlsCombinationList) {
            if (object.kernelId != 3 || object.aid.startsWith("A000000042") || object.trsType != 0) continue;
            ++n2;
            stringBuilder.append("    application");
            stringBuilder.append(n++);
            stringBuilder.append(":\r\n");
            stringBuilder.append("      tag_84:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.aid);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 16\r\n");
            stringBuilder.append("      tag_94:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 252\r\n");
            stringBuilder.append("      tag_9C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.trsType));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_5F24:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string2);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 3\r\n");
            stringBuilder.append("      tag_5F2A:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%04d", object.currencyCode));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F01:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.acquirerId);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 6\r\n");
            stringBuilder.append("      tag_9F06:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.aid);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 16\r\n");
            stringBuilder.append("      tag_9F09:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.appVersionNumber.substring(object.appVersionNumber.length() - 4));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F1B:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalFloorLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F1D:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalRiskMgmtData);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 8\r\n");
            stringBuilder.append("      tag_9F35:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.terminalType);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_9F40:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.additionnalTerminalCapabilities);
            stringBuilder.append("\"\r\n");
            if (object.tranCategoryCode > 0) {
                stringBuilder.append("      tag_9F53:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.tranCategoryCode);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("      tag_9F65:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string3);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 2\r\n");
            stringBuilder.append("      tag_9F66:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.ttq);
            stringBuilder.append("\"\r\n");
            if (object.expressPayTerminalCapabilities != null) {
                stringBuilder.append("      tag_9F6D:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.expressPayTerminalCapabilities);
                stringBuilder.append("\"\r\n");
            }
            if (object.expressPayTerminalTransactionCapabilities != null) {
                stringBuilder.append("      tag_9F6E:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.expressPayTerminalTransactionCapabilities);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("      tag_9F7E:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string4);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("                max_length: 1\r\n");
            stringBuilder.append("      tag_DF810C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.kernelId));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8118:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.chipCapabilityCVMReq);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8119:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.chipCapabilityNoCVM);
            stringBuilder.append("\"\r\n");
            String cfr_ignored_0 = object.defaultUDOL;
            stringBuilder.append("      tag_DF811B:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.kernelConfiguration);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(string5);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811D:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(String.format("%02d", object.maxNumberTornTrs));
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811E:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.magCapabilityCVMReq);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF811F:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.securityCapability);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8120:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacDefault);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8121:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacDenial);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8122:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.tacOnline);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8123:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessFloorLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8124:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessTransactionLimitNoOnDevice);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8125:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerContactlessTransactionLimitOnDevice);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF8126:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.readerCVMRequiredLimit);
            stringBuilder.append("\"\r\n");
            stringBuilder.append("      tag_DF812C:\r\n");
            stringBuilder.append("                value: \"");
            stringBuilder.append(object.magCapabilityNoCVM);
            stringBuilder.append("\"\r\n");
            if (object.defaultDDOL != null) {
                stringBuilder.append("      tag_DFDF18:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.defaultDDOL);
                stringBuilder.append("\"\r\n");
            }
            if (object.defaultTDOL != null) {
                stringBuilder.append("      tag_DFDF19:\r\n");
                stringBuilder.append("                value: \"");
                stringBuilder.append(object.defaultTDOL);
                stringBuilder.append("\"\r\n");
            }
            stringBuilder.append("\r\n");
        }
        stringBuilder.insert(0, UCube.createFirstPartForKernel3(yP_TCD_DCC_Business, n2));
        try {
            FileOutputStream iOException = new FileOutputStream("ucube_nfc_paywave_param.yaml");
            iOException.write(stringBuilder.toString().getBytes());
            iOException.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private static String createFirstPartForKernel3(YP_TCD_DCC_Business yP_TCD_DCC_Business, int n) {
        String string = "02";
        String string2 = "";
        String string3 = String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode()));
        String string4 = "";
        String string5 = "0250";
        String string6 = "";
        String string7 = "3132333435363738";
        String string8 = "";
        String string9 = "0001";
        String string10 = "416C63696E656F204B65726E656C";
        String string11 = "602048";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("settings:\r\n\r\n");
        stringBuilder.append("  terminal:\r\n\r\n");
        stringBuilder.append("    terminal0:\r\n");
        stringBuilder.append("      tag_5F36:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_5F57:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 1\r\n");
        stringBuilder.append("      tag_9F15:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string3);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F16:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string4);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 15\r\n");
        stringBuilder.append("      tag_9F1A:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string5);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F1C:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string6);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 8\r\n");
        stringBuilder.append("      tag_9F1E:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string7);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F33:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string11);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 3\r\n");
        stringBuilder.append("      tag_9F4E:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string8);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 256\r\n");
        stringBuilder.append("      tag_9F6D:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string9);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_9F7C:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(string10);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 20\r\n");
        stringBuilder.append("      tag_DF8117:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF811A:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(defaultUDOL);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_D000:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(String.format("%02X", n));
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_D001:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF00:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(Kernel3DefaultReaderContactlessTransactionLimit);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF01:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(Kernel3DefaultReaderContactlessCVMLimit);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DF02:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append(Kernel3DefaultReaderContactlessFloorLimit);
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF02:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("9F029F039F265F2482505A5F349F129F369F079F099F279F34849F1E9F109F119F249F339F1A9F3595579F535F2A9A9C9F37");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 128\r\n");
        stringBuilder.append("      tag_DFDF03:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("509F12849F119F6D9F24569F6B");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("                max_length: 128\r\n");
        stringBuilder.append("      tag_DFDF14:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00003A98");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF15:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("00000001");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF15:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("1024");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("      tag_DFDF21:\r\n");
        stringBuilder.append("                value: \"");
        stringBuilder.append("0000");
        stringBuilder.append("\"\r\n");
        stringBuilder.append("\r\n");
        return stringBuilder.toString();
    }

    static class ConfigObject {
        List<CtlsCombination> ctlsCombinationList = new ArrayList<CtlsCombination>();
        List<LimitSet> ctlsLimitSetList = new ArrayList<LimitSet>();
        String forbiddenProducts;

        ConfigObject() {
        }
    }

    static class CtlsCombination
    implements Comparable<CtlsCombination> {
        int trsType;
        int kernelId;
        String aid;
        String terminalCapabilities;
        String additionnalTerminalCapabilities;
        String terminalType;
        String countryCode;
        String merchantCategoryCode;
        String merchantIdentifier;
        String appVersionNumber;
        String terminalIdentification;
        String merchantNameLocation;
        String acquirerId;
        String ttq;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int extendedSelectionSupportFlag;
        int maxNumberTornTrs;
        String terminalFloorLimit;
        String readerContactlessFloorLimit;
        String readerCtlsTrnsLimit;
        String readerContactlessTransactionLimitNoOnDevice;
        String readerContactlessTransactionLimitOnDevice;
        String readerCVMRequiredLimit;
        int statusCheckSupportFlag;
        int currencyCode;
        int priority;
        String chipCapabilityCVMReq;
        String chipCapabilityNoCVM;
        String magCapabilityNoCVM;
        String magCapabilityCVMReq;
        String tacDefault;
        String tacDenial;
        String tacOnline;
        String kernelConfiguration;
        String securityCapability;
        String cardDataInputCapability;
        int tranCategoryCode;
        String terminalRiskMgmtData;
        String endUserSupportedLanguage;
        String expressPayTerminalCapabilities;
        String expressPayTerminalTransactionCapabilities;
        String defaultDDOL;
        String defaultTDOL;
        String defaultUDOL;

        CtlsCombination() {
        }

        @Override
        public int compareTo(CtlsCombination ctlsCombination) {
            return this.kernelId - ctlsCombination.kernelId;
        }
    }

    static class LimitSet {
        int kernelId;
        String currencyCode;
        String appProgramId;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int statusCheckSupportFlag;
        String readerCVMRequiredLimit;
        String readerCtlsFloorLimit;
        String readerCtlsTranLimit;
        String readerCtlsTermFloorLimit;
        String currencyExponent;

        LimitSet() {
        }
    }
}

