/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_GlobalComponent;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.YP_Service;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.extension.bin.YP_TCD_DCB_Interface_BIN;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.currency.YP_TCD_DCB_Interface_Currency;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.extension.time.YP_TCD_DCB_Host_Time;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Account;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_IHM;
import org.yp.framework.ondemandcomponents.pos.interfaces.YP_PROT_Update;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.framework.services.YP_TS_Listener;
import org.yp.framework.transactions.appselector.Albert;
import org.yp.framework.transactions.appselector.ApduHandler;
import org.yp.framework.transactions.appselector.BinList;
import org.yp.framework.transactions.appselector.BlackList;
import org.yp.framework.transactions.appselector.DuplicatedHandler;
import org.yp.framework.transactions.appselector.FAPI;
import org.yp.framework.transactions.appselector.GlobalSummaryReport;
import org.yp.framework.transactions.appselector.NovelPayPAL;
import org.yp.framework.transactions.appselector.Prolin;
import org.yp.framework.transactions.appselector.RefundHandler;
import org.yp.framework.transactions.appselector.SPm2x;
import org.yp.framework.transactions.appselector.SessionSummaryReport;
import org.yp.framework.transactions.appselector.StandardTLV;
import org.yp.framework.transactions.appselector.UCube;
import org.yp.framework.transactions.appselector.info.InfoMonext;
import org.yp.utils.Bitmap;
import org.yp.utils.CryptoUtils;
import org.yp.utils.ExtendedResult;
import org.yp.utils.ExtendedTVR;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.ZipUtils;
import org.yp.utils.enums.ClientCapabilityEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.IdentificationLevelEnumeration;
import org.yp.utils.enums.StoreStatusEnumeration;
import org.yp.utils.enums.TicketTypeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;
import org.yp.utils.enums.sorec.TerminalStatusEnumeration;
import org.yp.xml.jaxb.spxctlcfg.PublicKeyLISTSType;
import org.yp.xml.jaxb.spxctlcfg.PublicKeyRecordType;
import org.yp.xml.jaxb.spxctlcfg.TAGLISTSRecordType;
import org.yp.xml.jaxb.spxctlcfg.TAGLISTSType;
import org.yp.xml.jaxb.spxctlcfg.TAIDAMTRecordType;
import org.yp.xml.jaxb.spxctlcfg.TAIDAMTType;
import org.yp.xml.jaxb.spxctlcfg.TAIDTABRecordType;
import org.yp.xml.jaxb.spxctlcfg.TAIDTABType;
import org.yp.xml.jaxb.spxctlcfg.TCONFRecordType;
import org.yp.xml.jaxb.spxctlcfg.TCONFType;
import org.yp.xml.jaxb.spxctlcfg.TDRLRecordType;
import org.yp.xml.jaxb.spxctlcfg.TDRLType;
import org.yp.xml.jaxb.spxctlcfg.Terminal;
import org.yp.xml.jaxb.ypproperties.Property;

public class YP_BT_WEB_Mobile
extends YP_Transaction {
    private YP_GlobalComponent contactlessSPCParser = null;
    private String requestAPPTags = null;
    private TLVHandler requestAPPTagsHandler = null;
    private Terminal spxxxCfgData = null;
    private PublicKeyLISTSType publicKeyLISTS = null;
    private static final String defaultAdditionalTerminalCapabilities = "600080A001";
    private static final String defaultUDOL = "9F6A04";
    private static final String NEPTING = "1";
    private static final String SNCF = "3";
    private static final byte[] terminalCapabilitiesMCMagstripe;
    private static final byte[] terminalCapabilitiesMC;
    private static final byte[] terminalCapabilitiesNoCVMMC;
    private static final byte[] terminalCapabilitiesVISA;
    private static final byte[] terminalCapabilitiesNoCVMVISA;
    private static final byte[] defaultTerminalCapabilities;
    private static final byte[] defaultTerminalCapabilitiesNoCVM;
    private static final String defaultVISATTQ = "32204000";
    private static final String defaultVISARefunTTQ = "22800000";
    private static final byte[] terminalCapabilitiesAMEX;
    final byte CLL3_RDR_NO_LOAD_CAPK_ON_SAVE = 1;
    final byte CLL3_RDR_MULTI_VERLIST = (byte)2;
    final byte CLL3_RDR_MULTI_DYNLIM = (byte)4;
    final byte CLL3_RDR_EVENT_OUTCOME = (byte)8;
    final byte CLL3_RDR_PARAM_DISABLE_SOUND = 1;
    final byte CLL3_RDR_PARAM_CK_TAG_DF61 = (byte)4;
    final byte CLL3_RDR_PARAM_TERM_PRIORITY_SUPPORT = (byte)8;
    final byte CLL3_RDR_PARAM_CK_EXCEPTION = (byte)16;
    final byte CLL3_RDR_PARAM_CUSTOM_LIST = (byte)32;
    final byte CLL3_RDR_PARAM_MAX_LIMITS = (byte)64;
    final byte CLL3_RDR_PARAM_FLUSH_CONFIG = (byte)-128;
    private final byte CLL3_STAT_CHECK = 1;
    private final byte CLL3_STAT_OK = (byte)2;
    private final byte CLL3_ZERO_CHECK = (byte)4;
    private final byte CLL3_ZERO_OK = (byte)8;
    private final byte CLL3_ZERO_RULE = (byte)16;
    private final byte CLL3_CFL_CHECK = (byte)32;
    private final byte CLL3_CTL_CHECK = (byte)64;
    private final byte CLL3_CVL_CHECK = (byte)-128;
    private final byte CLL3_EMV_SUPTD = 1;
    private final byte CLL3_MSD_SUPTD = (byte)2;
    private final byte CLL3_PARTIAL_MATCH = (byte)4;
    private final byte CLL3_ONDEVICE_CVM = (byte)8;
    private final byte CLL3_DF61_AID_SUPPORT = (byte)16;
    private final byte CLL3_TTQ_PRESENT = 1;
    private final byte CLL3_VISA_PPROC = (byte)2;
    private final byte CLL3_CFG_REBOOT = (byte)4;
    private final byte CLL3_CFG_NOCFM = (byte)8;
    private final byte CLL3_DRL_SUPTD = (byte)16;
    private final byte CLL3_AMEX_PROC = (byte)32;
    private final byte CLL3_LOA_OK = (byte)64;
    private final byte CLL3_MCD_PROC = (byte)-128;
    private final byte LIM_TXN_SALE = 1;
    private final byte LIM_TXN_CASH = (byte)2;
    private final byte LIM_TXN_CASHBK = (byte)4;
    private final byte LIM_TXN_REFUND = (byte)8;
    private final byte LIM_TFL_PRESENT = 1;
    private final byte LIM_CFL_PRESENT = (byte)2;
    private final byte LIM_CTL_PRESENT = (byte)4;
    private final byte LIM_CVL_PRESENT = (byte)8;
    private final byte LIM_CTL2_PRESENT = (byte)16;
    private final byte LIM_KID_PRESENT = (byte)32;
    private final byte LIM_FTD_PRESENT = (byte)64;
    private final Map<Integer, KernelCtlConfig> kernelCtlConfigList = new HashMap<Integer, KernelCtlConfig>();
    private int kernelCtlConfigIndex = 0;
    private final Map<Integer, AmountLimitConfig> amountLimitConfigList = new HashMap<Integer, AmountLimitConfig>();
    private int amountLimitConfigIndex = 0;
    private final Map<Integer, DynamicLimitConfig> dynamicLimitConfigList = new HashMap<Integer, DynamicLimitConfig>();
    private int dynamicLimitConfigIndex = 0;
    private IdentificationLevelEnumeration userIdentificationLevel = IdentificationLevelEnumeration.UNKNOWN;
    private boolean biosVersionNotReceived = false;
    private boolean appCBVersionNotReceived = false;
    private static final int IPN_STANDARD = 1;
    private static final int IPN_CULTURA_BUGGED = 2;
    private static final int IPN_CULTURA_OK = 3;
    private static final String CLIENT_PROPERTIES_PREFIX = "CLI_";
    private static Boolean countryManagerPresent;
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration;
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$RESULT_TYPE;
    private static volatile /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration;

    static {
        byte[] byArray = new byte[3];
        byArray[0] = 96;
        byArray[1] = 32;
        terminalCapabilitiesMCMagstripe = byArray;
        terminalCapabilitiesMC = new byte[]{96, 32, 8};
        terminalCapabilitiesNoCVMMC = new byte[]{96, 8, 8};
        terminalCapabilitiesVISA = new byte[]{96, 32, 64};
        terminalCapabilitiesNoCVMVISA = new byte[]{96, 40, 64};
        defaultTerminalCapabilities = new byte[]{96, 32, -56};
        defaultTerminalCapabilitiesNoCVM = new byte[]{96, 40, -56};
        terminalCapabilitiesAMEX = new byte[]{96, -88, -56};
    }

    public YP_BT_WEB_Mobile(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
    }

    @Override
    public String toString() {
        return "EPayment";
    }

    @Override
    public String getVersion() {
        return "V1.4.0.13";
    }

    public void stop() {
        if (this.getDataContainerTransaction() != null) {
            String string = this.getDataContainerTransaction().getEFTResponse(this);
            if (string != null && this.getClientConnectionHandler() != null) {
                if (this.getLogLevel() == 5) {
                    this.logger(5, "|| RESPONSE TO SEND ||\n" + string);
                } else if (this.getLogLevel() == 4) {
                    if (string.length() < 10000) {
                        this.logger(4, "|| RESPONSE TO SEND ||\n" + string);
                    } else {
                        this.logger(4, "|| TRUNCATED RESPONSE TO SEND ||\n" + string.substring(0, 10000));
                    }
                }
                this.getClientConnectionHandler().send(string);
            }
            this.getDataContainerTransaction().shutdown();
            this.setDataContainerTransaction(null);
        }
    }

    public void close() {
        this.stop();
        if (this.getClientConnectionHandler() != null) {
            this.getClientConnectionHandler().shutdown();
            this.setClientConnectionHandler(null);
        }
        this.shutdown();
    }

    void callSelectedApplication(YP_TCD_DCC_Business yP_TCD_DCC_Business, boolean bl) throws Exception {
        String string;
        String string2 = this.getContractIdentifier();
        boolean bl2 = this.setContractIdentifier(yP_TCD_DCC_Business.getContractIdentifier());
        if (bl2 && this.getLogLevel() >= 4 && (string = this.getDataContainerTransaction().getProtocolEFT().getInitialRequest()) != null) {
            this.logger(4, UtilsYP.requestWithoutSensitiveData(string));
        }
        this.getDataContainerTransaction().setContractIdentifier(this.getContractIdentifier());
        this.callDealTransaction(yP_TCD_DCC_Business);
        if (bl) {
            this.setContractIdentifier(string2);
            this.getDataContainerTransaction().setContractIdentifier(string2);
        }
    }

    private void dealOneRequest() throws Exception {
        Object object;
        int n;
        Object object2;
        Object object3;
        Object object4;
        Object object5;
        try {
            object5 = this.getDataContainerTransaction().getContractIdentifier();
            this.setContractIdentifier((String)object5);
            if (this.getLogLevel() >= 4 && ((String)object5).split("_").length == 4 && (object4 = this.getDataContainerTransaction().getProtocolEFT().getInitialRequest()) != null) {
                this.logger(4, UtilsYP.requestWithoutSensitiveData((String)object4));
            }
            if (this.getLogLevel() >= 5) {
                this.logger(5, "Run(): Application name:" + (String)object5);
            }
        }
        catch (Exception exception) {
            this.logger(2, "run() mandatory parameter contractIdentifier Missing !!!", exception);
            return;
        }
        this.requestAPPTags = this.getDataContainerTransaction().commonHandler.getRequestAppTags();
        if (this.requestAPPTags == null || this.requestAPPTags.isEmpty()) {
            this.requestAPPTagsHandler = null;
        } else {
            try {
                this.requestAPPTagsHandler = new TLVHandler(this.requestAPPTags);
                if (this.requestAPPTagsHandler != null) {
                    Object object6;
                    object5 = this.requestAPPTagsHandler.getTLV(-538738384);
                    if (object5 != null) {
                        this.getDataContainerTransaction().setCashierID(new String(((TLV)object5).value));
                    }
                    if ((object4 = this.requestAPPTagsHandler.getTLV(-538803956)) != null) {
                        long l = TLVHandler.getLong(((TLV)object4).value);
                        object6 = (String)this.getPluginByName("TokenManager").dealRequest(this, "getClearValue", l);
                        if (object6 != null) {
                            this.getDataContainerTransaction().accountHandler.setAccountIdentifier((String)object6);
                            this.getDataContainerTransaction().accountHandler.setMaskedAccountIdentifier(UtilsYP.maskPAN((String)object6));
                            YP_TCD_DCC_Business.setIDToken(this.getDataContainerTransaction(), l);
                        }
                    }
                    if ((object3 = this.requestAPPTagsHandler.getTLV(14672642)) != null) {
                        object2 = UtilsYP.devHexa(((TLV)object3).value);
                        object6 = new ExtendedTVR((String)object2);
                        this.getDataContainerTransaction().setExtendedTVR((ExtendedTVR)object6);
                    }
                    if (DuplicatedHandler.performChecks(this, this.requestAPPTagsHandler) == 1) {
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                        return;
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "run(): ", exception);
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(7));
                return;
            }
        }
        this.printDebugInformations();
        this.checkNepSign(this.getDataContainerTransaction());
        try {
            object5 = this.getDataContainerTransaction().accountHandler.getCustomerIPAddress();
            if (object5 != null && !((String)object5).isEmpty() && (object4 = this.getCountryManager()) != null) {
                object3 = (String)((YP_Object)object4).dealRequest(this, "getCountryNameFR", object5);
                if (object3 == null || ((String)object3).isEmpty()) {
                    this.logger(3, "run() unknown country");
                } else {
                    YP_TCD_DCC_Business.setCountryName(this.getDataContainerTransaction(), (String)object3);
                }
            }
        }
        catch (Exception exception) {
            this.logger(3, "run() unknown country", exception);
        }
        object5 = this.getDataContainerTransaction().getSubRequestType();
        if (this.getDataContainerTransaction().getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Login && object5 != null && object5 == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Change) {
            this.doChangePassword();
            return;
        }
        if (this.getDataContainerTransaction().getRequestType() == YP_TCD_PosProtocol.REQUEST_TYPE.Login && object5 != null && object5 == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Reset) {
            this.doResetPassword();
            return;
        }
        this.doAuthentification();
        block7 : switch (this.userIdentificationLevel) {
            case NONE: 
            case PASSWORD: 
            case TOKEN: {
                break;
            }
            case PERMANENT_TOKEN: {
                switch (this.getDataContainerTransaction().getRequestType()) {
                    case Reprint: 
                    case Report: 
                    case GetData: {
                        break block7;
                    }
                }
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(102));
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "run() authentification : no right to do this request using permanent token");
                }
                return;
            }
            case BLOCKED: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(61));
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "run() authentification : Account blocked for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            case EXPIRED_PASSWORD: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(66));
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "run() authentification password has expired for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            case EXPIRED_SESSION: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(62));
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "run() authentification session expired for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            case FAILED: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(60));
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "run() authentification failed :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            case ACCOUNT_UNKNOWN: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(64));
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "run() Account unknown for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            case EMPTY_ACCESS: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(65));
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "run() authentification succeeded but no access found  for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
            default: {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(63));
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "run() authentification error for :" + this.getDataContainerTransaction().userHandler.getUserUID());
                }
                return;
            }
        }
        if (this.requestAPPTagsHandler != null && (object4 = this.requestAPPTagsHandler.getTLV(-538738383)) != null) {
            object3 = new String(((TLV)object4).value);
            this.getDataContainerTransaction().userHandler.setUserUID((String)object3);
        }
        if (object5 != null && object5 == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ApduCommands) {
            object4 = new ApduHandler();
            ((ApduHandler)object4).getApduDataFromProtocol(this.getDataContainerTransaction());
        }
        if (this.getDataContainerTransaction().accountHandler.isLoadAccountPostponed()) {
            this.getDataContainerTransaction().accountHandler.readRequest();
        }
        if (this.getDataContainerTransaction().reservationHandler.isLoadReferenceDetailsPostponed()) {
            this.getDataContainerTransaction().reservationHandler.readRequest();
        }
        if (!this.getDataContainerTransaction().getContractIdentifier().contentEquals("KERNEL") && !this.getDataContainerTransaction().getContractIdentifier().startsWith("GROUP")) {
            try {
                object4 = this.getDataContainerTransaction().getDataContainerBrand();
                boolean bl = ((YP_TCD_DCC_Brand)object4).isValidRequest(this);
                if (!bl) {
                    this.logger(2, "run() not validate by brand");
                    return;
                }
            }
            catch (Exception exception) {
                this.logger(3, "run() validate by brand ", exception);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(4));
                return;
            }
        }
        block20 : switch (this.getDataContainerTransaction().getRequestType()) {
            case Shutdown: {
                this.doShutdownRequest();
                return;
            }
            case System: {
                this.doSystemRequest();
                return;
            }
            case Loyalty: {
                if (object5 != null && (object5 == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM || object5 != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Authorization || object5 != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.AuthorizationAndCompletion || object5 != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion)) break;
                this.doLoyaltyRequest();
                return;
            }
            case Report: {
                switch (this.getDataContainerTransaction().getSubRequestType()) {
                    case Diary: {
                        this.doDiaryRequest();
                        return;
                    }
                    case TerminalSummaryReport: {
                        long l = SessionSummaryReport.getTransactionSystemGMTTimeMSFromRequest(this);
                        if (l <= 0L) break block20;
                        SessionSummaryReport.doReport(this, l);
                        return;
                    }
                }
                break;
            }
            case ReprintLastTrs: {
                this.doReprintLastRequest();
                return;
            }
            case Reprint: {
                if (this.requestAPPTagsHandler == null || (object4 = this.requestAPPTagsHandler.getTLV(-538869478)) != null && TLVHandler.getBool(((TLV)object4).value)) break;
                this.doReprint();
                return;
            }
            case Login: {
                this.doLoginRequest();
                return;
            }
            case Logout: {
                this.doLogoutRequest();
                return;
            }
            case GetData: {
                this.doGetDataRequest();
                return;
            }
            case SetData: {
                this.doSetDataRequest();
                return;
            }
            case CreateData: {
                this.doCreateDataRequest();
                return;
            }
            case Reconciliation: 
            case RemoteParameterization: {
                if (UtilsYP.getInstanceRole() == 1) break;
                this.logger(2, "run() Only master can use Closure, Reconciliation or RemoteParameterization");
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(102));
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                return;
            }
            case GlobalSummaryReport: {
                GlobalSummaryReport.doReport(this);
                return;
            }
        }
        int n2 = this.doParameterUpdate(null, false);
        if (n2 == 1) {
            this.dealIOSParamBug(null);
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            this.logger(3, "run() parametrization is required!!!");
            return;
        }
        List<YP_TCD_DCC_Business> list = this.getApplicationList();
        if (list == null) {
            this.logger(2, "run() no application List");
            return;
        }
        if (list.isEmpty()) {
            this.logger(2, "run() application List empty");
            return;
        }
        if (RefundHandler.performChecks(this, this.requestAPPTagsHandler, list) < 0) {
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return;
        }
        object2 = new int[list.size()];
        Object object7 = 0;
        Object object8 = 0;
        if (list.size() == 1 && this.getDataContainerTransaction().getContractIdentifier().contentEquals(list.get(0).getContractIdentifier())) {
            object8 = 1;
            object7 = 9999;
            object2[0] = 9999;
        } else {
            n = 0;
            while (n < list.size()) {
                try {
                    object = list.get(n);
                    object2[n] = ((YP_TCD_DCC_Business)object).isTrsTypeAllowed(this.getDataContainerTransaction()) ? (Object)((YP_TCD_DCC_Business)object).getApplicationPlugin().applicationSelection(this, (YP_TCD_DCC_Business)object, this.getDataContainerTransaction()) : (Object)false;
                    if (object7 < object2[n]) {
                        object7 = object2[n];
                        object8 = 1;
                    } else if (object7 == object2[n]) {
                        ++object8;
                    }
                }
                catch (NoSuchMethodError noSuchMethodError) {
                    this.logger(2, "run() " + noSuchMethodError);
                }
                n += 1;
            }
        }
        if (object7 == 0) {
            this.logger(2, "run() no application elected");
            return;
        }
        if (object8 == 1) {
            n = 0;
            while (n < ((Object)object2).length) {
                if (object2[n] == object7) {
                    this.callSelectedApplication(list.get(n), false);
                    break;
                }
                n += 1;
            }
        } else if (object7 >= 9998) {
            n = 0;
            while (n < ((Object)object2).length) {
                if (object2[n] == object7) {
                    this.callDealTransaction(list.get(n));
                }
                n += 1;
            }
        } else {
            block132: {
                n = 0;
                if (object8 > 1) {
                    try {
                        TLVHandler tLVHandler;
                        TLV tLV;
                        Object object9;
                        Object object10;
                        object = this.getDataContainerTransaction().accountHandler.getADFList();
                        if (object != null && object.size() > 1) {
                            int n3 = Integer.MAX_VALUE;
                            Object object11 = null;
                            object10 = object.iterator();
                            while (object10.hasNext()) {
                                int n4;
                                object9 = (AccountHandler.ADF)object10.next();
                                if (((AccountHandler.ADF)object9).priorityIndicator == null || ((AccountHandler.ADF)object9).priorityIndicator.isEmpty() || (n4 = Integer.parseInt(((AccountHandler.ADF)object9).priorityIndicator)) >= n3) continue;
                                n3 = n4;
                                object11 = object9;
                            }
                            if (object11 != null) {
                                int n5 = 0;
                                while (n5 < ((Object)object2).length) {
                                    List<YP_Row> list2;
                                    if (object2[n5] == object7 && (object10 = (YP_TCD_DCB_Interface_EMV)list.get(n5).getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) != null && (list2 = object10.getAIDList(((AccountHandler.ADF)object11).aid)) != null && !list2.isEmpty()) {
                                        object2[n5] = object7 + 1;
                                    }
                                    ++n5;
                                }
                                object8 = 0;
                                object7 = 0;
                                n5 = 0;
                                while (n5 < list.size()) {
                                    if (object7 < object2[n5]) {
                                        object7 = object2[n5];
                                        object8 = 1;
                                    } else if (object7 == object2[n5]) {
                                        ++object8;
                                    }
                                    ++n5;
                                }
                            }
                        }
                        if (object8 > 1) {
                            try {
                                this.retrieveTerminalRow(list.get(0).getDataContainerMerchant());
                                String string = this.getTerminalType();
                                int n6 = 0;
                                while (n6 < ((Object)object2).length) {
                                    if (object2[n6] == object7) {
                                        object9 = list.get(n6).getApplicationPlugin().getApplicationEnvironmentType();
                                        if (string.contentEquals("22") && ((String)object9).contentEquals("10")) {
                                            Object object12 = object2;
                                            int n7 = n6;
                                            object12[n7] = object12[n7] + true;
                                        } else if (string.contentEquals("25") && ((String)object9).contentEquals("45")) {
                                            Object object13 = object2;
                                            int n8 = n6;
                                            object13[n8] = object13[n8] + true;
                                        }
                                    }
                                    ++n6;
                                }
                                object8 = 0;
                                object7 = 0;
                                n6 = 0;
                                while (n6 < list.size()) {
                                    if (object7 < object2[n6]) {
                                        object7 = object2[n6];
                                        object8 = 1;
                                    } else if (object7 == object2[n6]) {
                                        ++object8;
                                    }
                                    ++n6;
                                }
                            }
                            catch (Exception exception) {
                                this.logger(2, "run() During check if we can increase the priority of MPA / MPE contract ", exception);
                            }
                        }
                        if (object8 <= 1 || this.requestAPPTagsHandler == null || (tLV = this.requestAPPTagsHandler.getTLV(-2064032)) == null || (object9 = (tLVHandler = new TLVHandler(tLV.value)).getTLV(-538803871)) == null || TLVHandler.getDCBInt(((TLV)object9).value) != 1 || (object10 = tLVHandler.getTLV(-538738331)) == null) break block132;
                        String string = new String(((TLV)object10).value, StandardCharsets.UTF_8);
                        int n9 = 0;
                        while (n9 < ((Object)object2).length) {
                            YP_TCD_DCC_Business yP_TCD_DCC_Business;
                            String string2;
                            if (object2[n9] == object7 && (string2 = (yP_TCD_DCC_Business = list.get(n9)).getContractRow().getFieldStringValueByName("contractLabel")).contentEquals(string)) {
                                object2[n9] = ++object7;
                                object8 = 1;
                                break;
                            }
                            ++n9;
                        }
                    }
                    catch (Exception exception) {
                        this.logger(2, "run() ", exception);
                    }
                }
            }
            if (object8 > 1) {
                if (InfoMonext.isMONEXTBrand(this, list.get(0).getDataContainerBrand())) {
                    if (InfoMonext.updatePrecisions(this, list, (int[])object2, object7) > 0) {
                        object7 = 0;
                        int n10 = 0;
                        while (n10 < list.size()) {
                            if (object7 < object2[n10]) {
                                object7 = object2[n10];
                                object8 = 1;
                            } else if (object7 == object2[n10]) {
                                ++object8;
                            }
                            ++n10;
                        }
                    } else {
                        n = 1;
                    }
                } else {
                    if (this.isClientCanPerformAppSelection()) {
                        this.askforAppSelection(list, (int[])object2, (int)object7);
                        return;
                    }
                    this.logger(3, "run() " + object8 + " applications elected. We take the first one...");
                    n = 1;
                }
            }
            int n11 = 0;
            while (n11 < ((Object)object2).length) {
                if (object2[n11] == object7) {
                    this.callSelectedApplication(list.get(n11), n != 0);
                    break;
                }
                ++n11;
            }
        }
        switch (this.getDataContainerTransaction().getRequestType()) {
            case Report: {
                this.handleReportsTicket(list);
                break;
            }
        }
    }

    private void handleReportsTicket(List<YP_TCD_DCC_Business> list) {
        switch (this.getDataContainerTransaction().getRequestType()) {
            case Report: {
                break;
            }
            default: {
                this.logger(2, "handleReportsTicket() is only for reports");
                return;
            }
        }
        String string = this.getDataContainerTransaction().accountHandler.getCustomerMailAddress();
        String string2 = this.getDataContainerTransaction().accountHandler.getCustomerPrimaryPhoneFromRequest();
        if ((string == null || string.isEmpty()) && (string2 == null || string2.isEmpty())) {
            this.logger(4, "handleReportsTicket() Not needed as there is neither email address nore primary phone");
            return;
        }
        String string3 = this.getDataContainerTransaction().getTicket();
        if (string3 == null || string3.isEmpty()) {
            this.logger(4, "handleReportsTicket() Not needed as there is no ticket");
            return;
        }
        if (list == null || list.isEmpty()) {
            this.logger(2, "handleReportsTicket() No dataContainer");
            return;
        }
        if (list.size() > 1) {
            this.logger(2, "handleReportsTicket() Not done as for the moment it's only for when there is but one  dataContainer");
            return;
        }
        YP_TCD_DCC_Business yP_TCD_DCC_Business = list.get(0);
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getDataContainerTransaction().getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.logger(2, "handleReportsTicket() no sub request");
            return;
        }
        switch (sUB_REQUEST_TYPE) {
            case ReconciliationReport: {
                if (string != null && !string.isEmpty()) {
                    yP_TCD_DCC_Business.mailTLCReport(string, "Rapport telecollecte", string3);
                }
                if (string2 == null || string2.isEmpty()) break;
                yP_TCD_DCC_Business.sendSMS(string2, string3);
                break;
            }
            default: {
                this.logger(2, "handleReportsTicket() Ticket not yet handled :" + (Object)((Object)sUB_REQUEST_TYPE));
                return;
            }
        }
    }

    private void callDealTransaction(YP_TCD_DCC_Business yP_TCD_DCC_Business) throws Exception {
        if (this.extraChecksBeforeDealTransaction(yP_TCD_DCC_Business) < 0) {
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return;
        }
        YP_Application yP_Application = yP_TCD_DCC_Business.newApplicationPlugin(this);
        yP_Application.initialize();
        yP_Application.dealRequest(this, "dealTransaction", new Object[0]);
        yP_Application.shutdown();
    }

    private void retrieveTerminalRow(YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant) {
        try {
            if (this.getDataContainerTransaction().getTerminalRow() != null) {
                return;
            }
            if (this.requestAPPTagsHandler == null) {
                return;
            }
            int n = this.getDataContainerTransaction().getRealNLPA();
            if (n > 0) {
                Object object;
                TLV tLV;
                String string = null;
                TLV tLV2 = this.requestAPPTagsHandler.getTLV(16769880);
                if (tLV2 != null && (tLV = ((TLVHandler)(object = new TLVHandler(tLV2.value))).getTLV(14672736)) != null) {
                    string = new String(tLV.value);
                    this.getDataContainerTransaction().setTerminalSerialNumber(string);
                }
                object = yP_TCD_DCC_Merchant.getDataContainerBrand().getTerminalRow(yP_TCD_DCC_Merchant.getIDMerchant(), string);
                this.getDataContainerTransaction().setTerminalRow((YP_Row)object);
            }
        }
        catch (Exception exception) {
            this.logger(3, "extraChecksBeforeDealTransaction() retrieving terminal row", exception);
        }
    }

    private int extraChecksBeforeDealTransaction(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        YP_Row yP_Row;
        Object object;
        if (this.getLogLevel() >= 5 && this.getDataContainerTransaction().getSubRequestType() != null && this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.Completion) {
            this.logger(6, "breakpoint");
        }
        this.retrieveTerminalRow(yP_TCD_DCC_Business.getDataContainerMerchant());
        try {
            int n = this.getDataContainerTransaction().getRealNLPA();
            if (n > 0 && (object = this.getDataContainerTransaction().getTerminalRow()) != null) {
                String string;
                boolean bl = yP_TCD_DCC_Business.getDataContainerBrand().isMPOS((YP_Row)object);
                this.getDataContainerTransaction().setMPosTrs(bl);
                String string2 = object.getFieldStringValueByName("alias");
                if (string2 != null && !string2.isEmpty() && ((string = this.getDataContainerTransaction().commonHandler.getMerchantPOSAlias()) == null || string.isEmpty())) {
                    this.getDataContainerTransaction().commonHandler.setMerchantPOSAlias(string2);
                }
            }
        }
        catch (Exception exception) {
            this.logger(3, "extraChecksBeforeDealTransaction() mposTRS ", exception);
        }
        if ((this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction || this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM || this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC) && (yP_Row = this.getDataContainerTransaction().getTerminalRow()) != null) {
            object = (TerminalStatusEnumeration)((Object)yP_Row.getFieldValueByName("terminalStatus"));
            if (object == null) {
                this.logger(3, "extraChecksBeforeDealTransaction() Not really possible");
            } else {
                switch (YP_BT_WEB_Mobile.$SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration()[((Enum)object).ordinal()]) {
                    case 3: {
                        this.logger(2, "extraChecksBeforeDealTransaction() terminal inactive !!! " + yP_Row.getFieldStringValueByName("terminalSerialNumber"));
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                        YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(72));
                        return -1;
                    }
                }
            }
        }
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void run() {
        try {
            while (true) {
                byte[] byArray;
                if (this.getDataContainerTransaction() == null) {
                    this.setObjectStatus(6);
                    this.setWatchDogTimoutMS(300000);
                    this.iAmAlive();
                    if (this.getClientConnectionHandler().waitRequest(300000) <= 0) {
                        this.logger(5, "Run(): nothing received");
                        return;
                    }
                    this.iAmAlive();
                    this.setObjectStatus(1);
                    this.setDataContainerTransaction((YP_TCD_DC_Transaction)this.newPluginByName(this.dataContainerTransactionName, new Object[0]));
                    this.getDataContainerTransaction().setTransactionProcessFather(this);
                    this.getDataContainerTransaction().initialize();
                }
                if ((byArray = this.getClientConnectionHandler().getInitialRequest()) != null && byArray.length > 0) {
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "Run(): something received");
                    }
                } else {
                    if (this.getLogLevel() < 5) return;
                    this.logger(5, "Run(): nothing received");
                    return;
                }
                int n = this.getDataContainerTransaction().load(byArray, byArray.length);
                if (n != 1) {
                    this.logger(3, "run() failed to load message !!!");
                    return;
                }
                this.dealOneRequest();
                this.stop();
                this.setContractIdentifier("KERNEL");
                continue;
                break;
            }
        }
        catch (Exception exception) {
            this.logger(2, "run()  ", exception);
            return;
        }
        finally {
            this.close();
        }
    }

    public int reload() {
        try {
            int n = (Integer)this.getPluginByName("DataContainerManager").dealRequest(this, "reload", new Object[0]);
            if (n == 1) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            } else if (n == 0) {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            } else {
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            }
            return n;
        }
        catch (Exception exception) {
            this.logger(2, "reload() ", exception);
            return -1;
        }
    }

    public int doSystemRequest() {
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getDataContainerTransaction().getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.logger(2, "doSystemRequest() no sub request");
            return -1;
        }
        switch (sUB_REQUEST_TYPE) {
            case Reload: {
                return this.reload();
            }
        }
        this.logger(2, "doSystemRequest() unknowm sub request " + (Object)((Object)sUB_REQUEST_TYPE));
        return -1;
    }

    private int shutdownWhenIdle() {
        try {
            YP_Object yP_Object;
            int n;
            int n2;
            this.logger(4, "shutdownWhenIdle() Started");
            YP_Service yP_Service = (YP_Service)this.getPluginByName("ProcessLauncher");
            this.setObjectStatus(6);
            long l = this.getDataContainerTransaction().contextHandler.getTimeoutMS();
            if (l < 0L) {
                l = 0L;
            }
            try {
                YP_Service yP_Service2 = (YP_Service)this.getPluginByName("GlobalProcessManager");
                n2 = 0;
                while (n2 < yP_Service2.getChildNB()) {
                    YP_Object yP_Object2 = yP_Service2.getChildByRank(n2);
                    if (yP_Object2 != null && yP_Object2 instanceof YP_TS_Listener) {
                        ((YP_TS_Listener)yP_Object2).stopListenning(l);
                    }
                    ++n2;
                }
                this.logger(4, "shutdownWhenIdle() Stop asked to listener");
                do {
                    n2 = 0;
                    n = 0;
                    while (n < yP_Service2.getChildNB()) {
                        yP_Object = yP_Service2.getChildByRank(n);
                        if (yP_Object != null && yP_Object instanceof YP_TS_Listener && yP_Object.getObjectStatus() == 2) {
                            n2 = 1;
                            break;
                        }
                        ++n;
                    }
                    if (n2 == 0 || l <= 0L) continue;
                    UtilsYP.sleep(100);
                } while (n2 != 0 && !UtilsYP.isTimeout(this.getStartTime(), l));
                this.logger(4, "shutdownWhenIdle() Listeners stopped");
            }
            catch (Exception exception) {
                this.logger(4, "shutdownWhenIdle() ", exception);
            }
            do {
                int n3 = yP_Service.getChildNB();
                n2 = 1;
                n = 0;
                while (n < n3) {
                    yP_Object = yP_Service.getChildByRank(n);
                    if (yP_Object != null && yP_Object.getObjectStatus() != 6) {
                        n2 = 0;
                        break;
                    }
                    ++n;
                }
                if (n2 != 0) {
                    this.logger(3, "shutdownWhenIdle() There are only idle process, we can exit...");
                    this.dumpStackTraces();
                    this.dumpStackTracesNew();
                    System.exit(0);
                }
                if (l <= 0L) continue;
                UtilsYP.sleep(100);
            } while (!UtilsYP.isTimeout(this.getStartTime(), l));
            this.logger(2, "shutdownWhenIdle() Unable to find a hole to stop the server");
            this.dumpStackTraces();
            this.dumpStackTracesNew();
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "shutdownWhenIdle() ", exception);
            return -1;
        }
    }

    private int closeCXAndShutdownWhenIdle() {
        try {
            this.logger(2, "closeCXAndShutdownWhenIdle() TODO");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return -1;
        }
        catch (Exception exception) {
            this.logger(2, "closeCXAndShutdownWhenIdle() ", exception);
            return -1;
        }
    }

    private int forcedShutdown() {
        try {
            this.logger(2, "forcedShutdown() Bonzai !!!");
            System.exit(0);
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "forcedShutdown() ", exception);
            return -1;
        }
    }

    private void dumpStackTraces() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
            Set<Thread> set = map.keySet();
            for (Thread thread : set) {
                stringBuilder.append("Trace information for the thread ");
                stringBuilder.append(thread);
                stringBuilder.append(UtilsYP.lineSeparator);
                StackTraceElement[] stackTraceElementArray = map.get(thread);
                int n = 0;
                while (n < stackTraceElementArray.length) {
                    stringBuilder.append(stackTraceElementArray[n]);
                    stringBuilder.append(UtilsYP.lineSeparator);
                    ++n;
                }
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            System.out.println(stringBuilder.toString());
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {}
    }

    ThreadInfo getThreadInfo(long l) {
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        if (!threadMXBean.isObjectMonitorUsageSupported() || !threadMXBean.isSynchronizerUsageSupported()) {
            return threadMXBean.getThreadInfo(l);
        }
        ThreadInfo[] threadInfoArray = threadMXBean.getThreadInfo(new long[]{l}, true, true);
        if (threadInfoArray.length == 0) {
            return null;
        }
        return threadInfoArray[0];
    }

    private void dumpStackTracesNew() {
        try {
            ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
            StringBuilder stringBuilder = new StringBuilder();
            Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
            Set<Thread> set = map.keySet();
            for (Thread thread : set) {
                stringBuilder.append("Trace information for the thread ");
                stringBuilder.append(thread);
                stringBuilder.append(" CPU TIME :");
                float f = 0.0f;
                long l = threadMXBean.getThreadCpuTime(thread.getId());
                if (l > 0L) {
                    f = l / 100000L;
                    f /= 1000.0f;
                }
                stringBuilder.append(f);
                stringBuilder.append(UtilsYP.lineSeparator);
                StackTraceElement[] stackTraceElementArray = map.get(thread);
                int n = 0;
                while (n < stackTraceElementArray.length) {
                    stringBuilder.append(stackTraceElementArray[n]);
                    stringBuilder.append(UtilsYP.lineSeparator);
                    ++n;
                }
                stringBuilder.append(UtilsYP.lineSeparator);
            }
            System.out.println(stringBuilder.toString());
            this.logger(4, stringBuilder.toString());
        }
        catch (Exception exception) {}
    }

    public int doShutdownRequest() {
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getDataContainerTransaction().getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.logger(2, "doShutdownRequest() no sub request");
            return -1;
        }
        this.dumpStackTraces();
        this.dumpStackTracesNew();
        switch (sUB_REQUEST_TYPE) {
            case ShutdownWhenIdle: {
                return this.shutdownWhenIdle();
            }
            case ForcedShutdown: {
                return this.forcedShutdown();
            }
            case CloseCXAndShutdownWhenIdle: {
                return this.closeCXAndShutdownWhenIdle();
            }
        }
        this.logger(2, "doShutdownRequest() unknowm sub request " + (Object)((Object)sUB_REQUEST_TYPE));
        return -1;
    }

    private int getCustomerData(YP_PROT_Account yP_PROT_Account) {
        int n;
        long l;
        block14: {
            block13: {
                l = this.getDataContainerTransaction().accountHandler.getCustomerIdentifier();
                if (l != 0L) break block13;
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "getCustomerData() mandatory parameter Customer Identifier missing");
                }
                return -1;
            }
            n = this.getDataContainerTransaction().accountHandler.load(null);
            if (n >= 0) break block14;
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getCustomerData() unable to get mop list for customer:" + l);
            }
            return -1;
        }
        try {
            List<YP_Row> list;
            if (n == 0) {
                if (this.getLogLevel() >= 3) {
                    this.logger(3, "getCustomerData() no mop found for customer " + l);
                }
            } else if (n > 0 && this.getLogLevel() >= 5) {
                this.logger(5, "getCustomerData() MOPs loaded");
            }
            if ((list = this.getDataContainerTransaction().accountHandler.getCurrentMOPRowList()) != null && !list.isEmpty()) {
                int n2 = list.size() - 1;
                while (n2 >= 0) {
                    n = (Integer)list.get(n2).getFieldValueByName("status");
                    if (n == 0) {
                        list.remove(n2);
                    }
                    --n2;
                }
            }
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "getCustomerData() ", exception);
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
    }

    private int addCustomerData(YP_PROT_Account yP_PROT_Account) {
        block7: {
            block6: {
                try {
                    this.getDataContainerTransaction().accountHandler.setCustomerStatus(1);
                    long l = this.getDataContainerTransaction().accountHandler.getIDMeanOfPayment();
                    if (l <= 0L) break block6;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "addCustomerData() update not allowed");
                    }
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    return -1;
                }
                catch (Exception exception) {
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "addCustomerData()  ", exception);
                    }
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                    return -1;
                }
            }
            int n = this.getDataContainerTransaction().accountHandler.persist();
            if (n >= 0) break block7;
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        return 1;
    }

    private int deleteCustomerData(YP_PROT_Account yP_PROT_Account) {
        block9: {
            int n;
            block8: {
                block7: {
                    try {
                        long l = this.getDataContainerTransaction().accountHandler.getCustomerIdentifier();
                        if (l != 0L) break block7;
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        this.logger(2, "deleteCustomerData() mandatory parameter Customer Identifier missing");
                        return -1;
                    }
                    catch (Exception exception) {
                        this.logger(2, "deleteCustomerData()  ", exception);
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        return -1;
                    }
                }
                if (this.getDataContainerTransaction().accountHandler.getMeanOfPaymentDatasReceived() == 2) {
                    this.getDataContainerTransaction().accountHandler.setAccountStatus(0);
                }
                if (this.getDataContainerTransaction().accountHandler.getMeanOfPaymentDatasReceived() != 1) break block8;
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                this.logger(2, "deleteCustomerData() One can't send MOP datas without identifier for delete");
                return -1;
            }
            if (this.getDataContainerTransaction().accountHandler.getMeanOfPaymentDatasReceived() == 0) {
                this.getDataContainerTransaction().accountHandler.setCustomerStatus(0);
            }
            if ((n = this.getDataContainerTransaction().accountHandler.persist()) >= 0) break block9;
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        return 1;
    }

    public int doLoyaltyRequest() {
        YP_TCD_PosProtocol yP_TCD_PosProtocol = this.getDataContainerTransaction().getProtocolEFT();
        if (yP_TCD_PosProtocol == null) {
            return -1;
        }
        if (!(yP_TCD_PosProtocol instanceof YP_PROT_Account)) {
            this.logger(2, "doLoyaltyRequest() bad interface");
            return -1;
        }
        YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE = this.getDataContainerTransaction().getSubRequestType();
        if (sUB_REQUEST_TYPE == null) {
            this.logger(2, "doLoyaltyRequest() no sub request");
            return -1;
        }
        switch (sUB_REQUEST_TYPE) {
            case GetCustomerData: {
                return this.getCustomerData((YP_PROT_Account)((Object)yP_TCD_PosProtocol));
            }
            case AddCustomerData: {
                return this.addCustomerData((YP_PROT_Account)((Object)yP_TCD_PosProtocol));
            }
            case DeleteCustomerData: {
                return this.deleteCustomerData((YP_PROT_Account)((Object)yP_TCD_PosProtocol));
            }
        }
        this.logger(2, "doLoyaltyRequest() unknowm sub request " + (Object)((Object)sUB_REQUEST_TYPE));
        return -1;
    }

    private int doAuthentification() {
        block16: {
            StringBuilder stringBuilder;
            String string;
            YP_Object yP_Object;
            block14: {
                block15: {
                    block13: {
                        block12: {
                            try {
                                this.userIdentificationLevel = IdentificationLevelEnumeration.NONE;
                                yP_Object = this.getPluginByName("User");
                                if (yP_Object != null) break block12;
                                this.logger(3, "doAuthentification() no plugin available");
                                return 0;
                            }
                            catch (Exception exception) {
                                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                                this.logger(2, "doAuthentification()  ", exception);
                                return -1;
                            }
                        }
                        string = this.getDataContainerTransaction().userHandler.getUserUID();
                        if (string != null && !string.isEmpty()) break block13;
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "doAuthentification() no uid available");
                        }
                        return 0;
                    }
                    String string2 = this.getDataContainerTransaction().userHandler.getUserPasswd();
                    stringBuilder = new StringBuilder();
                    if (string2 == null || string2.isEmpty()) break block14;
                    this.userIdentificationLevel = (IdentificationLevelEnumeration)((Object)yP_Object.dealRequest(this, "authenticate", string, string2, null, stringBuilder));
                    if (stringBuilder != null && stringBuilder.length() > 0) {
                        this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
                    }
                    if (this.userIdentificationLevel != IdentificationLevelEnumeration.PASSWORD) break block15;
                    return 1;
                }
                if (this.userIdentificationLevel == IdentificationLevelEnumeration.EXPIRED_PASSWORD) {
                    return -2;
                }
                return -1;
            }
            String string3 = this.getDataContainerTransaction().userHandler.getUserToken();
            if (string3 == null || string3.isEmpty()) break block16;
            this.userIdentificationLevel = (IdentificationLevelEnumeration)((Object)yP_Object.dealRequest(this, "authenticate", string, null, string3, stringBuilder));
            if (stringBuilder != null && stringBuilder.length() > 0) {
                this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
            }
            if (this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN || this.userIdentificationLevel == IdentificationLevelEnumeration.PERMANENT_TOKEN) {
                return 1;
            }
            return -1;
        }
        this.userIdentificationLevel = IdentificationLevelEnumeration.FAILED;
        return -1;
    }

    private int doChangePassword() {
        StringBuilder stringBuilder;
        block12: {
            block13: {
                String string;
                YP_Object yP_Object;
                block11: {
                    block10: {
                        try {
                            this.userIdentificationLevel = IdentificationLevelEnumeration.NONE;
                            yP_Object = this.getPluginByName("User");
                            if (yP_Object != null) break block10;
                            this.logger(3, "doChangePassword() no plugin available");
                            return 0;
                        }
                        catch (Exception exception) {
                            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                            this.logger(2, "doChangePassword()  ", exception);
                            return -1;
                        }
                    }
                    string = this.getDataContainerTransaction().userHandler.getUserUID();
                    if (string != null && !string.isEmpty()) break block11;
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "doChangePassword() no uid available");
                    }
                    return 0;
                }
                String string2 = this.getDataContainerTransaction().userHandler.getNewPasswd();
                String string3 = this.getDataContainerTransaction().userHandler.getUserPasswd();
                stringBuilder = new StringBuilder();
                if (string3 == null || string3.isEmpty() || string2 == null || string2.isEmpty()) break block12;
                this.userIdentificationLevel = (IdentificationLevelEnumeration)((Object)yP_Object.dealRequest(this, "changePassword", string, string3, string2, stringBuilder));
                if (this.userIdentificationLevel != IdentificationLevelEnumeration.PASSWORD) break block13;
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
                if (stringBuilder != null && stringBuilder.length() > 0) {
                    this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
                }
                return 1;
            }
            this.userIdentificationLevel = IdentificationLevelEnumeration.FAILED;
            if (stringBuilder != null && stringBuilder.length() > 0) {
                this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
            }
            return -1;
        }
        this.userIdentificationLevel = IdentificationLevelEnumeration.FAILED;
        if (stringBuilder != null && stringBuilder.length() > 0) {
            this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
        }
        return -1;
    }

    private int doResetPassword() {
        block8: {
            String string;
            YP_Object yP_Object;
            block7: {
                block6: {
                    try {
                        this.userIdentificationLevel = IdentificationLevelEnumeration.NONE;
                        yP_Object = this.getPluginByName("User");
                        if (yP_Object != null) break block6;
                        this.logger(2, "doResetPassword() no plugin available");
                        return -1;
                    }
                    catch (Exception exception) {
                        YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                        this.logger(2, "doResetPassword()  ", exception);
                        return -1;
                    }
                }
                string = this.getDataContainerTransaction().userHandler.getUserUID();
                if (string != null && !string.isEmpty()) break block7;
                this.logger(2, "doResetPassword() no uid available");
                return 0;
            }
            StringBuilder stringBuilder = new StringBuilder();
            this.userIdentificationLevel = (IdentificationLevelEnumeration)((Object)yP_Object.dealRequest(this, "resetPassword", string, stringBuilder));
            if (stringBuilder != null && stringBuilder.length() > 0) {
                this.getDataContainerTransaction().userHandler.setUserMessage(stringBuilder.toString());
            }
            if (this.userIdentificationLevel != IdentificationLevelEnumeration.UNKNOWN) break block8;
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        this.logger(2, "doResetPassword() failed");
        return 0;
    }

    /*
     * Exception decompiling
     */
    public int doLoginRequest() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Can't sort instructions [@NONE, blocks:[27, 12] lbl788 : CaseStatement: default:\u000a, @NONE, blocks:[27, 12] lbl788 : CaseStatement: default:\u000a]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:25)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.CompareByIndex.compare(CompareByIndex.java:8)
         *     at java.base/java.util.TimSort.countRunAndMakeAscending(TimSort.java:360)
         *     at java.base/java.util.TimSort.sort(TimSort.java:220)
         *     at java.base/java.util.Arrays.sort(Arrays.java:1307)
         *     at java.base/java.util.ArrayList.sort(ArrayList.java:1721)
         *     at java.base/java.util.Collections.sort(Collections.java:179)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.buildSwitchCases(SwitchReplacer.java:271)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitch(SwitchReplacer.java:258)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:66)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public int doLogoutRequest() {
        block9: {
            YP_Object yP_Object;
            String string;
            block8: {
                block7: {
                    block6: {
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        try {
                            if (this.userIdentificationLevel == IdentificationLevelEnumeration.PASSWORD || this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN) break block6;
                            this.logger(2, "doLogoutRequest() authentification failed");
                            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                            return -1;
                        }
                        catch (Exception exception) {
                            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                            this.logger(2, "doLogoutRequest()  ", exception);
                            return -1;
                        }
                    }
                    string = this.getDataContainerTransaction().userHandler.getUserUID();
                    if (string != null && !string.isEmpty()) break block7;
                    YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(6));
                    this.logger(2, "doLogoutRequest() uid is missing !!!");
                    return -1;
                }
                yP_Object = this.getPluginByName("User");
                if (yP_Object != null) break block8;
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                this.logger(2, "doLogoutRequest() component not found");
                return -1;
            }
            boolean bl = (Boolean)yP_Object.dealRequest(this, "logout", string);
            if (!bl) break block9;
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
        return 0;
    }

    public int doGetDataRequest() {
        block12: {
            YP_PROT_IHM yP_PROT_IHM;
            block11: {
                YP_TCD_PosProtocol yP_TCD_PosProtocol;
                block10: {
                    block9: {
                        yP_TCD_PosProtocol = this.getDataContainerTransaction().getProtocolEFT();
                        if (yP_TCD_PosProtocol != null) break block9;
                        return -1;
                    }
                    if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block10;
                    this.logger(2, "doGetDataRequest() bad interface");
                    return -1;
                }
                yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                if (this.userIdentificationLevel == IdentificationLevelEnumeration.PASSWORD || this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN || this.userIdentificationLevel == IdentificationLevelEnumeration.PERMANENT_TOKEN) break block11;
                if (yP_PROT_IHM.getViewName().contentEquals("View_Merchant")) {
                    this.getDataContainerTransaction().userHandler.setUserPreferredLanguage("fr");
                    break block11;
                }
                if (this.getDataContainerTransaction().accountHandler.getCustomerIdentifier() > 0L) break block11;
                this.logger(2, "doGetDataRequest() authentification failed");
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                return -1;
            }
            try {
                YP_Object yP_Object = this.getPluginByName("ViewFormatter");
                int n = (Integer)yP_Object.dealRequest(this, "getView", yP_PROT_IHM.getViewName());
                if (n != 1) break block12;
                return 1;
            }
            catch (Exception exception) {
                try {
                    this.logger(2, "doGetDataRequest() ", exception);
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                    return -1;
                }
                catch (Exception exception2) {
                    this.logger(2, "doGetDataRequest() ", exception2);
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                    return -1;
                }
            }
        }
        this.logger(2, "doGetDataRequest() unknown view");
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        return -1;
    }

    public int doSetDataRequest() {
        block16: {
            int n;
            block15: {
                YP_PROT_IHM yP_PROT_IHM;
                block14: {
                    YP_TCD_PosProtocol yP_TCD_PosProtocol;
                    block13: {
                        block12: {
                            block11: {
                                if (UtilsYP.getInstanceRole() == 1) break block11;
                                if (this.getContractIdentifier().startsWith("YouPay_YouPay_Dumper")) {
                                    this.logger(2, "doSetDataRequest() setData allowed on slave for Dumper");
                                    break block11;
                                }
                                this.logger(2, "doSetDataRequest() Only master can use setData");
                                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(102));
                                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                return -1;
                            }
                            yP_TCD_PosProtocol = this.getDataContainerTransaction().getProtocolEFT();
                            if (yP_TCD_PosProtocol != null) break block12;
                            return -1;
                        }
                        if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block13;
                        this.logger(2, "doSetDataRequest() bad interface");
                        return -1;
                    }
                    yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                    if (this.userIdentificationLevel == IdentificationLevelEnumeration.PASSWORD || this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN || this.getDataContainerTransaction().accountHandler.getCustomerIdentifier() > 0L) break block14;
                    this.logger(2, "doSetDataRequest() authentification failed");
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    return -1;
                }
                try {
                    YP_Object yP_Object = this.getPluginByName("ViewFormatter");
                    n = (Integer)yP_Object.dealRequest(this, "setView", yP_PROT_IHM.getViewName());
                    if (n != 1) break block15;
                    return 1;
                }
                catch (Exception exception) {
                    try {
                        this.logger(2, "doSetDataRequest() ", exception);
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        return -1;
                    }
                    catch (Exception exception2) {
                        this.logger(2, "doSetDataRequest() ", exception2);
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        return -1;
                    }
                }
            }
            if (n != 0) break block16;
            this.logger(2, "doSetDataRequest() set view failed");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 1;
        }
        this.logger(2, "doSetDataRequest() set view in error");
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        return 1;
    }

    public int doCreateDataRequest() {
        block15: {
            int n;
            block14: {
                YP_PROT_IHM yP_PROT_IHM;
                block13: {
                    YP_TCD_PosProtocol yP_TCD_PosProtocol;
                    block12: {
                        block11: {
                            block10: {
                                if (UtilsYP.getInstanceRole() == 1) break block10;
                                this.logger(2, "doCreateDataRequest() Only master can use createData");
                                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(102));
                                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                                return -1;
                            }
                            yP_TCD_PosProtocol = this.getDataContainerTransaction().getProtocolEFT();
                            if (yP_TCD_PosProtocol != null) break block11;
                            return -1;
                        }
                        if (yP_TCD_PosProtocol instanceof YP_PROT_IHM) break block12;
                        this.logger(2, "doCreateDataRequest() bad interface");
                        return -1;
                    }
                    yP_PROT_IHM = (YP_PROT_IHM)((Object)yP_TCD_PosProtocol);
                    if (this.userIdentificationLevel == IdentificationLevelEnumeration.PASSWORD || this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN) break block13;
                    this.logger(2, "doCreateDataRequest() authentification failed");
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    return -1;
                }
                try {
                    YP_Object yP_Object = this.getPluginByName("ViewFormatter");
                    n = (Integer)yP_Object.dealRequest(this, "createInView", yP_PROT_IHM.getViewName());
                    if (n != 1) break block14;
                    return 1;
                }
                catch (Exception exception) {
                    try {
                        this.logger(2, "doCreateDataRequest() ", exception);
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        return -1;
                    }
                    catch (Exception exception2) {
                        this.logger(2, "doCreateDataRequest() ", exception2);
                        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                        return -1;
                    }
                }
            }
            if (n != 0) break block15;
            this.logger(2, "doCreateDataRequest() create in view failed");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 1;
        }
        this.logger(2, "doCreateDataRequest() create in view in error");
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        return 1;
    }

    public int doDiaryRequest() {
        List<YP_TCD_DCC_Business> list;
        block13: {
            block12: {
                block11: {
                    if (this.userIdentificationLevel == IdentificationLevelEnumeration.PASSWORD || this.userIdentificationLevel == IdentificationLevelEnumeration.TOKEN || this.userIdentificationLevel == IdentificationLevelEnumeration.PERMANENT_TOKEN) break block11;
                    this.logger(2, "doDiaryRequest() authentification failed");
                    YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
                    return -1;
                }
                list = this.getApplicationList();
                if (list != null) break block12;
                this.logger(2, "doDiaryRequest() no application List");
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                return -1;
            }
            if (!list.isEmpty()) break block13;
            this.logger(2, "doDiaryRequest() application List empty");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            return 0;
        }
        try {
            boolean bl = false;
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                List<YP_Row> list2;
                if (yP_TCD_DCC_Business.transaction == null || (list2 = yP_TCD_DCC_Business.transaction.getRowList()) == null) continue;
                Field[] fieldArray = yP_TCD_DCC_Business.transaction.getNewRow().getFieldList();
                this.getDataContainerTransaction().xmlResponse.append("\n<table>");
                this.getDataContainerTransaction().xmlResponse.append("\n\t<header>");
                this.getDataContainerTransaction().xmlResponse.append("\n\t\t<name>");
                this.getDataContainerTransaction().xmlResponse.append(yP_TCD_DCC_Business.getApplicationPlugin().getSimpleName());
                this.getDataContainerTransaction().xmlResponse.append("</name>");
                int n = 0;
                while (n < fieldArray.length) {
                    this.getDataContainerTransaction().xmlResponse.append("\n\t\t<column>");
                    this.getDataContainerTransaction().xmlResponse.append("\n\t\t\t<name>");
                    this.getDataContainerTransaction().xmlResponse.append(fieldArray[n].getName());
                    this.getDataContainerTransaction().xmlResponse.append("</name>");
                    this.getDataContainerTransaction().xmlResponse.append("\n\t\t</column>");
                    ++n;
                }
                this.getDataContainerTransaction().xmlResponse.append("\n\t</header>");
                if (!list2.isEmpty()) {
                    bl = true;
                    for (YP_Row yP_Row : list2) {
                        this.getDataContainerTransaction().xmlResponse.append("\n\t<row>");
                        int n2 = 0;
                        while (n2 < fieldArray.length) {
                            this.getDataContainerTransaction().xmlResponse.append("\n\t\t<v>");
                            this.getDataContainerTransaction().xmlResponse.append(yP_Row.getFieldStringValueByName(fieldArray[n2].getName()));
                            this.getDataContainerTransaction().xmlResponse.append("</v>");
                            ++n2;
                        }
                        this.getDataContainerTransaction().xmlResponse.append("\n\t</row>");
                    }
                }
                this.getDataContainerTransaction().xmlResponse.append("\n</table>");
            }
            if (!bl) {
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            }
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "doDiaryRequest()  ", exception);
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
    }

    /*
     * WARNING - void declaration
     */
    private int doReprintLastRequest() {
        Object object;
        Object object2;
        Object object32;
        Object object4;
        Object object5;
        Object object6;
        List<YP_TCD_DCC_Business> list = this.getApplicationList();
        if (list == null) {
            this.logger(2, "doReprintLastRequest() no application List");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
        if (list.isEmpty()) {
            this.logger(2, "doReprintLastRequest() application List empty");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            return 0;
        }
        try {
            long l = list.get(0).getDataContainerMerchant().getIDMerchant();
            for (YP_TCD_DCC_Business object72 : list) {
                if (object72.getDataContainerMerchant().getIDMerchant() == l) continue;
                this.logger(2, "doReprintLastRequest() multiple idMerchant we don't check");
                l = 0L;
                break;
            }
            if (l > 0L) {
                int n;
                TLVHandler tLVHandler;
                Object exception = null;
                object6 = this.requestAPPTagsHandler.getTLV(16769880);
                if (object6 != null && (object5 = (tLVHandler = new TLVHandler(((TLV)object6).value)).getTLV(14672736)) != null) {
                    String string = new String(((TLV)object5).value);
                    this.getDataContainerTransaction().setTerminalSerialNumber(string);
                }
                if ((n = this.getDataContainerTransaction().getRealNLPA()) > 0) {
                    object5 = this.getDataContainerTransaction().getDataContainerBrand();
                    if (object5 == null) {
                        this.logger(3, "doReprintLastRequest() unable to get brand !!!");
                    } else {
                        void var4_9;
                        object4 = ((YP_TCD_DCC_Brand)object5).getTerminalRow(l, (String)var4_9);
                        if (object4 != null) {
                            this.getDataContainerTransaction().setTerminalRow((YP_Row)object4);
                        }
                    }
                }
            }
        }
        catch (Exception exception) {
            this.logger(3, "doReprintLastRequest() retrieving terminal row", exception);
        }
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        int n = 0;
        if (this.requestAPPTagsHandler != null) {
            try {
                TLV tLV = this.requestAPPTagsHandler.getTLV(-538803964);
                if (tLV != null && tLV.length > 0) {
                    n = TLVHandler.getDCBInt(tLV.value);
                }
            }
            catch (Exception exception) {
                this.logger(4, "doReprintLastRequest(): stan not received??? ", exception);
            }
        }
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
            if (yP_TCD_DCC_Business.transaction == null) continue;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
            yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MAX);
            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.DEBIT_DIFFERED, TransactionTypeEnumeration.CREDIT, TransactionTypeEnumeration.REVERSAL_DEBIT, TransactionTypeEnumeration.INITIAL_RESERVATION, TransactionTypeEnumeration.CLOSING_PAYMENT, TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT, TransactionTypeEnumeration.COMPLEMENTARY_REFUND, TransactionTypeEnumeration.QUASI_CASH, TransactionTypeEnumeration.REFUND_QUASI_CASH, TransactionTypeEnumeration.REVERSAL_QUASI_CASH, TransactionTypeEnumeration.ADVICE_DEBIT});
            yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
            if (n > 0 && yP_TCD_DCC_Business.transaction.getFieldByName("stan") != null) {
                yP_ComplexGabarit.set("stan", YP_ComplexGabarit.OPERATOR.EQUAL, n);
            }
            if ((object5 = this.getDataContainerTransaction().getNLPA3_6()) != null && !((String)object5).isEmpty()) {
                yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, (String)object5);
            } else {
                long l = this.getDataContainerTransaction().userHandler.getUserIdentifier();
                if (l > 0L) {
                    yP_ComplexGabarit.set("idUser", YP_ComplexGabarit.OPERATOR.EQUAL, l);
                }
            }
            object4 = yP_TCD_DCC_Business.transaction.getRowListSuchAs(yP_ComplexGabarit);
            if (object4 == null) continue;
            arrayList.addAll((Collection<YP_Row>)object4);
        }
        if (arrayList.isEmpty()) {
            this.logger(3, "doReprintLastRequest() Nothing found !!!");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            return 0;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(((YP_Row)arrayList.get(0)).getFather());
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MAX);
        object6 = YP_TCD_DesignAccesObject.getRowListSuchAs(arrayList, yP_ComplexGabarit);
        YP_Row yP_Row = object6.get(0);
        object5 = (YP_TCD_DCC_EFT_Business)yP_Row.getFather().getFather();
        object4 = ((YP_TCD_DCC_Business)object5).snapshotTransaction(this.getDataContainerTransaction());
        YP_Row yP_Row2 = this.getDataContainerTransaction().getTerminalRow();
        ((YP_TCD_DCC_Business)object5).loadTransaction(this.getDataContainerTransaction(), object6.get(0));
        this.getDataContainerTransaction().setTerminalRow(yP_Row2);
        Bitmap bitmap = new Bitmap().set(TicketTypeEnumeration.MERCHANT.getValue()).set(TicketTypeEnumeration.CUSTOMER.getValue());
        if (this.requestAPPTagsHandler != null) {
            try {
                for (Object object32 : this.requestAPPTagsHandler) {
                    switch (((TLV)object32).tag) {
                        case 16769901: {
                            try {
                                object2 = new TLVHandler(((TLV)object32).value);
                                object = ((TLVHandler)object2).getTLV(14672497);
                                if (object == null) break;
                                bitmap = new Bitmap(TLVHandler.getDCBLong(((TLV)object).value));
                                break;
                            }
                            catch (Exception exception) {
                                this.logger(2, "doReprintLastRequest(): ", exception);
                            }
                        }
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "doReprintLastRequest(): ", exception);
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(7));
                return 0;
            }
        }
        object32 = new TLVHandler();
        if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER.getValue())) {
            try {
                ((TLVHandler)object32).addASCII(14672663, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 1).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                ((TLVHandler)object32).addASCII(14672663, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 1).getBytes()));
            }
        }
        if (bitmap.isSet(TicketTypeEnumeration.MERCHANT.getValue())) {
            try {
                ((TLVHandler)object32).addASCII(14672664, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 2).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                ((TLVHandler)object32).addASCII(14672664, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 2).getBytes()));
            }
        }
        if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER_HANDWRITTEN.getValue())) {
            try {
                ((TLVHandler)object32).addASCII(14672755, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 3).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                ((TLVHandler)object32).addASCII(14672755, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), true, 3).getBytes()));
            }
        }
        String string = this.getDataContainerTransaction().accountHandler.getCustomerPrimaryPhoneFromRequest();
        if (bitmap.isSet(TicketTypeEnumeration.SMS_TICKET.getValue()) || string != null && !string.isEmpty()) {
            try {
                ((TLVHandler)object32).addASCII(-538738382, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), false, 4).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                ((TLVHandler)object32).addASCII(-538738382, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object5).getTransactionTicket(this.getDataContainerTransaction(), false, 4).getBytes()));
            }
        }
        ((TLVHandler)object32).add(14672409, (long)YP_TCD_DCC_Business.getTransactionStatus((YP_TCD_DC_Transaction)this.getDataContainerTransaction()).code);
        ((TLVHandler)object32).add(14672642, this.getDataContainerTransaction().getExtendedTVR().toString());
        object2 = (YP_TCD_DCB_Interface_Currency)((YP_TCD_DC_Context)object5).getExtensionByType(YP_TCD_DCB_Interface_Currency.class);
        if (object2 != null) {
            try {
                object = String.valueOf(object2.formatAmount(YP_TCD_DCC_Business.getTransactionAmount(this.getDataContainerTransaction()), YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.getDataContainerTransaction()))) + ' ' + YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.getDataContainerTransaction());
                ((TLVHandler)object32).addASCII(14672716, (String)object);
            }
            catch (Exception exception) {
                this.logger(2, "doReprintLastRequest() formated amount ", exception);
            }
        }
        this.getDataContainerTransaction().commonHandler.setResponseAppTags(((TLVHandler)object32).toString());
        this.getDataContainerTransaction().getTransactionList().add(yP_Row);
        ((YP_TCD_DCC_Business)object5).loadTransactions(this.getDataContainerTransaction(), (List<YP_Row>)object4);
        int n2 = this.dealSMSAndMailReprint((YP_TCD_DCC_EFT_Business)object5, (TLVHandler)object32);
        if (n2 < 0) {
            this.logger(2, "doReprint() Refused as called for SMS/Mail");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
        return 1;
    }

    private int doReprint() {
        Object object;
        Object object2;
        List<YP_Row> list;
        Object object32;
        List<YP_TCD_DCC_Business> list2 = this.getApplicationList();
        if (list2 == null) {
            this.logger(2, "doReprint() no application List");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
        if (list2.isEmpty()) {
            this.logger(2, "doReprint() application List empty");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            return 0;
        }
        Bitmap bitmap = new Bitmap().set(TicketTypeEnumeration.MERCHANT.getValue()).set(TicketTypeEnumeration.CUSTOMER.getValue());
        if (this.requestAPPTagsHandler != null) {
            try {
                block20: for (Object object32 : this.requestAPPTagsHandler) {
                    switch (((TLV)object32).tag) {
                        case 16769901: {
                            try {
                                list = new TLVHandler(((TLV)object32).value);
                                object2 = ((TLVHandler)((Object)list)).getTLV(14672497);
                                if (object2 == null) break;
                                bitmap = new Bitmap(TLVHandler.getDCBLong(((TLV)object2).value));
                            }
                            catch (Exception exception) {
                                this.logger(2, "doReprint(): ", exception);
                            }
                            continue block20;
                        }
                        case -538738381: {
                            this.getDataContainerTransaction().commonHandler.setMerchantPrivateData(new String(((TLV)object32).value));
                            break;
                        }
                        case -538738399: {
                            list = new String(((TLV)object32).value);
                            YP_TCD_DCC_Business.setMerchantTransactionIdentifier(this.getDataContainerTransaction(), (String)((Object)list));
                            break;
                        }
                        case -538803934: {
                            YP_TCD_DCC_Business.setTransactionAmount(this.getDataContainerTransaction(), TLVHandler.getDCBLong(((TLV)object32).value));
                        }
                    }
                }
            }
            catch (Exception exception) {
                this.logger(2, "doReprint(): ", exception);
                YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(7));
                return 0;
            }
        }
        object32 = new ArrayList();
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list2) {
            if (yP_TCD_DCC_Business.transaction == null || (object = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DCC_Business.transaction, yP_TCD_DCC_Business.transactionArchive, 0, 1, new YP_ComplexGabarit[]{object2 = this.getReprintGabarit(yP_TCD_DCC_Business)})) == null) continue;
            object32.addAll(object);
        }
        if (object32.isEmpty()) {
            this.logger(3, "doReprint() Nothing found !!!");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(1));
            return 0;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(((YP_Row)object32.get(0)).getFather());
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.MAX);
        list = YP_TCD_DesignAccesObject.getRowListSuchAs((List<YP_Row>)object32, yP_ComplexGabarit);
        object2 = list.get(0);
        object = (YP_TCD_DCC_EFT_Business)((YP_Row)object2).getFather().getFather();
        List<YP_Row> list3 = ((YP_TCD_DCC_Business)object).snapshotTransaction(this.getDataContainerTransaction());
        ((YP_TCD_DCC_Business)object).loadTransaction(this.getDataContainerTransaction(), list.get(0));
        TLVHandler tLVHandler = new TLVHandler();
        if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER.getValue())) {
            try {
                tLVHandler.addASCII(14672663, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 1).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                tLVHandler.addASCII(14672663, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 1).getBytes()));
            }
        }
        if (bitmap.isSet(TicketTypeEnumeration.MERCHANT.getValue())) {
            try {
                tLVHandler.addASCII(14672664, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 2).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                tLVHandler.addASCII(14672664, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 2).getBytes()));
            }
        }
        if (bitmap.isSet(TicketTypeEnumeration.CUSTOMER_HANDWRITTEN.getValue())) {
            try {
                tLVHandler.addASCII(14672755, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 3).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                tLVHandler.addASCII(14672755, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), true, 3).getBytes()));
            }
        }
        String string = this.getDataContainerTransaction().accountHandler.getCustomerPrimaryPhoneFromRequest();
        if (bitmap.isSet(TicketTypeEnumeration.SMS_TICKET.getValue()) || string != null && !string.isEmpty()) {
            try {
                tLVHandler.addASCII(-538738382, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), false, 4).getBytes("UTF-8")));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                tLVHandler.addASCII(-538738382, UtilsYP.base64Encode(((YP_TCD_DCC_EFT_Business)object).getTransactionTicket(this.getDataContainerTransaction(), false, 4).getBytes()));
            }
        }
        tLVHandler.add(14672409, (long)YP_TCD_DCC_Business.getTransactionStatus((YP_TCD_DC_Transaction)this.getDataContainerTransaction()).code);
        tLVHandler.add(14672642, this.getDataContainerTransaction().getExtendedTVR().toString());
        YP_TCD_DCB_Interface_Currency yP_TCD_DCB_Interface_Currency = (YP_TCD_DCB_Interface_Currency)((YP_TCD_DC_Context)object).getExtensionByType(YP_TCD_DCB_Interface_Currency.class);
        if (yP_TCD_DCB_Interface_Currency != null) {
            try {
                String string2 = String.valueOf(yP_TCD_DCB_Interface_Currency.formatAmount(YP_TCD_DCC_Business.getTransactionAmount(this.getDataContainerTransaction()), YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.getDataContainerTransaction()))) + ' ' + YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.getDataContainerTransaction());
                tLVHandler.addASCII(14672716, string2);
            }
            catch (Exception exception) {
                this.logger(2, "doReprint() formated amount ", exception);
            }
        }
        this.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        this.getDataContainerTransaction().getTransactionList().add((YP_Row)object2);
        ((YP_TCD_DCC_Business)object).loadTransactions(this.getDataContainerTransaction(), list3);
        int n = this.dealSMSAndMailReprint((YP_TCD_DCC_EFT_Business)object, tLVHandler);
        if (n < 0) {
            this.logger(2, "doReprint() Refused as called for SMS/Mail");
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
        } else {
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
        return 1;
    }

    private int dealSMSAndMailReprint(YP_TCD_DCC_EFT_Business yP_TCD_DCC_EFT_Business, TLVHandler tLVHandler) {
        Object object;
        Object object2;
        int n = 0;
        String string = this.getDataContainerTransaction().accountHandler.getCustomerMailAddress();
        if (string != null && !string.isEmpty()) {
            try {
                object2 = tLVHandler.getTLV(14672663);
                if (object2 != null) {
                    int n2;
                    boolean bl = false;
                    object = tLVHandler.getTLV(14672409);
                    if (object != null && (n2 = TLVHandler.getDCBInt(((TLV)object).value)) == TransactionStatusEnumeration.ACCEPTED.code) {
                        bl = true;
                    }
                    String string2 = new String(UtilsYP.base64Decode(new String(((TLV)object2).value)));
                    string2 = string2.replace("<br>", "\n");
                    string2 = string2.replace("<br/>", "\n");
                    string2 = string2.replaceAll("<[^>]*>", "");
                    n = yP_TCD_DCC_EFT_Business.mailTRSReprint(this.getDataContainerTransaction(), string, bl ? "Confirmation de paiement" : "Paiement non abouti", string2, bl);
                }
            }
            catch (Exception exception) {
                this.logger(2, "dealSMSAndMailReprint() mail reprint ", exception);
            }
        }
        if ((object2 = this.getDataContainerTransaction().accountHandler.getCustomerPrimaryPhoneFromRequest()) != null && !((String)object2).isEmpty()) {
            try {
                TLV tLV = tLVHandler.getTLV(-538738382);
                if (tLV != null) {
                    object = new String(UtilsYP.base64Decode(new String(tLV.value)));
                    n = yP_TCD_DCC_EFT_Business.sendSMS((String)object2, (String)object);
                }
            }
            catch (Exception exception) {
                this.logger(2, "dealSMSAndMailReprint() mail reprint ", exception);
            }
        }
        return n;
    }

    private YP_ComplexGabarit getReprintGabarit(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        String string;
        Timestamp timestamp;
        Timestamp timestamp2;
        Timestamp timestamp3;
        Timestamp timestamp4;
        String string2;
        String string3;
        String string4;
        String string5;
        long l;
        long l2;
        Timestamp timestamp5;
        Timestamp timestamp6;
        int n;
        int n2;
        long l3;
        long l4;
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
        long l5 = YP_TCD_DCC_Business.getReferenceTransactionPrimaryKey(this.getDataContainerTransaction());
        if (l5 > 0L) {
            yP_ComplexGabarit.set("idTransaction", YP_ComplexGabarit.OPERATOR.EQUAL, l5);
        }
        if ((l4 = YP_TCD_DCC_Business.getIDToken(this.getDataContainerTransaction())) != 0L) {
            yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, l4);
        }
        if ((l3 = this.getDataContainerTransaction().accountHandler.getIDMeanOfPayment()) != 0L) {
            yP_ComplexGabarit.set("idMeanOfPayment", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
        }
        if ((n2 = YP_TCD_DCC_Business.getTransactionNumber(this.getDataContainerTransaction())) != 0) {
            yP_ComplexGabarit.set("transactionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, n2);
        }
        if ((n = YP_TCD_DCC_Business.getReferenceTransactionNumber(this.getDataContainerTransaction())) != 0) {
            yP_ComplexGabarit.set("referenceTransactionNumber", YP_ComplexGabarit.OPERATOR.EQUAL, n);
        }
        if ((timestamp6 = YP_TCD_DCC_Business.getTransactionAppliLocalTime(this.getDataContainerTransaction())) != null && timestamp6.getTime() != 0L) {
            yP_ComplexGabarit.set("transactionAppliLocalTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp6);
        }
        if ((timestamp5 = YP_TCD_DCC_Business.getReferenceTransactionAppliLocalTime(this.getDataContainerTransaction())) != null && timestamp5.getTime() != 0L) {
            yP_ComplexGabarit.set("referenceTransactionAppliLocalTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp5);
        }
        if ((l2 = YP_TCD_DCC_Business.getTransactionAmount(this.getDataContainerTransaction())) != 0L) {
            yP_ComplexGabarit.set("transactionAmount", YP_ComplexGabarit.OPERATOR.EQUAL, l2);
        }
        if ((l = (long)YP_TCD_DCC_Business.getTransactionCurrencyNumerical(this.getDataContainerTransaction())) != 0L) {
            yP_ComplexGabarit.set("transactionCurrencyNumerical", YP_ComplexGabarit.OPERATOR.EQUAL, l);
        }
        if ((string5 = YP_TCD_DCC_Business.getTransactionCurrencyAlpha(this.getDataContainerTransaction())) != null && !string5.isEmpty()) {
            yP_ComplexGabarit.set("transactionCurrencyAlpha", YP_ComplexGabarit.OPERATOR.EQUAL, string5);
        }
        if ((string4 = YP_TCD_DCC_Business.getMerchantTransactionIdentifier(this.getDataContainerTransaction())) != null && !string4.isEmpty()) {
            yP_ComplexGabarit.set("merchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
        }
        if ((string3 = YP_TCD_DCC_Business.getReferenceMerchantTransactionIdentifier(this.getDataContainerTransaction())) != null && !string3.isEmpty()) {
            yP_ComplexGabarit.set("referenceMerchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        }
        if ((string2 = this.getDataContainerTransaction().commonHandler.getMerchantPrivateData()) != null && !string2.isEmpty()) {
            yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        }
        if ((timestamp4 = YP_TCD_DCC_Business.getMerchantTransactionTime(this.getDataContainerTransaction())) != null && timestamp4.getTime() != 0L) {
            yP_ComplexGabarit.set("merchantTransactionTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp4);
        }
        if ((timestamp3 = YP_TCD_DCC_Business.getReferenceMerchantTransactionTime(this.getDataContainerTransaction())) != null && timestamp3.getTime() != 0L) {
            yP_ComplexGabarit.set("referenceMerchantTransactionTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp3);
        }
        if ((timestamp2 = YP_TCD_DCC_Business.getTerminalTransactionTime(this.getDataContainerTransaction())) != null && timestamp2.getTime() != 0L) {
            yP_ComplexGabarit.set("terminalTransactionTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp2);
        }
        if ((timestamp = YP_TCD_DCC_Business.getReferenceTerminalTransactionTime(this.getDataContainerTransaction())) != null && timestamp.getTime() != 0L) {
            yP_ComplexGabarit.set("referenceTerminalTransactionTime", YP_ComplexGabarit.OPERATOR.EQUAL, timestamp);
        }
        if ((string = this.getDataContainerTransaction().getNLPA3_6()) != null && !string.isEmpty()) {
            yP_ComplexGabarit.set("nlpa", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        return yP_ComplexGabarit;
    }

    private boolean isCtclActivated(YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, YP_App_Interface_Selection yP_App_Interface_Selection) {
        return yP_TCD_DCB_Interface_CTCL != null && yP_TCD_DCB_Interface_CTCL.isActive() && yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS);
    }

    private int doParameterUpdate(YP_Row yP_Row, boolean bl) {
        ArrayList arrayList;
        YP_PROT_Update yP_PROT_Update;
        block124: {
            List<YP_TCD_DCC_Business> list;
            boolean bl2;
            List<UpdateHandler.ParameterFile> list2;
            block123: {
                block122: {
                    block121: {
                        YP_TCD_PosProtocol yP_TCD_PosProtocol;
                        block120: {
                            block119: {
                                yP_TCD_PosProtocol = this.getDataContainerTransaction().getProtocolEFT();
                                if (yP_TCD_PosProtocol != null) break block119;
                                return 0;
                            }
                            if (yP_TCD_PosProtocol instanceof YP_PROT_Update) break block120;
                            if (this.getLogLevel() >= 5) {
                                this.logger(5, "doParameterUpdate() bad interface");
                            }
                            return 0;
                        }
                        yP_PROT_Update = (YP_PROT_Update)((Object)yP_TCD_PosProtocol);
                        UpdateHandler updateHandler = this.getDataContainerTransaction().updateHandler;
                        list2 = yP_PROT_Update.getParameterFileList(updateHandler);
                        if (list2 != null) break block121;
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "doParameterUpdate() parameterFileList==null");
                        }
                        return 0;
                    }
                    if (!list2.isEmpty()) break block122;
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "doParameterUpdate() empty parameterFileList");
                    }
                    return 0;
                }
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "doParameterUpdate() parameterFileList received");
                }
                bl2 = false;
                for (UpdateHandler.ParameterFile list3 : list2) {
                    switch (list3.headerParameterFile.tableName) {
                        case "BinList": {
                            bl2 = true;
                            break;
                        }
                    }
                }
                list = this.getApplicationList();
                if (list != null) break block123;
                this.logger(2, "doParameterUpdate() no application List");
                return -1;
            }
            try {
                Object object;
                arrayList = new ArrayList();
                long l = 0L;
                long l2 = 0L;
                long l3 = 0L;
                long l4 = 0L;
                long l5 = 0L;
                long l6 = 0L;
                long l7 = 0L;
                long l8 = 0L;
                long l9 = 0L;
                long l10 = 0L;
                long l11 = 0L;
                long l12 = 0L;
                long l13 = 0L;
                ArrayList<Property> arrayList2 = new ArrayList<Property>();
                StringBuilder stringBuilder = new StringBuilder();
                StringBuilder stringBuilder2 = new StringBuilder();
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    Object object2;
                    Object object3;
                    YP_TCD_DCB_Interface_BIN yP_TCD_DCB_Interface_BIN;
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(NEPTING)) continue;
                    if (bl2 && (yP_TCD_DCB_Interface_BIN = (YP_TCD_DCB_Interface_BIN)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_BIN.class)) != null) {
                        l13 += yP_TCD_DCB_Interface_BIN.getBinChecksum();
                    }
                    if (yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) {
                        l6 += ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getCurrencyChecksum();
                    }
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_CMC7)) continue;
                        object = yP_TCD_DCC_Business.getInitialisationRow().serialize();
                        object3 = new CRC32();
                        object3.update(((String)object).getBytes(), 0, ((String)object).length());
                        l8 += object3.getValue();
                    }
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class);
                    if (yP_TCD_DCB_Interface_EMV == null) continue;
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class);
                    object3 = yP_TCD_DCC_Business.selectorList.iterator();
                    while (object3.hasNext()) {
                        YP_Row yP_Row2;
                        String string;
                        object = (YP_App_Interface_Selection)object3.next();
                        if (object.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) {
                            l += yP_TCD_DCB_Interface_EMV.getAIDTableChecksum();
                            l2 += yP_TCD_DCB_Interface_EMV.getAIDParametersTableChecksum();
                            l3 += yP_TCD_DCB_Interface_EMV.getKeysTableChecksum();
                            l5 += yP_TCD_DCB_Interface_EMV.getKeysTableChecksum();
                        }
                        if (this.isCtclActivated(yP_TCD_DCB_Interface_CTCL, (YP_App_Interface_Selection)object)) {
                            l10 += yP_TCD_DCB_Interface_CTCL.getCTCLChecksum();
                            l4 += yP_TCD_DCB_Interface_CTCL.getKeysTableChecksum();
                            l5 += yP_TCD_DCB_Interface_CTCL.getKeysTableChecksum();
                        }
                        if (!object.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC) && !this.isCtclActivated(yP_TCD_DCB_Interface_CTCL, (YP_App_Interface_Selection)object)) continue;
                        if (yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && (object2 = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getEndUserLangageList(this.getDataContainerTransaction())) != null && !((String)object2).isEmpty()) {
                            stringBuilder.append((String)object2);
                        }
                        if ((object2 = yP_TCD_DCC_Business.getMerchantName()) != null && !((String)object2).isEmpty()) {
                            stringBuilder.append((String)object2);
                        }
                        if ((string = yP_TCD_DCC_Business.getMerchantCategoryCode()) != null && !string.isEmpty()) {
                            stringBuilder.append(string);
                        }
                        if (yP_TCD_DCC_Business.merchantParameters == null || (yP_Row2 = yP_TCD_DCC_Business.merchantParameters.getUniqueRow()) == null) continue;
                        stringBuilder2.append(yP_Row2.serialize());
                    }
                    object = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class);
                    if (object != null) {
                        object2 = yP_TCD_DCC_Business.selectorList.iterator();
                        while (object2.hasNext()) {
                            object3 = object2.next();
                            if (object3.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) {
                                l11 += object.getProductListTableChecksum();
                            }
                            if (!this.isCtclActivated(yP_TCD_DCB_Interface_CTCL, (YP_App_Interface_Selection)object3)) continue;
                            l12 += object.getProductListTableChecksum();
                        }
                    }
                    if ((object3 = yP_TCD_DCC_Business.getPropertiesParameters()) == null) continue;
                    arrayList2.addAll((Collection<Property>)object3);
                }
                if (stringBuilder.length() > 0) {
                    CRC32 cRC32 = new CRC32();
                    cRC32.update(stringBuilder.toString().getBytes(), 0, stringBuilder.length());
                    l7 = cRC32.getValue();
                }
                if (stringBuilder2.length() > 0) {
                    CRC32 cRC32 = new CRC32();
                    cRC32.update(stringBuilder2.toString().getBytes(), 0, stringBuilder2.length());
                    l9 = cRC32.getValue();
                }
                block73: for (UpdateHandler.ParameterFile parameterFile : list2) {
                    if (bl) {
                        parameterFile.headerParameterFile.checksum = "0";
                    }
                    switch (parameterFile.headerParameterFile.tableName) {
                        case "EMV_ICC_Key": {
                            StandardTLV.dealEMV_ICC_KeyUpdate(this, list, arrayList, parameterFile, l3);
                            break;
                        }
                        case "EMV_NFC_Key": {
                            StandardTLV.dealEMV_NFC_KeyUpdate(this, list, arrayList, parameterFile, l4);
                            break;
                        }
                        case "EMV_ICC_Key_PosMate": {
                            FAPI.dealEMV_ICC_NFC_Key_PosMateUpdate(this, this.requestAPPTagsHandler, list, arrayList, parameterFile, l5);
                            break;
                        }
                        case "EMV_ICC_Key_Albert": {
                            Albert.dealEMV_ICC_NFC_KeyUpdate(this, list, arrayList, parameterFile, l5);
                            break;
                        }
                        case "EMV_ICC_Key_NovelPayPAL": {
                            NovelPayPAL.dealEMV_ICC_NFC_KeyUpdate(this, list, arrayList, parameterFile, l5);
                            break;
                        }
                        case "CTCL_Parameters": {
                            this.dealCTCL_Parameters_Update(list, arrayList, parameterFile, l10);
                            break;
                        }
                        case "CTCL_Albert_Parameters": {
                            Albert.dealCTCL_Parameters_Update(this, list, arrayList, parameterFile, l10, l12);
                            break;
                        }
                        case "CTCL_NovelPayPAL_Parameters": {
                            NovelPayPAL.dealCTCL_Parameters_Update(this, list, arrayList, parameterFile, l10);
                            break;
                        }
                        case "CTCL_Prolin_Parameters": {
                            Prolin.dealCTCL_Parameters_Update(this, list, arrayList, parameterFile, l10);
                            break;
                        }
                        case "CTCL_UCube_Parameters": {
                            UCube.dealCTCL_Parameters_Update(this, list, this.requestAPPTagsHandler, arrayList, parameterFile, l10);
                            break;
                        }
                        case "CTCL_SPm2x_Parameters": {
                            boolean bl3 = false;
                            if (yP_Row == null) {
                                bl3 = true;
                            } else {
                                object = yP_Row.getFieldStringValueByName("kernelVersion");
                                if (!(!((String)object).startsWith("t2.") && !((String)object).startsWith("2.") && !((String)object).startsWith("t4.") && !((String)object).startsWith("4.") || ((String)object).startsWith("t2.30.43") || ((String)object).startsWith("2.30.43") || ((String)object).startsWith("t2.30.44") || ((String)object).startsWith("2.30.44") || ((String)object).startsWith("t4.0.27") || ((String)object).startsWith("4.0.27") || ((String)object).startsWith("t4.0.34") || ((String)object).startsWith("4.0.34"))) {
                                    bl3 = true;
                                }
                            }
                            if (!bl3) continue block73;
                            this.dealCTCL_SPm2x_ParametersUpdate(list, arrayList, parameterFile, l10);
                            break;
                        }
                        case "TerminalConfig": {
                            SPm2x.dealSPm2x_TerminalConfig(this, list, arrayList, parameterFile, yP_Row, this.requestAPPTagsHandler);
                            break;
                        }
                        case "Currency_FAPI": {
                            SPm2x.dealSPm2x_Currency(this, list, arrayList, parameterFile, yP_Row, this.requestAPPTagsHandler);
                            break;
                        }
                        case "EMV_ICC_AID": {
                            StandardTLV.dealEMV_ICC_AIDUpdate(this, list, arrayList, parameterFile, l);
                            break;
                        }
                        case "EMV_ICC_AID_Parameters": {
                            StandardTLV.dealEMV_ICC_AID_ParametersUpdate(this, list, arrayList, parameterFile, l, l2, l9);
                            break;
                        }
                        case "EMV_ICC_AID_PosMate": {
                            FAPI.dealEMV_ICC_AID_PosmateUpdate(this, this.requestAPPTagsHandler, list, arrayList, parameterFile, l, l2, l7, l11, yP_Row);
                            break;
                        }
                        case "EMV_ICC_AID_Albert": {
                            Albert.dealEMV_ICC_AIDUpdate(this, list, arrayList, parameterFile, (l + l2 + l7) % 0x100000000L);
                            break;
                        }
                        case "EMV_ICC_AID_NovelPayPAL": {
                            NovelPayPAL.dealEMV_ICC_AIDUpdate(this, list, arrayList, parameterFile, (l + l2 + l7) % 0x100000000L);
                            break;
                        }
                        case "EMV_ICC_UCube": {
                            UCube.dealICC_Parameters_Update(this, list, this.requestAPPTagsHandler, arrayList, parameterFile, (l + l2 + l7) % 0x100000000L);
                            break;
                        }
                        case "Currency": {
                            StandardTLV.dealCurrencyUpdate(this, list, arrayList, parameterFile, l6);
                            break;
                        }
                        case "CHQ_Parameters": {
                            StandardTLV.dealCHQ_ParametersUpdate(this, list, arrayList, parameterFile, l8);
                            break;
                        }
                        case "Properties": {
                            StandardTLV.dealPropertiesUpdate(this, arrayList, parameterFile, arrayList2);
                            break;
                        }
                        case "ForbiddenProducts": {
                            StandardTLV.dealForbiddenProducts(this, list, arrayList, parameterFile, l11);
                            break;
                        }
                        case "BinList": {
                            if (this.biosVersionNotReceived) continue block73;
                            BinList.dealBinListUpdate(this, list, arrayList, parameterFile, l13);
                            break;
                        }
                        case "BlackList": {
                            if (this.biosVersionNotReceived) continue block73;
                            BlackList.dealBlackListUpdate(this, list, arrayList, parameterFile);
                            break;
                        }
                        default: {
                            this.logger(2, "doParameterUpdate() unknown parameter:" + parameterFile.headerParameterFile.tableName);
                        }
                    }
                }
                this.addTerminalCountryCode(list);
                if (!arrayList.isEmpty()) break block124;
                return 0;
            }
            catch (Exception exception) {
                YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                this.logger(2, "doParameterUpdate() ", exception);
                return -1;
            }
        }
        yP_PROT_Update.setParameterFileList(arrayList);
        this.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PARAMETERIZATION_NEEDED);
        YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(9));
        return 1;
    }

    private int isDynamicLimitConfigPresent(DynamicLimitConfig dynamicLimitConfig) {
        if (this.dynamicLimitConfigList.size() <= 0) {
            return -1;
        }
        int n = 0;
        while (n < this.dynamicLimitConfigList.size()) {
            if (this.dynamicLimitConfigList.get(n).isEqual(dynamicLimitConfig)) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    private String getKernelID(YP_Row yP_Row) {
        String string = yP_Row.getFieldStringValueByName("kernelID");
        if (string == null || string.isEmpty()) {
            return null;
        }
        try {
            string = String.format("%02d", Integer.parseInt(string));
            return string;
        }
        catch (Exception exception) {
            this.logger(2, "getKernelID() ", exception);
            return null;
        }
    }

    private AmountLimitConfig fillInAmountLimitConfig(YP_Row yP_Row, long l) {
        String string;
        AmountLimitConfig amountLimitConfig = new AmountLimitConfig();
        amountLimitConfig.AllowCards = false;
        amountLimitConfig.AllowCash = false;
        amountLimitConfig.AllowCashback = false;
        amountLimitConfig.AllowMobileDevices = true;
        amountLimitConfig.CvmRequiredLimit = yP_Row.getFieldStringValueByName("readerCVMRequiredLimit");
        amountLimitConfig.FloorLimit = yP_Row.getFieldStringValueByName("readerContactlessFloorLimit");
        if (yP_Row.getFieldStringValueByName("transactionType").contentEquals("20")) {
            amountLimitConfig.AllowRefund = true;
            amountLimitConfig.AllowSale = false;
        } else {
            amountLimitConfig.AllowRefund = false;
            amountLimitConfig.AllowSale = true;
        }
        String string2 = this.getKernelID(yP_Row);
        if (string2 == null) {
            this.logger(2, "fillInAmountLimitConfig() kernID null!!!");
            return null;
        }
        if (string2.contentEquals("02")) {
            string = yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitOnDevice");
            try {
                string = Long.toString(Math.min(Long.parseLong(string), l));
            }
            catch (Exception exception) {}
            amountLimitConfig.OnDeviceCvmTransactionLimit = string;
        }
        amountLimitConfig.TerminalFloorLimit = yP_Row.getFieldStringValueByName("terminalFloorLimit");
        string = yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitNoOnDevice");
        try {
            string = string2.contentEquals("03") || string2.contentEquals("04") ? Long.toString(Math.min(Long.parseLong(string), l + 1L)) : Long.toString(Math.min(Long.parseLong(string), l));
        }
        catch (Exception exception) {}
        amountLimitConfig.TransactionLimit = string;
        amountLimitConfig.Currency = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
        return amountLimitConfig;
    }

    private int isAmountLimitConfigPresent(AmountLimitConfig amountLimitConfig) {
        if (this.amountLimitConfigList.size() <= 0) {
            return -1;
        }
        int n = 0;
        while (n < this.amountLimitConfigList.size()) {
            if (this.amountLimitConfigList.get(n).isEqual(amountLimitConfig)) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    private List<YP_Row> getPartialAIDRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        String string2 = string.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("partialSelectionAllowed", YP_ComplexGabarit.OPERATOR.EQUAL, true);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() == 0) {
            return null;
        }
        for (YP_Row yP_Row : list) {
            String string3 = yP_Row.getFieldStringValueByName("pix");
            if (!string.startsWith(String.valueOf(string2) + string3)) continue;
            arrayList.add(yP_Row);
        }
        return arrayList;
    }

    private String getTerminalType() {
        YP_Row yP_Row = this.getDataContainerTransaction().getTerminalRow();
        if (yP_Row == null) {
            return "22";
        }
        String string = yP_Row.getFieldStringValueByName("terminalType");
        if (string == null || string.isEmpty()) {
            return "22";
        }
        return string;
    }

    private KernelCtlConfig fillInSPmxKernelCfg(YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, YP_Row yP_Row) {
        String string;
        String string2;
        Object object2;
        Cloneable cloneable;
        List<YP_Row> list;
        if (this.getLogLevel() == 6) {
            this.logger(6, "fillInSPmxKernelCfg");
        }
        KernelCtlConfig kernelCtlConfig = new KernelCtlConfig();
        String string3 = yP_Row.getFieldStringValueByName("applicationIdentifier");
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getAIDTable();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        if (string3.length() < 10) {
            this.logger(3, "fillInSPmxKernelCfg: aid length invalid: " + string3.length());
            return null;
        }
        String string4 = string3.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
        String string5 = null;
        if (string3.length() > 10) {
            string5 = string3.substring(10);
            yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.START_WITH, string5);
        }
        if (((list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit)) == null || list.isEmpty()) && ((list = this.getPartialAIDRow(yP_TCD_DesignAccesObject, string3)) == null || list.isEmpty())) {
            this.logger(3, "fillInSPmxKernelCfg: aid not found for " + string3);
            return null;
        }
        kernelCtlConfig.aid = string3;
        String string6 = this.getKernelID(yP_Row);
        if (string6 == null) {
            this.logger(3, "fillInSPmxKernelCfg: kernelID missing for " + string3);
            return null;
        }
        kernelCtlConfig.kernelID = string6;
        kernelCtlConfig.isFrenchAID = string4.toUpperCase().contentEquals("A000000042") || string4.toUpperCase().contentEquals("D250000012");
        kernelCtlConfig.AdditionalTerminalCapabilities = defaultAdditionalTerminalCapabilities;
        kernelCtlConfig.AllowLOA = false;
        Boolean bl = (Boolean)list.get(0).getFieldValueByName("partialSelectionAllowed");
        kernelCtlConfig.AllowPartialMatch = bl != null && bl != false;
        String string7 = yP_Row.getFieldStringValueByName("statusCheckSupport");
        kernelCtlConfig.AllowStatusCheck = string7 != null && string7.contentEquals(NEPTING);
        String string8 = yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport");
        kernelCtlConfig.AllowZeroAmount = string8 != null && string8.contentEquals(NEPTING);
        if (string6.contentEquals("04")) {
            kernelCtlConfig.AmexProcessingRrequired = true;
            kernelCtlConfig.ExpressPayRandomNumberScope = 60;
            kernelCtlConfig.ExpressPayTerminalCapabilities = "C0";
            kernelCtlConfig.ExpressPayTerminalTransactionCapabilities = "D8A00000";
        } else {
            kernelCtlConfig.AmexProcessingRrequired = false;
        }
        String string9 = yP_TCD_DCB_Interface_CTCL.getForbiddenProduct(string3);
        if (string9 != null) {
            kernelCtlConfig.ForbiddenProduct = string9;
            try {
                kernelCtlConfig.ForbiddenProductList = new ArrayList<String>();
                cloneable = yP_TCD_DCB_Interface_CTCL.getProductListTable();
                if (cloneable != null) {
                    object2 = new YP_ComplexGabarit((YP_TCD_DesignAccesObject)cloneable);
                    ((YP_ComplexGabarit)object2).set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                    List<YP_Row> list2 = ((YP_TCD_DesignAccesObject)cloneable).getRowListSuchAs(new YP_ComplexGabarit[]{object2});
                    for (YP_Row object3 : list2) {
                        string2 = object3.getFieldStringValueByName("codeProduit");
                        if (string2 == null || string2.isEmpty()) {
                            this.logger(3, "fillInSPmxKernelCfg() product code missing!!!");
                            continue;
                        }
                        if (kernelCtlConfig.ForbiddenProductList.contains(string2)) continue;
                        if (kernelCtlConfig.ForbiddenProductList.size() > 4) {
                            this.logger(2, "fillInSPmxKernelCfg() too many products for " + string3);
                            continue;
                        }
                        kernelCtlConfig.ForbiddenProductList.add(string2);
                    }
                }
            }
            catch (Exception exception) {
                this.logger(3, "fillInSPmxKernelCfg() ", exception);
            }
        }
        if ((cloneable = yP_TCD_DCB_Interface_CTCL.getAIDParameters(string3)) == null) {
            this.logger(3, "fillInSPmxKernelCfg() " + string3);
            return null;
        }
        kernelCtlConfig.DefaultDDOL = ((YP_Row)cloneable).getFieldStringValueByName("defaultDDOL");
        kernelCtlConfig.DefaultTDOL = ((YP_Row)cloneable).getFieldStringValueByName("defaultTDOL");
        kernelCtlConfig.DefaultUDOL = defaultUDOL;
        object2 = new StringBuilder();
        int n = 0;
        while (n < list.size()) {
            int n2 = (Integer)list.get(n).getFieldValueByName("terminalApplicationVersionNumber");
            if (n != 0) {
                ((StringBuilder)object2).append(",");
            }
            ((StringBuilder)object2).append(String.format("%4s", Integer.toHexString(n2)).replace(' ', '0'));
            ++n;
        }
        kernelCtlConfig.EmvApplicationVersionList = ((StringBuilder)object2).toString().toUpperCase();
        if (string6.contentEquals("03")) {
            kernelCtlConfig.EmvSupported = true;
        }
        if (string6.contentEquals("02")) {
            kernelCtlConfig.MasterCardProcessingRequired = true;
            kernelCtlConfig.MsdApplicationVersionList = kernelCtlConfig.EmvApplicationVersionList;
            if (kernelCtlConfig.aid.toUpperCase().contentEquals("A0000000043060") || kernelCtlConfig.aid.toUpperCase().contentEquals("A0000000425010") || kernelCtlConfig.aid.toUpperCase().contentEquals("A0000000422010")) {
                kernelCtlConfig.EmvSupported = true;
            }
        } else {
            kernelCtlConfig.MasterCardProcessingRequired = false;
        }
        kernelCtlConfig.NoCardholderConfirmation = false;
        kernelCtlConfig.OnlineCryptogramOnZeroAmount = false;
        String string10 = yP_Row.getFieldStringValueByName("readerCVMRequiredLimit");
        kernelCtlConfig.PerformCvmRequiredLimitCheck = !string10.contentEquals("999999999999");
        String string11 = yP_Row.getFieldStringValueByName("readerContactlessFloorLimit");
        kernelCtlConfig.PerformFloorLimitCheck = !string11.contentEquals("999999999999");
        kernelCtlConfig.PerformStatusCheck = false;
        kernelCtlConfig.PerformZeroAmountCheck = true;
        kernelCtlConfig.PerformTransactionLimitCheck = true;
        kernelCtlConfig.PriorityIndicator = (Integer)list.get(0).getFieldValueByName("priority");
        kernelCtlConfig.RebootAfterGPO = false;
        kernelCtlConfig.TerminalActionCodeDefault = yP_Row.getFieldStringValueByName("tacDefault");
        kernelCtlConfig.TerminalActionCodeDenial = yP_Row.getFieldStringValueByName("tacDenial");
        kernelCtlConfig.TerminalActionCodeOnline = yP_Row.getFieldStringValueByName("tacOnline");
        Object object4 = new byte[defaultTerminalCapabilities.length];
        string2 = yP_Row.getFieldStringValueByName("signatureHandled");
        if (this.getTerminalType().contentEquals("25")) {
            string2 = "false";
        }
        String string12 = yP_Row.getFieldStringValueByName("pinOnlineHandled");
        String string13 = yP_Row.getFieldStringValueByName("noCVMHandled");
        if (yP_Row.getFieldStringValueByName("transactionType").contentEquals("20")) {
            string = "true";
            kernelCtlConfig.OnDeviceCvmSupported = true;
        } else {
            string = yP_Row.getFieldStringValueByName("onDeviceCVMHandled");
            kernelCtlConfig.OnDeviceCvmSupported = string != null && string.contentEquals("true");
        }
        switch (string6) {
            case "02": {
                kernelCtlConfig.TerminalCapabilitiesMsd = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe);
                kernelCtlConfig.TerminalCapabilitiesNoCvm = UtilsYP.devHexa(terminalCapabilitiesNoCVMMC);
                System.arraycopy(terminalCapabilitiesMC, 0, object4, 0, terminalCapabilitiesMC.length);
                if (string2 != null && string2.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x20);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xDF);
                }
                if (string12 != null && string12.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x40);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xBF);
                }
                if (string13 != null && string13.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 8);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xF7);
                }
                kernelCtlConfig.TerminalCapabilities = UtilsYP.devHexa((byte[])object4);
                break;
            }
            case "03": {
                kernelCtlConfig.TerminalCapabilitiesNoCvm = UtilsYP.devHexa(terminalCapabilitiesNoCVMVISA);
                System.arraycopy(terminalCapabilitiesVISA, 0, object4, 0, terminalCapabilitiesVISA.length);
                if (string2 != null && string2.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x20);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xDF);
                }
                if (string12 != null && string12.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x40);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xBF);
                }
                if (string13 != null && string13.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 8);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xF7);
                }
                kernelCtlConfig.TerminalCapabilities = UtilsYP.devHexa((byte[])object4);
                break;
            }
            case "04": {
                kernelCtlConfig.TerminalCapabilities = UtilsYP.devHexa(terminalCapabilitiesAMEX);
                break;
            }
            default: {
                kernelCtlConfig.TerminalCapabilitiesNoCvm = UtilsYP.devHexa(defaultTerminalCapabilitiesNoCVM);
                System.arraycopy(defaultTerminalCapabilities, 0, object4, 0, defaultTerminalCapabilities.length);
                if (string2 != null && string2.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x20);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xDF);
                }
                if (string12 != null && string12.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 0x40);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xBF);
                }
                if (string13 != null && string13.contentEquals("true")) {
                    Object object = object4;
                    object[1] = (byte)(object[1] | 8);
                } else {
                    Object object = object4;
                    object[1] = (byte)(object[1] & 0xF7);
                }
                kernelCtlConfig.TerminalCapabilities = UtilsYP.devHexa((byte[])object4);
            }
        }
        if (this.getLogLevel() >= 5) {
            this.logger(5, "fillInSPmxKernelCfg() : 0x" + kernelCtlConfig.TerminalCapabilities);
        }
        if (string6.contentEquals("03")) {
            kernelCtlConfig.VisaPreProcessingRequired = true;
            kernelCtlConfig.VisaTTQPresent = true;
            byte[] byArray = UtilsYP.redHexa(defaultVISATTQ);
            byte[] byArray2 = UtilsYP.redHexa(defaultVISARefunTTQ);
            if (string2 != null && string2.contentEquals("true")) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : signature supported for VISA kernel");
                }
                byArray[0] = (byte)(byArray[0] | 2);
                byArray2[0] = (byte)(byArray2[0] | 2);
            } else {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : signature NOT supported for VISA kernel");
                }
                byArray[0] = (byte)(byArray[0] & 0xFD);
                byArray2[0] = (byte)(byArray2[0] & 0xFD);
            }
            if (string12 != null && string12.contentEquals("true")) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : PIN Online supported for VISA kernel");
                }
                byArray[0] = (byte)(byArray[0] | 4);
                byArray2[0] = (byte)(byArray2[0] | 4);
            } else {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : PIN Online NOT supported for VISA kernel");
                }
                byArray[0] = (byte)(byArray[0] & 0xFB);
                byArray2[0] = (byte)(byArray2[0] & 0xFB);
            }
            if (string != null && string.contentEquals("true")) {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : On Device CVM supported for VISA kernel");
                }
                byArray[2] = (byte)(byArray[2] | 0x40);
                byArray2[2] = (byte)(byArray2[2] | 0x40);
            } else {
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "fillInSPmxKernelCfg() : On Device CVM NOT supported for VISA kernel");
                }
                byArray[2] = (byte)(byArray[2] & 0xBF);
                byArray2[2] = (byte)(byArray2[2] & 0xBF);
            }
            kernelCtlConfig.TerminalTransactionQualifier = UtilsYP.devHexa(byArray);
            kernelCtlConfig.TerminalTransactionQualifierRefund = UtilsYP.devHexa(byArray2);
        } else {
            kernelCtlConfig.VisaPreProcessingRequired = false;
        }
        return kernelCtlConfig;
    }

    private int isKernelCtlConfigPresent(KernelCtlConfig kernelCtlConfig) {
        if (this.kernelCtlConfigList.isEmpty()) {
            return -1;
        }
        int n = 0;
        while (n < this.kernelCtlConfigList.size()) {
            if (this.kernelCtlConfigList.get(n).isEqual(kernelCtlConfig)) {
                return n;
            }
            ++n;
        }
        return -1;
    }

    private DynamicLimitConfig fillInDynamicLimitConfig(YP_Row yP_Row) {
        DynamicLimitConfig dynamicLimitConfig = new DynamicLimitConfig();
        String string = yP_Row.getFieldStringValueByName("statusCheckSupport");
        dynamicLimitConfig.AllowStatusCheck = string != null && string.contentEquals("0");
        String string2 = yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport");
        dynamicLimitConfig.AllowZeroAmount = string2 != null && string2.contentEquals("0");
        dynamicLimitConfig.CvmRequiredLimit = yP_Row.getFieldStringValueByName("CVMRequiredLimit");
        dynamicLimitConfig.PerformCvmRequiredLimitCheck = !dynamicLimitConfig.CvmRequiredLimit.contentEquals("999999999999");
        dynamicLimitConfig.FloorLimit = yP_Row.getFieldStringValueByName("ctlFloorLimit");
        dynamicLimitConfig.PerformFloorLimitCheck = !dynamicLimitConfig.FloorLimit.contentEquals("999999999999");
        dynamicLimitConfig.OnlineCryptogramOnZeroAmount = false;
        dynamicLimitConfig.PerformStatusCheck = false;
        dynamicLimitConfig.PerformZeroAmountCheck = true;
        dynamicLimitConfig.ProgramId = yP_Row.getFieldStringValueByName("applicationPgmId");
        dynamicLimitConfig.PerformTransactionLimitCheck = true;
        dynamicLimitConfig.TransactionLimit = yP_Row.getFieldStringValueByName("ctlTransactionLimit");
        if (dynamicLimitConfig.TransactionLimit.contentEquals("999999999999")) {
            dynamicLimitConfig.PerformTransactionLimitCheck = false;
        }
        return dynamicLimitConfig;
    }

    private boolean fillInSPxxxPublicKeys(Terminal terminal, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL) {
        try {
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillInSPxxxPublicKeys");
            }
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getKeysTable();
            if (this.publicKeyLISTS == null) {
                this.publicKeyLISTS = new PublicKeyLISTSType();
            }
            for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                String string;
                PublicKeyRecordType publicKeyRecordType = new PublicKeyRecordType();
                String string2 = yP_Row.getFieldStringValueByName("rid");
                int n = (Integer)yP_Row.getFieldValueByName("index");
                String string3 = Integer.toHexString(n).toUpperCase();
                if (string3.length() % 2 == 1) {
                    string3 = String.valueOf('0') + string3;
                }
                int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                String string4 = "0";
                if (n2 == 3) {
                    string = "00000003";
                    string4 = "03";
                } else if (n2 == 65537) {
                    string = "00010001";
                    string4 = "010001";
                } else {
                    string = Integer.toHexString(n2);
                    if (string.length() % 2 == 1) {
                        string = String.valueOf('0') + string;
                    }
                }
                String string5 = yP_Row.getFieldStringValueByName("keyValue");
                publicKeyRecordType.setRID(string2);
                publicKeyRecordType.setINDEX(string3);
                publicKeyRecordType.setEXPONENT(string);
                publicKeyRecordType.setKEY(string5);
                publicKeyRecordType.setEXPIRYDATE("291231");
                publicKeyRecordType.setALGORITHM1("01");
                publicKeyRecordType.setALGORITHM2("01");
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                String string6 = String.valueOf(string2) + string3 + string5 + string4;
                publicKeyRecordType.setHASH(UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string6))));
                if (this.publicKeyLISTS == null) continue;
                this.publicKeyLISTS.getRecord().add(publicKeyRecordType);
            }
        }
        catch (Exception exception) {
            this.logger(2, "fillInSPxxxPublicKeys: ", exception);
            return false;
        }
        return true;
    }

    private TAIDTABRecordType fillInTaidTabRecord(KernelCtlConfig kernelCtlConfig) {
        TAIDTABRecordType tAIDTABRecordType = new TAIDTABRecordType();
        try {
            Object object;
            tAIDTABRecordType.setTAIDNAME(kernelCtlConfig.aid);
            tAIDTABRecordType.setTAIDKERNELAPP(kernelCtlConfig.kernelID);
            if (kernelCtlConfig.TerminalCapabilities != null) {
                tAIDTABRecordType.setTAIDTCAP(kernelCtlConfig.TerminalCapabilities);
            }
            if (kernelCtlConfig.TerminalCapabilitiesNoCvm != null) {
                tAIDTABRecordType.setTAIDTCAPNOCVM(kernelCtlConfig.TerminalCapabilitiesNoCvm);
            }
            tAIDTABRecordType.setTAIDADDTCAP(kernelCtlConfig.AdditionalTerminalCapabilities);
            String string = kernelCtlConfig.EmvApplicationVersionList.replaceAll(",", "");
            int n = string.length() / 4;
            tAIDTABRecordType.setTAIDVERLIST(String.valueOf(String.format("%02d", n)) + string);
            if (kernelCtlConfig.MsdApplicationVersionList != null) {
                object = kernelCtlConfig.MsdApplicationVersionList.replaceAll(",", "");
                n = ((String)object).length() / 4;
                tAIDTABRecordType.setTAIDMAGVERLIST(String.valueOf(String.format("%02d", n)) + (String)object);
            }
            if (Integer.parseInt(kernelCtlConfig.kernelID) == 2) {
                if (kernelCtlConfig.EmvSupported) {
                    if (this.getTerminalType().contentEquals("25")) {
                        tAIDTABRecordType.setTAIDADDTAGS("0F9F1D080C00800000000000DF810400");
                    } else {
                        tAIDTABRecordType.setTAIDADDTAGS("0F9F1D082C00800000000000DF810400");
                    }
                } else if (this.getTerminalType().contentEquals("25")) {
                    tAIDTABRecordType.setTAIDADDTAGS("0F9F1D080C00000000000000DF810400");
                } else {
                    tAIDTABRecordType.setTAIDADDTAGS("0F9F1D082C00000000000000DF810400");
                }
            }
            if (kernelCtlConfig.DefaultDDOL != null) {
                tAIDTABRecordType.setTAIDDEFDDOL(String.valueOf(String.format("%02X", kernelCtlConfig.DefaultDDOL.length() / 2)) + kernelCtlConfig.DefaultDDOL);
            }
            if (kernelCtlConfig.DefaultTDOL != null) {
                tAIDTABRecordType.setTAIDDEFTDOL(String.valueOf(String.format("%02X", kernelCtlConfig.DefaultTDOL.length() / 2)) + kernelCtlConfig.DefaultTDOL);
            }
            if (kernelCtlConfig.DefaultUDOL != null) {
                tAIDTABRecordType.setTAIDDEFUDOL(String.valueOf(String.format("%02X", kernelCtlConfig.DefaultUDOL.length() / 2)) + kernelCtlConfig.DefaultUDOL);
            }
            if (Integer.parseInt(kernelCtlConfig.kernelID) == 4) {
                if (kernelCtlConfig.ExpressPayRandomNumberScope >= 0) {
                    tAIDTABRecordType.setTAIDEXPRAND(String.format("%d", kernelCtlConfig.ExpressPayRandomNumberScope));
                }
                if (kernelCtlConfig.ExpressPayTerminalCapabilities != null) {
                    tAIDTABRecordType.setTAIDEXPCAP(kernelCtlConfig.ExpressPayTerminalCapabilities);
                }
                if (kernelCtlConfig.ExpressPayTerminalTransactionCapabilities != null) {
                    tAIDTABRecordType.setTAIDTTC(kernelCtlConfig.ExpressPayTerminalTransactionCapabilities);
                }
            }
            if (kernelCtlConfig.PriorityIndicator >= 0) {
                tAIDTABRecordType.setTAIDPRIORITYIND(String.format("%X", kernelCtlConfig.PriorityIndicator));
            }
            if (kernelCtlConfig.TerminalActionCodeDefault != null) {
                tAIDTABRecordType.setTAIDTACDEF(kernelCtlConfig.TerminalActionCodeDefault);
            }
            if (kernelCtlConfig.TerminalActionCodeDenial != null) {
                tAIDTABRecordType.setTAIDTACDEN(kernelCtlConfig.TerminalActionCodeDenial);
            }
            if (kernelCtlConfig.TerminalActionCodeOnline != null) {
                tAIDTABRecordType.setTAIDTACONL(kernelCtlConfig.TerminalActionCodeOnline);
            }
            if (kernelCtlConfig.TerminalTransactionQualifier != null) {
                tAIDTABRecordType.setTAIDVISATTQ(kernelCtlConfig.TerminalTransactionQualifier);
            }
            if (kernelCtlConfig.TerminalTransactionQualifierCash != null) {
                tAIDTABRecordType.setTAIDCASHTTQ(kernelCtlConfig.TerminalTransactionQualifierCash);
            }
            if (kernelCtlConfig.TerminalTransactionQualifierCashback != null) {
                tAIDTABRecordType.setTAIDCASHBACKTTQ(kernelCtlConfig.TerminalTransactionQualifierCashback);
            }
            if (kernelCtlConfig.TerminalTransactionQualifierRefund != null) {
                tAIDTABRecordType.setTAIDREFUNDTTQ(kernelCtlConfig.TerminalTransactionQualifierRefund);
            }
            if (kernelCtlConfig.ForbiddenProduct != null) {
                tAIDTABRecordType.setTAIDASPRD(kernelCtlConfig.ForbiddenProduct);
            }
            byte[] byArray = new byte[4];
            byArray[0] = 16;
            byArray[3] = 1;
            object = byArray;
            if (kernelCtlConfig.AllowLOA) {
                Object object2 = object;
                object2[2] = (byte)(object2[2] + 64);
            }
            if (kernelCtlConfig.AllowPartialMatch) {
                Object object3 = object;
                object3[1] = (byte)(object3[1] + 4);
            }
            if (kernelCtlConfig.AllowStatusCheck) {
                Object object4 = object;
                object4[0] = (byte)(object4[0] + 2);
            }
            if (kernelCtlConfig.AllowZeroAmount) {
                Object object5 = object;
                object5[0] = (byte)(object5[0] + 8);
            }
            if (kernelCtlConfig.AmexProcessingRrequired) {
                Object object6 = object;
                object6[2] = (byte)(object6[2] + 32);
            }
            if (kernelCtlConfig.EmvSupported) {
                Object object7 = object;
                object7[1] = (byte)(object7[1] + true);
            }
            if (kernelCtlConfig.MasterCardProcessingRequired) {
                Object object8 = object;
                object8[2] = (byte)(object8[2] + -128);
            }
            if (kernelCtlConfig.MsdSupported) {
                Object object9 = object;
                object9[1] = (byte)(object9[1] + 2);
            }
            if (kernelCtlConfig.NoCardholderConfirmation) {
                Object object10 = object;
                object10[2] = (byte)(object10[2] + 8);
            }
            if (kernelCtlConfig.OnDeviceCvmSupported) {
                Object object11 = object;
                object11[1] = (byte)(object11[1] + 8);
            }
            if (kernelCtlConfig.isFrenchAID) {
                Object object12 = object;
                object12[1] = (byte)(object12[1] + 16);
            }
            if (kernelCtlConfig.OnlineCryptogramOnZeroAmount) {
                Object object13 = object;
                object13[0] = (byte)(object13[0] + 16);
            }
            if (kernelCtlConfig.PerformCvmRequiredLimitCheck) {
                Object object14 = object;
                object14[0] = (byte)(object14[0] + -128);
            }
            if (kernelCtlConfig.PerformFloorLimitCheck) {
                Object object15 = object;
                object15[0] = (byte)(object15[0] + 32);
            }
            if (kernelCtlConfig.PerformStatusCheck) {
                Object object16 = object;
                object16[0] = (byte)(object16[0] + true);
            }
            if (kernelCtlConfig.PerformTransactionLimitCheck) {
                Object object17 = object;
                object17[0] = (byte)(object17[0] + 64);
            }
            if (kernelCtlConfig.PerformZeroAmountCheck) {
                Object object18 = object;
                object18[0] = (byte)(object18[0] + 4);
            }
            if (kernelCtlConfig.RebootAfterGPO) {
                Object object19 = object;
                object19[2] = (byte)(object19[2] + 4);
            }
            if (kernelCtlConfig.VisaPreProcessingRequired) {
                Object object20 = object;
                object20[2] = (byte)(object20[2] + 2);
            }
            if (kernelCtlConfig.VisaTTQPresent) {
                Object object21 = object;
                object21[2] = (byte)(object21[2] + true);
                Object object22 = object;
                object22[2] = (byte)(object22[2] + 16);
            }
            tAIDTABRecordType.setTAIDSPECIFIC(UtilsYP.devHexa((byte[])object));
        }
        catch (Exception exception) {
            this.logger(2, "fillInTaidTabRecord: ", exception);
            return null;
        }
        return tAIDTABRecordType;
    }

    private TAIDAMTRecordType fillInTaidAmtRecord(String string, String string2, AmountLimitConfig amountLimitConfig, KernelCtlConfig kernelCtlConfig) {
        TAIDAMTRecordType tAIDAMTRecordType = new TAIDAMTRecordType();
        byte[] byArray = new byte[2];
        byArray[1] = 32;
        byte[] byArray2 = byArray;
        try {
            if (amountLimitConfig.AllowRefund) {
                byArray2[0] = (byte)(byArray2[0] + 8);
                if (kernelCtlConfig.MasterCardProcessingRequired) {
                    byArray2[1] = (byte)(byArray2[1] + 64);
                }
            } else {
                byArray2[0] = (byte)(byArray2[0] + 1);
            }
            tAIDAMTRecordType.setAMTRID(string);
            tAIDAMTRecordType.setAMTKID(string2);
            if (amountLimitConfig.CvmRequiredLimit != null) {
                byArray2[1] = (byte)(byArray2[1] + 8);
                tAIDAMTRecordType.setAMTTCVL(String.format("%012d", Long.parseLong(amountLimitConfig.CvmRequiredLimit)));
            }
            if (amountLimitConfig.FloorLimit != null) {
                byArray2[1] = (byte)(byArray2[1] + 2);
                if (amountLimitConfig.AllowRefund) {
                    tAIDAMTRecordType.setAMTTCFL(String.format("%012d", Long.parseLong("0")));
                } else {
                    tAIDAMTRecordType.setAMTTCFL(String.format("%012d", Long.parseLong(amountLimitConfig.FloorLimit)));
                }
            }
            if (amountLimitConfig.OnDeviceCvmTransactionLimit != null) {
                byArray2[1] = (byte)(byArray2[1] + 16);
                tAIDAMTRecordType.setAMTTCTL2(String.format("%012d", Long.parseLong(amountLimitConfig.OnDeviceCvmTransactionLimit)));
            }
            if (amountLimitConfig.TerminalFloorLimit != null) {
                byArray2[1] = (byte)(byArray2[1] + 1);
                tAIDAMTRecordType.setAMTTFL(String.format("%012d", Long.parseLong(amountLimitConfig.TerminalFloorLimit)));
            }
            if (amountLimitConfig.TransactionLimit != null) {
                byArray2[1] = (byte)(byArray2[1] + 4);
                tAIDAMTRecordType.setAMTTCTL(String.format("%012d", Long.parseLong(amountLimitConfig.TransactionLimit)));
            }
            tAIDAMTRecordType.setAMTBITMAP(UtilsYP.devHexa(byArray2));
            if (amountLimitConfig.Currency != null) {
                tAIDAMTRecordType.setAMTCURRENCY(String.format("%04d", Integer.parseInt(amountLimitConfig.Currency)));
            }
        }
        catch (Exception exception) {
            this.logger(2, "fillInTaidAmtRecord: ", exception);
            return null;
        }
        return tAIDAMTRecordType;
    }

    private TDRLRecordType fillInTDrlRecord(DynamicLimitConfig dynamicLimitConfig) {
        TDRLRecordType tDRLRecordType = new TDRLRecordType();
        try {
            tDRLRecordType.setDRLAPPPROGID(dynamicLimitConfig.ProgramId);
            byte[] byArray = new byte[2];
            if (dynamicLimitConfig.AllowStatusCheck) {
                byArray[0] = (byte)(byArray[0] + 2);
            }
            if (dynamicLimitConfig.AllowZeroAmount) {
                byArray[0] = (byte)(byArray[0] + 8);
            }
            if (dynamicLimitConfig.OnlineCryptogramOnZeroAmount) {
                byArray[0] = (byte)(byArray[0] + 16);
            }
            if (dynamicLimitConfig.PerformCvmRequiredLimitCheck) {
                byArray[0] = (byte)(byArray[0] + -128);
            }
            if (dynamicLimitConfig.PerformFloorLimitCheck) {
                byArray[0] = (byte)(byArray[0] + 32);
            }
            if (dynamicLimitConfig.PerformStatusCheck) {
                byArray[0] = (byte)(byArray[0] + 1);
            }
            if (dynamicLimitConfig.PerformTransactionLimitCheck) {
                byArray[0] = (byte)(byArray[0] + 64);
            }
            if (dynamicLimitConfig.PerformZeroAmountCheck) {
                byArray[0] = (byte)(byArray[0] + 4);
            }
            tDRLRecordType.setDRLLCB(UtilsYP.devHexa(byArray));
            if (dynamicLimitConfig.TransactionLimit != null) {
                tDRLRecordType.setDRLCTL(String.format("%012d", Long.parseLong(dynamicLimitConfig.TransactionLimit)));
            }
            if (dynamicLimitConfig.CvmRequiredLimit != null) {
                tDRLRecordType.setDRLCVL(String.format("%012d", Long.parseLong(dynamicLimitConfig.CvmRequiredLimit)));
            }
            if (dynamicLimitConfig.FloorLimit != null) {
                tDRLRecordType.setDRLCFL(String.format("%012d", Long.parseLong(dynamicLimitConfig.FloorLimit)));
            }
        }
        catch (Exception exception) {
            this.logger(2, "fillInTDrlRecord: ", exception);
            return null;
        }
        return tDRLRecordType;
    }

    private String fillInSPxxxAidParams(Terminal terminal) {
        try {
            Object object;
            Object object2;
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillInSPxxxAidParams ");
            }
            TAIDTABType tAIDTABType = new TAIDTABType();
            TAIDAMTType tAIDAMTType = new TAIDAMTType();
            int n = 0;
            while (n < this.kernelCtlConfigList.size()) {
                KernelCtlConfig kernelCtlConfig = this.kernelCtlConfigList.get(n);
                object2 = kernelCtlConfig.aid;
                object = String.format("%02d", Integer.parseInt(kernelCtlConfig.kernelID));
                TAIDTABRecordType tAIDTABRecordType = this.fillInTaidTabRecord(kernelCtlConfig);
                if (tAIDTABType != null) {
                    tAIDTABType.getRecord().add(tAIDTABRecordType);
                    int n2 = 0;
                    while (n2 < kernelCtlConfig.amountConfigList.size()) {
                        AmountLimitConfig amountLimitConfig = this.amountLimitConfigList.get(kernelCtlConfig.amountConfigList.get(n2));
                        TAIDAMTRecordType tAIDAMTRecordType = this.fillInTaidAmtRecord((String)object2, (String)object, amountLimitConfig, kernelCtlConfig);
                        if (tAIDAMTType != null) {
                            tAIDAMTType.getRecord().add(tAIDAMTRecordType);
                        }
                        ++n2;
                    }
                }
                ++n;
            }
            terminal.setTAIDTAB(tAIDTABType);
            terminal.setTAIDAMT(tAIDAMTType);
            TDRLType tDRLType = new TDRLType();
            int n3 = 0;
            while (n3 < this.dynamicLimitConfigList.size()) {
                object2 = this.dynamicLimitConfigList.get(n3);
                object = this.fillInTDrlRecord((DynamicLimitConfig)object2);
                if (tDRLType != null) {
                    tDRLType.getRecord().add((TDRLRecordType)object);
                }
                ++n3;
            }
            terminal.setTDRL(tDRLType);
        }
        catch (Exception exception) {
            this.logger(2, "fillInSPxxxAidParams: ", exception);
        }
        return null;
    }

    private String getConfigBitmap() {
        byte[] byArray = new byte[4];
        byArray[1] = 6;
        byArray[2] = -62;
        byte[] byArray2 = byArray;
        if (!UtilsYP.isMoroccoServer()) {
            byArray2[2] = (byte)(byArray2[2] | 4);
            byArray2[2] = (byte)(byArray2[2] | 8);
        }
        return UtilsYP.devHexa(byArray2);
    }

    private String fillInSPxxxTConfParams(Terminal terminal, YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        try {
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillInSPxxxTConfParams");
            }
            TCONFRecordType tCONFRecordType = new TCONFRecordType();
            tCONFRecordType.setTCTCAP("E060C8");
            tCONFRecordType.setTCADDTCAP(defaultAdditionalTerminalCapabilities);
            tCONFRecordType.setTCEMVTYPE(this.getTerminalType());
            try {
                tCONFRecordType.setTCCTRYCODE(String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getCountryCode())));
            }
            catch (Exception exception) {
                this.logger(2, "fillInSPxxxTConfParams() Bad country code ", exception);
                tCONFRecordType.setTCCTRYCODE("0250");
            }
            String string = yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode();
            if (string.length() % 2 != 0) {
                string = "0" + string;
            }
            tCONFRecordType.setTCACQID(string);
            try {
                tCONFRecordType.setMERCCATCODE(String.format("%02d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode())));
            }
            catch (Exception exception) {
                this.logger(2, "fillInSPxxxTConfParams() Bad MCC ", exception);
                tCONFRecordType.setMERCCATCODE("9999");
            }
            tCONFRecordType.setTCTID(yP_TCD_DCC_Business.getMerchantContract());
            tCONFRecordType.setTCDEFLANG("fr");
            tCONFRecordType.setTCEVENTMASK("00010000");
            tCONFRecordType.setCONFIGBITMAPS(this.getConfigBitmap());
            TCONFType tCONFType = new TCONFType();
            tCONFType.getRecord().add(tCONFRecordType);
            terminal.setTCONF(tCONFType);
        }
        catch (Exception exception) {
            this.logger(2, "fillInSPxxxTConfParams: ", exception);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String fillInSPxxxTagLists(Terminal terminal, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL) {
        try {
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillInSPxxxTagLists");
            }
            List<String> list = yP_TCD_DCB_Interface_CTCL.getKIDList();
            TAGLISTSType tAGLISTSType = terminal.getTAGLISTS();
            if (tAGLISTSType == null) {
                tAGLISTSType = new TAGLISTSType();
                terminal.setTAGLISTS(tAGLISTSType);
            } else if (!tAGLISTSType.getRecord().isEmpty() && tAGLISTSType.getRecord().get(0).getKERNELID().isEmpty()) {
                tAGLISTSType.getRecord().clear();
            }
            Iterator<String> iterator = list.iterator();
            while (true) {
                TAGLISTSRecordType tAGLISTSRecordType2;
                if (!iterator.hasNext()) {
                    return null;
                }
                String string = iterator.next();
                String string2 = String.format("%02d", Integer.parseInt(string));
                boolean bl = false;
                for (TAGLISTSRecordType tAGLISTSRecordType2 : tAGLISTSType.getRecord()) {
                    if (!tAGLISTSRecordType2.getKERNELID().contentEquals(string2)) continue;
                    bl = true;
                    break;
                }
                if (bl) continue;
                tAGLISTSRecordType2 = new TAGLISTSRecordType();
                tAGLISTSRecordType2.setKERNELID(string2);
                Object object = "005700005000005A00007100007200008200008900008A00008E00008F00009100009500009A00009B00009C005F24005F25005F2A005F30005F34009F02009F03009F06009F07009F08009F09009F0D009F0E009F0F009F10009F12009F17009F1A009F21009F26009F27009F33009F34009F35009F36009F37009F39009F41000084000087005F28005F2D009F11009F2A009F5A009F69009F6E009F7C00BF0C009F0A00";
                switch (string) {
                    case "02": {
                        object = String.valueOf(object) + "DF74009F6B00005600DF4B009F7E009F5000";
                        break;
                    }
                    case "03": {
                        object = String.valueOf(object) + "004F009F5D009F66009F6C00";
                        break;
                    }
                    case "04": {
                        object = String.valueOf(object);
                        break;
                    }
                    default: {
                        return null;
                    }
                }
                tAGLISTSRecordType2.setLIST((String)object);
                tAGLISTSType.getRecord().add(tAGLISTSRecordType2);
            }
        }
        catch (Exception exception) {
            this.logger(2, "fillInSPxxxTagLists: ", exception);
        }
        return null;
    }

    private String formatSPxxxCtlData(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL) {
        try {
            if (this.getLogLevel() == 6) {
                this.logger(6, "formatSPxxxCtlData");
            }
            if (this.contactlessSPCParser == null) {
                this.contactlessSPCParser = (YP_GlobalComponent)this.getPluginByName("SpcCtclParser");
            }
            if (this.spxxxCfgData == null) {
                this.spxxxCfgData = (Terminal)this.contactlessSPCParser.dealRequest(this, "xmlFileToObject", String.valueOf(UtilsYP.getPath()) + "technics/xml/ctcl/ctcl_template.xml");
                this.fillInSPxxxTConfParams(this.spxxxCfgData, yP_TCD_DCC_Business);
            }
            this.fillInSPxxxPublicKeys(this.spxxxCfgData, yP_TCD_DCB_Interface_CTCL);
            this.fillInSPxxxTagLists(this.spxxxCfgData, yP_TCD_DCB_Interface_CTCL);
        }
        catch (Exception exception) {
            this.logger(2, "formatSPxxxCtlData: ", exception);
        }
        return null;
    }

    private String generateSPxxxCtlData() {
        try {
            if (this.getLogLevel() == 6) {
                this.logger(6, "generateSPxxxCtlData()");
            }
            if (this.spxxxCfgData != null && this.contactlessSPCParser != null) {
                String string = (String)this.contactlessSPCParser.dealRequest(this, "objectToXML", this.spxxxCfgData);
                if (this.getLogLevel() == 6) {
                    PrintWriter printWriter = new PrintWriter("./SPc5Generated.xml", "UTF-8");
                    printWriter.println(string);
                    printWriter.close();
                }
                return string;
            }
        }
        catch (Exception exception) {
            this.logger(2, "generateSPxxxCtlData(): ", exception);
        }
        return null;
    }

    private void addAmountLimitToKernelConfig(String string, String string2, int n) {
        if (this.kernelCtlConfigList.isEmpty()) {
            return;
        }
        int n2 = 0;
        while (n2 < this.kernelCtlConfigList.size()) {
            if (this.kernelCtlConfigList.get((Object)Integer.valueOf((int)n2)).aid.contentEquals(string) && this.kernelCtlConfigList.get((Object)Integer.valueOf((int)n2)).kernelID.contentEquals(string2)) {
                this.kernelCtlConfigList.get((Object)Integer.valueOf((int)n2)).amountConfigList.add(n);
            }
            ++n2;
        }
    }

    private void addDRLIndicator(String string) {
        try {
            int n = Integer.parseInt(string);
            int n2 = 0;
            while (n2 < this.kernelCtlConfigList.size()) {
                if (Integer.parseInt(this.kernelCtlConfigList.get((Object)Integer.valueOf((int)n2)).kernelID) == n) {
                    this.kernelCtlConfigList.get((Object)Integer.valueOf((int)n2)).supportDRL = true;
                }
                ++n2;
            }
        }
        catch (Exception exception) {
            return;
        }
    }

    private boolean fillSPmxCtlInternalStructure(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, int n) {
        Object object;
        List<YP_Row> list = yP_TCD_DCB_Interface_CTCL.getAIDKIDList(new Integer(n).toString());
        for (YP_Row yP_Row : list) {
            object = yP_Row.getFieldStringValueByName("applicationIdentifier");
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillSPmxCtlInternalStructure(): process contactless aid: " + (String)object);
            }
            if (yP_Row.getFieldStringValueByName("transactionType").contentEquals("20")) continue;
            KernelCtlConfig object2 = this.fillInSPmxKernelCfg(yP_TCD_DCB_Interface_CTCL, yP_Row);
            if (object2 == null) {
                this.logger(3, "fillSPmxCtlInternalStructure(): kernel Config null for " + (String)object);
                continue;
            }
            int n2 = this.isKernelCtlConfigPresent(object2);
            if (n2 != -1) continue;
            if (this.getLogLevel() == 6) {
                this.logger(6, "fillSPmxCtlInternalStructure(): kernel config missing, lets add it");
            }
            this.kernelCtlConfigList.put(this.kernelCtlConfigIndex++, object2);
        }
        long l = 99999999999L;
        object = (YP_TCD_DCB_Interface_Currency)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_Currency.class);
        if (object != null) {
            try {
                l = object.getCurrencyMaxAmount(n);
                if (l < 0L) {
                    this.logger(2, "checkAmount() unable to retrieve maximum amountbad");
                }
            }
            catch (Exception exception) {}
        }
        for (YP_Row yP_Row : list) {
            String string = yP_Row.getFieldStringValueByName("applicationIdentifier");
            String string2 = this.getKernelID(yP_Row);
            if (string2 == null) {
                this.logger(3, "fillSPmxCtlInternalStructure: kernelID missing for " + string);
                return false;
            }
            AmountLimitConfig amountLimitConfig = this.fillInAmountLimitConfig(yP_Row, l);
            if (amountLimitConfig == null) {
                this.logger(2, "fillSPmxCtlInternalStructure(): amountLimitConfig null");
                return false;
            }
            int n3 = this.isAmountLimitConfigPresent(amountLimitConfig);
            if (n3 == -1) {
                n3 = this.amountLimitConfigIndex;
                this.amountLimitConfigList.put(this.amountLimitConfigIndex++, amountLimitConfig);
            }
            this.addAmountLimitToKernelConfig(string, string2, n3);
            YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getDRLTable();
            if (yP_TCD_DesignAccesObject == null) continue;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            String string3 = String.format("%02d", Integer.parseInt(string2));
            yP_ComplexGabarit.set("kernelID", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
            List<YP_Row> list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            int n4 = -1;
            if (list2 == null || list2.size() <= 0) continue;
            this.addDRLIndicator(string3);
            int n5 = 0;
            while (n5 < list2.size()) {
                DynamicLimitConfig dynamicLimitConfig = this.fillInDynamicLimitConfig(list2.get(n5));
                if (dynamicLimitConfig == null) {
                    this.logger(2, "fillSPmxCtlInternalStructure(): dynamicLimitConfig null");
                    return false;
                }
                n4 = this.isDynamicLimitConfigPresent(dynamicLimitConfig);
                if (n4 == -1) {
                    n4 = this.dynamicLimitConfigIndex;
                    this.dynamicLimitConfigList.put(this.dynamicLimitConfigIndex++, dynamicLimitConfig);
                }
                ++n5;
            }
        }
        return true;
    }

    private String formatSPm2CtlData() {
        Object object;
        StringBuilder stringBuilder = new StringBuilder("");
        int n = 0;
        while (n < this.dynamicLimitConfigList.size()) {
            object = this.dynamicLimitConfigList.get(n);
            stringBuilder.append("#CTL_DynamicLimit" + n + ";\n");
            stringBuilder.append("ProgramId=" + ((DynamicLimitConfig)object).ProgramId + ";\n");
            if (((DynamicLimitConfig)object).AllowStatusCheck) {
                stringBuilder.append("AllowStatusCheck=" + ((DynamicLimitConfig)object).AllowStatusCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).AllowZeroAmount) {
                stringBuilder.append("AllowZeroAmount=" + ((DynamicLimitConfig)object).AllowZeroAmount + ";\n");
            }
            if (((DynamicLimitConfig)object).OnlineCryptogramOnZeroAmount) {
                stringBuilder.append("OnlineCryptogramOnZeroAmount=" + ((DynamicLimitConfig)object).OnlineCryptogramOnZeroAmount + ";\n");
            }
            if (((DynamicLimitConfig)object).PerformCvmRequiredLimitCheck) {
                stringBuilder.append("PerformCvmRequiredLimitCheck=" + ((DynamicLimitConfig)object).PerformCvmRequiredLimitCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).PerformFloorLimitCheck) {
                stringBuilder.append("PerformFloorLimitCheck=" + ((DynamicLimitConfig)object).PerformFloorLimitCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).PerformStatusCheck) {
                stringBuilder.append("PerformStatusCheck=" + ((DynamicLimitConfig)object).PerformStatusCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).PerformTransactionLimitCheck) {
                stringBuilder.append("PerformTransactionLimitCheck=" + ((DynamicLimitConfig)object).PerformTransactionLimitCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).PerformZeroAmountCheck) {
                stringBuilder.append("PerformZeroAmountCheck=" + ((DynamicLimitConfig)object).PerformZeroAmountCheck + ";\n");
            }
            if (((DynamicLimitConfig)object).TransactionLimit != null) {
                stringBuilder.append("TransactionLimit=" + ((DynamicLimitConfig)object).TransactionLimit + ";\n");
            }
            if (((DynamicLimitConfig)object).TransactionLimit != null) {
                stringBuilder.append("CvmRequiredLimit=" + ((DynamicLimitConfig)object).CvmRequiredLimit + ";\n");
            }
            if (((DynamicLimitConfig)object).TransactionLimit != null) {
                stringBuilder.append("FloorLimit=" + ((DynamicLimitConfig)object).FloorLimit + ";\n");
            }
            stringBuilder.append("\n");
            ++n;
        }
        n = 0;
        while (n < this.kernelCtlConfigList.size()) {
            object = this.kernelCtlConfigList.get(n);
            stringBuilder.append("#CTL_KernelConfiguration" + n + ";\n");
            if (((KernelCtlConfig)object).isFrenchAID) {
                stringBuilder.append("AllowKernelFallback=true;\n");
            }
            if (((KernelCtlConfig)object).AdditionalTerminalCapabilities != null) {
                stringBuilder.append("AdditionalTerminalCapabilities=" + ((KernelCtlConfig)object).AdditionalTerminalCapabilities + ";\n");
            }
            if (((KernelCtlConfig)object).DefaultDDOL != null) {
                stringBuilder.append("DefaultDDOL=" + ((KernelCtlConfig)object).DefaultDDOL + ";\n");
            }
            if (((KernelCtlConfig)object).DefaultTDOL != null) {
                stringBuilder.append("DefaultTDOL=" + ((KernelCtlConfig)object).DefaultTDOL + ";\n");
            }
            if (((KernelCtlConfig)object).DefaultUDOL != null) {
                stringBuilder.append("DefaultUDOL=" + ((KernelCtlConfig)object).DefaultUDOL + ";\n");
            }
            if (((KernelCtlConfig)object).EmvApplicationVersionList != null) {
                stringBuilder.append("EmvApplicationVersionList=" + ((KernelCtlConfig)object).EmvApplicationVersionList + ";\n");
            }
            if (((KernelCtlConfig)object).ExpressPayRandomNumberScope >= 0) {
                stringBuilder.append("ExpressPayRandomNumberScope=" + ((KernelCtlConfig)object).ExpressPayRandomNumberScope + ";\n");
            }
            if (((KernelCtlConfig)object).ExpressPayTerminalCapabilities != null) {
                stringBuilder.append("ExpressPayTerminalCapabilities=" + ((KernelCtlConfig)object).ExpressPayTerminalCapabilities + ";\n");
            }
            if (((KernelCtlConfig)object).ExpressPayTerminalTransactionCapabilities != null) {
                stringBuilder.append("ExpressPayTerminalTransactionCapabilities=" + ((KernelCtlConfig)object).ExpressPayTerminalTransactionCapabilities + ";\n");
            }
            if (((KernelCtlConfig)object).MsdApplicationVersionList != null) {
                stringBuilder.append("MsdApplicationVersionList=" + ((KernelCtlConfig)object).MsdApplicationVersionList + ";\n");
            }
            if (((KernelCtlConfig)object).PriorityIndicator >= 0) {
                stringBuilder.append("PriorityIndicator=" + ((KernelCtlConfig)object).PriorityIndicator + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalActionCodeDefault != null) {
                stringBuilder.append("TerminalActionCodeDefault=" + ((KernelCtlConfig)object).TerminalActionCodeDefault + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalActionCodeDenial != null) {
                stringBuilder.append("TerminalActionCodeDenial=" + ((KernelCtlConfig)object).TerminalActionCodeDenial + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalActionCodeOnline != null) {
                stringBuilder.append("TerminalActionCodeOnline=" + ((KernelCtlConfig)object).TerminalActionCodeOnline + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalCapabilities != null) {
                stringBuilder.append("TerminalCapabilities=" + ((KernelCtlConfig)object).TerminalCapabilities + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalCapabilitiesNoCvm != null) {
                stringBuilder.append("TerminalCapabilitiesNoCvm=" + ((KernelCtlConfig)object).TerminalCapabilitiesNoCvm + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalCapabilitiesMsd != null) {
                stringBuilder.append("MasterCardMagStripeCvmCapability=" + ((KernelCtlConfig)object).TerminalCapabilitiesMsd + ";\n");
                stringBuilder.append("MasterCardMagStripeNoCvmCapability=" + ((KernelCtlConfig)object).TerminalCapabilitiesMsd + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalTransactionQualifier != null) {
                stringBuilder.append("TerminalTransactionQualifier=" + ((KernelCtlConfig)object).TerminalTransactionQualifier + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalTransactionQualifierCash != null) {
                stringBuilder.append("TerminalTransactionQualifierCash=" + ((KernelCtlConfig)object).TerminalTransactionQualifierCash + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalTransactionQualifierCashback != null) {
                stringBuilder.append("TerminalTransactionQualifierCashback=" + ((KernelCtlConfig)object).TerminalTransactionQualifierCashback + ";\n");
            }
            if (((KernelCtlConfig)object).TerminalTransactionQualifierRefund != null) {
                stringBuilder.append("TerminalTransactionQualifierRefund=" + ((KernelCtlConfig)object).TerminalTransactionQualifierRefund + ";\n");
            }
            if (Integer.parseInt(((KernelCtlConfig)object).kernelID) == 2) {
                if (((KernelCtlConfig)object).EmvSupported) {
                    stringBuilder.append("AdditionalTags=9F1D082C00800000000000;\n");
                } else {
                    stringBuilder.append("AdditionalTags=9F1D082C00000000000000;\n");
                }
            }
            if (((KernelCtlConfig)object).AllowLOA) {
                stringBuilder.append("AllowLOA=" + ((KernelCtlConfig)object).AllowLOA + ";\n");
            }
            if (((KernelCtlConfig)object).AllowPartialMatch) {
                stringBuilder.append("AllowPartialMatch=" + ((KernelCtlConfig)object).AllowPartialMatch + ";\n");
            }
            if (((KernelCtlConfig)object).AllowStatusCheck) {
                stringBuilder.append("AllowStatusCheck=" + ((KernelCtlConfig)object).AllowStatusCheck + ";\n");
            }
            if (((KernelCtlConfig)object).AllowZeroAmount) {
                stringBuilder.append("AllowZeroAmount=" + ((KernelCtlConfig)object).AllowZeroAmount + ";\n");
            }
            if (((KernelCtlConfig)object).AmexProcessingRrequired) {
                stringBuilder.append("AmexProcessingRrequired=" + ((KernelCtlConfig)object).AmexProcessingRrequired + ";\n");
            }
            if (((KernelCtlConfig)object).EmvSupported) {
                stringBuilder.append("EmvSupported=" + ((KernelCtlConfig)object).EmvSupported + ";\n");
            }
            if (((KernelCtlConfig)object).MasterCardProcessingRequired) {
                stringBuilder.append("MasterCardProcessingRequired=" + ((KernelCtlConfig)object).MasterCardProcessingRequired + ";\n");
            }
            if (((KernelCtlConfig)object).MsdSupported) {
                stringBuilder.append("MsdSupported=" + ((KernelCtlConfig)object).MsdSupported + ";\n");
            }
            if (((KernelCtlConfig)object).NoCardholderConfirmation) {
                stringBuilder.append("NoCardholderConfirmation=" + ((KernelCtlConfig)object).NoCardholderConfirmation + ";\n");
            }
            if (((KernelCtlConfig)object).OnDeviceCvmSupported) {
                stringBuilder.append("OnDeviceCvmSupported=" + ((KernelCtlConfig)object).OnDeviceCvmSupported + ";\n");
            }
            if (((KernelCtlConfig)object).OnlineCryptogramOnZeroAmount) {
                stringBuilder.append("OnlineCryptogramOnZeroAmount=" + ((KernelCtlConfig)object).OnlineCryptogramOnZeroAmount + ";\n");
            }
            if (((KernelCtlConfig)object).PerformCvmRequiredLimitCheck) {
                stringBuilder.append("PerformCvmRequiredLimitCheck=" + ((KernelCtlConfig)object).PerformCvmRequiredLimitCheck + ";\n");
            }
            if (((KernelCtlConfig)object).PerformFloorLimitCheck) {
                stringBuilder.append("PerformFloorLimitCheck=" + ((KernelCtlConfig)object).PerformFloorLimitCheck + ";\n");
            }
            if (((KernelCtlConfig)object).PerformStatusCheck) {
                stringBuilder.append("PerformStatusCheck=" + ((KernelCtlConfig)object).PerformStatusCheck + ";\n");
            }
            if (((KernelCtlConfig)object).PerformTransactionLimitCheck) {
                stringBuilder.append("PerformTransactionLimitCheck=" + ((KernelCtlConfig)object).PerformTransactionLimitCheck + ";\n");
            }
            if (((KernelCtlConfig)object).PerformZeroAmountCheck) {
                stringBuilder.append("PerformZeroAmountCheck=" + ((KernelCtlConfig)object).PerformZeroAmountCheck + ";\n");
            }
            if (((KernelCtlConfig)object).RebootAfterGPO) {
                stringBuilder.append("RebootAfterGPO=" + ((KernelCtlConfig)object).RebootAfterGPO + ";\n");
            }
            if (((KernelCtlConfig)object).VisaPreProcessingRequired) {
                stringBuilder.append("VisaPreProcessingRequired=" + ((KernelCtlConfig)object).VisaPreProcessingRequired + ";\n");
            }
            if (((KernelCtlConfig)object).VisaTTQPresent) {
                stringBuilder.append("VisaTTQPresent=" + ((KernelCtlConfig)object).VisaTTQPresent + ";\n");
            }
            if (((KernelCtlConfig)object).supportDRL) {
                stringBuilder.append("AllowDynamicLimit=true;\n");
            }
            if (((KernelCtlConfig)object).ForbiddenProductList != null && !((KernelCtlConfig)object).ForbiddenProductList.isEmpty()) {
                stringBuilder.append("ForbiddenProducts=");
                int n2 = 0;
                while (n2 < ((KernelCtlConfig)object).ForbiddenProductList.size()) {
                    if (n2 != 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append(((KernelCtlConfig)object).ForbiddenProductList.get(n2));
                    ++n2;
                }
                stringBuilder.append(";\r\n");
            }
            stringBuilder.append("\n");
            ++n;
        }
        n = 0;
        while (n < this.amountLimitConfigList.size()) {
            object = this.amountLimitConfigList.get(n);
            stringBuilder.append("#CTL_AmountLimit" + n + ";\n");
            if (((AmountLimitConfig)object).CvmRequiredLimit != null) {
                stringBuilder.append("CvmRequiredLimit=" + ((AmountLimitConfig)object).CvmRequiredLimit + ";\n");
            }
            if (((AmountLimitConfig)object).FloorLimit != null) {
                stringBuilder.append("FloorLimit=" + ((AmountLimitConfig)object).FloorLimit + ";\n");
            }
            if (((AmountLimitConfig)object).OnDeviceCvmTransactionLimit != null) {
                stringBuilder.append("OnDeviceCvmTransactionLimit=" + ((AmountLimitConfig)object).OnDeviceCvmTransactionLimit + ";\n");
            }
            if (((AmountLimitConfig)object).TerminalFloorLimit != null) {
                stringBuilder.append("TerminalFloorLimit=" + ((AmountLimitConfig)object).TerminalFloorLimit + ";\n");
            }
            if (((AmountLimitConfig)object).TransactionLimit != null) {
                stringBuilder.append("TransactionLimit=" + ((AmountLimitConfig)object).TransactionLimit + ";\n");
            }
            if (((AmountLimitConfig)object).AllowCards) {
                stringBuilder.append("AllowCards=" + ((AmountLimitConfig)object).AllowCards + ";\n");
            }
            if (((AmountLimitConfig)object).AllowCash) {
                stringBuilder.append("AllowCash=" + ((AmountLimitConfig)object).AllowCash + ";\n");
            }
            if (((AmountLimitConfig)object).AllowCashback) {
                stringBuilder.append("AllowCashback=" + ((AmountLimitConfig)object).AllowCashback + ";\n");
            }
            if (((AmountLimitConfig)object).AllowMobileDevices) {
                stringBuilder.append("AllowMobileDevices=" + ((AmountLimitConfig)object).AllowMobileDevices + ";\n");
            }
            stringBuilder.append("AllowRefund=" + ((AmountLimitConfig)object).AllowRefund + ";\n");
            stringBuilder.append("AllowSale=" + ((AmountLimitConfig)object).AllowSale + ";\n");
            stringBuilder.append("\n");
            ++n;
        }
        n = 0;
        while (n < this.kernelCtlConfigList.size()) {
            object = this.kernelCtlConfigList.get(n);
            String string = "#CTL_" + ((KernelCtlConfig)object).aid + "_" + String.format("%02d", Integer.parseInt(((KernelCtlConfig)object).kernelID)) + ";\n";
            stringBuilder.append(string);
            stringBuilder.append("KernelConfiguration=" + n + ";\n\n");
            int n3 = 0;
            while (n3 < ((KernelCtlConfig)object).amountConfigList.size()) {
                stringBuilder.append(string);
                stringBuilder.append("AmountLimit=" + ((KernelCtlConfig)object).amountConfigList.get(n3) + ";\n\n");
                ++n3;
            }
            if (((KernelCtlConfig)object).kernelID.contentEquals("03") && this.dynamicLimitConfigList.size() > 0) {
                n3 = 0;
                while (n3 < this.dynamicLimitConfigList.size()) {
                    stringBuilder.append(string);
                    stringBuilder.append("DynamicLimit=" + n3 + ";\n\n");
                    ++n3;
                }
                stringBuilder.append("\n");
            }
            ++n;
        }
        return stringBuilder.toString();
    }

    private void dealCTCL_Parameters_Update(List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                String string;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(this.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                block2: for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!object2.getActivationCode().contentEquals(NEPTING) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)object2.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        if (!this.isCtclActivated(yP_TCD_DCB_Interface_CTCL, yP_App_Interface_Selection)) continue;
                        this.fillSPmxCtlInternalStructure(object2, yP_TCD_DCB_Interface_CTCL, YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(object2));
                        this.formatSPxxxCtlData(object2, yP_TCD_DCB_Interface_CTCL);
                        continue block2;
                    }
                }
                if (this.publicKeyLISTS != null) {
                    this.spxxxCfgData.setKEYTAB(this.publicKeyLISTS);
                }
                if (this.spxxxCfgData != null) {
                    this.fillInSPxxxAidParams(this.spxxxCfgData);
                }
                if ((string = this.generateSPxxxCtlData()) != null) {
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, string);
                    tLVHandler.add(14672506, (long)string.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                }
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = "0";
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealCTCL_Parameters_Update() ", exception);
        }
    }

    private void dealCTCL_SPm2x_ParametersUpdate(List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null && l == 0L) {
                return;
            }
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                Object object;
                Object object2;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(this.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                block2: for (YP_TCD_DCC_Business object32 : list) {
                    if (!object32.getActivationCode().contentEquals(NEPTING) || (object2 = (YP_TCD_DCB_Interface_CTCL)object32.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object32.selectorList) {
                        if (!this.isCtclActivated((YP_TCD_DCB_Interface_CTCL)object2, yP_App_Interface_Selection)) continue;
                        this.fillSPmxCtlInternalStructure(object32, (YP_TCD_DCB_Interface_CTCL)object2, YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(object32));
                        continue block2;
                    }
                }
                String string = this.formatSPm2CtlData();
                if (this.getLogLevel() == 6) {
                    object = new PrintWriter("./SPm2Generated.xml", "UTF-8");
                    ((PrintWriter)object).println(string);
                    ((PrintWriter)object).close();
                }
                object = new TLVHandler();
                object2 = SPm2x.extractKSN(this, this.requestAPPTagsHandler);
                if (object2 != null && ((TLV)object2).value != null && ((TLV)object2).value.length > 0) {
                    YP_Object yP_Object = this.getPluginByName("CryptoManager");
                    String string2 = (String)yP_Object.dealRequest(this, "sha256Hash", new Object[]{string.getBytes("ISO-8859-1")});
                    if (string2 == null || string2.isEmpty()) {
                        this.logger(2, "dealCTCL_SPm2x_ParametersUpdate() pb during hash");
                    } else {
                        String string3 = DUKPT.macResponseData(UtilsYP.devHexa(((TLV)object2).value), UtilsYP.redHexa(string2));
                        ((TLVHandler)object).addASCII(14672758, string3);
                    }
                } else {
                    this.logger(2, "dealCTCL_SPm2x_ParametersUpdate() No KSN");
                }
                ((TLVHandler)object).addASCII(14672757, string);
                ((TLVHandler)object).add(14672506, (long)string.length());
                parameterFile2.appTagsList.add(((TLVHandler)object).toString());
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            this.logger(2, "dealCTCL_SPm2x_ParametersUpdate()", exception);
        }
    }

    public static Integer getDefaultNFCCurrencyNumericalCode(YP_TCD_DCC_Business yP_TCD_DCC_Business) {
        if (!(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) {
            yP_TCD_DCC_Business.logger(2, "getDefaultNFCCurrencyNumericalCode() not an EFT business ???, default to Euro");
            return 978;
        }
        List<String> list = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getListOfAuthorizedCurrency();
        if (list.isEmpty()) {
            yP_TCD_DCC_Business.logger(3, "getDefaultNFCCurrencyNumericalCode() currencyAlphabeticalCodeList empty, default to Euro");
            return 978;
        }
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            String string;
            switch (string = iterator.next()) {
                case "EUR": 
                case "MAD": {
                    return ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyNumericalCode(string);
                }
            }
        }
        return ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyNumericalCode(list.get(0));
    }

    private void dealOneParameter(YP_Row yP_Row, YP_Row yP_Row2, TLVHandler tLVHandler, String string, String string2, int n, int n2) throws Exception {
        String string3 = yP_Row.getFieldStringValueByName(string);
        if (string3 == null || string3.isEmpty()) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "dealOneParameter() " + string + " not versioned");
            }
            return;
        }
        String string4 = yP_Row2.getFieldStringValueByName(string);
        if (string4 == null) {
            this.logger(2, "dealOneParameter() ...");
            return;
        }
        if ((string4 = string4.trim()).isEmpty()) {
            if (n2 == -2064075) {
                this.logger(3, "dealOneParameter() pinpad update not activated at no adequat terminal");
                return;
            }
            if (n2 == 16769874) {
                this.logger(3, "dealOneParameter() " + string + " won't be updated to " + string3);
                return;
            }
            this.logger(3, "dealOneParameter() maybe " + string + " shouldn't be updated to " + string3);
        }
        if (string3.contentEquals(string4)) {
            if (this.getLogLevel() >= 5) {
                this.logger(5, "dealOneParameter() " + string + " OK : " + string4);
            }
            return;
        }
        this.logger(3, "dealOneParameter() " + string + " need to be updated from version " + string4 + " to " + string3);
        if (n2 == 16769874 && (string4.contentEquals("3.3.6.27") || string4.contentEquals("3.3.6.26") || string4.contentEquals("3.3.6.21") || string4.contentEquals("3.3.6.19")) && string3.contentEquals("3.3.6.17")) {
            this.logger(3, "dealOneParameter() downgrade deactivated");
            return;
        }
        TLVHandler tLVHandler2 = new TLVHandler();
        String string5 = yP_Row.getFieldStringValueByName(string2);
        if (string5.startsWith("http")) {
            tLVHandler2.addASCII(14672747, string5);
        } else {
            TLVHandler tLVHandler3;
            TLVHandler tLVHandler4;
            TLV tLV;
            Object object;
            Object object2;
            Object object3;
            if (string5.startsWith("$SOFT_")) {
                object3 = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                object2 = ((YP_TCD_DCC_Technique)object3).getSoftUpdateRow(this, string5, string4);
                if (object2 == null || string5.isEmpty()) {
                    this.logger(2, "dealOneParameter() ");
                    return;
                }
                string5 = ((YP_Row)object2).getFieldStringValueByName("updateURL");
                object = (Boolean)((YP_Row)object2).getFieldValueByName("isMandatory");
                if (object != null) {
                    tLVHandler2.add(-538869443, (Boolean)object);
                }
            }
            if (string5.contains("AIM_CAPS_1.0.0.SDP")) {
                object3 = yP_Row2.getFieldStringValueByName("kernelVersion");
                if (object3 == null) {
                    this.logger(2, "dealOneParameter() SPm20 FAPI to Nepting not possible !");
                    return;
                }
                if (!((String)object3).contentEquals("4.0.52")) {
                    this.logger(2, "dealOneParameter() SPm20 FAPI to Nepting deactivated for " + (String)object3);
                    return;
                }
            }
            object3 = new FileInputStream(string5);
            object2 = new byte[((FileInputStream)object3).available()];
            ((FileInputStream)object3).read((byte[])object2);
            ((FileInputStream)object3).close();
            object = null;
            TLV tLV2 = this.requestAPPTagsHandler.getTLV(n);
            if (tLV2 != null && (tLV = (tLVHandler4 = new TLVHandler(tLV2.value)).getTLV(n2)) != null && (object = (tLVHandler3 = new TLVHandler(tLV.value)).getTLV(14672737)) != null) {
                YP_Object yP_Object = this.getPluginByName("CryptoManager");
                String string6 = (String)yP_Object.dealRequest(this, "sha256Hash", object2);
                if (string6 == null || string6.isEmpty()) {
                    this.logger(2, "dealOneParameter() pb during hash");
                } else {
                    String string7 = DUKPT.macResponseData(UtilsYP.devHexa(((TLV)object).value), UtilsYP.redHexa(string6));
                    tLVHandler2.addASCII(14672758, string7);
                }
            }
            tLVHandler2.add(14672757, UtilsYP.devHexa((byte[])object2));
            tLVHandler2.add(14672506, (long)((Object)object2).length);
            try {
                tLVHandler2.addASCII(-538738344, new File(string5).getName());
            }
            catch (Exception exception) {}
        }
        if (n2 == 16769900) {
            tLVHandler2.addASCII(14672720, YP_Row.getStringValue(string3));
        }
        tLVHandler.add(n2, tLVHandler2.toString());
    }

    private void dealOneImage(YP_Row yP_Row, YP_Row yP_Row2, TLVHandler tLVHandler, String string, int n, int n2, YP_Row yP_Row3) throws Exception {
        if (yP_Row2 == null || yP_Row3 == null) {
            return;
        }
        String string2 = yP_Row3.getFieldStringValueByName("version");
        if (string2 == null || string2.isEmpty()) {
            this.logger(2, "dealOneImage() no version defined for " + string);
            return;
        }
        String string3 = yP_Row2.getFieldStringValueByName(string);
        if (string2.contentEquals(string3)) {
            return;
        }
        this.logger(3, "dealOneImage() " + string + " need to be updated from version " + string3 + " to " + string2);
        TLVHandler tLVHandler2 = new TLVHandler();
        String string4 = yP_Row3.getFieldStringValueByName("url");
        if (string4 == null || string4.isEmpty()) {
            this.logger(2, "dealOneImage() no url defined for " + string);
            return;
        }
        if (string4.startsWith("http")) {
            tLVHandler2.addASCII(14672747, string4);
        } else {
            TLVHandler tLVHandler3;
            TLVHandler tLVHandler4;
            TLV tLV;
            FileInputStream fileInputStream = new FileInputStream(string4);
            byte[] byArray = new byte[fileInputStream.available()];
            fileInputStream.read(byArray);
            fileInputStream.close();
            TLV tLV2 = null;
            TLV tLV3 = this.requestAPPTagsHandler.getTLV(n);
            if (tLV3 != null && (tLV = (tLVHandler4 = new TLVHandler(tLV3.value)).getTLV(n2)) != null && (tLV2 = (tLVHandler3 = new TLVHandler(tLV.value)).getTLV(14672737)) != null) {
                YP_Object yP_Object = this.getPluginByName("CryptoManager");
                String string5 = (String)yP_Object.dealRequest(this, "sha256Hash", new Object[]{byArray});
                if (string5 == null || string5.isEmpty()) {
                    this.logger(2, "dealOneImage() pb during hash");
                } else {
                    String string6 = DUKPT.macResponseData(UtilsYP.devHexa(tLV2.value), UtilsYP.redHexa(string5));
                    tLVHandler2.addASCII(14672758, string6);
                }
            }
            tLVHandler2.add(14672757, UtilsYP.devHexa(byArray));
            tLVHandler2.add(14672506, (long)byArray.length);
        }
        tLVHandler2.addASCII(14672720, YP_Row.getStringValue(string2));
        tLVHandler.add(n2, tLVHandler2.toString());
    }

    private void dealOneImage(YP_Row yP_Row, YP_Row yP_Row2, TLVHandler tLVHandler, String string, String string2, int n, int n2) throws Exception {
        if (yP_Row2 == null || yP_Row == null) {
            return;
        }
        String string3 = yP_Row.getFieldStringValueByName(string);
        if (string3 == null || string3.isEmpty()) {
            return;
        }
        if (!"$".contentEquals(string3.substring(0, 1))) {
            this.dealOneParameter(yP_Row, yP_Row2, tLVHandler, string, string2, n, n2);
        } else {
            YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
            YP_Row yP_Row3 = yP_TCD_DCC_Technique.getImage(this, string3);
            this.dealOneImage(yP_Row, yP_Row2, tLVHandler, string, n, n2, yP_Row3);
        }
    }

    private int doSoftUpdate(YP_Row yP_Row) {
        Object object;
        YP_Row yP_Row2;
        block18: {
            long l;
            long l2;
            block19: {
                block17: {
                    long l3;
                    YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
                    block16: {
                        try {
                            yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
                            l3 = (Long)yP_Row.getFieldValueByName("idTerminalConfig");
                            if (l3 > 0L) break block16;
                            if (this.getLogLevel() >= 4) {
                                this.logger(4, "doSoftUpdate() no config defined yet !");
                            }
                            return 0;
                        }
                        catch (Exception exception) {
                            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
                            if (this.getLogLevel() >= 2) {
                                this.logger(2, "doSoftUpdate()  ", exception);
                            }
                            return -1;
                        }
                    }
                    yP_Row2 = yP_TCD_DCC_Technique.getTerminalConfigRow(l3);
                    if (yP_Row2 != null) break block17;
                    if (this.getLogLevel() >= 2) {
                        this.logger(2, "doSoftUpdate() terminal config not found " + l3);
                    }
                    return -1;
                }
                l2 = (Long)yP_Row2.getFieldValueByName("idTerminalReference");
                if (l2 <= 0L) break block18;
                l = (Long)yP_Row.getFieldValueByName("idTerminalReference");
                if (l > 0L) break block19;
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "doSoftUpdate() no idTerminalReference !");
                }
                return 0;
            }
            if (l == l2) break block18;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "doSoftUpdate() idTerminalReference are different :" + l + " vs " + l2);
            }
            return 0;
        }
        TLVHandler tLVHandler = new TLVHandler();
        if (!this.biosVersionNotReceived) {
            this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "biosVersion", "biosURL", 16769880, 16769874);
        }
        this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "kernelVersion", "kernelURL", 16769880, 16769875);
        this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "level2ICCVersion", "level2ICCURL", 16769880, 16769876);
        this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "level2CTLVersion", "level2CTLURL", 16769880, 16769877);
        this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "appHandlerTerminalVersion", "appHandlerTerminalURL", 16769880, 16769878);
        if (!this.appCBVersionNotReceived) {
            this.dealOneParameter(yP_Row2, yP_Row, tLVHandler, "appCBTerminalVersion", "appCBTerminalURL", 16769880, 16769879);
        }
        this.dealOneImage(yP_Row2, yP_Row, tLVHandler, "screenSaverName", "screenSaverURL", 16769880, 16769900);
        if (!tLVHandler.isEmpty()) {
            object = new TLVHandler();
            ((TLVHandler)object).add(16769880, tLVHandler.toString());
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + ((TLVHandler)object).toString());
            this.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PARAMETERIZATION_NEEDED);
        }
        if (!((String)(object = yP_Row.getFieldStringValueByName("pinpadSerialNumber"))).isEmpty()) {
            TLVHandler tLVHandler2 = new TLVHandler();
            this.dealOneImage(yP_Row2, yP_Row, tLVHandler2, "pinpadScreenSaverName", "pinpadScreenSaverURL", -2064115, 16769900);
            this.dealOneParameter(yP_Row2, yP_Row, tLVHandler2, "pinpadVersion", "pinpadURL", -2064115, -2064075);
            if (!tLVHandler2.isEmpty()) {
                TLVHandler tLVHandler3 = new TLVHandler();
                tLVHandler3.add(-2064115, tLVHandler2.toString());
                this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler3.toString());
                this.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.PARAMETERIZATION_NEEDED);
            }
        }
        return 1;
    }

    private int addDebugInformations(YP_Row yP_Row) {
        Object object;
        Object object2;
        int n = (Integer)yP_Row.getFieldValueByName("debugLevel");
        if (n != 0) {
            object2 = yP_Row.getFieldStringValueByName("terminalManufacturerID");
            object = yP_Row.getFieldStringValueByName("terminalSerialNumber");
            this.logger(2, "addDebugInformations() Warning ! logs are activated for the terminal " + (String)object2 + " " + (String)object);
        }
        object2 = new TLVHandler();
        ((TLVHandler)object2).add(14672509, (long)n);
        object = new TLVHandler();
        ((TLVHandler)object).add(16769147, ((TLVHandler)object2).toString());
        this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + ((TLVHandler)object).toString());
        return 1;
    }

    private int printDebugInformations() {
        TLV tLV;
        block17: {
            block16: {
                if (this.requestAPPTagsHandler != null) break block16;
                return 0;
            }
            tLV = this.requestAPPTagsHandler.getTLV(16769147);
            if (tLV != null && tLV.value != null && tLV.value.length != 0) break block17;
            return 0;
        }
        try {
            TLVHandler tLVHandler = new TLVHandler(tLV.value);
            block13: for (TLV tLV2 : tLVHandler) {
                switch (tLV2.tag) {
                    case 14672767: {
                        this.logger(4, "printDebugInformations() " + UtilsYP.lineSeparator + new String(tLV2.value));
                        break;
                    }
                    case -538738374: {
                        String string;
                        if (this.getLogLevel() < 5) continue block13;
                        try {
                            string = ZipUtils.deCompress(tLV2.value);
                            if (string == null) {
                                this.logger(2, "printDebugInformations() not able to decompress");
                                break;
                            }
                            this.logger(5, "printDebugInformations() " + UtilsYP.lineSeparator + string);
                        }
                        catch (Exception exception) {
                            this.logger(2, "printDebugInformations() ", exception);
                        }
                        continue block13;
                    }
                    case -538738386: {
                        String string;
                        if (this.getLogLevel() < 5) continue block13;
                        try {
                            string = ZipUtils.deCompressGZ(tLV2.value);
                            if (string == null) {
                                this.logger(2, "printDebugInformations() not able to decompress");
                                break;
                            }
                            this.logger(5, "printDebugInformations() " + UtilsYP.lineSeparator + string);
                        }
                        catch (Exception exception) {
                            this.logger(2, "printDebugInformations() ", exception);
                        }
                        continue block13;
                    }
                    default: {
                        this.logger(2, "printDebugInformations() tag not handled " + tLV2.tag);
                    }
                }
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "printDebugInformations()  ", exception);
            return -1;
        }
    }

    private int checkNepSign(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        Object object;
        TLV tLV;
        block36: {
            block35: {
                String[] stringArray;
                String string;
                block34: {
                    block33: {
                        try {
                            if (this.requestAPPTagsHandler != null) break block33;
                            return 0;
                        }
                        catch (Exception exception) {
                            this.logger(2, "checkNepSign() ", exception);
                            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(7));
                            return -1;
                        }
                    }
                    tLV = this.requestAPPTagsHandler.getTLV(-538738408);
                    if (tLV != null && tLV.value != null && tLV.value.length != 0) break block34;
                    return 0;
                }
                TLV tLV2 = this.requestAPPTagsHandler.getTLV(-538803943);
                int n = tLV2 != null ? TLVHandler.getDCBInt(tLV2.value) : 1;
                Boolean bl = yP_TCD_DC_Transaction.commonHandler.isTestMode();
                this.logger(4, "checkNepSign() nep_TestMode: " + bl);
                if (n == 2 && !bl.booleanValue()) {
                    this.logger(4, "checkNepSign() test mode forced");
                    bl = true;
                }
                String string2 = Long.toString(YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction));
                this.logger(4, "checkNepSign() nep_Amount: " + string2);
                if (n == 2 || n == 3) {
                    string = Integer.toString(YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_TCD_DC_Transaction));
                    if (string.contentEquals("0")) {
                        if (YP_TCD_DCC_Business.getTransactionCurrencyAlpha(yP_TCD_DC_Transaction).contentEquals("EUR")) {
                            string = "978";
                        } else {
                            this.logger(2, "checkNepSign() nep_Currency is missing");
                        }
                    }
                } else {
                    string = YP_TCD_DCC_Business.getTransactionCurrencyAlpha(yP_TCD_DC_Transaction);
                }
                this.logger(4, "checkNepSign() nep_Currency: " + string);
                String string3 = null;
                TLV tLV3 = this.requestAPPTagsHandler.getTLV(-538738413);
                if (tLV3 != null) {
                    string3 = new String(tLV3.value);
                    this.logger(4, "checkNepSign() nep_UrlStatus: " + string3);
                }
                String string4 = null;
                TLV tLV4 = this.requestAPPTagsHandler.getTLV(-538738409);
                if (tLV4 != null) {
                    string4 = new String(tLV4.value);
                    this.logger(4, "checkNepSign() nep_UrlCancel: " + string4);
                }
                String string5 = null;
                TLV tLV5 = this.requestAPPTagsHandler.getTLV(-538738412);
                if (tLV5 != null) {
                    string5 = new String(tLV5.value);
                    this.logger(4, "checkNepSign() nep_UrlSuccess: " + string5);
                }
                String string6 = null;
                TLV tLV6 = this.requestAPPTagsHandler.getTLV(-538738411);
                if (tLV6 != null) {
                    string6 = new String(tLV6.value);
                    this.logger(4, "checkNepSign() nep_UrlError: " + string6);
                }
                String string7 = null;
                TLV tLV7 = this.requestAPPTagsHandler.getTLV(-538738410);
                if (tLV7 != null) {
                    string7 = new String(tLV7.value);
                    this.logger(4, "checkNepSign() nep_UrlRefused: " + string7);
                }
                String string8 = (stringArray = this.getContractIdentifier().split("_")).length > 1 ? String.valueOf(stringArray[0]) + "_" + stringArray[1] : stringArray[0];
                this.logger(4, "checkNepSign() nep_MerchantID: " + string8);
                String string9 = yP_TCD_DC_Transaction.commonHandler.getMerchantTransactionIdentifier();
                if (string9 != null && !string9.isEmpty()) {
                    this.logger(4, "checkNepSign() nep_TransactionID: " + string9);
                }
                StringBuilder stringBuilder = new StringBuilder();
                if (n == 2 || n == 3) {
                    stringBuilder.append(String.valueOf(string2) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string5.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string6.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string7.getBytes("UTF-8"))) + '|');
                    if (this.getLogLevel() >= 5) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append(String.valueOf(string2) + '|');
                        ((StringBuilder)object).append(String.valueOf(string) + '|');
                        ((StringBuilder)object).append(String.valueOf(string5) + '|');
                        ((StringBuilder)object).append(String.valueOf(string6) + '|');
                        ((StringBuilder)object).append(String.valueOf(string7) + '|');
                        if (bl != null && bl.booleanValue()) {
                            ((StringBuilder)object).append("01234567890");
                        } else {
                            ((StringBuilder)object).append("?????????");
                        }
                        this.logger(5, "checkNepSign() Buffer to sign (without Base 64 encoding): " + ((StringBuilder)object).toString());
                    }
                } else {
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string8.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string9.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(string2) + '|');
                    stringBuilder.append(String.valueOf(string) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string5.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string6.getBytes("UTF-8"))) + '|');
                    stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string7.getBytes("UTF-8"))) + '|');
                    if (string4 != null && !string4.isEmpty() && !string4.equalsIgnoreCase("null")) {
                        stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string4.getBytes("UTF-8"))) + '|');
                    }
                    if (string3 != null && !string3.isEmpty() && !string3.equalsIgnoreCase("null")) {
                        stringBuilder.append(String.valueOf(UtilsYP.base64Encode(string3.getBytes("UTF-8"))) + '|');
                    }
                    if (this.getLogLevel() >= 5) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append(String.valueOf(string8) + '|');
                        ((StringBuilder)object).append(String.valueOf(string9) + '|');
                        ((StringBuilder)object).append(String.valueOf(string2) + '|');
                        ((StringBuilder)object).append(String.valueOf(string) + '|');
                        ((StringBuilder)object).append(String.valueOf(string5) + '|');
                        ((StringBuilder)object).append(String.valueOf(string6) + '|');
                        ((StringBuilder)object).append(String.valueOf(string7) + '|');
                        if (string4 != null && !string4.isEmpty() && !string4.equalsIgnoreCase("null")) {
                            ((StringBuilder)object).append(String.valueOf(string4) + '|');
                        }
                        if (string3 != null && !string3.isEmpty() && !string3.equalsIgnoreCase("null")) {
                            ((StringBuilder)object).append(String.valueOf(string3) + '|');
                        }
                        if (bl != null && bl.booleanValue()) {
                            ((StringBuilder)object).append("01234567890");
                        } else {
                            ((StringBuilder)object).append("?????????");
                        }
                        this.logger(5, "checkNepSign() Buffer to sign (without Base 64 encoding): " + ((StringBuilder)object).toString());
                    }
                }
                if (this.getLogLevel() >= 5) {
                    if (bl != null && bl.booleanValue()) {
                        this.logger(5, "checkNepSign() Buffer to sign: " + stringBuilder.toString() + "01234567890");
                    } else {
                        this.logger(5, "checkNepSign() Buffer to sign: " + stringBuilder.toString() + "?????????");
                    }
                }
                if ((object = (Object)CryptoUtils.getNepSign(bl, string8, stringBuilder)) != null) break block35;
                this.logger(2, "checkNepSign() ");
                return 0;
            }
            this.logger(4, "checkNepSign() nep_Sign: " + UtilsYP.devHexa((byte[])object));
            if (!Arrays.equals((byte[])object, tLV.value)) break block36;
            return 1;
        }
        this.logger(2, "checkNepSign() signatures don't match:" + UtilsYP.devHexa((byte[])object) + " vs " + UtilsYP.devHexa(tLV.value));
        YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
        YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(92));
        return -1;
    }

    private int addMarocTrsFlow() {
        List<YP_TCD_DCC_Business> list;
        block9: {
            list = this.getApplicationList();
            if (list != null) break block9;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addMarocTrsFlow() no application List");
            }
            return -1;
        }
        try {
            boolean bl = false;
            for (YP_TCD_DCC_Business object2 : list) {
                String string = object2.getApplicationPlugin().getApplicationPropertie("MarocTrsFlow");
                if (!UtilsYP.isTrue(string)) continue;
                bl = true;
                break;
            }
            if (this.getLogLevel() >= 5) {
                if (bl) {
                    this.logger(5, "addMarocTrsFlow() Maroc Trs Flow is activated");
                } else {
                    this.logger(5, "addMarocTrsFlow() Maroc Trs Flow is not activated");
                }
            }
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(-538869499, (Boolean)bl);
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler.toString());
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addMarocTrsFlow()  ", exception);
            }
            return -1;
        }
    }

    private int addPinOnline() {
        List<YP_TCD_DCC_Business> list;
        block9: {
            list = this.getApplicationList();
            if (list != null) break block9;
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addPinOnline() no application List");
            }
            return -1;
        }
        try {
            boolean bl = false;
            for (YP_TCD_DCC_Business object2 : list) {
                String string = object2.getApplicationPlugin().getApplicationPropertie("PinOnlineCapable");
                if (!UtilsYP.isTrue(string)) continue;
                bl = true;
                break;
            }
            if (this.getLogLevel() >= 5) {
                if (bl) {
                    this.logger(5, "addPinOnline() PIN ONLINE is activated");
                } else {
                    this.logger(5, "addPinOnline() PIN ONLINE is not activated");
                }
            }
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(-538869501, (Boolean)bl);
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler.toString());
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "addPinOnline()  ", exception);
            }
            return -1;
        }
    }

    private int addPermanentToken() {
        String string;
        block4: {
            try {
                string = this.getDataContainerTransaction().userHandler.getPermanentToken();
                if (string != null && !string.isEmpty()) break block4;
                return 0;
            }
            catch (Exception exception) {
                if (this.getLogLevel() >= 2) {
                    this.logger(2, "addPermanentToken()  ", exception);
                }
                return -1;
            }
        }
        TLVHandler tLVHandler = new TLVHandler();
        tLVHandler.addASCII(-538738417, string);
        this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler.toString());
        return 1;
    }

    private void addTerminalCountryCode(List<YP_TCD_DCC_Business> list) {
        if (this.getLogLevel() >= 6) {
            this.logger(6, "addTerminalCountryCode() start");
        }
        try {
            String string = null;
            for (YP_TCD_DCC_Business object : list) {
                String string2 = object.getCountryCode();
                if (string2 == null || (string2 = string2.trim()).isEmpty()) continue;
                if (string == null) {
                    if (this.getLogLevel() >= 6) {
                        this.logger(6, "addTerminalCountryCode() country code to add:" + string2);
                    }
                    string = string2;
                    continue;
                }
                if (string.contentEquals(string2)) continue;
                this.logger(2, "addTerminalCountryCode() differents country code:" + string + " vs " + string2);
            }
            if (string != null) {
                while (string.length() < 4) {
                    string = String.valueOf(String.valueOf('0')) + string;
                }
                TLVHandler tLVHandler = new TLVHandler(this.getDataContainerTransaction().commonHandler.getResponseEMVTags());
                tLVHandler.add("9F1A", string);
                this.getDataContainerTransaction().commonHandler.setResponseEMVTags(tLVHandler.toString());
                if (this.getLogLevel() >= 6) {
                    this.logger(6, "addTerminalCountryCode() country code added");
                }
            }
        }
        catch (Exception exception) {
            this.logger(2, "addTerminalCountryCode() ", exception);
        }
    }

    List<Property> getCliProperties() {
        YP_TCD_DC_Context yP_TCD_DC_Context2;
        List<YP_TCD_DCC_Merchant> list = this.getMerchantList();
        List<YP_TCD_DCC_Business> list2 = this.getApplicationList();
        HashSet<YP_TCD_DCC_Merchant> hashSet = new HashSet<YP_TCD_DCC_Merchant>(list);
        for (YP_TCD_DC_Context yP_TCD_DC_Context2 : list2) {
            hashSet.add(yP_TCD_DC_Context2.getDataContainerMerchant());
        }
        if (hashSet.size() != 1) {
            if (this.getLogLevel() >= 5) {
                if (hashSet.isEmpty()) {
                    this.logger(5, "getCliProperties() empty");
                } else {
                    this.logger(5, "getCliProperties() too many");
                }
            }
            return new ArrayList<Property>();
        }
        yP_TCD_DC_Context2 = (YP_TCD_DCC_Merchant)hashSet.iterator().next();
        YP_TCD_DCC_Technique yP_TCD_DCC_Technique = ((YP_TS_DataContainerManager)this.getPluginByName("DataContainerManager")).getDataContainerTechnique();
        if (yP_TCD_DCC_Technique == null) {
            this.logger(2, "getCliProperties() no DCC_Technique...");
            return null;
        }
        List<Property> list3 = yP_TCD_DCC_Technique.getMerchantProperties((YP_TCD_DCC_Merchant)yP_TCD_DC_Context2, CLIENT_PROPERTIES_PREFIX, this.getDataContainerTransaction().contextHandler.getStoreIdentifier());
        if (list3 == null) {
            this.logger(2, "getCliProperties() null list");
            return null;
        }
        if (list3.isEmpty() && this.getLogLevel() >= 5) {
            this.logger(5, "getCliProperties() Nothing found");
        }
        return list3;
    }

    private int addCLIProperties() {
        List<Property> list;
        block7: {
            block6: {
                list = this.getCliProperties();
                if (list != null) break block6;
                return -1;
            }
            if (!list.isEmpty()) break block7;
            return 0;
        }
        try {
            TLVHandler tLVHandler = new TLVHandler();
            for (Property object2 : list) {
                TLVHandler tLVHandler2 = new TLVHandler();
                tLVHandler2.addASCII(-538738393, object2.getName());
                tLVHandler2.addASCII(-538738392, object2.getValue());
                tLVHandler.add(-2064090, tLVHandler2);
            }
            TLVHandler tLVHandler3 = new TLVHandler();
            tLVHandler3.add(-2064085, tLVHandler);
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler3.toString());
            if (this.getLogLevel() >= 5) {
                this.logger(5, "addCLIProperties() properties added");
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "addCLIProperties() ", exception);
            return -1;
        }
    }

    private int addNDOLCTCL(List<YP_TCD_DCC_Business> list) {
        int n;
        long l;
        long l2;
        int n2;
        block54: {
            block53: {
                List<UpdateHandler.ParameterFile> list2;
                block52: {
                    YP_OnDemandComponent yP_OnDemandComponent22;
                    block51: {
                        block50: {
                            block49: {
                                List<YP_TCD_DCC_Merchant> list3 = this.getMerchantList();
                                List<YP_TCD_DCC_Business> list4 = this.getApplicationList();
                                HashSet<YP_TCD_DCC_Merchant> hashSet = new HashSet<YP_TCD_DCC_Merchant>(list3);
                                for (YP_OnDemandComponent yP_OnDemandComponent22 : list4) {
                                    hashSet.add(yP_OnDemandComponent22.getDataContainerMerchant());
                                }
                                if (hashSet.size() == 1) break block49;
                                if (this.getLogLevel() >= 5) {
                                    if (hashSet.isEmpty()) {
                                        this.logger(5, "addNDOLCTCL() empty");
                                    } else {
                                        this.logger(5, "addNDOLCTCL() too many");
                                    }
                                }
                                return 0;
                            }
                            yP_OnDemandComponent22 = this.getDataContainerTransaction().getProtocolEFT();
                            if (yP_OnDemandComponent22 != null) break block50;
                            return 0;
                        }
                        if (yP_OnDemandComponent22 instanceof YP_PROT_Update) break block51;
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "addNDOLCTCL() bad interface");
                        }
                        return 0;
                    }
                    YP_PROT_Update yP_PROT_Update = (YP_PROT_Update)((Object)yP_OnDemandComponent22);
                    UpdateHandler updateHandler = this.getDataContainerTransaction().updateHandler;
                    list2 = yP_PROT_Update.getParameterFileList(updateHandler);
                    if (list2 != null && !list2.isEmpty()) break block52;
                    if (this.getLogLevel() >= 5) {
                        this.logger(5, "addNDOLCTCL() no parameter");
                    }
                    return 0;
                }
                n2 = 0;
                for (UpdateHandler.ParameterFile parameterFile : list2) {
                    switch (parameterFile.headerParameterFile.tableName) {
                        case "CTCL_Parameters": {
                            n2 = 1;
                            break;
                        }
                        case "CTCL_SPm2x_Parameters": {
                            n2 = 2;
                            break;
                        }
                        case "CTCL_Albert_Parameters": {
                            n2 = 3;
                            break;
                        }
                        case "CTCL_NovelPayPAL_Parameters": {
                            n2 = 4;
                            break;
                        }
                        case "CTCL_Prolin_Parameters": {
                            n2 = 5;
                            break;
                        }
                        case "CTCL_UCube_Parameters": {
                            n2 = 6;
                            break;
                        }
                    }
                }
                if (n2 != 0) break block53;
                if (this.getLogLevel() >= 5) {
                    this.logger(5, "addNDOLCTCL() no ctcl parameter");
                }
                return 0;
            }
            try {
                l2 = Long.MAX_VALUE;
                l = Long.MIN_VALUE;
                n = 0;
                boolean bl = false;
                block26: for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!object2.getActivationCode().contentEquals(NEPTING) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)object2.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        long l3;
                        int n3;
                        if (!this.isCtclActivated(yP_TCD_DCB_Interface_CTCL, yP_App_Interface_Selection)) continue;
                        bl = true;
                        YP_TCD_DCB_Interface_Currency yP_TCD_DCB_Interface_Currency = (YP_TCD_DCB_Interface_Currency)object2.getExtensionByType(YP_TCD_DCB_Interface_Currency.class);
                        if (yP_TCD_DCB_Interface_Currency == null || (n3 = YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(object2).intValue()) <= 0) continue block26;
                        long l4 = yP_TCD_DCB_Interface_Currency.getCurrencyMinAmount(n3);
                        if (l4 > 0L && l4 < l2) {
                            l2 = l4;
                            n = n3;
                        }
                        if ((l3 = yP_TCD_DCB_Interface_Currency.getCurrencyMaxAmount(n3)) <= 0L || l3 <= l) continue block26;
                        l = l3;
                        n = n3;
                        continue block26;
                    }
                }
                if (bl) break block54;
                this.logger(4, "addNDOLCTCL() Ndol not added as no NFC application activated");
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "addNDOLCTCL() ", exception);
                return -1;
            }
        }
        TLVHandler tLVHandler = new TLVHandler();
        if (n2 == 1) {
            tLVHandler.add(-2064084, "5F285F2D84879F119F2A9F5A9F5D9F699F6E9F7CBF0C9F349F6C9F66DCDD9F6B56DF4B9F7EDF81159F109F279F089F079F369F379F50");
        } else if (n2 == 2) {
            tLVHandler.add(-2064084, "500082009F125F285F2D840087009F119F2A9F5A9F5D9F699F6E9F7CBF0C9F349F6C9F66DC00DD00D600DF4B9F7EDF81159F109F279F089F079F369F379F269F505F249500");
        } else {
            tLVHandler.add(-2064084, "57505A7172828487898A8E8F91959A9B9C5F245F255F2A5F2D5F305F349F029F039F069F079F089F099F0D9F0E9F0F9F109F119F129F179F1A9F219F269F279F2A9F339F349F359F369F379F399F415F285F2D9F119F2A9F5A9F5D9F669F699F6B9F6E9F6C9F7C9F7EBF0CDCDDDF4B9F0ADF72DF81159F5056");
        }
        if (l2 != Long.MAX_VALUE) {
            tLVHandler.add(-538803881, l2);
        }
        if (l != Long.MIN_VALUE) {
            tLVHandler.add(-538803882, l);
        }
        if (l2 != Long.MAX_VALUE || l != Long.MIN_VALUE) {
            tLVHandler.add(-538803875, (long)n);
        }
        this.getDataContainerTransaction().commonHandler.setResponseAppTags(String.valueOf(this.getDataContainerTransaction().commonHandler.getResponseAppTags()) + tLVHandler.toString());
        if (this.getLogLevel() >= 5) {
            this.logger(5, "addNDOLCTCL() properties added");
        }
        return 1;
    }

    private String getAppHandlerTerminalVersion() {
        try {
            TLVHandler tLVHandler;
            TLV tLV;
            TLV tLV2;
            TLVHandler tLVHandler2;
            TLV tLV3;
            TLV tLV4;
            if (this.requestAPPTagsHandler != null && (tLV4 = this.requestAPPTagsHandler.getTLV(16769880)) != null && (tLV3 = (tLVHandler2 = new TLVHandler(tLV4.value)).getTLV(14672729)) != null && (tLV2 = tLVHandler2.getTLV(16769878)) != null && (tLV = (tLVHandler = new TLVHandler(tLV2.value)).getTLV(14672720)) != null) {
                return new String(tLV.value);
            }
        }
        catch (Exception exception) {
            this.logger(2, "getAppHandlerTerminalVersion() ", exception);
        }
        return "";
    }

    private int dealIOSParamBug(YP_Row yP_Row) {
        block3: {
            try {
                if (this.getAppHandlerTerminalVersion().endsWith("-i")) break block3;
                return 0;
            }
            catch (Exception exception) {
                this.logger(2, "dealIOSParamBug() ", exception);
                return -1;
            }
        }
        this.logger(3, "dealIOSParamBug() needed");
        return this.doParameterUpdate(yP_Row, true);
    }

    private void addLocalTime(List<YP_TCD_DCC_Business> list) {
        if (this.getDataContainerTransaction().commonHandler.getTransactionAppliLocalTime().equals(UtilsYP.EMPTY_TIMESTAMP)) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(NEPTING) || !(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null) continue;
                if (!(yP_TCD_DCC_Business.timeInterface instanceof YP_TCD_DCB_Host_Time)) break;
                this.getDataContainerTransaction().commonHandler.setTransactionAppliLocalTime(new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(this.getStartTime()).getTimeInMillis()));
                break;
            }
        }
        if (this.getDataContainerTransaction().commonHandler.getTransactionAppliLocalTime().equals(UtilsYP.EMPTY_TIMESTAMP)) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(NEPTING) || !(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) continue;
                if (!(yP_TCD_DCC_Business.timeInterface instanceof YP_TCD_DCB_Host_Time)) break;
                this.getDataContainerTransaction().commonHandler.setTransactionAppliLocalTime(new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(this.getStartTime()).getTimeInMillis()));
                break;
            }
        }
        if (this.getDataContainerTransaction().commonHandler.getTransactionAppliLocalTime().equals(UtilsYP.EMPTY_TIMESTAMP)) {
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(NEPTING) || !(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) continue;
                if (yP_TCD_DCC_Business.timeInterface == null) break;
                this.getDataContainerTransaction().commonHandler.setTransactionAppliLocalTime(new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(this.getStartTime()).getTimeInMillis()));
                break;
            }
        }
    }

    private void addTransactionTypeAllowed(List<YP_TCD_DCC_Business> list) {
        try {
            Bitmap bitmap = new Bitmap();
            for (YP_TCD_DCC_Business object2 : list) {
                Bitmap bitmap2;
                if (!object2.getActivationCode().contentEquals(NEPTING) || !(object2 instanceof YP_TCD_DCC_EFT_Business) || (bitmap2 = ((YP_TCD_DCC_EFT_Business)object2).getTransactionTypeAllowed(this.getDataContainerTransaction())) == null) continue;
                bitmap2 = new Bitmap(bitmap2.getBitmap());
                try {
                    Bitmap bitmap3 = new Bitmap(Long.parseLong(object2.getApplicationPlugin().getApplicationPropertie("TrsTypeAllowed")));
                    int n = 1;
                    while (n < 64) {
                        if (!bitmap3.isSet(n)) {
                            bitmap2.unSet(n);
                        }
                        ++n;
                    }
                }
                catch (Exception exception) {}
                bitmap.add(bitmap2);
            }
            TLVHandler tLVHandler = new TLVHandler(this.getDataContainerTransaction().commonHandler.getResponseAppTags());
            tLVHandler.add(-538803888, bitmap.getBitmap());
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        }
        catch (Exception exception) {
            this.logger(2, "addTransactionTypeAllowed() ", exception);
        }
    }

    private boolean isClientCanPerformAppSelection() {
        block4: {
            if (this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction || this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM || this.getDataContainerTransaction().getSubRequestType() == YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC) break block4;
            return false;
        }
        try {
            Bitmap bitmap;
            TLV tLV;
            if (this.requestAPPTagsHandler != null && (tLV = this.requestAPPTagsHandler.getTLV(-538803873)) != null && (bitmap = new Bitmap(TLVHandler.getDCBInt(tLV.value))).isSet(ClientCapabilityEnumeration.MENU_CAPABLE.getValue())) {
                TLVHandler tLVHandler;
                TLV tLV2;
                TLV tLV3 = this.requestAPPTagsHandler.getTLV(-2064032);
                return tLV3 == null || (tLV2 = (tLVHandler = new TLVHandler(tLV3.value)).getTLV(-538803871)) == null || TLVHandler.getDCBInt(tLV2.value) != 1;
            }
        }
        catch (Exception exception) {
            this.logger(2, "isClientCanPerformAppSelection() ", exception);
        }
        return false;
    }

    private void askforAppSelection(List<YP_TCD_DCC_Business> list, int[] nArray, int n) {
        try {
            TLVHandler tLVHandler = new TLVHandler(this.getDataContainerTransaction().commonHandler.getResponseAppTags());
            TLVHandler tLVHandler2 = new TLVHandler();
            tLVHandler2.addASCII(-538738334, "MENU");
            tLVHandler2.add(-538803871, 1L);
            tLVHandler2.add(-538803869, 30000L);
            tLVHandler2.add(-538738332, this.getLabel("APP_SELECTION").getBytes(StandardCharsets.UTF_8));
            int n2 = 0;
            while (n2 < nArray.length) {
                if (nArray[n2] == n) {
                    YP_TCD_DCC_Business yP_TCD_DCC_Business = list.get(n2);
                    tLVHandler2.add(-538738331, yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel").getBytes(StandardCharsets.UTF_8));
                    tLVHandler2.add(-538869402, (Boolean)false);
                }
                ++n2;
            }
            tLVHandler.add(-2064032, tLVHandler2);
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(100));
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Intermediate);
        }
        catch (Exception exception) {
            this.logger(2, "askforAppSelection() " + exception);
            YP_TCD_DCC_Business.setExtendedResult(this.getDataContainerTransaction(), new ExtendedResult(13));
            YP_TCD_DCC_Business.setGlobalResult(this.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
        }
    }

    private int addTerminalTypeAliasAndLanguage(YP_Row yP_Row) {
        String string = yP_Row.getFieldStringValueByName("terminalType");
        String string2 = yP_Row.getFieldStringValueByName("terminalLanguage");
        String string3 = yP_Row.getFieldStringValueByName("alias");
        if ((string == null || string.isEmpty()) && (string2 == null || string2.isEmpty()) && string3 == null) {
            return 0;
        }
        try {
            TLVHandler tLVHandler = new TLVHandler(this.getDataContainerTransaction().commonHandler.getResponseAppTags());
            if (string != null && !string.isEmpty()) {
                tLVHandler.addASCII(-538738322, string);
            }
            if (string2 != null && !string2.isEmpty()) {
                tLVHandler.addASCII(-538738323, string2);
            }
            if (string3 != null) {
                tLVHandler.addASCII(-538738324, string3);
            }
            this.getDataContainerTransaction().commonHandler.setResponseAppTags(tLVHandler.toString());
        }
        catch (Exception exception) {
            this.logger(2, "addTerminalTypeAliasAndLanguage() " + exception);
        }
        return 1;
    }

    private YP_Service getCountryManager() {
        YP_Service yP_Service = null;
        if ((countryManagerPresent == null || countryManagerPresent.booleanValue()) && (yP_Service = (YP_Service)this.getPluginByName("IPToCountryManager")) == null) {
            countryManagerPresent = false;
        }
        return yP_Service;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration() {
        if ($SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration != null) {
            return $SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration;
        }
        int[] nArray = new int[TerminalStatusEnumeration.values().length];
        try {
            nArray[TerminalStatusEnumeration.A_JOUR.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[TerminalStatusEnumeration.CHARGE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[TerminalStatusEnumeration.DELETED.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[TerminalStatusEnumeration.EN_COURS_MAJ.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[TerminalStatusEnumeration.NON_MAJ.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[TerminalStatusEnumeration.PROGRAMME.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$utils$enums$sorec$TerminalStatusEnumeration = nArray;
        return nArray;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$RESULT_TYPE() {
        if ($SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$RESULT_TYPE != null) {
            return $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$RESULT_TYPE;
        }
        int[] nArray = new int[YP_TCD_PosProtocol.RESULT_TYPE.values().length];
        try {
            nArray[YP_TCD_PosProtocol.RESULT_TYPE.Error.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.RESULT_TYPE.Intermediate.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.RESULT_TYPE.Refused.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.RESULT_TYPE.Success.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[YP_TCD_PosProtocol.RESULT_TYPE.Unknown.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$framework$ondemandcomponents$pos$YP_TCD_PosProtocol$RESULT_TYPE = nArray;
        return nArray;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration() {
        if ($SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration != null) {
            return $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration;
        }
        int[] nArray = new int[StoreStatusEnumeration.values().length];
        try {
            nArray[StoreStatusEnumeration.ACTIVE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.DELETED.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.INACTIVE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            nArray[StoreStatusEnumeration.UNKNOWN.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$yp$utils$enums$StoreStatusEnumeration = nArray;
        return nArray;
    }

    private class AmountLimitConfig {
        boolean AllowMobileDevices;
        boolean AllowCards;
        boolean AllowSale;
        boolean AllowCash;
        boolean AllowCashback;
        boolean AllowRefund;
        String FloorLimit;
        String TransactionLimit;
        String CvmRequiredLimit;
        String OnDeviceCvmTransactionLimit;
        String TerminalFloorLimit;
        String Currency;

        private AmountLimitConfig() {
        }

        private boolean isEqual(AmountLimitConfig amountLimitConfig) {
            if (amountLimitConfig == null) {
                return false;
            }
            if (this.AllowMobileDevices != amountLimitConfig.AllowMobileDevices) {
                return false;
            }
            if (this.AllowCards != amountLimitConfig.AllowCards) {
                return false;
            }
            if (this.AllowSale != amountLimitConfig.AllowSale) {
                return false;
            }
            if (this.AllowCash != amountLimitConfig.AllowCash) {
                return false;
            }
            if (this.AllowCashback != amountLimitConfig.AllowCashback) {
                return false;
            }
            if (this.AllowRefund != amountLimitConfig.AllowRefund) {
                return false;
            }
            if (this.FloorLimit == null && amountLimitConfig.FloorLimit != null || this.FloorLimit != null && amountLimitConfig.FloorLimit == null) {
                return false;
            }
            if (this.FloorLimit != null && !this.FloorLimit.contentEquals(amountLimitConfig.FloorLimit)) {
                return false;
            }
            if (this.TransactionLimit == null && amountLimitConfig.TransactionLimit != null || this.TransactionLimit != null && amountLimitConfig.TransactionLimit == null) {
                return false;
            }
            if (this.TransactionLimit != null && !this.TransactionLimit.contentEquals(amountLimitConfig.TransactionLimit)) {
                return false;
            }
            if (this.CvmRequiredLimit == null && amountLimitConfig.CvmRequiredLimit != null || this.CvmRequiredLimit != null && amountLimitConfig.CvmRequiredLimit == null) {
                return false;
            }
            if (this.CvmRequiredLimit != null && !this.CvmRequiredLimit.contentEquals(amountLimitConfig.CvmRequiredLimit)) {
                return false;
            }
            if (this.OnDeviceCvmTransactionLimit == null && amountLimitConfig.OnDeviceCvmTransactionLimit != null || this.OnDeviceCvmTransactionLimit != null && amountLimitConfig.OnDeviceCvmTransactionLimit == null) {
                return false;
            }
            if (this.OnDeviceCvmTransactionLimit != null && !this.OnDeviceCvmTransactionLimit.contentEquals(amountLimitConfig.OnDeviceCvmTransactionLimit)) {
                return false;
            }
            if (this.TerminalFloorLimit == null && amountLimitConfig.TerminalFloorLimit != null || this.TerminalFloorLimit != null && amountLimitConfig.TerminalFloorLimit == null) {
                return false;
            }
            if (this.TerminalFloorLimit != null && !this.TerminalFloorLimit.contentEquals(amountLimitConfig.TerminalFloorLimit)) {
                return false;
            }
            return this.Currency == null || this.Currency.contentEquals(amountLimitConfig.Currency);
        }
    }

    private class DynamicLimitConfig {
        String ProgramId;
        boolean PerformStatusCheck;
        boolean AllowStatusCheck;
        boolean PerformZeroAmountCheck;
        boolean AllowZeroAmount;
        boolean OnlineCryptogramOnZeroAmount;
        boolean PerformFloorLimitCheck;
        boolean PerformTransactionLimitCheck;
        boolean PerformCvmRequiredLimitCheck;
        String FloorLimit;
        String TransactionLimit;
        String CvmRequiredLimit;

        private DynamicLimitConfig() {
        }

        private boolean isEqual(DynamicLimitConfig dynamicLimitConfig) {
            if (dynamicLimitConfig == null) {
                return false;
            }
            if (this.ProgramId == null && dynamicLimitConfig.ProgramId != null || this.ProgramId != null && dynamicLimitConfig.ProgramId == null) {
                return false;
            }
            if (this.ProgramId != null && !this.ProgramId.contentEquals(dynamicLimitConfig.ProgramId)) {
                return false;
            }
            if (this.PerformStatusCheck != dynamicLimitConfig.PerformStatusCheck) {
                return false;
            }
            if (this.AllowStatusCheck != dynamicLimitConfig.AllowStatusCheck) {
                return false;
            }
            if (this.PerformZeroAmountCheck != dynamicLimitConfig.PerformZeroAmountCheck) {
                return false;
            }
            if (this.AllowZeroAmount != dynamicLimitConfig.AllowZeroAmount) {
                return false;
            }
            if (this.OnlineCryptogramOnZeroAmount != dynamicLimitConfig.OnlineCryptogramOnZeroAmount) {
                return false;
            }
            if (this.PerformFloorLimitCheck != dynamicLimitConfig.PerformFloorLimitCheck) {
                return false;
            }
            if (this.PerformTransactionLimitCheck != dynamicLimitConfig.PerformTransactionLimitCheck) {
                return false;
            }
            if (this.PerformCvmRequiredLimitCheck != dynamicLimitConfig.PerformCvmRequiredLimitCheck) {
                return false;
            }
            if (this.FloorLimit == null && dynamicLimitConfig.FloorLimit != null || this.FloorLimit != null && dynamicLimitConfig.FloorLimit == null) {
                return false;
            }
            if (this.FloorLimit != null && !this.FloorLimit.contentEquals(dynamicLimitConfig.FloorLimit)) {
                return false;
            }
            if (this.TransactionLimit == null && dynamicLimitConfig.TransactionLimit != null || this.TransactionLimit != null && dynamicLimitConfig.TransactionLimit == null) {
                return false;
            }
            if (this.TransactionLimit != null && !this.TransactionLimit.contentEquals(dynamicLimitConfig.TransactionLimit)) {
                return false;
            }
            if (this.CvmRequiredLimit == null && dynamicLimitConfig.CvmRequiredLimit != null || this.CvmRequiredLimit != null && dynamicLimitConfig.CvmRequiredLimit == null) {
                return false;
            }
            return this.CvmRequiredLimit == null || this.CvmRequiredLimit.contentEquals(dynamicLimitConfig.CvmRequiredLimit);
        }
    }

    private class KernelCtlConfig {
        String kernelID;
        String aid;
        int PriorityIndicator;
        boolean PerformStatusCheck;
        boolean AllowStatusCheck;
        boolean PerformZeroAmountCheck;
        boolean AllowZeroAmount;
        boolean OnlineCryptogramOnZeroAmount;
        boolean PerformFloorLimitCheck;
        boolean PerformTransactionLimitCheck;
        boolean PerformCvmRequiredLimitCheck;
        boolean EmvSupported;
        boolean MsdSupported;
        boolean AllowPartialMatch;
        boolean OnDeviceCvmSupported;
        boolean VisaTTQPresent;
        boolean VisaPreProcessingRequired;
        boolean AmexProcessingRrequired;
        boolean MasterCardProcessingRequired;
        boolean RebootAfterGPO;
        boolean NoCardholderConfirmation;
        boolean AllowLOA;
        boolean isFrenchAID;
        boolean supportDRL = false;
        String TerminalCapabilities;
        String TerminalCapabilitiesNoCvm;
        String TerminalCapabilitiesMsd;
        String AdditionalTerminalCapabilities;
        String EmvApplicationVersionList;
        String MsdApplicationVersionList;
        String TerminalTransactionQualifier;
        String TerminalTransactionQualifierCash;
        String TerminalTransactionQualifierRefund;
        String TerminalTransactionQualifierCashback;
        String TerminalActionCodeOnline;
        String TerminalActionCodeDefault;
        String TerminalActionCodeDenial;
        String DefaultTDOL;
        String DefaultDDOL;
        String DefaultUDOL;
        String ExpressPayTerminalCapabilities;
        String ForbiddenProduct;
        List<String> ForbiddenProductList;
        int ExpressPayRandomNumberScope;
        String ExpressPayTerminalTransactionCapabilities;
        List<Integer> amountConfigList = new ArrayList<Integer>();

        private KernelCtlConfig() {
        }

        private boolean isEqual(KernelCtlConfig kernelCtlConfig) {
            if (kernelCtlConfig == null) {
                return false;
            }
            if (this.kernelID != null && !this.kernelID.contentEquals(kernelCtlConfig.kernelID)) {
                return false;
            }
            if (this.aid != null && !this.aid.contentEquals(kernelCtlConfig.aid)) {
                return false;
            }
            return this.isFrenchAID == kernelCtlConfig.isFrenchAID;
        }
    }
}

