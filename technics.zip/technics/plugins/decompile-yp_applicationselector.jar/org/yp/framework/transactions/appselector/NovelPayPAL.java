/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters.YP_TCD_DCB_Interface_CallParameters;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.transactions.appselector.YP_BT_WEB_Mobile;
import org.yp.utils.EMV;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class NovelPayPAL {
    public static final String PART_MATCH = "0";
    public static final String FULL_MATCH = "1";
    private static final String defaultAdditionalTerminalCapabilities = "600080A001";
    private static final String defaultUDOL = "9F6A04";
    private static final byte[] terminalCapabilitiesMCMagstripe;
    private static final byte[] terminalCapabilitiesMC;
    private static final byte[] terminalCapabilitiesNoCVMMC;
    private static final byte[] terminalCapabilitiesVISA;
    private static final byte[] terminalCapabilitiesNoCVMVISA;
    private static final byte[] defaultTerminalCapabilities;
    private static final byte[] defaultTerminalCapabilitiesNoCVM;
    private static final byte[] terminalCapabilitiesAMEX;
    private static final String defaultVISATTQ = "32204000";
    private static final String defaultVISARefundTTQ = "22800000";

    static {
        byte[] byArray = new byte[3];
        byArray[0] = 96;
        byArray[1] = 32;
        terminalCapabilitiesMCMagstripe = byArray;
        terminalCapabilitiesMC = new byte[]{96, 32, 8};
        terminalCapabilitiesNoCVMMC = new byte[]{96, 8, 8};
        terminalCapabilitiesVISA = new byte[]{96, 32, 64};
        terminalCapabilitiesNoCVMVISA = new byte[]{96, 40, 64};
        defaultTerminalCapabilities = new byte[]{96, 32, 72};
        defaultTerminalCapabilitiesNoCVM = new byte[]{96, 40, 72};
        terminalCapabilitiesAMEX = new byte[]{96, -88, -56};
    }

    public static void dealEMV_ICC_NFC_KeyUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                HashMap<String, String> hashMap = new HashMap<String, String>();
                StringBuilder stringBuilder = new StringBuilder();
                for (YP_TCD_DCC_Business object : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!object.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)object.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC) && !yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getKeysTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string;
                            String string2 = yP_Row.getFieldStringValueByName("rid");
                            int n = (Integer)yP_Row.getFieldValueByName("index");
                            int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                            String string3 = yP_Row.getFieldStringValueByName("keyValue");
                            if (string3.length() % 2 == 1) {
                                yP_Transaction.logger(2, "dealEMV_ICC_NFC_KeyUpdate() bad key value ignored");
                                continue;
                            }
                            String string4 = Integer.toHexString(n);
                            if (string4.length() % 2 == 1) {
                                string4 = String.valueOf('0') + string4;
                            }
                            if ((string = Integer.toHexString(n2)).length() % 2 == 1) {
                                string = String.valueOf('0') + string;
                            }
                            String string5 = String.valueOf(string2) + string4 + string3 + string;
                            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                            String string6 = UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string5)));
                            String string7 = String.valueOf(string2) + "_" + string4;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            NovelPayPAL.add(stringBuilder2, "expirationDate", "291231");
                            NovelPayPAL.add(stringBuilder2, "hash", string6);
                            while (string.length() < 6) {
                                string = String.valueOf('0') + string;
                            }
                            NovelPayPAL.add(stringBuilder2, "exponent", string);
                            NovelPayPAL.add(stringBuilder2, "index", string4);
                            NovelPayPAL.add(stringBuilder2, "key", string3);
                            NovelPayPAL.add(stringBuilder2, "rid", string2);
                            if (yP_Transaction.getLogLevel() >= 5) {
                                yP_Transaction.logger(5, "dealEMV_ICC_NFC_KeyUpdate() rid: " + string2);
                                yP_Transaction.logger(5, "dealEMV_ICC_NFC_KeyUpdate() index: " + string4);
                                yP_Transaction.logger(5, "dealEMV_ICC_NFC_KeyUpdate() exponent: " + string);
                                yP_Transaction.logger(5, "dealEMV_ICC_NFC_KeyUpdate() hash: " + string6);
                            }
                            boolean bl = false;
                            String string8 = (String)hashMap.get(string7);
                            if (string8 != null) {
                                if (!string8.contentEquals(stringBuilder2)) {
                                    yP_Transaction.logger(3, "dealEMV_ICC_NFC_KeyUpdate() Same key differents values " + string8 + " vs " + stringBuilder2);
                                }
                                bl = true;
                            }
                            if (bl) continue;
                            hashMap.put(string7, stringBuilder2.toString());
                            if (stringBuilder.length() == 0) {
                                stringBuilder.append("[");
                            } else {
                                stringBuilder.append(",");
                            }
                            stringBuilder.append("\r\n{\r\n");
                            stringBuilder.append(stringBuilder2.toString());
                            stringBuilder.append("\r\n}");
                        }
                    }
                }
                if (stringBuilder.length() > 0) {
                    stringBuilder.append("\r\n]");
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, stringBuilder.toString());
                    tLVHandler.add(14672506, (long)stringBuilder.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                    list2.add(parameterFile2);
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_NFC_KeyUpdate()" + exception);
        }
    }

    private static String getTerminalType(YP_Transaction yP_Transaction) {
        YP_Row yP_Row = yP_Transaction.getDataContainerTransaction().getTerminalRow();
        if (yP_Row == null) {
            return "22";
        }
        String string = yP_Row.getFieldStringValueByName("terminalType");
        if (string == null || string.isEmpty()) {
            return "22";
        }
        return string;
    }

    private static void add(StringBuilder stringBuilder, String string, String string2) {
        if (stringBuilder.length() > 0) {
            stringBuilder.append(",\r\n");
        }
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\": \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"");
    }

    public static void dealEMV_ICC_AIDUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l += 4L))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                StringBuilder stringBuilder = new StringBuilder();
                HashMap<String, String> hashMap = new HashMap<String, String>();
                for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!(object2 instanceof YP_TCD_DCC_EFT_Business) || !object2.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)object2.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getAIDTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            Boolean bl;
                            String string = yP_Row.getFieldStringValueByName("rid");
                            String string2 = yP_Row.getFieldStringValueByName("pix");
                            String string3 = String.valueOf(string) + string2;
                            YP_Row yP_Row2 = yP_TCD_DCB_Interface_EMV.getAIDParameters(string3);
                            if (yP_Row2 == null) {
                                yP_Transaction.logger(2, "dealEMV_ICC_AIDUpdate() Parameters not found for aid" + string3);
                                continue;
                            }
                            String string4 = EMV.getAIDName(string3);
                            if (string4.length() > 16) {
                                string4 = string4.substring(0, 16);
                            }
                            String string5 = (bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed")) == null || bl != false ? PART_MATCH : FULL_MATCH;
                            int n = (Integer)yP_Row.getFieldValueByName("priority");
                            String string6 = yP_Row2.getFieldStringValueByName("defaultDDOL");
                            String string7 = yP_Row2.getFieldStringValueByName("defaultTDOL");
                            String string8 = yP_Row2.getFieldStringValueByName("tacDenial");
                            String string9 = yP_Row2.getFieldStringValueByName("tacOnline");
                            String string10 = yP_Row2.getFieldStringValueByName("tacDefault");
                            long l2 = (Long)yP_Row2.getFieldValueByName("thresholdCall");
                            int n2 = (Integer)yP_Row2.getFieldValueByName("randomCallCoefficient");
                            int n3 = (Integer)yP_Row2.getFieldValueByName("randomCallMaximumCoefficient");
                            int n4 = (Integer)yP_Row2.getFieldValueByName("currencyNumericalCode");
                            YP_TCD_DCB_Interface_CallParameters.Thresholds thresholds = null;
                            if (n4 == 0) {
                                yP_Transaction.logger(3, "dealEMV_ICC_AIDUpdate() no random call parameters for " + string3);
                            } else {
                                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionCurrencyNumerical(n4);
                                thresholds = ((YP_TCD_DCC_EFT_Business)object2).callParametersInterface.getThresholds(yP_Transaction.getDataContainerTransaction());
                            }
                            if (thresholds == null) {
                                thresholds = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
                            }
                            long l3 = thresholds.defaultThreshold;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            NovelPayPAL.add(stringBuilder2, "aid", string3);
                            NovelPayPAL.add(stringBuilder2, "appSelectionIndicator", string5);
                            NovelPayPAL.add(stringBuilder2, "appLabel", string4);
                            NovelPayPAL.add(stringBuilder2, "defaultDDOL", string6);
                            NovelPayPAL.add(stringBuilder2, "defaultTDOL", string7);
                            NovelPayPAL.add(stringBuilder2, "floorLimit", Long.toString(l3));
                            NovelPayPAL.add(stringBuilder2, "maxTargetPercentage", Integer.toString(n3));
                            NovelPayPAL.add(stringBuilder2, "tacDefault", string10);
                            NovelPayPAL.add(stringBuilder2, "tacDenial", string8);
                            NovelPayPAL.add(stringBuilder2, "tacOnline", string9);
                            NovelPayPAL.add(stringBuilder2, "targetPercentage", Integer.toString(n2));
                            NovelPayPAL.add(stringBuilder2, "threshold", Long.toString(l2));
                            String string11 = Integer.toHexString(n);
                            if (string11.length() == 1) {
                                string11 = PART_MATCH + string11;
                            }
                            NovelPayPAL.add(stringBuilder2, "priority", string11);
                            boolean bl2 = false;
                            String string12 = (String)hashMap.get(string3);
                            if (string12 != null) {
                                if (!string12.contentEquals(stringBuilder2.toString())) {
                                    yP_Transaction.logger(3, "dealEMV_ICC_AIDUpdate() Same aid differents values " + string12 + " vs " + stringBuilder2);
                                }
                                bl2 = true;
                            }
                            if (bl2) continue;
                            hashMap.put(string3, stringBuilder2.toString());
                            if (stringBuilder.length() == 0) {
                                stringBuilder.append("[");
                            } else {
                                stringBuilder.append(",");
                            }
                            stringBuilder.append("\r\n{\r\n");
                            stringBuilder.append(stringBuilder2.toString());
                            stringBuilder.append("\r\n}");
                        }
                    }
                }
                if (stringBuilder.length() > 0) {
                    stringBuilder.append("\r\n]");
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, stringBuilder.toString());
                    tLVHandler.add(14672506, (long)stringBuilder.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                } else {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals(PART_MATCH)) {
                        return;
                    }
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, "");
                    tLVHandler.add(14672506, 0L);
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                    parameterFile2.headerParameterFile.checksum = PART_MATCH;
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_AIDUpdate()" + exception);
        }
    }

    public static void dealCTCL_Parameters_Update(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        l += 11L;
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                String string;
                String string2;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                ConfigObject configObject = null;
                block2: for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!object2.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)object2.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        String string3 = object2.getCountryCode();
                        while (string3.length() < 4) {
                            string3 = String.valueOf('0') + string3;
                        }
                        if (configObject == null) {
                            configObject = new ConfigObject();
                        }
                        configObject.ctlsInitConfig.countryCode = string3;
                        configObject.ctlsInitConfig.terminalType = NovelPayPAL.getTerminalType(yP_Transaction);
                        configObject.ctlsInitConfig.termId = "00000000";
                        configObject.ctlsInitConfig.merchId = "000000000000000";
                        NovelPayPAL.deallOneCTCLContract(yP_Transaction, object2, yP_TCD_DCB_Interface_CTCL, configObject);
                        continue block2;
                    }
                }
                if (configObject != null && (string2 = NovelPayPAL.getForbiddenProducts(yP_Transaction, list)) != null && !string2.isEmpty()) {
                    configObject.ctlsInitConfig.forbiddenProducts = string2;
                }
                if ((string = NovelPayPAL.generateJSON(configObject)) != null) {
                    if (yP_Transaction.getLogLevel() == 6) {
                        yP_Transaction.logger(6, "dealCTCL_Parameters_Update()  : " + string);
                    }
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, string);
                    tLVHandler.add(14672506, (long)string.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                }
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals(PART_MATCH)) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = PART_MATCH;
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealCTCL_Parameters_Update() " + exception);
        }
    }

    private static String generateJSON(ConfigObject configObject) {
        if (configObject == null) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{\r\n");
        stringBuilder.append("\"ctlsInitConfig\": {\r\n");
        NovelPayPAL.appendJson(stringBuilder, configObject.ctlsInitConfig);
        stringBuilder.append("\r\n  },\r\n");
        stringBuilder.append("\"debitCtlsCombinationList\": [");
        NovelPayPAL.appendJson(stringBuilder, configObject.debitCtlsCombinationList);
        stringBuilder.append("\r\n  ],\r\n");
        stringBuilder.append("\"refundCtlsCombinationList\": [");
        NovelPayPAL.appendJson(stringBuilder, configObject.refundCtlsCombinationList);
        stringBuilder.append("\r\n  ],\r\n");
        stringBuilder.append("\"ctlsDebitUpdateConfigList\": [");
        NovelPayPAL.appendJsonUpdateConfig(stringBuilder, configObject.ctlsDebitUpdateConfigList);
        stringBuilder.append("\r\n  ],\r\n");
        stringBuilder.append("\"ctlsRefundUpdateConfigList\": [");
        NovelPayPAL.appendJsonUpdateConfig(stringBuilder, configObject.ctlsRefundUpdateConfigList);
        stringBuilder.append("\r\n  ],\r\n");
        stringBuilder.append("\"ctlsLimitSetList\": [");
        NovelPayPAL.appendJsonLimits(stringBuilder, configObject.ctlsLimitSetList);
        stringBuilder.append("\r\n  ]\r\n");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private static void appendJson(StringBuilder stringBuilder, CtlsInitConfig ctlsInitConfig) {
        NovelPayPAL.appendJson(stringBuilder, "countryCode", ctlsInitConfig.countryCode);
        NovelPayPAL.appendJson(stringBuilder, "terminalType", ctlsInitConfig.terminalType);
        NovelPayPAL.appendJson(stringBuilder, "termId", ctlsInitConfig.termId);
        NovelPayPAL.appendJson(stringBuilder, "merchId", ctlsInitConfig.merchId);
        NovelPayPAL.appendJson(stringBuilder, "forbiddenProducts", ctlsInitConfig.forbiddenProducts, true);
    }

    private static void appendJson(StringBuilder stringBuilder, List<CtlsCombination> list) {
        int n = 0;
        while (n < list.size()) {
            CtlsCombination ctlsCombination = list.get(n);
            if (n != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append("\r\n  {\r\n");
            NovelPayPAL.appendJson(stringBuilder, "kernelId", ctlsCombination.kernelId);
            NovelPayPAL.appendJson(stringBuilder, "aid", ctlsCombination.aid);
            NovelPayPAL.appendJson(stringBuilder, "ttq", ctlsCombination.ttq);
            NovelPayPAL.appendJson(stringBuilder, "appSelectionIndicator", ctlsCombination.appSelectionIndicator);
            NovelPayPAL.appendJson(stringBuilder, "zeroAmountAllowedFlag", ctlsCombination.zeroAmountAllowedFlag);
            NovelPayPAL.appendJson(stringBuilder, "extendedSelectionSupportFlag", ctlsCombination.extendedSelectionSupportFlag);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTermFloorLimit", ctlsCombination.readerCtlsTermFloorLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTrnsLimit", ctlsCombination.readerCtlsTrnsLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsFloorLimit", ctlsCombination.readerCtlsFloorLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCVMRequiredLimit", ctlsCombination.readerCVMRequiredLimit);
            NovelPayPAL.appendJson(stringBuilder, "statusCheckSupportFlag", ctlsCombination.statusCheckSupportFlag);
            NovelPayPAL.appendJson(stringBuilder, "currencyCode", ctlsCombination.currencyCode);
            NovelPayPAL.appendJson(stringBuilder, "priority", ctlsCombination.priority, true);
            stringBuilder.append("  }");
            ++n;
        }
    }

    private static void appendJsonUpdateConfig(StringBuilder stringBuilder, List<CtlsUpdateConfig> list) {
        int n = 0;
        while (n < list.size()) {
            CtlsUpdateConfig ctlsUpdateConfig = list.get(n);
            if (n != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append("\r\n  {\r\n");
            NovelPayPAL.appendJson(stringBuilder, "kernelId", ctlsUpdateConfig.kernelId);
            NovelPayPAL.appendJson(stringBuilder, "selectedAid", ctlsUpdateConfig.selectedAid);
            NovelPayPAL.appendJson(stringBuilder, "ctlsTermCapabilities", ctlsUpdateConfig.ctlsTermCapabilities);
            NovelPayPAL.appendJson(stringBuilder, "ctlsAddTermCapabilities", ctlsUpdateConfig.ctlsAddTermCapabilities);
            NovelPayPAL.appendJson(stringBuilder, "appName", ctlsUpdateConfig.appName);
            NovelPayPAL.appendJson(stringBuilder, "merchantNameLocation", ctlsUpdateConfig.merchantNameLocation);
            NovelPayPAL.appendJson(stringBuilder, "acquirerId", ctlsUpdateConfig.acquirerId);
            NovelPayPAL.appendJson(stringBuilder, "appVersionNumber", ctlsUpdateConfig.appVersionNumber);
            NovelPayPAL.appendJson(stringBuilder, "chipCapabilityCVMReq", ctlsUpdateConfig.chipCapabilityCVMReq);
            NovelPayPAL.appendJson(stringBuilder, "chipCapabilityNoCVM", ctlsUpdateConfig.chipCapabilityNoCVM);
            NovelPayPAL.appendJson(stringBuilder, "holdTimeValue", ctlsUpdateConfig.holdTimeValue);
            NovelPayPAL.appendJson(stringBuilder, "ifdSerialNo", ctlsUpdateConfig.ifdSerialNo);
            NovelPayPAL.appendJson(stringBuilder, "kernel2Configuration", ctlsUpdateConfig.kernel2Configuration);
            NovelPayPAL.appendJson(stringBuilder, "magCapabilityNoCVM", ctlsUpdateConfig.magCapabilityNoCVM);
            NovelPayPAL.appendJson(stringBuilder, "magCapabilityCVMReq", ctlsUpdateConfig.magCapabilityCVMReq);
            NovelPayPAL.appendJson(stringBuilder, "merchantCategoryCode", ctlsUpdateConfig.merchantCategoryCode);
            NovelPayPAL.appendJson(stringBuilder, "merchantCustomData", ctlsUpdateConfig.merchantCustomData);
            NovelPayPAL.appendJson(stringBuilder, "merchantIdentifier", ctlsUpdateConfig.merchantIdentifier);
            NovelPayPAL.appendJson(stringBuilder, "messageHoldTime", ctlsUpdateConfig.messageHoldTime);
            NovelPayPAL.appendJson(stringBuilder, "tacDefault", ctlsUpdateConfig.tacDefault);
            NovelPayPAL.appendJson(stringBuilder, "tacDenial", ctlsUpdateConfig.tacDenial);
            NovelPayPAL.appendJson(stringBuilder, "tacOnline", ctlsUpdateConfig.tacOnline);
            NovelPayPAL.appendJson(stringBuilder, "tranCategoryCode", ctlsUpdateConfig.tranCategoryCode);
            NovelPayPAL.appendJson(stringBuilder, "terminalRiskMgmtData", ctlsUpdateConfig.terminalRiskMgmtData);
            NovelPayPAL.appendJson(stringBuilder, "phoneMsgTable", ctlsUpdateConfig.phoneMsgTable);
            if (ctlsUpdateConfig.amexContactlessReaderCapabilities != null) {
                NovelPayPAL.appendJson(stringBuilder, "amexContactlessReaderCapabilities", ctlsUpdateConfig.amexContactlessReaderCapabilities);
            }
            if (ctlsUpdateConfig.amexEnhancedContactlessReaderCapabilities != null) {
                NovelPayPAL.appendJson(stringBuilder, "amexEnhancedContactlessReaderCapabilities", ctlsUpdateConfig.amexEnhancedContactlessReaderCapabilities);
            }
            if (ctlsUpdateConfig.defaultDDOL != null) {
                NovelPayPAL.appendJson(stringBuilder, "defaultDDOL", ctlsUpdateConfig.defaultDDOL);
            }
            if (ctlsUpdateConfig.defaultTDOL != null) {
                NovelPayPAL.appendJson(stringBuilder, "defaultTDOL", ctlsUpdateConfig.defaultTDOL);
            }
            String cfr_ignored_0 = ctlsUpdateConfig.defaultUDOL;
            NovelPayPAL.appendJson(stringBuilder, "currencyCode", ctlsUpdateConfig.limitSet.currencyCode);
            NovelPayPAL.appendJson(stringBuilder, "appProgramId", ctlsUpdateConfig.limitSet.appProgramId);
            NovelPayPAL.appendJson(stringBuilder, "appSelectionIndicator", ctlsUpdateConfig.limitSet.appSelectionIndicator);
            NovelPayPAL.appendJson(stringBuilder, "zeroAmountAllowedFlag", ctlsUpdateConfig.limitSet.zeroAmountAllowedFlag);
            NovelPayPAL.appendJson(stringBuilder, "statusCheckAllowedFlag", ctlsUpdateConfig.limitSet.statusCheckAllowedFlag);
            NovelPayPAL.appendJson(stringBuilder, "readerCVMRequiredLimit", ctlsUpdateConfig.limitSet.readerCVMRequiredLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsFloorLimit", ctlsUpdateConfig.limitSet.readerCtlsFloorLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimit", ctlsUpdateConfig.limitSet.readerCtlsTranLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTermFloorLimit", ctlsUpdateConfig.limitSet.readerCtlsTermFloorLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimitNoOnDev", ctlsUpdateConfig.limitSet.readerCtlsTranLimitNoOnDev);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimitOnDev", ctlsUpdateConfig.limitSet.readerCtlsTranLimitOnDev);
            NovelPayPAL.appendJson(stringBuilder, "currencyExponent", ctlsUpdateConfig.limitSet.currencyExponent, true);
            stringBuilder.append("  }");
            ++n;
        }
    }

    private static void appendJsonLimits(StringBuilder stringBuilder, List<LimitSet> list) {
        int n = 0;
        while (n < list.size()) {
            LimitSet limitSet = list.get(n);
            if (n != 0) {
                stringBuilder.append(",");
            }
            stringBuilder.append("\r\n  {\r\n");
            NovelPayPAL.appendJson(stringBuilder, "kernelId", limitSet.kernelId);
            NovelPayPAL.appendJson(stringBuilder, "currencyCode", limitSet.currencyCode);
            NovelPayPAL.appendJson(stringBuilder, "appProgramId", limitSet.appProgramId);
            NovelPayPAL.appendJson(stringBuilder, "appSelectionIndicator", limitSet.appSelectionIndicator);
            NovelPayPAL.appendJson(stringBuilder, "zeroAmountAllowedFlag", limitSet.zeroAmountAllowedFlag);
            NovelPayPAL.appendJson(stringBuilder, "statusCheckAllowedFlag", limitSet.statusCheckAllowedFlag);
            NovelPayPAL.appendJson(stringBuilder, "readerCVMRequiredLimit", limitSet.readerCVMRequiredLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsFloorLimit", limitSet.readerCtlsFloorLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimit", limitSet.readerCtlsTranLimit);
            NovelPayPAL.appendJson(stringBuilder, "readerCtlsTermFloorLimit", limitSet.readerCtlsTermFloorLimit);
            if (limitSet.readerCtlsTranLimitNoOnDev != null) {
                NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimitNoOnDev", limitSet.readerCtlsTranLimitNoOnDev);
            }
            if (limitSet.readerCtlsTranLimitOnDev != null) {
                NovelPayPAL.appendJson(stringBuilder, "readerCtlsTranLimitOnDev", limitSet.readerCtlsTranLimitOnDev);
            }
            NovelPayPAL.appendJson(stringBuilder, "currencyExponent", limitSet.currencyExponent, true);
            stringBuilder.append("  }");
            ++n;
        }
    }

    private static void appendJson(StringBuilder stringBuilder, String string, int n) {
        NovelPayPAL.appendJson(stringBuilder, string, n, false);
    }

    private static void appendJson(StringBuilder stringBuilder, String string, int n, boolean bl) {
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\" : ");
        stringBuilder.append(n);
        if (bl) {
            stringBuilder.append("\r\n");
        } else {
            stringBuilder.append(",\r\n");
        }
    }

    private static void appendJson(StringBuilder stringBuilder, String string, String string2) {
        NovelPayPAL.appendJson(stringBuilder, string, string2, false);
    }

    private static void appendJson(StringBuilder stringBuilder, String string, String string2, boolean bl) {
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\" : \"");
        stringBuilder.append(string2);
        if (bl) {
            stringBuilder.append("\"\r\n");
        } else {
            stringBuilder.append("\",\r\n");
        }
    }

    private static void deallOneCTCLContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, ConfigObject configObject) {
        Object object;
        int n = YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(yP_TCD_DCC_Business);
        List<YP_Row> list = yP_TCD_DCB_Interface_CTCL.getAIDKIDList(Integer.toString(n));
        block51: for (YP_Row yP_Row : list) {
            object = "";
            String string = "";
            try {
                Object object2;
                CtlsUpdateConfig ctlsUpdateConfig;
                CtlsCombination ctlsCombination;
                int n2;
                block88: {
                    block86: {
                        String string2;
                        List<YP_Row> list2;
                        object = yP_Row.getFieldStringValueByName("applicationIdentifier");
                        n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
                        switch (n2) {
                            case 2: 
                            case 3: 
                            case 4: {
                                break;
                            }
                            default: {
                                yP_Transaction.logger(3, "deallOneCTCLContract() kernel not yet handled " + n2);
                                continue block51;
                            }
                        }
                        string = yP_Row.getFieldStringValueByName("transactionType");
                        if (yP_Transaction.getLogLevel() == 6) {
                            yP_Transaction.logger(6, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + n2 + " " + string);
                        }
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getAIDTable();
                        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        if (((String)object).length() < 10) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid length invalid: " + ((String)object).length());
                            continue;
                        }
                        String string3 = ((String)object).substring(0, 10);
                        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                        String string4 = null;
                        if (((String)object).length() > 10) {
                            string4 = ((String)object).substring(10);
                            yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.START_WITH, string4);
                        }
                        if (((list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit)) == null || list2.isEmpty()) && ((list2 = NovelPayPAL.getPartialAIDRow(yP_TCD_DesignAccesObject, (String)object)) == null || list2.isEmpty())) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid not found for " + (String)object);
                            continue;
                        }
                        ctlsCombination = new CtlsCombination();
                        ctlsCombination.kernelId = n2;
                        ctlsCombination.aid = object;
                        String string5 = yP_Row.getFieldStringValueByName("signatureHandled");
                        if (NovelPayPAL.getTerminalType(yP_Transaction).contentEquals("25")) {
                            string5 = "false";
                        }
                        String string6 = yP_Row.getFieldStringValueByName("pinOnlineHandled");
                        String string7 = yP_Row.getFieldStringValueByName("noCVMHandled");
                        String string8 = yP_Row.getFieldStringValueByName("onDeviceCVMHandled");
                        if (string.contentEquals("20")) {
                            string8 = "true";
                        }
                        byte[] byArray = UtilsYP.redHexa(defaultVISATTQ);
                        byte[] byArray2 = UtilsYP.redHexa(defaultVISARefundTTQ);
                        if (string5 != null && string5.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 2);
                            byArray2[0] = (byte)(byArray2[0] | 2);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFD);
                            byArray2[0] = (byte)(byArray2[0] & 0xFD);
                        }
                        if (string6 != null && string6.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 4);
                            byArray2[0] = (byte)(byArray2[0] | 4);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFB);
                            byArray2[0] = (byte)(byArray2[0] & 0xFB);
                        }
                        if (string8 != null && string8.contentEquals("true")) {
                            byArray[2] = (byte)(byArray[2] | 0x40);
                            byArray2[2] = (byte)(byArray2[2] | 0x40);
                        } else {
                            byArray[2] = (byte)(byArray[2] & 0xBF);
                            byArray2[2] = (byte)(byArray2[2] & 0xBF);
                        }
                        switch (string) {
                            case "0": 
                            case "00": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray);
                                break;
                            }
                            case "20": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray2);
                            }
                        }
                        ctlsCombination.appSelectionIndicator = 0;
                        ctlsCombination.zeroAmountAllowedFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport")) ? 1 : 0;
                        ctlsCombination.extendedSelectionSupportFlag = 0;
                        ctlsCombination.readerCtlsTermFloorLimit = yP_Row.getFieldStringValueByName("readerContactlessFloorLimit");
                        long l = Long.parseLong(yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitNoOnDevice"));
                        long l2 = Long.parseLong(yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitOnDevice"));
                        ctlsCombination.readerCtlsTrnsLimit = l > l2 ? yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitNoOnDevice") : yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitOnDevice");
                        ctlsCombination.readerCtlsFloorLimit = yP_Row.getFieldStringValueByName("terminalFloorLimit");
                        ctlsCombination.readerCVMRequiredLimit = yP_Row.getFieldStringValueByName("readerCVMRequiredLimit");
                        ctlsCombination.statusCheckSupportFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("statusCheckSupport")) ? 1 : 0;
                        try {
                            int n3;
                            ctlsCombination.priority = n3 = ((Integer)list2.get(0).getFieldValueByName("priority")).intValue();
                        }
                        catch (Exception exception) {
                            yP_Transaction.logger(2, "deallOneCTCLContract(): While processing priority: " + (String)object, exception);
                        }
                        ctlsCombination.currencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
                        switch (string) {
                            case "0": 
                            case "00": {
                                configObject.debitCtlsCombinationList.add(ctlsCombination);
                                break;
                            }
                            case "20": {
                                configObject.refundCtlsCombinationList.add(ctlsCombination);
                                break;
                            }
                            default: {
                                yP_Transaction.logger(2, "deallOneCTCLContract(): row ignored : " + (String)object + " " + n2 + " " + string);
                                continue block51;
                            }
                        }
                        ctlsUpdateConfig = new CtlsUpdateConfig();
                        ctlsUpdateConfig.kernelId = n2;
                        ctlsUpdateConfig.selectedAid = object;
                        ctlsUpdateConfig.ctlsAddTermCapabilities = defaultAdditionalTerminalCapabilities;
                        ctlsUpdateConfig.appName = yP_TCD_DCC_Business.getContractRow().getFieldStringValueByName("contractLabel");
                        ctlsUpdateConfig.merchantNameLocation = UtilsYP.devHexa(yP_TCD_DCC_Business.getMerchantName().getBytes());
                        ctlsUpdateConfig.acquirerId = yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode();
                        StringBuilder stringBuilder = new StringBuilder();
                        int n4 = 0;
                        while (n4 < list2.size()) {
                            int n5 = (Integer)list2.get(n4).getFieldValueByName("terminalApplicationVersionNumber");
                            stringBuilder.append(String.format("%4s", Integer.toHexString(n5)).replace(' ', '0'));
                            ++n4;
                        }
                        ctlsUpdateConfig.appVersionNumber = stringBuilder.toString();
                        byte[] byArray3 = new byte[defaultTerminalCapabilities.length];
                        switch (n2) {
                            case 2: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMMC);
                                System.arraycopy(terminalCapabilitiesMC, 0, byArray3, 0, terminalCapabilitiesMC.length);
                                break;
                            }
                            case 3: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMVISA);
                                System.arraycopy(terminalCapabilitiesVISA, 0, byArray3, 0, terminalCapabilitiesVISA.length);
                                break;
                            }
                            case 4: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesAMEX);
                                System.arraycopy(terminalCapabilitiesAMEX, 0, byArray3, 0, terminalCapabilitiesAMEX.length);
                                break;
                            }
                            default: {
                                string2 = UtilsYP.devHexa(defaultTerminalCapabilitiesNoCVM);
                                System.arraycopy(defaultTerminalCapabilities, 0, byArray3, 0, defaultTerminalCapabilities.length);
                            }
                        }
                        byArray3[1] = string5 != null && string5.contentEquals("true") ? (byte)(byArray3[1] | 0x20) : (byte)(byArray3[1] & 0xDF);
                        byArray3[1] = string6 != null && string6.contentEquals("true") ? (byte)(byArray3[1] | 0x40) : (byte)(byArray3[1] & 0xBF);
                        byArray3[1] = string7 != null && string7.contentEquals("true") ? (byte)(byArray3[1] | 8) : (byte)(byArray3[1] & 0xF7);
                        ctlsUpdateConfig.ctlsTermCapabilities = UtilsYP.devHexa(byArray3);
                        ctlsUpdateConfig.chipCapabilityCVMReq = UtilsYP.devHexa(byArray3).substring(2, 4);
                        ctlsUpdateConfig.chipCapabilityNoCVM = string2.substring(2, 4);
                        ctlsUpdateConfig.holdTimeValue = "00";
                        ctlsUpdateConfig.messageHoldTime = "00";
                        ctlsUpdateConfig.ifdSerialNo = yP_TCD_DCC_Business.getTerminalIdentification();
                        if (n2 != 2) break block86;
                        object2 = new byte[1];
                        if (UtilsYP.isTrue(string8)) {
                            object2[0] = (byte)(object2[0] | 0x20);
                        }
                        switch (object) {
                            case "A0000000043060": 
                            case "A0000000422010": 
                            case "A0000000425010": {
                                object2[0] = (byte)(object2[0] | 0x80);
                                if (NovelPayPAL.getTerminalType(yP_Transaction).contentEquals("25")) {
                                    ctlsUpdateConfig.terminalRiskMgmtData = "0C00800000000000";
                                    break;
                                }
                                ctlsUpdateConfig.terminalRiskMgmtData = "2C00800000000000";
                                break;
                            }
                            default: {
                                ctlsUpdateConfig.terminalRiskMgmtData = NovelPayPAL.getTerminalType(yP_Transaction).contentEquals("25") ? "0C00000000000000" : "2C00000000000000";
                            }
                        }
                        ctlsUpdateConfig.kernel2Configuration = UtilsYP.devHexa((byte[])object2);
                        break block88;
                    }
                    ctlsUpdateConfig.terminalRiskMgmtData = "0000000000000000";
                    ctlsUpdateConfig.kernel2Configuration = "00";
                }
                if (n2 == 4) {
                    ctlsUpdateConfig.amexContactlessReaderCapabilities = "C0";
                    ctlsUpdateConfig.amexEnhancedContactlessReaderCapabilities = "D8A00000";
                }
                ctlsUpdateConfig.magCapabilityNoCVM = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsUpdateConfig.magCapabilityCVMReq = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsUpdateConfig.merchantCategoryCode = String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode()));
                ctlsUpdateConfig.merchantCustomData = "0000000000000000000000000000000000000000";
                ctlsUpdateConfig.merchantIdentifier = yP_TCD_DCC_Business.getCommercialRegisterNumber();
                ctlsUpdateConfig.tacOnline = yP_Row.getFieldStringValueByName("tacOnline");
                ctlsUpdateConfig.tacDefault = yP_Row.getFieldStringValueByName("tacDefault");
                ctlsUpdateConfig.tacDenial = yP_Row.getFieldStringValueByName("tacDenial");
                ctlsUpdateConfig.tranCategoryCode = 0;
                object2 = yP_TCD_DCB_Interface_CTCL.getAIDParameters((String)object);
                if (object2 != null) {
                    TLVHandler tLVHandler;
                    Object object3 = ((YP_Row)object2).getFieldStringValueByName("specificData");
                    if (object3 != null && !((String)object3).isEmpty() && (tLVHandler = new TLVHandler((String)object3)) != null) {
                        for (TLV tLV : tLVHandler) {
                            switch (tLV.tag) {
                                case 40787: {
                                    ctlsUpdateConfig.tranCategoryCode = Integer.parseInt(UtilsYP.devHexa(tLV.value), 16);
                                    break;
                                }
                                case 57103: {
                                    break;
                                }
                            }
                        }
                    }
                    ctlsUpdateConfig.defaultDDOL = ((YP_Row)object2).getFieldStringValueByName("defaultDDOL");
                    ctlsUpdateConfig.defaultTDOL = ((YP_Row)object2).getFieldStringValueByName("defaultTDOL");
                    ctlsUpdateConfig.defaultUDOL = defaultUDOL;
                }
                ctlsUpdateConfig.phoneMsgTable = "";
                ctlsUpdateConfig.limitSet = new LimitSet();
                ctlsUpdateConfig.limitSet.currencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
                ctlsUpdateConfig.limitSet.currencyExponent = yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface != null ? String.format("%02d", ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyFraction(Integer.parseInt(ctlsUpdateConfig.limitSet.currencyCode))) : "02";
                ctlsUpdateConfig.limitSet.readerCtlsFloorLimit = yP_Row.getFieldStringValueByName("readerContactlessFloorLimit");
                ctlsUpdateConfig.limitSet.readerCtlsTermFloorLimit = yP_Row.getFieldStringValueByName("terminalFloorLimit");
                ctlsUpdateConfig.limitSet.readerCVMRequiredLimit = yP_Row.getFieldStringValueByName("readerCVMRequiredLimit");
                ctlsUpdateConfig.limitSet.readerCtlsTranLimit = ctlsCombination.readerCtlsTrnsLimit;
                ctlsUpdateConfig.limitSet.readerCtlsTranLimitNoOnDev = yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitNoOnDevice");
                ctlsUpdateConfig.limitSet.readerCtlsTranLimitOnDev = yP_Row.getFieldStringValueByName("readerContactlessTransactionLimitOnDevice");
                ctlsUpdateConfig.limitSet.appSelectionIndicator = 0;
                ctlsUpdateConfig.limitSet.zeroAmountAllowedFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport")) ? 1 : 0;
                ctlsUpdateConfig.limitSet.statusCheckAllowedFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("statusCheckSupport")) ? 1 : 0;
                ctlsUpdateConfig.limitSet.appProgramId = "";
                switch (string) {
                    case "0": 
                    case "00": {
                        configObject.ctlsDebitUpdateConfigList.add(ctlsUpdateConfig);
                        break;
                    }
                    case "20": {
                        configObject.ctlsRefundUpdateConfigList.add(ctlsUpdateConfig);
                        break;
                    }
                    default: {
                        yP_Transaction.logger(2, "deallOneCTCLContract(): row ignored : " + (String)object + " " + n2 + " " + string);
                        break;
                    }
                }
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + string, exception);
            }
        }
        for (YP_Row yP_Row : yP_TCD_DCB_Interface_CTCL.getDRLTable()) {
            object = NovelPayPAL.fillInLimitSet(yP_TCD_DCC_Business, yP_Row);
            if (object == null) continue;
            configObject.ctlsLimitSetList.add((LimitSet)object);
        }
    }

    private static String getForbiddenProducts(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list) {
        TLVHandler tLVHandler = new TLVHandler();
        try {
            HashMap hashMap = new HashMap();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                YP_TCD_DCB_Interface_ProductList yP_TCD_DCB_Interface_ProductList;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_ProductList = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_ProductList.getProductListTable();
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string;
                    String string2;
                    String string3 = yP_Row.getFieldStringValueByName("emvApplicationAID");
                    if (string3 == null || string3.isEmpty()) {
                        yP_Transaction.logger(4, "getForbiddenProducts() maybe a product indexed by BIN");
                        continue;
                    }
                    ArrayList<String> arrayList = (ArrayList<String>)hashMap.get(string3);
                    if (arrayList == null) {
                        arrayList = new ArrayList<String>();
                        hashMap.put(string3, arrayList);
                    }
                    if ((string2 = yP_Row.getFieldStringValueByName("electronicProductIdentification")) == null || string2.isEmpty()) {
                        string2 = "0001";
                    }
                    if ((string = yP_Row.getFieldStringValueByName("codeProduit")) == null || string.isEmpty()) {
                        yP_Transaction.logger(3, "getForbiddenProducts() product code missing!!!");
                        continue;
                    }
                    if (arrayList.contains(string)) continue;
                    arrayList.add(string);
                    tLVHandler.add(79, string3);
                    tLVHandler.add(40714, String.format("%s%02d%s", string2, string.length() / 2, string));
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "getForbiddenProducts() ", exception);
        }
        return tLVHandler.toString();
    }

    private static LimitSet fillInLimitSet(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_Row yP_Row) {
        LimitSet limitSet = new LimitSet();
        String string = yP_Row.getFieldStringValueByName("statusCheckSupport");
        limitSet.statusCheckAllowedFlag = string != null && string.contentEquals(PART_MATCH) ? 1 : 0;
        String string2 = yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport");
        limitSet.zeroAmountAllowedFlag = string2 != null && string2.contentEquals(PART_MATCH) ? 1 : 0;
        limitSet.readerCVMRequiredLimit = yP_Row.getFieldStringValueByName("CVMRequiredLimit");
        limitSet.readerCVMRequiredLimit.contentEquals("999999999999");
        limitSet.readerCtlsTermFloorLimit = yP_Row.getFieldStringValueByName("ctlFloorLimit");
        limitSet.readerCtlsTermFloorLimit.contentEquals("999999999999");
        limitSet.readerCtlsFloorLimit = yP_Row.getFieldStringValueByName("ctlFloorLimit");
        limitSet.appProgramId = yP_Row.getFieldStringValueByName("applicationPgmId");
        limitSet.readerCtlsTranLimit = yP_Row.getFieldStringValueByName("ctlTransactionLimit");
        limitSet.kernelId = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
        limitSet.currencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
        while (limitSet.currencyCode.length() < 3) {
            limitSet.currencyCode = PART_MATCH + limitSet.currencyCode;
        }
        limitSet.currencyExponent = yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface != null ? String.format("%02d", ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyFraction(Integer.parseInt(limitSet.currencyCode))) : "02";
        limitSet.appSelectionIndicator = 0;
        return limitSet;
    }

    private static boolean isAlreadyInsideParameters(ConfigObject configObject, String string, String string2, String string3) {
        return false;
    }

    private static List<YP_Row> getPartialAIDRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        String string2 = string.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("partialSelectionAllowed", YP_ComplexGabarit.OPERATOR.EQUAL, true);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() == 0) {
            return null;
        }
        for (YP_Row yP_Row : list) {
            String string3 = yP_Row.getFieldStringValueByName("pix");
            if (!string.startsWith(String.valueOf(string2) + string3)) continue;
            arrayList.add(yP_Row);
        }
        return arrayList;
    }

    static class ConfigObject {
        CtlsInitConfig ctlsInitConfig = new CtlsInitConfig();
        List<CtlsCombination> debitCtlsCombinationList = new ArrayList<CtlsCombination>();
        List<CtlsCombination> refundCtlsCombinationList = new ArrayList<CtlsCombination>();
        List<CtlsUpdateConfig> ctlsDebitUpdateConfigList = new ArrayList<CtlsUpdateConfig>();
        List<CtlsUpdateConfig> ctlsRefundUpdateConfigList = new ArrayList<CtlsUpdateConfig>();
        List<LimitSet> ctlsLimitSetList = new ArrayList<LimitSet>();

        ConfigObject() {
        }
    }

    static class CtlsCombination {
        int kernelId;
        String aid;
        String ttq;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int extendedSelectionSupportFlag;
        String readerCtlsTermFloorLimit;
        String readerCtlsTrnsLimit;
        String readerCtlsFloorLimit;
        String readerCVMRequiredLimit;
        int statusCheckSupportFlag;
        String currencyCode;
        int priority;

        CtlsCombination() {
        }
    }

    static class CtlsInitConfig {
        String termId;
        String merchId;
        String countryCode;
        String terminalType;
        String forbiddenProducts;

        CtlsInitConfig() {
        }
    }

    static class CtlsUpdateConfig {
        int kernelId;
        String selectedAid;
        String ctlsTermCapabilities;
        String ctlsAddTermCapabilities;
        String appName;
        String merchantNameLocation;
        String acquirerId;
        String appVersionNumber;
        String chipCapabilityCVMReq;
        String chipCapabilityNoCVM;
        String holdTimeValue;
        String ifdSerialNo;
        String kernel2Configuration;
        String magCapabilityNoCVM;
        String magCapabilityCVMReq;
        String merchantCategoryCode;
        String merchantCustomData;
        String merchantIdentifier;
        String messageHoldTime;
        String tacDefault;
        String tacDenial;
        String tacOnline;
        int tranCategoryCode;
        String terminalRiskMgmtData;
        String phoneMsgTable;
        String amexContactlessReaderCapabilities;
        String amexEnhancedContactlessReaderCapabilities;
        String defaultDDOL;
        String defaultTDOL;
        String defaultUDOL;
        LimitSet limitSet;

        CtlsUpdateConfig() {
        }
    }

    static class LimitSet {
        int kernelId;
        String currencyCode;
        String appProgramId;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int statusCheckAllowedFlag;
        String readerCVMRequiredLimit;
        String readerCtlsFloorLimit;
        String readerCtlsTranLimit;
        String readerCtlsTermFloorLimit;
        String readerCtlsTranLimitNoOnDev;
        String readerCtlsTranLimitOnDev;
        String currencyExponent;

        LimitSet() {
        }
    }
}

