/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.transactions.appselector.SPm2x;
import org.yp.utils.EMV;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class FAPI {
    public static void dealEMV_ICC_NFC_Key_PosMateUpdate(YP_Transaction yP_Transaction, TLVHandler tLVHandler, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                Object object;
                Object object2;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                String string = "#CAK_Index;\r\n";
                string = String.valueOf(string) + "CAK_DefaultKeyAlgorithm=1;\r\n";
                string = String.valueOf(string) + "CAK_DefaultChecksumAlgorithm=1;\r\n";
                string = String.valueOf(string) + "CAK_ModulusChunkSize=64;\r\n";
                string = String.valueOf(string) + "CAK_CrlSerialsPerBlock=5;\r\n\r\n\r\n";
                HashMap<String, String> hashMap = new HashMap<String, String>();
                for (YP_TCD_DCC_Business object32 : list) {
                    if (!object32.getActivationCode().contentEquals("1") || (object2 = (YP_TCD_DCB_Interface_EMV)object32.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    object = (YP_TCD_DCB_Interface_CTCL)object32.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class);
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object32.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC) && !FAPI.isCtclActivated((YP_TCD_DCB_Interface_CTCL)object, yP_App_Interface_Selection)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = object2.getKeysTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string2;
                            String string3;
                            String string4 = yP_Row.getFieldStringValueByName("rid");
                            int n = (Integer)yP_Row.getFieldValueByName("index");
                            int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                            String string5 = yP_Row.getFieldStringValueByName("keyValue");
                            String string6 = Integer.toHexString(n);
                            if (string6.length() % 2 == 1) {
                                string6 = String.valueOf('0') + string6;
                            }
                            if ((string3 = Integer.toHexString(n2)).length() % 2 == 1) {
                                string3 = String.valueOf('0') + string3;
                            }
                            String string7 = String.valueOf(string4) + string6 + string5 + string3;
                            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                            String string8 = UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string7)));
                            String string9 = string2 = "#CAK_" + string4 + "_" + string6 + ";\r\n";
                            string9 = String.valueOf(string9) + "CAK_Exponent=" + n2 + ";\r\n";
                            string9 = String.valueOf(string9) + "CAK_ExpiryDate=20291231;\r\n";
                            string9 = String.valueOf(string9) + "CAK_Checksum=" + string8 + ";\r\n";
                            int n3 = string5.length() / 64;
                            if (string5.length() % 64 != 0) {
                                ++n3;
                            }
                            string9 = String.valueOf(string9) + "CAK_ModulusChunks=" + n3 + ";\r\n";
                            int n4 = 1;
                            while (n4 <= n3) {
                                string9 = n4 == n3 ? String.valueOf(string9) + "CAK_ModulusChunk" + n4 + "=" + string5.substring((n4 - 1) * 64) + ";\r\n" : String.valueOf(string9) + "CAK_ModulusChunk" + n4 + "=" + string5.substring((n4 - 1) * 64, n4 * 64) + ";\r\n";
                                ++n4;
                            }
                            n4 = 0;
                            String string10 = (String)hashMap.get(string2);
                            if (string10 != null) {
                                if (!string10.contentEquals(string9)) {
                                    yP_Transaction.logger(2, "dealEMV_ICC_NFC_Key_PosMateUpdate() Same key differents values " + string10 + " vs " + string9);
                                }
                                n4 = 1;
                            }
                            if (n4 != 0) continue;
                            hashMap.put(string2, string9);
                            string = String.valueOf(string) + string9;
                        }
                    }
                }
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "dealEMV_ICC_NFC_Key_PosMateUpdate() cakeys to download: " + string);
                }
                TLVHandler tLVHandler2 = new TLVHandler();
                TLV tLV = SPm2x.extractKSN(yP_Transaction, tLVHandler);
                if (tLV != null && tLV.value != null && tLV.value.length > 0) {
                    object2 = yP_Transaction.getPluginByName("CryptoManager");
                    object = (String)((YP_Object)object2).dealRequest(yP_Transaction, "sha256Hash", new Object[]{string.getBytes("ISO-8859-1")});
                    if (object == null || ((String)object).isEmpty()) {
                        yP_Transaction.logger(2, "dealEMV_ICC_NFC_Key_PosMateUpdate() pb during hash");
                    } else {
                        String string11 = DUKPT.macResponseData(UtilsYP.devHexa(tLV.value), UtilsYP.redHexa((String)object));
                        tLVHandler2.addASCII(14672758, string11);
                    }
                } else {
                    yP_Transaction.logger(2, "dealEMV_ICC_NFC_Key_PosMateUpdate() No KSN");
                }
                tLVHandler2.addASCII(14672757, string);
                tLVHandler2.add(14672506, (long)string.length());
                parameterFile2.appTagsList.add(tLVHandler2.toString());
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_NFC_Key_PosMateUpdate()", exception);
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void dealEMV_ICC_AID_PosmateUpdate(YP_Transaction yP_Transaction, TLVHandler tLVHandler, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l, long l2, long l3, long l4, YP_Row yP_Row) {
        try {
            Object object;
            long l5 = (l + l2 + l3) % 0x100000000L;
            long l6 = (l5 + l4) % 0x100000000L;
            boolean bl = false;
            if (yP_Row != null) {
                object = yP_Row.getFieldStringValueByName("kernelVersion");
                if (object != null && (((String)object).startsWith("t2.") || ((String)object).startsWith("2."))) {
                    bl = true;
                }
            } else {
                try {
                    long l7;
                    if (parameterFile.headerParameterFile.checksum != null && (l7 = Long.parseLong(parameterFile.headerParameterFile.checksum)) == l6) {
                        bl = true;
                    }
                }
                catch (Exception exception) {}
            }
            if (bl) {
                l5 = l6;
            }
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l5))) {
                String string;
                String string2;
                Object object2;
                Object object3;
                Object object4;
                Object object5;
                Object object6;
                object = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                ((UpdateHandler.ParameterFile)object).headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                ((UpdateHandler.ParameterFile)object).headerParameterFile.checksum = Long.toString(l5);
                ((UpdateHandler.ParameterFile)object).headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                HashMap<Object, String[]> hashMap = new HashMap<Object, String[]>();
                String string3 = "\r\n";
                if (bl) {
                    string3 = String.valueOf(string3) + ";";
                }
                if (bl && l4 > 0L) {
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                        Object object7;
                        if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (object7 = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null) continue;
                        for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                            if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                            object6 = object7.getProductListTable();
                            object5 = ((YP_TCD_DesignAccesObject)object6).iterator();
                            while (object5.hasNext()) {
                                object4 = object5.next();
                                object3 = ((YP_Row)object4).getFieldStringValueByName("emvApplicationAID");
                                if (object3 == null || ((String)object3).isEmpty()) {
                                    yP_Transaction.logger(4, "dealEMV_ICC_AID_PosmateUpdate() maybe a product indexed by BIN");
                                    continue;
                                }
                                object2 = (List)hashMap.get(object3);
                                if (object2 == null) {
                                    object2 = new ArrayList();
                                    hashMap.put(object3, (String[])object2);
                                }
                                if ((string2 = ((YP_Row)object4).getFieldStringValueByName("electronicProductIdentification")) == null || !string2.contentEquals("0001")) continue;
                                string = ((YP_Row)object4).getFieldStringValueByName("codeProduit");
                                if (string == null || string.isEmpty()) {
                                    yP_Transaction.logger(3, "dealEMV_ICC_AID_PosmateUpdate() product code missing!!!");
                                    continue;
                                }
                                if (object2.contains(string)) continue;
                                if (object2.size() > 4) {
                                    yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate() too many products for " + (String)object3);
                                    continue;
                                }
                                object2.add(string);
                            }
                        }
                    }
                }
                HashMap<String, String> hashMap2 = new HashMap<String, String>();
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                        object4 = yP_TCD_DCB_Interface_EMV.getAIDTable();
                        object3 = ((YP_TCD_DesignAccesObject)object4).iterator();
                        while (object3.hasNext()) {
                            Object object8;
                            Object object9;
                            YP_Row yP_Row2;
                            String string4;
                            String string5;
                            object5 = object3.next();
                            object2 = ((YP_Row)object5).getFieldStringValueByName("rid");
                            string2 = ((YP_Row)object5).getFieldStringValueByName("pix");
                            string = String.valueOf(object2) + string2;
                            Boolean bl2 = (Boolean)((YP_Row)object5).getFieldValueByName("partialSelectionAllowed");
                            int n = (Integer)((YP_Row)object5).getFieldValueByName("priority");
                            String string6 = "#APP_" + string + ";\r\n";
                            string6 = String.valueOf(string6) + "APP_Name = " + EMV.getAIDName(string) + ";\r\n";
                            string6 = bl2 == null || bl2 == false ? String.valueOf(string6) + "APP_PartialMatch = FALSE;\r\n" : String.valueOf(string6) + "APP_PartialMatch = TRUE;\r\n";
                            string6 = n == 254 || n == 255 ? String.valueOf(string6) + "APP_Priority = TRUE;\r\n" : String.valueOf(string6) + "APP_Priority = FALSE;\r\n";
                            if (yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && (string5 = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getEndUserLangageList(yP_Transaction.getDataContainerTransaction())) != null && !string5.isEmpty()) {
                                string6 = String.valueOf(string6) + "APP_Language = " + string5 + ";\r\n";
                            }
                            if ((string5 = yP_TCD_DCC_Business.getMerchantName()) != null && !string5.isEmpty()) {
                                string6 = String.valueOf(string6) + "APP_MerchantNameLocation = " + string5 + ";\r\n";
                            }
                            if ((string4 = yP_TCD_DCC_Business.getMerchantCategoryCode()) != null && !string4.isEmpty()) {
                                string6 = String.valueOf(string6) + "APP_MerchantCategoryCode = " + string4 + ";\r\n";
                            }
                            if ((yP_Row2 = yP_TCD_DCB_Interface_EMV.getAIDParameters(string)) != null && (object9 = yP_Row2.getFieldStringValueByName("specificData")) != null && !((String)object9).isEmpty() && (object8 = new TLVHandler((String)object9)) != null) {
                                Iterator<TLV> iterator = ((TLVHandler)object8).iterator();
                                while (iterator.hasNext()) {
                                    TLV tLV = iterator.next();
                                    switch (tLV.tag) {
                                        case 40787: {
                                            string6 = String.valueOf(string6) + "APP_TransactionCategoryCode = " + new String(tLV.value, "ISO-8859-1") + ";\r\n";
                                            break;
                                        }
                                        case 57103: {
                                            yP_Transaction.logger(3, "dealEMV_ICC_AID_PosmateUpdate(): Tag DF0F found -> probably a B12-V1 contract");
                                            break;
                                        }
                                        default: {
                                            yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate(): EMV tag extension not handled :" + Integer.toHexString(tLV.tag));
                                        }
                                    }
                                }
                            }
                            if (((String)object2).toUpperCase().contentEquals("A000000333")) {
                                string6 = String.valueOf(string6) + "APP_Capabilities=60F8C8;\r\n";
                            }
                            if (bl) {
                                string6 = String.valueOf(string6) + "APP_PriorityIndicator = " + n + ";\r\n";
                                object9 = (List)hashMap.get(string);
                                if (object9 != null && !object9.isEmpty()) {
                                    string6 = String.valueOf(string6) + "APP_ForbiddenProducts =";
                                    int n2 = 0;
                                    while (n2 < object9.size()) {
                                        if (n2 != 0) {
                                            string6 = String.valueOf(string6) + ",";
                                        }
                                        string6 = String.valueOf(string6) + (String)object9.get(n2);
                                        ++n2;
                                    }
                                    string6 = String.valueOf(string6) + ";\r\n";
                                }
                            }
                            string6 = String.valueOf(string6) + "\r\n";
                            boolean bl3 = false;
                            object8 = (String)hashMap2.get(string);
                            if (object8 != null) {
                                if (!((String)object8).contentEquals(string6)) {
                                    yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate() Same aid differents values " + (String)object8 + " vs " + string6);
                                }
                                bl3 = true;
                            }
                            if (bl3) continue;
                            hashMap2.put(string, string6);
                            string3 = String.valueOf(string3) + string6;
                        }
                    }
                }
                String[] stringArray = new String[]{"50", "71", "72", "82", "87", "89", "8A", "8C", "8D", "8E", "8F", "91", "95", "9A", "9B", "9C", "5F24", "5F25", "5F28", "5F2A", "5F2D", "5F30", "5F34", "9F02", "9F03", "9F06", "9F07", "9F08", "9F09", "9F0A", "9F0D", "9F0E", "9F0F", "9F10", "9F11", "9F12", "9F17", "9F1A", "9F21", "9F26", "9F27", "9F33", "9F34", "9F35", "9F36", "9F37", "9F39", "9F41", "9F4E", "D7", "D8", "D9", "DB"};
                int n = 0;
                boolean bl4 = false;
                StringBuffer stringBuffer = new StringBuffer("");
                object6 = new StringBuffer("");
                object2 = stringArray;
                int n3 = stringArray.length;
                int n4 = 0;
                while (n4 < n3) {
                    void var25_30;
                    object4 = object2[n4];
                    ++var25_30;
                    if (stringBuffer.length() + ((String)object4).length() > 64) {
                        ((StringBuffer)object6).append("TWL_Chunk");
                        ((StringBuffer)object6).append(++n);
                        ((StringBuffer)object6).append('=');
                        ((StringBuffer)object6).append(stringBuffer);
                        ((StringBuffer)object6).append(";\r\n");
                        stringBuffer.setLength(0);
                    }
                    stringBuffer.append((String)object4);
                    if (stringArray.length == var25_30) {
                        ((StringBuffer)object6).append("TWL_Chunk");
                        ((StringBuffer)object6).append(++n);
                        ((StringBuffer)object6).append('=');
                        ((StringBuffer)object6).append(stringBuffer);
                        ((StringBuffer)object6).append(";\r\n");
                    }
                    ++n4;
                }
                string3 = String.valueOf(string3) + "#TagsWhiteList;\r\n";
                string3 = String.valueOf(string3) + "TWL_Chunks=" + n + ";\r\n";
                string3 = String.valueOf(string3) + ((StringBuffer)object6).toString();
                object4 = new TLVHandler();
                TLV tLV = SPm2x.extractKSN(yP_Transaction, tLVHandler);
                if (tLV != null && tLV.value != null && tLV.value.length > 0) {
                    YP_Object yP_Object = yP_Transaction.getPluginByName("CryptoManager");
                    object2 = (String)yP_Object.dealRequest(yP_Transaction, "sha256Hash", new Object[]{string3.getBytes("ISO-8859-1")});
                    if (object2 == null || ((String)object2).isEmpty()) {
                        yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate() pb during hash");
                    } else {
                        string2 = DUKPT.macResponseData(UtilsYP.devHexa(tLV.value), UtilsYP.redHexa((String)object2));
                        ((TLVHandler)object4).addASCII(14672758, string2);
                    }
                } else {
                    yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate() No KSN");
                }
                ((TLVHandler)object4).addASCII(14672757, string3);
                if (yP_Transaction.getLogLevel() >= 5) {
                    yP_Transaction.logger(5, "dealEMV_ICC_AID_PosmateUpdate() aids: " + string3);
                }
                ((TLVHandler)object4).add(14672506, (long)string3.length());
                ((UpdateHandler.ParameterFile)object).appTagsList.add(((TLVHandler)object4).toString());
                list2.add((UpdateHandler.ParameterFile)object);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_AID_PosmateUpdate()", exception);
        }
    }

    private static boolean isCtclActivated(YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, YP_App_Interface_Selection yP_App_Interface_Selection) {
        return yP_TCD_DCB_Interface_CTCL != null && yP_TCD_DCB_Interface_CTCL.isActive() && yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS);
    }
}

