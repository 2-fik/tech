/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.security.MessageDigest;
import java.util.List;
import java.util.zip.CRC32;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.transactions.appselector.YP_BT_WEB_Mobile;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.xml.jaxb.ypproperties.Property;

public abstract class StandardTLV {
    public static void dealEMV_ICC_KeyUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    parameterFile2.headerParameterFile.tableVersion = yP_TCD_DCB_Interface_EMV.getKeysTable().getTableVersion();
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getKeysTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string;
                            TLVHandler tLVHandler = new TLVHandler();
                            String string2 = yP_Row.getFieldStringValueByName("rid");
                            int n = (Integer)yP_Row.getFieldValueByName("index");
                            int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                            String string3 = yP_Row.getFieldStringValueByName("keyValue");
                            tLVHandler.add(14672688, string2);
                            tLVHandler.add(14672434, (long)n);
                            String string4 = tLVHandler.toString();
                            tLVHandler.add(14672435, (long)n2);
                            tLVHandler.add(14672696, string3);
                            tLVHandler.add(14672692, "20130101");
                            tLVHandler.add(14672693, "20291231");
                            tLVHandler.add(14672694, "SHA-1");
                            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                            String string5 = Integer.toHexString(n);
                            if (string5.length() % 2 == 1) {
                                string5 = String.valueOf('0') + string5;
                            }
                            if ((string = Integer.toHexString(n2)).length() % 2 == 1) {
                                string = String.valueOf('0') + string;
                            }
                            String string6 = String.valueOf(string2) + string5 + string3 + string;
                            tLVHandler.add(14672695, UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string6))));
                            String string7 = tLVHandler.toString();
                            boolean bl = false;
                            for (String string8 : parameterFile2.appTagsList) {
                                if (!string8.startsWith(string4)) continue;
                                if (!string8.contentEquals(string7)) {
                                    yP_Transaction.logger(3, "dealEMV_ICC_KeyUpdate() Same key differents values " + string8 + " vs " + string7);
                                }
                                bl = true;
                                break;
                            }
                            if (bl) continue;
                            parameterFile2.appTagsList.add(string7);
                        }
                    }
                }
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = "0";
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_KeyUpdate()", exception);
        }
    }

    public static void dealEMV_ICC_AIDUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                    if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                    YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getAIDTable();
                    for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                        TLVHandler tLVHandler = new TLVHandler();
                        String string = yP_Row.getFieldStringValueByName("rid");
                        String string2 = yP_Row.getFieldStringValueByName("pix");
                        Boolean bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed");
                        int n = (Integer)yP_Row.getFieldValueByName("priority");
                        Boolean bl2 = (Boolean)yP_Row.getFieldValueByName("forcingAllowed");
                        int n2 = (Integer)yP_Row.getFieldValueByName("terminalApplicationVersionNumber");
                        tLVHandler.add(14672688, string);
                        tLVHandler.add(14672689, string2);
                        tLVHandler.add(14672685, String.format("%4s", Integer.toHexString(n2)).replace(' ', '0'));
                        String string3 = tLVHandler.toString();
                        tLVHandler.add(14672160, bl2);
                        tLVHandler.add(14672430, (long)n);
                        tLVHandler.add(14672175, bl);
                        String string4 = tLVHandler.toString();
                        boolean bl3 = false;
                        for (String string5 : parameterFile2.appTagsList) {
                            if (!string5.startsWith(string3)) continue;
                            if (!string5.contentEquals(string4)) {
                                yP_Transaction.logger(3, "dealEMV_ICC_AIDUpdate() Same AID differents values " + string5 + " vs " + string4);
                            }
                            bl3 = true;
                            break;
                        }
                        if (bl3) continue;
                        parameterFile2.appTagsList.add(string4);
                    }
                }
            }
            if (parameterFile2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                parameterFile2.headerParameterFile.checksum = "0";
            }
            list2.add(parameterFile2);
        }
    }

    public static void dealEMV_ICC_AID_ParametersUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l, long l2, long l3) {
        long l4 = (l + l2 + l3) % 0x100000000L;
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l4))) {
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l4);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                    if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                    YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getAIDParametersTable();
                    for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                        CharSequence charSequence;
                        String string;
                        String string2;
                        int n;
                        Object object;
                        Object object2;
                        List<Integer> list3;
                        int n2;
                        int n3;
                        long l5;
                        int n4;
                        String string3;
                        String string4;
                        String string5;
                        String string6;
                        String string7;
                        TLVHandler tLVHandler = new TLVHandler();
                        String string8 = yP_Row.getFieldStringValueByName("rid");
                        if (string8 == null || string8.isEmpty()) {
                            yP_Transaction.logger(2, "dealEMV_ICC_AID_ParametersUpdate() one empty line ???");
                            continue;
                        }
                        tLVHandler.add(14672688, string8);
                        String string9 = string8;
                        String string10 = yP_Row.getFieldStringValueByName("pix");
                        if (string10 != null && !string10.isEmpty()) {
                            tLVHandler.add(14672689, string10);
                            string9 = String.valueOf(string9) + string10;
                        }
                        String string11 = tLVHandler.toString();
                        TLVHandler tLVHandler2 = new TLVHandler();
                        String string12 = yP_Row.getFieldStringValueByName("tacDenial");
                        if (string12 != null && !string12.isEmpty()) {
                            tLVHandler2.add(14672675, string12);
                        }
                        if ((string7 = yP_Row.getFieldStringValueByName("tacOnline")) != null && !string7.isEmpty()) {
                            tLVHandler2.add(14672676, string7);
                        }
                        if ((string6 = yP_Row.getFieldStringValueByName("tacDefault")) != null && !string6.isEmpty()) {
                            tLVHandler2.add(14672677, string6);
                        }
                        if ((string5 = yP_Row.getFieldStringValueByName("defaultDDOL")) != null && !string5.isEmpty()) {
                            tLVHandler2.add(14672678, string5);
                        }
                        if ((string4 = yP_Row.getFieldStringValueByName("defaultPDOL")) != null && !string4.isEmpty()) {
                            tLVHandler2.add(14672679, string4);
                        }
                        if ((string3 = yP_Row.getFieldStringValueByName("defaultTDOL")) != null && !string3.isEmpty()) {
                            tLVHandler2.add(14672680, string3);
                        }
                        if ((n4 = ((Integer)yP_Row.getFieldValueByName("currencyNumericalCode")).intValue()) >= 0) {
                            tLVHandler2.add(14672425, (long)n4);
                        }
                        if ((l5 = ((Long)yP_Row.getFieldValueByName("thresholdCall")).longValue()) >= 0L) {
                            tLVHandler2.add(14672426, l5);
                        }
                        if ((n3 = ((Integer)yP_Row.getFieldValueByName("randomCallCoefficient")).intValue()) >= 0) {
                            tLVHandler2.add(14672427, (long)n3);
                        }
                        if ((n2 = ((Integer)yP_Row.getFieldValueByName("randomCallMaximumCoefficient")).intValue()) >= 0) {
                            tLVHandler2.add(14672428, (long)n2);
                        }
                        if ((list3 = yP_TCD_DCB_Interface_EMV.getTAVNList(string9)) != null && !list3.isEmpty()) {
                            object2 = new StringBuilder();
                            object = list3.iterator();
                            while (object.hasNext()) {
                                n = object.next();
                                string2 = Integer.toHexString(n);
                                if (string2.length() == 1) {
                                    ((StringBuilder)object2).append("000");
                                } else if (string2.length() == 2) {
                                    ((StringBuilder)object2).append("00");
                                } else if (string2.length() == 3) {
                                    ((StringBuilder)object2).append('0');
                                } else if (string2.length() != 4) {
                                    yP_Transaction.logger(2, "dealEMV_ICC_AID_ParametersUpdate() bad tavn:" + string2);
                                    continue;
                                }
                                ((StringBuilder)object2).append(string2);
                            }
                            tLVHandler2.add(14672685, ((StringBuilder)object2).toString());
                        }
                        if ((object2 = yP_TCD_DCB_Interface_EMV.getAIDData(string9)) != null) {
                            n = (Integer)((YP_Row)object2).getFieldValueByName("priority");
                            if (n == 254 || n == 255) {
                                tLVHandler2.add(14672223, (Boolean)true);
                            } else {
                                tLVHandler2.add(14672223, (Boolean)false);
                            }
                        } else {
                            tLVHandler2.add(14672223, (Boolean)false);
                        }
                        tLVHandler.add(-538738405, tLVHandler2);
                        TLVHandler tLVHandler3 = new TLVHandler();
                        object = yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode();
                        if (object != null && !((String)object).isEmpty()) {
                            tLVHandler3.addASCII("9F01", (String)object);
                        }
                        if ((string2 = yP_TCD_DCC_Business.getMerchantCategoryCode()) != null && !string2.isEmpty()) {
                            tLVHandler3.add("9F15", string2);
                        }
                        if ((string = yP_TCD_DCC_Business.getMerchantContract()) != null && !string.isEmpty()) {
                            charSequence = new StringBuilder(15);
                            ((StringBuilder)charSequence).append(string);
                            while (((StringBuilder)charSequence).length() < 15) {
                                ((StringBuilder)charSequence).append(' ');
                            }
                            tLVHandler3.addASCII("9F16", ((StringBuilder)charSequence).substring(0, 15));
                        }
                        charSequence = yP_TCD_DCC_Business.getCountryCode();
                        while (((String)charSequence).length() < 4) {
                            charSequence = String.valueOf('0') + (String)charSequence;
                        }
                        tLVHandler3.add(40730, (String)charSequence);
                        long l6 = 0L;
                        if (n4 != 0 && yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) {
                            int n5 = YP_TCD_DCC_Business.getTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction());
                            YP_TCD_DCC_Business.setTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction(), n4);
                            l6 = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).callParametersInterface.getMaxThresholdCall(yP_Transaction.getDataContainerTransaction());
                            YP_TCD_DCC_Business.setTransactionCurrencyNumerical(yP_Transaction.getDataContainerTransaction(), n5);
                            if (l6 < 0L) {
                                l6 = 0L;
                            }
                        }
                        tLVHandler3.add("9F1B", String.format("%8s", Long.toHexString(l6)).replace(' ', '0'));
                        tLVHandler3.addASCII(40732, yP_TCD_DCC_Business.getTerminalIdentification());
                        tLVHandler.add(-538738404, tLVHandler3);
                        String string13 = tLVHandler.toString();
                        boolean bl = false;
                        for (String string14 : parameterFile2.appTagsList) {
                            if (!string14.startsWith(string11)) continue;
                            if (!string14.contentEquals(string13)) {
                                yP_Transaction.logger(3, "dealEMV_ICC_AID_ParametersUpdate() Same AID differents values " + string14 + " vs " + string13);
                            }
                            bl = true;
                            break;
                        }
                        if (bl) continue;
                        parameterFile2.appTagsList.add(string13);
                    }
                }
            }
            if (parameterFile2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                parameterFile2.headerParameterFile.checksum = "0";
            }
            list2.add(parameterFile2);
        }
    }

    public static void dealForbiddenProducts(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            StringBuilder stringBuilder = new StringBuilder();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_ProductList yP_TCD_DCB_Interface_ProductList;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_ProductList = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null) continue;
                for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                    if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                    YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_ProductList.getProductListTable();
                    for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                        TLVHandler tLVHandler = new TLVHandler();
                        String string = yP_Row.getFieldStringValueByName("emvApplicationAID");
                        if (string == null || string.isEmpty()) {
                            yP_Transaction.logger(4, "dealForbiddenProducts() maybe a product indexed by BIN");
                            continue;
                        }
                        tLVHandler.add(-538738400, string);
                        String string2 = yP_Row.getFieldStringValueByName("electronicProductIdentification");
                        if (string2 == null || string2.isEmpty()) {
                            string2 = "0001";
                        }
                        tLVHandler.add(-538738370, string2);
                        String string3 = yP_Row.getFieldStringValueByName("codeProduit");
                        if (string3 == null || string3.isEmpty()) {
                            yP_Transaction.logger(3, "dealForbiddenProducts() product code missing!!!");
                            continue;
                        }
                        tLVHandler.add(-538738369, string3);
                        TLVHandler tLVHandler2 = new TLVHandler();
                        tLVHandler2.add(-2064064, tLVHandler);
                        stringBuilder.append(tLVHandler2.toString());
                    }
                    if (stringBuilder.length() <= 0) continue;
                    parameterFile2.appTagsList.add(stringBuilder.toString());
                }
            }
            if (parameterFile2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                parameterFile2.headerParameterFile.checksum = "0";
            }
            list2.add(parameterFile2);
        }
    }

    public static void dealCHQ_ParametersUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1")) continue;
                for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                    if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_CMC7)) continue;
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(-538738414, yP_TCD_DCC_Business.getMerchantName());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                }
            }
            if (parameterFile2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                parameterFile2.headerParameterFile.checksum = "0";
            }
            list2.add(parameterFile2);
        }
    }

    public static void dealCurrencyUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
            UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
            parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            parameterFile2.headerParameterFile.checksum = Long.toString(l);
            parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || !(yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business)) continue;
                List<String> list3 = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getListOfAuthorizedCurrency();
                for (String string : list3) {
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672715, string);
                    String string2 = tLVHandler.toString();
                    tLVHandler.add(14672425, (long)((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyNumericalCode(string));
                    tLVHandler.add(14672458, (long)((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyFraction(string));
                    String string3 = tLVHandler.toString();
                    boolean bl = false;
                    for (String string4 : parameterFile2.appTagsList) {
                        if (!string4.startsWith(string2)) continue;
                        if (!string4.contentEquals(string3)) {
                            yP_Transaction.logger(2, "dealCurrencyUpdate()  Same Currency differents values " + string4 + " vs " + string3);
                        }
                        bl = true;
                        break;
                    }
                    if (bl) continue;
                    parameterFile2.appTagsList.add(string3);
                }
            }
            if (parameterFile2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                parameterFile2.headerParameterFile.checksum = "0";
            }
            list2.add(parameterFile2);
        }
    }

    public static void dealPropertiesUpdate(YP_BT_WEB_Mobile yP_BT_WEB_Mobile, List<UpdateHandler.ParameterFile> list, UpdateHandler.ParameterFile parameterFile, List<Property> list2) {
        Object object;
        Object object2;
        List<Property> list3 = yP_BT_WEB_Mobile.getCliProperties();
        if (list3 != null) {
            list2.addAll(list3);
        }
        CRC32 cRC32 = new CRC32();
        for (Property property : list2) {
            object2 = property.getName().getBytes();
            cRC32.update((byte[])object2, 0, ((byte[])object2).length);
            object = property.getValue().getBytes();
            cRC32.update((byte[])object, 0, ((byte[])object).length);
        }
        long l = cRC32.getValue();
        if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
            object2 = new UpdateHandler.ParameterFile(yP_BT_WEB_Mobile.getDataContainerTransaction().updateHandler);
            object2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
            object2.headerParameterFile.checksum = Long.toString(l);
            object2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
            if (!list2.isEmpty()) {
                object = new TLVHandler();
                for (Property property : list2) {
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(-538738393, property.getName());
                    tLVHandler.addASCII(-538738392, property.getValue());
                    ((TLVHandler)object).add(-2064090, tLVHandler);
                }
                object2.appTagsList.add(((TLVHandler)object).toString());
            }
            if (object2.appTagsList.isEmpty()) {
                if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                    return;
                }
                object2.headerParameterFile.checksum = "0";
            }
            list.add((UpdateHandler.ParameterFile)object2);
        }
    }

    public static void dealEMV_NFC_KeyUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject;
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS) || (yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getKeysTable()) == null) continue;
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string;
                            TLVHandler tLVHandler = new TLVHandler();
                            String string2 = yP_Row.getFieldStringValueByName("rid");
                            int n = (Integer)yP_Row.getFieldValueByName("index");
                            int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                            String string3 = yP_Row.getFieldStringValueByName("keyValue");
                            tLVHandler.add(14672688, string2);
                            tLVHandler.add(14672434, (long)n);
                            String string4 = tLVHandler.toString();
                            tLVHandler.add(14672435, (long)n2);
                            tLVHandler.add(14672696, string3);
                            tLVHandler.add(14672692, "20130101");
                            tLVHandler.add(14672693, "20291231");
                            tLVHandler.add(14672694, "SHA-1");
                            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                            String string5 = Integer.toHexString(n);
                            if (string5.length() % 2 == 1) {
                                string5 = String.valueOf('0') + string5;
                            }
                            if ((string = Integer.toHexString(n2)).length() % 2 == 1) {
                                string = String.valueOf('0') + string;
                            }
                            String string6 = String.valueOf(string2) + string5 + string3 + string;
                            tLVHandler.add(14672695, UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string6))));
                            String string7 = tLVHandler.toString();
                            boolean bl = false;
                            for (String string8 : parameterFile2.appTagsList) {
                                if (!string8.startsWith(string4)) continue;
                                if (!string8.contentEquals(string7)) {
                                    yP_Transaction.logger(2, "dealEMV_NFC_KeyUpdate() Same key differents values " + string8 + " vs " + string7);
                                }
                                bl = true;
                                break;
                            }
                            if (bl) continue;
                            parameterFile2.appTagsList.add(string7);
                        }
                    }
                }
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = "0";
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_NFC_KeyUpdate()", exception);
        }
    }
}

