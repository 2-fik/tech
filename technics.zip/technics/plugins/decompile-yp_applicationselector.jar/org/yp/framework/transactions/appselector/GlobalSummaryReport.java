/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Process;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Technique;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;

class GlobalSummaryReport {
    GlobalSummaryReport() {
    }

    public static int doReport(YP_Transaction yP_Transaction) {
        List<YP_Row> list;
        YP_Object yP_Object;
        YP_TS_DataContainerManager yP_TS_DataContainerManager;
        block12: {
            YP_TCD_DCC_Technique yP_TCD_DCC_Technique;
            block11: {
                yP_Transaction.getDataContainerTransaction().contextHandler.setPositiveApplicationIdentifierList(null);
                yP_TS_DataContainerManager = (YP_TS_DataContainerManager)yP_Transaction.getPluginByName("DataContainerManager");
                yP_TCD_DCC_Technique = yP_TS_DataContainerManager.getDataContainerTechnique();
                yP_Object = yP_Transaction.getPluginByName("User");
                if (yP_Object != null) break block11;
                yP_Transaction.logger(3, "doReport() no plugin available");
                YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
                return -1;
            }
            list = GlobalSummaryReport.getRowListFromDAO(yP_Transaction, yP_TCD_DCC_Technique, "MgtParameters", "key", "mailGlobalReport");
            if (list != null && !list.isEmpty()) break block12;
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
            yP_Transaction.logger(4, "doReport() No subscriber");
            return 0;
        }
        try {
            YP_Process yP_Process = yP_Transaction.getProcessPluginByThreadID(Thread.currentThread().getId());
            for (YP_Row yP_Row : list) {
                long l;
                if (yP_Process != null) {
                    yP_Process.iAmAlive();
                }
                if ((l = ((Long)yP_Row.getFieldValueByName("idUser")).longValue()) <= 0L) {
                    yP_Transaction.logger(2, "doReport() bad idUser for" + yP_Row.getPrimaryKey());
                    continue;
                }
                YP_Row yP_Row2 = (YP_Row)yP_Object.dealRequest(yP_Transaction, "getUserRowByID", l);
                if (yP_Row2 == null) {
                    yP_Transaction.logger(2, "doReport() user not found :" + l);
                    continue;
                }
                String string = yP_Row2.getFieldStringValueByName("mail");
                if (string == null || string.isEmpty()) {
                    yP_Transaction.logger(2, "doReport() no mail for :" + l);
                    continue;
                }
                long l2 = (Long)yP_Row.getFieldValueByName("idMerchant");
                if (l2 <= 0L) {
                    yP_Transaction.logger(2, "doReport() no merchant for :" + l);
                    continue;
                }
                YP_TCD_DCC_Merchant yP_TCD_DCC_Merchant = (YP_TCD_DCC_Merchant)yP_TS_DataContainerManager.dealRequest(yP_Transaction, "getDataContainerMerchant", l2);
                if (yP_TCD_DCC_Merchant == null) {
                    yP_Transaction.logger(2, "doReport() no DC merchant found for :" + l + " " + l2);
                    continue;
                }
                yP_Transaction.setContractIdentifier(yP_TCD_DCC_Merchant.getContractIdentifier());
                String string2 = yP_Row.getFieldStringValueByName("value");
                yP_TCD_DCC_Merchant.doGlobalReport(yP_Transaction, string, string2);
            }
        }
        catch (Exception exception) {
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            yP_Transaction.logger(2, "doReport() ", exception);
            return -1;
        }
        YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        return 1;
    }

    private static List<YP_Row> getRowListFromDAO(YP_Transaction yP_Transaction, YP_TCD_DCC_Technique yP_TCD_DCC_Technique, String string, String string2, String string3) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCC_Technique.getDesignAccesObject_ByName(string);
        if (yP_TCD_DesignAccesObject == null) {
            return null;
        }
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set(string2, YP_ComplexGabarit.OPERATOR.EQUAL, string3);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        return list;
    }
}

