/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.crypto.soft.DUKPT;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;

public abstract class SPm2x {
    public static void dealSPm2x_TerminalConfig(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, YP_Row yP_Row, TLVHandler tLVHandler) {
        try {
            String string;
            if (list == null || list.isEmpty()) {
                yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() applicationDCCList is null or empty");
                return;
            }
            if (yP_Row == null) {
                yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() terminalRow is null");
                return;
            }
            String string2 = yP_Row.getFieldStringValueByName("kernelVersion");
            if (string2 == null) {
                yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() kernelVersion  is null");
                return;
            }
            if (string2.startsWith("t2.") || string2.startsWith("2.")) {
                string = "SPm2";
            } else if (string2.startsWith("t4.") || string2.startsWith("4.")) {
                string = "SPm20";
            } else {
                yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() unsupported terminal type");
                return;
            }
            String string3 = list.get(0).getParameter(String.valueOf(string) + "_TerminalConfigPath", true);
            if (string3 == null || string3.isEmpty()) {
                yP_Transaction.logger(4, "dealSPm2x_TerminalConfig() No TerminalConfigPath parameter found");
                return;
            }
            String string4 = new File(string3).getName();
            if (string4 == null || string4.isEmpty()) {
                yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() terminalConfigFilename is null or empty");
                return;
            }
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(string4)) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = string4;
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                String string5 = yP_Transaction.getFileContent(string3);
                if (string5 == null || string5.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() terminalConfig file not found or empty");
                    return;
                }
                TLV tLV = SPm2x.extractKSN(yP_Transaction, tLVHandler);
                if (tLV == null || tLV.value == null || tLV.value.length <= 0) {
                    yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() No KSN");
                    return;
                }
                YP_Object yP_Object = yP_Transaction.getPluginByName("CryptoManager");
                String string6 = (String)yP_Object.dealRequest(yP_Transaction, "sha256Hash", new Object[]{string5.getBytes("ISO-8859-1")});
                if (string6 == null || string6.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() pb during hash");
                    return;
                }
                String string7 = DUKPT.macResponseData(UtilsYP.devHexa(tLV.value), UtilsYP.redHexa(string6));
                if (string7 == null || string7.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_TerminalConfig() pb during mac");
                    return;
                }
                TLVHandler tLVHandler2 = new TLVHandler();
                tLVHandler2.addASCII(14672758, string7);
                tLVHandler2.addASCII(14672757, string5);
                tLVHandler2.add(14672506, (long)string5.length());
                parameterFile2.appTagsList.add(tLVHandler2.toString());
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealSPm2x_TerminalConfig()" + exception);
        }
    }

    public static void dealSPm2x_Currency(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, YP_Row yP_Row, TLVHandler tLVHandler) {
        try {
            String string;
            if (list == null || list.isEmpty()) {
                yP_Transaction.logger(2, "dealSPm2x_Currency() applicationDCCList is null or empty");
                return;
            }
            if (yP_Row == null) {
                yP_Transaction.logger(2, "dealSPm2x_Currency() terminalRow is null");
                return;
            }
            String string2 = yP_Row.getFieldStringValueByName("kernelVersion");
            if (string2 == null) {
                yP_Transaction.logger(2, "dealSPm2x_Currency() kernelVersion  is null");
                return;
            }
            if (string2.startsWith("t2.") || string2.startsWith("2.")) {
                string = "SPm2";
            } else if (string2.startsWith("t4.") || string2.startsWith("4.")) {
                string = "SPm20";
            } else {
                yP_Transaction.logger(2, "dealSPm2x_Currency() unsupported terminal type");
                return;
            }
            String string3 = list.get(0).getParameter(String.valueOf(string) + "_CurrencyFapiPath", true);
            if (string3 == null || string3.isEmpty()) {
                yP_Transaction.logger(4, "dealSPm2x_Currency() No currencyFapiPath parameter found");
                return;
            }
            String string4 = new File(string3).getName();
            if (string4 == null || string4.isEmpty()) {
                yP_Transaction.logger(2, "dealSPm2x_Currency() currencyFapiFilename is null or empty");
                return;
            }
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(string4)) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = string4;
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                String string5 = yP_Transaction.getFileContent(string3);
                if (string5 == null || string5.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_Currency() currencyFile file not found or empty");
                    return;
                }
                TLV tLV = SPm2x.extractKSN(yP_Transaction, tLVHandler);
                if (tLV == null || tLV.value == null || tLV.value.length <= 0) {
                    yP_Transaction.logger(2, "dealSPm2x_Currency() No KSN");
                    return;
                }
                YP_Object yP_Object = yP_Transaction.getPluginByName("CryptoManager");
                String string6 = (String)yP_Object.dealRequest(yP_Transaction, "sha256Hash", new Object[]{string5.getBytes("ISO-8859-1")});
                if (string6 == null || string6.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_Currency() pb during hash");
                    return;
                }
                String string7 = DUKPT.macResponseData(UtilsYP.devHexa(tLV.value), UtilsYP.redHexa(string6));
                if (string7 == null || string7.isEmpty()) {
                    yP_Transaction.logger(2, "dealSPm2x_Currency() pb during mac");
                    return;
                }
                TLVHandler tLVHandler2 = new TLVHandler();
                tLVHandler2.addASCII(14672758, string7);
                tLVHandler2.addASCII(14672757, string5);
                tLVHandler2.add(14672506, (long)string5.length());
                parameterFile2.appTagsList.add(tLVHandler2.toString());
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealSPm2x_Currency()" + exception);
        }
    }

    public static TLV extractKSN(YP_Transaction yP_Transaction, TLVHandler tLVHandler) {
        block10: {
            TLV tLV;
            try {
                tLV = tLVHandler.getTLV(14672737);
                if (tLV != null) {
                    return tLV;
                }
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "extractKSN() " + exception);
            }
            try {
                TLVHandler tLVHandler2;
                TLV tLV2;
                TLV tLV3;
                TLVHandler tLVHandler3;
                tLV = tLVHandler.getTLV(16769880);
                if (tLV == null || (tLVHandler3 = new TLVHandler(tLV.value)) == null || (tLV3 = tLVHandler3.getTLV(16769874)) == null || (tLV2 = (tLVHandler2 = new TLVHandler(tLV3.value)).getTLV(14672720)) == null || tLV2.value == null || tLV2.value.length <= 22) break block10;
                int n = 0;
                while (n < tLV2.value.length) {
                    if (tLV2.value[n] == 28) {
                        int n2 = ++n;
                        while (n2 < tLV2.value.length) {
                            if (tLV2.value[n2] == 28) {
                                if (n2 - n == 20) {
                                    yP_Transaction.logger(3, "extractKSN() KSN is extracted ");
                                    return new TLV(14672737, 10, UtilsYP.redHexa(Arrays.copyOfRange(tLV2.value, n, n2)));
                                }
                                break block10;
                            }
                            ++n2;
                        }
                        break;
                    }
                    ++n;
                }
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "extractKSN() " + exception);
            }
        }
        return null;
    }
}

