/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_SQL_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Brand;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Context;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.ExtendedResult;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class RefundHandler {
    private static final String MGT_PARAM_MANUAL_REFUND_MERCHANT = "manualRefundMerchant";

    /*
     * Enabled aggressive exception aggregation
     */
    public static int performChecks(YP_Transaction yP_Transaction, TLVHandler tLVHandler, List<YP_TCD_DCC_Business> list) {
        long l;
        String string;
        String string2;
        String string3;
        Object object;
        Object object2;
        Object object3;
        try {
            if (yP_Transaction.getDataContainerTransaction().getSubRequestType() != null && yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.None) {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() subrequest inside");
                }
                return 0;
            }
            object3 = yP_Transaction.getDataContainerTransaction().commonHandler.getPaymentTechnology();
            if (object3 != null && object3 != EntryModeEnumeration.UNKNOWN) {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() entry mode provided");
                }
                return 0;
            }
            object2 = YP_TCD_DCC_Business.getMerchantTransactionIdentifier(yP_Transaction.getDataContainerTransaction());
            object = YP_TCD_DCC_Business.getReferenceMerchantTransactionIdentifier(yP_Transaction.getDataContainerTransaction());
            if ((object2 == null || ((String)object2).isEmpty()) && (object == null || ((String)object).isEmpty())) {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() no merchant transaction identifiers");
                }
                return 0;
            }
            if (object == null || ((String)object).isEmpty()) {
                string3 = null;
                string2 = object2;
            } else {
                string3 = object;
                string2 = object2;
            }
            if (tLVHandler == null) {
                string = "";
            } else {
                TLV tLV = tLVHandler.getTLV(-538738381);
                if (tLV == null) {
                    if (yP_Transaction.getLogLevel() >= 6) {
                        yP_Transaction.logger(6, "performChecks() no TLV MERCHANT_PRIVATE_DATA");
                    }
                    string = "";
                } else {
                    string = new String(tLV.value);
                    if (string.isEmpty() && yP_Transaction.getLogLevel() >= 6) {
                        yP_Transaction.logger(6, "performChecks() merchantPrivateData is empty");
                    }
                }
            }
            l = yP_Transaction.getDataContainerTransaction().commonHandler.getTransactionAmount();
            if (l <= 0L) {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() no amount");
                }
                return 0;
            }
            if (tLVHandler != null) {
                TLV tLV = tLVHandler.getTLV(-538803956);
                if (tLV != null) {
                    if (yP_Transaction.getLogLevel() >= 6) {
                        yP_Transaction.logger(6, "performChecks() token provided");
                    }
                    return 0;
                }
                TLV tLV2 = tLVHandler.getTLV(16769892);
                if (tLV2 != null) {
                    if (yP_Transaction.getLogLevel() >= 6) {
                        yP_Transaction.logger(6, "performChecks() track2 provided");
                    }
                    return 0;
                }
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            yP_Transaction.logger(2, "performChecks() ", exception);
            return 0;
        }
        try {
            List<YP_Row> list2;
            YP_ComplexGabarit yP_ComplexGabarit;
            Object object4;
            long l2;
            YP_Row yP_Row;
            long l3;
            List<YP_Row> list3;
            yP_Transaction.logger(4, "performChecks() refund with data wanted");
            object3 = new ArrayList();
            object2 = null;
            if (list.size() > 1 && yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers != null && !yP_Transaction.getDataContainerTransaction().contextHandler.brandContainers.isEmpty() && UtilsYP.getTableStructureMode() == 1 && !yP_Transaction.getDataContainerTransaction().getContractIdentifier().contains("_")) {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() ONE_SCHEMA_BY_APPLICATION mode");
                }
                object = null;
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    if (yP_TCD_DCC_Business.transaction == null) continue;
                    object = yP_TCD_DCC_Business.transaction;
                    break;
                }
                YP_ComplexGabarit yP_ComplexGabarit2 = RefundHandler.getDebitGabarit((YP_TCD_DesignAccesObject)object, string3, string);
                yP_ComplexGabarit2.set("contractKey", YP_ComplexGabarit.OPERATOR.DIFFERENT, 0L);
                block8: for (YP_TCD_DCC_Brand yP_TCD_DCC_Brand : yP_Transaction.getBrandList()) {
                    list3 = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DCC_Brand, 0, 10, yP_ComplexGabarit2);
                    if (list3 == null) {
                        yP_Transaction.logger(2, "performChecks() unable to retrieve list !!!");
                        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                        return -1;
                    }
                    if (list3.isEmpty()) continue;
                    object3.addAll(list3);
                    long l4 = ((YP_Row)object3.get((int)0)).contractKey;
                    for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                        if (yP_TCD_DCC_Business.getIDContract() != l4) continue;
                        object2 = yP_TCD_DCC_Business;
                        continue block8;
                    }
                }
            } else {
                if (yP_Transaction.getLogLevel() >= 6) {
                    yP_Transaction.logger(6, "performChecks() old mode");
                }
                int n = 0;
                while (n < list.size()) {
                    YP_ComplexGabarit yP_ComplexGabarit3;
                    List<YP_Row> list4;
                    object2 = list.get(n);
                    if (((YP_TCD_DCC_Business)object2).transaction != null && (list4 = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(((YP_TCD_DCC_Business)object2).transaction, ((YP_TCD_DCC_Business)object2).transactionArchive, 0, 1, yP_ComplexGabarit3 = RefundHandler.getDebitGabarit(((YP_TCD_DCC_Business)object2).transaction, string3, string))) != null && !list4.isEmpty()) {
                        object3.addAll(list4);
                        break;
                    }
                    ++n;
                }
            }
            if (object3.isEmpty()) {
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(109));
                yP_Transaction.logger(4, "performChecks() nothing found");
                return -1;
            }
            if (object3.size() > 1) {
                yP_Transaction.logger(2, "performChecks() too many found for " + string);
            }
            if ((l3 = ((Long)(yP_Row = (YP_Row)object3.get(0)).getFieldValueByName("idToken")).longValue()) <= 0L) {
                yP_Transaction.logger(2, "performChecks() idToken should be set !!!");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            Object object5 = Long.toHexString(l3);
            if (((String)object5).length() % 2 != 0) {
                object5 = "0" + (String)object5;
            }
            if (tLVHandler == null) {
                tLVHandler = new TLVHandler();
                tLVHandler.add(-538803956, (String)object5);
                yP_Transaction.getDataContainerTransaction().commonHandler.setRequestAppTags(tLVHandler.toString());
            } else {
                tLVHandler.add(-538803956, (String)object5);
            }
            list3 = (String)yP_Transaction.getPluginByName("TokenManager").dealRequest(yP_Transaction, "getClearValue", l3);
            if (list3 == null) {
                yP_Transaction.logger(2, "performChecks() unable to get PAN");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(13));
                return -1;
            }
            yP_Transaction.getDataContainerTransaction().accountHandler.setAccountIdentifier((String)((Object)list3));
            yP_Transaction.getDataContainerTransaction().accountHandler.setMaskedAccountIdentifier(UtilsYP.maskPAN((String)((Object)list3)));
            YP_TCD_DCC_Business.setIDToken(yP_Transaction.getDataContainerTransaction(), l3);
            Timestamp timestamp = (Timestamp)yP_Row.getFieldValueByName("accountExpirationDate");
            if (timestamp != null && timestamp.getTime() != 0L) {
                yP_Transaction.getDataContainerTransaction().accountHandler.setAccountExpirationDate(timestamp);
            }
            if ((l2 = ((Long)yP_Row.getFieldValueByName("transactionAmount")).longValue()) < l) {
                yP_Transaction.logger(2, "performChecks() refund must be lower than the initial debit");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(25));
                return -1;
            }
            String string4 = yP_Transaction.getDataContainerTransaction().commonHandler.getTransactionCurrencyAlpha();
            String string5 = yP_Row.getFieldStringValueByName("transactionCurrencyAlpha");
            if (string4 == null || string4.isEmpty()) {
                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionCurrencyAlpha(string5);
            } else if (!string4.contentEquals(string5)) {
                yP_Transaction.logger(2, "performChecks() bad currency alpha");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            int n = yP_Transaction.getDataContainerTransaction().commonHandler.getTransactionCurrencyNumerical();
            int n2 = (Integer)yP_Row.getFieldValueByName("transactionCurrencyNumerical");
            if (n == 0) {
                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionCurrencyNumerical(n2);
            } else if (n != n2) {
                yP_Transaction.logger(2, "performChecks() bad currency numerical");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            int n3 = yP_Transaction.getDataContainerTransaction().commonHandler.getTransactionAmountFraction();
            int n4 = (Integer)yP_Row.getFieldValueByName("transactionAmountFraction");
            if (n3 == 0) {
                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionAmountFraction(n4);
            } else if (n3 != n4) {
                yP_Transaction.logger(2, "performChecks() bad currency fraction");
                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(7));
                return -1;
            }
            YP_TCD_DCC_Business.setPaymentTechnology(yP_Transaction.getDataContainerTransaction(), EntryModeEnumeration.ENTRY_MODE_MANUAL);
            list.clear();
            Object object6 = ((YP_TCD_DCC_Business)object2).getDataContainerMerchant().dataContainerBusinessList.iterator();
            block11: while (object6.hasNext()) {
                object4 = object6.next();
                if (!((YP_TCD_DCC_Business)object4).getActivationCode().contentEquals("1")) continue;
                block12: for (YP_App_Interface_Selection yP_App_Interface_Selection : ((YP_TCD_DCC_Business)object4).selectorList) {
                    if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_MANUAL)) continue;
                    AcceptationLevelEnumeration acceptationLevelEnumeration = yP_App_Interface_Selection.getAcceptationLevel(yP_Transaction.getDataContainerTransaction());
                    switch (acceptationLevelEnumeration) {
                        case ACCEPTED: 
                        case WATCHED: {
                            break;
                        }
                        default: {
                            continue block12;
                        }
                    }
                    if (string2 != null && !string2.isEmpty() || string != null && !string.isEmpty()) {
                        yP_ComplexGabarit = new YP_ComplexGabarit(((YP_TCD_DCC_Business)object4).transaction);
                        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.CREDIT, TransactionTypeEnumeration.REFUND_QUASI_CASH});
                        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
                        yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                        yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        if (string2 != null) {
                            yP_ComplexGabarit.set("merchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                        }
                        if ((list2 = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(((YP_TCD_DCC_Business)object4).transaction, ((YP_TCD_DCC_Business)object4).transactionArchive, yP_ComplexGabarit)) != null && !list2.isEmpty()) {
                            yP_Transaction.logger(2, "performChecks() one refund with same data found");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                            return -1;
                        }
                    }
                    if (string3 != null && !string3.isEmpty() || string != null && !string.isEmpty()) {
                        long l5;
                        yP_ComplexGabarit = new YP_ComplexGabarit(((YP_TCD_DCC_Business)object4).transaction);
                        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, TransactionTypeEnumeration.CREDIT);
                        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
                        yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                        yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                        if (string3 != null) {
                            yP_ComplexGabarit.set("referenceMerchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                        }
                        if (l2 < l + (l5 = ((YP_TCD_DCC_Business)object4).transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit))) {
                            yP_Transaction.logger(2, "performChecks() sum of refund must be lower than the initial debit");
                            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(25));
                            return -1;
                        }
                    }
                    list.add((YP_TCD_DCC_Business)object4);
                    continue block11;
                }
            }
            if (!list.isEmpty()) {
                return 1;
            }
            object4 = ((YP_TCD_DC_Context)object2).getParameter(MGT_PARAM_MANUAL_REFUND_MERCHANT, true);
            if (object4 != null && !((String)object4).isEmpty() && (object6 = (YP_TCD_DCC_Merchant)((YP_TS_DataContainerManager)yP_Transaction.getPluginByName("DataContainerManager")).dealRequest(yP_Transaction, "getDataContainerMerchant", Long.parseLong((String)object4))) != null) {
                block13: for (YP_TCD_DCC_Business yP_TCD_DCC_Business : ((YP_TCD_DCC_Merchant)object6).dataContainerBusinessList) {
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1")) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_MANUAL)) continue;
                        if (string2 != null && !string2.isEmpty() || string != null && !string.isEmpty()) {
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
                            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.CREDIT, TransactionTypeEnumeration.REFUND_QUASI_CASH});
                            yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
                            yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                            yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                            if (string2 != null) {
                                yP_ComplexGabarit.set("merchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
                            }
                            if ((list2 = YP_TCD_DAO_SQL_Transaction.getRowListSuchAsForTransaction(yP_TCD_DCC_Business.transaction, yP_TCD_DCC_Business.transactionArchive, yP_ComplexGabarit)) != null && !list2.isEmpty()) {
                                yP_Transaction.logger(2, "performChecks() one refund with same data found");
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(101));
                                return -1;
                            }
                        }
                        if (string3 != null && !string3.isEmpty() || string != null && !string.isEmpty()) {
                            long l6;
                            yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
                            yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, TransactionTypeEnumeration.CREDIT);
                            yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
                            yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                            yP_ComplexGabarit.set("idToken", YP_ComplexGabarit.OPERATOR.EQUAL, l3);
                            if (string3 != null) {
                                yP_ComplexGabarit.set("referenceMerchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                            }
                            if (l2 < l + (l6 = yP_TCD_DCC_Business.transaction.getSumSuchAs("transactionAmount", yP_ComplexGabarit))) {
                                yP_Transaction.logger(2, "performChecks() sum of refund must be lower than the initial debit");
                                YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(25));
                                return -1;
                            }
                        }
                        list.add(yP_TCD_DCC_Business);
                        continue block13;
                    }
                }
            }
            if (!list.isEmpty()) {
                return 1;
            }
            YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(103));
            return -1;
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "performChecks() ", exception);
            return -1;
        }
    }

    private static YP_ComplexGabarit getDebitGabarit(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string, String string2) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        yP_ComplexGabarit.set("transactionType", YP_ComplexGabarit.OPERATOR.IN, new Object[]{TransactionTypeEnumeration.DEBIT, TransactionTypeEnumeration.DEBIT_DIFFERED, TransactionTypeEnumeration.QUASI_CASH});
        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
        if (string != null) {
            yP_ComplexGabarit.set("merchantTransactionIdentifier", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        }
        yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("transactionSystemGMTTimeMS", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        return yP_ComplexGabarit;
    }
}

