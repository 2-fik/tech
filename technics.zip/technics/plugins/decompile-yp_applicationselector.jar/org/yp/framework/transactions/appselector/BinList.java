/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.bin.YP_TCD_DCB_Interface_BIN;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TreatmentCodeEnumeration;

public abstract class BinList {
    public static void dealBinListUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                SelectorList selectorList = new SelectorList();
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    Object object;
                    if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (object = (YP_TCD_DCB_Interface_BIN)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_BIN.class)) == null || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    boolean bl = false;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business.selectorList) {
                        List<YP_Row> list3;
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC) && !yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class);
                        if (yP_TCD_DCB_Interface_CTCL != null) {
                            list3 = yP_TCD_DCB_Interface_CTCL.getAIDKIDList();
                            for (YP_Row yP_Row : list3) {
                                String string = yP_Row.getFieldStringValueByName("applicationIdentifier");
                                if (string == null || !string.startsWith("A0000000041010")) continue;
                                bl = true;
                                break;
                            }
                        }
                        if ((list3 = yP_TCD_DCB_Interface_EMV.getAIDList("A0000000041010")) == null || list3.isEmpty()) continue;
                        bl = true;
                        break;
                    }
                    if (!bl) continue;
                    BinList.addOneBinTable(yP_Transaction, selectorList, object.getBINTable());
                }
                StringBuilder stringBuilder = new StringBuilder();
                for (SelectorEnreg selectorEnreg : selectorList.list) {
                    if (selectorEnreg.level != AcceptationLevelEnumeration.ACCEPTED) continue;
                    BinList.addHexPan(yP_Transaction, stringBuilder, selectorEnreg.start);
                    BinList.addHexPan(yP_Transaction, stringBuilder, selectorEnreg.end);
                    if (selectorEnreg.treatmentCode == TreatmentCodeEnumeration.ICC_TEST_SC12569 || selectorEnreg.treatmentCode == TreatmentCodeEnumeration.ISO_TEST_SC12569) {
                        stringBuilder.append("03");
                    } else {
                        stringBuilder.append("01");
                    }
                    stringBuilder.append("00");
                }
                TLVHandler tLVHandler = new TLVHandler();
                tLVHandler.add(-538738338, stringBuilder.toString());
                parameterFile2.appTagsList.add(tLVHandler.toString());
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealBlackListUpdate() getBlackList() ", exception);
            return;
        }
    }

    private static void addHexPan(YP_Transaction yP_Transaction, StringBuilder stringBuilder, BigInteger bigInteger) {
        String string = Long.toHexString(bigInteger.longValue());
        if (string == null || string.isEmpty()) {
            yP_Transaction.logger(2, "addOnePAN() no hexPan for :" + bigInteger);
            stringBuilder.append("0000000000000000");
            return;
        }
        if (string.length() > 16) {
            yP_Transaction.logger(2, "addOnePAN() hexPan too long for:" + bigInteger + ":" + string);
            stringBuilder.append("0000000000000000");
            return;
        }
        int n = 16 - string.length();
        int n2 = 0;
        while (n2 < n) {
            stringBuilder.append('0');
            ++n2;
        }
        stringBuilder.append(string);
    }

    private static int addOneBinTable(YP_Transaction yP_Transaction, SelectorList selectorList, YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject) {
        try {
            for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                AcceptationLevelEnumeration acceptationLevelEnumeration = (AcceptationLevelEnumeration)((Object)yP_Row.getFieldValueByName("level"));
                TreatmentCodeEnumeration treatmentCodeEnumeration = (TreatmentCodeEnumeration)((Object)yP_Row.getFieldValueByName("treatmentCode"));
                String string = yP_Row.getFieldStringValueByName("start");
                String string2 = yP_Row.getFieldStringValueByName("end");
                if (string.indexOf(32) >= 0 || string.length() != 19 || string2.indexOf(32) >= 0 || string2.length() != 19) continue;
                BigInteger bigInteger = new BigInteger(string);
                BigInteger bigInteger2 = new BigInteger(string2);
                SelectorEnreg selectorEnreg = new SelectorEnreg(bigInteger, bigInteger2, acceptationLevelEnumeration, treatmentCodeEnumeration);
                if (selectorList.list.isEmpty()) {
                    selectorList.list.add(selectorEnreg);
                    continue;
                }
                BinList.insertselectionRowInBinList(selectorList.list, selectorEnreg, bigInteger2.subtract(bigInteger));
            }
            return 1;
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "addOneBinTable() :", exception);
            return -1;
        }
    }

    private static int search(List<SelectorEnreg> list, BigInteger bigInteger) {
        int n = 0;
        int n2 = list.size();
        int n3 = 0;
        while (n < n2) {
            n3 = (n + n2) / 2;
            SelectorEnreg selectorEnreg = list.get(n3);
            int n4 = bigInteger.compareTo(selectorEnreg.start);
            if (n4 < 0) {
                n2 = n3;
                continue;
            }
            if (n4 > 0) {
                if (selectorEnreg.end.compareTo(bigInteger) >= 0) {
                    return n3;
                }
                n = n3 + 1;
                continue;
            }
            return n3;
        }
        return -(n + 1);
    }

    private static int insertselectionRowInBinList(List<SelectorEnreg> list, SelectorEnreg selectorEnreg, BigInteger bigInteger) {
        int n = BinList.search(list, selectorEnreg.start);
        if (n < 0) {
            BigInteger bigInteger2;
            int n2 = BinList.search(list, selectorEnreg.end);
            if (n == n2) {
                list.add(-n - 1, selectorEnreg);
                return 1;
            }
            SelectorEnreg selectorEnreg2 = new SelectorEnreg(selectorEnreg.start, selectorEnreg.end, selectorEnreg.level, selectorEnreg.treatmentCode);
            selectorEnreg.start = bigInteger2 = list.get((int)(-n - 1)).start;
            selectorEnreg2.end = bigInteger2.subtract(UtilsYP.big1);
            list.add(-n - 1, selectorEnreg2);
            return BinList.insertselectionRowInBinList(list, selectorEnreg, bigInteger);
        }
        SelectorEnreg selectorEnreg3 = list.get(n);
        BigInteger bigInteger3 = selectorEnreg3.end.subtract(selectorEnreg3.start);
        if (bigInteger.compareTo(bigInteger3) >= 0) {
            if (selectorEnreg3.end.compareTo(selectorEnreg.end) >= 0) {
                return 1;
            }
            selectorEnreg.start = selectorEnreg3.end.add(UtilsYP.big1);
            return BinList.insertselectionRowInBinList(list, selectorEnreg, bigInteger);
        }
        if (selectorEnreg3.start.compareTo(selectorEnreg.start) == 0) {
            if (selectorEnreg3.end.compareTo(selectorEnreg.end) <= 0) {
                selectorEnreg3.start = selectorEnreg.start;
                selectorEnreg3.level = selectorEnreg.level;
                selectorEnreg.start = selectorEnreg3.end.add(UtilsYP.big1);
                return BinList.insertselectionRowInBinList(list, selectorEnreg, bigInteger);
            }
            selectorEnreg3.start = selectorEnreg.end.add(UtilsYP.big1);
            list.add(n, selectorEnreg);
            return 1;
        }
        if (selectorEnreg3.end.compareTo(selectorEnreg.end) <= 0) {
            selectorEnreg3.end = selectorEnreg.start.subtract(UtilsYP.big1);
            return BinList.insertselectionRowInBinList(list, selectorEnreg, bigInteger);
        }
        SelectorEnreg selectorEnreg4 = new SelectorEnreg(selectorEnreg.end.add(UtilsYP.big1), selectorEnreg3.end, selectorEnreg3.level, selectorEnreg3.treatmentCode);
        list.add(n + 1, selectorEnreg4);
        selectorEnreg3.end = selectorEnreg.start.subtract(UtilsYP.big1);
        return BinList.insertselectionRowInBinList(list, selectorEnreg, bigInteger);
    }

    static class SelectorEnreg {
        BigInteger start;
        BigInteger end;
        AcceptationLevelEnumeration level;
        TreatmentCodeEnumeration treatmentCode;

        SelectorEnreg(BigInteger bigInteger, BigInteger bigInteger2, AcceptationLevelEnumeration acceptationLevelEnumeration, TreatmentCodeEnumeration treatmentCodeEnumeration) {
            this.start = bigInteger;
            this.end = bigInteger2;
            this.level = acceptationLevelEnumeration;
            this.treatmentCode = treatmentCodeEnumeration;
        }
    }

    static class SelectorList {
        List<SelectorEnreg> list = new ArrayList<SelectorEnreg>();

        SelectorList() {
        }
    }
}

