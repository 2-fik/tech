/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.utils.ExtendedResult;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.enums.ExtendedTVREnumeration;
import org.yp.utils.enums.TransactionStatusEnumeration;

public class DuplicatedHandler {
    public static int performChecks(YP_Transaction yP_Transaction, TLVHandler tLVHandler) {
        block13: {
            if (yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransaction && yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.OpenTransactionAndTRM && yP_Transaction.getDataContainerTransaction().getSubRequestType() != YP_TCD_PosProtocol.SUB_REQUEST_TYPE.ProcessNFC) {
                return 0;
            }
            if (tLVHandler == null) {
                return 0;
            }
            if (!yP_Transaction.getDataContainerTransaction().getExtendedTVR().isSet(ExtendedTVREnumeration.SUSPECTED_DUPLICATE)) {
                return 0;
            }
            yP_Transaction.logger(3, "performChecks() It's a suspected duplicated trs");
            TLV tLV = null;
            try {
                tLV = tLVHandler.getTLV(-538738381);
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "performChecks() ", exception);
            }
            if (tLV == null) {
                yP_Transaction.logger(2, "performChecks() MERCHANT_PRIVATE_DATA is mandatory for duplicated trs");
                return 0;
            }
            String string = new String(tLV.value);
            if (string.isEmpty()) {
                yP_Transaction.logger(2, "performChecks() MERCHANT_PRIVATE_DATA must not be empty for duplicated trs");
                return 0;
            }
            List<YP_TCD_DCC_Business> list = yP_Transaction.getApplicationList();
            try {
                ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
                YP_TCD_DCC_Business yP_TCD_DCC_Business = null;
                int n = 0;
                while (n < list.size()) {
                    yP_TCD_DCC_Business = list.get(n);
                    if (yP_TCD_DCC_Business.transaction != null) {
                        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DCC_Business.transaction);
                        yP_ComplexGabarit.set("transactionStatus", YP_ComplexGabarit.OPERATOR.EQUAL, TransactionStatusEnumeration.ACCEPTED);
                        yP_ComplexGabarit.set("merchantPrivateData", YP_ComplexGabarit.OPERATOR.EQUAL, string);
                        List<YP_Row> list2 = yP_TCD_DCC_Business.transaction.getRowListSuchAs(0, 1, yP_ComplexGabarit);
                        if (list2 != null && !list2.isEmpty()) {
                            arrayList.addAll(list2);
                            break;
                        }
                    }
                    ++n;
                }
                if (!arrayList.isEmpty()) break block13;
                yP_Transaction.logger(4, "performChecks() nothing found");
                return 0;
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "performChecks() ", exception);
                return -1;
            }
        }
        yP_Transaction.getDataContainerTransaction().getExtendedTVR().add(ExtendedTVREnumeration.DUPLICATE_TRS);
        YP_TCD_DCC_Business.setExtendedResult(yP_Transaction.getDataContainerTransaction(), new ExtendedResult(42));
        return 1;
    }
}

