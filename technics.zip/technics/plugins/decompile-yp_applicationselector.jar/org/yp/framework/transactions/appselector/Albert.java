/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.callparameters.YP_TCD_DCB_Interface_CallParameters;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.emv.YP_TCD_DCB_Interface_EMV;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.utils.EMV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class Albert {
    private static final String defaultAdditionalTerminalCapabilities = "600080A001";
    private static final String defaultUDOL = "9F6A04";
    private static final byte[] terminalCapabilitiesMCMagstripe;
    private static final byte[] terminalCapabilitiesMC;
    private static final byte[] terminalCapabilitiesNoCVMMC;
    private static final byte[] terminalCapabilitiesVISA;
    private static final byte[] terminalCapabilitiesNoCVMVISA;
    private static final byte[] defaultTerminalCapabilities;
    private static final byte[] defaultTerminalCapabilitiesNoCVM;
    private static final byte[] terminalCapabilitiesAMEX;
    private static final String defaultVISATTQ = "32204000";
    private static final String defaultVISARefundTTQ = "22800000";

    static {
        byte[] byArray = new byte[3];
        byArray[0] = 96;
        byArray[1] = 32;
        terminalCapabilitiesMCMagstripe = byArray;
        terminalCapabilitiesMC = new byte[]{96, 32, 8};
        terminalCapabilitiesNoCVMMC = new byte[]{96, 8, 8};
        terminalCapabilitiesVISA = new byte[]{96, 32, 64};
        terminalCapabilitiesNoCVMVISA = new byte[]{96, 40, 64};
        defaultTerminalCapabilities = new byte[]{96, 32, 72};
        defaultTerminalCapabilitiesNoCVM = new byte[]{96, 40, 72};
        terminalCapabilitiesAMEX = new byte[]{96, -88, -56};
    }

    public static void dealEMV_ICC_NFC_KeyUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                HashMap<String, String> hashMap = new HashMap<String, String>();
                StringBuilder stringBuilder = new StringBuilder();
                for (YP_TCD_DCC_Business object : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!object.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)object.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC) && !yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getKeysTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string;
                            String string2 = yP_Row.getFieldStringValueByName("rid");
                            int n = (Integer)yP_Row.getFieldValueByName("index");
                            int n2 = (Integer)yP_Row.getFieldValueByName("exponent");
                            String string3 = yP_Row.getFieldStringValueByName("keyValue");
                            String string4 = Integer.toHexString(n);
                            if (string4.length() % 2 == 1) {
                                string4 = String.valueOf('0') + string4;
                            }
                            if ((string = Integer.toHexString(n2)).length() % 2 == 1) {
                                string = String.valueOf('0') + string;
                            }
                            String string5 = String.valueOf(string2) + string4 + string3 + string;
                            MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                            String string6 = UtilsYP.devHexa(messageDigest.digest(UtilsYP.redHexa(string5)));
                            String string7 = String.valueOf(string2) + "_" + string4;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            Albert.add(stringBuilder2, "expirationDate", "291231");
                            Albert.add(stringBuilder2, "hash", string6);
                            while (string.length() < 6) {
                                string = String.valueOf('0') + string;
                            }
                            Albert.add(stringBuilder2, "exponent", string);
                            Albert.add(stringBuilder2, "index", string4);
                            Albert.add(stringBuilder2, "key", string3);
                            Albert.add(stringBuilder2, "rid", string2);
                            boolean bl = false;
                            String string8 = (String)hashMap.get(string7);
                            if (string8 != null) {
                                if (!string8.contentEquals(stringBuilder2)) {
                                    yP_Transaction.logger(2, "dealEMV_ICC_NFC_KeyUpdate() Same key differents values " + string8 + " vs " + stringBuilder2);
                                }
                                bl = true;
                            }
                            if (bl) continue;
                            hashMap.put(string7, stringBuilder2.toString());
                            if (stringBuilder.length() == 0) {
                                stringBuilder.append("[");
                            } else {
                                stringBuilder.append(",");
                            }
                            stringBuilder.append("\r\n{\r\n");
                            stringBuilder.append(stringBuilder2.toString());
                            stringBuilder.append("\r\n}");
                        }
                    }
                }
                if (stringBuilder.length() > 0) {
                    stringBuilder.append("\r\n]");
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, stringBuilder.toString());
                    tLVHandler.add(14672506, (long)stringBuilder.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                    list2.add(parameterFile2);
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_NFC_KeyUpdate()" + exception);
        }
    }

    private static void add(StringBuilder stringBuilder, String string, String string2) {
        if (stringBuilder.length() > 0) {
            stringBuilder.append(",\r\n");
        }
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\": \"");
        stringBuilder.append(string2);
        stringBuilder.append("\"");
    }

    private static void add(StringBuilder stringBuilder, String string, int n) {
        if (stringBuilder.length() > 0) {
            stringBuilder.append(",\r\n");
        }
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\": ");
        stringBuilder.append(n);
    }

    private static void add(StringBuilder stringBuilder, String string, long l) {
        if (stringBuilder.length() > 0) {
            stringBuilder.append(",\r\n");
        }
        stringBuilder.append("    \"");
        stringBuilder.append(string);
        stringBuilder.append("\": ");
        stringBuilder.append(l);
    }

    public static void dealEMV_ICC_AIDUpdate(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l += 2L))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                StringBuilder stringBuilder = new StringBuilder();
                HashMap<String, String> hashMap = new HashMap<String, String>();
                for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_EMV yP_TCD_DCB_Interface_EMV;
                    if (!(object2 instanceof YP_TCD_DCC_EFT_Business) || !object2.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_EMV = (YP_TCD_DCB_Interface_EMV)object2.getExtensionByType(YP_TCD_DCB_Interface_EMV.class)) == null) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_ICC)) continue;
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_EMV.getAIDTable();
                        for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                            String string;
                            Boolean bl;
                            String string2 = yP_Row.getFieldStringValueByName("rid");
                            String string3 = yP_Row.getFieldStringValueByName("pix");
                            String string4 = String.valueOf(string2) + string3;
                            YP_Row yP_Row2 = yP_TCD_DCB_Interface_EMV.getAIDParameters(string4);
                            if (yP_Row2 == null) {
                                yP_Transaction.logger(2, "dealEMV_ICC_AIDUpdate() Parameters not found for aid" + string4);
                                continue;
                            }
                            String string5 = EMV.getAIDName(string4);
                            if (string5.length() > 16) {
                                string5 = string5.substring(0, 16);
                            }
                            String string6 = (bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed")) == null || bl == false ? "0" : "1";
                            String string7 = yP_Row2.getFieldStringValueByName("defaultDDOL");
                            String string8 = yP_Row2.getFieldStringValueByName("defaultTDOL");
                            String string9 = yP_Row2.getFieldStringValueByName("tacDenial");
                            String string10 = yP_Row2.getFieldStringValueByName("tacOnline");
                            String string11 = yP_Row2.getFieldStringValueByName("tacDefault");
                            long l2 = (Long)yP_Row2.getFieldValueByName("thresholdCall");
                            int n = (Integer)yP_Row2.getFieldValueByName("randomCallCoefficient");
                            int n2 = (Integer)yP_Row2.getFieldValueByName("randomCallMaximumCoefficient");
                            int n3 = (Integer)yP_Row2.getFieldValueByName("currencyNumericalCode");
                            YP_TCD_DCB_Interface_CallParameters.Thresholds thresholds = null;
                            if (n3 == 0) {
                                yP_Transaction.logger(3, "dealEMV_ICC_AIDUpdate() no random call parameters for " + string4);
                            } else {
                                yP_Transaction.getDataContainerTransaction().commonHandler.setTransactionCurrencyNumerical(n3);
                                thresholds = ((YP_TCD_DCC_EFT_Business)object2).callParametersInterface.getThresholds(yP_Transaction.getDataContainerTransaction());
                            }
                            if (thresholds == null) {
                                thresholds = new YP_TCD_DCB_Interface_CallParameters.Thresholds();
                            }
                            long l3 = thresholds.defaultThreshold;
                            String string12 = "";
                            List<Integer> list3 = yP_TCD_DCB_Interface_EMV.getTAVNList(string4);
                            if (list3 != null && !list3.isEmpty()) {
                                string = String.format("%04X", list3.get(0));
                                for (int n4 : list3) {
                                    string12 = String.valueOf(string12) + String.format("%04X", n4);
                                }
                            } else {
                                string = "0000";
                                string12 = "0000";
                            }
                            StringBuilder stringBuilder2 = new StringBuilder();
                            Albert.add(stringBuilder2, "aid", string4);
                            Albert.add(stringBuilder2, "appLabel", string5);
                            Albert.add(stringBuilder2, "defaultDDOL", string7);
                            Albert.add(stringBuilder2, "defaultTDOL", string8);
                            Albert.add(stringBuilder2, "exactMatchRequired", string6);
                            Albert.add(stringBuilder2, "floorLimit", l3);
                            Albert.add(stringBuilder2, "maxTargetPercentage", n2);
                            Albert.add(stringBuilder2, "tacDefault", string11);
                            Albert.add(stringBuilder2, "tacDenial", string9);
                            Albert.add(stringBuilder2, "tacOnline", string10);
                            Albert.add(stringBuilder2, "targetPercentage", n);
                            Albert.add(stringBuilder2, "termAppVersion", string);
                            Albert.add(stringBuilder2, "termAppVersions", string12);
                            Albert.add(stringBuilder2, "threshold", l2);
                            boolean bl2 = false;
                            String string13 = (String)hashMap.get(string4);
                            if (string13 != null) {
                                if (!string13.contentEquals(stringBuilder2.toString())) {
                                    yP_Transaction.logger(3, "dealEMV_ICC_AIDUpdate() Same aid differents values " + string13 + " vs " + stringBuilder2);
                                }
                                bl2 = true;
                            }
                            if (bl2) continue;
                            hashMap.put(string4, stringBuilder2.toString());
                            if (stringBuilder.length() == 0) {
                                stringBuilder.append("[");
                            } else {
                                stringBuilder.append(",");
                            }
                            stringBuilder.append("\r\n{\r\n");
                            stringBuilder.append(stringBuilder2.toString());
                            stringBuilder.append("\r\n}");
                        }
                    }
                }
                if (stringBuilder.length() > 0) {
                    stringBuilder.append("\r\n]");
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, stringBuilder.toString());
                    tLVHandler.add(14672506, (long)stringBuilder.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                } else {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                        return;
                    }
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, "");
                    tLVHandler.add(14672506, 0L);
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                    parameterFile2.headerParameterFile.checksum = "0";
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealEMV_ICC_AIDUpdate()" + exception);
        }
    }

    public static void dealCTCL_Parameters_Update(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l, long l2) {
        long l3 = (l + l2) % 0x100000000L;
        l3 += 13L;
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l3))) {
                Object object2;
                Cloneable cloneable;
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l3);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                boolean bl = false;
                boolean bl2 = false;
                if (!list.isEmpty() && (cloneable = yP_Transaction.getDataContainerTransaction().getTerminalRow()) != null) {
                    int n;
                    object2 = ((YP_Row)cloneable).getFieldStringValueByName("appHandlerTerminalVersion");
                    if (!((String)object2).startsWith("1.1")) {
                        bl2 = true;
                    }
                    if ((n = ((Integer)((YP_Row)cloneable).getFieldValueByName("debugLevel")).intValue()) != 0) {
                        bl = true;
                    }
                }
                cloneable = new ArrayList();
                object2 = new PropertyTree();
                if (bl) {
                    PropertySection propertySection = new PropertySection("Config");
                    ((PropertyTree)object2).addPropertySection(propertySection);
                    propertySection.addProperty("Debug", "Yes");
                }
                PropertySection propertySection = new PropertySection("Terminal");
                ((PropertyTree)object2).addPropertySection(propertySection);
                propertySection.addProperty("CountryCode", list.get(0).getCountryCode());
                propertySection.addProperty("TerminalType", "22");
                propertySection.addProperty("TerminalCapabilities", UtilsYP.devHexa(defaultTerminalCapabilities));
                propertySection.addProperty("AdditionalTerminalCapabilities", defaultAdditionalTerminalCapabilities);
                propertySection.addProperty("ProvideCardholderConfirmation", "Yes");
                propertySection.addProperty("EMVContact", "Yes");
                propertySection.addProperty("EMVContactless", "Yes");
                propertySection.addProperty("Magstripe", "Yes");
                propertySection.addProperty("PinTimeOut", "60");
                propertySection.addProperty("BatchManaged", "Yes");
                propertySection.addProperty("AdviceManaged", "Yes");
                propertySection.addProperty("PSE", "Yes");
                propertySection.addProperty("Autorun", "No");
                propertySection.addProperty("PredefinedAmount", "0");
                if (bl) {
                    propertySection.addProperty("Debug", "Yes");
                } else {
                    propertySection.addProperty("Debug", "No");
                }
                propertySection.addProperty("CBSelection", "Yes");
                String string = Albert.getForbiddenProducts(yP_Transaction, list);
                if (string != null && !string.isEmpty()) {
                    propertySection.addProperty("FORBIDDEN_PRODUCTS", string);
                }
                block2: for (YP_TCD_DCC_Business object3 : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!object3.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)object3.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object3.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        if (bl2) {
                            Albert.deallOneCTCLContract(yP_Transaction, object3, yP_TCD_DCB_Interface_CTCL, (PropertyTree)object2, (List<LimitSet>)((Object)cloneable));
                            continue block2;
                        }
                        Albert.deallOneCTCLContractOld(yP_Transaction, object3, yP_TCD_DCB_Interface_CTCL, (PropertyTree)object2);
                        continue block2;
                    }
                }
                Albert.addVisaDRL((PropertyTree)object2, (List<LimitSet>)((Object)cloneable));
                String string2 = Albert.generateJSON((PropertyTree)object2);
                if (string2 != null) {
                    if (yP_Transaction.getLogLevel() == 6) {
                        yP_Transaction.logger(6, "dealCTCL_Parameters_Update() : " + string2);
                    }
                    TLVHandler tLVHandler = new TLVHandler();
                    tLVHandler.addASCII(14672757, string2);
                    tLVHandler.add(14672506, (long)string2.length());
                    parameterFile2.appTagsList.add(tLVHandler.toString());
                }
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals("0")) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = "0";
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealCTCL_Parameters_Update() " + exception);
        }
    }

    private static List<LimitSet> getLimitList(List<YP_Row> list) {
        ArrayList<LimitSet> arrayList = new ArrayList<LimitSet>();
        for (YP_Row yP_Row : list) {
            LimitSet limitSet = new LimitSet();
            arrayList.add(limitSet);
            Boolean bl = (Boolean)yP_Row.getFieldValueByName("statusCheckSupport");
            limitSet.statusCheckSupport = bl != null && bl != false;
            Boolean bl2 = (Boolean)yP_Row.getFieldValueByName("zeroAmountAllowedSupport");
            limitSet.zeroAmountAllowedSupport = bl2 != null && bl2 != false;
            limitSet.CVMRequiredLimit = yP_Row.getFieldStringValueByName("CVMRequiredLimit");
            while (limitSet.CVMRequiredLimit.length() < 12) {
                limitSet.CVMRequiredLimit = "0" + limitSet.CVMRequiredLimit;
            }
            limitSet.CVMRequiredLimit.contentEquals("999999999999");
            limitSet.ctlFloorLimit = yP_Row.getFieldStringValueByName("ctlFloorLimit");
            while (limitSet.ctlFloorLimit.length() < 12) {
                limitSet.ctlFloorLimit = "0" + limitSet.ctlFloorLimit;
            }
            limitSet.ctlFloorLimit.contentEquals("999999999999");
            limitSet.applicationPgmId = yP_Row.getFieldStringValueByName("applicationPgmId");
            limitSet.ctlTransactionLimit = yP_Row.getFieldStringValueByName("ctlTransactionLimit");
            while (limitSet.ctlTransactionLimit.length() < 12) {
                limitSet.ctlTransactionLimit = "0" + limitSet.ctlTransactionLimit;
            }
            limitSet.kernelID = yP_Row.getFieldStringValueByName("kernelID");
            limitSet.numericalCurrencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
            while (limitSet.numericalCurrencyCode.length() < 3) {
                limitSet.numericalCurrencyCode = "0" + limitSet.numericalCurrencyCode;
            }
        }
        return arrayList;
    }

    private static void addLimits(YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, List<LimitSet> list) {
        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getDRLTable();
        if (yP_TCD_DesignAccesObject != null) {
            List<LimitSet> list2;
            YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
            yP_ComplexGabarit.set("kernelID", YP_ComplexGabarit.OPERATOR.EQUAL, "03");
            List<YP_Row> list3 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
            if (list3 != null && !list3.isEmpty() && (list2 = Albert.getLimitList(list3)) != null) {
                list.addAll(list2);
            }
        }
    }

    private static void addVisaDRL(PropertyTree propertyTree, List<LimitSet> list) {
        if (list != null && !list.isEmpty()) {
            PropertySection propertySection = new PropertySection("Visa");
            propertyTree.addPropertySection(propertySection);
            for (LimitSet limitSet : list) {
                EmvTagStore emvTagStore = new EmvTagStore();
                propertySection.addProperty(new PropertyItem("DRL", emvTagStore));
                emvTagStore.setTag("9F5A", limitSet.applicationPgmId);
                byte[] byArray = new byte[]{120};
                if (limitSet.statusCheckSupport) {
                    byArray[0] = (byte)(byArray[0] | 0x80);
                }
                emvTagStore.setTag("BITMAP_ENTRY_POINT", UtilsYP.devHexa(byArray));
                if (limitSet.zeroAmountAllowedSupport) {
                    emvTagStore.setTag("STATUS_ZERO_AMOUNT_ALLOWED_FLAG", "01");
                } else {
                    emvTagStore.setTag("STATUS_ZERO_AMOUNT_ALLOWED_FLAG", "02");
                }
                emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", limitSet.ctlFloorLimit);
                emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", limitSet.ctlTransactionLimit);
                emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", limitSet.CVMRequiredLimit);
            }
        }
    }

    private static String getForbiddenProducts(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list) {
        TLVHandler tLVHandler = new TLVHandler();
        try {
            HashMap hashMap = new HashMap();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                YP_TCD_DCB_Interface_ProductList yP_TCD_DCB_Interface_ProductList;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals("1") || (yP_TCD_DCB_Interface_ProductList = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_ProductList.getProductListTable();
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string;
                    String string2;
                    String string3 = yP_Row.getFieldStringValueByName("emvApplicationAID");
                    if (string3 == null || string3.isEmpty()) {
                        yP_Transaction.logger(4, "getForbiddenProducts() maybe a product indexed by BIN");
                        continue;
                    }
                    ArrayList<String> arrayList = (ArrayList<String>)hashMap.get(string3);
                    if (arrayList == null) {
                        arrayList = new ArrayList<String>();
                        hashMap.put(string3, arrayList);
                    }
                    if ((string2 = yP_Row.getFieldStringValueByName("electronicProductIdentification")) == null || string2.isEmpty()) {
                        string2 = "0001";
                    }
                    if ((string = yP_Row.getFieldStringValueByName("codeProduit")) == null || string.isEmpty()) {
                        yP_Transaction.logger(3, "dealEMV_ICC_AID_PosmateUpdate() product code missing!!!");
                        continue;
                    }
                    if (arrayList.contains(string)) continue;
                    arrayList.add(string);
                    tLVHandler.add(79, string3);
                    tLVHandler.add(40714, String.format("%s%02d%s", string2, string.length() / 2, string));
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealCTCL_Parameters_Update() " + exception);
        }
        return tLVHandler.toString();
    }

    private static String generateJSON(PropertyTree propertyTree) {
        if (propertyTree == null || propertyTree.propertySectionList == null || propertyTree.propertySectionList.size() <= 1) {
            return "";
        }
        boolean bl = true;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[\r\n");
        for (PropertySection propertySection : propertyTree.propertySectionList) {
            if (bl) {
                bl = false;
                stringBuilder.append("\t{\r\n");
            } else {
                stringBuilder.append(", {\r\n");
            }
            stringBuilder.append("\t\t\"propertySection\": {\r\n");
            stringBuilder.append("\t\t\t\"sectionName\": \"");
            stringBuilder.append(propertySection.sectionName);
            stringBuilder.append("\",\r\n");
            stringBuilder.append("\t\t\t\"propertyItem\": [\r\n");
            boolean bl2 = true;
            for (PropertyItem propertyItem : propertySection.propertyList) {
                if (bl2) {
                    bl2 = false;
                } else {
                    stringBuilder.append(",\r\n");
                }
                if (propertyItem.tagStore != null) {
                    stringBuilder.append("\t\t\t\t{ \"propertyName\": \"");
                    stringBuilder.append(propertyItem.propertyName);
                    stringBuilder.append("\",\r\n");
                    stringBuilder.append("\t\t\t\t\t\"tagStore\" : [\r\n");
                    boolean bl3 = true;
                    for (String string : propertyItem.tagStore.getAllTags().keySet()) {
                        if (bl3) {
                            bl3 = false;
                        } else {
                            stringBuilder.append(",\r\n");
                        }
                        stringBuilder.append("\t\t\t\t\t{ \"tag\": \"");
                        stringBuilder.append(string);
                        stringBuilder.append("\", \"value\": \"");
                        stringBuilder.append(propertyItem.tagStore.getTag(string));
                        stringBuilder.append("\" }");
                    }
                    stringBuilder.append("\r\n\t\t\t\t\t]\r\n");
                    stringBuilder.append("\t\t\t\t}");
                    continue;
                }
                stringBuilder.append("\t\t\t\t{ \"propertyName\": \"");
                stringBuilder.append(propertyItem.propertyName);
                stringBuilder.append("\", \"propertyValue\": \"");
                stringBuilder.append(propertyItem.propertyValue);
                stringBuilder.append("\" }");
            }
            stringBuilder.append("\r\n");
            stringBuilder.append("\t\t\t]\r\n");
            stringBuilder.append("\t\t}\r\n");
            stringBuilder.append("\t}\r\n");
        }
        stringBuilder.append("]\r\n");
        return stringBuilder.toString();
    }

    private static void deallOneCTCLContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, PropertyTree propertyTree, List<LimitSet> list) {
        Albert.addLimits(yP_TCD_DCB_Interface_CTCL, list);
        List<YP_Row> list2 = yP_TCD_DCB_Interface_CTCL.getAIDKIDList();
        block48: for (YP_Row yP_Row : list2) {
            String string = "";
            String string2 = "";
            String string3 = "";
            try {
                String string4;
                Object object2;
                List<YP_Row> list3;
                boolean bl;
                String string5;
                string = yP_Row.getFieldStringValueByName("applicationIdentifier");
                string2 = yP_Row.getFieldStringValueByName("kernelID");
                if (string2.length() == 1) {
                    string2 = "0" + string2;
                }
                string3 = yP_Row.getFieldStringValueByName("transactionType");
                if (yP_Transaction.getLogLevel() == 6) {
                    yP_Transaction.logger(6, "deallOneCTCLContract(): process contactless aid: " + string + " " + string2 + " " + string3);
                }
                if (!"978".contentEquals(string5 = yP_Row.getFieldStringValueByName("numericalCurrencyCode"))) {
                    yP_Transaction.logger(3, "deallOneCTCLContract(): currency other than 978 ignored :" + string5);
                }
                if (bl = Albert.isAlreadyInsideParameters(propertyTree, string, string2, string3)) {
                    yP_Transaction.logger(3, "deallOneCTCLContract(): Already there :" + string + " " + string2 + " " + string3);
                    continue;
                }
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getAIDTable();
                YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                if (string.length() < 10) {
                    yP_Transaction.logger(3, "deallOneCTCLContract: aid length invalid: " + string.length());
                    continue;
                }
                String string6 = string.substring(0, 10);
                yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string6);
                String string7 = null;
                if (string.length() > 10) {
                    string7 = string.substring(10);
                    yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.START_WITH, string7);
                }
                if (((list3 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit)) == null || list3.isEmpty()) && ((list3 = Albert.getPartialAIDRow(yP_TCD_DesignAccesObject, string)) == null || list3.isEmpty())) {
                    yP_Transaction.logger(3, "deallOneCTCLContract: aid not found for " + string);
                    continue;
                }
                String string8 = String.valueOf(string) + ":" + Integer.toString(Integer.parseInt(string2));
                PropertySection propertySection = null;
                boolean bl2 = false;
                for (Object object2 : propertyTree) {
                    if (!((PropertySection)object2).sectionName.contentEquals(string8)) continue;
                    propertySection = object2;
                    break;
                }
                if (propertySection == null) {
                    bl2 = true;
                    propertySection = new PropertySection(string8);
                    propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
                    if (!list3.isEmpty()) {
                        propertySection.addProperty("TerminalPriority", list3.get(0).getFieldStringValueByName("priority"));
                    }
                }
                switch (string3) {
                    case "0": 
                    case "00": {
                        object2 = "Purchase";
                        break;
                    }
                    case "20": {
                        object2 = "Refund";
                        break;
                    }
                    default: {
                        yP_Transaction.logger(2, "deallOneCTCLContract(): row ignored : " + string + " " + string2 + " " + string3);
                        continue block48;
                    }
                }
                EmvTagStore emvTagStore = new EmvTagStore();
                propertySection.addProperty(new PropertyItem((String)object2, emvTagStore));
                String string9 = yP_TCD_DCC_Business.getCountryCode();
                while (string9.length() < 4) {
                    string9 = String.valueOf('0') + string9;
                }
                emvTagStore.setTag("TERMINAL_COUNTRY_CODE", string9);
                emvTagStore.setTag("TERMINAL_TYPE", "22");
                byte[] byArray = new byte[defaultTerminalCapabilities.length];
                String string10 = yP_Row.getFieldStringValueByName("signatureHandled");
                String string11 = yP_Row.getFieldStringValueByName("pinOnlineHandled");
                String string12 = yP_Row.getFieldStringValueByName("noCVMHandled");
                String string13 = yP_Row.getFieldStringValueByName("onDeviceCVMHandled");
                if (string3.contentEquals("20")) {
                    string13 = "true";
                }
                switch (string2) {
                    case "02": {
                        string4 = UtilsYP.devHexa(terminalCapabilitiesNoCVMMC);
                        System.arraycopy(terminalCapabilitiesMC, 0, byArray, 0, terminalCapabilitiesMC.length);
                        byArray[1] = string10 != null && string10.contentEquals("true") ? (byte)(byArray[1] | 0x20) : (byte)(byArray[1] & 0xDF);
                        byArray[1] = string11 != null && string11.contentEquals("true") ? (byte)(byArray[1] | 0x40) : (byte)(byArray[1] & 0xBF);
                        if (string12 != null && string12.contentEquals("true")) {
                            byArray[1] = (byte)(byArray[1] | 8);
                            break;
                        }
                        byArray[1] = (byte)(byArray[1] & 0xF7);
                        break;
                    }
                    case "03": {
                        string4 = UtilsYP.devHexa(terminalCapabilitiesNoCVMVISA);
                        System.arraycopy(terminalCapabilitiesVISA, 0, byArray, 0, terminalCapabilitiesVISA.length);
                        byArray[1] = string10 != null && string10.contentEquals("true") ? (byte)(byArray[1] | 0x20) : (byte)(byArray[1] & 0xDF);
                        byArray[1] = string11 != null && string11.contentEquals("true") ? (byte)(byArray[1] | 0x40) : (byte)(byArray[1] & 0xBF);
                        if (string12 != null && string12.contentEquals("true")) {
                            byArray[1] = (byte)(byArray[1] | 8);
                            break;
                        }
                        byArray[1] = (byte)(byArray[1] & 0xF7);
                        break;
                    }
                    case "04": {
                        byArray = terminalCapabilitiesAMEX;
                        string4 = UtilsYP.devHexa(terminalCapabilitiesAMEX);
                        break;
                    }
                    default: {
                        string4 = UtilsYP.devHexa(defaultTerminalCapabilitiesNoCVM);
                        System.arraycopy(defaultTerminalCapabilities, 0, byArray, 0, defaultTerminalCapabilities.length);
                        byArray[1] = string10 != null && string10.contentEquals("true") ? (byte)(byArray[1] | 0x20) : (byte)(byArray[1] & 0xDF);
                        byArray[1] = string11 != null && string11.contentEquals("true") ? (byte)(byArray[1] | 0x40) : (byte)(byArray[1] & 0xBF);
                        byArray[1] = string12 != null && string12.contentEquals("true") ? (byte)(byArray[1] | 8) : (byte)(byArray[1] & 0xF7);
                    }
                }
                emvTagStore.setTag("TERMINAL_CAPABILITIES", UtilsYP.devHexa(byArray));
                emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
                StringBuilder stringBuilder = new StringBuilder();
                int n = 0;
                while (n < list3.size()) {
                    int n2 = (Integer)list3.get(n).getFieldValueByName("terminalApplicationVersionNumber");
                    stringBuilder.append(String.format("%4s", Integer.toHexString(n2)).replace(' ', '0'));
                    ++n;
                }
                emvTagStore.setTag("DF50", stringBuilder.toString());
                emvTagStore.setTag("TAC_ONLINE", yP_Row.getFieldStringValueByName("tacOnline"));
                emvTagStore.setTag("TAC_DEFAULT", yP_Row.getFieldStringValueByName("tacDefault"));
                emvTagStore.setTag("TAC_DENIAL", yP_Row.getFieldStringValueByName("tacDenial"));
                emvTagStore.setTag("MERCHANT_CATEGORY_CODE", String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode())));
                emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", Albert.getPaddedAmount(yP_Row, "readerContactlessFloorLimit"));
                emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", Albert.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitNoOnDevice"));
                if ("02".contentEquals(string2)) {
                    emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_ON_DEVICE_CVM", Albert.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitOnDevice"));
                }
                emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", Albert.getPaddedAmount(yP_Row, "readerCVMRequiredLimit"));
                StringBuilder stringBuilder2 = new StringBuilder(yP_Row.getFieldStringValueByName("terminalFloorLimit"));
                while (stringBuilder2.length() < 8) {
                    stringBuilder2.insert(0, "0");
                }
                if (stringBuilder2.length() > 8) {
                    emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "99999900");
                } else {
                    emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", stringBuilder2.toString());
                }
                byte[] byArray2 = new byte[]{120};
                if (UtilsYP.isTrue(yP_Row.getFieldStringValueByName("statusCheckSupport"))) {
                    byArray2[0] = (byte)(byArray2[0] | 0x80);
                }
                emvTagStore.setTag("BITMAP_ENTRY_POINT", UtilsYP.devHexa(byArray2));
                if (UtilsYP.isTrue(yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport"))) {
                    emvTagStore.setTag("STATUS_ZERO_AMOUNT_ALLOWED_FLAG", "01");
                } else {
                    emvTagStore.setTag("STATUS_ZERO_AMOUNT_ALLOWED_FLAG", "02");
                }
                switch (string2) {
                    case "02": {
                        emvTagStore.setTag("SECURITY_CAPABILITIES", UtilsYP.devHexa(byArray).substring(4, 6));
                        emvTagStore.setTag("DEFAULT_UDOL", defaultUDOL);
                        emvTagStore.setTag("CARD_DATA_INPUT_CAPABILITIES", UtilsYP.devHexa(byArray).substring(0, 2));
                        emvTagStore.setTag("CVM_CAPABILITIES_CVM_REQUIRED", UtilsYP.devHexa(byArray).substring(2, 4));
                        emvTagStore.setTag("CVM_CAPABILITIES_NO_CVM_REQUIRED", string4.substring(2, 4));
                        emvTagStore.setTag("9F6D", stringBuilder.substring(stringBuilder.length() - 4));
                        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_CVM_REQUIRED", UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4));
                        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_NO_CVM_REQUIRED", UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4));
                        byte[] byArray3 = new byte[1];
                        if (UtilsYP.isTrue(string13)) {
                            byArray3[0] = (byte)(byArray3[0] | 0x20);
                        }
                        switch (string) {
                            case "A0000000043060": 
                            case "A0000000422010": 
                            case "A0000000425010": {
                                byArray3[0] = (byte)(byArray3[0] | 0x80);
                                emvTagStore.setTag("TERMINAL_RISK_MANAGEMENT_DATA", "2C00800000000000");
                                break;
                            }
                            default: {
                                emvTagStore.setTag("TERMINAL_RISK_MANAGEMENT_DATA", "2C00000000000000");
                            }
                        }
                        emvTagStore.setTag("KERNEL_CONFIGURATION", UtilsYP.devHexa(byArray3));
                        emvTagStore.setTag("MAX_LIFETIME_TORN_TRANSACTION", "012C");
                        emvTagStore.setTag("MAX_NUMBER_TORN_TRANSACTION", "01");
                        emvTagStore.setTag("DF04", "");
                        emvTagStore.setTag("DF05", "");
                        break;
                    }
                    case "03": {
                        byte[] byArray4 = UtilsYP.redHexa(defaultVISATTQ);
                        byte[] byArray5 = UtilsYP.redHexa(defaultVISARefundTTQ);
                        if (string10 != null && string10.contentEquals("true")) {
                            byArray4[0] = (byte)(byArray4[0] | 2);
                            byArray5[0] = (byte)(byArray5[0] | 2);
                        } else {
                            byArray4[0] = (byte)(byArray4[0] & 0xFD);
                            byArray5[0] = (byte)(byArray5[0] & 0xFD);
                        }
                        if (string11 != null && string11.contentEquals("true")) {
                            byArray4[0] = (byte)(byArray4[0] | 4);
                            byArray5[0] = (byte)(byArray5[0] | 4);
                        } else {
                            byArray4[0] = (byte)(byArray4[0] & 0xFB);
                            byArray5[0] = (byte)(byArray5[0] & 0xFB);
                        }
                        if (string13 != null && string13.contentEquals("true")) {
                            byArray4[2] = (byte)(byArray4[2] | 0x40);
                            byArray5[2] = (byte)(byArray5[2] | 0x40);
                        } else {
                            byArray4[2] = (byte)(byArray4[2] & 0xBF);
                            byArray5[2] = (byte)(byArray5[2] & 0xBF);
                        }
                        byte[] byArray6 = new byte[3];
                        byArray6[0] = -16;
                        byArray6[1] = -128;
                        byte[] byArray7 = byArray6;
                        if (list.isEmpty()) {
                            byArray7[1] = 0;
                        }
                        emvTagStore.setTag("KERNEL_CONFIGURATION", UtilsYP.devHexa(byArray7));
                        switch (string3) {
                            case "0": 
                            case "00": {
                                emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", UtilsYP.devHexa(byArray4));
                                break;
                            }
                            case "20": {
                                emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", UtilsYP.devHexa(byArray5));
                            }
                        }
                        break;
                    }
                    case "04": {
                        emvTagStore.setTag("9F6D", "C0");
                        emvTagStore.setTag("9F6E", "D8A00000");
                    }
                }
                emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
                if (!bl2) continue;
                propertyTree.addPropertySection(propertySection);
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "deallOneCTCLContract(): process contactless aid: " + string + " " + string2 + " " + string3 + " " + exception);
            }
        }
    }

    private static void deallOneCTCLContractOld(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, PropertyTree propertyTree) {
        PropertySection propertySection = new PropertySection("A0000000421010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        EmvTagStore emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00002000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000422010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000000000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00000000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000424010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00002000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000425010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000000000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00000000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000031010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00002000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000032010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "3");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602840");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "40");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER", defaultVISATTQ);
        emvTagStore.setTag("TAC_ONLINE", "0000008800");
        emvTagStore.setTag("TAC_DEFAULT", "0000008800");
        emvTagStore.setTag("TAC_DENIAL", "B000C00000");
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000000000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000030001");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002001");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00000000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "00");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        propertySection = new PropertySection("A0000000041010");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "2");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("KERNEL_ID", "02");
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602808");
        emvTagStore.setTag("CARD_DATA_INPUT_CAPABILITIES", "60");
        emvTagStore.setTag("CVM_CAPABILITIES_CVM_REQUIRED", "28");
        emvTagStore.setTag("CVM_CAPABILITIES_NO_CVM_REQUIRED", "08");
        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_CVM_REQUIRED", "10");
        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_NO_CVM_REQUIRED", "00");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "08");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("9F6D", "0001");
        emvTagStore.setTag("TAC_ONLINE", "FC50808800");
        emvTagStore.setTag("TAC_DEFAULT", "FC50808800");
        emvTagStore.setTag("TAC_DENIAL", "0000000000");
        emvTagStore.setTag("DEFAULT_UDOL", defaultUDOL);
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_ON_DEVICE_CVM", "000000030000");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002000");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00002000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "20");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        emvTagStore.setTag("MAX_LIFETIME_TORN_TRANSACTION", "0000");
        emvTagStore.setTag("MAX_NUMBER_TORN_TRANSACTION", "00");
        emvTagStore.setTag("TERMINAL_RISK_MANAGEMENT_DATA", "2C00000000000000");
        propertySection = new PropertySection("A0000000043060");
        propertyTree.addPropertySection(propertySection);
        propertySection.addProperty("ApplicationSelectionIndicator", "Yes");
        propertySection.addProperty("KernelId", "2");
        emvTagStore = new EmvTagStore();
        propertySection.addProperty(new PropertyItem("Purchase", emvTagStore));
        emvTagStore.setTag("KERNEL_ID", "02");
        emvTagStore.setTag("TERMINAL_COUNTRY_CODE", "0250");
        emvTagStore.setTag("TERMINAL_TYPE", "22");
        emvTagStore.setTag("TERMINAL_CAPABILITIES", "602808");
        emvTagStore.setTag("CARD_DATA_INPUT_CAPABILITIES", "60");
        emvTagStore.setTag("CVM_CAPABILITIES_CVM_REQUIRED", "28");
        emvTagStore.setTag("CVM_CAPABILITIES_NO_CVM_REQUIRED", "08");
        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_CVM_REQUIRED", "10");
        emvTagStore.setTag("MAGSTRIPE_CVM_CAPABILITIES_NO_CVM_REQUIRED", "00");
        emvTagStore.setTag("SECURITY_CAPABILITIES", "08");
        emvTagStore.setTag("ADDITIONAL_TERMINAL_CAPABILITIES", defaultAdditionalTerminalCapabilities);
        emvTagStore.setTag("APPLICATION_VERSION_NUMBER", "0002");
        emvTagStore.setTag("9F6D", "0001");
        emvTagStore.setTag("TAC_ONLINE", "FC50808800");
        emvTagStore.setTag("TAC_DEFAULT", "FC50808800");
        emvTagStore.setTag("TAC_DENIAL", "0000000000");
        emvTagStore.setTag("DEFAULT_UDOL", defaultUDOL);
        emvTagStore.setTag("MERCHANT_CATEGORY_CODE", "8999");
        emvTagStore.setTag("READER_CONTACTLESS_FLOOR_LIMIT", "000000000000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM", "000000002000");
        emvTagStore.setTag("READER_CONTACTLESS_TRANSACTION_LIMIT_ON_DEVICE_CVM", "000000030000");
        emvTagStore.setTag("READER_CVM_REQUIRED_LIMIT", "000000002000");
        emvTagStore.setTag("TERMINAL_FLOOR_LIMIT", "00000000");
        emvTagStore.setTag("KERNEL_CONFIGURATION", "20");
        emvTagStore.setTag("MESSAGE_HOLD_TIME", "000000");
        emvTagStore.setTag("BITMAP_ENTRY_POINT", "78");
        emvTagStore.setTag("MAX_LIFETIME_TORN_TRANSACTION", "0000");
        emvTagStore.setTag("MAX_NUMBER_TORN_TRANSACTION", "00");
        emvTagStore.setTag("TERMINAL_RISK_MANAGEMENT_DATA", "2C00000000000000");
    }

    private static boolean isAlreadyInsideParameters(PropertyTree propertyTree, String string, String string2, String string3) {
        for (PropertySection propertySection : propertyTree) {
            if (!propertySection.sectionName.contentEquals(String.valueOf(string) + ":" + Integer.toString(Integer.parseInt(string2)))) continue;
            for (PropertyItem propertyItem : propertySection.propertyList) {
                if (propertyItem.propertyName.contentEquals("Purchase") && ("00".contentEquals(string3) || "0".contentEquals(string3))) {
                    return true;
                }
                if (!propertyItem.propertyName.contentEquals("Refund") || !"20".contentEquals(string3)) continue;
                return true;
            }
        }
        return false;
    }

    private static List<YP_Row> getPartialAIDRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        String string2 = string.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("partialSelectionAllowed", YP_ComplexGabarit.OPERATOR.EQUAL, true);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() == 0) {
            return null;
        }
        for (YP_Row yP_Row : list) {
            String string3 = yP_Row.getFieldStringValueByName("pix");
            if (!string.startsWith(String.valueOf(string2) + string3)) continue;
            arrayList.add(yP_Row);
        }
        return arrayList;
    }

    private static String getPaddedAmount(YP_Row yP_Row, String string) {
        StringBuilder stringBuilder = new StringBuilder(yP_Row.getFieldStringValueByName(string));
        while (stringBuilder.length() < 12) {
            stringBuilder.insert(0, "0");
        }
        return stringBuilder.toString();
    }

    private static class AgnosEmvTag {
        public static final String SECURITY_CAPABILITIES = "SECURITY_CAPABILITIES";
        public static final String KERNEL_ID = "KERNEL_ID";
        public static final String CARD_DATA_INPUT_CAPABILITIES = "CARD_DATA_INPUT_CAPABILITIES";
        public static final String CVM_CAPABILITIES_CVM_REQUIRED = "CVM_CAPABILITIES_CVM_REQUIRED";
        public static final String CVM_CAPABILITIES_NO_CVM_REQUIRED = "CVM_CAPABILITIES_NO_CVM_REQUIRED";
        public static final String DEFAULT_UDOL = "DEFAULT_UDOL";
        public static final String KERNEL_CONFIGURATION = "KERNEL_CONFIGURATION";
        public static final String MAX_LIFETIME_TORN_TRANSACTION = "MAX_LIFETIME_TORN_TRANSACTION";
        public static final String MAX_NUMBER_TORN_TRANSACTION = "MAX_NUMBER_TORN_TRANSACTION";
        public static final String MAGSTRIPE_CVM_CAPABILITIES_CVM_REQUIRED = "MAGSTRIPE_CVM_CAPABILITIES_CVM_REQUIRED";
        public static final String TAC_DEFAULT = "TAC_DEFAULT";
        public static final String TAC_DENIAL = "TAC_DENIAL";
        public static final String TAC_ONLINE = "TAC_ONLINE";
        public static final String READER_CONTACTLESS_FLOOR_LIMIT = "READER_CONTACTLESS_FLOOR_LIMIT";
        public static final String READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM = "READER_CONTACTLESS_TRANSACTION_LIMIT_NO_ON_DEVICE_CVM";
        public static final String READER_CONTACTLESS_TRANSACTION_LIMIT_ON_DEVICE_CVM = "READER_CONTACTLESS_TRANSACTION_LIMIT_ON_DEVICE_CVM";
        public static final String READER_CVM_REQUIRED_LIMIT = "READER_CVM_REQUIRED_LIMIT";
        public static final String TIMEOUT_VALUE = "TIMEOUT_VALUE";
        public static final String MAGSTRIPE_CVM_CAPABILITIES_NO_CVM_REQUIRED = "MAGSTRIPE_CVM_CAPABILITIES_NO_CVM_REQUIRED";
        public static final String BITMAP_ENTRY_POINT = "BITMAP_ENTRY_POINT";
        public static final String ONLINE_TAG_LIST = "ONLINE_TAG_LIST";
        public static final String STATUS_ZERO_AMOUNT_ALLOWED_FLAG = "STATUS_ZERO_AMOUNT_ALLOWED_FLAG";
        public static final String ACCOUNT_TYPE = "ACCOUNT_TYPE";
        public static final String ACQUIRER_IDENTIFIER = "ACQUIRER_IDENTIFIER";
        public static final String APPLICATION_VERSION_NUMBER = "APPLICATION_VERSION_NUMBER";
        public static final String MERCHANT_CATEGORY_CODE = "MERCHANT_CATEGORY_CODE";
        public static final String MERCHANT_IDENTIFIER = "MERCHANT_IDENTIFIER";
        public static final String TERMINAL_COUNTRY_CODE = "TERMINAL_COUNTRY_CODE";
        public static final String TERMINAL_FLOOR_LIMIT = "TERMINAL_FLOOR_LIMIT";
        public static final String TERMINAL_IDENTIFICATION = "TERMINAL_IDENTIFICATION";
        public static final String IFD_SERIAL_NUMBER_OR_TERMINAL_IDENTIFICATION = "IFD_SERIAL_NUMBER_OR_TERMINAL_IDENTIFICATION";
        public static final String TERMINAL_CAPABILITIES = "TERMINAL_CAPABILITIES";
        public static final String TERMINAL_TYPE = "TERMINAL_TYPE";
        public static final String ADDITIONAL_TERMINAL_CAPABILITIES = "ADDITIONAL_TERMINAL_CAPABILITIES";
        public static final String MERCHANT_NAME_AND_LOCATION = "MERCHANT_NAME_AND_LOCATION";
        public static final String PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER = "PUNATC_OR_TERMINAL_TRANSACTION_QUALIFIER";
        public static final String CONTACTLESS_READER_CAPABILITIES = "CONTACTLESS_READER_CAPABILITIES";
        public static final String DCW_DISCOVER_VERSION_1_MOBILE_SUPPORT_INDICATOR_MASTERCARD = "DCW_DISCOVER_VERSION_1_MOBILE_SUPPORT_INDICATOR_MASTERCARD";
        public static final String TERMINAL_RISK_MANAGEMENT_DATA = "TERMINAL_RISK_MANAGEMENT_DATA";
        public static final String MESSAGE_HOLD_TIME = "MESSAGE_HOLD_TIME";

        private AgnosEmvTag() {
        }
    }

    private static class AgnosProperties {
        public static final String SECTION_TERMINAL = "Terminal";
        public static final String COUNTRY_CODE = "CountryCode";
        public static final String PROVIDE_CARDHOLDER_CONFIRMATION = "ProvideCardholderConfirmation";
        public static final String TERMINAL_TYPE = "TerminalType";
        public static final String EMV_CONTACT = "EMVContact";
        public static final String TERMINAL_CAPABILITIES = "TerminalCapabilities";
        public static final String ADDITIONAL_TERMINAL_CAPABILITIES = "AdditionalTerminalCapabilities";
        public static final String EMV_CONTACTLESS = "EMVContactless";
        public static final String MAGSTRIPE = "Magstripe";
        public static final String PIN_TIME_OUT = "PinTimeOut";
        public static final String BATCH_MANAGED = "BatchManaged";
        public static final String ADVICE_MANAGED = "AdviceManaged";
        public static final String PSE = "PSE";
        public static final String AUTORUN = "Autorun";
        public static final String PREDEFINED_AMOUNT = "PredefinedAmount";
        public static final String APPLICATION_SELECTION_INDICATOR = "ApplicationSelectionIndicator";
        public static final String KERNEL_ID = "KernelId";
        public static final String PURCHASE = "Purchase";
        public static final String CASH = "Cash";
        public static final String WITH_CASHBACK = "WithCashback";
        public static final String REFUND = "Refund";
        public static final String SECTION_CONFIG = "Config";
        public static final String DEBUG = "Debug";
        public static final String CB_SELECTION = "CBSelection";
        public static final String TERMINAL_PRIORITY = "TerminalPriority";

        private AgnosProperties() {
        }
    }

    private static final class EmvTagStore
    implements TagStore {
        private final Map<String, String> tags = new LinkedHashMap<String, String>();

        @Override
        public String getTag(String string) {
            return this.tags.get(string);
        }

        @Override
        public Map<String, String> getTags(String[] stringArray) {
            HashMap<String, String> hashMap = new HashMap<String, String>();
            if (stringArray != null) {
                String[] stringArray2 = stringArray;
                int n = stringArray.length;
                int n2 = 0;
                while (n2 < n) {
                    String string = stringArray2[n2];
                    String string2 = this.tags.get(string);
                    if (string2 != null) {
                        hashMap.put(string, string2);
                    }
                    ++n2;
                }
            }
            return hashMap;
        }

        @Override
        public Map<String, String> getAllTags() {
            return Collections.unmodifiableMap(this.tags);
        }

        @Override
        public boolean hasTags() {
            return !this.tags.isEmpty();
        }

        @Override
        public void setTag(String string, String string2) {
            this.tags.put(string, string2);
        }

        @Override
        public Map<String, String> getTags() {
            return this.tags;
        }
    }

    static class LimitSet {
        String kernelID;
        String applicationPgmId;
        String numericalCurrencyCode;
        String ctlTransactionLimit;
        String ctlFloorLimit;
        String CVMRequiredLimit;
        boolean statusCheckSupport;
        boolean zeroAmountAllowedSupport;

        LimitSet() {
        }
    }

    private static class PropertyItem {
        private final String propertyName;
        private final String propertyValue;
        private final TagReader tagStore;

        public PropertyItem(String string, String string2) {
            this.propertyName = string;
            this.propertyValue = string2;
            this.tagStore = null;
        }

        public PropertyItem(String string, TagReader tagReader) {
            this.propertyName = string;
            this.propertyValue = null;
            this.tagStore = tagReader;
        }

        public String getPropertyName() {
            return this.propertyName;
        }

        public String getPropertyValue() {
            return this.propertyValue;
        }

        public TagReader getTagStore() {
            return this.tagStore;
        }
    }

    private static class PropertySection
    implements Iterable<PropertyItem> {
        private final List<PropertyItem> propertyList = new ArrayList<PropertyItem>();
        private final String sectionName;

        public PropertySection(String string) {
            this.sectionName = string;
        }

        public String getSectionName() {
            return this.sectionName;
        }

        public void addProperty(PropertyItem propertyItem) {
            this.propertyList.add(propertyItem);
        }

        public void addProperty(String string, String string2) {
            this.addProperty(new PropertyItem(string, string2));
        }

        @Override
        public Iterator<PropertyItem> iterator() {
            return this.propertyList.iterator();
        }
    }

    private static class PropertyTree
    implements Iterable<PropertySection> {
        private final List<PropertySection> propertySectionList = new ArrayList<PropertySection>();

        public void addPropertySection(PropertySection propertySection) {
            this.propertySectionList.add(propertySection);
        }

        @Override
        public Iterator<PropertySection> iterator() {
            return this.propertySectionList.iterator();
        }
    }

    private static interface TagReader {
        public String getTag(String var1);

        public Map<String, String> getTags(String[] var1);

        public Map<String, String> getAllTags();

        public boolean hasTags();

        public Map<String, String> getTags();
    }

    private static interface TagStore
    extends TagReader,
    TagWriter {
    }

    private static interface TagWriter {
        public void setTag(String var1, String var2);
    }
}

