/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.yp.designaccesobjects.YP_Row;
import org.yp.designaccesobjects.brand.DAO_Summary;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DAO_LOC_Table;
import org.yp.framework.ondemandcomponents.YP_TCD_DataBaseConnector;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.applications.YP_Print;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Merchant;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.pos.YP_TCD_PosProtocol;
import org.yp.framework.services.YP_TS_DataContainerManager;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

class SessionSummaryReport
extends YP_Print {
    private static final int ALL_TRANSACTIONS = 1;
    private static final int ALL_TRANSACTIONS_BUT_CHQ = 2;
    private static final int ONLY_CHQ = 3;

    public SessionSummaryReport(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        super(yP_TCD_DCC_Business, yP_TCD_DC_Transaction);
    }

    static int doReport(YP_Transaction yP_Transaction, long l) {
        List<YP_TCD_DCC_Business> list = yP_Transaction.getApplicationList();
        if (list == null) {
            yP_Transaction.logger(2, "doReport() no application List");
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Error);
            return -1;
        }
        if (list.isEmpty()) {
            yP_Transaction.logger(2, "doReport() application List empty");
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Refused);
            return 0;
        }
        SessionSummaryReport sessionSummaryReport = new SessionSummaryReport(list.get(0), yP_Transaction.getDataContainerTransaction());
        sessionSummaryReport.doReport(yP_Transaction, list, l);
        return 1;
    }

    static long getTransactionSystemGMTTimeMSFromRequest(YP_Transaction yP_Transaction) {
        TLV tLV;
        block5: {
            String string;
            block4: {
                try {
                    string = yP_Transaction.getDataContainerTransaction().commonHandler.getRequestAppTags();
                    if (string != null && !string.isEmpty()) break block4;
                    return -1L;
                }
                catch (Exception exception) {
                    yP_Transaction.logger(2, "getTransactionSystemGMTTimeMSFromRequest() " + exception);
                    return -1L;
                }
            }
            TLVHandler tLVHandler = new TLVHandler(string);
            tLV = tLVHandler.getTLV(-538803914);
            if (tLV != null) break block5;
            return -1L;
        }
        return TLVHandler.getDCBLong(tLV.value);
    }

    /*
     * WARNING - void declaration
     */
    private void doReport(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, long l) {
        List<Object> list2;
        String string;
        String string2;
        boolean bl = false;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(list.get(0).getDataContainerMerchant().getMerchantLabel());
        this.appendLineFeed(stringBuilder);
        String string3 = yP_Transaction.getDataContainerTransaction().contextHandler.getStoreIdentifier();
        if (string3 != null && !string3.isEmpty()) {
            String string4 = list.get(0).getDataContainerBrand().getStoreLabel(list.get(0).getDataContainerMerchant().getIDMerchant(), string3);
            stringBuilder.append(string4);
            this.appendLineFeed(stringBuilder);
        }
        stringBuilder.append(this.getLabelTranslated("TERMINAL_LABEL", "TERMINAL"));
        stringBuilder.append(' ');
        stringBuilder.append(this.dataContainerTransaction.getRealNLPA());
        int n = YP_TCD_DCC_Business.getShiftNumber(yP_Transaction.getDataContainerTransaction());
        if (n > 0) {
            stringBuilder.append(" / ");
            stringBuilder.append(n);
        }
        this.appendLineFeed(stringBuilder);
        YP_TCD_DCC_Business yP_TCD_DCC_Business = null;
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business2 : list) {
            if (!yP_TCD_DCC_Business2.getActivationCode().contentEquals("1") || yP_TCD_DCC_Business2.timeInterface == null) continue;
            yP_TCD_DCC_Business = yP_TCD_DCC_Business2;
            break;
        }
        if (yP_TCD_DCC_Business != null) {
            string2 = SessionSummaryReport.getFormattedTime(new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(l).getTimeInMillis()));
            string = SessionSummaryReport.getFormattedTime(new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(yP_Transaction.getStartTime()).getTimeInMillis()));
        } else {
            string2 = SessionSummaryReport.getFormattedTime(list.get(0), l);
            string = SessionSummaryReport.getFormattedTime(list.get(0), yP_Transaction.getStartTime());
        }
        this.appendLineFeed(stringBuilder);
        stringBuilder.append(this.getLabelTranslated("FROM_DATE_LABEL", "DU"));
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        this.appendLineFeed(stringBuilder);
        stringBuilder.append(this.getLabelTranslated("TO_DATE_LABEL", "AU"));
        stringBuilder.append(' ');
        stringBuilder.append(string);
        this.appendLineFeed(stringBuilder);
        HashMap<YP_TCD_DCC_Merchant, List<YP_TCD_DCC_Business>> hashMap = new HashMap<YP_TCD_DCC_Merchant, List<YP_TCD_DCC_Business>>();
        for (YP_TCD_DCC_Business yP_TCD_DCC_Business3 : list) {
            if (yP_TCD_DCC_Business3.transaction == null) continue;
            list2 = (ArrayList<YP_TCD_DCC_Business>)hashMap.get(yP_TCD_DCC_Business3.getDataContainerMerchant());
            if (list2 == null) {
                list2 = new ArrayList<YP_TCD_DCC_Business>();
                hashMap.put(yP_TCD_DCC_Business3.getDataContainerMerchant(), list2);
            }
            list2.add(yP_TCD_DCC_Business3);
            for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business3.selectorList) {
                if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_CMC7)) continue;
                bl = true;
            }
        }
        String string4 = "                    AND nlpa = '" + yP_Transaction.getDataContainerTransaction().getNLPA3_6() + "'\r\n";
        if (l > 0L) {
            String string5 = String.valueOf(string4) + "                    AND transactionSystemGMTTimeMS > '" + l + "'\r\n";
        }
        if (n > 0) {
            void var13_15;
            String string6 = String.valueOf(var13_15) + "                    AND shiftNumber = '" + n + "'\r\n";
        }
        Object object = null;
        try {
            void var16_27;
            void var13_17;
            object = (YP_TCD_DAO_LOC_Table)((YP_TS_DataContainerManager)yP_Transaction.getPluginByName("DataContainerManager")).getDataContainerTechnique().newPluginByName("DAO_Table", DAO_Summary.class, 0, 1, null);
            Object var16_25 = null;
            if (bl) {
                list2 = this.getSummaryList(yP_Transaction, hashMap, (String)var13_17, (YP_TCD_DAO_LOC_Table)object, 2);
                List<YP_Row> list3 = this.getSummaryList(yP_Transaction, hashMap, (String)var13_17, (YP_TCD_DAO_LOC_Table)object, 3);
            } else {
                list2 = this.getSummaryList(yP_Transaction, hashMap, (String)var13_17, (YP_TCD_DAO_LOC_Table)object, 1);
            }
            if (list2 == null && var16_27 == null) {
                yP_Transaction.logger(2, "doReport() null list");
            } else {
                if ((list2 == null || list2.isEmpty()) && (var16_27 == null || var16_27.isEmpty())) {
                    yP_Transaction.logger(4, "doReport() nothing found");
                    this.appendLineFeed(stringBuilder);
                    stringBuilder.append(this.getLabelTranslated("NO_TRANSACTION_LABEL", "Pas de transaction"));
                    this.appendLineFeed(stringBuilder);
                } else {
                    if (list2 != null && !list2.isEmpty()) {
                        this.appendOneList(stringBuilder, list2, false);
                    }
                    if (var16_27 != null && !var16_27.isEmpty()) {
                        this.appendOneList(stringBuilder, (List<YP_Row>)var16_27, true);
                    }
                }
                this.appendLineFeed(stringBuilder);
                yP_Transaction.getDataContainerTransaction().setTicket(String.valueOf(yP_Transaction.getDataContainerTransaction().getTicket()) + stringBuilder.toString());
            }
            SessionSummaryReport.addCurrentGMTTimeMSToResponse(this.dataContainerTransaction);
            YP_TCD_DCC_Business.setGlobalResult(yP_Transaction.getDataContainerTransaction(), YP_TCD_PosProtocol.RESULT_TYPE.Success);
        }
        finally {
            ((YP_TCD_DAO_LOC_Table)object).shutdown();
        }
    }

    private void appendOneList(StringBuilder stringBuilder, List<YP_Row> list, boolean bl) {
        for (YP_Row yP_Row : list) {
            String string = yP_Row.getFieldStringValueByName("transactionCurrencyAlpha");
            int n = this.getAmountFraction(string);
            this.appendLineFeed(stringBuilder);
            if (bl) {
                stringBuilder.append("DEBIT CHEQUE");
            } else {
                stringBuilder.append(this.getLabelTranslated("PURCHASE_TRANSACTION_TYPE", "DEBIT"));
            }
            stringBuilder.append(" : ");
            this.appendLineFeed(stringBuilder);
            int n2 = (Integer)yP_Row.getFieldValueByName("nbDebit");
            stringBuilder.append(n2);
            stringBuilder.append(" trs  / ");
            long l = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountDebit"));
            stringBuilder.append(UtilsYP.formatAmount(l, n, Locale.FRANCE));
            stringBuilder.append(' ');
            stringBuilder.append(string);
            this.appendLineFeed(stringBuilder);
            long l2 = 0L;
            int n3 = (Integer)yP_Row.getFieldValueByName("nbRefund");
            if (n3 > 0) {
                this.appendLineFeed(stringBuilder);
                stringBuilder.append(this.getLabelTranslated("REFUND_TRANSACTION_TYPE", "CREDIT"));
                stringBuilder.append(" : ");
                this.appendLineFeed(stringBuilder);
                stringBuilder.append(n3);
                stringBuilder.append(" trs  / ");
                l2 = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountRefund"));
                stringBuilder.append(UtilsYP.formatAmount(l2, n, Locale.FRANCE));
                stringBuilder.append(' ');
                stringBuilder.append(string);
                this.appendLineFeed(stringBuilder);
            }
            long l3 = 0L;
            int n4 = (Integer)yP_Row.getFieldValueByName("nbReversalDebit");
            if (n4 > 0) {
                this.appendLineFeed(stringBuilder);
                if (bl) {
                    stringBuilder.append("ANNULATION CHEQUE");
                } else {
                    stringBuilder.append(this.getLabelTranslated("REVERSAL_TRANSACTION_TYPE", "ANNULATION"));
                }
                stringBuilder.append(" : ");
                this.appendLineFeed(stringBuilder);
                stringBuilder.append(n4);
                stringBuilder.append(" trs  / ");
                l3 = Long.parseLong(yP_Row.getFieldStringValueByName("totalAmountReversalDebit"));
                stringBuilder.append(UtilsYP.formatAmount(l3, n, Locale.FRANCE));
                stringBuilder.append(' ');
                stringBuilder.append(string);
                this.appendLineFeed(stringBuilder);
            }
            if (l2 <= 0L && l3 <= 0L) continue;
            this.appendLineFeed(stringBuilder);
            this.getLabelTranslated("TOTAL_AMOUNT_LABEL", "MONTANT TOTAL");
            stringBuilder.append(" : ");
            stringBuilder.append(UtilsYP.formatAmount(l - (l2 + l3), n, Locale.FRANCE));
            stringBuilder.append(' ');
            stringBuilder.append(string);
            this.appendLineFeed(stringBuilder);
        }
    }

    private int getAmountFraction(String string) {
        if (string != null && string.contentEquals("XPF")) {
            return 0;
        }
        return 2;
    }

    private static void appendOneContract(boolean bl, StringBuilder stringBuilder, YP_TCD_DCC_Business yP_TCD_DCC_Business, String string) {
        String string2 = yP_TCD_DCC_Business.transaction.getDataBaseConnector().sql_Formater.getContractKeyClause(yP_TCD_DCC_Business.transaction);
        if (!bl) {
            stringBuilder.append("          UNION ALL\r\n");
        }
        stringBuilder.append("          SELECT\r\n");
        stringBuilder.append("              ");
        stringBuilder.append(yP_TCD_DCC_Business.getDataBaseConnector().sql_Formater.sqlDate("transactionAppliLocalTime"));
        stringBuilder.append(" AS dateTmp\r\n");
        stringBuilder.append("              ,transactionType\r\n");
        stringBuilder.append("              ,transactionAmount\r\n");
        stringBuilder.append("              ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("              ,nlpa AS terminalTmp\r\n");
        stringBuilder.append("              ,cashierID AS cashierIDTmp\r\n");
        stringBuilder.append("              FROM " + yP_TCD_DCC_Business.transaction.getFullTableName() + "\r\n");
        stringBuilder.append("              WHERE transactionStatus ='ACCEPTED'\r\n");
        stringBuilder.append(string);
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append("              AND" + string2 + "\r\n");
        }
        stringBuilder.append("          UNION ALL\r\n");
        stringBuilder.append("          SELECT\r\n");
        stringBuilder.append("              ");
        stringBuilder.append(yP_TCD_DCC_Business.getDataBaseConnector().sql_Formater.sqlDate("transactionAppliLocalTime"));
        stringBuilder.append(" AS dateTmp\r\n");
        stringBuilder.append("              ,transactionType\r\n");
        stringBuilder.append("              ,transactionAmount\r\n");
        stringBuilder.append("              ,transactionCurrencyAlpha\r\n");
        stringBuilder.append("              ,nlpa AS terminalTMP\r\n");
        stringBuilder.append("              ,cashierID AS cashierIDTmp\r\n");
        stringBuilder.append("              FROM " + yP_TCD_DCC_Business.transactionArchive.getFullTableName() + "\r\n");
        stringBuilder.append("              WHERE transactionStatus ='ACCEPTED'\r\n");
        stringBuilder.append(string);
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append("              AND" + string2 + "\r\n");
        }
    }

    private static String getFormattedTime(YP_TCD_DCC_Business yP_TCD_DCC_Business, long l) {
        Timestamp timestamp = new Timestamp(yP_TCD_DCC_Business.timeInterface.getAppliLocalTime(l).getTimeInMillis());
        return SessionSummaryReport.getFormattedTime(timestamp);
    }

    private static String getFormattedTime(Timestamp timestamp) {
        String string = timestamp.toString();
        if (string.indexOf(46) > 0) {
            string = string.substring(0, string.indexOf(46));
        }
        return string;
    }

    private List<YP_Row> getSummaryList(YP_Transaction yP_Transaction, Map<YP_TCD_DCC_Merchant, List<YP_TCD_DCC_Business>> map, String string, YP_TCD_DAO_LOC_Table yP_TCD_DAO_LOC_Table, int n) {
        List<YP_Row> list = null;
        for (List<YP_TCD_DCC_Business> list2 : map.values()) {
            YP_TCD_DataBaseConnector yP_TCD_DataBaseConnector = list2.get(0).getDataBaseConnector();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT \r\n");
            stringBuilder.append("        '***' AS date\r\n");
            stringBuilder.append("        ,'***' AS contractIdentifier\r\n");
            stringBuilder.append("        ,transactionCurrencyAlpha\r\n");
            stringBuilder.append("        ,terminalTmp AS terminal\r\n");
            stringBuilder.append("        ,'***' AS cashierID\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ('DEBIT' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT' , 'DEBIT_DIFFERED', 'QUASI_CASH') , 1, 0)) AS nbDebit\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ('DEBIT' , 'CLOSING_PAYMENT' , 'COMPLEMENTARY_PAYMENT', 'DEBIT_DIFFERED', 'QUASI_CASH') , transactionAmount, 0)) AS totalAmountDebit\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , 1, 0)) AS nbRefund\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ( 'CREDIT','COMPLEMENTARY_REFUND', 'REFUND_QUASI_CASH') , transactionAmount, 0)) AS totalAmountRefund\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ('REVERSAL_DEBIT', 'REVERSAL_QUASI_CASH'), 1, 0)) AS nbReversalDebit\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType IN ('REVERSAL_DEBIT', 'REVERSAL_QUASI_CASH'), transactionAmount, 0)) AS totalAmountReversalDebit\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType = 'INITIAL_RESERVATION', 1, 0)) AS nbINITIAL_RESERVATION\r\n");
            stringBuilder.append("        ,SUM(");
            stringBuilder.append(yP_TCD_DataBaseConnector.sql_Formater.sqlIF());
            stringBuilder.append("(transactionType = 'INITIAL_RESERVATION', transactionAmount, 0)) AS totalAmountINITIAL_RESERVATION\r\n");
            stringBuilder.append("FROM\r\n");
            stringBuilder.append("(\r\n");
            YP_TCD_DCC_Business yP_TCD_DCC_Business = null;
            boolean bl = true;
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business2 : list2) {
                if (yP_TCD_DCC_Business2.transaction == null || yP_TCD_DCC_Business2.transactionArchive == null) continue;
                yP_TCD_DCC_Business2.transaction.size();
                if (n == 3 || n == 2) {
                    boolean bl2 = false;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : yP_TCD_DCC_Business2.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_CMC7)) continue;
                        bl2 = true;
                    }
                    if (n == 3 && !bl2 || n == 2 && bl2) continue;
                }
                yP_TCD_DCC_Business = yP_TCD_DCC_Business2;
                SessionSummaryReport.appendOneContract(bl, stringBuilder, yP_TCD_DCC_Business2, string);
                bl = false;
            }
            if (bl) continue;
            stringBuilder.append(") tmp\r\n");
            stringBuilder.append("GROUP BY transactionCurrencyAlpha, terminalTmp");
            list = list2.get((int)0).transaction.getDataBaseConnector().dealSelect((YP_TCD_DesignAccesObject)yP_TCD_DCC_Business.transaction, yP_TCD_DAO_LOC_Table, stringBuilder.toString());
            if (list == null) {
                for (YP_TCD_DCC_Business yP_TCD_DCC_Business2 : list2) {
                    if (yP_TCD_DCC_Business2.transaction == null || yP_TCD_DCC_Business2.transactionArchive == null) continue;
                    yP_TCD_DCC_Business2.transaction.getRowAt(0);
                    yP_TCD_DCC_Business2.transactionArchive.getRowAt(0);
                }
                list = list2.get((int)0).transaction.getDataBaseConnector().dealSelect((YP_TCD_DesignAccesObject)list2.get((int)0).transaction, yP_TCD_DAO_LOC_Table, stringBuilder.toString());
            }
            if (yP_Transaction.getLogLevel() < 5) continue;
            yP_Transaction.logger(5, "doReport() \n" + stringBuilder.toString());
        }
        return list;
    }

    public static int addCurrentGMTTimeMSToResponse(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        String string;
        block3: {
            try {
                string = yP_TCD_DC_Transaction.commonHandler.getResponseAppTags();
                TLVHandler tLVHandler = new TLVHandler(string);
                if (tLVHandler.getTLV(-538803914) == null) break block3;
                return 0;
            }
            catch (Exception exception) {
                yP_TCD_DC_Transaction.logger(2, "addCurrentGMTTimeMSToResponse()  " + exception);
                return -1;
            }
        }
        TLVHandler tLVHandler = new TLVHandler();
        tLVHandler.add(-538803914, UtilsYP.getSystemGMTTime().getTimeInMillis());
        yP_TCD_DC_Transaction.commonHandler.setResponseAppTags(String.valueOf(string) + tLVHandler.toString());
        return 1;
    }

    @Override
    public String ticket(boolean bl, int n) {
        return null;
    }

    @Override
    protected String summaryReport(YP_TCD_PosProtocol.SUB_REQUEST_TYPE sUB_REQUEST_TYPE, List<YP_Row> list) {
        return null;
    }
}

