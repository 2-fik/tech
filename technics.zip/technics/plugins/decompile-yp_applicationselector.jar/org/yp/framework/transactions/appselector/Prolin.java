/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Transaction;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_EFT_Business;
import org.yp.framework.ondemandcomponents.datacontainers.extension.ctcl.YP_TCD_DCB_Interface_CTCL;
import org.yp.framework.ondemandcomponents.datacontainers.extension.productlist.YP_TCD_DCB_Interface_ProductList;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.UpdateHandler;
import org.yp.framework.transactions.appselector.YP_BT_WEB_Mobile;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public abstract class Prolin {
    public static final String PART_MATCH = "0";
    public static final String FULL_MATCH = "1";
    private static final String defaultAdditionalTerminalCapabilities = "600080A001";
    private static final byte[] terminalCapabilitiesMCMagstripe;
    private static final byte[] terminalCapabilitiesMC;
    private static final byte[] terminalCapabilitiesNoCVMMC;
    private static final byte[] terminalCapabilitiesVISA;
    private static final byte[] terminalCapabilitiesNoCVMVISA;
    private static final byte[] defaultTerminalCapabilities;
    private static final byte[] defaultTerminalCapabilitiesNoCVM;
    private static final byte[] terminalCapabilitiesAMEX;
    private static final String defaultVISATTQ = "32204000";
    private static final String defaultVISARefundTTQ = "22800000";
    private static final String defaultUDOL = "9F6A04";

    static {
        byte[] byArray = new byte[3];
        byArray[0] = 96;
        byArray[1] = 32;
        terminalCapabilitiesMCMagstripe = byArray;
        terminalCapabilitiesMC = new byte[]{96, 32, 8};
        terminalCapabilitiesNoCVMMC = new byte[]{96, 8, 8};
        terminalCapabilitiesVISA = new byte[]{96, 32, 64};
        terminalCapabilitiesNoCVMVISA = new byte[]{96, 40, 64};
        defaultTerminalCapabilities = new byte[]{96, 32, 72};
        defaultTerminalCapabilitiesNoCVM = new byte[]{96, 40, 72};
        terminalCapabilitiesAMEX = new byte[]{96, -88, -56};
    }

    public static void dealCTCL_Parameters_Update(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list, List<UpdateHandler.ParameterFile> list2, UpdateHandler.ParameterFile parameterFile, long l) {
        l += 6L;
        try {
            if (parameterFile.headerParameterFile.checksum == null || !parameterFile.headerParameterFile.checksum.contentEquals(Long.toString(l))) {
                UpdateHandler.ParameterFile parameterFile2 = new UpdateHandler.ParameterFile(yP_Transaction.getDataContainerTransaction().updateHandler);
                parameterFile2.headerParameterFile.tableName = parameterFile.headerParameterFile.tableName;
                parameterFile2.headerParameterFile.checksum = Long.toString(l);
                parameterFile2.headerParameterFile.creationTimestamp = UtilsYP.printDateTime(UtilsYP.getSystemGMTTime());
                ConfigObject configObject = new ConfigObject();
                block2: for (YP_TCD_DCC_Business object2 : list) {
                    YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                    if (!object2.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)object2.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                    for (YP_App_Interface_Selection yP_App_Interface_Selection : object2.selectorList) {
                        if (!yP_App_Interface_Selection.canHandle(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS)) continue;
                        Prolin.deallOneCTCLContract(yP_Transaction, object2, yP_TCD_DCB_Interface_CTCL, configObject);
                        continue block2;
                    }
                }
                String string = Prolin.getForbiddenProducts(yP_Transaction, list);
                if (string != null && !string.isEmpty()) {
                    configObject.forbiddenProducts = string;
                }
                Prolin.generateTAGS(parameterFile2.appTagsList, configObject);
                if (parameterFile2.appTagsList.isEmpty()) {
                    if (parameterFile.headerParameterFile.checksum != null && parameterFile.headerParameterFile.checksum.contentEquals(PART_MATCH)) {
                        return;
                    }
                    parameterFile2.headerParameterFile.checksum = PART_MATCH;
                }
                list2.add(parameterFile2);
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "dealCTCL_Parameters_Update() " + exception);
        }
    }

    private static void generateTAGS(List<String> list, ConfigObject configObject) {
        Collections.sort(configObject.ctlsCombinationList);
        for (CtlsCombination ctlsCombination : configObject.ctlsCombinationList) {
            TLVHandler tLVHandler = new TLVHandler();
            tLVHandler.add(156, (long)ctlsCombination.trsType);
            tLVHandler.add(24362, (long)ctlsCombination.currencyCode);
            tLVHandler.add(40705, ctlsCombination.acquirerId);
            tLVHandler.add(40710, ctlsCombination.aid);
            tLVHandler.add(40713, ctlsCombination.appVersionNumber.substring(ctlsCombination.appVersionNumber.length() - 4));
            tLVHandler.add(14672685, ctlsCombination.appVersionNumber);
            tLVHandler.add(40725, ctlsCombination.merchantCategoryCode);
            tLVHandler.addASCII(40726, ctlsCombination.merchantIdentifier);
            tLVHandler.add(40730, ctlsCombination.countryCode);
            tLVHandler.addASCII(40732, ctlsCombination.terminalIdentification);
            tLVHandler.add(40733, ctlsCombination.terminalRiskMgmtData);
            tLVHandler.add(40731, ctlsCombination.terminalFloorLimit);
            tLVHandler.add(40746, (long)ctlsCombination.kernelId);
            tLVHandler.add(40755, ctlsCombination.terminalCapabilities);
            tLVHandler.add(40757, ctlsCombination.terminalType);
            tLVHandler.add(40768, ctlsCombination.additionnalTerminalCapabilities);
            tLVHandler.addASCII(40782, ctlsCombination.merchantNameLocation);
            if (ctlsCombination.tranCategoryCode > 0) {
                tLVHandler.add(40787, (long)ctlsCombination.tranCategoryCode);
            }
            tLVHandler.add(40806, ctlsCombination.ttq);
            if (ctlsCombination.expressPayTerminalCapabilities != null) {
                tLVHandler.add(40813, ctlsCombination.expressPayTerminalCapabilities);
            }
            if (ctlsCombination.expressPayTerminalTransactionCapabilities != null) {
                tLVHandler.add(40814, ctlsCombination.expressPayTerminalTransactionCapabilities);
            }
            if (ctlsCombination.defaultDDOL != null) {
                tLVHandler.add(14672678, ctlsCombination.defaultDDOL);
            }
            if (ctlsCombination.defaultTDOL != null) {
                tLVHandler.add(14672680, ctlsCombination.defaultTDOL);
            }
            String cfr_ignored_0 = ctlsCombination.defaultUDOL;
            tLVHandler.add(14647575, ctlsCombination.cardDataInputCapability);
            tLVHandler.add(14647576, ctlsCombination.chipCapabilityCVMReq);
            tLVHandler.add(14647577, ctlsCombination.chipCapabilityNoCVM);
            tLVHandler.add(14647579, ctlsCombination.kernelConfiguration);
            tLVHandler.add(14647581, (long)ctlsCombination.maxNumberTornTrs);
            tLVHandler.add(14647582, ctlsCombination.magCapabilityNoCVM);
            tLVHandler.add(14647583, ctlsCombination.securityCapability);
            tLVHandler.add(14647596, ctlsCombination.magCapabilityCVMReq);
            tLVHandler.add(14647584, ctlsCombination.tacDefault);
            tLVHandler.add(14647585, ctlsCombination.tacDenial);
            tLVHandler.add(14647586, ctlsCombination.tacOnline);
            tLVHandler.add(14647587, ctlsCombination.readerContactlessFloorLimit);
            tLVHandler.add(14647588, ctlsCombination.readerContactlessTransactionLimitNoOnDevice);
            tLVHandler.add(14647589, ctlsCombination.readerContactlessTransactionLimitOnDevice);
            tLVHandler.add(14647590, ctlsCombination.readerCVMRequiredLimit);
            tLVHandler.add(14672430, (long)ctlsCombination.priority);
            tLVHandler.add(14672175, (Boolean)(ctlsCombination.appSelectionIndicator == 0 ? 1 : 0));
            tLVHandler.add(-538803855, (long)ctlsCombination.statusCheckSupportFlag);
            tLVHandler.add(-538803854, (long)ctlsCombination.zeroAmountAllowedFlag);
            tLVHandler.add(-538803853, (long)ctlsCombination.extendedSelectionSupportFlag);
            if (ctlsCombination.endUserSupportedLanguage != null) {
                int n = 0;
                while (n < ctlsCombination.endUserSupportedLanguage.length() - 1) {
                    tLVHandler.addASCII(14672657, ctlsCombination.endUserSupportedLanguage.substring(n, n + 2));
                    n += 2;
                }
            }
            list.add(tLVHandler.toString());
        }
        TLVHandler tLVHandler = new TLVHandler();
        for (LimitSet limitSet : configObject.ctlsLimitSetList) {
            TLVHandler tLVHandler2 = new TLVHandler();
            tLVHandler2.add(24362, limitSet.currencyCode);
            tLVHandler2.add(24374, limitSet.currencyExponent);
            tLVHandler2.add(40731, limitSet.readerCtlsTermFloorLimit);
            tLVHandler2.add(40746, (long)limitSet.kernelId);
            tLVHandler2.add(40794, limitSet.appProgramId);
            tLVHandler2.add(14647587, limitSet.readerCtlsFloorLimit);
            tLVHandler2.add(14647589, limitSet.readerCtlsTranLimit);
            tLVHandler2.add(14647590, limitSet.readerCVMRequiredLimit);
            tLVHandler2.add(-538803855, (long)limitSet.statusCheckSupportFlag);
            tLVHandler2.add(-538803854, (long)limitSet.zeroAmountAllowedFlag);
            tLVHandler.add(-2064012, tLVHandler2);
        }
        if (!tLVHandler.isEmpty()) {
            list.add(tLVHandler.toString());
        }
        if (configObject.forbiddenProducts != null && !configObject.forbiddenProducts.isEmpty()) {
            list.add(configObject.forbiddenProducts);
        }
    }

    private static String getTerminalType(YP_Transaction yP_Transaction) {
        YP_Row yP_Row = yP_Transaction.getDataContainerTransaction().getTerminalRow();
        if (yP_Row == null) {
            return "22";
        }
        String string = yP_Row.getFieldStringValueByName("terminalType");
        if (string == null || string.isEmpty()) {
            return "22";
        }
        return string;
    }

    private static void deallOneCTCLContract(YP_Transaction yP_Transaction, YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL, ConfigObject configObject) {
        Object object;
        int n = YP_BT_WEB_Mobile.getDefaultNFCCurrencyNumericalCode(yP_TCD_DCC_Business);
        List<YP_Row> list = yP_TCD_DCB_Interface_CTCL.getAIDKIDList(Integer.toString(n));
        block42: for (YP_Row yP_Row : list) {
            object = "";
            String string = "";
            try {
                TLVHandler tLVHandler;
                Object object2;
                CtlsCombination ctlsCombination;
                int n2;
                block79: {
                    block77: {
                        String string2;
                        List<YP_Row> list2;
                        object = yP_Row.getFieldStringValueByName("applicationIdentifier");
                        n2 = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
                        switch (n2) {
                            case 2: 
                            case 3: 
                            case 4: {
                                break;
                            }
                            default: {
                                yP_Transaction.logger(3, "deallOneCTCLContract() kernel not yet handled " + n2);
                                continue block42;
                            }
                        }
                        string = yP_Row.getFieldStringValueByName("transactionType");
                        if (yP_Transaction.getLogLevel() == 6) {
                            yP_Transaction.logger(6, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + n2 + " " + string);
                        }
                        YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_CTCL.getAIDTable();
                        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
                        if (((String)object).length() < 10) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid length invalid: " + ((String)object).length());
                            continue;
                        }
                        String string3 = ((String)object).substring(0, 10);
                        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string3);
                        String string4 = null;
                        if (((String)object).length() > 10) {
                            string4 = ((String)object).substring(10);
                            yP_ComplexGabarit.set("pix", YP_ComplexGabarit.OPERATOR.START_WITH, string4);
                        }
                        if (((list2 = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit)) == null || list2.isEmpty()) && ((list2 = Prolin.getPartialAIDRow(yP_TCD_DesignAccesObject, (String)object)) == null || list2.isEmpty())) {
                            yP_Transaction.logger(3, "deallOneCTCLContract: aid not found for " + (String)object);
                            continue;
                        }
                        ctlsCombination = new CtlsCombination();
                        ctlsCombination.kernelId = n2;
                        ctlsCombination.aid = object;
                        String string5 = yP_TCD_DCC_Business.getCountryCode();
                        while (string5.length() < 4) {
                            string5 = String.valueOf('0') + string5;
                        }
                        ctlsCombination.countryCode = string5;
                        ctlsCombination.terminalType = Prolin.getTerminalType(yP_Transaction);
                        String string6 = yP_Row.getFieldStringValueByName("signatureHandled");
                        if (ctlsCombination.terminalType.contentEquals("25")) {
                            string6 = "false";
                        }
                        String string7 = yP_Row.getFieldStringValueByName("pinOnlineHandled");
                        String string8 = yP_Row.getFieldStringValueByName("noCVMHandled");
                        String string9 = yP_Row.getFieldStringValueByName("onDeviceCVMHandled");
                        if (string.contentEquals("20")) {
                            string9 = "true";
                        }
                        byte[] byArray = UtilsYP.redHexa(defaultVISATTQ);
                        byte[] byArray2 = UtilsYP.redHexa(defaultVISARefundTTQ);
                        if (string6 != null && string6.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 2);
                            byArray2[0] = (byte)(byArray2[0] | 2);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFD);
                            byArray2[0] = (byte)(byArray2[0] & 0xFD);
                        }
                        if (string7 != null && string7.contentEquals("true")) {
                            byArray[0] = (byte)(byArray[0] | 4);
                            byArray2[0] = (byte)(byArray2[0] | 4);
                        } else {
                            byArray[0] = (byte)(byArray[0] & 0xFB);
                            byArray2[0] = (byte)(byArray2[0] & 0xFB);
                        }
                        if (string9 != null && string9.contentEquals("true")) {
                            byArray[2] = (byte)(byArray[2] | 0x40);
                            byArray2[2] = (byte)(byArray2[2] | 0x40);
                        } else {
                            byArray[2] = (byte)(byArray[2] & 0xBF);
                            byArray2[2] = (byte)(byArray2[2] & 0xBF);
                        }
                        switch (string) {
                            case "0": 
                            case "00": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray);
                                break;
                            }
                            case "20": {
                                ctlsCombination.ttq = UtilsYP.devHexa(byArray2);
                            }
                        }
                        ctlsCombination.appSelectionIndicator = 0;
                        ctlsCombination.maxNumberTornTrs = 2;
                        ctlsCombination.zeroAmountAllowedFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport")) ? 1 : 0;
                        ctlsCombination.extendedSelectionSupportFlag = 0;
                        ctlsCombination.readerContactlessFloorLimit = Prolin.getPaddedAmount(yP_Row, "readerContactlessFloorLimit");
                        ctlsCombination.terminalFloorLimit = Prolin.getPaddedAmount(yP_Row, "terminalFloorLimit");
                        ctlsCombination.readerContactlessTransactionLimitNoOnDevice = Prolin.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitNoOnDevice");
                        ctlsCombination.readerContactlessTransactionLimitOnDevice = Prolin.getPaddedAmount(yP_Row, "readerContactlessTransactionLimitOnDevice");
                        ctlsCombination.readerCVMRequiredLimit = Prolin.getPaddedAmount(yP_Row, "readerCVMRequiredLimit");
                        int n3 = ctlsCombination.statusCheckSupportFlag = UtilsYP.isTrue(yP_Row.getFieldStringValueByName("statusCheckSupport")) ? 1 : 0;
                        if (yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business) {
                            ctlsCombination.endUserSupportedLanguage = ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).getEndUserLangageList(yP_Transaction.getDataContainerTransaction());
                        }
                        try {
                            int n4;
                            ctlsCombination.priority = n4 = ((Integer)list2.get(0).getFieldValueByName("priority")).intValue();
                        }
                        catch (Exception exception) {
                            yP_Transaction.logger(2, "deallOneCTCLContract(): While processing priority: " + (String)object, exception);
                        }
                        ctlsCombination.currencyCode = Integer.parseInt(yP_Row.getFieldStringValueByName("numericalCurrencyCode"));
                        switch (string) {
                            case "0": 
                            case "00": {
                                ctlsCombination.trsType = 0;
                                break;
                            }
                            case "20": {
                                ctlsCombination.trsType = 20;
                                break;
                            }
                            default: {
                                yP_Transaction.logger(2, "deallOneCTCLContract(): row ignored : " + (String)object + " " + n2 + " " + string);
                                continue block42;
                            }
                        }
                        configObject.ctlsCombinationList.add(ctlsCombination);
                        ctlsCombination.additionnalTerminalCapabilities = defaultAdditionalTerminalCapabilities;
                        ctlsCombination.merchantNameLocation = yP_TCD_DCC_Business.getMerchantName();
                        ctlsCombination.acquirerId = yP_TCD_DCC_Business.getAcquiringInstitutionIdentificationCode();
                        if (ctlsCombination.acquirerId.length() % 2 == 1) {
                            ctlsCombination.acquirerId = PART_MATCH + ctlsCombination.acquirerId;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        int n5 = 0;
                        while (n5 < list2.size()) {
                            int n6 = (Integer)list2.get(n5).getFieldValueByName("terminalApplicationVersionNumber");
                            stringBuilder.append(String.format("%4s", Integer.toHexString(n6)).replace(' ', '0'));
                            ++n5;
                        }
                        ctlsCombination.appVersionNumber = stringBuilder.toString();
                        byte[] byArray3 = new byte[defaultTerminalCapabilities.length];
                        switch (n2) {
                            case 2: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMMC);
                                System.arraycopy(terminalCapabilitiesMC, 0, byArray3, 0, terminalCapabilitiesMC.length);
                                break;
                            }
                            case 3: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesNoCVMVISA);
                                System.arraycopy(terminalCapabilitiesVISA, 0, byArray3, 0, terminalCapabilitiesVISA.length);
                                break;
                            }
                            case 4: {
                                string2 = UtilsYP.devHexa(terminalCapabilitiesAMEX);
                                System.arraycopy(terminalCapabilitiesAMEX, 0, byArray3, 0, terminalCapabilitiesAMEX.length);
                                break;
                            }
                            default: {
                                string2 = UtilsYP.devHexa(defaultTerminalCapabilitiesNoCVM);
                                System.arraycopy(defaultTerminalCapabilities, 0, byArray3, 0, defaultTerminalCapabilities.length);
                            }
                        }
                        byArray3[1] = string6 != null && string6.contentEquals("true") ? (byte)(byArray3[1] | 0x20) : (byte)(byArray3[1] & 0xDF);
                        byArray3[1] = string7 != null && string7.contentEquals("true") ? (byte)(byArray3[1] | 0x40) : (byte)(byArray3[1] & 0xBF);
                        byArray3[1] = string8 != null && string8.contentEquals("true") ? (byte)(byArray3[1] | 8) : (byte)(byArray3[1] & 0xF7);
                        ctlsCombination.terminalCapabilities = UtilsYP.devHexa(byArray3);
                        ctlsCombination.cardDataInputCapability = UtilsYP.devHexa(byArray3).substring(0, 2);
                        ctlsCombination.chipCapabilityCVMReq = UtilsYP.devHexa(byArray3).substring(2, 4);
                        ctlsCombination.chipCapabilityNoCVM = string2.substring(2, 4);
                        ctlsCombination.securityCapability = UtilsYP.devHexa(byArray3).substring(4, 6);
                        ctlsCombination.terminalIdentification = yP_TCD_DCC_Business.getTerminalIdentification();
                        if (n2 != 2) break block77;
                        object2 = new byte[1];
                        if (UtilsYP.isTrue(string9)) {
                            object2[0] = (byte)(object2[0] | 0x20);
                        }
                        switch (object) {
                            case "A0000000043060": 
                            case "A0000000422010": 
                            case "A0000000425010": {
                                object2[0] = (byte)(object2[0] | 0x80);
                                if (Prolin.getTerminalType(yP_Transaction).contentEquals("25")) {
                                    ctlsCombination.terminalRiskMgmtData = "0C00800000000000";
                                    break;
                                }
                                ctlsCombination.terminalRiskMgmtData = "2C00800000000000";
                                break;
                            }
                            default: {
                                ctlsCombination.terminalRiskMgmtData = Prolin.getTerminalType(yP_Transaction).contentEquals("25") ? "0C00000000000000" : "2C00000000000000";
                            }
                        }
                        ctlsCombination.kernelConfiguration = UtilsYP.devHexa((byte[])object2);
                        break block79;
                    }
                    ctlsCombination.terminalRiskMgmtData = "0000000000000000";
                    ctlsCombination.kernelConfiguration = "00";
                }
                if (n2 == 4) {
                    ctlsCombination.expressPayTerminalCapabilities = "C0";
                    ctlsCombination.expressPayTerminalTransactionCapabilities = "D8A00000";
                }
                ctlsCombination.magCapabilityNoCVM = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsCombination.magCapabilityCVMReq = UtilsYP.devHexa(terminalCapabilitiesMCMagstripe).substring(2, 4);
                ctlsCombination.merchantCategoryCode = String.format("%04d", Integer.parseInt(yP_TCD_DCC_Business.getMerchantCategoryCode()));
                ctlsCombination.merchantIdentifier = yP_TCD_DCC_Business.getCommercialRegisterNumber();
                while (ctlsCombination.merchantIdentifier.length() < 15) {
                    ctlsCombination.merchantIdentifier = String.valueOf(ctlsCombination.merchantIdentifier) + " ";
                }
                ctlsCombination.tacOnline = yP_Row.getFieldStringValueByName("tacOnline");
                ctlsCombination.tacDefault = yP_Row.getFieldStringValueByName("tacDefault");
                ctlsCombination.tacDenial = yP_Row.getFieldStringValueByName("tacDenial");
                ctlsCombination.tranCategoryCode = 0;
                object2 = yP_TCD_DCB_Interface_CTCL.getAIDParameters((String)object);
                if (object2 == null) continue;
                Object object3 = ((YP_Row)object2).getFieldStringValueByName("specificData");
                if (object3 != null && !((String)object3).isEmpty() && (tLVHandler = new TLVHandler((String)object3)) != null) {
                    for (TLV tLV : tLVHandler) {
                        switch (tLV.tag) {
                            case 40787: {
                                ctlsCombination.tranCategoryCode = Integer.parseInt(UtilsYP.devHexa(tLV.value), 16);
                                break;
                            }
                            case 57103: {
                                break;
                            }
                        }
                    }
                }
                ctlsCombination.defaultDDOL = ((YP_Row)object2).getFieldStringValueByName("defaultDDOL");
                ctlsCombination.defaultTDOL = ((YP_Row)object2).getFieldStringValueByName("defaultTDOL");
                ctlsCombination.defaultUDOL = defaultUDOL;
            }
            catch (Exception exception) {
                yP_Transaction.logger(2, "deallOneCTCLContract(): process contactless aid: " + (String)object + " " + string, exception);
            }
        }
        for (YP_Row yP_Row : yP_TCD_DCB_Interface_CTCL.getDRLTable()) {
            object = Prolin.fillInLimitSet(yP_TCD_DCC_Business, yP_Row);
            if (object == null) continue;
            configObject.ctlsLimitSetList.add((LimitSet)object);
        }
    }

    private static String getForbiddenProducts(YP_Transaction yP_Transaction, List<YP_TCD_DCC_Business> list) {
        TLVHandler tLVHandler = new TLVHandler();
        try {
            HashMap hashMap = new HashMap();
            for (YP_TCD_DCC_Business yP_TCD_DCC_Business : list) {
                YP_TCD_DCB_Interface_CTCL yP_TCD_DCB_Interface_CTCL;
                YP_TCD_DCB_Interface_ProductList yP_TCD_DCB_Interface_ProductList;
                if (!yP_TCD_DCC_Business.getActivationCode().contentEquals(FULL_MATCH) || (yP_TCD_DCB_Interface_ProductList = (YP_TCD_DCB_Interface_ProductList)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_ProductList.class)) == null || (yP_TCD_DCB_Interface_CTCL = (YP_TCD_DCB_Interface_CTCL)yP_TCD_DCC_Business.getExtensionByType(YP_TCD_DCB_Interface_CTCL.class)) == null || !yP_TCD_DCB_Interface_CTCL.isActive()) continue;
                YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject = yP_TCD_DCB_Interface_ProductList.getProductListTable();
                for (YP_Row yP_Row : yP_TCD_DesignAccesObject) {
                    String string;
                    String string2;
                    String string3 = yP_Row.getFieldStringValueByName("emvApplicationAID");
                    if (string3 == null || string3.isEmpty()) {
                        yP_Transaction.logger(4, "getForbiddenProducts() maybe a product indexed by BIN");
                        continue;
                    }
                    ArrayList<String> arrayList = (ArrayList<String>)hashMap.get(string3);
                    if (arrayList == null) {
                        arrayList = new ArrayList<String>();
                        hashMap.put(string3, arrayList);
                    }
                    if ((string2 = yP_Row.getFieldStringValueByName("electronicProductIdentification")) == null || string2.isEmpty()) {
                        string2 = "0001";
                    }
                    if ((string = yP_Row.getFieldStringValueByName("codeProduit")) == null || string.isEmpty()) {
                        yP_Transaction.logger(3, "getForbiddenProducts() product code missing!!!");
                        continue;
                    }
                    if (arrayList.contains(string)) continue;
                    arrayList.add(string);
                    TLVHandler tLVHandler2 = new TLVHandler();
                    tLVHandler2.add(-538738400, string3);
                    tLVHandler2.add(-538738370, string2);
                    tLVHandler2.add(-538738369, string);
                    tLVHandler.add(-2064064, tLVHandler2);
                }
            }
        }
        catch (Exception exception) {
            yP_Transaction.logger(2, "getForbiddenProducts() ", exception);
        }
        return tLVHandler.toString();
    }

    private static LimitSet fillInLimitSet(YP_TCD_DCC_Business yP_TCD_DCC_Business, YP_Row yP_Row) {
        LimitSet limitSet = new LimitSet();
        String string = yP_Row.getFieldStringValueByName("statusCheckSupport");
        limitSet.statusCheckSupportFlag = string != null && string.contentEquals(PART_MATCH) ? 1 : 0;
        String string2 = yP_Row.getFieldStringValueByName("zeroAmountAllowedSupport");
        limitSet.zeroAmountAllowedFlag = string2 != null && string2.contentEquals(PART_MATCH) ? 1 : 0;
        limitSet.readerCVMRequiredLimit = Prolin.getPaddedAmount(yP_Row, "CVMRequiredLimit");
        limitSet.readerCVMRequiredLimit.contentEquals("999999999999");
        limitSet.readerCtlsTermFloorLimit = Prolin.getPaddedAmount(yP_Row, "ctlFloorLimit");
        limitSet.readerCtlsTermFloorLimit.contentEquals("999999999999");
        limitSet.readerCtlsFloorLimit = Prolin.getPaddedAmount(yP_Row, "ctlFloorLimit");
        limitSet.appProgramId = yP_Row.getFieldStringValueByName("applicationPgmId");
        limitSet.readerCtlsTranLimit = Prolin.getPaddedAmount(yP_Row, "ctlTransactionLimit");
        limitSet.kernelId = Integer.parseInt(yP_Row.getFieldStringValueByName("kernelID"));
        limitSet.currencyCode = yP_Row.getFieldStringValueByName("numericalCurrencyCode");
        while (limitSet.currencyCode.length() < 4) {
            limitSet.currencyCode = PART_MATCH + limitSet.currencyCode;
        }
        limitSet.currencyExponent = yP_TCD_DCC_Business instanceof YP_TCD_DCC_EFT_Business && ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface != null ? String.format("%02d", ((YP_TCD_DCC_EFT_Business)yP_TCD_DCC_Business).currencyInterface.getCurrencyFraction(Integer.parseInt(limitSet.currencyCode))) : "02";
        limitSet.appSelectionIndicator = 0;
        return limitSet;
    }

    private static List<YP_Row> getPartialAIDRow(YP_TCD_DesignAccesObject yP_TCD_DesignAccesObject, String string) {
        ArrayList<YP_Row> arrayList = new ArrayList<YP_Row>();
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(yP_TCD_DesignAccesObject);
        String string2 = string.substring(0, 10);
        yP_ComplexGabarit.set("rid", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("partialSelectionAllowed", YP_ComplexGabarit.OPERATOR.EQUAL, true);
        List<YP_Row> list = yP_TCD_DesignAccesObject.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.size() == 0) {
            return null;
        }
        for (YP_Row yP_Row : list) {
            String string3 = yP_Row.getFieldStringValueByName("pix");
            if (!string.startsWith(String.valueOf(string2) + string3)) continue;
            arrayList.add(yP_Row);
        }
        return arrayList;
    }

    private static String getPaddedAmount(YP_Row yP_Row, String string) {
        StringBuilder stringBuilder = new StringBuilder(yP_Row.getFieldStringValueByName(string));
        while (stringBuilder.length() < 12) {
            stringBuilder.insert(0, PART_MATCH);
        }
        return stringBuilder.toString();
    }

    static class ConfigObject {
        List<CtlsCombination> ctlsCombinationList = new ArrayList<CtlsCombination>();
        List<LimitSet> ctlsLimitSetList = new ArrayList<LimitSet>();
        String forbiddenProducts;

        ConfigObject() {
        }
    }

    static class CtlsCombination
    implements Comparable<CtlsCombination> {
        int trsType;
        int kernelId;
        String aid;
        String terminalCapabilities;
        String additionnalTerminalCapabilities;
        String terminalType;
        String countryCode;
        String merchantCategoryCode;
        String merchantIdentifier;
        String appVersionNumber;
        String terminalIdentification;
        String merchantNameLocation;
        String acquirerId;
        String ttq;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int extendedSelectionSupportFlag;
        int maxNumberTornTrs;
        String terminalFloorLimit;
        String readerContactlessFloorLimit;
        String readerCtlsTrnsLimit;
        String readerContactlessTransactionLimitNoOnDevice;
        String readerContactlessTransactionLimitOnDevice;
        String readerCVMRequiredLimit;
        int statusCheckSupportFlag;
        int currencyCode;
        int priority;
        String chipCapabilityCVMReq;
        String chipCapabilityNoCVM;
        String magCapabilityNoCVM;
        String magCapabilityCVMReq;
        String tacDefault;
        String tacDenial;
        String tacOnline;
        String kernelConfiguration;
        String securityCapability;
        String cardDataInputCapability;
        int tranCategoryCode;
        String terminalRiskMgmtData;
        String endUserSupportedLanguage;
        String expressPayTerminalCapabilities;
        String expressPayTerminalTransactionCapabilities;
        String defaultDDOL;
        String defaultTDOL;
        String defaultUDOL;

        CtlsCombination() {
        }

        @Override
        public int compareTo(CtlsCombination ctlsCombination) {
            return this.kernelId - ctlsCombination.kernelId;
        }
    }

    static class LimitSet {
        int kernelId;
        String currencyCode;
        String appProgramId;
        int appSelectionIndicator;
        int zeroAmountAllowedFlag;
        int statusCheckSupportFlag;
        String readerCVMRequiredLimit;
        String readerCtlsFloorLimit;
        String readerCtlsTranLimit;
        String readerCtlsTermFloorLimit;
        String currencyExponent;

        LimitSet() {
        }
    }
}

