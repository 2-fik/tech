/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.transactions.appselector;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.EntryModeEnumeration;

public class ApduHandler {
    private StringBuilder constructedEMVTags = new StringBuilder();

    public void getApduDataFromProtocol(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        if (yP_TCD_DC_Transaction == null) {
            return;
        }
        String string = yP_TCD_DC_Transaction.commonHandler.getRequestAppTags();
        if (string == null || string.isEmpty()) {
            return;
        }
        try {
            TLVHandler tLVHandler = new TLVHandler(string);
            TLV tLV = tLVHandler.getTLV(-538738347);
            if (tLV == null) {
                return;
            }
            this.getEMVData(yP_TCD_DC_Transaction, tLV.value);
            yP_TCD_DC_Transaction.commonHandler.setPaymentTechnology(EntryModeEnumeration.ENTRY_MODE_EMV_CONTACTLESS);
        }
        catch (Exception exception) {
            yP_TCD_DC_Transaction.logger(2, "getApduDataFromProtocol: ", exception);
            return;
        }
    }

    private String getEMVData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            return null;
        }
        int n = 0;
        int n2 = byArray.length;
        StringBuilder stringBuilder = new StringBuilder();
        while (n < n2) {
            int n3 = byArray[n + 4] & 0xFF;
            if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                yP_TCD_DC_Transaction.logger(5, "getEMVData() apduLength: " + n3);
            }
            byte[] byArray2 = new byte[n3 -= 2];
            byte by = byArray[n + 1];
            if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                yP_TCD_DC_Transaction.logger(5, "getEMVData() CLA: " + String.format("%x", byArray[n]) + " INS: " + String.format("%x", byArray[n + 1]));
            }
            if (by == -82) {
                this.getInitialData(yP_TCD_DC_Transaction);
            }
            System.arraycopy(byArray, n + 5, byArray2, 0, n3);
            this.manageEmvTemplate(yP_TCD_DC_Transaction, byArray2);
            stringBuilder.append(UtilsYP.devHexa(byArray2));
            n = n + 5 + n3 + 2;
        }
        this.constructedEMVTags.append("9F3303E0B8C8");
        this.constructedEMVTags.append("9f0607A0000000041010");
        yP_TCD_DC_Transaction.commonHandler.setRequestEMVTags(this.constructedEMVTags.toString());
        return stringBuilder.toString();
    }

    private boolean fillEmvDatas(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, TLVHandler tLVHandler) {
        try {
            Object object2;
            AccountHandler.ADF aDF = new AccountHandler.ADF(yP_TCD_DC_Transaction.accountHandler);
            for (Object object2 : tLVHandler) {
                switch (((TLV)object2).tag) {
                    case 132: {
                        aDF.aid = UtilsYP.devHexa(((TLV)object2).value);
                        break;
                    }
                    case 135: {
                        aDF.priorityIndicator = UtilsYP.devHexa(((TLV)object2).value);
                        break;
                    }
                    case 80: {
                        aDF.label = UtilsYP.devHexa(((TLV)object2).value);
                        break;
                    }
                    case 40722: {
                        aDF.preferredName = UtilsYP.devHexa(((TLV)object2).value);
                        break;
                    }
                }
            }
            object2 = new ArrayList();
            object2.add(aDF);
            yP_TCD_DC_Transaction.accountHandler.setADFList((List<AccountHandler.ADF>)object2);
        }
        catch (Exception exception) {
            return false;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void getInitialData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        try {
            try {
                fileReader = new FileReader("initialEmvData.txt");
                bufferedReader = new BufferedReader(fileReader);
                String string = bufferedReader.readLine();
                if (string == null) return;
                this.constructedEMVTags.append(string);
                try {
                    TLVHandler tLVHandler = new TLVHandler(string);
                    this.fillEmvDatas(yP_TCD_DC_Transaction, tLVHandler);
                    return;
                }
                catch (Exception exception) {}
                return;
            }
            catch (FileNotFoundException fileNotFoundException) {
                yP_TCD_DC_Transaction.logger(2, "getInitialData: " + fileNotFoundException.toString());
                if (fileReader == null) return;
                try {
                    fileReader.close();
                    return;
                }
                catch (IOException iOException) {
                    yP_TCD_DC_Transaction.logger(2, "getInitialData: " + iOException.toString());
                }
                return;
            }
            catch (IOException iOException) {
                yP_TCD_DC_Transaction.logger(2, "getInitialData: " + iOException.toString());
                if (fileReader == null) return;
                try {
                    fileReader.close();
                    return;
                }
                catch (IOException iOException2) {
                    yP_TCD_DC_Transaction.logger(2, "getInitialData: " + iOException2.toString());
                }
                return;
            }
        }
        finally {
            if (fileReader != null) {
                try {
                    fileReader.close();
                }
                catch (IOException iOException) {
                    yP_TCD_DC_Transaction.logger(2, "getInitialData: " + iOException.toString());
                }
            }
        }
    }

    private void manageEmvTemplate(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            return;
        }
        int n = 0;
        switch (byArray[n++]) {
            case 111: {
                int n2 = byArray[n++] & 0xFF;
                byte[] byArray2 = new byte[n2];
                System.arraycopy(byArray, n, byArray2, 0, n2);
                this.parseSelectData(yP_TCD_DC_Transaction, byArray2);
                break;
            }
            case 112: 
            case 119: {
                int n3 = byArray[n++] & 0xFF;
                if (n3 > 127) {
                    n3 = byArray[n++] & 0xFF;
                }
                byte[] byArray3 = new byte[n3];
                System.arraycopy(byArray, n, byArray3, 0, n3);
                if (yP_TCD_DC_Transaction.getLogLevel() >= 5) {
                    yP_TCD_DC_Transaction.logger(5, "getEMVData() apduCommand: " + UtilsYP.devHexa(byArray3));
                }
                this.constructedEMVTags.append(UtilsYP.devHexa(byArray3));
                break;
            }
            default: {
                yP_TCD_DC_Transaction.logger(2, "unknown template: " + byArray[0]);
            }
        }
    }

    private void parseSelectData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        Object object;
        if (byArray == null || byArray.length == 0) {
            return;
        }
        int n = 0;
        boolean bl = false;
        AccountHandler.ADF aDF = new AccountHandler.ADF(yP_TCD_DC_Transaction.accountHandler);
        StringBuilder stringBuilder = new StringBuilder();
        while (n < byArray.length) {
            switch (byArray[n]) {
                case -124: {
                    int n2 = ++n;
                    int n3 = byArray[n2] & 0xFF;
                    object = new byte[n3];
                    System.arraycopy(byArray, ++n, object, 0, n3);
                    stringBuilder.append("84" + String.format("%02x", n3) + UtilsYP.devHexa((byte[])object));
                    if (object[0] != 50) {
                        bl = true;
                        aDF.aid = UtilsYP.devHexa((byte[])object);
                    }
                    n += n3;
                    break;
                }
                case -91: {
                    int n4 = ++n;
                    int n3 = byArray[n4] & 0xFF;
                    byte[] byArray2 = new byte[n3];
                    System.arraycopy(byArray, ++n, byArray2, 0, n3);
                    stringBuilder.append(UtilsYP.devHexa(byArray2));
                    this.parseADFData(yP_TCD_DC_Transaction, byArray2, aDF);
                    n += n3;
                }
            }
        }
        if (bl) {
            object = new ArrayList<AccountHandler.ADF>();
            object.add(aDF);
            yP_TCD_DC_Transaction.accountHandler.setADFList((List<AccountHandler.ADF>)object);
            this.constructedEMVTags.append("9F2A0102");
            this.constructedEMVTags.append((CharSequence)stringBuilder);
        }
    }

    private AccountHandler.ADF parseADFData(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray, AccountHandler.ADF aDF) {
        int n = 0;
        while (n < byArray.length) {
            block0 : switch (byArray[n++]) {
                case 80: {
                    String string;
                    byte by = byArray[n++];
                    byte[] byArray2 = new byte[by];
                    System.arraycopy(byArray, n, byArray2, 0, by);
                    aDF.label = string = UtilsYP.devHexa(byArray2);
                    n += by;
                    break;
                }
                case -121: {
                    String string;
                    byte by = byArray[n++];
                    byte[] byArray2 = new byte[by];
                    System.arraycopy(byArray, n, byArray2, 0, by);
                    aDF.priorityIndicator = string = UtilsYP.devHexa(byArray2);
                    n += by;
                    break;
                }
                case -97: {
                    byte[] byArray2;
                    byte by;
                    switch (byArray[n++]) {
                        case 56: {
                            by = byArray[n++];
                            byArray2 = new byte[by];
                            System.arraycopy(byArray, n, byArray2, 0, by);
                            UtilsYP.devHexa(byArray2);
                            n += by;
                            break block0;
                        }
                    }
                    yP_TCD_DC_Transaction.logger(2, "parseADFData()  ERROR Unknown or unexpected EMV TAG");
                    break;
                }
                case -65: {
                    byte[] byArray2;
                    byte by;
                    switch (byArray[n++]) {
                        case 12: {
                            by = byArray[n++];
                            byArray2 = new byte[by];
                            System.arraycopy(byArray, n, byArray2, 0, by);
                            this.parseBF0CTemplate(yP_TCD_DC_Transaction, byArray2);
                            n += by;
                            break block0;
                        }
                    }
                    yP_TCD_DC_Transaction.logger(2, "parseADFData()  ERROR Unknown or unexpected EMV TAG");
                }
            }
        }
        return aDF;
    }

    private void parseBF0CTemplate(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            return;
        }
        int n = 0;
        while (n < byArray.length) {
            block0 : switch (byArray[n++]) {
                case 97: {
                    int n2 = byArray[n++] & 0xFF;
                    byte[] byArray2 = new byte[n2];
                    System.arraycopy(byArray, n, byArray2, 0, n2);
                    this.parse61Template(yP_TCD_DC_Transaction, byArray2);
                    n += n2;
                    break;
                }
                case -33: {
                    byte[] byArray2;
                    int n2;
                    switch (byArray[n++]) {
                        case 32: {
                            n2 = byArray[n++];
                            byArray2 = new byte[n2];
                            System.arraycopy(byArray, n, byArray2, 0, n2);
                            UtilsYP.devHexa(byArray2);
                            n += n2;
                            break block0;
                        }
                    }
                    yP_TCD_DC_Transaction.logger(2, "parseBF0CTemplate()  ERROR parseBF0CTemplate Unknown or unexpected EMV TAG DF" + byArray[n - 1]);
                    break;
                }
                case -97: {
                    byte[] byArray2;
                    int n2;
                    switch (byArray[n++]) {
                        case 110: {
                            n2 = byArray[n++];
                            byArray2 = new byte[n2];
                            System.arraycopy(byArray, n, byArray2, 0, n2);
                            UtilsYP.devHexa(byArray2);
                            n += n2;
                            break block0;
                        }
                        case 93: {
                            n2 = byArray[n++];
                            byArray2 = new byte[n2];
                            System.arraycopy(byArray, n, byArray2, 0, n2);
                            UtilsYP.devHexa(byArray2);
                            n += n2;
                            break block0;
                        }
                    }
                    yP_TCD_DC_Transaction.logger(2, "parseBF0CTemplate()  ERROR parseBF0CTemplate Unknown or unexpected EMV TAG DF" + byArray[n - 1]);
                    break;
                }
                default: {
                    yP_TCD_DC_Transaction.logger(2, "parseBF0CTemplate() unknown template: " + byArray[0]);
                }
            }
        }
    }

    private void parse61Template(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            return;
        }
        int n = 0;
        while (n < byArray.length) {
            block0 : switch (byArray[n++]) {
                case 79: {
                    int n2 = byArray[n++] & 0xFF;
                    byte[] byArray2 = new byte[n2];
                    System.arraycopy(byArray, n, byArray2, 0, n2);
                    n += n2;
                    break;
                }
                case -121: {
                    int n2 = byArray[n++] & 0xFF;
                    byte[] byArray2 = new byte[n2];
                    System.arraycopy(byArray, n, byArray2, 0, n2);
                    n += n2;
                    break;
                }
                case -97: {
                    byte[] byArray2;
                    int n2;
                    switch (byArray[n++]) {
                        case 42: {
                            n2 = byArray[n++];
                            byArray2 = new byte[n2];
                            System.arraycopy(byArray, n, byArray2, 0, n2);
                            UtilsYP.devHexa(byArray2);
                            n += n2;
                            break block0;
                        }
                    }
                    yP_TCD_DC_Transaction.logger(2, "parse61Template() Unknown or unexpected EMV TAG DF" + byArray[n - 1]);
                    break;
                }
                default: {
                    yP_TCD_DC_Transaction.logger(2, "parse61Template() unknown template: " + byArray[0]);
                }
            }
        }
    }

    private void parse77Template(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, byte[] byArray) {
        if (byArray == null || byArray.length == 0) {
            return;
        }
        int n = 0;
        while (n < byArray.length) {
            switch (byArray[n++]) {
                case -126: {
                    int n2 = byArray[n++] & 0xFF;
                    byte[] byArray2 = new byte[n2];
                    System.arraycopy(byArray, n, byArray2, 0, n2);
                    n += n2;
                    break;
                }
                case -108: {
                    int n2 = byArray[n++] & 0xFF;
                    byte[] byArray2 = new byte[n2];
                    System.arraycopy(byArray, n, byArray2, 0, n2);
                    n += n2;
                    break;
                }
                default: {
                    yP_TCD_DC_Transaction.logger(2, "parse77Template() unknown template: " + byArray[0]);
                }
            }
        }
    }

    public class TLVContainer {
        String tag;
        int longueur;
        String valeur;
        byte[] tlvValue;
    }
}

