/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.appselectors.cmc7;

import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;

public class YP_BCD_A_SEL_STD_CMC7
extends YP_OnDemandComponent
implements YP_App_Interface_Selection {
    public YP_BCD_A_SEL_STD_CMC7(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TS_GlobalProcessManager) {
            return;
        }
        if (!(yP_Object instanceof YP_TCD_DCC_Business)) {
            this.logger(2, "YP_BCD_A_SEL_STD_CMC7() father must be a data container business");
            throw new Exception();
        }
        ((YP_TCD_DCC_Business)yP_Object).selectorList.add(this);
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "ApplicationSelectorCMC7";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    @Override
    public AcceptationLevelEnumeration getAcceptationLevel(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            if (this.canHandle(yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology())) {
                return AcceptationLevelEnumeration.ACCEPTED;
            }
        }
        catch (Exception exception) {
            this.logger(2, "getAcceptationLevel() " + exception);
        }
        return AcceptationLevelEnumeration.UNKNOWN;
    }

    @Override
    public boolean canHandle(EntryModeEnumeration entryModeEnumeration) {
        if (entryModeEnumeration == null) {
            return false;
        }
        switch (entryModeEnumeration) {
            case ENTRY_MODE_CMC7: 
            case ENTRY_MODE_CMC7_KEYED: {
                return true;
            }
        }
        return false;
    }
}

