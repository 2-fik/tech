/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.appselectors.aid;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_ComplexGabarit;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_Application;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.Bitmap;
import org.yp.utils.TLV;
import org.yp.utils.TLVHandler;
import org.yp.utils.UtilsYP;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;
import org.yp.utils.enums.TransactionTypeEnumeration;

public class YP_BCD_A_SEL_STD_TT_PRODUCT_AID
extends YP_OnDemandComponent
implements YP_App_Interface_Selection {
    private YP_TCD_DesignAccesObject daoAID;
    private YP_TCD_DesignAccesObject daoProductList;
    private YP_TCD_DesignAccesObject daoSchemeParameters;
    List<List<SelectorEnreg>> selectorListByPriority;

    public YP_BCD_A_SEL_STD_TT_PRODUCT_AID(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TS_GlobalProcessManager) {
            return;
        }
        if (!(yP_Object instanceof YP_TCD_DCC_Business)) {
            this.logger(2, "YP_BCD_A_SEL_STD_TT_PRODUCT_AID() father must be a data container business");
            throw new Exception();
        }
        ((YP_TCD_DCC_Business)yP_Object).selectorList.add(this);
        if (objectArray == null || objectArray.length < 1) {
            this.logger(2, "YP_BCD_A_SEL_STD_TT_PRODUCT_AID() bad number of parameters");
            throw new Exception();
        }
        if (objectArray[0] == null || !(objectArray[0] instanceof YP_TCD_DesignAccesObject)) {
            this.logger(2, "YP_BCD_A_SEL_STD_TT_PRODUCT_AID() bad parameter 1");
            throw new Exception();
        }
        this.daoAID = (YP_TCD_DesignAccesObject)objectArray[0];
        this.daoAID.registerWatcher(this.getProcessID());
        if (objectArray[1] != null) {
            this.daoProductList = (YP_TCD_DesignAccesObject)objectArray[1];
            this.daoProductList.registerWatcher(this.getProcessID());
        }
        if (objectArray.length > 2 && objectArray[2] != null) {
            this.daoSchemeParameters = (YP_TCD_DesignAccesObject)objectArray[2];
            this.daoSchemeParameters.registerWatcher(this.getProcessID());
        }
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "ApplicationSelectorByAIDAndProductAndTransactionType";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private int reloadIfNeeded() {
        if (this.selectorListByPriority == null || this.daoAID.getProcessID() == this.getNotification() || this.daoProductList.getProcessID() == this.getNotification() || this.daoSchemeParameters.getProcessID() == this.getNotification()) {
            return this.initialiseSelectorList();
        }
        return 0;
    }

    private boolean isForbiddenProduct(String string, String string2, String string3) {
        if (this.daoProductList == null || this.daoProductList.size() <= 0) {
            return false;
        }
        String string4 = UtilsYP.padString(string3, 10, '0');
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.daoProductList);
        yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.EQUAL, string);
        yP_ComplexGabarit.set("electronicProductIdentification", YP_ComplexGabarit.OPERATOR.EQUAL, string2);
        yP_ComplexGabarit.set("codeProduit", YP_ComplexGabarit.OPERATOR.EQUAL, string4);
        return this.daoProductList.getCountSuchAs(yP_ComplexGabarit) > 0;
    }

    private int initialiseSelectorList() {
        try {
            this.daoAID.lock();
            this.selectorListByPriority = new ArrayList<List<SelectorEnreg>>();
            for (YP_Row yP_Row : this.daoAID) {
                String string = String.valueOf(yP_Row.getFieldStringValueByName("rid")) + yP_Row.getFieldStringValueByName("pix");
                Boolean bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed");
                int n = (Integer)yP_Row.getFieldValueByName("priority");
                List<SelectorEnreg> list = null;
                int n2 = 0;
                while (n2 < this.selectorListByPriority.size()) {
                    List<SelectorEnreg> list2 = this.selectorListByPriority.get(n2);
                    if (list2.get((int)0).priority == n) {
                        list = list2;
                        break;
                    }
                    if (list2.get((int)0).priority < n) {
                        list = new ArrayList();
                        this.selectorListByPriority.add(n2, list);
                        break;
                    }
                    ++n2;
                }
                if (list == null) {
                    list = new ArrayList<SelectorEnreg>();
                    this.selectorListByPriority.add(list);
                }
                n2 = 0;
                for (SelectorEnreg selectorEnreg : list) {
                    if (!selectorEnreg.aid.contentEquals(string)) continue;
                    n2 = 1;
                    break;
                }
                if (n2 != 0) continue;
                list.add(new SelectorEnreg(string, bl, yP_Row, n));
            }
            return 1;
        }
        catch (Exception exception) {
            this.logger(2, "initialiseSelectorList() ???:", exception);
            return -1;
        }
        finally {
            this.daoAID.unlock();
        }
    }

    private SelectorEnreg search(String string) {
        for (List<SelectorEnreg> list : this.selectorListByPriority) {
            for (SelectorEnreg selectorEnreg : list) {
                if (!(selectorEnreg.partialSelectionAllowed == null || selectorEnreg.partialSelectionAllowed == false ? string.contentEquals(selectorEnreg.aid) : string.startsWith(selectorEnreg.aid))) continue;
                return selectorEnreg;
            }
        }
        return null;
    }

    @Override
    public AcceptationLevelEnumeration getAcceptationLevel(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            EntryModeEnumeration entryModeEnumeration = yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology();
            switch (entryModeEnumeration) {
                case ENTRY_MODE_TAPPED: 
                case ENTRY_MODE_EMV_CONTACTLESS: {
                    return AcceptationLevelEnumeration.UNKNOWN;
                }
            }
            this.reloadIfNeeded();
            List<AccountHandler.ADF> list = yP_TCD_DC_Transaction.accountHandler.getADFList();
            if (list == null || list.isEmpty()) {
                return AcceptationLevelEnumeration.UNKNOWN;
            }
            for (AccountHandler.ADF aDF : list) {
                if (this.search(aDF.aid) == null || this.isForbiddenProduct(aDF)) continue;
                return AcceptationLevelEnumeration.ACCEPTED;
            }
            return AcceptationLevelEnumeration.UNKNOWN;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "getAcceptationLevel()  ???:", exception);
            }
            return null;
        }
    }

    @Override
    public boolean canHandle(EntryModeEnumeration entryModeEnumeration) {
        if (entryModeEnumeration == null) {
            return false;
        }
        switch (entryModeEnumeration) {
            case ENTRY_MODE_ICC: 
            case ENTRY_MODE_SYNC_ICC: {
                return true;
            }
        }
        return false;
    }

    private boolean isForbiddenProduct(AccountHandler.ADF aDF) {
        TLV tLV;
        block10: {
            block9: {
                block8: {
                    if (aDF == null) {
                        return false;
                    }
                    try {
                        if (aDF.emvTagsExtension != null) break block8;
                        if (this.getLogLevel() >= 5) {
                            this.logger(5, "getProductInfo() no product code received!!!");
                        }
                        return false;
                    }
                    catch (Exception exception) {
                        this.logger(2, "getProductInfo() ", exception);
                        return false;
                    }
                }
                TLVHandler tLVHandler = new TLVHandler(aDF.emvTagsExtension);
                tLV = tLVHandler.getTLV(40714);
                if (tLV != null) break block9;
                return false;
            }
            if (tLV.value != null && tLV.value.length >= 3) break block10;
            return false;
        }
        String string = UtilsYP.devHexa(tLV.value);
        String string2 = string.substring(0, 4);
        String string3 = string.substring(4, 6);
        int n = 6 + 2 * Integer.parseInt(string3);
        if (string.length() < n) {
            this.logger(3, "getProductInfo() Invalid product (Italian card ?)");
            n = string.length();
        }
        String string4 = string.substring(6, n);
        return this.isForbiddenProduct(aDF.aid, string2, string4);
    }

    private Bitmap getTransactionTypeAllowed(String string) {
        YP_ComplexGabarit yP_ComplexGabarit = new YP_ComplexGabarit(this.daoSchemeParameters);
        yP_ComplexGabarit.set("entryMode", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_ICC);
        yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.EQUAL, string.toUpperCase());
        yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
        List<YP_Row> list = this.daoSchemeParameters.getRowListSuchAs(yP_ComplexGabarit);
        if (list == null || list.isEmpty()) {
            yP_ComplexGabarit = new YP_ComplexGabarit(this.daoSchemeParameters);
            yP_ComplexGabarit.set("entryMode", YP_ComplexGabarit.OPERATOR.EQUAL, EntryModeEnumeration.ENTRY_MODE_ICC);
            yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.MATCH_BEGINNING, string.toUpperCase());
            yP_ComplexGabarit.set("emvApplicationAID", YP_ComplexGabarit.OPERATOR.ORDER_DESC);
            list = this.daoSchemeParameters.getRowListSuchAs(yP_ComplexGabarit);
            if (list == null || list.isEmpty()) {
                this.logger(2, "getSchemeParameters() row not found");
                return null;
            }
        }
        YP_Row yP_Row = list.get(0);
        return (Bitmap)yP_Row.getFieldValueByName("trsTypeAllowed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean isTransactionTypeAllowed(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, AccountHandler.ADF aDF) {
        if (this.daoSchemeParameters == null) return true;
        if (this.daoSchemeParameters.getRowList().size() == 0) {
            return true;
        }
        String string = this.daoSchemeParameters.getRowAt(0).getFieldStringValueByName("parametersType");
        if (string == null) return true;
        if (string.isEmpty()) return true;
        if (string.contentEquals("CB55")) {
            return true;
        }
        if (aDF == null) {
            return false;
        }
        try {
            Bitmap bitmap = this.getTransactionTypeAllowed(aDF.aid);
            if (bitmap == null) {
                return false;
            }
            TransactionTypeEnumeration transactionTypeEnumeration = yP_TCD_DC_Transaction.commonHandler.getTransactionType();
            switch (transactionTypeEnumeration) {
                case ADDITIONAL_RESERVATION: {
                    if (bitmap.isSet(TransactionTypeEnumeration.ADDITIONAL_RESERVATION.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction ADDITIONAL_RESERVATION not allowed");
                    return false;
                }
                case CLOSING_PAYMENT: 
                case ADVICE_DEBIT: {
                    return true;
                }
                case COMPLEMENTARY_PAYMENT: {
                    if (bitmap.isSet(TransactionTypeEnumeration.COMPLEMENTARY_PAYMENT.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction COMPLEMENTARY_PAYMENT not allowed");
                    return false;
                }
                case COMPLEMENTARY_REFUND: {
                    if (bitmap.isSet(TransactionTypeEnumeration.COMPLEMENTARY_REFUND.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction COMPLEMENTARY_REFUND not allowed");
                    return false;
                }
                case INITIAL_RESERVATION: {
                    if (YP_TCD_DCC_Business.getTransactionAmount(yP_TCD_DC_Transaction) == 0L) {
                        if (bitmap.isSet(TransactionTypeEnumeration.INFORMATION.getValue())) return true;
                        this.logger(2, "isTransactionTypeNotAllowed transaction demande de renseignement not allowed");
                        return false;
                    }
                    EntryModeEnumeration entryModeEnumeration = YP_TCD_DCC_Business.getPaymentTechnology(yP_TCD_DC_Transaction);
                    if (bitmap.isSet(TransactionTypeEnumeration.INITIAL_RESERVATION.getValue())) return true;
                    if (entryModeEnumeration != EntryModeEnumeration.ENTRY_MODE_KEYED) {
                        if (entryModeEnumeration != EntryModeEnumeration.ENTRY_MODE_MANUAL) return true;
                    }
                    this.logger(2, "isTransactionTypeNotAllowed transaction manual INITIAL_RESERVATION not allowed");
                    return false;
                }
                case DEBIT: 
                case ONE_TIME_RESERVATION: {
                    if (bitmap.isSet(TransactionTypeEnumeration.DEBIT.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction debit  not allowed");
                    return false;
                }
                case QUASI_CASH: {
                    if (bitmap.isSet(TransactionTypeEnumeration.QUASI_CASH.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction quasi-cash  not allowed");
                    return false;
                }
                case DEBIT_DIFFERED: {
                    if (bitmap.isSet(TransactionTypeEnumeration.DEBIT_DIFFERED.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction debit differed not allowed");
                    return false;
                }
                case CREDIT: 
                case ADVICE_REFUND: {
                    if (bitmap.isSet(TransactionTypeEnumeration.CREDIT.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction refund not allowed");
                    return false;
                }
                case REFUND_QUASI_CASH: {
                    if (bitmap.isSet(TransactionTypeEnumeration.REFUND_QUASI_CASH.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction refund not allowed");
                    return false;
                }
                case REVERSAL_DEBIT: 
                case ADVICE_REVERSAL: {
                    if (bitmap.isSet(TransactionTypeEnumeration.REVERSAL_DEBIT.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction reversal debit not allowed");
                    return false;
                }
                case REVERSAL_QUASI_CASH: {
                    if (bitmap.isSet(TransactionTypeEnumeration.REVERSAL_QUASI_CASH.getValue())) return true;
                    this.logger(2, "isTransactionTypeNotAllowed transaction reversal debit not allowed");
                    return false;
                }
                default: {
                    this.logger(2, "isTransactionTypeNotAllowed transaction type unknown -> not allowed");
                    return false;
                }
                case ADVICE_NONACHIEVED: 
            }
            return true;
        }
        catch (Exception exception) {
            this.logger(2, "isTransactionTypeNotAllowed() ", exception);
            return false;
        }
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            YP_Application yP_Application = (YP_Application)yP_Object;
            if (string.contentEquals("selectAID")) {
                List list = (List)objectArray[0];
                return this.selectAID(yP_Application.getDataContainerTransaction(), list);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :  ", exception);
            return null;
        }
    }

    private Object selectAID(YP_TCD_DC_Transaction yP_TCD_DC_Transaction, List<AccountHandler.ADF> list) {
        this.reloadIfNeeded();
        if (list == null || list.isEmpty()) {
            this.logger(2, "selectAID() bad parameters");
            return null;
        }
        ArrayList<AccountHandler.ADF> arrayList = new ArrayList<AccountHandler.ADF>();
        for (List<SelectorEnreg> list2 : this.selectorListByPriority) {
            for (Object object : list2) {
                for (AccountHandler.ADF aDF : list) {
                    if (((SelectorEnreg)object).partialSelectionAllowed == null || !((SelectorEnreg)object).partialSelectionAllowed.booleanValue()) {
                        if (!aDF.aid.contentEquals(((SelectorEnreg)object).aid) || this.isForbiddenProduct(aDF) || !this.isTransactionTypeAllowed(yP_TCD_DC_Transaction, aDF)) continue;
                        arrayList.add(aDF);
                        continue;
                    }
                    if (!aDF.aid.startsWith(((SelectorEnreg)object).aid) || this.isForbiddenProduct(aDF) || !this.isTransactionTypeAllowed(yP_TCD_DC_Transaction, aDF)) continue;
                    arrayList.add(aDF);
                }
            }
            if (!arrayList.isEmpty()) break;
        }
        ArrayList<AccountHandler.ADF> arrayList2 = new ArrayList<AccountHandler.ADF>();
        for (AccountHandler.ADF aDF : list) {
            if (!arrayList.contains(aDF)) continue;
            arrayList2.add(aDF);
        }
        return arrayList2;
    }

    class SelectorEnreg {
        String aid;
        Boolean partialSelectionAllowed;
        YP_Row row;
        int priority;

        SelectorEnreg(String string, Boolean bl, YP_Row yP_Row, int n) {
            this.aid = string;
            this.partialSelectionAllowed = bl;
            this.row = yP_Row;
            this.priority = n;
        }
    }
}

