/*
 * Decompiled with CFR 0.152.
 */
package org.yp.framework.ondemandcomponents.appselectors.aid;

import java.util.ArrayList;
import java.util.List;
import org.yp.designaccesobjects.YP_Row;
import org.yp.framework.YP_Object;
import org.yp.framework.YP_OnDemandComponent;
import org.yp.framework.ondemandcomponents.YP_TCD_DesignAccesObject;
import org.yp.framework.ondemandcomponents.appselectors.YP_App_Interface_Selection;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DCC_Business;
import org.yp.framework.ondemandcomponents.datacontainers.YP_TCD_DC_Transaction;
import org.yp.framework.ondemandcomponents.datacontainers.handlers.AccountHandler;
import org.yp.framework.services.YP_TS_GlobalProcessManager;
import org.yp.utils.enums.AcceptationLevelEnumeration;
import org.yp.utils.enums.EntryModeEnumeration;

public class YP_BCD_A_SEL_STD_CTCL_AID
extends YP_OnDemandComponent
implements YP_App_Interface_Selection {
    private YP_TCD_DesignAccesObject daoAID;
    List<List<SelectorEnreg>> selectorListByPriority;

    public YP_BCD_A_SEL_STD_CTCL_AID(YP_Object yP_Object, Object ... objectArray) throws Exception {
        super(yP_Object, objectArray);
        if (yP_Object instanceof YP_TS_GlobalProcessManager) {
            return;
        }
        if (!(yP_Object instanceof YP_TCD_DCC_Business)) {
            this.logger(2, "YP_BCD_A_SEL_STD_CTCL_AID() father must be a data container business");
            throw new Exception();
        }
        ((YP_TCD_DCC_Business)yP_Object).selectorList.add(this);
        if (objectArray == null || objectArray.length < 1) {
            this.logger(2, "YP_BCD_A_SEL_STD_CTCL_AID() bad number of parameters");
            throw new Exception();
        }
        if (objectArray[0] == null || !(objectArray[0] instanceof YP_TCD_DesignAccesObject)) {
            this.logger(2, "YP_BCD_A_SEL_STD_CTCL_AID() bad parameter 1");
            throw new Exception();
        }
        this.daoAID = (YP_TCD_DesignAccesObject)objectArray[0];
        this.daoAID.registerWatcher(this.getProcessID());
    }

    @Override
    public int initialize() {
        super.initialize();
        return 1;
    }

    @Override
    public int shutdown() {
        super.shutdown();
        return 1;
    }

    @Override
    public String toString() {
        return "ApplicationSelectorByCTCLAID";
    }

    @Override
    public String getVersion() {
        return "V1.0.0.0";
    }

    private int reloadIfNeeded() {
        if (this.selectorListByPriority == null || this.daoAID.getProcessID() == this.getNotification()) {
            return this.initialiseSelectorList();
        }
        return 0;
    }

    private int initialiseSelectorList() {
        try {
            this.daoAID.lock();
            this.selectorListByPriority = new ArrayList<List<SelectorEnreg>>();
            for (YP_Row yP_Row : this.daoAID) {
                String string = String.valueOf(yP_Row.getFieldStringValueByName("rid")) + yP_Row.getFieldStringValueByName("pix");
                Boolean bl = (Boolean)yP_Row.getFieldValueByName("partialSelectionAllowed");
                int n = (Integer)yP_Row.getFieldValueByName("priority");
                List<SelectorEnreg> list = null;
                int n2 = 0;
                while (n2 < this.selectorListByPriority.size()) {
                    List<SelectorEnreg> list2 = this.selectorListByPriority.get(n2);
                    if (list2.get((int)0).priority == n) {
                        list = list2;
                        break;
                    }
                    if (list2.get((int)0).priority < n) {
                        list = new ArrayList();
                        this.selectorListByPriority.add(n2, list);
                        break;
                    }
                    ++n2;
                }
                if (list == null) {
                    list = new ArrayList<SelectorEnreg>();
                    this.selectorListByPriority.add(list);
                }
                n2 = 0;
                for (SelectorEnreg selectorEnreg : list) {
                    if (!selectorEnreg.aid.contentEquals(string)) continue;
                    n2 = 1;
                    break;
                }
                if (n2 != 0) continue;
                list.add(new SelectorEnreg(string, bl, yP_Row, n));
            }
            return 1;
        }
        catch (Exception exception) {
            if (this.getLogLevel() >= 2) {
                this.logger(2, "initialiseSelectorList() ???:" + exception);
            }
            return -1;
        }
        finally {
            this.daoAID.unlock();
        }
    }

    private SelectorEnreg search(String string) {
        for (List<SelectorEnreg> list : this.selectorListByPriority) {
            for (SelectorEnreg selectorEnreg : list) {
                if (!(selectorEnreg.partialSelectionAllowed == null || selectorEnreg.partialSelectionAllowed == false ? string.contentEquals(selectorEnreg.aid) : string.startsWith(selectorEnreg.aid))) continue;
                return selectorEnreg;
            }
        }
        return null;
    }

    @Override
    public AcceptationLevelEnumeration getAcceptationLevel(YP_TCD_DC_Transaction yP_TCD_DC_Transaction) {
        try {
            EntryModeEnumeration entryModeEnumeration = yP_TCD_DC_Transaction.commonHandler.getPaymentTechnology();
            switch (entryModeEnumeration) {
                case ENTRY_MODE_TAPPED: 
                case ENTRY_MODE_EMV_CONTACTLESS: {
                    break;
                }
                default: {
                    return AcceptationLevelEnumeration.UNKNOWN;
                }
            }
            this.reloadIfNeeded();
            List<AccountHandler.ADF> list = yP_TCD_DC_Transaction.accountHandler.getADFList();
            if (list == null || list.isEmpty()) {
                return AcceptationLevelEnumeration.UNKNOWN;
            }
            for (AccountHandler.ADF aDF : list) {
                if (this.search(aDF.aid) == null) continue;
                return AcceptationLevelEnumeration.ACCEPTED;
            }
            return AcceptationLevelEnumeration.UNKNOWN;
        }
        catch (Exception exception) {
            this.logger(2, "getAcceptationLevel()  ???:" + exception);
            return null;
        }
    }

    @Override
    public boolean canHandle(EntryModeEnumeration entryModeEnumeration) {
        if (entryModeEnumeration == null) {
            return false;
        }
        switch (entryModeEnumeration) {
            case ENTRY_MODE_TAPPED: 
            case ENTRY_MODE_EMV_CONTACTLESS: {
                return true;
            }
        }
        return false;
    }

    @Override
    public Object dealRequest(YP_Object yP_Object, String string, Object ... objectArray) {
        try {
            if (string.contentEquals("selectAID")) {
                List list = (List)objectArray[0];
                return this.selectAID(list);
            }
            this.logger(2, "dealRequest() request unknown " + string);
            return null;
        }
        catch (Exception exception) {
            this.logger(2, "dealRequest() bad request ??? :  " + exception);
            return null;
        }
    }

    private Object selectAID(List<AccountHandler.ADF> list) {
        this.reloadIfNeeded();
        if (list == null || list.isEmpty()) {
            this.logger(2, "selectAID() bad parameters");
            return null;
        }
        ArrayList<AccountHandler.ADF> arrayList = new ArrayList<AccountHandler.ADF>();
        for (List<SelectorEnreg> list2 : this.selectorListByPriority) {
            for (SelectorEnreg selectorEnreg : list2) {
                for (AccountHandler.ADF aDF : list) {
                    if (selectorEnreg.partialSelectionAllowed == null || !selectorEnreg.partialSelectionAllowed.booleanValue()) {
                        if (!aDF.aid.contentEquals(selectorEnreg.aid)) continue;
                        arrayList.add(aDF);
                        continue;
                    }
                    if (!aDF.aid.startsWith(selectorEnreg.aid)) continue;
                    arrayList.add(aDF);
                }
            }
            if (!arrayList.isEmpty()) break;
        }
        return arrayList;
    }

    class SelectorEnreg {
        String aid;
        Boolean partialSelectionAllowed;
        YP_Row row;
        int priority;

        SelectorEnreg(String string, Boolean bl, YP_Row yP_Row, int n) {
            this.aid = string;
            this.partialSelectionAllowed = bl;
            this.row = yP_Row;
            this.priority = n;
        }
    }
}

